# Valepólis V0.3.0 — Consolidação das prioridades 15–22

## Alterações efetivamente aplicadas
- Controlos de câmara por toque: arrasto com um dedo para rodar; gesto com dois dedos para ajustar a distância.
- Limites centrais de distância da câmara (38–230) aplicados também à roda do rato, para reduzir aproximações extremas.
- Preservados o projeto, o workflow e os sistemas existentes.

## Auditorias executadas neste ambiente
- `tools/preflight_project.py`: 40 verificações estáticas passaram.
- `tools/preflight_regional_roads.py`: grafo/registos regionais passaram; o próprio teste assinala que não valida geometria física.
- `tools/validate_company_runtime_registry.py`: 100 empresas/candidaturas verificadas; Godot runtime não executado.
- `tools/validate_company_entity_employment_v030.py`: 8 verificações passaram.
- `tools/preflight_installations.py`: 25 verificações passaram.
- `tools/validate_master_registry.py`: falhou uma verificação: `master_company_count_matches` (valor 41). Não alterado porque não existe confirmação de qual é o total mestre correto.

## Limitações importantes
O executável Godot não está instalado neste ambiente. Não foi possível executar a cena, fazer teste visual 3D, validar colisões/percursos físicos ou compilar/instalar a APK Android. Portanto, estas fases não são declaradas concluídas funcionalmente. A rede regional tem um grafo lógico, mas isso não prova que todas as estradas e pontes estejam fisicamente ligadas e transitáveis. As empresas/instalações continuam propostas até existir aprovação e ligação a edifícios físicos confirmados.

## Prioridades abrangidas
15. Rede rodoviária física — auditoria estática disponível; validação geométrica pendente.
16. Pontes/acessos regionais — conectividade lógica auditada; travessia física pendente.
17. Trânsito — scripts e registos auditados; circulação em runtime pendente.
18. Mapa/terreno — recursos preservados; inspeção visual pendente.
19. Câmara/controlos móveis — toque e limites de zoom ajustados; teste em dispositivo pendente.
20. Habitantes/empresas — validadores estáticos executados; ligação física/rotinas em runtime pendentes.
21. Auditoria integrada — validadores disponíveis executados; há uma falha de contagem mestre por resolver.
22. APK Android — não compilada nem instalada neste ambiente.

## Resultado honesto
ZIP empacotado e integridade a verificar após criação. Isto é uma consolidação de correções e auditorias, não uma certificação de jogo pronto.

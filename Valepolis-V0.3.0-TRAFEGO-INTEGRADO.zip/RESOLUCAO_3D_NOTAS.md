# Valepólis V0.3.0 — melhoria de resolução 3D

Alterações desta revisão:
- viewport principal de referência aumentado de 720x1280 para 1080x1920;
- SubViewport do mapa renderiza a 1320x1336 e é reduzido pelo SubViewportContainer;
- anti-aliasing MSAA 2x no mapa e nas pré-visualizações 3D;
- pré-visualizações de personagem renderizam com mais píxeis;
- filtro de texturas suavizado.

A resolução superior aumenta a carga gráfica e o consumo de memória. A configuração deve ser validada em execução no Godot e num dispositivo Android real; não se declara a compilação ou o desempenho móvel como testados nesta revisão.

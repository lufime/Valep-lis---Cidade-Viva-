# Valepólis V0.3.0 — Circulação V13

Continua a partir da V12. A geração de ligações entre bairros verifica agora as amostras dos eixos contra as caixas delimitadoras (AABB) dos objetos `Edificio_*` e `Cobertura_*`, com margem de segurança. Se um segmento tiver uma amostra demasiado próxima de um edifício, fica marcado como geometricamente não validado e a função de rota recusa-o.

Limitações: não cria desvios automáticos nem recalcula uma rota alternativa; é uma primeira barreira contra trajetórias que atravessem edifícios. AABB pode produzir falsos positivos e não deteta água, terreno, árvores, instalações ou colisões complexas. O custo de verificação e a sintaxe Godot precisam de teste no projeto real. ZIP verificado quanto à integridade, mas não executado no Godot.

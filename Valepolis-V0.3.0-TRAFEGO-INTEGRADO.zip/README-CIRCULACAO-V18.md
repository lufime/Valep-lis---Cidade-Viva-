# Valepólis V0.3.0 — Circulação V18

Base: V17 corrigida PRE-FLIGHT.

## Alterações
- A atribuição explícita de uma rota verifica se o veículo está a até 8 unidades do início; não teletransporta veículos distantes.
- Rotas atribuídas deixam de fazer loop no fim: o agente fica marcado como concluído.
- Adicionada `get_vehicle_route_status(agent_index)` para consultar origem, destino, progresso e conclusão.
- Os agentes de circulação ambiente mantêm o comportamento de percurso repetitivo existente.

## Limites
- A rota ainda depende da geometria linear e das heurísticas existentes. Não garante ausência de água, instalações, obstáculos ou colisões.
- Não implementa semáforos funcionais, regras completas do Código da Estrada, nem despacho automático de veículos.
- Não houve compilação Godot nesta execução. É obrigatório correr o workflow e inspecionar o comportamento em jogo antes de considerar a alteração aprovada.

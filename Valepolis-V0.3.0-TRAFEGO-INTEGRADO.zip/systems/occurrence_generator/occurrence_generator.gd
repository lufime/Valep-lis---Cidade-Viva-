extends RefCounted
class_name ValepolisOccurrenceGenerator

# Gerador de ocorrências visuais fictícias.
# A imagem e a animação são referências de estado; os assets finais podem
# substituir os placeholders sem alterar a lógica.

const CATALOG := [
    {"id":"INC-FIRE","name":"Incêndio estrutural","severity":"alta","image":"incendio_estrutural","animation":"fire_structure"},
    {"id":"INC-ROAD","name":"Acidente rodoviário","severity":"alta","image":"acidente_rodoviario","animation":"traffic_collision"},
    {"id":"INC-MED","name":"Emergência médica","severity":"alta","image":"emergencia_medica","animation":"medical_response"},
    {"id":"INC-RES","name":"Resgate de pessoa","severity":"alta","image":"resgate_pessoa","animation":"rescue_person"},
    {"id":"INC-FLOOD","name":"Inundação","severity":"media","image":"inundacao","animation":"flood_water"},
    {"id":"INC-STORM","name":"Tempestade","severity":"media","image":"tempestade","animation":"storm"},
    {"id":"INC-VEH","name":"Avaria de veículo","severity":"baixa","image":"avaria_veiculo","animation":"vehicle_hazard"},
    {"id":"INC-URBAN","name":"Incidente urbano","severity":"media","image":"incidente_urbano","animation":"urban_response"},
    {"id":"INC-MISSING","name":"Pessoa desaparecida","severity":"alta","image":"pessoa_desaparecida","animation":"search_operation"},
    {"id":"INC-FIRE-WILD","name":"Incêndio florestal","severity":"alta","image":"incendio_florestal","animation":"wildfire"}
]

static func generate(seed: int, neighborhood: String = "") -> Dictionary:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed
    var item: Dictionary = CATALOG[rng.randi_range(0,CATALOG.size()-1)].duplicate(true)
    item["instance_id"] = "OCC-%08d" % abs(seed)
    item["neighborhood"] = neighborhood
    item["seed"] = seed
    item["state"] = "detetada"
    item["progress"] = 0.0
    item["visual_path"] = "res://assets/occurrences/" + str(item["image"]) + ".png"
    item["animation_key"] = str(item["animation"])
    return item

static func visual_path(occurrence: Dictionary) -> String:
    return str(occurrence.get("visual_path",""))

static func animation_key(occurrence: Dictionary) -> String:
    return str(occurrence.get("animation_key","idle"))

extends RefCounted
class_name ValepolisOccurrenceAnimation

# Biblioteca de animações lógicas. A implementação visual pode usar AnimatedSprite2D,
# AnimationPlayer ou partículas, dependendo da cena. Não cria pop-ups.

const STATES := {
    "fire_structure": ["detected","smoke","flames","response","contained","resolved"],
    "traffic_collision": ["detected","warning","response","scene_control","cleared"],
    "medical_response": ["detected","dispatch","arrival","care","transport","resolved"],
    "rescue_person": ["detected","search","contact","rescue","resolved"],
    "flood_water": ["detected","rising","peak","receding","resolved"],
    "storm": ["detected","intensifying","peak","weakening","resolved"],
    "vehicle_hazard": ["detected","warning","assistance","cleared"],
    "urban_response": ["detected","dispatch","response","stabilized","resolved"],
    "search_operation": ["detected","search","located","safe","resolved"],
    "wildfire": ["detected","spread","response","contained","extinguished"]
}

static func states(animation_key: String) -> Array:
    return STATES.get(animation_key, ["detected","active","resolved"])

static func progress_state(animation_key: String, progress: float) -> String:
    var s := states(animation_key)
    var idx := clampi(int(floor(clampf(progress,0.0,0.9999)*s.size())),0,s.size()-1)
    return str(s[idx])

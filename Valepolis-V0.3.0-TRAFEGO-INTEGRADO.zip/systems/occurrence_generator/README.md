# Gerador de Ocorrências e Animações V0.3.0

Gera ocorrências com ID, gravidade, bairro, imagem visual e estado de animação.
A animação é uma máquina de estados e pode ser ligada a AnimatedSprite2D,
AnimationPlayer ou partículas.

Os SVG são placeholders leves e substituíveis por arte final.

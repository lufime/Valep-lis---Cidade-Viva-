extends Node

const REGISTRY_PATH := "res://data/catalogo_empresas_v030.json"
const ADDRESS_PATH := "res://data/enderecamento_valepolis.json"

var _loaded := false
var _last_error := ""
var _catalog: Dictionary = {}
var _companies_by_id: Dictionary = {}
var _addresses_by_id: Dictionary = {}
var _companies_by_neighborhood: Dictionary = {}

func _ready() -> void:
    load_registry()

func load_registry() -> bool:
    _loaded = false
    _last_error = ""
    _catalog.clear()
    _companies_by_id.clear()
    _addresses_by_id.clear()
    _companies_by_neighborhood.clear()
    var addresses_data: Variant = _read_json(ADDRESS_PATH)
    if not (addresses_data is Dictionary):
        return _fail("Cadastro de moradas indisponível ou inválido.")
    for address in addresses_data.get("addresses", []):
        if not (address is Dictionary):
            return _fail("Existe um registo de morada inválido.")
        var address_id := str(address.get("id", ""))
        if address_id.is_empty() or _addresses_by_id.has(address_id):
            return _fail("ID de morada vazio ou duplicado: %s" % address_id)
        _addresses_by_id[address_id] = address

    var data: Variant = _read_json(REGISTRY_PATH)
    if not (data is Dictionary):
        return _fail("Catálogo de empresas indisponível ou inválido.")
    var rows: Variant = data.get("companies", [])
    if not (rows is Array):
        return _fail("A lista de empresas é inválida.")
    for row in rows:
        if not (row is Dictionary):
            return _fail("Existe um registo de empresa inválido.")
        var company_id := str(row.get("company_id", ""))
        if company_id.is_empty() or _companies_by_id.has(company_id):
            return _fail("ID de empresa vazio ou duplicado: %s" % company_id)
        var candidate_id := str(row.get("proposed_address_candidate_id", ""))
        if not candidate_id.is_empty():
            if not _addresses_by_id.has(candidate_id):
                return _fail("Morada candidata inexistente para %s: %s" % [company_id, candidate_id])
            var address: Dictionary = _addresses_by_id[candidate_id]
            var company_neighborhood := str(row.get("neighborhood_name", ""))
            if str(address.get("bairro", "")) != company_neighborhood:
                return _fail("Bairro da morada não coincide com a empresa %s." % company_id)
        _companies_by_id[company_id] = row
        var neighborhood := str(row.get("neighborhood_name", ""))
        if not _companies_by_neighborhood.has(neighborhood):
            _companies_by_neighborhood[neighborhood] = []
        _companies_by_neighborhood[neighborhood].append(row)
    _catalog = data
    _loaded = true
    return true

func _read_json(path: String) -> Variant:
    if not FileAccess.file_exists(path):
        _last_error = "Ficheiro não encontrado: %s" % path
        return null
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        _last_error = "Não foi possível abrir: %s" % path
        return null
    return JSON.parse_string(file.get_as_text())

func _fail(message: String) -> bool:
    _loaded = false
    _last_error = message
    push_warning(message)
    return false

func is_loaded() -> bool:
    return _loaded

func get_last_error() -> String:
    return _last_error

func get_summary() -> Dictionary:
    return {"loaded": _loaded, "company_count": _companies_by_id.size(), "neighborhood_count": _companies_by_neighborhood.size(), "candidate_addresses": _count_candidate_addresses(), "physically_bound": _count_physically_bound(), "error": _last_error}

func _count_candidate_addresses() -> int:
    var count := 0
    for row in _companies_by_id.values():
        if not str(row.get("proposed_address_candidate_id", "")).is_empty():
            count += 1
    return count

func _count_physically_bound() -> int:
    var count := 0
    for row in _companies_by_id.values():
        if str(row.get("building_id", "")).strip_edges().is_empty():
            continue
        var pos: Variant = row.get("map_position", null)
        if bool(row.get("map_spawned", false)) and str(row.get("record_status", "")) == "aprovado" and pos is Array and pos.size() >= 3:
            count += 1
    return count

func get_all_companies() -> Array:
    return _companies_by_id.values() if _loaded else []

func get_company(company_id: String) -> Dictionary:
    return _companies_by_id.get(company_id, {}).duplicate(true) if _loaded else {}

func get_companies_for_neighborhood(neighborhood_name: String) -> Array:
    return _companies_by_neighborhood.get(neighborhood_name, []).duplicate(true) if _loaded else []

func get_candidate_address(company_id: String) -> Dictionary:
    if not _loaded or not _companies_by_id.has(company_id):
        return {}
    var address_id := str(_companies_by_id[company_id].get("proposed_address_candidate_id", ""))
    return _addresses_by_id.get(address_id, {}).duplicate(true)

func get_map_spawnable_companies() -> Array:
    # Nunca criar empresa no mapa apenas porque existe uma morada candidata.
    var result: Array = []
    if not _loaded:
        return result
    for row in _companies_by_id.values():
        var pos: Variant = row.get("map_position", null)
        if str(row.get("record_status", "")) != "aprovado":
            continue
        if not bool(row.get("map_spawned", false)):
            continue
        if str(row.get("building_id", "")).strip_edges().is_empty():
            continue
        if not (pos is Array) or pos.size() < 3:
            continue
        result.append(row.duplicate(true))
    return result

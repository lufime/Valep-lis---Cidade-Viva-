extends Node

const REGISTRY_PATH := "res://data/installation_registry_v030.json"
const OVERRIDES_PATH := "user://valepolis_installation_overrides_v030.json"
const DEFERRED_FIELDS := ["staff_count", "staff_ids", "teams", "vehicle_count", "vehicle_ids", "inventory", "economy", "budget_eur", "balance_eur", "capacity", "opening_hours", "departments"]
const MAP_BINDING_FIELDS := ["map_spawned", "building_id", "map_position", "record_status", "map_object_link_status"]

var _registry: Dictionary = {}
var _by_id: Dictionary = {}
var _overrides: Dictionary = {}
var _loaded := false
var _last_error := ""

func _ready() -> void:
    load_registry()
    _load_overrides()

func load_registry() -> bool:
    _loaded = false
    _registry.clear()
    _by_id.clear()
    if not FileAccess.file_exists(REGISTRY_PATH):
        _last_error = "Ficheiro de instalações não encontrado: %s" % REGISTRY_PATH
        push_warning(_last_error)
        return false
    var file := FileAccess.open(REGISTRY_PATH, FileAccess.READ)
    if file == null:
        _last_error = "Não foi possível abrir o registo de instalações."
        push_warning(_last_error)
        return false
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary):
        _last_error = "O registo de instalações não contém um objeto JSON válido."
        push_warning(_last_error)
        return false
    var rows: Variant = parsed.get("installations", [])
    if not (rows is Array):
        _last_error = "A lista de instalações é inválida."
        push_warning(_last_error)
        return false
    for row in rows:
        if not (row is Dictionary):
            _last_error = "Existe um registo de instalação inválido."
            return false
        var iid := str(row.get("installation_id", ""))
        if iid.is_empty() or _by_id.has(iid):
            _last_error = "ID de instalação vazio ou duplicado: %s" % iid
            _by_id.clear()
            return false
        _by_id[iid] = row
    _registry = parsed
    _loaded = true
    _last_error = ""
    return true

func _load_overrides() -> void:
    _overrides.clear()
    if not FileAccess.file_exists(OVERRIDES_PATH):
        return
    var file := FileAccess.open(OVERRIDES_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if parsed is Dictionary:
        _overrides = parsed

func is_loaded() -> bool:
    return _loaded

func get_last_error() -> String:
    return _last_error

func get_registry_summary() -> Dictionary:
    if not _loaded:
        return {"loaded": false, "error": _last_error, "physical_installations": 0, "embedded_units": 0}
    var embedded: Array = _registry.get("embedded_units", [])
    var neighborhoods: Array = _registry.get("neighborhood_distribution", [])
    return {"loaded": true, "status": str(_registry.get("status", "")), "physical_installations": _by_id.size(), "embedded_units": embedded.size(), "neighborhoods": neighborhoods.size(), "tnur_standalone_installations": int(_registry.get("count_summary", {}).get("tnur_standalone_installations", 0))}

func get_all_installations() -> Array:
    if not _loaded:
        return []
    var result: Array = []
    for row in _registry.get("installations", []):
        result.append(_apply_overrides(row))
    return result

func get_installation(installation_id: String) -> Dictionary:
    if not _loaded or not _by_id.has(installation_id):
        return {}
    return _apply_overrides(_by_id[installation_id])

func get_map_spawnable_installations() -> Array:
    # Só devolve locais com aprovação explícita, ID físico e coordenadas já
    # definidas. Propostas sem aprovação não são criadas no mundo 3D.
    var result: Array = []
    for row in get_all_installations():
        var map_position: Variant = row.get("map_position", null)
        if not bool(row.get("map_spawned", false)):
            continue
        if str(row.get("record_status", "")) != "aprovado":
            continue
        if str(row.get("building_id", "")).strip_edges().is_empty():
            continue
        if not (map_position is Array) or map_position.size() < 3:
            continue
        var valid_coordinates := true
        for coordinate in map_position.slice(0, 3):
            if not (coordinate is int or coordinate is float):
                valid_coordinates = false
                break
        if valid_coordinates:
            result.append(row)
    return result

func get_installations_for_entity(entity_id: String) -> Array:
    var result: Array = []
    for row in get_all_installations():
        if str(row.get("entity_id", "")) == entity_id:
            result.append(row)
    return result

func get_installations_for_neighborhood(neighborhood_name: String) -> Array:
    var result: Array = []
    for row in get_all_installations():
        if str(row.get("neighborhood_name", "")) == neighborhood_name:
            result.append(row)
    return result

func get_embedded_units_for_host(installation_id: String) -> Array:
    var result: Array = []
    if not _loaded:
        return result
    for unit in _registry.get("embedded_units", []):
        if str(unit.get("host_installation_id", "")) == installation_id:
            result.append(unit.duplicate(true))
    return result

func get_embedded_units_for_entity(entity_id: String) -> Array:
    var result: Array = []
    if not _loaded:
        return result
    for unit in _registry.get("embedded_units", []):
        if str(unit.get("entity_id", "")) == entity_id:
            result.append(unit.duplicate(true))
    return result

func get_neighborhood_distribution() -> Array:
    if not _loaded:
        return []
    var distribution: Array = _registry.get("neighborhood_distribution", [])
    return distribution.duplicate(true)

func _apply_overrides(source: Dictionary) -> Dictionary:
    var result: Dictionary = source.duplicate(true)
    var iid := str(result.get("installation_id", ""))
    var custom: Variant = _overrides.get(iid, {})
    if custom is Dictionary:
        for field in custom.keys():
            if field in DEFERRED_FIELDS or field in MAP_BINDING_FIELDS:
                result[field] = custom[field]
    return result

func _persist_overrides() -> bool:
    var file := FileAccess.open(OVERRIDES_PATH, FileAccess.WRITE)
    if file == null:
        return false
    file.store_string(JSON.stringify(_overrides, "\t"))
    file.close()
    return true

func set_deferred_field(installation_id: String, field: String, value: Variant) -> Dictionary:
    if not _loaded or not _by_id.has(installation_id):
        return {"ok": false, "error": "Instalação não encontrada."}
    if not (field in DEFERRED_FIELDS):
        return {"ok": false, "error": "Campo não permitido para configuração adiada."}
    if field in ["staff_count", "vehicle_count", "budget_eur", "balance_eur", "capacity"] and value != null and float(value) < 0.0:
        return {"ok": false, "error": "O valor numérico não pode ser negativo."}
    var previous_overrides: Dictionary = _overrides.duplicate(true)
    if not _overrides.has(installation_id):
        _overrides[installation_id] = {}
    _overrides[installation_id][field] = value
    if not _persist_overrides():
        _overrides = previous_overrides
        return {"ok": false, "error": "Não foi possível guardar a configuração no dispositivo."}
    return {"ok": true, "installation_id": installation_id, "field": field, "configured": value != null}

func activate_installation_on_map(installation_id: String, building_id: String, map_position: Array, explicitly_approved: bool = false) -> Dictionary:
    if not explicitly_approved:
        return {"ok": false, "error": "A instalação só pode ser criada após aprovação explícita."}
    if not _loaded or not _by_id.has(installation_id):
        return {"ok": false, "error": "Instalação não encontrada."}
    if building_id.strip_edges().is_empty():
        return {"ok": false, "error": "É obrigatório indicar um ID físico."}
    if map_position.size() < 3:
        return {"ok": false, "error": "A posição 3D tem de conter X, Y e Z."}
    for coordinate in map_position.slice(0, 3):
        if not (coordinate is int or coordinate is float):
            return {"ok": false, "error": "As coordenadas 3D têm de ser numéricas."}
    for row in get_all_installations():
        if str(row.get("installation_id", "")) != installation_id and bool(row.get("map_spawned", false)) and str(row.get("building_id", "")) == building_id:
            return {"ok": false, "error": "O ID físico já está associado a outra instalação."}
    var previous_overrides: Dictionary = _overrides.duplicate(true)
    if not _overrides.has(installation_id):
        _overrides[installation_id] = {}
    _overrides[installation_id]["map_spawned"] = true
    _overrides[installation_id]["building_id"] = building_id
    _overrides[installation_id]["map_position"] = map_position.slice(0, 3)
    _overrides[installation_id]["record_status"] = "aprovado"
    _overrides[installation_id]["map_object_link_status"] = "objeto_3d_criado"
    if not _persist_overrides():
        _overrides = previous_overrides
        return {"ok": false, "error": "Não foi possível guardar a ligação 3D."}
    return {"ok": true, "installation_id": installation_id, "building_id": building_id}

func validate_registry() -> Dictionary:
    var errors: Array[String] = []
    var warnings: Array[String] = []
    if not _loaded:
        return {"ok": false, "errors": [_last_error], "warnings": []}
    var seen_addresses: Dictionary = {}
    var seen_buildings: Dictionary = {}
    for row in get_all_installations():
        var iid := str(row.get("installation_id", ""))
        var address_id := str(row.get("address_id", ""))
        if address_id.is_empty():
            errors.append("Morada em falta: %s" % iid)
        elif seen_addresses.has(address_id):
            errors.append("Morada duplicada: %s" % address_id)
        else:
            seen_addresses[address_id] = true
        if bool(row.get("map_spawned", false)):
            var building_id := str(row.get("building_id", "")).strip_edges()
            var map_position: Variant = row.get("map_position", null)
            if str(row.get("record_status", "")) != "aprovado":
                errors.append("Instalação criada sem aprovação explícita: %s" % iid)
            if building_id.is_empty() or seen_buildings.has(building_id):
                errors.append("ID físico vazio ou duplicado: %s" % iid)
            else:
                seen_buildings[building_id] = true
            if not (map_position is Array) or map_position.size() < 3:
                errors.append("Coordenadas 3D em falta: %s" % iid)
            else:
                for coordinate in map_position.slice(0, 3):
                    if not (coordinate is int or coordinate is float):
                        errors.append("Coordenada 3D não numérica: %s" % iid)
                        break
        for field in ["staff_count", "vehicle_count", "inventory", "economy", "budget_eur", "balance_eur", "capacity", "opening_hours"]:
            if row.get(field, null) != null:
                warnings.append("Campo adiado preenchido na proposta: %s.%s" % [iid, field])
    for unit in _registry.get("embedded_units", []):
        if bool(unit.get("standalone_installation", true)) or bool(unit.get("counts_as_physical_location", true)):
            errors.append("Unidade integrada contabilizada como instalação independente: %s" % str(unit.get("unit_id", "?")))
        if not _by_id.has(str(unit.get("host_installation_id", ""))):
            errors.append("Unidade integrada sem instalação anfitriã válida: %s" % str(unit.get("unit_id", "?")))
    if int(_registry.get("count_summary", {}).get("tnur_standalone_installations", -1)) != 0:
        errors.append("TNUR não pode ter instalações independentes.")
    var embedded: Array = _registry.get("embedded_units", [])
    return {"ok": errors.is_empty(), "errors": errors, "warnings": warnings, "physical_installations": _by_id.size(), "embedded_units": embedded.size()}

extends Control
class_name ValepolisNeighborhoodOverviewMap

signal neighborhood_selected(neighborhood_name: String)

const DATA_PATH := "res://data/limites_bairros_v030.json"
const COLORS := [Color("#2e7568"), Color("#426d8b"), Color("#8d7548"), Color("#477b59"), Color("#706a9b"), Color("#367f85"), Color("#8d5d55")]
var _neighborhoods: Array[Dictionary] = []
var _world_bounds := Rect2(-52.5, -49.161, 105.0, 98.322)
var _font: Font
var _selected := ""

func _ready() -> void:
    custom_minimum_size = Vector2(0, 230)
    size_flags_horizontal = Control.SIZE_EXPAND_FILL
    mouse_filter = Control.MOUSE_FILTER_STOP
    _font = ThemeDB.fallback_font
    _load_data()
    queue_redraw()

func _load_data() -> void:
    if not FileAccess.file_exists(DATA_PATH):
        push_warning("Mapa geral: limites_bairros_v030.json não encontrado.")
        return
    var file := FileAccess.open(DATA_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary):
        push_warning("Mapa geral: ficheiro de limites inválido.")
        return
    var bounds: Dictionary = parsed.get("world_bounds_xz", {})
    if bounds.size() >= 4:
        var min_x := float(bounds.get("min_x", -52.5))
        var max_x := float(bounds.get("max_x", 52.5))
        var min_z := float(bounds.get("min_z", -49.161))
        var max_z := float(bounds.get("max_z", 49.161))
        _world_bounds = Rect2(min_x, min_z, max_x - min_x, max_z - min_z)
    for item in parsed.get("neighborhoods", []):
        if item is Dictionary and item.has("name") and item.get("boundary_xz", []) is Array:
            _neighborhoods.append(item)

func _map_rect() -> Rect2:
    var margin := 12.0
    var available := size - Vector2(margin * 2.0, margin * 2.0)
    var aspect := _world_bounds.size.x / maxf(_world_bounds.size.y, 0.01)
    var w := available.x
    var h := w / aspect
    if h > available.y:
        h = available.y
        w = h * aspect
    return Rect2((size - Vector2(w, h)) * 0.5, Vector2(w, h))

func _world_to_screen(p: Vector2, r: Rect2) -> Vector2:
    return Vector2(r.position.x + (p.x - _world_bounds.position.x) / _world_bounds.size.x * r.size.x,
        r.position.y + (p.y - _world_bounds.position.y) / _world_bounds.size.y * r.size.y)

func _draw() -> void:
    draw_rect(Rect2(Vector2.ZERO, size), Color("#103746"), true)
    var r := _map_rect()
    # Faixa exterior representa água/margens sem atribuir essa área a bairros.
    draw_rect(r, Color("#226579"), true)
    var font_size := 10 if size.x < 560 else 12
    for i in range(_neighborhoods.size()):
        var item := _neighborhoods[i]
        var points: PackedVector2Array = []
        for raw in item.get("boundary_xz", []):
            if raw is Dictionary:
                points.append(_world_to_screen(Vector2(float(raw.get("x", 0.0)), float(raw.get("z", 0.0))), r))
        if points.size() < 3:
            continue
        var name := str(item.get("name", ""))
        var color: Color = COLORS[i % COLORS.size()]
        if name == _selected:
            color = color.lightened(0.22)
        draw_colored_polygon(points, color)
        var closed := points.duplicate()
        closed.append(points[0])
        draw_polyline(closed, Color("#d8e6d8"), 1.2, true)
        var center := _world_to_screen(Vector2(float(item.get("center_xz", {}).get("x", 0.0)), float(item.get("center_xz", {}).get("z", 0.0))), r)
        var label := name
        var text_size := _font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size)
        draw_string(_font, center - Vector2(text_size.x * 0.5, -font_size * 0.35), label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color.WHITE)
    draw_rect(r, Color("#a8d3d9"), false, 2.0)
    draw_string(_font, Vector2(10, 18), "MAPA GERAL • 25 BAIRROS INDEPENDENTES", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color("#e7d99b"))

func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        _select_at(event.position)
    elif event is InputEventScreenTouch and event.pressed:
        _select_at(event.position)

func _select_at(point: Vector2) -> void:
    var r := _map_rect()
    if not r.has_point(point):
        return
    var world := Vector2(
        _world_bounds.position.x + (point.x - r.position.x) / r.size.x * _world_bounds.size.x,
        _world_bounds.position.y + (point.y - r.position.y) / r.size.y * _world_bounds.size.y
    )
    for item in _neighborhoods:
        var polygon := PackedVector2Array()
        for raw in item.get("boundary_xz", []):
            if raw is Dictionary:
                polygon.append(Vector2(float(raw.get("x", 0.0)), float(raw.get("z", 0.0))))
        if polygon.size() >= 3 and Geometry2D.is_point_in_polygon(world, polygon):
            _selected = str(item.get("name", ""))
            queue_redraw()
            neighborhood_selected.emit(_selected)
            accept_event()
            return

extends RefCounted
class_name ValepolisAnimationAssetLibrary

const ROOT := "res://assets/animations/v030/"

static func clip(character_id:String, animation_key:String) -> String:
    return "%s%s/%s.tres" % [ROOT, character_id, animation_key]

static func preview(character_id:String, animation_key:String) -> String:
    return "%s%s/previews/%s.png" % [ROOT, character_id, animation_key]

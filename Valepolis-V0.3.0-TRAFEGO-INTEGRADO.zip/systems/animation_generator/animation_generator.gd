extends RefCounted
class_name ValepolisAnimationGenerator

## V0.3.0 — Gerador de animações de personagens
## Estilo alvo: 3D cartoon realista de videojogo, semelhante a uma produção
## cinematográfica de cidade viva. Não usar bonecos pixelizados ou formas primitivas
## como arte final.

const VERSION := "0.3.0"
const FPS := 24
const WALK_FRAMES := 8
const RUN_FRAMES := 8

const ANIMATION_PROFILES := {
    "idle": {"loop": true, "frames": 8, "fps": 12},
    "walk": {"loop": true, "frames": 8, "fps": 24},
    "run": {"loop": true, "frames": 8, "fps": 30},
    "talk": {"loop": true, "frames": 10, "fps": 18},
    "phone": {"loop": true, "frames": 10, "fps": 18},
    "sit": {"loop": true, "frames": 8, "fps": 16},
    "work": {"loop": true, "frames": 12, "fps": 18},
    "drive": {"loop": true, "frames": 12, "fps": 24},
    "rescue": {"loop": false, "frames": 16, "fps": 24},
    "fire_response": {"loop": false, "frames": 20, "fps": 24},
    "medical_response": {"loop": false, "frames": 18, "fps": 24},
    "enter_exit": {"loop": false, "frames": 14, "fps": 24}
}

static func generate_profile(seed_value:int, character_id:String, profession:String="") -> Dictionary:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    var profile := {
        "version": VERSION,
        "character_id": character_id,
        "profession": profession,
        "style": "realistic_cartoon_3d_game",
        "camera": "three_quarter_full_body",
        "lighting": "natural_cinematic",
        "material_quality": "game_ready",
        "animation_fps": 24,
        "speed_scale": rng.randf_range(0.88,1.14),
        "stride_scale": rng.randf_range(0.92,1.08),
        "body_sway": rng.randf_range(0.75,1.25),
        "arm_swing": rng.randf_range(0.85,1.18),
        "head_turn": rng.randf_range(0.75,1.20),
        "idle_offset": rng.randf_range(0.0,1.0),
        "gesture_variant": rng.randi_range(0,15),
        "walk_variant": rng.randi_range(0,7),
        "run_variant": rng.randi_range(0,7),
        "talk_variant": rng.randi_range(0,7),
        "unique_motion_profile": true,
        "clone": false
    }
    return profile

static func animation_data(animation_key:String) -> Dictionary:
    return ANIMATION_PROFILES.get(animation_key, ANIMATION_PROFILES["idle"])

static func required_assets(animation_key:String) -> Array[String]:
    return [
        "character_model",
        "skeleton",
        "materials",
        "animation_clip:%s" % animation_key
    ]

static func validate_final_art(asset_path:String) -> bool:
    # Final art must be supplied by the project asset pipeline.
    # This generator intentionally does not create pixel-art placeholders.
    return asset_path != "" and ResourceLoader.exists(asset_path)

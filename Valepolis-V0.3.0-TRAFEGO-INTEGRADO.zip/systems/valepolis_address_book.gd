extends RefCounted
class_name ValepolisAddressBook
## Livro de endereços fictícios de Valepólis. Dados carregados sob pedido.

const ADDRESS_DATA_PATH := "res://data/enderecamento_valepolis.json"
const COMMUNICATIONS_PATH := "res://data/comunicacoes_valepolis.json"

static func load_json(path: String) -> Dictionary:
    if not FileAccess.file_exists(path):
        push_warning("Ficheiro de dados não encontrado: " + path)
        return {}
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        return {}
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    return parsed if parsed is Dictionary else {}

static func find_street(street_id: String) -> Dictionary:
    var data := load_json(ADDRESS_DATA_PATH)
    for street in data.get("streets", []):
        if str(street.get("id", "")) == street_id:
            return street
    return {}

static func get_addresses_for_neighborhood(neighborhood: String) -> Array:
    var data := load_json(ADDRESS_DATA_PATH)
    var result: Array = []
    for address in data.get("addresses", []):
        if str(address.get("bairro", "")) == neighborhood:
            result.append(address)
    return result

static func format_phone(raw_digits: String) -> String:
    var digits := raw_digits.replace(" ", "").replace("-", "")
    return digits.replace("0", "O")

static func format_email(local_part: String, three_letter_code: String) -> String:
    var code := three_letter_code.to_lower()
    if code.length() != 3:
        return ""
    return local_part.to_lower().replace(" ", ".") + "@" + code

extends Node3D
class_name TrafficManager

## Traffic manager for Valepólis (Godot 4.5).
## The road network must be supplied by the city/map system:
## - call clear_road_network()
## - call add_road_node(id, world_position)
## - call connect_road_nodes(from_id, to_id, bidirectional)
## Or assign road_network_root and use nodes in group "traffic_nodes";
## optional road-node metadata: traffic_id (int), connected_to (Array[int]).
##
## This script intentionally does not generate fake roads or test vehicles.

signal vehicle_spawned(vehicle_id: int)
signal vehicle_removed(vehicle_id: int)
signal traffic_network_ready(node_count: int, edge_count: int)
signal traffic_network_error(message: String)

@export_group("Scene")
@export var vehicle_mesh: Mesh
@export var road_network_root: Node
@export var multimesh_instance_path: NodePath = ^"MultiMeshInstance3D"
@export var auto_build_network_from_group: bool = true
@export var road_node_group: StringName = &"traffic_nodes"

@export_group("Traffic capacity")
@export_range(0, 2000, 1) var max_vehicles: int = 500
@export_range(1, 64, 1) var max_route_calculations_per_frame: int = 4
@export_range(0.1, 10.0, 0.1) var congestion_update_interval: float = 2.0
@export_range(1.0, 50.0, 0.5) var congestion_radius: float = 12.0
@export_range(0.0, 5.0, 0.1) var congestion_weight: float = 0.7

@export_group("Driving")
@export_range(0.5, 5.0, 0.1) var waypoint_reach_distance: float = 1.5
@export_range(0.5, 8.0, 0.1) var default_minimum_gap: float = 3.0
@export_range(0.0, 20.0, 0.5) var braking_distance: float = 7.0
@export_range(0.0, 2.0, 0.05) var vehicle_y_offset: float = 0.2
@export var use_vehicle_spacing: bool = true

@export_group("Traffic lights")
@export var traffic_lights_root: Node
@export_range(0.5, 120.0, 0.5) var default_green_duration: float = 12.0
@export_range(0.5, 120.0, 0.5) var default_red_duration: float = 10.0
@export_range(0.1, 10.0, 0.1) var default_yellow_duration: float = 2.0

enum LightState { RED, GREEN, YELLOW }

var vehicles: Array[Dictionary] = []
var astar: AStar3D = AStar3D.new()
var intersections: Array[Dictionary] = []
var congestion_timer: float = 0.0

var _multimesh_instance: MultiMeshInstance3D
var _route_queue: Array[Dictionary] = []
var _next_vehicle_id: int = 1
var _network_ready: bool = false
var _network_edges: int = 0
var _rng := RandomNumberGenerator.new()
var _external_route_provider: Callable = Callable()


func _ready() -> void:
	_rng.randomize()
	_multimesh_instance = get_node_or_null(multimesh_instance_path) as MultiMeshInstance3D
	if _multimesh_instance == null:
		traffic_network_error.emit("MultiMeshInstance3D não encontrado no caminho configurado.")
		set_process(false)
		return

	if vehicle_mesh == null:
		if _multimesh_instance.multimesh != null:
			vehicle_mesh = _multimesh_instance.multimesh.mesh
		if vehicle_mesh == null:
			traffic_network_error.emit("vehicle_mesh não está configurada; os veículos não podem ser desenhados.")
			set_process(false)
			return

	_setup_multimesh()
	_setup_traffic_lights()

	if auto_build_network_from_group and road_network_root != null:
		build_network_from_scene(road_network_root)

	if astar.get_point_ids().size() >= 2:
		_network_ready = true
		traffic_network_ready.emit(astar.get_point_ids().size(), _network_edges)
	elif not _external_route_provider.is_valid():
		traffic_network_error.emit("Rede viária ainda não configurada. Regista os nós e liga as estradas através da API pública.")


func _setup_multimesh() -> void:
	var mm := _multimesh_instance.multimesh
	if mm == null:
		mm = MultiMesh.new()
		_multimesh_instance.multimesh = mm
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = vehicle_mesh
	mm.instance_count = max_vehicles
	mm.visible_instance_count = 0
	mm.custom_aabb = AABB(Vector3(-10000, -1000, -10000), Vector3(20000, 3000, 20000))


func _setup_traffic_lights() -> void:
	intersections.clear()
	if traffic_lights_root == null:
		return
	for node in traffic_lights_root.find_children("*", "Node3D", true, false):
		if not node.is_in_group("traffic_intersections"):
			continue
		var green := float(node.get_meta("green_duration", default_green_duration))
		var red := float(node.get_meta("red_duration", default_red_duration))
		var yellow := float(node.get_meta("yellow_duration", default_yellow_duration))
		intersections.append({
			"node": node,
			"position": node.global_position,
			"radius": float(node.get_meta("traffic_radius", 8.0)),
			"state": LightState.GREEN,
			"timer": _rng.randf_range(0.0, maxf(green, 0.1)),
			"green_duration": maxf(green, 0.5),
			"red_duration": maxf(red, 0.5),
			"yellow_duration": maxf(yellow, 0.1),
			"approach_node_ids": node.get_meta("approach_node_ids", PackedInt64Array())
		})


## Build a network from scene nodes in road_node_group.
## Each node needs metadata "traffic_id" (int) and "connected_to" (Array[int]).
func build_network_from_scene(root: Node) -> bool:
	clear_road_network()
	if root == null:
		traffic_network_error.emit("A raiz da rede viária não está definida.")
		return false

	var road_nodes: Array[Node] = []
	if root.is_in_group(road_node_group):
		road_nodes.append(root)
	road_nodes.append_array(root.find_children("*", "Node3D", true, false))
	var id_to_node: Dictionary = {}

	for node in road_nodes:
		if not node.is_in_group(road_node_group):
			continue
		if not node.has_meta("traffic_id"):
			continue
		var point_id := int(node.get_meta("traffic_id"))
		if id_to_node.has(point_id):
			traffic_network_error.emit("ID de nó viário duplicado: %d" % point_id)
			clear_road_network()
			return false
		id_to_node[point_id] = node
		add_road_node(point_id, (node as Node3D).global_position)

	for point_id in id_to_node:
		var node: Node = id_to_node[point_id]
		var links = node.get_meta("connected_to", [])
		for linked_id_value in links:
			var linked_id := int(linked_id_value)
			if id_to_node.has(linked_id) and not astar.are_points_connected(int(point_id), linked_id):
				connect_road_nodes(int(point_id), linked_id, true)

	_network_ready = astar.get_point_ids().size() >= 2 and _network_edges > 0
	if _network_ready:
		traffic_network_ready.emit(astar.get_point_ids().size(), _network_edges)
	else:
		traffic_network_error.emit("A rede encontrada não tem nós e ligações suficientes.")
	return _network_ready


func clear_road_network() -> void:
	astar.clear()
	_network_edges = 0
	_network_ready = false
	_route_queue.clear()


func add_road_node(point_id: int, world_position: Vector3) -> bool:
	if astar.has_point(point_id):
		traffic_network_error.emit("Não foi possível registar o nó duplicado %d." % point_id)
		return false
	astar.add_point(point_id, world_position)
	return true


func connect_road_nodes(from_id: int, to_id: int, bidirectional: bool = true) -> bool:
	if not astar.has_point(from_id) or not astar.has_point(to_id) or from_id == to_id:
		return false
	if not astar.are_points_connected(from_id, to_id):
		astar.connect_points(from_id, to_id, bidirectional)
		_network_edges += 1
	_network_ready = astar.get_point_ids().size() >= 2 and _network_edges > 0
	return true


func update_road_node_position(point_id: int, world_position: Vector3) -> bool:
	if not astar.has_point(point_id):
		return false
	astar.set_point_position(point_id, world_position)
	return true


## Creates a vehicle only when a valid route exists. Returns its ID, or -1 on failure.
func spawn_dynamic_vehicle(start_id: int, end_id: int, speed: float = 8.0, vehicle_data: Dictionary = {}) -> int:
	if not _network_ready or vehicles.size() >= max_vehicles:
		return -1
	if not astar.has_point(start_id) or not astar.has_point(end_id) or start_id == end_id:
		return -1
	var path := astar.get_point_path(start_id, end_id)
	if path.size() < 2:
		return -1

	var vehicle_id := _next_vehicle_id
	_next_vehicle_id += 1
	var start_position: Vector3 = path[0]
	start_position.y += vehicle_y_offset
	var record: Dictionary = {
		"id": vehicle_id,
		"external_route": false,
		"remove_on_route_complete": false,
		"position": start_position,
		"route": path,
		"waypoint_index": 1,
		"speed": maxf(speed, 0.0),
		"desired_speed": maxf(speed, 0.0),
		"start_point_id": start_id,
		"end_point_id": end_id,
		"route_check_timer": _rng.randf_range(0.0, 3.0),
		"is_waiting": false,
		"is_calculating_route": false,
		"braking": false,
		"minimum_gap": maxf(float(vehicle_data.get("minimum_gap", default_minimum_gap)), 0.5),
		"length": maxf(float(vehicle_data.get("length", 4.5)), 1.0),
		"mesh_transform": Transform3D(Basis.IDENTITY, start_position)
	}
	vehicles.append(record)
	vehicle_spawned.emit(vehicle_id)
	return vehicle_id


## Accepts waypoints produced by ValepolisCity3D's existing road geometry.
## This is the integration path for real city roads; it does not invent a new route.
func spawn_vehicle_on_waypoints(waypoints: Array, speed: float = 8.0, vehicle_data: Dictionary = {}) -> int:
	if _multimesh_instance == null or _multimesh_instance.multimesh == null or vehicles.size() >= max_vehicles:
		return -1
	var path := PackedVector3Array()
	for value in waypoints:
		if value is Vector3 and (path.is_empty() or path[path.size() - 1].distance_to(value) > 0.25):
			path.append(value)
	if path.size() < 2:
		return -1
	var vehicle_id := _next_vehicle_id
	_next_vehicle_id += 1
	var start_position := path[0] + Vector3.UP * vehicle_y_offset
	vehicles.append({
		"id": vehicle_id,
		"external_route": true,
		"remove_on_route_complete": true,
		"position": start_position,
		"route": path,
		"waypoint_index": 1,
		"speed": maxf(speed, 0.0),
		"desired_speed": maxf(speed, 0.0),
		"start_point_id": -1,
		"end_point_id": -1,
		"route_check_timer": 999999.0,
		"is_waiting": false,
		"is_calculating_route": false,
		"braking": false,
		"minimum_gap": maxf(float(vehicle_data.get("minimum_gap", default_minimum_gap)), 0.5),
		"length": maxf(float(vehicle_data.get("length", 4.5)), 1.0),
		"mesh_transform": _make_vehicle_transform(start_position, (path[1] - path[0]).normalized())
	})
	vehicle_spawned.emit(vehicle_id)
	return vehicle_id

func set_external_route_provider(provider: Callable) -> void:
	_external_route_provider = provider

func remove_vehicle(vehicle_id: int) -> bool:
	for i in range(vehicles.size() - 1, -1, -1):
		if int(vehicles[i]["id"]) == vehicle_id:
			vehicles.remove_at(i)
			vehicle_removed.emit(vehicle_id)
			return true
	return false


func request_route_async(vehicle_ref: Dictionary, start_id: int, end_id: int) -> void:
	# Queue work for the main thread. AStar3D and shared vehicle dictionaries are not
	# accessed from worker threads, avoiding unsafe cross-thread access.
	if vehicle_ref.get("is_calculating_route", false):
		return
	if not astar.has_point(start_id) or not astar.has_point(end_id):
		return
	vehicle_ref["is_calculating_route"] = true
	_route_queue.append({
		"vehicle_id": int(vehicle_ref["id"]),
		"vehicle_ref": vehicle_ref,
		"start_id": start_id,
		"end_id": end_id
	})


func _process(delta: float) -> void:
	if _multimesh_instance == null or _multimesh_instance.multimesh == null:
		return
	_update_traffic_lights(delta)
	_update_dynamic_weights(delta)
	_process_route_queue()
	_update_vehicles(delta)
	_sync_multimesh()


func _process_route_queue() -> void:
	var jobs := mini(max_route_calculations_per_frame, _route_queue.size())
	for i in range(jobs):
		var job: Dictionary = _route_queue.pop_front()
		var vehicle_ref: Dictionary = job["vehicle_ref"]
		var path: PackedVector3Array = astar.get_point_path(int(job["start_id"]), int(job["end_id"]))
		if not path.is_empty() and vehicles.has(vehicle_ref):
			vehicle_ref["route"] = path
			vehicle_ref["waypoint_index"] = 1 if path.size() > 1 else 0
			vehicle_ref["end_point_id"] = int(job["end_id"])
		vehicle_ref["is_calculating_route"] = false


func _update_vehicles(delta: float) -> void:
	for i in range(vehicles.size()):
		var v: Dictionary = vehicles[i]
		v["route_check_timer"] = float(v["route_check_timer"]) + delta
		if not bool(v.get("external_route", false)) and float(v["route_check_timer"]) >= 8.0:
			v["route_check_timer"] = 0.0
			var current_node := _get_nearest_astar_node(v["position"])
			var destination := int(v["end_point_id"])
			if current_node >= 0 and current_node != destination and not v["is_calculating_route"]:
				# Recalculate only if a route is missing or the vehicle is substantially off-route.
				if _distance_to_route(v["position"], v["route"]) > congestion_radius:
					request_route_async(v, current_node, destination)

		v["is_waiting"] = _is_blocked_by_red_light(v["position"])
		var route: PackedVector3Array = v["route"]
		var waypoint_index := int(v["waypoint_index"])
		if waypoint_index >= route.size():
			v["speed"] = 0.0
			if bool(v.get("remove_on_route_complete", false)):
				call_deferred("remove_vehicle", int(v["id"]))
			continue
		if v["is_waiting"] or route.size() < 2:
			v["speed"] = move_toward(float(v["speed"]), 0.0, 10.0 * delta)
			continue

		var target: Vector3 = route[waypoint_index]
		var flat_target := Vector3(target.x, float(v["position"].y) - vehicle_y_offset, target.z)
		var direction := flat_target - Vector3(v["position"].x, float(v["position"].y) - vehicle_y_offset, v["position"].z)
		var distance := direction.length()
		if distance <= waypoint_reach_distance:
			waypoint_index += 1
			v["waypoint_index"] = waypoint_index
			if waypoint_index >= route.size():
				if bool(v.get("remove_on_route_complete", false)):
					v["speed"] = 0.0
					call_deferred("remove_vehicle", int(v["id"]))
				else:
					_finish_vehicle_route(v)
				continue
			target = route[waypoint_index]
			flat_target = Vector3(target.x, float(v["position"].y) - vehicle_y_offset, target.z)
			direction = flat_target - Vector3(v["position"].x, float(v["position"].y) - vehicle_y_offset, v["position"].z)
			distance = direction.length()

		if distance <= 0.001:
			continue
		var dir := direction.normalized()
		var target_speed := float(v["desired_speed"])
		if use_vehicle_spacing and _has_vehicle_ahead(v, dir, float(v["minimum_gap"])):
			target_speed = 0.0
			v["braking"] = true
		else:
			v["braking"] = false

		# Slow down before a red/yellow light rather than stopping abruptly at its centre.
		if _distance_to_red_light(v["position"]) < braking_distance:
			target_speed = minf(target_speed, float(v["desired_speed"]) * 0.35)
		v["speed"] = move_toward(float(v["speed"]), target_speed, 5.0 * delta)
		var step := minf(float(v["speed"]) * delta, distance)
		v["position"] = v["position"] + dir * step
		v["position"].y += 0.0
		v["mesh_transform"] = _make_vehicle_transform(v["position"], dir)


func _finish_vehicle_route(v: Dictionary) -> void:
	var old_start := int(v["start_point_id"])
	var old_end := int(v["end_point_id"])
	var new_start := old_end
	var new_end := old_start
	if not astar.has_point(new_start) or not astar.has_point(new_end):
		v["speed"] = 0.0
		return
	var new_path := astar.get_point_path(new_start, new_end)
	if new_path.size() < 2:
		v["speed"] = 0.0
		return
	v["start_point_id"] = new_start
	v["end_point_id"] = new_end
	v["route"] = new_path
	v["waypoint_index"] = 1
	v["position"] = new_path[0] + Vector3.UP * vehicle_y_offset
	v["mesh_transform"] = _make_vehicle_transform(v["position"], (new_path[1] - new_path[0]).normalized())


func _make_vehicle_transform(position: Vector3, direction: Vector3) -> Transform3D:
	var p := position + Vector3.UP * vehicle_y_offset
	if direction.length_squared() <= 0.0001:
		return Transform3D(Basis.IDENTITY, p)
	var forward := Vector3(direction.x, 0.0, direction.z).normalized()
	if forward.length_squared() <= 0.0001:
		return Transform3D(Basis.IDENTITY, p)
	# Godot's -Z is the forward axis for look_at.
	var basis := Basis.looking_at(forward, Vector3.UP)
	return Transform3D(basis, p)


func _sync_multimesh() -> void:
	var mm := _multimesh_instance.multimesh
	var count := mini(vehicles.size(), max_vehicles)
	mm.visible_instance_count = count
	for i in range(count):
		var v: Dictionary = vehicles[i]
		mm.set_instance_transform(i, v.get("mesh_transform", Transform3D(Basis.IDENTITY, v["position"])))


func _get_nearest_astar_node(pos: Vector3) -> int:
	var point_ids := astar.get_point_ids()
	if point_ids.is_empty():
		return -1
	var nearest_id := int(point_ids[0])
	var min_dist := pos.distance_squared_to(astar.get_point_position(nearest_id))
	for i in range(1, point_ids.size()):
		var point_id := int(point_ids[i])
		var dist := pos.distance_squared_to(astar.get_point_position(point_id))
		if dist < min_dist:
			min_dist = dist
			nearest_id = point_id
	return nearest_id


func _distance_to_route(position: Vector3, route: PackedVector3Array) -> float:
	if route.is_empty():
		return INF
	var min_distance := INF
	for point in route:
		min_distance = minf(min_distance, position.distance_to(point))
	return min_distance


func _has_vehicle_ahead(vehicle: Dictionary, direction: Vector3, minimum_gap: float) -> bool:
	var pos: Vector3 = vehicle["position"]
	for other in vehicles:
		if int(other["id"]) == int(vehicle["id"]):
			continue
		var offset: Vector3 = other["position"] - pos
		var forward_distance := offset.dot(direction)
		if forward_distance <= 0.0 or forward_distance > maxf(braking_distance, minimum_gap + float(vehicle["length"])):
			continue
		var lateral := (offset - direction * forward_distance).length()
		if lateral < 2.2 and forward_distance < minimum_gap + float(vehicle["length"]):
			return true
	return false


func _is_blocked_by_red_light(position: Vector3) -> bool:
	for light in intersections:
		if int(light["state"]) == LightState.GREEN:
			continue
		if position.distance_to(light["position"]) <= float(light["radius"]):
			return true
	return false


func _distance_to_red_light(position: Vector3) -> float:
	var nearest := INF
	for light in intersections:
		if int(light["state"]) == LightState.GREEN:
			continue
		nearest = minf(nearest, position.distance_to(light["position"]))
	return nearest


func _update_traffic_lights(delta: float) -> void:
	for light in intersections:
		var node: Node3D = light.get("node")
		if not is_instance_valid(node):
			continue
		light["position"] = node.global_position
		light["timer"] = float(light["timer"]) + delta
		var duration := float(light["green_duration"])
		if int(light["state"]) == LightState.RED:
			duration = float(light["red_duration"])
		elif int(light["state"]) == LightState.YELLOW:
			duration = float(light["yellow_duration"])
		if float(light["timer"]) < duration:
			continue
		light["timer"] = 0.0
		match int(light["state"]):
			LightState.GREEN:
				light["state"] = LightState.YELLOW
			LightState.YELLOW:
				light["state"] = LightState.RED
			LightState.RED:
				light["state"] = LightState.GREEN


func _update_dynamic_weights(delta: float) -> void:
	congestion_timer += delta
	if congestion_timer < congestion_update_interval:
		return
	congestion_timer = 0.0
	for point_id in astar.get_point_ids():
		var position := astar.get_point_position(point_id)
		var nearby := 0
		for vehicle in vehicles:
			if Vector2(vehicle["position"].x, vehicle["position"].z).distance_to(Vector2(position.x, position.z)) <= congestion_radius:
				nearby += 1
		astar.set_point_weight_scale(point_id, 1.0 + float(nearby) * congestion_weight)


## Returns a valid random road-node ID, or -1 when the network is unavailable.
func get_random_road_node_id() -> int:
	var ids := astar.get_point_ids()
	if ids.is_empty():
		return -1
	return int(ids[_rng.randi_range(0, ids.size() - 1)])


## Convenience method for the city simulation to spawn traffic without fixed test data.
func spawn_vehicle_for_city(speed_min: float = 5.0, speed_max: float = 13.0, vehicle_data: Dictionary = {}) -> int:
	var ids := astar.get_point_ids()
	if ids.size() < 2 or vehicles.size() >= max_vehicles:
		return -1
	for attempt in range(12):
		var start_id := int(ids[_rng.randi_range(0, ids.size() - 1)])
		var end_id := int(ids[_rng.randi_range(0, ids.size() - 1)])
		if start_id == end_id:
			continue
		var result := spawn_dynamic_vehicle(start_id, end_id, _rng.randf_range(speed_min, speed_max), vehicle_data)
		if result >= 0:
			return result
	return -1


func get_traffic_stats() -> Dictionary:
	var waiting := 0
	var braking := 0
	for vehicle in vehicles:
		if vehicle["is_waiting"]:
			waiting += 1
		if vehicle["braking"]:
			braking += 1
	return {
		"vehicle_count": vehicles.size(),
		"vehicle_capacity": max_vehicles,
		"waiting_at_lights": waiting,
		"braking_or_blocked": braking,
		"road_node_count": astar.get_point_ids().size(),
		"road_edge_count": _network_edges,
		"network_ready": _network_ready
	}

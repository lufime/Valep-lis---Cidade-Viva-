extends RefCounted
class_name ValepolisSystemsSelfTest

static func run(runtime: ValepolisSystemsRuntime) -> Dictionary:
    var results := {}
    runtime.initialize()
    results["initialize"] = runtime.initialized
    results["entity_capability_catalog_loaded"] = not runtime.entity_response_capabilities.is_empty()
    results["entity_catalog_covers_all_registry_entities"] = runtime.entity_response_capabilities.get("entities", []).size() >= 9
    var entity_catalog_audit := runtime.validate_entity_master_catalog()
    results["entity_master_catalog_valid"] = entity_catalog_audit.get("ok", false)
    results["entity_directory_includes_tnur_unit"] = runtime.get_entity_directory(true).size() == 9
    results["entity_directory_can_exclude_integrated_units"] = runtime.get_entity_directory(false).size() == 8
    var tnur_profile_result := runtime.get_entity_profile("TNUR")
    var tnur_profile: Dictionary = tnur_profile_result.get("profile", {})
    results["tnur_profile_has_brigada_parent"] = tnur_profile_result.get("ok", false) and str(tnur_profile.get("parent_entity_id", "")) == "BRIGADA" and str(tnur_profile.get("organizational_status", "")) == "integrated_unit"
    results["deferred_resource_fields_are_unset"] = tnur_profile.get("staffing", "missing") == null and tnur_profile.get("economy", "missing") == null and tnur_profile.get("installation_count", "missing") == null and tnur_profile.get("vehicles", "missing") == null and tnur_profile.get("inventory", "missing") == null and tnur_profile.get("budget", "missing") == null and tnur_profile.get("balance", "missing") == null
    results["unknown_entity_profile_rejected"] = not runtime.get_entity_profile("UNKNOWN_ENTITY").get("ok", true)

    runtime.set_paused(true)
    var before := runtime.sim_minute
    runtime.tick(10)
    results["pause_freezes_clock"] = runtime.sim_minute == before
    runtime.set_paused(false)
    runtime.tick(10)
    results["clock_advances"] = runtime.sim_minute == before + 10

    var inc := runtime.create_incident("INC-MED", "Nexora")
    results["incident_created"] = inc.has("id") and inc["state"] == "detected"
    results["incident_transition"] = runtime.advance_incident(inc["id"], "dispatch")


    # TNUR is a hosted unit: standalone registration must fail, and each
    # registered centre must point to a real BRIGADA base.
    var standalone_tnur := runtime.register_entity_resources("TNUR", "Nexora", [], [], "TNUR-INDEPENDENT")
    results["tnur_standalone_base_rejected"] = not standalone_tnur.get("ok", false) and not standalone_tnur.get("standalone_base_allowed", true)
    var brigada_base_a := runtime.register_entity_resources("BRIGADA", "Nexora", [], [], "BRG-BASE-NEXORA")
    var brigada_base_b := runtime.register_entity_resources("BRIGADA", "Altavira", [], [], "BRG-BASE-ALTAVIRA")
    results["brigada_bases_register"] = brigada_base_a.get("ok", false) and brigada_base_b.get("ok", false)
    var tnur_centre_a := runtime.register_entity_resources("TNUR", "Nexora", [], [], "TNUR-CENTRE-001", "BRG-BASE-NEXORA")
    var tnur_centre_b := runtime.register_entity_resources("TNUR", "Altavira", [], [], "TNUR-CENTRE-002", "BRG-BASE-ALTAVIRA")
    results["tnur_centres_hosted_in_brigada_bases"] = tnur_centre_a.get("ok", false) and tnur_centre_b.get("ok", false)
    results["tnur_not_independent_after_registration"] = not runtime.entity_resources.get("TNUR", {}).get("is_independent_base", true) and runtime.entity_resources.get("TNUR", {}).get("tnur_centres", {}).size() == 2
    results["brigada_bases_reference_tnur_centres"] = runtime.entity_resources.get("BRIGADA", {}).get("bases", {}).get("BRG-BASE-NEXORA", {}).get("tnur_centres", []).has("TNUR-CENTRE-001") and runtime.entity_resources.get("BRIGADA", {}).get("bases", {}).get("BRG-BASE-ALTAVIRA", {}).get("tnur_centres", []).has("TNUR-CENTRE-002")

    # Resource dispatch is tested only when the caller has registered a city.
    if is_instance_valid(runtime.city_node):
        var resource_registration := runtime.register_entity_resources(
            "SUE",
            "Nexora",
            [{"id": "TEST-SUE-TEAM", "skills": ["medical_response"], "state": "available"}],
            [{"id": "TEST-SUE-AMB", "incident_types": ["medical_response"], "state": "available"}]
        )
        results["resource_registration"] = resource_registration.get("ok", false)
        var medical_incident := runtime.create_incident("INC-MED", "Nexora")
        var dispatched := runtime.dispatch_entity("SUE", str(medical_incident["id"]), "Nexora")
        results["dispatch_assigns_team_vehicle"] = dispatched.get("ok", false) and dispatched.get("dispatch", {}).has("team_id") and dispatched.get("dispatch", {}).has("vehicle_id")
        if dispatched.get("ok", false):
            runtime.tick(int(dispatched["dispatch"].get("estimated_travel_minutes", 1)))
            results["dispatch_arrives_after_travel"] = str(runtime.dispatches.back().get("state", "")) == "on_scene"
            var completed := runtime.complete_dispatch(str(dispatched["dispatch"]["id"]), true)
            results["dispatch_releases_resources"] = completed.get("ok", false) and runtime.team_registry["TEST-SUE-TEAM"].get("state") == "available" and runtime.vehicle_registry["TEST-SUE-AMB"].get("state") == "available"

    var tx := runtime.add_transaction("salary", -125000, "PERSON-001")
    results["unconfigured_economy_rejects_transaction"] = not tx.get("ok", false) and runtime.economy.get("balance", null) == null and runtime.economy.get("transactions", []).is_empty()

    runtime.set_weather("rain", 0.5)
    results["weather_state"] = runtime.weather["state"] == "rain"

    runtime.set_asset_state("AMB-001", "under_repair")
    runtime.tick(1)
    var maintenance_held := runtime.maintenance["AMB-001"] == "under_repair"
    var maintenance_advanced := runtime.advance_maintenance("AMB-001", "restored")
    results["maintenance_requires_explicit_transition"] = maintenance_held and maintenance_advanced.get("ok", false) and runtime.maintenance["AMB-001"] == "restored"

    runtime.set_construction("SITE-001", "construction")
    runtime.tick(1)
    var construction_held := runtime.construction["SITE-001"] == "construction"
    var construction_advanced := runtime.advance_construction("SITE-001", "inspection")
    results["construction_requires_explicit_transition"] = construction_held and construction_advanced.get("ok", false) and runtime.construction["SITE-001"] == "inspection"

    runtime.set_traffic_state("NEXORA-CENTER", "congested")
    results["traffic_state"] = runtime.traffic["NEXORA-CENTER"] == "congested"

    runtime.set_family("FAM-001", ["PERSON-001", "PERSON-002"])
    runtime.set_person_state("PERSON-001", {"activity":"work", "neighborhood":"Nexora"})
    results["family_state"] = runtime.families.has("FAM-001")
    results["person_state"] = runtime.memories["PERSON-001"]["current"]["activity"] == "work"

    var p := runtime.advance_episode()
    results["progression"] = p["episode"] == 2
    runtime.progression = {"episode": 10, "season": 20}
    var final_progression := runtime.advance_episode()
    results["progression_caps_at_200"] = int(final_progression.get("season", 0)) == 20 and int(final_progression.get("episode", 0)) == 10 and bool(final_progression.get("completed", false))

    var failed := []
    for key in results:
        if not results[key]:
            failed.append(key)
    return {"passed": failed.is_empty(), "failed": failed, "results": results}

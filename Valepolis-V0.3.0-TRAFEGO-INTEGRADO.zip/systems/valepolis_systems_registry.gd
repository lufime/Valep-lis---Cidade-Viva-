extends Node
class_name ValepolisSystemsRegistry

const VERSION := "0.3.0"
const POPULATION_REFERENCE := 1_000_000
const ACTIVE_DETAIL_TARGET := 200

var systems_status := {
    "population": "200_individual_agents_plus_aggregated_reference_population",
    "families_relationships": "partial_runtime_pending_family_distribution",
    "ageing": "pending_demographic_rules",
    "health": "abstract_agent_state_simulation",
    "careers_work": "professions_catalogued_employment_and_staffing_pending",
    "economy": "deferred_pending_owner_definition",
    "businesses": "catalogued_pending_capacity_prices_and_opening_rules",
    "construction": "explicit_state_transitions_pending_duration_and_resource_rules",
    "traffic_mobility": "abstract_simulation_pending_runtime_test",
    "weather_environment": "abstract_simulation_pending_runtime_test",
    "incidents_emergencies": "event_generation_pending_end_to_end_dispatch_test",
    "damage_maintenance": "explicit_state_transitions_pending_duration_and_resource_rules",
    "memory_consequences": "partial_runtime_pending_runtime_test",
    "missions_episodes": "200_episodes_in_20_seasons_catalogued",
    "privacy_knowledge": "pending_runtime_test",
    "save_load": "implemented_pending_runtime_test",
    "ui_navigation": "implemented_pending_runtime_test"
}

func status(system_id: String) -> String:
    return String(systems_status.get(system_id, "undefined"))

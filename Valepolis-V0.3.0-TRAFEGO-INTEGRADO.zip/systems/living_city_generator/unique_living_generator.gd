extends RefCounted
class_name ValepolisLivingUniqueGenerator

## V0.3.0 — Vida Viva
## Regra obrigatória: não gerar clones. Cada personagem recebe uma assinatura visual
## e comportamental única. Nomes são fictícios e retratos não representam pessoas reais.

const VERSION := "0.3.0"
const PORTRAIT_DIR := "user://portraits/"
static var used_visual_signatures: Dictionary = {}
static var used_names: Dictionary = {}

const SKIN := ["tone_a","tone_b","tone_c","tone_d","tone_e","tone_f","tone_g"]
const HAIR := ["black_short","brown_short","brown_long","blond_short","auburn","curly_dark","gray","wavy_dark","red_short"]
const EYES := ["brown","dark","hazel","green","blue","gray"]
const OUTFITS := ["casual_a","casual_b","work_a","work_b","sue","brigada","police","tnur","student","retail","technical","rural"]
const ACCESSORIES := ["none","glasses","cap","watch","backpack","earrings","helmet","badge"]
const BODY := ["slim","average","athletic","compact","tall","broad"]
const HEIGHT := [1.54,1.58,1.62,1.66,1.70,1.74,1.78,1.82,1.86,1.90]

static func generate_unique(seed_value:int, neighborhood:String, profession:String="") -> Dictionary:
    var rng := RandomNumberGenerator.new()
    var attempt := 0
    while attempt < 1000:
        rng.seed = seed_value + attempt * 7919
        var dna := _make_dna(rng, profession)
        var signature := _signature(dna)
        if not used_visual_signatures.has(signature):
            var name := _unique_name(rng)
            used_visual_signatures[signature] = true
            used_names[name] = true
            return {
                "id":"LIFE-%08d" % abs(seed_value),
                "name":name,
                "neighborhood":neighborhood,
                "profession":profession,
                "visual_dna":dna,
                "visual_signature":signature,
                "clone":false,
                "unique":true,
                "portrait_seed":rng.randi(),
                "animation_set":_animation_set(rng, profession)
            }
        attempt += 1
    push_error("Não foi possível encontrar DNA visual único.")
    return {}

static func _make_dna(rng:RandomNumberGenerator, profession:String) -> Dictionary:
    var outfit := _pick(rng, OUTFITS)
    if profession.to_lower().find("polícia") >= 0: outfit = "police"
    elif profession.to_lower().find("brigada") >= 0: outfit = "brigada"
    elif profession.to_lower().find("sue") >= 0 or profession.to_lower().find("méd") >= 0: outfit = "sue"
    elif profession.to_lower().find("tnur") >= 0: outfit = "tnur"
    return {
        "skin":_pick(rng,SKIN),
        "hair":_pick(rng,HAIR),
        "eyes":_pick(rng,EYES),
        "outfit":outfit,
        "accessory":_pick(rng,ACCESSORIES),
        "body":_pick(rng,BODY),
        "height":_pick(rng,HEIGHT),
        "hair_variant":rng.randi_range(0,5),
        "face_variant":rng.randi_range(0,15),
        "age_band":rng.randi_range(0,7)
    }

static func _signature(dna:Dictionary) -> String:
    return JSON.stringify(dna, "", false)

static func _unique_name(rng:RandomNumberGenerator) -> String:
    var a := ["Arel","Néria","Cael","Ivara","Zélio","Dúnia","Míria","Varel","Sélia","Orven","Tavén","Lúria","Nelor","Avena","Rúlio","Evara"]
    var b := ["Vanoa","Solven","Orven","Nelor","Tavén","Marven","Sarel","Dúnia","Virel","Auren","Valen","Seron","Mavora","Elven","Néria","Taren"]
    for i in range(500):
        var name := "%s %s" % [_pick(rng,a),_pick(rng,b)]
        if not used_names.has(name): return name
    return "Valepolis-%08d" % rng.randi()

static func _pick(rng:RandomNumberGenerator, values:Array):
    return values[rng.randi_range(0,values.size()-1)]

static func _animation_set(rng:RandomNumberGenerator, profession:String) -> Array:
    var common := ["idle","walk","turn","talk","phone","sit","stand","enter_exit"]
    var special := ["work","drive","wait"]
    if profession != "":
        special.append("work")
    if rng.randf() > 0.45: special.append("leisure")
    return common + special

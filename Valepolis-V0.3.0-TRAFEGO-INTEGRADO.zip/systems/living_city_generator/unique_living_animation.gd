extends RefCounted
class_name ValepolisLivingUniqueAnimation

## Animações visuais com pequenas variações por personagem.
## A animação base pode ser partilhada; o movimento, escala, ritmo e timing NÃO são clonados.

static func build_profile(seed_value:int) -> Dictionary:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    return {
        "speed_scale": rng.randf_range(0.88,1.14),
        "stride_scale": rng.randf_range(0.92,1.08),
        "idle_offset": rng.randf_range(0.0,1.0),
        "turn_delay": rng.randf_range(0.1,0.8),
        "gesture_set": rng.randi_range(0,7),
        "walk_variant": rng.randi_range(0,5),
        "talk_variant": rng.randi_range(0,5),
        "unique_animation_profile": true
    }

static func states(activity:String) -> Array:
    var table := {
        "walk":["idle","start","walk","turn","stop"],
        "work":["idle","work","pause","work","finish"],
        "drive":["parked","start","drive","slow","stop"],
        "talk":["approach","gesture","talk","listen","leave"],
        "phone":["idle","take_phone","use_phone","put_phone"],
        "leisure":["idle","move","interact","rest"],
        "enter_exit":["approach","open","enter","exit","close"]
    }
    return table.get(activity,["idle","move","stop"])

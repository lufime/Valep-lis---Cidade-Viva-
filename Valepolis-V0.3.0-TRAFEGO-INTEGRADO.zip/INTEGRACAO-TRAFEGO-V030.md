# Integração do TrafficManager — Valepólis V0.3.0

## Alterações

- Adicionado `systems/traffic_manager.gd`, com movimento MultiMesh e criação controlada de veículos por waypoints.
- `systems/city_3d.gd` inicializa o gestor depois de gerar o mundo e disponibiliza `spawn_traffic_vehicle_between_neighborhoods(origin, destination, speed)`.
- Os percursos são obtidos através de `get_vehicle_waypoints_between_neighborhoods`, que utiliza o grafo rodoviário e os segmentos geométricos já existentes.
- Não são alteradas nem removidas as estradas, passeios, passadeiras, sinalização, iluminação, guardas ou veículos ambientais existentes.
- Não são criados veículos novos automaticamente na inicialização; a simulação/camada de serviços pode pedir a criação quando necessário.

## Utilização

A partir de uma referência a `ValepolisCity3D`, chamar:

`spawn_traffic_vehicle_between_neighborhoods("Marévia", "Pedravora", 7.0)`

O método devolve o ID do veículo ou `-1` se não existir um percurso aceite pela validação geométrica atual. Os nomes têm de corresponder aos bairros existentes no catálogo de `city_3d.gd`.

## Limitações conhecidas

- A validação dos segmentos rodoviários continua a ser heurística; não é uma verificação completa de colisões, água, instalações ou continuidade física.
- O novo gestor não substitui automaticamente os veículos ambientais já existentes. Serve como camada de trânsito controlada e ligada aos percursos do mapa.
- A malha MultiMesh inicial é uma representação simples de veículo. Pode ser substituída por uma malha aprovada sem alterar a API de rotas.
- O projeto não foi compilado nem executado no Godot nesta sessão; a integração foi verificada por inspeção estática e integridade do ZIP, não por teste de runtime.

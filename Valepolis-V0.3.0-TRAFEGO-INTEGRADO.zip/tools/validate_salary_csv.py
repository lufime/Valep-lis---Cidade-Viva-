#!/usr/bin/env python3
"""Validate the salary CSV import without modifying source data."""
from __future__ import annotations
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CSV_PATH = ROOT / "data" / "salary_by_profession_proposal_v030.csv"
JSON_PATH = ROOT / "data" / "salary_by_profession_proposal_v030.json"
EXPECTED_COUNT = 800
SALARY_FIELD = "Salario_bruto_mensal_proposto_EUR"

def fail(message: str) -> None:
    print(f"FAIL|Importação CSV salarial|{message}")
    raise SystemExit(1)

def main() -> int:
    if not CSV_PATH.is_file() or not JSON_PATH.is_file():
        fail("CSV ou catálogo JSON não encontrado")
    try:
        with CSV_PATH.open("r", encoding="utf-8-sig", newline="") as handle:
            sample = handle.read(8192)
            handle.seek(0)
            try:
                dialect = csv.Sniffer().sniff(sample, delimiters=";,\t|")
            except csv.Error:
                # O ficheiro oficial do projeto usa ponto e vírgula.
                dialect = csv.excel
                dialect.delimiter = ";"
            reader = csv.DictReader(handle, dialect=dialect)
            if not reader.fieldnames:
                fail("cabeçalho CSV ausente")
            headers = [h.strip() for h in reader.fieldnames]
            if len(headers) != len(set(headers)):
                fail("cabeçalhos duplicados")
            required = {"ID", "Profissão", SALARY_FIELD, "Horas_semanais_referencia"}
            if not required.issubset(headers):
                fail("cabeçalhos obrigatórios ausentes: " + ", ".join(sorted(required - set(headers))))
            rows = []
            for line_no, raw in enumerate(reader, start=2):
                row = {(k.strip() if k else k): (v.strip() if isinstance(v, str) else v)
                       for k, v in raw.items()}
                if None in row or any(v is None for v in row.values()):
                    fail(f"linha {line_no}: número de colunas inválido")
                rows.append((line_no, row))
    except (OSError, UnicodeError, csv.Error) as exc:
        fail(f"leitura CSV falhou: {exc}")

    if len(rows) != EXPECTED_COUNT:
        fail(f"esperados {EXPECTED_COUNT} registos; encontrados {len(rows)}")
    ids = [row.get("ID", "") for _, row in rows]
    if any(not value for value in ids) or len(ids) != len(set(ids)):
        fail("IDs vazios ou duplicados; dados mantidos para inspeção")

    try:
        catalog = json.loads(JSON_PATH.read_text(encoding="utf-8-sig"))
    except (OSError, json.JSONDecodeError) as exc:
        fail(f"catálogo JSON inválido: {exc}")
    professions = catalog.get("professions", [])
    if not isinstance(professions, list) or len(professions) != EXPECTED_COUNT:
        fail(f"JSON não contém exatamente {EXPECTED_COUNT} registos")
    by_id = {str(item.get("ID", "")): item for item in professions if isinstance(item, dict)}
    if len(by_id) != EXPECTED_COUNT:
        fail("IDs JSON vazios, duplicados ou registos inválidos")
    if set(ids) != set(by_id):
        fail("IDs CSV e JSON não coincidem; nenhum registo foi removido")

    for line_no, row in rows:
        item = by_id[row["ID"]]
        if row["Profissão"] != str(item.get("Profissão", "")):
            fail(f"linha {line_no}, {row['ID']}: profissão diverge do JSON")
        try:
            csv_salary = int(row[SALARY_FIELD])
            json_salary = item.get(SALARY_FIELD)
            if isinstance(json_salary, bool) or not isinstance(json_salary, (int, float)) or csv_salary != json_salary:
                fail(f"linha {line_no}, {row['ID']}: salário diverge do JSON")
            if csv_salary <= 0:
                fail(f"linha {line_no}, {row['ID']}: salário não positivo")
        except (TypeError, ValueError):
            fail(f"linha {line_no}, {row['ID']}: salário não numérico")
        for field in ("Ramo", "Subcategoria", "Estado_catalogo", "Escala_proposta",
                      "Escala_designacao", "Salario_status", "Regra_classificacao", "Nota_bairro"):
            if field in row and str(item.get(field, "")) != row[field]:
                fail(f"linha {line_no}, {row['ID']}: campo {field} diverge do JSON")
        hours = item.get("Horas_semanais_referencia")
        if str(hours) != row["Horas_semanais_referencia"]:
            fail(f"linha {line_no}, {row['ID']}: horas semanais divergem do JSON")
        adjustment = item.get("Ajuste_bairro_EUR")
        if ("" if adjustment is None else str(adjustment)) != row.get("Ajuste_bairro_EUR", ""):
            fail(f"linha {line_no}, {row['ID']}: ajuste de bairro diverge do JSON")

    print(f"PASS|Importação CSV salarial|registos={len(rows)}|IDs únicos=800|salários coincidem com JSON=800|dados não alterados")
    return 0

if __name__ == "__main__":
    sys.exit(main())

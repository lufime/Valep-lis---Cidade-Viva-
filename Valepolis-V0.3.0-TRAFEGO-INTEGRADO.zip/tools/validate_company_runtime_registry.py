#!/usr/bin/env python3
"""Static validation for Valepolis V0.3.0 company runtime registry."""
import json
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
companies = json.loads((ROOT/'data/catalogo_empresas_v030.json').read_text(encoding='utf-8'))['companies']
addresses = json.loads((ROOT/'data/enderecamento_valepolis.json').read_text(encoding='utf-8'))['addresses']
by_address = {a['id']: a for a in addresses}
assert len(by_address) == len(addresses), 'Duplicate address IDs'
ids = [c['company_id'] for c in companies]
assert len(ids) == 100 and len(set(ids)) == 100, 'Expected 100 unique company IDs'
candidates = [c.get('proposed_address_candidate_id') for c in companies]
assert all(candidates), 'Missing candidate address'
assert len(set(candidates)) == 100, 'Candidate addresses must be unique'
for company in companies:
    addr = by_address.get(company['proposed_address_candidate_id'])
    assert addr, f"Unknown candidate address for {company['company_id']}"
    assert addr['bairro'] == company['neighborhood_name'], f"Neighborhood mismatch: {company['company_id']}"
script = (ROOT/'systems/valepolis_company_registry.gd').read_text(encoding='utf-8')
project = (ROOT/'project.godot').read_text(encoding='utf-8')
for method in ['load_registry', 'get_all_companies', 'get_company', 'get_companies_for_neighborhood', 'get_candidate_address', 'get_map_spawnable_companies']:
    assert f'func {method}(' in script, f'Missing API: {method}'
assert 'ValepolisCompanies="*res://systems/valepolis_company_registry.gd"' in project, 'Autoload missing'
assert 'Never create' not in script # ensure comment localized as authored below
assert 'Nunca criar empresa no mapa' in script
print('STATIC_RESULT=PASS')
print('COMPANIES=100')
print('UNIQUE_COMPANY_IDS=100')
print('UNIQUE_CANDIDATE_ADDRESSES=100')
print('CANDIDATE_NEIGHBORHOODS_MATCH=100')
print('RUNTIME_REGISTRY_API=6')
print('GODOT_RUNTIME=NOT_RUN')

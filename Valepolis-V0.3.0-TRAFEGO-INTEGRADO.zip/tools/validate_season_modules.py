#!/usr/bin/env python3
"""Validate Valepólis V0.3.0 offline season modules against their manifest."""
import hashlib, json, sys
from pathlib import Path
root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "data/seasons_manifest.json").read_text(encoding="utf-8"))
errors=[]; total=0; seen=set()
for module in manifest.get("modules", []):
    path=root/module["file"]
    if not path.is_file(): errors.append(f"MISSING|{module['file']}"); continue
    raw=path.read_bytes(); digest=hashlib.sha256(raw).hexdigest()
    if digest != module.get("sha256"): errors.append(f"HASH_FAIL|{module['file']}")
    data=json.loads(raw.decode("utf-8")); eps=data.get("episodes", [])
    if len(eps) != 10 or len(eps) != int(module.get("episodes", -1)):
        errors.append(f"COUNT_FAIL|season={module.get('season')}|episodes={len(eps)}")
    for ep in eps:
        key=(int(ep.get("season",0)),int(ep.get("episode",0)))
        if key in seen: errors.append(f"DUPLICATE|{key}")
        seen.add(key); total += 1
        if key[0] != int(module.get("season",0)): errors.append(f"WRONG_SEASON|{key}")
if len(manifest.get("modules", [])) != 20: errors.append("SEASON_COUNT_FAIL")
if total != 200 or len(seen) != 200: errors.append(f"TOTAL_FAIL|episodes={total}|unique={len(seen)}")
if errors:
    print("\n".join("FAIL|"+e for e in errors)); print("RESULT=FAIL"); sys.exit(1)
print("PASS|20 módulos de temporada íntegros")
print("PASS|200 episódios únicos, 10 por temporada")
print("PASS|SHA-256 de todos os módulos confirmado")
print("INFO|Instalação dinâmica/download Android não está implementada por este manifesto")
print("RESULT=PASS_STATIC")

#!/usr/bin/env python3
"""Static consistency checks for the Valepolis V0.3.0 master registry."""
import json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
read=lambda p: json.loads((ROOT/p).read_text(encoding="utf-8"))
co=read("data/companies_catalog_v030.json"); ent=read("data/entity_master_catalog.json"); tax=read("data/catalogo_v3.json"); ins=read("data/installation_registry_v030.json"); pop=read("data/populacao_por_bairro_v030.json"); master=read("data/master_registry_v030.json")
checks=[]
def check(name, ok, detail): checks.append((name,bool(ok),detail))
company_ids=[x.get("company_id") for x in co.get("companies",[])]
installation_ids=[x.get("installation_id") for x in ins.get("installations",[])]
check("company_ids_unique",len(company_ids)==len(set(company_ids)) and None not in company_ids,f"{len(company_ids)} empresas propostas")
check("installation_ids_unique",len(installation_ids)==len(set(installation_ids)) and None not in installation_ids,f"{len(installation_ids)} propostas de instalação")
check("neighborhoods_25",len(pop.get("neighborhoods",[]))==25,f"{len(pop.get('neighborhoods',[]))} bairros")
check("population_total_1m",sum(n.get("population_proposed",0) for n in pop.get("neighborhoods",[]))==1_000_000,str(sum(n.get("population_proposed",0) for n in pop.get("neighborhoods",[]))))
check("all_company_neighborhoods_exist",all(c.get("neighborhood_name") in {n.get("name") for n in pop["neighborhoods"]} for c in co["companies"]),"bairros preferenciais comparados com matriz populacional")
check("master_company_count_matches",master["source_counts"]["companies_proposed"]==len(co["companies"]),str(master["source_counts"]["companies_proposed"]))
check("master_installation_count_matches",master["source_counts"]["installation_proposals"]==len(ins["installations"]),str(master["source_counts"]["installation_proposals"]))
check("taxonomy_profession_count",len(tax.get("profissoes",[]))==800,str(len(tax.get("profissoes",[]))))
check("taxonomy_compatibility_refs",all(x.get("Profissão ID") for x in tax.get("compatibilidade",[])),f"{len(tax.get('compatibilidade',[]))} relações")
for name,ok,detail in checks: print(("PASS" if ok else "FAIL")+"|"+name+"|"+detail)
failed=sum(not x[1] for x in checks); print(f"RESULT={'PASS' if not failed else 'FAIL'}|TOTAL={len(checks)}|FAIL={failed}"); sys.exit(1 if failed else 0)

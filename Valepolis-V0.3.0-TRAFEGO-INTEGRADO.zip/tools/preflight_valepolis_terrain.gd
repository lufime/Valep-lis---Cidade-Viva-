extends SceneTree

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var terrain_script: Script = load("res://addons/valepolis_terrain/terrain_generator.gd")
    if terrain_script == null:
        push_error("Addon Valepólis Terrain não foi carregado")
        quit(1)
        return
    var terrain: Node3D = terrain_script.new() as Node3D
    if terrain == null:
        push_error("Não foi possível instanciar ValepolisTerrain")
        quit(1)
        return
    root.add_child(terrain)
    await process_frame
    var mesh_node := terrain.get_node_or_null("TerrainMesh") as MeshInstance3D
    if mesh_node == null or mesh_node.mesh == null or mesh_node.mesh.get_surface_count() < 1:
        push_error("Addon não gerou malha de relevo")
        terrain.queue_free()
        quit(1)
        return
    var vertex_data: Variant = mesh_node.mesh.surface_get_arrays(0)[Mesh.ARRAY_VERTEX]
    var vertex_count: int = int(vertex_data.size())
    if vertex_count < 1000:
        push_error("Malha de relevo inesperadamente pequena: %d vértices" % vertex_count)
        terrain.queue_free()
        quit(1)
        return
    if terrain.get_node_or_null("TerrainCollision/TerrainShape") == null:
        push_error("Colisão do terreno não foi gerada")
        terrain.queue_free()
        quit(1)
        return
    print("VALEPOLIS_TERRAIN_PASS=vertices:%d,surfaces:%d,collision=ready" % [vertex_count, mesh_node.mesh.get_surface_count()])
    terrain.queue_free()
    quit(0)

# Política de bloqueio — PRE-FLIGHT V0.3.0

O PRE-FLIGHT é uma barreira obrigatória.

A ordem oficial do workflow é:

1. Executar PRE-FLIGHT.
2. Gerar e publicar o relatório.
3. Só quando `RESULTADO=PASS`, sem `FAIL` e sem `SKIP`, continuar.
4. Gerar/exportar o APK.
5. Se PRE-FLIGHT for `FAIL` ou `INCOMPLETE`, o job termina com erro e o APK não é gerado.

`INCOMPLETE` nunca é aprovação.

Erros de parser GDScript, erros funcionais, referências inválidas, falhas de estrutura ou qualquer etapa não executada bloqueiam a geração do APK.

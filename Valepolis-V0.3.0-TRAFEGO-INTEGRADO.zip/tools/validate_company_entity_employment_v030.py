#!/usr/bin/env python3
"""Static cross-catalog checks for Valepolis V0.3.0; does not validate Godot runtime."""
import json, sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(p): return json.loads((root/p).read_text(encoding="utf-8"))
c=read("data/companies_catalog_v030.json")["companies"]
e=read("data/entity_master_catalog.json")["entities"]
i=read("data/installation_registry_v030.json")["installations"]
p=read("data/populacao_por_bairro_v030.json")["neighborhoods"]
checks=[("company_ids_unique",len({x["company_id"] for x in c})==len(c)),("entity_ids_unique",len({x["id"] for x in e})==len(e)),("installation_ids_unique",len({x["installation_id"] for x in i})==len(i)),("neighborhoods_25",len(p)==25),("population_total_1m",sum(int(x["population_proposed"]) for x in p)==1000000),("companies_not_spawned",all(x.get("map_spawned") is False and x.get("building_id") is None for x in c)),("installations_not_spawned",all(x.get("map_spawned") is False and x.get("building_id") is None for x in i)),("no_unverified_employees",all(not x.get("employees") for x in c))]
for name,ok in checks: print(("PASS" if ok else "FAIL")+"|"+name)
print(f"RESULT={'PASS' if all(ok for _,ok in checks) else 'FAIL'}|TOTAL={len(checks)}|FAIL={sum(not ok for _,ok in checks)}")
sys.exit(0 if all(ok for _,ok in checks) else 1)

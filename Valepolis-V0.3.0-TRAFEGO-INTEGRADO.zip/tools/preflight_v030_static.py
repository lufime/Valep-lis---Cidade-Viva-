#!/usr/bin/env python3
"""Valepólis V0.3.0 offline structural PRE-FLIGHT. Does not replace Godot runtime tests."""
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
passes, failures, warnings = [], [], []

def ok(msg): passes.append(msg)
def fail(msg): failures.append(msg)
def warn(msg): warnings.append(msg)

required = [
    "project.godot", "Main.tscn", "City3D.tscn", "main.gd",
    "systems/city_3d.gd", "systems/valepolis_systems_runtime.gd",
    "tools/preflight_functional.gd", "export_presets.cfg",
]
for rel in required:
    (ok if (ROOT / rel).is_file() else fail)(f"Ficheiro obrigatório: {rel}")

# Validate every JSON file, including configuration and game data.
json_files = list(ROOT.rglob("*.json"))
for path in json_files:
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"JSON inválido: {path.relative_to(ROOT)} ({exc})")
if json_files:
    ok(f"JSON válidos: {len(json_files)} ficheiros verificados")

# Validate every literal res:// reference used in scenes/scripts/config text.
resource_exts = {".gd", ".tscn", ".tres", ".godot", ".cfg", ".json"}
checked_refs, missing_refs = 0, []
for path in ROOT.rglob("*"):
    if not path.is_file() or path.suffix not in resource_exts:
        continue
    try:
        content = path.read_text(encoding="utf-8")
    except Exception:
        continue
    for match in re.finditer(r'res://([^"\s)]+)', content):
        rel = match.group(1).rstrip(",;")
        # Only audit literal file paths; skip dynamically composed paths and
        # prose fragments that happen to begin with res://.
        if any(token in rel for token in ["%", "{", "}", "+", "$"]):
            continue
        if Path(rel).suffix not in {".gd", ".tscn", ".tres", ".png", ".jpg", ".webp", ".svg", ".json", ".cfg", ".wav", ".ogg", ".ttf", ".otf", ".md"}:
            continue
        checked_refs += 1
        if not (ROOT / rel).exists():
            missing_refs.append((path.relative_to(ROOT), rel))
for source, target in missing_refs:
    fail(f"Referência res:// em falta: {source} -> {target}")
if not missing_refs:
    ok(f"Referências res:// encontradas: {checked_refs}")

# Catch the specific invalid dictionary syntax that existed in V30.
runtime = (ROOT / "systems/valepolis_systems_runtime.gd").read_text(encoding="utf-8")
if re.search(r'"status"\s*:\s*"[^"]+"\s*:', runtime):
    fail("Sintaxe suspeita em dicionário: chave status contém um segundo ':'")
else:
    ok("Dicionários do runtime sem o padrão de sintaxe inválido V30")
for fn in ["calculate_market_price", "validate_stock_sale", "validate_public_expense",
           "calculate_credit_installment", "calculate_insurance_premium",
           "calculate_insurance_payout"]:
    (ok if f"func {fn}(" in runtime else fail)(f"Função económica: {fn}")

city = (ROOT / "systems/city_3d.gd").read_text(encoding="utf-8")
for fn in ["set_detail_level", "get_detail_level", "show_city_overview",
           "focus_neighborhood", "set_neighborhood_labels_visible"]:
    (ok if f"func {fn}(" in city else fail)(f"API mapa/câmara: {fn}")
if all(token in city for token in ['        1:', '        2:', '        3:', '        4:']):
    ok("Quatro níveis de detalhe declarados")
else:
    fail("Os quatro níveis de detalhe não estão todos declarados")

main = (ROOT / "main.gd").read_text(encoding="utf-8")
if "_v030_set_detail_level.bind(1)" in main and "_v030_set_detail_level.bind(4)" in main:
    ok("Interface liga os controlos aos níveis 1–4")
else:
    fail("Controlos da interface não estão ligados aos quatro níveis")

# Verify neighborhood data stays at 25 entries in the 3D controller.
names_match = re.search(r"const NEIGHBORHOODS := \[(.*?)\]", city, re.S)
if names_match:
    names = re.findall(r'"([^"]+)"', names_match.group(1))
    if len(names) == 25 and len(set(names)) == 25:
        ok("Lista 3D contém 25 bairros únicos")
    else:
        fail(f"Lista 3D tem {len(names)} nomes e {len(set(names))} únicos")
else:
    fail("Não foi possível localizar a lista de bairros 3D")

# Scene references must resolve; runtime tests are deliberately reported separately.
scene = (ROOT / "City3D.tscn").read_text(encoding="utf-8")
if 'res://systems/city_3d.gd' in scene:
    ok("Cena City3D ligada ao controlador esperado")
else:
    fail("City3D.tscn não referencia systems/city_3d.gd")

print("VALEPÓLIS V0.3.0 — PRE-FLIGHT ESTÁTICO")
print(f"PASS={len(passes)} FAIL={len(failures)} WARN={len(warnings)}")
for item in passes: print("PASS | " + item)
for item in warnings: print("WARN | " + item)
for item in failures: print("FAIL | " + item)
if failures:
    sys.exit(1)

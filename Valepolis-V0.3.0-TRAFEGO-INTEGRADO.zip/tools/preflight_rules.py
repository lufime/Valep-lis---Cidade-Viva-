#!/usr/bin/env python3
"""PRE-FLIGHT de regras aprovadas para Valepólis V0.3.0. Verificação estática."""
import json, re, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
passes=[]; failures=[]
def check(ok, label, detail=""):
    (passes if ok else failures).append((label,detail))
def load(rel):
    try: return json.loads((ROOT/rel).read_text(encoding="utf-8"))
    except Exception as exc:
        failures.append((f"JSON legível: {rel}",str(exc))); return {}

# Official list: exact order and names from the current project catalogue.
hoods=load("bairros_valepolis.json").get("neighborhoods",[])
names=[x.get("name") for x in hoods]
expected_names=["Nexora","Altavira","Rivéria","Marévia","Montélia","Lúmora","Florávia","Pedrália","Valeora","Brisamar","Fontélia","Silvéria","Portávia","Lacéria","Ventúria","Olivéria","Ribeora","Solária","Avelora","Terrávia","Altória","Marivora","Verdelis","Estúria","Pedravora"]
check(names==expected_names and len(set(names))==25,"25 bairros oficiais, nomes e ordem",f"encontrados={len(names)}")

# Approved population source and every runtime-facing mirror.
approved=load("data/populacao_por_bairro_v030.json")
rows=approved.get("neighborhoods",[])
expected_pop={x.get("name"):x.get("population_proposed") for x in rows}
check(approved.get("status")=="aprovado_pelo_utilizador_para_integracao","Fonte populacional marcada como aprovada",str(approved.get("status")))
check(approved.get("population_total")==1_000_000 and len(rows)==25 and sum(int(v or 0) for v in expected_pop.values())==1_000_000,"População aprovada totaliza 1.000.000",f"total={sum(int(v or 0) for v in expected_pop.values())}")
check(set(expected_pop)==set(expected_names) and len(expected_pop)==25,"Distribuição aprovada cobre os 25 bairros")
rootpop=load("populacao_valepolis.json")
root_rows=rootpop.get("neighborhoods",[])
root_map={x.get("name"):x.get("population") for x in root_rows}
share_map={x.get("name"):x.get("population_share") for x in root_rows}
check(rootpop.get("reference_population")==1_000_000 and root_map==expected_pop,"Configuração populacional de runtime coincide com fonte aprovada")
check(len(root_rows)==25 and all(abs(float(share_map.get(n,-1))-float(expected_pop[n])/1_000_000)<1e-8 for n in expected_names),"Quotas populacionais correspondem à distribuição aprovada")
hood_map={x.get("name"):x.get("population") for x in hoods}
check(hood_map==expected_pop,"Catálogo territorial coincide com população aprovada")

# Culture rules: six named influences are distinct from ten local identities; local assignments stay unresolved.
cult=load("data/cultural_identity_v030.json")
expected_cultures={"Portuguesa":"Portávia","Italiana":"Solária","Alemã":"Pedravora","Francesa":"Altavira","Asiática":"Lacéria","Africana":"Ribeora"}
actual={x.get("name"):x.get("assigned_neighborhood") for x in cult.get("cultures",[])}
check(len(cult.get("cultures",[]))==6 and actual==expected_cultures,"Seis influências culturais e atribuições aprovadas")
local=cult.get("local_identities",[])
check(len(local)==10 and len({x.get("name") for x in local})==10,"Dez identidades locais distintas")
check(all(x.get("assigned_neighborhood") is None for x in local),"Não inventa atribuições dos dez bairros de identidade local")

# Neighborhood-specific economic profiles must cover the official territory without inventing numeric prices/salaries.
necon=load("data/neighborhood_economy_v030.json")
nprofiles=necon.get("neighborhoods",[])
nmap={x.get("neighborhood"):x for x in nprofiles}
check(len(nprofiles)==25 and set(nmap)==set(expected_names),"Perfis económicos cobrem exatamente os 25 bairros")
check(all(nmap[n].get("population_reference")==expected_pop[n] for n in expected_names),"Perfis económicos usam a população aprovada por bairro")
check(all(nmap[n].get("priority_sectors") and nmap[n].get("potential_local_supply") and nmap[n].get("demand_drivers") for n in expected_names),"Cada bairro tem setores, oferta potencial e fatores de procura")
runtime_econ=(ROOT/"systems/valepolis_systems_runtime.gd").read_text(encoding="utf-8",errors="replace")
check(all(re.search(r"^func\s+"+fn+r"\s*\(",runtime_econ,re.M) for fn in ["record_market_observation","get_neighborhood_economic_profile","get_market_observation","get_market_pressure","get_market_audit"]),"Runtime expõe registo e consulta da oferta/procura por bairro")
check("neighborhood_economy = _load_json(\"neighborhood_economy_v030.json\"" in runtime_econ,"Runtime carrega os perfis económicos dos bairros")
check('"price_change": "not_applied"' in runtime_econ,"Não altera preços automaticamente sem regra e valores configurados")
check(all("price_response" in nmap[n].get("market_rules",{}) and "revenues_expenses" in nmap[n].get("market_rules",{}) for n in expected_names),"Regras de mercado auditáveis presentes por bairro")
check(necon.get("market_mechanics",{}).get("price_adjustment","").startswith("Gradual") and "não" in necon.get("design_constraints",[""])[2].lower(),"Preços graduais e sem valores inventados")
# Episodes, proposed facilities and deferred values.
episodes=load("data/episodes_200.json").get("episodes",[])
keys={(x.get("season"),x.get("episode")) for x in episodes}
check(len(episodes)==200 and len(keys)==200,"200 episódios sem duplicação")
check({x.get("season") for x in episodes}==set(range(1,21)) and all(sum(1 for x in episodes if x.get("season")==s)==10 for s in range(1,21)),"20 temporadas com 10 episódios cada")
inst=load("data/installation_registry_v030.json")
fac=inst.get("installations",[])
check(len(fac)==275 and all(x.get("map_spawned") is False and x.get("building_id") is None for x in fac),"275 instalações permanecem propostas e não geram edifícios automaticamente")
check(inst.get("count_summary",{}).get("tnur_standalone_installations")==0,"TNUR sem instalações independentes")
econ=load("data/economy_config.json")
# Regras económicas/fiscais aprovadas pelo utilizador. Não inventar salários-base,
# preços ou montantes concretos que ainda não estejam definidos no catálogo.
tax=econ.get("tax_model", {})
approved_tax={
    "social_security_rate": 0.11,
    "irs_marginal_brackets": [
        {"up_to": 900, "rate": 0.00},
        {"up_to": 1500, "rate": 0.05},
        {"up_to": 2500, "rate": 0.10},
        {"up_to": 4000, "rate": 0.18},
        {"up_to": None, "rate": 0.25}
    ],
    "consumption_tax_rates": {"essentials": 0.00, "ordinary": 0.13, "non_essential": 0.23},
    "property_tax_annual_range": [0.003, 0.008],
    "profits_tax_rate": 0.15
}
check(econ.get("currency")=="EUR" and econ.get("accounting")=="cents","Economia usa EUR e contabilidade em cêntimos")
check(tax==approved_tax,"Modelo fiscal coincide com regras aprovadas",f"modelo={tax}")
check(econ.get("net_salary_formula")=="gross_salary - social_security - IRS","Fórmula de salário líquido aprovada")
check(econ.get("starting_balance_rule")=="one_month_net_salary","Saldo inicial corresponde a um mês de salário líquido")
check(set(["supply_demand","persistent_accounts","municipal_economy","inflation","economic_cycles","emergencies"]).issubset(set(econ.get("economic_systems", []))),"Sistemas económicos aprovados identificados")
check(econ.get("configured") is True and econ.get("status")=="approved_rules_values_pending","Regras fiscais aprovadas sem inventar salários-base/preços")

# Technical configuration and strict PRE-FLIGHT gates.
project=(ROOT/"project.godot").read_text(encoding="utf-8",errors="replace") if (ROOT/"project.godot").exists() else ""
export=(ROOT/"export_presets.cfg").read_text(encoding="utf-8",errors="replace") if (ROOT/"export_presets.cfg").exists() else ""
workflow=(ROOT/".github/workflows/build.yml").read_text(encoding="utf-8",errors="replace") if (ROOT/".github/workflows/build.yml").exists() else ""
check('config/version="0.3.0"' in project and 'version/name="0.3.0"' in export,"Versão ativa V0.3.0 coerente")
check('version/code=30000' in export,"versionCode Android igual a 30000")
check("TOTAL_FAIL" in workflow or "preflight.sh" in workflow,"Workflow chama o PRE-FLIGHT")
check("INCOMPLETE" in (ROOT/"tools/preflight.py").read_text(encoding="utf-8",errors="replace") if (ROOT/"tools/preflight.py").exists() else False,"Runner distingue INCOMPLETE de PASS")

for label,detail in passes: print("PASS|"+label+("|"+detail if detail else ""))
for label,detail in failures: print("FAIL|"+label+("|"+detail if detail else ""))
print(f"RULES_AUDIT={'PASS' if not failures else 'FAIL'}|passes={len(passes)}|failures={len(failures)}")
sys.exit(0 if not failures else 1)

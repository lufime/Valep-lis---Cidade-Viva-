#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ $# -lt 1 ]]; then
  echo "Uso: bash run_preflight.sh /caminho/para/o/projeto [--godot /caminho/godot] [--export-apk]"
  exit 64
fi
PROJECT="$1"
shift
python3 "$HERE/preflight.py" "$PROJECT" "$@"

# Valepólis V0.3.0 — Mapa geral e 25 mapas independentes

## Alteração
- Adicionado `systems/neighborhood_overview_map.gd`, um controlo Godot que desenha o mapa geral a partir dos polígonos reais guardados em `data/limites_bairros_v030.json`.
- O mapa geral apresenta os limites territoriais dos 25 bairros, nomes e seleção por toque/clique.
- `main.gd` integra o mapa geral na janela Atlas, mantendo os 25 cartões individuais e os seus botões de abertura 3D.
- Selecionar um polígono chama o fluxo existente `_v030_select_2d_map_neighborhood`, que abre a vista 3D focada no bairro.
- O mapa usa os limites X/Z existentes; não cria nem altera a posição dos bairros, as áreas exteriores ou a atribuição cultural.

## Validação executada nesta sessão
- ZIP original extraído sem erro.
- `project.godot` presente.
- JSON territorial analisado: 25 bairros, 25 nomes únicos e todos os 25 polígonos têm pelo menos 3 pontos.
- Confirmada a integração do novo mapa em `main.gd` e a existência do script novo.
- Não foi possível executar o parser/runtime Godot nesta sessão porque o executável Godot não está instalado/disponível. A compilação Android e o teste visual no telemóvel permanecem por validar no GitHub Actions/dispositivo.

## Ficheiros alterados/adicionados
- Modificado: `main.gd`
- Adicionado: `systems/neighborhood_overview_map.gd`
- Adicionado: `IMPLEMENTACAO-MAPA-GERAL-25-BAIRROS.md`

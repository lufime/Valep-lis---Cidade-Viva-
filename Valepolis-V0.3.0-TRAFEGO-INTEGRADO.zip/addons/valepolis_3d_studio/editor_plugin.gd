@tool
extends EditorPlugin

func _enter_tree() -> void:
    add_custom_type("ValepolisProceduralCharacter", "Node3D", preload("res://addons/valepolis_3d_studio/procedural_character.gd"), null)

func _exit_tree() -> void:
    remove_custom_type("ValepolisProceduralCharacter")

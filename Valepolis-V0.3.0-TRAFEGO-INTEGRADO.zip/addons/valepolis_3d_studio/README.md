# Valepólis 3D Studio

Addon próprio para gerar recursos 3D no Godot, sem ferramentas externas obrigatórias.

- `procedural_character.gd`: personagem modular procedural, com variação determinística e uniformes-base por entidade.
- `asset_generator.gd`: gera cinco cenas de personagens e cinco cenas de edifícios diretamente como `.tscn`.
- `editor_plugin.gd`: regista o tipo de personagem no editor.

Limitação da versão inicial: os personagens usam geometria procedural simples; rigging completo, expressões faciais, roupa detalhada e animações avançadas são fases posteriores.


### Personagens procedurais — detalhes V0.3.0

A geração inclui detalhes geométricos adicionais (mãos, calçado, olhos, nariz, fecho e faixa refletora conforme a função). Estes modelos continuam estilizados e não incluem ainda rigging nem animações completas.

extends Node3D
class_name ValepolisProceduralCharacter

## Personagem procedural melhorada para Valepólis V0.3.0.
## Modelo low-poly modular, com silhueta, rosto, cabelo e uniforme diferenciados.
## Continua independente de assets externos para ser compatível com Android.
@export var seed_value: int = 1
@export_enum("Civil", "BRIGADA", "SUE", "TNUR", "Policia") var role: String = "Civil"
@export_range(1.45, 2.1, 0.01) var character_height: float = 1.72
@export var regenerate_on_ready: bool = true
var _animation_clock: float = 0.0
var _is_moving: bool = false
var _rest_rotations: Dictionary = {}

func _ready() -> void:
    if regenerate_on_ready:
        regenerate()

func regenerate() -> void:
    for child in get_children():
        child.queue_free()
    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    var skin_palette: Array[Color] = [Color("#f1c7a5"), Color("#d9a77c"), Color("#b97852"), Color("#8d573d"), Color("#6b402f")]
    var hair_palette: Array[Color] = [Color("#211a18"), Color("#493026"), Color("#79502f"), Color("#b27c43"), Color("#d7c39c"), Color("#77716b")]
    var skin: Color = skin_palette[rng.randi_range(0, skin_palette.size() - 1)]
    var hair: Color = hair_palette[rng.randi_range(0, hair_palette.size() - 1)]
    var uniform := _uniform_color()
    var dark_uniform := uniform.darkened(0.24)
    var light_uniform := uniform.lightened(0.22)
    var h := character_height
    var head_w := rng.randf_range(0.92, 1.08)
    var hair_style := rng.randi_range(0, 3)
    var body_style := rng.randi_range(0, 2)

    # Pernas, joelhos e calçado separados para uma silhueta menos rígida.
    _add_capsule("LegL", Vector3(-0.105, h * 0.22, 0), Vector3(0.105, h * 0.22, 0.11), Color("#293745"))
    _add_capsule("LegR", Vector3(0.105, h * 0.22, 0), Vector3(0.105, h * 0.22, 0.11), Color("#293745"))
    _add_box("ShoeL", Vector3(-0.11, 0.055, 0.07), Vector3(0.17, 0.11, 0.30), Color("#17232c"))
    _add_box("ShoeR", Vector3(0.11, 0.055, 0.07), Vector3(0.17, 0.11, 0.30), Color("#17232c"))

    # Tronco com casaco/colete e uma segunda camada frontal.
    _add_capsule("Torso", Vector3(0, h * 0.55, 0), Vector3(0.36, h * 0.18, 0.22), uniform)
    if body_style == 0:
        _add_box("CasacoFrente", Vector3(0, h * 0.55, 0.177), Vector3(0.39, h * 0.27, 0.055), uniform)
    elif body_style == 1:
        _add_box("ColeteFrente", Vector3(0, h * 0.55, 0.184), Vector3(0.31, h * 0.25, 0.045), light_uniform)
    else:
        _add_box("CamisaFrente", Vector3(0, h * 0.55, 0.181), Vector3(0.25, h * 0.24, 0.04), light_uniform)
    _add_capsule("Neck", Vector3(0, h * 0.72, 0), Vector3(0.09, 0.08, 0.09), skin)

    # Braços ligeiramente afastados do corpo, com ombros, mangas e mãos.
    _add_sphere("ShoulderL", Vector3(-0.245, h * 0.65, 0), Vector3(0.13, 0.14, 0.13), uniform)
    _add_sphere("ShoulderR", Vector3(0.245, h * 0.65, 0), Vector3(0.13, 0.14, 0.13), uniform)
    _add_capsule("ArmL", Vector3(-0.285, h * 0.53, 0), Vector3(0.085, h * 0.20, 0.085), uniform, deg_to_rad(7.0))
    _add_capsule("ArmR", Vector3(0.285, h * 0.53, 0), Vector3(0.085, h * 0.20, 0.085), uniform, deg_to_rad(-7.0))
    _add_sphere("HandL", Vector3(-0.31, h * 0.36, 0.025), Vector3(0.075, 0.085, 0.075), skin)
    _add_sphere("HandR", Vector3(0.31, h * 0.36, 0.025), Vector3(0.075, 0.085, 0.075), skin)

    # Cabeça, orelhas e rosto com profundidade visível na câmara frontal.
    _add_sphere("Head", Vector3(0, h * 0.835, 0), Vector3(0.225 * head_w, 0.265, 0.215), skin)
    _add_sphere("EarL", Vector3(-0.222 * head_w, h * 0.835, 0.012), Vector3(0.045, 0.065, 0.035), skin)
    _add_sphere("EarR", Vector3(0.222 * head_w, h * 0.835, 0.012), Vector3(0.045, 0.065, 0.035), skin)
    var eye_y := h * 0.846
    _add_sphere("EyeL", Vector3(-0.073 * head_w, eye_y, 0.194), Vector3(0.031, 0.037, 0.018), Color("#f8f5eb"))
    _add_sphere("EyeR", Vector3(0.073 * head_w, eye_y, 0.194), Vector3(0.031, 0.037, 0.018), Color("#f8f5eb"))
    _add_sphere("PupilL", Vector3(-0.071 * head_w, eye_y, 0.211), Vector3(0.014, 0.022, 0.009), Color("#20252a"))
    _add_sphere("PupilR", Vector3(0.075 * head_w, eye_y, 0.211), Vector3(0.014, 0.022, 0.009), Color("#20252a"))
    _add_capsule("BrowL", Vector3(-0.073 * head_w, h * 0.873, 0.195), Vector3(0.046, 0.012, 0.012), hair)
    _add_capsule("BrowR", Vector3(0.073 * head_w, h * 0.873, 0.195), Vector3(0.046, 0.012, 0.012), hair)
    _add_sphere("Nose", Vector3(0, h * 0.818, 0.218), Vector3(0.031, 0.045, 0.032), skin.darkened(0.04))
    _add_box("Mouth", Vector3(0, h * 0.786, 0.207), Vector3(0.065, 0.012, 0.012), Color("#8b5148"))

    # Cabelo com quatro padrões determinísticos; evita clones visuais perfeitos.
    match hair_style:
        0:
            _add_sphere("HairCap", Vector3(0, h * 0.925, -0.005), Vector3(0.235 * head_w, 0.105, 0.22), hair)
        1:
            _add_sphere("HairCap", Vector3(0, h * 0.923, -0.015), Vector3(0.24 * head_w, 0.09, 0.22), hair)
            _add_sphere("HairBack", Vector3(0, h * 0.825, -0.12), Vector3(0.21, 0.20, 0.12), hair)
        2:
            _add_sphere("HairCap", Vector3(0, h * 0.93, 0), Vector3(0.235 * head_w, 0.075, 0.215), hair)
            _add_sphere("HairSideL", Vector3(-0.19, h * 0.86, 0), Vector3(0.055, 0.12, 0.10), hair)
            _add_sphere("HairSideR", Vector3(0.19, h * 0.86, 0), Vector3(0.055, 0.12, 0.10), hair)
        _:
            _add_sphere("HairCap", Vector3(0, h * 0.925, -0.02), Vector3(0.24 * head_w, 0.11, 0.23), hair)
            _add_sphere("Franja", Vector3(0, h * 0.89, 0.15), Vector3(0.16, 0.055, 0.09), hair)

    # Gola, fecho, bolsos e distintivos mudam de acordo com a entidade.
    _add_box("CollarL", Vector3(-0.075, h * 0.686, 0.176), Vector3(0.12, 0.07, 0.035), light_uniform)
    _add_box("CollarR", Vector3(0.075, h * 0.686, 0.176), Vector3(0.12, 0.07, 0.035), light_uniform)
    _add_box("UniformZip", Vector3(0, h * 0.55, 0.214), Vector3(0.014, h * 0.22, 0.014), Color("#d8e0e5"))
    _add_box("PocketL", Vector3(-0.105, h * 0.53, 0.215), Vector3(0.09, 0.09, 0.025), dark_uniform)
    _add_box("PocketR", Vector3(0.105, h * 0.53, 0.215), Vector3(0.09, 0.09, 0.025), dark_uniform)
    if role in ["BRIGADA", "SUE", "TNUR"]:
        var band_color: Color = Color("#e8cf54") if role == "BRIGADA" else Color("#e7edf0")
        _add_box("ReflectiveBand", Vector3(0, h * 0.49, 0.222), Vector3(0.37, 0.045, 0.025), band_color)
    if role == "Policia":
        _add_box("PoliceBadge", Vector3(-0.11, h * 0.64, 0.218), Vector3(0.065, 0.08, 0.025), Color("#d6bd65"))
        _add_box("ShoulderPatch", Vector3(0.235, h * 0.65, 0.13), Vector3(0.08, 0.09, 0.035), Color("#d6bd65"))

    # Sombra/plataforma discreta para retratos 3D.
    var base := MeshInstance3D.new()
    base.name = "CharacterBase"
    var base_mesh := CylinderMesh.new()
    base_mesh.top_radius = 0.43
    base_mesh.bottom_radius = 0.46
    base_mesh.height = 0.055
    base.mesh = base_mesh
    base.position = Vector3(0, 0.025, 0)
    base.material_override = _material(Color("#2c4657"))
    add_child(base)

func _uniform_color() -> Color:
    match role:
        "BRIGADA": return Color("#263c4a")
        "SUE": return Color("#f1f3f4")
        "TNUR": return Color("#f2f2f2")
        "Policia": return Color("#152d50")
        _: return Color("#426b85")

func _material(color: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = 0.78
    return material

func _add_box(part_name: String, pos: Vector3, dimensions: Vector3, color: Color) -> void:
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = part_name
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    mesh_instance.material_override = _material(color)
    add_child(mesh_instance)

func _add_capsule(part_name: String, pos: Vector3, dimensions: Vector3, color: Color, rot_z: float = 0.0) -> void:
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = part_name
    var mesh := CapsuleMesh.new()
    mesh.radius = minf(dimensions.x, dimensions.z)
    mesh.height = maxf(mesh.radius * 2.0, dimensions.y * 2.0)
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    mesh_instance.rotation.z = rot_z
    mesh_instance.material_override = _material(color)
    add_child(mesh_instance)

func _add_sphere(part_name: String, pos: Vector3, scale_value: Vector3, color: Color) -> void:
    var mesh_instance := MeshInstance3D.new()
    mesh_instance.name = part_name
    var mesh := SphereMesh.new()
    mesh.radius = 0.5
    mesh.height = 1.0
    mesh_instance.mesh = mesh
    mesh_instance.position = pos
    mesh_instance.scale = scale_value * 2.0
    mesh_instance.material_override = _material(color)
    add_child(mesh_instance)


## Ativado pelo controlador do mundo para distinguir repouso e marcha.
func set_moving(value: bool) -> void:
    _is_moving = value

func _process(delta: float) -> void:
    _animation_clock += delta
    var gait_speed := 8.5 if _is_moving else 2.0
    var gait_amount := 0.42 if _is_moving else 0.035
    _animate_part("LegL", sin(_animation_clock * gait_speed) * gait_amount)
    _animate_part("LegR", sin(_animation_clock * gait_speed + PI) * gait_amount)
    _animate_part("ArmL", sin(_animation_clock * gait_speed + PI) * gait_amount * 0.72)
    _animate_part("ArmR", sin(_animation_clock * gait_speed) * gait_amount * 0.72)
    _animate_part("Head", sin(_animation_clock * (1.4 if not _is_moving else 4.2)) * (0.012 if not _is_moving else 0.025))

func _animate_part(part_name: String, angle: float) -> void:
    var part := get_node_or_null(part_name) as Node3D
    if part == null:
        return
    if not _rest_rotations.has(part_name):
        _rest_rotations[part_name] = part.rotation
    var rest: Vector3 = _rest_rotations[part_name]
    part.rotation = Vector3(rest.x, rest.y, rest.z + angle)

# Valepólis Terrain 1.1.0 — relevo geográfico automático

Addon próprio de Godot, sem dependência do Terrain3D ou de extensões nativas externas.

## Geografia configurada
- Norte: transição de planície para praia e costa.
- Oeste: vale do rio/estuário e margens.
- Centro: planície urbana suave para os 25 bairros e a malha viária existente.
- Este: cordilheira com cristas e vales de alturas variáveis.
- Sul: terreno ondulado para a zona de Santo André do Vale e Portela do Sul.

O relevo é gerado automaticamente por uma função de altura determinística e contínua. Não usa dados GIS reais nem um DEM externo: representa a geografia fictícia aprovada de Valepólis através das coordenadas já usadas no mapa V0.3.0.

## API
- `regenerate()` — reconstrói a malha e a colisão.
- `height_at(x, z)` — consulta a altura calculada para coordenadas do mapa.
- `get_geography_profile()` — devolve o perfil geográfico aplicado.
- `generate_collision` — permite ativar/desativar colisão.
- `resolution` — resolução da malha, predefinição 160 segmentos por eixo.

A versão precisa de execução real no Godot para validar renderização, colisões e exportação Android. A criação do ZIP não equivale a uma compilação ou teste runtime.

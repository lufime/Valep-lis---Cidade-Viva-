@tool
extends EditorPlugin

const TERRAIN_SCRIPT: Script = preload("res://addons/valepolis_terrain/terrain_generator.gd")

func _enter_tree() -> void:
    add_custom_type("ValepolisTerrain", "Node3D", TERRAIN_SCRIPT, null)

func _exit_tree() -> void:
    remove_custom_type("ValepolisTerrain")

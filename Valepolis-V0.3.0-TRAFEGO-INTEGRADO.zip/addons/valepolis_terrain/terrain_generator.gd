extends Node3D
class_name ValepolisTerrainGenerator

## Relevo procedural de Valepólis, gerado automaticamente a partir da geografia
## aprovada do mapa: costa/praias a norte, rio-estuário a oeste, centro urbano
## relativamente plano, montanhas a este e terreno ondulado a sul.
## Coordenadas do mapa: X negativo = oeste; X positivo = este;
## Z negativo = norte; Z positivo = sul.

@export_range(32, 256, 1) var resolution: int = 192
@export_range(64.0, 256.0, 1.0) var terrain_width: float = 192.0
@export_range(64.0, 256.0, 1.0) var terrain_depth: float = 176.0
@export_range(0.0, 1.0, 0.01) var hills_strength: float = 1.0
@export_range(4.0, 40.0, 0.5) var mountain_height: float = 20.0
@export var generate_collision: bool = true
@export var generate_on_ready: bool = true

const WATER_LEVEL: float = 0.0
const CITY_FLAT_HALF_EXTENT := Vector2(29.0, 27.0)
const CITY_TRANSITION := Vector2(15.0, 18.0)
const COAST_CENTER_Z := -57.0
const RIVER_CENTER_X := -56.0

var _mesh_instance: MeshInstance3D
var _body: StaticBody3D

func _ready() -> void:
    if generate_on_ready:
        regenerate()

func regenerate() -> void:
    if not is_inside_tree():
        return
    if is_instance_valid(_mesh_instance):
        _mesh_instance.queue_free()
    if is_instance_valid(_body):
        _body.queue_free()
    var mesh := _build_mesh()
    _mesh_instance = MeshInstance3D.new()
    _mesh_instance.name = "TerrainMesh"
    _mesh_instance.mesh = mesh
    add_child(_mesh_instance)
    if generate_collision:
        _body = StaticBody3D.new()
        _body.name = "TerrainCollision"
        var collision := CollisionShape3D.new()
        collision.name = "TerrainShape"
        collision.shape = mesh.create_trimesh_shape()
        _body.add_child(collision)
        add_child(_body)

func _smooth01(a: float, b: float, value: float) -> float:
    if is_equal_approx(a, b):
        return 0.0 if value < a else 1.0
    var t := clampf((value - a) / (b - a), 0.0, 1.0)
    return t * t * (3.0 - 2.0 * t)

func _noise(x: float, z: float) -> float:
    # Ruído determinístico por ondas combinadas; não depende de addons externos.
    return (sin(x * 0.115 + z * 0.037) * 0.46
        + cos(z * 0.093 - x * 0.052) * 0.32
        + sin((x + z) * 0.041) * 0.22)

func _height(x: float, z: float) -> float:
    # Centro de Valepólis: plataforma urbana suave para manter a malha viária
    # e os edifícios existentes compatíveis com o mapa V0.3.0.
    var flat_x := 1.0 - _smooth01(CITY_FLAT_HALF_EXTENT.x, CITY_FLAT_HALF_EXTENT.x + CITY_TRANSITION.x, absf(x))
    var flat_z := 1.0 - _smooth01(CITY_FLAT_HALF_EXTENT.y, CITY_FLAT_HALF_EXTENT.y + CITY_TRANSITION.y, absf(z))
    var city_flat := flat_x * flat_z

    var base_noise := _noise(x, z) * hills_strength
    var rolling_south := _smooth01(12.0, 34.0, z) * (1.8 + base_noise * 2.3)

    # Cordilheira oriental: vários alinhamentos irregulares, mais elevados para
    # leste, com vales entre cristas em vez de uma única parede uniforme.
    var east_factor := _smooth01(31.0, 57.0, x)
    var ridge_1 := exp(-pow((z + 21.0 + sin(x * 0.12) * 4.0) / 13.0, 2.0))
    var ridge_2 := exp(-pow((z - 5.0 + cos(x * 0.09) * 5.0) / 17.0, 2.0))
    var ridge_3 := exp(-pow((z - 32.0 + sin(x * 0.08) * 3.0) / 10.0, 2.0))
    var mountain_noise := base_noise * 2.0 + sin(x * 0.27 + z * 0.11) * 1.1
    var mountains := east_factor * mountain_height * (0.10 + 0.42 * ridge_1 + 0.38 * ridge_2 + 0.30 * ridge_3)
    mountains += east_factor * mountain_noise

    # Costa norte: terreno desce suavemente para a praia e o nível do mar.
    # O plano de água já existe em systems/city_3d.gd.
    var coast_factor := _smooth01(-34.0, -57.0, z)
    var coastal_slope := -1.15 * coast_factor
    var beach_ridge := 0.55 * exp(-pow((z + 51.0) / 4.0, 2.0))

    # Rio/estuário a oeste: margens baixas e vale longitudinal sob o canal
    # visual existente, sem elevar o centro urbano.
    var river_distance := absf(x - RIVER_CENTER_X)
    var river_bank := 0.65 * exp(-pow((river_distance - 8.0) / 4.5, 2.0))
    var river_valley := -0.72 * exp(-pow(river_distance / 7.5, 2.0))
    var river_end_fade := 1.0 - _smooth01(39.0, 49.0, absf(z))
    river_bank *= river_end_fade
    river_valley *= river_end_fade

    # Aplicar relevo natural nas zonas não urbanas, mantendo transição contínua.
    var natural_height := base_noise * 1.65 + rolling_south + mountains + coastal_slope + beach_ridge + river_bank + river_valley
    return natural_height * (1.0 - city_flat)

func height_at(world_x: float, world_z: float) -> float:
    return _height(world_x, world_z)

func get_geography_profile() -> Dictionary:
    return {
        "north": "costa_e_praias",
        "west": "rio_estuario",
        "center": "planicie_urbana_25_bairros",
        "east": "montanhas_e_vales",
        "south": "terreno_ondulado_santo_andre_do_vale_portela_do_sul",
        "water_level": WATER_LEVEL,
        "generated_from_geography": true
    }

func _vertex_color(height: float, x: float, z: float) -> Color:
    if x > 31.0 and height > 7.0:
        return Color(0.37, 0.38, 0.35) # rocha oriental
    if z < -47.0 and height < 1.8:
        return Color(0.76, 0.69, 0.51) # areia da costa norte
    if absf(x - RIVER_CENTER_X) < 8.5 and absf(z) < 45.0:
        return Color(0.43, 0.49, 0.34) # margens do estuário
    if height > 5.0:
        return Color(0.32, 0.38, 0.27)
    if z > 26.0:
        return Color(0.30, 0.40, 0.25) # colinas a sul
    return Color(0.25, 0.39, 0.23) # planície/verde

func _build_mesh() -> ArrayMesh:
    var segments: int = clampi(resolution, 32, 256)
    var vertices := PackedVector3Array()
    var uvs := PackedVector2Array()
    var colors := PackedColorArray()
    var indices := PackedInt32Array()
    vertices.resize((segments + 1) * (segments + 1))
    uvs.resize(vertices.size())
    colors.resize(vertices.size())
    var half_w := terrain_width * 0.5
    var half_d := terrain_depth * 0.5
    for z_i in range(segments + 1):
        var z := -half_d + terrain_depth * float(z_i) / float(segments)
        for x_i in range(segments + 1):
            var x := -half_w + terrain_width * float(x_i) / float(segments)
            var idx := z_i * (segments + 1) + x_i
            var h := _height(x, z)
            vertices[idx] = Vector3(x, h, z)
            uvs[idx] = Vector2(float(x_i) / float(segments), float(z_i) / float(segments))
            colors[idx] = _vertex_color(h, x, z)
    for z_i in range(segments):
        for x_i in range(segments):
            var a := z_i * (segments + 1) + x_i
            var b := a + 1
            var c := a + segments + 1
            var d := c + 1
            indices.append_array(PackedInt32Array([a, c, b, b, c, d]))
    var arrays: Array = []
    arrays.resize(Mesh.ARRAY_MAX)
    arrays[Mesh.ARRAY_VERTEX] = vertices
    arrays[Mesh.ARRAY_TEX_UV] = uvs
    arrays[Mesh.ARRAY_COLOR] = colors
    arrays[Mesh.ARRAY_INDEX] = indices
    var mesh := ArrayMesh.new()
    mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
    var material := StandardMaterial3D.new()
    material.vertex_color_use_as_albedo = true
    material.roughness = 1.0
    material.cull_mode = BaseMaterial3D.CULL_DISABLED
    mesh.surface_set_material(0, material)
    return mesh

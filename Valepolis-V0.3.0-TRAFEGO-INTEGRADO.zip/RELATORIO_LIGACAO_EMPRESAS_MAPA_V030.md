# Relatório — Ligação de empresas ao mapa 3D (V0.3.0)

## Alteração
- `systems/city_3d.gd` chama `_bind_companies_to_existing_buildings()` após gerar o mundo.
- A rotina percorre nós já existentes e procura `address_id` exato e bairro coincidente com a morada candidata da empresa.
- Quando encontra correspondência, grava apenas metadados informativos `company_candidate_id`, `company_candidate_name` e estado pendente de aprovação física no edifício existente.
- Não cria edifícios, coordenadas, empresas operacionais, trabalhadores ou empregos.
- Registos sem correspondência exata permanecem pendentes e são contados no log.

## Verificações estáticas executadas
- JSON do catálogo de empresas parseado.
- IDs de empresa únicos.
- IDs de moradas candidatas existentes e bairros coincidentes.
- Script contém chamada após `_build_world()` e antes da criação de instalações aprovadas.
- ZIP testado com `unzip -t` após empacotamento.

## Limitações
- O mapa procedural atribui apenas um subconjunto das moradas existentes aos edifícios genéricos. Por isso, é esperado que muitas empresas não encontrem correspondência física exata nesta fase.
- Os edifícios gerados proceduralmente não equivalem automaticamente a instalações comerciais reais. A ligação por metadados não confirma uso, capacidade, acesso, nem aprovação da implantação.
- Godot não estava disponível neste ambiente; não foi possível executar o projeto, confirmar parsing GDScript no motor, testar visualmente o mapa ou exportar APK.

## Estado
Integração segura de correspondências exatas implementada no código; validação runtime/visual e ligações físicas restantes pendentes.

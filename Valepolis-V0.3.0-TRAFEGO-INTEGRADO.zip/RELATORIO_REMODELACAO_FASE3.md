# Valepólis V0.3.0 — Remodelação Fase 3

## Alterações efetuadas no código
- Aumentado o fator de expansão do cenário de 1,25 para 1,45.
- Corrigida a conversão de coordenadas na consulta de altura do terreno para que objetos que se movem usem a mesma escala do terreno expandido.
- Corrigidos os percursos armazenados em arrays dos veículos e peões: estes caminhos não eram filhos Node3D e não eram ampliados pela expansão da hierarquia, pelo que os agentes podiam regressar às coordenadas antigas ao começar a mover-se.
- A posição inicial da personagem acompanha a expansão aplicada ao mundo.
- Ampliado o alcance e reajustada a distância de câmara para a nova dimensão do mapa.

## Validação realizada
- Verificação textual dos blocos alterados: realizada.
- Verificação de integridade do ZIP: a executar no empacotamento.
- Execução/importação em Godot 4.5: não disponível neste ambiente.
- Renderização, colisões, circulação real, FPS e APK: não testados.

## Limitações
Esta fase corrige inconsistências de escala que afetavam os objetos móveis e amplia o mapa de forma uniforme. Não equivale a reconstruir individualmente cada edifício, rua, ponte ou perfil topográfico. A passagem dos veículos pelas pontes e a ausência de colisões com edifícios continuam a exigir teste em execução.

# Valepólis V0.3.0 — Remodelação estrutural, fase 1

## Alterações aplicadas
- Aumentada a distância inicial da câmara de 48 para 108 unidades para enquadrar uma porção muito maior da cidade e tornar mais fácil localizar bairros e vias.
- Aumentado o campo de visão de 58° para 64° e o alcance de câmara para 900 unidades.
- Recalibrado o zoom externo para manter uma vista geral útil e permitir aproximação gradual sem reduzir a distância abaixo de 24 unidades.
- Mantidos os nomes dos 25 bairros, o relevo próprio, as duas pontes e o workflow existente.

## O que esta fase não resolve ainda
- Não altera a escala física do terreno nem reconstrói os quarteirões.
- Não comprova a circulação real dos veículos ou a navegabilidade de todas as estradas.
- Não substitui a validação visual de relevo, edifícios, pontes, personagem e câmara no Godot.
- Não altera `.github/workflows/build.yml`.

## Validação efetuada
- Verificação textual das alterações de câmara: concluída.
- Godot 4.5 disponível neste ambiente: não encontrado.
- Execução do projeto e exportação/teste de APK: não realizados.

# Valepólis V0.3.0 — Mapa dos 25 bairros V20

## Alterações
- A vista inicial da cena 3D passa a enquadrar a cidade inteira, com uma distância maior e uma inclinação panorâmica.
- Adicionada a API `get_neighborhood_names()` para uma futura/ligada interface poder listar os 25 nomes oficiais.
- Adicionada `focus_neighborhood(nome)` para centrar a câmara num bairro existente sem alterar as suas coordenadas.
- Adicionada `set_neighborhood_labels_visible(bool)` para mostrar/ocultar apenas as etiquetas territoriais dos bairros.
- As etiquetas de bairro recebem o grupo `valepolis_neighborhood_labels`.
- Não foram alterados o workflow, as posições territoriais, as regras do jogo nem os dados populacionais.

## Limitações e validação
- ZIP derivado de V19 corrigida; apenas `systems/city_3d.gd` e este README foram alterados.
- A integridade do arquivo foi verificada após a criação.
- Não foi possível executar Godot neste ambiente. A apresentação visual, a seleção ligada a botões da interface e a compilação continuam por confirmar em runtime.
- O seletor de bairros fica disponível como API de cena; não se afirma que tenha sido acrescentado um botão visível à interface existente.

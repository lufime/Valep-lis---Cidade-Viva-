extends RefCounted
class_name ValepolisCharacterGenerator

# Gerador determinístico e reproduzível de personagens.
# Os retratos são gerados como placeholders visuais fictícios; não representam pessoas reais.

const FICTIONAL_GIVEN_A := [
    "Arel","Néria","Varel","Lúvia","Cael","Míria","Darel","Zélio","Ivara","Névio",
    "Sálen","Téria","Vion","Aven","Rélia","Dávio","Elvar","Mavira","Nélor","Sávia",
    "Orven","Léria","Célor","Véria","Tavén","Ilen","Raviel","Móvia","Zaren","Elior",
    "Navira","Valen","Cória","Rúvio","Melva","Arven","Sélia","Téron","Lunel","Várea"
]
const FICTIONAL_GIVEN_B := [
    "a","e","i","o","u","ia","ea","io","iel","ara","ora","ira","ena","eva","ila","uno","éria","ávia"
]
const FICTIONAL_SUR_A := [
    "Val","Ner","Lor","Mar","Vel","Riv","Sol","Aven","Cal","Dór","Fen","Lun","Mor","Tav",
    "Ser","Vél","Orv","Nex","Alv","Rén","Sil","Tor","Vár","Cér","Mav","Del","Rov","Elv"
]
const FICTIONAL_SUR_B := [
    "ara","eno","ira","ova","eli","una","or","is","en","ava","ion","el","ora","im","eus","al"
]

static func _invented_word(rng: RandomNumberGenerator, pool_a: Array, pool_b: Array) -> String:
    var s := str(pool_a[rng.randi_range(0, pool_a.size()-1)])
    if rng.randf() < 0.75:
        s += str(pool_b[rng.randi_range(0, pool_b.size()-1)])
    return s

static func generate_name(seed: int, used: Dictionary = {}) -> String:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed
    for attempt in range(100):
        var first := _invented_word(rng, FICTIONAL_GIVEN_A, FICTIONAL_GIVEN_B)
        var surname := _invented_word(rng, FICTIONAL_SUR_A, FICTIONAL_SUR_B)
        var name := first + " " + surname
        if not used.has(name):
            return name
    return "Habitante-%06d" % abs(seed)

static func generate_character(seed: int, profession: String = "Cidadão") -> Dictionary:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed
    var gender: String = ["F", "M"][rng.randi_range(0, 1)]
    var age := rng.randi_range(18, 82)
    return {
        "id": "VAL-%08d" % abs(seed),
        "name": generate_name(seed),
        "age": age,
        "gender": gender,
        "profession": profession,
        "portrait_seed": seed,
        "portrait_style": "realista_ficticio",
        "portrait_path": "user://portraits/VAL-%08d.png" % abs(seed)
    }

static func portrait_path(id: String) -> String:
    return "user://portraits/" + id + ".png"

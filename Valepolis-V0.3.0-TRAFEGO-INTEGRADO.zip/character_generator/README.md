# Gerador de Personagens V0.3.0

## Regra oficial de nomes

Os nomes das personagens são **100% fictícios**.

O sistema não usa:
- listas de nomes portugueses reais;
- apelidos reais;
- bases de dados de pessoas;
- nomes de celebridades;
- nomes gerados pela simples combinação de nomes reais.

Os nomes são construídos a partir de blocos fonéticos próprios do universo de Valepólis.
A `seed` garante reprodutibilidade e o controlo de duplicados evita identidades repetidas.

Os retratos são avatares procedurais fictícios e não representam pessoas reais.

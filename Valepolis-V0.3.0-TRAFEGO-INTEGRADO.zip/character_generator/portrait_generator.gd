extends RefCounted
class_name ValepolisPortraitGenerator

# Gera retratos 2D fictícios diretamente em runtime.
# Não usa fotografias de pessoas reais. O resultado é um avatar estilizado,
# consistente para o mesmo seed.

static func generate_portrait(seed: int, size: int = 256) -> Image:
    var rng := RandomNumberGenerator.new()
    rng.seed = seed
    var img := Image.create(size, size, false, Image.FORMAT_RGBA8)
    img.fill(Color("111827"))

    var skin_palette := [Color("f1c7a5"),Color("d9a77c"),Color("b97852"),Color("8d573d"),Color("6b402f")]
    var hair_palette := [Color("241b18"),Color("4a3026"),Color("7b4a2e"),Color("b7834f"),Color("d9c09a")]
    var shirt_palette := [Color("234b6f"),Color("355f7a"),Color("4d5d73"),Color("315b4c"),Color("6b4b5a")]

    var skin := skin_palette[rng.randi_range(0, skin_palette.size()-1)]
    var hair := hair_palette[rng.randi_range(0, hair_palette.size()-1)]
    var shirt := shirt_palette[rng.randi_range(0, shirt_palette.size()-1)]

    # Fundo em faixas suaves
    for y in range(size):
        var t := float(y) / float(size)
        var c := Color(0.07 + 0.04*t, 0.10 + 0.05*t, 0.16 + 0.08*t, 1.0)
        for x in range(size):
            img.set_pixel(x,y,c)

    var cx := size/2
    var head_r := int(size*0.27)
    var cy := int(size*0.39)

    # Ombros/corpo
    for y in range(int(size*0.62), size):
        var half := int(size*0.36 * sqrt(max(0.0, 1.0 - pow((float(y)-size*0.62)/(size*0.38),2))))
        for x in range(max(0,cx-half), min(size,cx+half)):
            img.set_pixel(x,y,shirt)

    # Pescoço
    for y in range(cy+head_r-8, cy+head_r+40):
        for x in range(cx-35,cx+36):
            if x>=0 and x<size and y>=0 and y<size:
                img.set_pixel(x,y,skin)

    # Cabeça
    for y in range(cy-head_r, cy+head_r+1):
        for x in range(cx-head_r, cx+head_r+1):
            var dx := x-cx
            var dy := y-cy
            if dx*dx + dy*dy <= head_r*head_r:
                img.set_pixel(x,y,skin)

    # Cabelo
    var hairline := cy-head_r+12
    for y in range(cy-head_r, cy-int(head_r*0.35)):
        var width := int(sqrt(max(0.0, head_r*head_r - pow(float(y-cy),2))))
        for x in range(max(0,cx-width), min(size,cx+width)):
            if rng.randf() > 0.04:
                img.set_pixel(x,y,hair)

    # Olhos
    var eye_y := cy-8
    for ex in [cx-43,cx+43]:
        for y in range(eye_y-5,eye_y+6):
            for x in range(ex-5,ex+6):
                if x>=0 and x<size and y>=0 and y<size:
                    img.set_pixel(x,y,Color.WHITE)
        for y in range(eye_y-2,eye_y+3):
            for x in range(ex-2,ex+3):
                if x>=0 and x<size and y>=0 and y<size:
                    img.set_pixel(x,y,Color("18202b"))

    # Nariz e boca
    for y in range(cy+2,cy+28):
        for x in range(cx-2,cx+3):
            if x>=0 and x<size and y>=0 and y<size:
                img.set_pixel(x,y,Color(0.72,0.42,0.31,1))
    for x in range(cx-22,cx+23):
        y := cy+55
        if y>=0 and y<size:
            img.set_pixel(x,y,Color("7a3035"))

    return img

static func save_portrait(seed: int, id: String, size: int = 256) -> String:
    var dir := "user://portraits"
    DirAccess.make_dir_recursive_absolute(dir)
    var path := dir + "/" + id + ".png"
    var img := generate_portrait(seed,size)
    img.save_png(path)
    return path

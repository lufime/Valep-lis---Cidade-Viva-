Valepólis V0.3.0 — Remodelação Fase 4
Alteração focada na largura nominal das vias locais, passeios e ligações entre bairros. Consultar RELATORIO_REMODELACAO_FASE4.md para limitações e testes pendentes. Não é uma APK testada.

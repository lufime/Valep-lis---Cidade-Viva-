# Correção PRE-FLIGHT — catálogo salarial e modelo fiscal

- Corrigida a condição que reprovava o projeto por `salary_baseline_proposed` e `tax_model` serem nulos no objeto legado `economy`.
- O PRE-FLIGHT passa agora a verificar diretamente `data/salary_by_profession_proposal_v030.json`: estado de referência aprovado, 800 profissões, IDs únicos e salário bruto mensal proposto numérico em cada registo.
- Verifica separadamente `data/economy_config.json` e os campos do modelo fiscal.
- Não altera os salários nem converte valores de proposta em salários finais; os registos têm `Salario_status` próprio e isso é preservado.
- Não desbloqueia transações, receitas, despesas, preços, stocks, saldo ou orçamento pendentes.

## Validação executada
- JSON salarial: 800 registos, IDs únicos, 800 valores numéricos positivos presentes.
- Modelo fiscal: campos principais presentes.
- Sintaxe Python do auditor: compilada com `py_compile`.
- Godot/APK: não executados neste ambiente; requerem workflow GitHub Actions.

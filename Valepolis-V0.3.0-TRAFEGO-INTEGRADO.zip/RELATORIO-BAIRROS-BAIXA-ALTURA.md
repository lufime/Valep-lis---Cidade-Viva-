# Bairros de baixa altura — Valepólis V0.3.0

## Alterações

- `data/architectural_identity_v030.json`: adicionada a propriedade `low_rise_1_2_floor_ratio` por bairro.
- `systems/city_3d.gd`: geração determinística de edifícios de 1 ou 2 pisos segundo a proporção do perfil; os restantes edifícios elegíveis têm pelo menos 3 pisos.
- Nexora, Altavira, Ventúria e Altória mantêm perfis predominantemente verticais; a regra dos 15 pisos da zona central continua dependente da definição do polígono central.
- Áreas e densidades continuam a ser propostas de planeamento, não polígonos GIS confirmados. Não foram inventadas novas fronteiras, culturas ou coordenadas.

## Proporção de edifícios de 1–2 pisos

| Bairro | Proporção-alvo | Justificação tipológica
|---|---:|---|
| Montélia | 78% | encostas e habitação de baixa densidade |
| Florávia | 72% | tecido residencial verde |
| Brisamar | 68% | zonas costeiras/residenciais de baixa altura |
| Silvéria | 58% | tecido residencial e verde |
| Lacéria | 52% | zonas lacustres/residenciais |
| Olivéria | 78% | baixa densidade e espaços verdes |
| Avelora | 68% | habitação de baixa altura |
| Terrávia | 60% | tecido residencial de baixa/média densidade |
| Marivora | 68% | tecido costeiro/residencial |
| Verdelis | 82% | bairro verde e de baixa densidade |
| Pedravora | 82% | transição montanhosa |
| Marévia | 48% | mistura costeira com edifícios médios |
| Portávia | 38% | mistura de frente urbana e habitação |
| Estúria | 38% | tecido misto |
| Rivéria | 30% | frente fluvial com mistura de alturas |
| Valeora | 32% | tecido misto |
| Pedrália | 28% | mistura residencial e edifícios médios |
| Fontélia | 32% | tecido misto |
| Ribeora | 28% | frente fluvial mista |
| Solária | 24% | tecido urbano misto |
| Lúmora | 20% | transição para zonas mais densas |
| Nexora, Altavira, Ventúria, Altória | 0% | perfis verticais mantidos |

As proporções são parâmetros técnicos propostos para a geração, não uma decisão urbanística oficial.

## Validação

- JSON de perfis: validado sintaticamente.
- Integridade ZIP: validada após criação.
- Não foi possível executar Godot 4.5, testar o mapa em runtime nem exportar APK neste ambiente. O PRE-FLIGHT de runtime continua obrigatório.

# Valepólis V0.3.0 — Sinalização provisória de empresas no mapa 3D

## Alteração
- Para cada empresa cuja morada candidata coincide exatamente com o `address_id` de um edifício existente e cujo bairro também coincide, o mapa grava os metadados da empresa e cria uma etiqueta 3D com o prefixo `CANDIDATA`.
- A etiqueta não declara que o edifício é comercial, que a empresa está aberta ou que a localização física foi aprovada.
- Empresas sem correspondência exata continuam pendentes. Não são criados edifícios, coordenadas, trabalhadores, empregos ou moradas adicionais.

## Controlos estáticos
- Verificar JSON do catálogo e unicidade de IDs.
- Verificar que cada `proposed_address_candidate_id` existe no registo de endereços e que o bairro coincide.
- Verificar que o código só cria etiqueta depois da correspondência exata por morada e bairro.
- Verificar que a etiqueta usa o prefixo `CANDIDATA` e o estado de aprovação física permanece pendente.
- Verificar integridade do ZIP.

## Limitações
- Não foi possível executar Godot neste ambiente. Parsing GDScript pelo motor, apresentação visual em runtime e exportação APK não foram testados.
- A etiqueta 3D é uma ajuda de auditoria visual, não valida por si só uso comercial, acesso pedonal/rodoviário, capacidade ou aprovação de implantação.

# Valepólis V0.3.0 — Remodelação Fase 13

Corrigida a inicialização da posição dos veículos: a posição horizontal inicial e a altura do terreno passam agora a ser calculadas a partir do mesmo primeiro waypoint do percurso. Isto elimina a discrepância entre a altura calculada numa posição provisória e a posição efetiva do veículo.

## Limites

- Verificação estática do código apenas.
- Godot não está instalado neste ambiente; não foi possível executar a cena, validar a circulação visual ou compilar a APK.
- Os percursos continuam locais e não constituem ainda prova de navegação global pelas duas pontes.

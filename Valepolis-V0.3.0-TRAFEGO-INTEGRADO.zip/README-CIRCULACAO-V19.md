# Valepólis V0.3.0 — Circulação V19 corrigida

Base: Circulação V18.

## Correção aplicada
- Corrigida a declaração de `next_target_index` em `systems/city_3d.gd`: acrescentado `var`, exigido pela sintaxe GDScript. O log V18 reportava `Expected end of statement after expression, found ":"` na linha 1586.

## Validação
- O conteúdo do ZIP foi preservado, exceto pela correção acima e este README.
- Integridade do arquivo ZIP deve ser verificada após criação.
- Não foi possível executar Godot nesta etapa; a compilação e os testes funcionais precisam ser repetidos no GitHub Actions.

# Valepólis V0.3.0 — FASES 01–22 + infraestrutura V4

Baseado na consolidação V3. Acrescenta linhas de paragem e semáforos visuais em cruzamentos selecionados. Preserva os restantes ficheiros.

IMPORTANTE: os semáforos são apenas objetos visuais com lentes coloridas fixas; não mudam de estado e não controlam trânsito. As linhas de paragem também não acionam travagem. Não é um sistema funcional de controlo de tráfego.

Verificação: integridade do ZIP. Não executado no Godot; compilação, posicionamento, colisões e desempenho por validar.

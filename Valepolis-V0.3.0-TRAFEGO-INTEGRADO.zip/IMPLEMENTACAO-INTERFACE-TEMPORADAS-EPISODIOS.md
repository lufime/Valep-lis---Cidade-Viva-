# Valepólis V0.3.0 — Interface de temporadas e episódios

## Implementação

- O menu principal passa a incluir o acesso **TEMPORADAS E EPISÓDIOS**.
- O ecrã apresenta as 20 temporadas em cartões responsivos: duas colunas em ecrã vertical e quatro em paisagem.
- Ao escolher uma temporada, apresenta os seus dez episódios com número, título e estado de interface.
- O painel de detalhe destaca o episódio selecionado.
- A confirmação guarda o ponto narrativo selecionado no estado de progressão do runtime e no ficheiro de gravação.
- A seleção narrativa é persistida através de `narrative_season`, `narrative_episode` e `narrative_selection_confirmed`; a lista de episódios concluídos fica reservada ao registo de conclusões reais.
- A interface usa o catálogo existente `data/episodes_200.json`, sem alterar os títulos aprovados nem inventar sinopses, objetivos ou condições de conclusão.
- A interface usa ScrollContainer do menu existente e alvos de toque grandes para Android.

## Limite funcional explícito

Esta implementação fornece navegação e seleção persistente das temporadas/episódios. Não declara que os objetivos narrativos dos 200 episódios estejam implementados: o catálogo contém títulos e duração variável, mas não especifica objetivos e condições de conclusão para cada episódio. Por isso, o ecrã não marca episódios como concluídos automaticamente.

## Verificações executadas

- Validador dos módulos: `PASS_STATIC` — 20 módulos, 200 episódios únicos, 10 por temporada e hashes dos módulos confirmados.
- A alteração GDScript não foi executada no Godot nesta sessão; a compilação/importação e o teste visual Android permanecem por validar no workflow.

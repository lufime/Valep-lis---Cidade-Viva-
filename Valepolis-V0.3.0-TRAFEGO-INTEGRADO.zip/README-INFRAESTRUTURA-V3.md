# Valepólis V0.3.0 — FASES 01–22 + infraestrutura V3

Base: `Valepolis-V0.3.0-CONSOLIDADO-FASES01-22-INFRAESTRUTURA.zip`.

A V3 acrescenta painéis azuis simplificados de sinalização de passadeira, com figura branca, nos dois lados de cada passadeira existente. Preserva o restante conteúdo do pacote-base e altera `systems/city_3d.gd`.

Os sinais são visuais, sem lógica de cedência ou semáforos. O pacote não foi executado no Godot. ZIP testado quanto à integridade; compilação, posição, colisões e desempenho não confirmados.

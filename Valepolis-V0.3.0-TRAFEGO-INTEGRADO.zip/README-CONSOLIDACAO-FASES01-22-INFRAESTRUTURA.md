# Valepólis V0.3.0 — Consolidado Fases 01–22 + infraestrutura visual

Este pacote parte do arquivo consolidado `Valepolis-V0.3.0-CONSOLIDADO-FASES15-22.zip`, que já continha o projeto e alterações anteriores, e integra a melhoria de infraestrutura visual V2.

Alteração de código feita nesta consolidação: `systems/city_3d.gd`.
Inclui passeios/bermas e drenagem visual nas estradas multilane, passadeiras visuais em cruzamentos selecionados, painéis de orientação simples, linhas de bordo e postes/luminárias visuais.

Não foram alterados os restantes ficheiros da base. As passadeiras e sinais não constituem um sistema funcional de semáforos ou cedência. Não se afirma que as Fases 01–22 foram novamente auditadas individualmente nesta execução: a consolidação herda o pacote-base identificado acima.

Verificação: integridade do ZIP de saída. Godot não foi executado; compilação, colisões, navegação física, alinhamento e desempenho continuam por validar.

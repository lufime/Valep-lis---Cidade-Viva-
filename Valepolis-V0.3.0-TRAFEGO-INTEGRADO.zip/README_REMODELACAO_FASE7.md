# Valepólis V0.3.0 — Remodelação Fase 7

Esta fase ajusta a distribuição interna dos edifícios nos núcleos de bairro, mantendo os identificadores e a lista oficial dos 25 bairros.

- Praças-base aumentadas de 18 × 18 para 22 × 22 unidades.
- Raio de colocação dos edifícios aumentado para reduzir a concentração junto ao centro do quarteirão.
- Margem de segurança usada pelo gerador de edifícios aumentada de 2,8 para 3,2 unidades em relação aos corredores rodoviários.
- Nenhum bairro, endereço, ponte ou sistema de jogo foi removido deliberadamente.

## Limitações e validação
A alteração é localizada e não representa uma reconstrução completa do mapa. Como a rede usa coordenadas fixas e os corredores são aproximados, é necessária inspeção no Godot 4.5 para confirmar que os edifícios não invadem estradas e que não surgem sobreposições entre bairros. Godot não estava disponível neste ambiente; não foi feita execução de runtime nem exportação/teste de APK. O workflow `.github/workflows/build.yml` foi preservado sem alterações.

# Valepólis V0.3.0 — Remodelação Fase 3

Base: projeto da Remodelação Fase 2.

Esta fase amplia a escala do mapa e corrige a escala dos percursos de veículos/peões e a consulta de altura do terreno. Ver `RELATORIO_REMODELACAO_FASE3.md` para os testes executados e as limitações.

Não foi executado Godot 4.5 nem exportada uma APK nesta fase.

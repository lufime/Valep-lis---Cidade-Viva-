# Correção da auditoria salarial/fiscal — Valepólis V0.3.0

## Causa
O PRE-FLIGHT tinha uma regra antiga que exigia simultaneamente `salary_baseline_proposed` e `tax_model` nulos. Isso contradizia os dados atuais: o catálogo de referência tem 800 profissões e o modelo fiscal contém as regras aprovadas, embora os valores operacionais continuem pendentes.

## Alterações
- `tools/preflight_project.py`: valida o catálogo de referência (800 registos, IDs únicos, salário bruto proposto presente) e o modelo fiscal com estado `approved_rules_values_pending`.
- `tools/preflight.py`: aplica a mesma validação para não voltar a falhar na auditoria geral.
- Não foram alterados salários, taxas, estado de ativação económica ou dados dos bairros.

## Verificação local
- `python -m py_compile tools/preflight_project.py tools/preflight.py`: passou.
- `python tools/preflight_project.py`: `PROJECT_AUDIT=PASS|passes=44|failures=0`.
- Não foi possível confirmar compilação Godot, exportação APK ou execução completa do workflow neste ambiente.

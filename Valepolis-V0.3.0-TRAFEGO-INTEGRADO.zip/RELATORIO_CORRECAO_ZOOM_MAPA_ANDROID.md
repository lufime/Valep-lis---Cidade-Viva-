# Relatório — correção do zoom e do tamanho do mapa

## Causa identificada
O nó `UI/Map/MapBody/Map3D` estava fixo em `660x668` na cena `Main.tscn`. Em ecrãs verticais, o painel pai aumentava, mas o SubViewportContainer continuava pequeno no canto superior esquerdo, deixando uma grande área verde vazia. Os botões também estavam identificados como níveis `1` e `2`, em vez de zoom `+` e `−`.

## Correções aplicadas
- `Map3D` passa a ocupar toda a área útil de `MapBody`, com âncoras de expansão.
- A rotina de sincronização ajusta o container ao tamanho real do painel e redimensiona o SubViewport.
- Botões táteis `+`, `−`, `◎` e `⌂` passam a chamar zoom-in, zoom-out, centrar e vista geral.
- Mantidos os limites de zoom e a pinça de dois dedos existentes.
- O mapa continua recortado dentro do painel; o zoom altera a câmara 3D, não a escala da interface.

## Validação
Foi feita inspeção estática das alterações e da cena. Não foi possível executar Godot nem compilar/testar APK neste ambiente; o funcionamento visual no dispositivo ainda precisa de ser confirmado no PRE-FLIGHT/Android.

# Valepólis V0.3.0 — implementação global (13-10-2026)

## Alterações aplicadas neste pacote

- Corrigida a ordem de configuração do `SubViewport`: `UPDATE_ALWAYS`, fundo e container são configurados antes de verificar se `ValepolisCity3D` já existe. Isto elimina o retorno antecipado que podia deixar um viewport preexistente sem atualização contínua.
- A câmara da cidade é ativada explicitamente para a cidade já existente ou recém-instanciada.
- O teste funcional verifica o modo de atualização, existência do container e da cidade, câmara ativa, visibilidade do container e dimensões do viewport. Não declara renderização visual aprovada só com verificações de nós.
- Adicionados quatro controlos de nível de detalhe (1–4) ligados à API do mapa e posicionados numa faixa horizontal separada dos controlos de zoom.
- Registada a aprovação global das propostas documentadas pendentes, sem substituir regras anteriores nem inventar efetivos, instalações ou dados económicos.
- Criados 20 módulos JSON de temporada, manifesto com SHA-256 e validador. O catálogo integral de 200 episódios foi preservado.

## Verificações executadas

- PRE-FLIGHT estático: **26 PASS, 0 FAIL**.
- Auditoria de regras: **32 PASS, 0 FAIL**.
- Auditoria do projeto: **44 PASS, 0 FAIL**.
- Auditoria de instalações: **26 PASS, 0 FAIL**.
- Auditoria estrutural da rede regional: **PASS_STATIC_ONLY**.
- JSON do projeto: **104 ficheiros válidos**.
- Módulos narrativos: **20 temporadas, 200 episódios únicos, 10 por temporada; SHA-256 confirmado**.

## Divergência documental/estrutural identificada e não inventada

`tools/validate_master_registry.py` falha em `master_company_count_matches`: o registo de empresas contém 41 correspondências no catálogo mestre, enquanto a auditoria identifica 50 empresas propostas. Os outros oito controlos deste teste passaram. Não foram inventadas nove empresas nem alterados os dados para forçar PASS; esta divergência fica para reconciliação com a fonte oficial das empresas.

## Limites de validação

- Não foi possível executar Godot 4.5 neste ambiente. O teste funcional alterado ainda precisa de ser executado no GitHub Actions.
- A renderização visual em Android, a circulação física das estradas e a APK não foram validadas nesta sessão.
- Os títulos e a duração variável dos 200 episódios não demonstram que todos os episódios tenham objetivos e condições de conclusão jogáveis implementados.
- Os módulos são unidades de empacotamento offline e auditoria; **o download/instalação dinâmica Android não está implementado**.


## Revisão adicional após o relatório CI de 13-10-2026

O relatório recebido testou o artefacto `Valepolis-V0.3.0-IMPLEMENTACAO-APROVACAO-GLOBAL.zip`, e registou `MAP_RENDER_FAIL` no teste funcional. Nesta revisão:

- `main.gd`: a rotina de sincronização do tamanho do viewport volta a impor `SubViewport.UPDATE_ALWAYS`, além da configuração inicial do mapa.
- `tools/preflight_functional.gd`: o teste aguarda seis frames para permitir a conclusão da configuração diferida de arranque; em caso de falha, regista o modo de atualização atual e o esperado.
- A verificação não foi removida nem convertida em PASS artificial. Se a configuração continuar errada, o PRE-FLIGHT continua a falhar.

Esta revisão foi validada por inspeção e verificações estáticas do pacote. O Godot 4.5 não está instalado neste ambiente; a execução CI posterior é necessária para confirmar o resultado funcional. A APK não é declarada concluída.

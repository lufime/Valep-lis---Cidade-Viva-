# Valepólis V0.3.0 — correção de visibilidade dos bairros

## Correção aplicada
- As etiquetas dos 25 bairros deixam de ser ocultadas nos níveis de detalhe 3 e 4.
- Cada etiqueta territorial é criada e agrupada explicitamente, sem depender da última etiqueta criada por outros sistemas.
- Aumentado o tamanho e o contraste das etiquetas para melhorar a leitura sobre a vista 3D.
- Preservadas as coordenadas X/Z, os nomes oficiais, a geografia e a distribuição dos bairros.

## Limitação de validação
Foi verificada a estrutura do ZIP e a presença das 25 identidades no código e nos dados. Esta correção ainda precisa de ser executada no Godot e verificada numa APK Android; não declarar validação runtime até isso acontecer.

# Valepólis V0.3.0 — Remodelação Fase 2

Esta entrega aplica expansão uniforme de 25% ao cenário 3D e recalibra a câmara/personagem para a nova escala. Consulte `RELATORIO_REMODELACAO_FASE2.md` para os limites de validação. Não considerar a circulação funcional ou a APK como testadas: requer execução no Godot 4.5.

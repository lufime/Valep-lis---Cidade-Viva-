# Valepólis V0.3.0 — Remodelação Fase 2

## Alterações de código
- Aplicada expansão uniforme de 25% aos nós 3D criados pela construção do mundo, incluindo terreno, bairros, edifícios, estradas, água e pontes. O objetivo é aumentar a escala visual e a área útil aparente sem mudar os nomes oficiais dos 25 bairros nem os identificadores do grafo de rotas.
- Ajustada a distância inicial da câmara para 135 unidades e o campo de visão para 66 graus, com limites de zoom ampliados para manter a cidade explorável após a expansão.
- Ajustada a posição inicial da personagem à nova escala do mundo.
- Mantidos os ficheiros do projeto, os dados territoriais, o registo de empresas, as duas pontes e o workflow existente.

## Validação executada
- Verificação de sintaxe textual/âncoras do patch: concluída.
- Verificação de que o fator de expansão, os limites de câmara e a posição inicial estão presentes: concluída.
- Integridade do ZIP: verificada após empacotamento.

## Limitações
- Godot 4.5 não está disponível neste ambiente; não foi executada importação nem renderização real.
- Não há confirmação de que todos os corredores continuem livres após a expansão, porque a geometria foi escalada uniformemente e não reconstruída individualmente.
- Não foram validados circulação de carros, colisões, caminhos navegáveis, FPS ou APK Android.
- Esta fase amplia a escala do cenário; não substitui uma remodelação artística individual de edifícios, relevo ou desenho de cada rua.

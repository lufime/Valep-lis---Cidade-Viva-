# Implementação — Atlas dos 25 mapas individuais

Projeto base: Valepólis V0.3.0 — território com áreas exteriores separadas.

## Alterações
- O painel 2D foi convertido num atlas rolável com 25 cartões individuais.
- Cada cartão mostra o número/nome do bairro, área calculada a partir do polígono, população e botão `ABRIR MAPA 3D`.
- Selecionar um cartão reutiliza `focus_neighborhood()` da cena 3D existente, atualiza o bairro atual e fecha o atlas.
- O atlas lê `data/limites_bairros_v030.json`; os dados territoriais não são duplicados nem inventados.
- Mantém-se o fluxo 3D existente e não são alterados os dados populacionais oficiais.

## Limitações de validação
- Os previews dentro dos cartões são esquemáticos; o botão abre a cena 3D existente para a vista real do bairro.
- Não foi possível executar o Godot 4.5 neste ambiente; falta validar o GDScript, o layout em telemóvel e a exportação APK.
- As áreas dos polígonos continuam a ser geometria virtual calculada, não levantamento geográfico real.

# Valepólis V0.3.0 — Remodelação Fase 8

## Alterações
- Aumentado o conjunto visual de veículos de 2 para 4 por bairro (até 100 veículos gerados para os 25 bairros).
- Distribuição dos veículos por ambos os lados dos corredores viários locais.
- Índices de tráfego estabilizados por bairro/veículo para distribuir melhor a seleção horária.
- A densidade horária mantém o comportamento existente, mas o mínimo de veículos visíveis foi aumentado para reduzir bairros sem carros.

## Limitações da validação
Foi feita verificação estática do código e integridade do ZIP. Godot não está instalado neste ambiente; portanto, não foi possível executar a cena, confirmar visualmente os carros, validar colisões ou compilar APK. O movimento continua a ser um percurso local demonstrativo, não pathfinding rodoviário global.

# Correção estrutural da escala do mapa — Valepólis V0.3.0

## Causa encontrada
O gerador aplicava `WORLD_EXPANSION_FACTOR = 1.45` às posições **e à escala dos nós 3D**. Isto aumentava todos os meshes, incluindo edifícios, pavimentos, passeios e estradas, apesar das alterações anteriores dizerem que os reduziam.

## Alterações
- Retirado o aumento artificial de escala global; fator de coordenadas passa a 1.0 para alinhar terreno, rede viária, edifícios e agentes na mesma unidade.
- Alturas visuais dos edifícios reduzidas em 32%.
- Pegadas dos edifícios reduzidas e limitadas a um mínimo mais pequeno.
- Ruas locais reduzidas de 2,45 m para 1,75 m de largura e encurtadas para 18 m.
- Passeios locais mais estreitos.
- Avenidas urbanas reduzidas para 70% da largura declarada; autoestradas para 82%, preservando hierarquia.
- Praças de bairro reduzidas de 18×18 m para 12,5×12,5 m.

## Limites de validação
Verificada a edição textual e a integridade do ZIP. Não foi possível executar o Godot neste ambiente; o resultado visual e a APK ainda precisam de validação em runtime. Esta alteração não declara o mapa como aprovado.

# Valepólis V0.3.0 — melhoria integrada do mapa e personagem 3D

## Alterações nesta revisão
- Edifícios do mapa recebem coberturas/cornijas e detalhes de janelas gerados proceduralmente, mantendo o perfil arquitetónico e a contagem de edifícios por bairro.
- Rótulos dos bairros passam a usar a altura do terreno como referência.
- Câmara inicial mais afastada e com ângulo mais alto para enquadrar melhor a cidade no ecrã móvel.
- A instância 3D do jogador recebe uma identidade atualizável através de `set_player_identity(nome, profissão)`.
- A etiqueta 3D do jogador acompanha o modelo quando este se desloca.
- O `main.gd` sincroniza o nome e profissão persistentes com o mundo 3D ao atualizar a interface.
- Não foi inventada uma distribuição cultural para os 16 bairros; preservam-se os 25 nomes oficiais e os dados territoriais existentes.

## Validação
- `tools/preflight_project.py`: PASS, 40 verificações estáticas, 0 falhas.
- Godot runtime, renderização Android, APK e controlos táteis: não executados neste ambiente; requerem teste no runner Godot/Android.

## Limitações conhecidas
- O modelo procedural continua a usar primitivas 3D e não é um personagem humano de alta fidelidade com esqueleto/roupa detalhada.
- Os detalhes de fachada são procedurais e não substituem modelos arquitetónicos artísticos específicos.
- O movimento tátil da personagem não foi implementado nesta revisão.

# Valepólis V0.3.0 — Remodelação Fase 6

## Alteração aplicada
- Aumentado o tamanho e o contorno dos rótulos 3D.
- Os rótulos usam billboard e `no_depth_test` para continuarem legíveis na vista geral.
- Os nomes dos 25 bairros passam a ser apresentados em maiúsculas e a uma altura superior aos quarteirões.
- A alteração é visual: não muda coordenadas dos bairros, moradas, rede rodoviária, pontes ou regras do jogo.

## Validação
- Comparação textual dos blocos alterados: realizada.
- Integridade do ZIP: verificada após empacotamento.
- Execução no Godot 4.5: não realizada (executável não disponível neste ambiente).
- APK Android: não exportada nem testada.
- Workflow `.github/workflows/build.yml`: preservado, não alterado.

## Limites
Esta fase melhora a identificação visual dos bairros, mas não constitui a remodelação completa de edifícios, relevo ou estradas e não prova que o trânsito funciona em execução.

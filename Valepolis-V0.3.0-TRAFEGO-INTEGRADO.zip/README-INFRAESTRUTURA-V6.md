# Valepólis V0.3.0 — Infraestrutura V6

Continua a partir do pacote V5 e preserva os restantes ficheiros. Em segmentos longos identificados pelo nome como `Autoestrada`, acrescenta guardas metálicas visuais nos dois lados, com postes de suporte, mantendo os balizadores existentes.

Limitação importante: as guardas são objetos de cenário e não devem ser consideradas barreiras físicas funcionais; colisão, geometria junto a curvas e relevo, desempenho e compilação precisam de validação no Godot. O ZIP foi verificado quanto à integridade, mas o projeto não foi executado.

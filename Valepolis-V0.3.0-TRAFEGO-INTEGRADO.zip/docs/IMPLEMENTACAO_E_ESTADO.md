# Valepólis V0.3.0 — Núcleo Cidade Viva

Este pacote é a próxima camada de implementação/configuração dos sistemas que faltavam:
economia, trabalho, trânsito, meteorologia, ocorrências, danos/manutenção, construção,
progressão e contratos de entidades/pessoas.

## O que foi feito aqui
- contratos de dados concretos;
- configurações data-driven;
- catálogo de ocorrências;
- estados de manutenção;
- ciclo de emprego;
- mobilidade;
- meteorologia;
- construção;
- progressão;
- registry de estados.

## O que NÃO foi alegado
O Godot não foi executado neste ambiente. Portanto estes sistemas não são marcados como
runtime-testados. O código existente `main.gd` foi preservado como fonte de integração e não
foi reescrito às cegas.

## Próxima validação real
1. integrar os registries no projeto;
2. abrir no Godot;
3. corrigir erros de importação;
4. executar a cena;
5. testar cada contrato;
6. exportar Android;
7. medir FPS/RAM/tempo de carregamento.

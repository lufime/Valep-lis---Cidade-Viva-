# Valepólis 3D Studio — geração nativa Godot

A geração de recursos 3D passa a ser executada diretamente no Godot, sem instalar ferramentas externas no workflow. A biblioteca inicial cria cenas `.tscn` de personagens modulares e edifícios através de primitivas e materiais nativos.

## Estado

- Relevo procedural: addon `valepolis_terrain`.
- Personagens procedurais: addon `valepolis_3d_studio`.
- Edifícios modulares: gerados por `asset_generator.gd`.
- Exportação: cenas nativas `.tscn`, prontas para carregar no Godot.
- Validação de runtime, rigging completo, animações avançadas e qualidade visual final: ainda precisam de testes reais no Godot e Android.

O workflow não instala nem executa modeladores 3D externos.

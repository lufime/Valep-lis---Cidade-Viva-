# Consolidação temporal e narrativa — V0.3.0

A simulação e os recursos 3D devem ser gerados e validados pelo projeto Godot. O addon `valepolis_terrain` trata do relevo procedural; `valepolis_3d_studio` gera personagens e edifícios modulares.

A validação em runtime e em Android continua a ser obrigatória antes de considerar a versão pronta para lançamento.

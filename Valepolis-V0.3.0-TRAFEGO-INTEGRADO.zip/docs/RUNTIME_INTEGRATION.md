# V0.3.0 — Integração Runtime

Foi adicionada uma ponte runtime `ValepolisSystemsRuntime`.

Adicionar como Autoload no Godot:
`res://systems/valepolis_systems_runtime.gd`
Nome sugerido: `ValepolisSystems`

Chamadas principais:
- `ValepolisSystems.initialize()`
- `ValepolisSystems.tick(1)`
- `ValepolisSystems.set_paused(true/false)`
- `ValepolisSystems.create_incident(...)`
- `ValepolisSystems.add_transaction(...)`

Também existe `ValepolisSystemsSelfTest` para validação no Godot.

# Licenças e direitos — Valepólis V0.3.0

Os recursos procedurais descritos nesta versão são gerados pelo código próprio do projeto através do Godot. As texturas e ícones incluídos devem manter as respetivas condições de licença e atribuição.

O pipeline de produção 3D do workflow usa ferramentas e recursos nativos do Godot; não instala nem executa ferramentas externas de modelação 3D.

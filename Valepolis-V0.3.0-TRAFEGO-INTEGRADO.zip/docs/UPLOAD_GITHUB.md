# Preparar e carregar o projeto no GitHub

Este ZIP tem os ficheiros do projeto diretamente na raiz, incluindo `project.godot`; não é necessário entrar numa subpasta depois de extrair.

## Opção recomendada — carregar o projeto completo

1. Extrair o ZIP no dispositivo.
2. Abrir o repositório `lufime/Quando-Toca-a-Sirene`.
3. Confirmar que estás na branch pretendida (`main`, salvo decisão diferente).
4. Carregar os ficheiros/pastas do projeto para a raiz do repositório, mantendo a estrutura e os nomes.
5. Rever a lista de alterações antes de confirmar o commit.
6. Abrir **Actions** e executar o workflow **Quando Toca a Sirene — V0.3.0 Android Preview**.
7. Verificar o relatório e os logs antes de considerar o APK válido.

## Atenção

- Não carregar uma pasta ZIP dentro do repositório como substituto dos ficheiros-fonte: o GitHub Actions não executará o projeto dentro de um ZIP.
- Não substituir a raiz do projeto por uma pasta interior; `project.godot`, `Main.tscn`, `main.gd` e `export_presets.cfg` devem ficar na raiz.
- Não carregar APKs, caches `.godot/`, keystores pessoais, passwords ou tokens.
- O ficheiro `docs/workflows/build-alternativo-nao-ativo.yml` é apenas uma cópia documental de um workflow alternativo; não é um workflow ativo. O workflow ativo está em `.github/workflows/build.yml`.
- Este pacote foi organizado para upload; a compilação/runtime/APK ainda precisam de confirmação real pelo Actions.

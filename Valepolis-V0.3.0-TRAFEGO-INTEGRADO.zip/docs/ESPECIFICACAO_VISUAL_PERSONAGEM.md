# Especificação visual das personagens — Valepólis V0.3.0

## Objetivo

Gerar automaticamente personagens fictícias no Godot, com variação determinística de aparência, corpo modular e cores de uniforme específicas por entidade.

## Base técnica atual

O addon `addons/valepolis_3d_studio/` gera personagens 3D a partir de malhas primitivas nativas. A primeira versão é uma base funcional para testar geração e integração.

## Evolução planeada

- aumentar variedade de rostos, cabelo, proporções e acessórios;
- acrescentar roupa modular e materiais por profissão;
- implementar esqueleto, rigging e animações;
- validar qualidade e desempenho em Android;
- garantir identidades únicas e compatibilidade com o sistema de profissões/entidades.

A qualidade artística final e o desempenho ainda precisam de validação no Godot e num dispositivo Android.

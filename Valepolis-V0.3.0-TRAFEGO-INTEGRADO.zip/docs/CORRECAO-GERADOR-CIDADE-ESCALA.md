# Correção estrutural de escala — Valepólis V0.3.0

## Alterações aplicadas ao código
- Substituída a colocação radial dispersa dos edifícios por lotes em grelha compacta por bairro.
- O gerador usa os 14 edifícios previstos nos perfis (com margem até 18), em vez de limitar cada núcleo a 8–12.
- Reduzida a praça/pavimento-base de cada núcleo de 12,5 × 12,5 para 8,5 × 8,5 unidades.
- Reduzida a largura efetiva das avenidas e autoestradas, bem como a largura dos passeios/bermas.
- Reduzidas as folgas usadas para excluir edifícios de corredores viários, que estavam a eliminar muitos lotes.
- Reduzido o tamanho das etiquetas 3D dos bairros (76 para 34, contorno 24 para 8, pixel size 0,012 para 0,006).
- Preservados os 25 nomes, as coordenadas POSITIONS, os perfis arquitetónicos e o limite de 30 pisos já definido nos dados.

## Validação
- ZIP de origem aberto e reempacotado; integridade ZIP validada.
- Verificados programaticamente os 25 bairros e os 25 centros territoriais.
- Verificada a presença das alterações acima no `systems/city_3d.gd`.
- **Não foi possível executar Godot nesta sessão**; não se afirma que a renderização Android esteja aprovada. O próximo PRE-FLIGHT deve compilar/importar e capturar uma imagem para avaliar a escala real.

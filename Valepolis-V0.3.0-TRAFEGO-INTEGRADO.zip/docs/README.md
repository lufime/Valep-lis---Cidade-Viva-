# Documentação do projeto

- `reports/`: relatórios de integração, validação e preflight.
- `audits/`: auditorias e registos de consolidação.
- `specifications/`: regras aprovadas e documentação funcional.
- `manifests/`: manifestos de integração, recursos e geradores.
- `workflows/`: notas de workflows e processos.

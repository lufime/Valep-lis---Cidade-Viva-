# Integração de instalações — Valepólis V0.3.0

**Estado:** proposta não oficial; catálogo, IDs, moradas de referência e leitor runtime preparados. Godot/Android não executados neste ambiente.

## Resultado
- 275 registos físicos propostos com IDs únicos e moradas de referência provisórias.
- 225 instalações construídas/centros/estabelecimentos + 50 parques/jardins públicos.
- Distribuição inicial pelos 25 bairros: 11 a 11 registos por bairro.
- 10 centros TNUR integrados em bases BRIGADA; 0 instalações TNUR independentes.
- 5 unidades policiais especializadas alojadas em instalações policiais existentes; 0 locais adicionais.
- `building_id` permanece `null` e `map_spawned` é `false`; não foram criados edifícios no mapa 3D.
- Campos de efetivos, equipas, viaturas, inventário, economia, orçamento, saldo, capacidade, horário e departamentos deixados por definir.
- Leitor runtime `ValepolisInstallations`: pesquisa por ID, entidade e bairro; validação estrutural; overrides futuros explicitamente configurados guardados em `user://`.
- A secção Instalações foi ligada à navegação de entidade. O mapa é ocultado enquanto a página central está ativa; a navegação permanece visível e não foi criado botão de fechar.
- Valores numéricos de salários e modelo fiscal removidos de `data/economy_config.json` para respeitar a decisão de deixar a economia por definir.

## Limitações
- A distribuição pelos bairros é equilibrada para planeamento, não otimizada por geografia, procura ou tempos de resposta.
- Moradas únicas são referências de planeamento; não provam que existam edifícios reais nesse endereço.
- As propostas não criam instalações físicas no mapa.
- A execução Godot, a renderização, os controlos por toque e a exportação APK continuam por verificar porque o executável Godot não está disponível neste ambiente.

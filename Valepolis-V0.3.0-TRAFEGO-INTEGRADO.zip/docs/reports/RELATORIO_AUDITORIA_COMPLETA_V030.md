# Quando Toca a Sirene — Valepólis V0.3.0
## Relatório de auditoria e integração

**Estado:** auditoria estática aprovada; validação real no Godot e geração da APK ainda pendentes.

## Trabalho executado

1. **Projeto e preflight**
   - Corrigido o workflow para criar a pasta `build` antes de escrever relatórios.
   - O workflow localiza explicitamente o `sdkmanager`, instala os componentes Android pedidos e verifica a assinatura da APK.
   - A compilação do workflow está identificada como **pré-visualização** e usa uma chave temporária, não uma assinatura de distribuição.
   - Adicionado `tools/preflight_project.py` para cruzar recursos, versões, dados populacionais, economia, episódios, instalações e regras de entidades.

2. **População e nomes**
   - A amostra detalhada é agora preparada para **200 agentes individuais**, com IDs únicos, nomes fictícios gerados e rotinas abstratas dependentes da hora/dia.
   - A população de referência continua em **1.000.000**. A configuração populacional e o mapa usam os mesmos 25 bairros, com quota de 4% (40.000 habitantes de referência) por bairro.
   - Atualizada a base documental de nomes para fragmentos fonéticos fictícios e migrados os nomes de demonstração antigos nas estruturas guardadas.
   - **Limite atual:** os 200 agentes existem no sistema de dados e têm estados/rotinas abstratas; apenas 3 personagens são atualmente materializadas como NPCs móveis visíveis no mapa. A movimentação 3D individual dos 200 ainda não está concluída.

3. **Economia, emprego, inventário e recursos**
   - Removidos saldos, salários, rendimentos, despesas e preços de demonstração.
   - A economia fica explicitamente por definir; transações são rejeitadas enquanto não existir configuração válida.
   - O inventário não aumenta automaticamente com o tempo.
   - Os registos antigos de demonstração de equipas, viaturas, edifícios, inventários, capacidades e efetivos são limpos na inicialização/carregamento da V0.3.0.
   - O estado inicial de combustível, condição e disponibilidade das viaturas é desconhecido, em vez de ser inventado.

4. **Ocorrências, manutenção e construção**
   - As missões deixam de ser concluídas automaticamente após um prazo inventado.
   - A conclusão exige transição explícita, equipa registada e viatura registada.
   - Reparações e obras não avançam automaticamente só porque passou um minuto; exigem transição explícita enquanto os prazos e critérios não forem aprovados.

5. **Instalações e mapa 3D**
   - Mantidas **275 propostas de local físico**, distribuídas pelos 25 bairros: 225 instalações/estabelecimentos propostos e 50 parques/jardins propostos.
   - As propostas continuam sem `building_id`, sem coordenadas 3D e com `map_spawned=false`.
   - O registo tem agora uma API de ativação que exige aprovação explícita, ID físico único e coordenadas numéricas; a gravação dos overrides é transacional.
   - O mapa 3D já consulta o registo para criar instalações aprovadas e deixou de criar bases/serviços físicos fixos por código.
   - **TNUR continua integrada na BRIGADA**: removida a antiga base TNUR independente do mapa; 10 centros TNUR permanecem unidades integradas, não locais físicos adicionais. As 5 unidades policiais especializadas também não duplicam instalações.

6. **Navegação e compatibilidade**
   - Preservada a navegação por páginas sem botão de fechar modal na secção de instalações.
   - Atualizados os testes funcionais para verificar 200 agentes, a rejeição de criação de instalações sem aprovação e o estado pendente da economia.
   - O catálogo mantém 200 episódios em 20 temporadas (10 por temporada), verificado estaticamente.

## Resultados de verificação

- **31 controlos** da auditoria cruzada do projeto: PASS, 0 falhas.
- **25 controlos** de instalações e regras de entidades: PASS, 0 falhas.
- **60 ficheiros JSON** analisados pelo preflight: válidos.
- **14 referências literais `res://`** verificadas: todas existem.
- **18 scripts GDScript**: delimitadores e strings equilibrados; sem nomes de função duplicados.
- Workflow YAML: PASS.
- Sintaxe Bash dos passos do workflow: PASS.
- `tools/preflight.sh`: `RESULT=PASS`.

## Limitações que continuam abertas

- Não existe executável Godot disponível neste ambiente. Por isso, **não foi possível executar o parser/runtime Godot, o preflight funcional GDScript, abrir a cena em execução, exportar ou instalar uma APK**.
- O workflow atualizado ainda precisa de ser executado no GitHub Actions para confirmar a compilação real e produzir o artefacto APK.
- Os edifícios/instalações propostos ainda não são objetos físicos do mapa. A geração depende de aprovação de localizações, IDs e coordenadas.
- Efetivos, equipas, quantidade de viaturas, inventário, salários, preços, orçamento, saldos, capacidade, horários, regras demográficas e equilíbrio económico permanecem por definir em conjunto.
- A movimentação 3D individual de 200 residentes, os testes completos de despacho e a persistência real continuam pendentes de validação runtime.

## Nota sobre a APK de pré-visualização

O workflow cria uma chave temporária de assinatura para permitir testar uma APK. Essa chave não é adequada para distribuição pública e muda entre execuções; para instalar uma nova pré-visualização sobre outra com assinatura diferente, pode ser necessário desinstalar a anterior. Não é uma assinatura de release final.

# Valepólis V0.3.0 — Regras económicas integradas V30

Estado: regras aprovadas para a simulação; validação de execução pendente.

## Regra de mercado
Aplicar `Pnovo = Panterior * (1 + clamp(0.45C + 0.40D - 0.25K, -0.10, +0.10))` apenas com preço anterior positivo e observações válidas. Fatores são normalizados para [-1, 1]. Dados insuficientes significam preço inalterado e evento de auditoria.

## Stocks e transações
- Stock disponível = stock físico - reservas.
- Rejeitar quantidades não positivas, venda superior ao stock disponível, referências inválidas e transações duplicadas.
- Compras só aumentam stock após receção confirmada.
- Vendas só reduzem stock e reconhecem receita mediante operação contabilística válida.
- Atualização de stock e contabilidade tem de ser atómica.
- Stocks iniciais não configurados continuam desconhecidos; não criar quantidades por omissão.

## Empresas e emprego
- Trabalhadores, contratos, fornecedores e clientes precisam de IDs válidos.
- Separar encomenda, receção, fatura, obrigação, pagamento e recebimento.
- Não reconhecer receita como caixa antes da cobrança.
- Aplicar salários V28 apenas com contrato, horas, período, empregador e conta financiada.
- Impedir duplicação de salários e operações contabilísticas.

## Finanças públicas
Uma despesa só pode ser submetida para contabilização se o montante for positivo, existir rubrica válida, a dotação disponível cobrir o valor e a tesouraria tiver fundos suficientes. Orçamento e saldo inicial não são inventados.

## Crédito
Parâmetros aprovados para simulação: taxa nominal anual de referência 6%, prestação mensal com capital decrescente, prazo máximo 60 meses e esforço mensal máximo proposto de 30% do rendimento líquido recorrente ou fluxo operacional verificado. O cálculo de prestação não desembolsa crédito. Desembolso aumenta caixa e dívida em igual capital, não receita.

## Seguros
Parâmetros aprovados para simulação: taxa base anual 2%, fator de risco entre 0,75 e 2,5 e franquia de referência de 5%. Prémio = valor seguro × taxa base × fator de risco. Indemnização = min(max(0, prejuízo aceite - franquia), limite remanescente). Não criar apólices ou pagar sinistros automaticamente.

## Bairros
Usar apenas população e setores prioritários já registados. Previsões de procura não são vendas. Não criar empresas, empregos, stock, preços locais, saldos ou receitas automaticamente.

## Persistência
- IDs de transação únicos e idempotentes.
- Movimentos de stock e dinheiro atómicos.
- Histórico contabilístico imutável; corrigir com movimentos de reversão.
- Guardar e recuperar contratos, contas, stocks, preços, observações e chaves de idempotência.
- Validar referências e reconciliação depois do carregamento.
- Não substituir um ficheiro de gravação válido por uma gravação corrompida.

## Testes de aceitação
1. Venda acima do stock: rejeitada, sem alterações.
2. Pedido duplicado: nenhum segundo movimento.
3. Despesa sem dotação/fundos: rejeitada.
4. Observações incompletas: preço não muda.
5. Fatura não recebida: aumenta contas a receber, não caixa.
6. Empréstimo: caixa e dívida aumentam pelo mesmo capital.
7. Sinistro não aceite: sem indemnização.
8. Reiniciar: estado recuperado sem duplicações.
9. Bairro sem empresa/stock registados: nada é criado.
10. Salário repetido no mesmo período: bloqueado.

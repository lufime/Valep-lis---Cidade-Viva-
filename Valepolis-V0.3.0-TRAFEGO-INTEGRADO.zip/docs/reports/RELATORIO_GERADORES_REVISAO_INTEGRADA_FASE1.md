# Valepólis V0.3.0 — Revisão integrada dos geradores (fase 1)

## Base
Projeto recebido: `Valepolis-V0.3.0-MAPA3D-PERSONAGEM-DIAGNOSTICO-CORRIGIDO.zip`.

## Ficheiros alterados
- `systems/city_3d.gd`
- `addons/valepolis_3d_studio/procedural_character.gd`

## Alterações
- Acrescentada atualização autónoma de veículos e peões em percursos locais associados aos eixos rodoviários/passeios já gerados.
- Movimento dos agentes é atualizado mesmo quando a personagem selecionada não está instanciada.
- A personagem selecionada comunica ao gerador quando está em movimento.
- Adicionada animação procedural de marcha/repouso para pernas e braços, com movimento discreto da cabeça.
- Aumentada a distância máxima de renderização da câmara para reduzir o desaparecimento do cenário em zoom afastado.

## Validação realizada
- `bash tools/preflight.sh`: PASS.
- Auditoria do projeto: 40 verificações PASS, 0 falhas.
- Auditoria de instalações: 25 verificações PASS, 0 falhas.
- JSON do projeto: 58 ficheiros parseáveis.
- A validação acima é estática/estrutural; não prova funcionamento visual em tempo real.

## Limitações conhecidas / próximo trabalho
- Não foi possível executar o Godot neste ambiente (executável não instalado); parser GDScript, física, animações e exportação Android ainda não foram testados em runtime.
- Os percursos de tráfego nesta fase são ciclos locais, não pathfinding global com semáforos, prioridade, colisão e congestionamento.
- As animações são procedurais simples sobre as peças atuais, não um esqueleto humano completo com IK.
- Os perfis arquitetónicos já existentes ainda precisam de gerar famílias geométricas específicas por bairro (telhados, fachadas, materiais, lotes e densidade) de forma mais abrangente.
- Não foram alteradas as atribuições culturais nem os dados oficiais dos 25 bairros.
- Não foram adicionadas dependências de Blender nem alterada a interface aprovada.

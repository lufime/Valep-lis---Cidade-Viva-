# V25 — Regras económicas por bairro integradas no runtime

## Alterações
- O runtime carrega `data/neighborhood_economy_v030.json`.
- Adicionadas APIs para consultar o perfil económico de um bairro, registar observações de oferta/procura, consultar pressão de mercado e ler o registo de auditoria.
- Cada observação fica associada ao bairro, produto/serviço e instante da simulação.
- A pressão é classificada como `shortage_pressure`, `surplus_pressure` ou `balanced`.
- O PRE-FLIGHT verifica a presença destas APIs e o carregamento dos perfis.

## Limites de segurança económica
O registo de pressão não altera preços automaticamente: faltam uma regra numérica aprovada de ajuste e preços de referência configurados. Também não cria stocks, empresas, vendas, salários, receitas, despesas ou dinheiro. As transações financeiras continuam sujeitas à validação de saldo e dos valores necessários.

## Validação
Verificados estruturalmente o ZIP, os JSON e a presença das funções. Não foi executado o interpretador Godot nem a simulação runtime neste ambiente; a compilação e integração real permanecem por validar no workflow Godot.

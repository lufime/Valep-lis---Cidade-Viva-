# Economia por bairro — Valepólis V0.3.0 / V24

## Implementação
Criado `data/neighborhood_economy_v030.json`, com um perfil para cada um dos 25 bairros, usando a função territorial e a população já presentes no projeto. Inclui setores prioritários, oferta potencial, fatores de procura e regras para stocks, transações, sazonalidade, emprego, receitas e despesas.

## Oferta e procura
A procura considera dados reais do jogo (população ativa, rendimento disponível, preços, stocks, capacidade e sazonalidade confirmada). A oferta considera stocks, produção registada, capacidade, trabalhadores, custos configurados e acessibilidade. A variação de preços deve ser gradual, explicável e limitada pela configuração do mercado.

## Salvaguardas
- Setores indicam especializações potenciais; não criam empresas ou instalações.
- Não foram criados salários-base, preços, receitas, despesas, stocks iniciais ou volumes de produção.
- As regras fiscais aprovadas continuam em `data/economy_config.json`.
- Uma operação sem dados necessários é bloqueada individualmente; isso não deve paralisar toda a economia.
- A especialização costeira, portuária, cultural, comercial, residencial, energética ou montanhosa deriva dos papéis territoriais registados.
- O PRE-FLIGHT verifica cobertura dos 25 bairros e consistência populacional.

## Estado de validação
ZIP validado estruturalmente após edição. Ainda é necessário executar `tools/preflight.sh`, importar o projeto no Godot, testar a simulação em runtime e confirmar a integração real do sistema económico com as empresas, stocks, famílias e transações. A existência do perfil não prova, por si só, que a economia já esteja ligada ao runtime.

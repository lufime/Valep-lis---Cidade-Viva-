# Valepólis V0.3.0 — Visibilidade de carros e habitantes por hora

## Alteração
- Os veículos e peões já gerados passam a obedecer ao perfil horário do relógio do jogo.
- Hora de ponta da manhã (07:00–09:59): mais carros e peões visíveis, com carros mais lentos.
- Período diurno (10:00–16:59): densidade intermédia/elevada de carros e habitantes.
- Hora de ponta da tarde (17:00–19:59): densidade elevada e circulação rodoviária mais lenta.
- Período noturno (23:00–05:59): menos carros e habitantes visíveis.
- Períodos de transição: densidade intermédia.
- Ao fim de semana, a densidade de carros pendulares diminui e a presença pedonal diurna aumenta.
- A seleção é determinística e usa índices estáveis; não recria personagens a cada mudança de hora.
- O relógio do jogo já chama `set_traffic_hour` através de `v030_update_traffic` em `main.gd`.

## Limitações / testes pendentes
- A população visível corresponde aos agentes pedonais ambientais que o mapa já gera (3 por bairro no gerador atual), não aos 1.000.000 habitantes como entidades 3D individuais.
- Isto controla a densidade visual e a velocidade básica; não implementa simulação completa de viagens casa-trabalho, destinos individuais, transportes públicos ou pathfinding global.
- O projeto foi atualizado por edição estática do script. Não foi executado Godot nesta sessão; importação, parsing/runtime e validação visual Android permanecem por executar. Não declarar PRE-FLIGHT aprovado com base nesta alteração.

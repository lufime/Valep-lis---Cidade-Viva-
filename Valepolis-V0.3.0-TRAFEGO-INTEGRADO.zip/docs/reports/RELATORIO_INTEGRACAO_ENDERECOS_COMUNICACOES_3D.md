# Relatório de integração — Valepólis V0.3.0

## Ficheiros alterados ou novos
- `city_3d.gd` — adiciona uma malha visual local de arruamentos/passeios por bairro e rótulos das avenidas principais.
- `data/enderecamento_valepolis.json` — 25 bairros, 125 arruamentos, 6.250 endereços de referência.
- `data/comunicacoes_valepolis.json` — regras fictícias de telefone e email, incluindo email privado e profissional.
- `systems/valepolis_address_book.gd` — funções auxiliares para consultar os dados e formatar contactos.

## Limites importantes
- As estradas criadas nesta alteração são geometria visual modular; ainda não implementam pathfinding, regras de trânsito ou navegação de veículos.
- Os endereços são referências de cadastro; ainda não estão associados a cada edifício 3D individual.
- Os códigos postais seguem a faixa aprovada para o jogo, mas não foi feita uma verificação mundial/abrangente de colisões com códigos reais.
- Godot não foi executado neste ambiente; não há confirmação de teste de runtime nem de APK.
- A interface principal não foi reescrita nesta alteração. A regra de navegação sem pop-ups precisa de auditoria/integração específica.

## Verificações estáticas
- 25 bairros.
- 125 arruamentos nomeados (5 por bairro).
- 6.250 endereços de referência.
- JSONs gerados e serializados.

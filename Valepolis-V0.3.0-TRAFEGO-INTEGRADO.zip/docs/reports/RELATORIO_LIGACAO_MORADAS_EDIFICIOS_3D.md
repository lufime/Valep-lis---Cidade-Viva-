# Relatório — ligação de moradas aos edifícios 3D

A base de endereços está agora alinhada com a ordem dos bairros em `city_3d.gd`. No arranque, o mapa carrega o JSON; cada edifício procedural recebe metadados de endereço e os segmentos de rua recebem metadados do arruamento.

## Verificações estáticas
- **neighborhoods**: 25
- **streets**: 125
- **reference_addresses**: 6250
- **unique_address_ids**: True
- **building_address_metadata_code**: True
- **street_metadata_code**: True
- **Godot_runtime_tested**: False
- **APK_tested**: False
- **vehicle_pathfinding**: False

## Limitações
- Os metadados ligam as moradas aos 14 edifícios de representação gerados por bairro; não cria ainda a população total de edifícios da cidade.
- Os endereços ainda são metadados internos, não placas de porta visíveis para todos os edifícios.
- A malha visual não inclui ainda pathfinding, navegação de veículos ou regras de trânsito.
- Não foi executado Godot nem compilada APK nesta validação.

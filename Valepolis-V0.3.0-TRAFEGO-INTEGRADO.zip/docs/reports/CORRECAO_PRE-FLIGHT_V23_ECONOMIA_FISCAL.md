# Correção PRE-FLIGHT V23 — economia e fiscalidade

## Correção aplicada
- Removida a verificação incorreta que exigia `tax_model` nulo.
- Registadas em `data/economy_config.json` as regras fiscais já aprovadas:
  - Segurança Social: 11%.
  - IRS marginal: 0% até €900; 5% até €1.500; 10% até €2.500; 18% até €4.000; 25% acima de €4.000.
  - Imposto sobre consumo: 0% essenciais; 13% ordinários; 23% não essenciais.
  - Imposto sobre imóveis: intervalo anual de 0,3% a 0,8%.
  - Imposto sobre lucros: 15%.
  - Salário líquido = bruto − Segurança Social − IRS.
  - Saldo inicial = um mês de salário líquido.
- O PRE-FLIGHT compara agora os valores fiscais com as regras aprovadas, em vez de os tratar como não definidos.

## Limite deliberado
A correção não inventa salários-base, preços, receitas, despesas, orçamento, crédito ou subsídios concretos. Esses montantes continuam pendentes de configuração específica. O bloqueio de transações quando faltam montantes necessários mantém-se.

## Validação
Esta alteração foi verificada estruturalmente ao criar o ZIP. Não foi possível executar Godot, importar recursos, executar testes funcionais reais ou exportar/instalar APK neste ambiente. O relatório PRE-FLIGHT deve continuar a apresentar esses gates como pendentes até serem executados no workflow.

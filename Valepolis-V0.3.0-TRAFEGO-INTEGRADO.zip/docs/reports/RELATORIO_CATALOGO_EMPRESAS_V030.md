# Catálogo inicial de empresas — Valepólis V0.3.0

## Estado
Proposta de trabalho **não oficial**, criada a pedido do utilizador. Não altera regras oficiais nem cria locais no mapa.

## Conteúdo
- 41 identidades empresariais fictícias propostas.
- 18 setores económicos.
- 0 moradas, edifícios, proprietários ou trabalhadores atribuídos automaticamente.
- 0 valores financeiros definidos.

## Regras de integridade
Os nomes e atividades são conteúdo proposto nesta revisão, não afirmações de que estas empresas já existam nos dados anteriores. Os IDs são estáveis dentro deste catálogo. Os campos sem confirmação permanecem nulos.

O catálogo respeita as categorias gerais da especificação da cidade: comércio, indústria, alojamento, restauração, serviços pessoais/profissionais, construção, energia, agricultura, finanças, comunicação social, mobilidade, logística e lazer. Saúde, educação, tecnologia e imobiliário foram separados para permitir rastreabilidade, sem presumir quantidades ou orçamento.

Parque Aquático e Marinho e Zoo de Valepólis permanecem privados. Parques e jardins públicos e serviços municipais não são convertidos em empresas privadas. TNUR continua integrada na BRIGADA e não é empresa independente.

## Por fazer antes de considerar implementado
1. Comparar IDs/atividades com o catálogo de entidades e profissões existente.
2. Resolver endereços e edifícios reais já registados, evitando duplicações.
3. Ligar habitantes existentes a empresas com profissão compatível, sem criar pessoas.
4. Definir vagas, contratos e horários a partir de regras aprovadas.
5. Configurar economia e testar no Godot; nenhum teste runtime foi executado nesta geração.

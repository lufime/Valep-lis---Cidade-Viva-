# Valepólis V0.3.0 — Continuação da auditoria

## Alterações nesta revisão

- Removidos do estado inicial da cena `Main.tscn` os valores demonstrativos visíveis `01/01/2026`, `€ 120`, `Energia 80`, `Fome 20/100` e `Saúde 100`.
- Substituído o texto inicial por um estado neutro enquanto a simulação arranca; o `main.gd` continua responsável por apresentar a data/hora real da nova partida e os valores da personagem quando a partida é inicializada.
- Acrescentados dois controlos à auditoria estática `tools/preflight_project.py` para impedir o regresso desses valores fictícios na cena inicial.

## Verificações executadas neste ambiente

- `bash tools/preflight.sh`: PASS.
- Auditoria de projeto: 33 controlos PASS, 0 falhas.
- Auditoria de instalações: 25 controlos PASS, 0 falhas.
- 60 ficheiros JSON parseáveis.
- Workflow Android em YAML válido.
- 275 registos de instalações com IDs únicos.
- 25 bairros oficiais e 200 episódios presentes.
- Verificado que o pipeline do workflow inclui importação headless do Godot, teste funcional, exportação Android e verificação da assinatura da APK.
- Confirmado que a cena inicial já não apresenta saldo, data ou necessidades fictícias antes de o script assumir o controlo.

## Limitações importantes

- O executável Godot não está instalado neste ambiente e não foi possível descarregá-lo, porque o acesso de rede falhou na resolução do domínio `github.com`.
- Portanto, não foi executado o parser/runtime do Godot, não foi feita exportação real da APK e não foi testada a instalação num dispositivo Android.
- Os controlos estáticos não garantem que a interface e todos os fluxos de jogo funcionem em execução. O workflow Android deve ser executado num runner com acesso à rede para confirmar esses pontos.
- Permanecem deliberadamente por definir os efetivos, a frota, o inventário, os salários, as receitas, as despesas, o orçamento e outras quantidades que exigem decisão do utilizador.
- As instalações continuam propostas de dados; não são geradas como edifícios 3D sem aprovação e coordenadas explícitas.

## Ficheiros alterados nesta continuação

- `Main.tscn`
- `tools/preflight_project.py`
- `RELATORIO_CONTINUACAO_AUDITORIA_V030.md`
- `RELATORIO_PREFLIGHT_CONTINUACAO_V030.txt`

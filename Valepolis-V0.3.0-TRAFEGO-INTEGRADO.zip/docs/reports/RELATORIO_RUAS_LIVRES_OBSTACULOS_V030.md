# Valepólis V0.3.0 — Correção inicial de corredores rodoviários

## Alteração aplicada
- `systems/city_3d.gd`: acrescentada reserva geométrica para eixos viários globais e ruas locais.
- O gerador de edifícios ignora posições dentro dos corredores reservados.
- Árvores, árvores de parques e veículos ambientais não são colocados quando a posição intersecta os corredores reservados.

## Limites
Esta alteração reduz obstáculos criados por estes geradores junto às vias principais e aos eixos locais. Não prova ausência total de colisões: as ligações inter-bairros, instalações registadas, marcos, geometria do terreno, passeios e pontes ainda precisam de validação no Godot em runtime. O projeto não foi executado neste ambiente; não declarar PRE-FLIGHT aprovado até correr os testes reais.

## Atualização — autoestradas e avenidas com múltiplas faixas
- Avenida Central e Avenida Transversal passam a ter 4 faixas, com marcações longitudinais.
- Avenida Norte e Avenida Sul passam a ter 3 faixas, com marcações longitudinais.
- Adicionada uma autoestrada periférica de 4 faixas a leste e uma variante de 4 faixas a sul, com ligações à malha urbana.
- Os corredores dessas vias foram incluídos nas reservas usadas pelos geradores de objetos.
- As marcações e plataformas são geradas pelo script Godot; não foi possível executar Godot/runtime nem verificar visualmente a geometria nesta sessão. A transitabilidade, as ligações exatas à rede regional e as colisões continuam por validar no PRE-FLIGHT.

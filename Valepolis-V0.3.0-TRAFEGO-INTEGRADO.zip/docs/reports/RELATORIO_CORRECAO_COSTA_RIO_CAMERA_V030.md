# Correção visual inicial — Valepólis V0.3.0

## Alteração
- Ajustada a faixa do mar para ficar apenas a norte, com footprint mais estreito e fora da zona urbana.
- Ajustado o canal do rio/estuário para a margem ocidental, mantendo a leitura continental e a continuidade terrestre a sul e a este.
- Ajustado ligeiramente o enquadramento inicial da câmara para mostrar melhor a cidade.

## Integridade
- `tools/preflight_project.py`: PASS — 40 verificações, 0 falhas.
- O preflight é estático; não substitui execução visual no Godot nem teste Android.
- Não foram alterados os 25 bairros, as coordenadas registadas, nem as regras culturais pendentes.

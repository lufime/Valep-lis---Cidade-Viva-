# Catálogo de entidades e profissões — V0.3.0

## Resultado da auditoria estática

- Ramos: **41**
- Subcategorias: **220**
- Profissões: **800**
- Tipos de entidade: **420**
- Compatibilidades profissão-entidade: **934**
- IDs de profissão duplicados: **0**
- IDs de entidade duplicados: **0**
- Pares de compatibilidade duplicados: **0**
- Profissões sem entidade compatível: **0**
- Entidades sem profissão compatível: **0**
- Referências de compatibilidade inválidas: **0**

A auditoria valida a estrutura por ID e a cobertura bidirecional; não certifica que todas as compatibilidades sejam semanticamente perfeitas. Existem nomes repetidos em ramos distintos, preservados porque os IDs são únicos.

## TNUR

As entradas taxonómicas TNUR (Base TNUR, Central TNUR, Serviço TNUR, Unidade TNUR) são preservadas na fonte, mas filtradas da seleção como entidades independentes. A unidade TNUR é gerida através da BRIGADA e os seus centros funcionam dentro de bases BRIGADA. Não se criam nem contabilizam bases TNUR autónomas.

## Campos deixados para definir em conjunto

- Efetivos e composição das equipas
- Economia, receitas e despesas das entidades
- Quantidade e localização das instalações
- Quantidade, modelos e códigos de viaturas
- Quantidades e categorias de inventário
- Orçamento e saldo

O catálogo descreve tipos funcionais; **420 tipos de entidade não significam 420 instalações físicas**. Nenhum efetivo, frota, inventário ou valor financeiro foi inferido a partir do catálogo. O carregamento de gravações antigas também ignora os antigos registos de gestão e orçamento das entidades, para impedir que valores de demonstração reapareçam.

## Limites de validação

Foram feitas verificações estáticas dos dados JSON e do código. Não foi possível executar o projeto no Godot nem compilar/testar a APK neste ambiente.

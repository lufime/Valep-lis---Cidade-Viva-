# Valepólis V0.3.0 — Calibração económica calculada V29

**Estado: proposta calculada, pendente de aprovação.** Não ativa automaticamente valores nem cria transações no jogo.

## Cálculos de base
- População total dos 25 bairros: **1,000,000 habitantes** (soma dos valores territoriais existentes).
- Catálogo de preços de referência ilustrativos: **15 produtos/serviços**.
- Previsões de procura: calculadas por bairro com `população × taxa configurada por residente`; são previsões de calibração, não vendas reais.
- Preços, custos unitários, crédito e seguro neste ficheiro são parâmetros de simulação propostos, não preços reais de mercado.
- Stock inicial por empresa: **não configurado**.
- Saldo inicial das empresas e município: **não configurado**.
- Orçamento municipal de abertura: **não configurado**.
- Empresas, empregos, vendas, receitas, stocks e sinistros: **não são criados automaticamente**.

## Parâmetros calculados para avaliação
- Ajuste de preço semanal limitado a ±10%; fórmula candidata `delta = 0,45C + 0,40D - 0,25K`.
- `C`: pressão de custos normalizada; `D`: pressão de procura; `K`: preço próprio face à mediana de pelo menos dois concorrentes válidos.
- Se os dados exigidos estiverem ausentes ou desatualizados, não se altera o preço.
- Crédito de exemplo: taxa nominal anual de 6%, capital decrescente, máximo 60 meses, prestação limitada a 30% do rendimento líquido recorrente ou fluxo de caixa operacional verificado.
- Seguro de exemplo: prémio anual = valor seguro × 2% × fator de risco (0,75–2,5); franquia de referência 5%.
- Persistência: gravação atómica, IDs idempotentes, histórico de auditoria e recuperação sem reaplicar transações.

## Regras mantidas
- Fiscalidade de simulação aprovada preservada sem alterações.
- Salários V28 preservados.
- Nenhum multiplicador salarial por bairro inventado.
- Não há stock negativo, transação duplicada nem preço automático sem dados válidos.
- Empréstimo aumenta caixa e dívida, não receita.
- Fatura não significa pagamento; encomenda não significa receção.

## Testes
Foram definidos 10 testes de aceitação em `data/economic_calibration_proposal_v029.json`. Nesta entrega foram verificadas a integridade do ZIP, a leitura dos JSON e a soma populacional. **Godot, PRE-FLIGHT e APK não foram executados.**

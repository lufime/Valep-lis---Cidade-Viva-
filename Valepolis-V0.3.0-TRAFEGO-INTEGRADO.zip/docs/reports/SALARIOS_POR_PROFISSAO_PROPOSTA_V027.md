# Valepólis V0.3.0 — Proposta de salários por profissão V27

**Estado: PROPOSTA PENDENTE DE APROVAÇÃO.** Não é uma tabela salarial oficial nem prova de execução no Godot.

## Âmbito
- Foram mantidos os IDs, nomes, ramos e subcategorias do catálogo de profissões existente.
- Foram classificadas as 800 profissões existentes em seis bandas salariais de referência que já constavam da proposta económica V26.
- A classificação automática serve apenas como primeira triagem e precisa de revisão profissional, sobretudo em profissões regulamentadas, turnos, risco, antiguidade, convenções coletivas e cargos públicos.
- Não foram inventadas novas profissões, empresas, vagas, stocks, receitas ou despesas.
- Não foram atribuídos prémios monetários por bairro: ainda não há multiplicadores salariais de bairro aprovados. Os perfis territoriais existentes indicam setores prioritários, não salários locais comprovados.

## Bandas de referência propostas
| Banda | Bruto mensal proposto (tempo completo) |
|---|---:|
| Entrada / apoio | €1.000 |
| Operacional qualificado | €1.250 |
| Técnico / especialista | €1.650 |
| Profissão superior / elevada especialização | €2.100 |
| Coordenação / chefia | €2.600 |
| Direção / responsabilidade máxima | €3.400 |

Referência externa para plausibilidade: a retribuição mínima mensal garantida em Portugal em 2026 é €920, com efeitos desde 1 de janeiro de 2026, nos termos do Decreto-Lei n.º 139/2025. Este valor não valida automaticamente as bandas propostas para o jogo. Fonte: DGERT e Diário da República.

## Regras de segurança económica
1. Salários são valores brutos; as deduções usam apenas a configuração fiscal aprovada já existente no projeto.
2. Tempo parcial: cálculo proporcional às horas contratadas, respeitando os mínimos legais aplicáveis.
3. Nenhum pagamento sem contrato, empregador, horas, período, conta e registo contabilístico válidos.
4. Impedir pagamento duplicado para a mesma pessoa, contrato e período.
5. Os salários não criam liquidez, receitas empresariais nem orçamento municipal.
6. O perfil económico do bairro pode influenciar a procura de competências e a disponibilidade de emprego apenas quando esses dados forem registados; não aplicar um multiplicador salarial local sem regra aprovada.

## Validação realizada
- Integridade ZIP: a verificar após empacotamento.
- JSON: serialização e leitura local.
- Catálogo: contagem e preservação dos IDs existentes.
- Godot/Pre-flight/APK: não executados nesta operação.

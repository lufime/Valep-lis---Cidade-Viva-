# Valepólis V0.3.0 — Salários por profissão e regras integradas V28

**Estado:** tabela e regras de salário aprovadas pelo utilizador para referência de simulação do jogo.

## Integrado
- Tabela para as 800 profissões existentes, mantendo os IDs e nomes do catálogo.
- Seis bandas de salário bruto mensal a tempo completo.
- Regra proporcional para contratos entre 0 e 40 horas semanais, com referência de 40 horas.
- Consulta de salário por ID de profissão e cálculo do bruto proporcional no runtime.
- Proteções documentadas contra pagamento sem contrato, empregador, conta financiada, período e registo contabilístico, bem como contra duplicação.
- A configuração fiscal aprovada existente foi preservada.

## Não ativado nem inventado
- Multiplicadores salariais por bairro.
- Empregos, empregadores, contratos, contas, liquidez ou pagamentos automáticos.
- Preços de produtos, stocks iniciais, receitas, despesas, orçamento, crédito ou subsídios.
- Cálculo líquido final sem integração/validação do processamento fiscal por período.

## Testes desta entrega
- ZIP: teste de integridade.
- JSON: leitura e validação.
- Catálogo: 800 IDs únicos preservados.
- Runtime: verificação textual da integração e presença das funções.
- Godot, PRE-FLIGHT e APK: **não executados nesta operação**.

# Valepólis V0.3.0 — Rede regional e pontes

## Alterações estruturais
- As pontes da União e do Horizonte são geradas como tabuleiros acima do `Rio_Estuario_Oeste`.
- Cada ponte tem rampas de acesso a oeste e a leste, com segmentos inclinados entre a cota do terreno e o tabuleiro.
- Um corredor rodoviário na margem ocidental liga os acessos das duas pontes e continua para sul.
- Foram acrescentados acessos rodoviários a Santo André do Vale, Portela do Sul e a áreas genéricas de vilas/arredores, sem inventar nomes oficiais para estas últimas.
- Os acessos orientais seguem trajetos curtos que contornam os centros dos bairros próximos antes de regressarem à rede urbana.
- As vias regionais e as pontes recebem metadados para facilitar a auditoria futura.
- O PRE-FLIGHT chama `tools/preflight_regional_roads.py` para verificar a presença estrutural destas ligações.

## Limites de validação
A auditoria automática atual é estática. Não prova ausência de colisões entre estradas, edifícios, árvores, parques ou água, nem prova que veículos percorram as vias em runtime. É obrigatório executar o projeto no Godot, inspecionar visualmente as duas margens e as rampas, e testar navegação antes de declarar a rede aprovada.

## Restrições preservadas
- Mantida a lista dos 25 bairros e os ficheiros existentes de moradas.
- Não foram renumeradas portas nem recalculados códigos postais.
- Não foram inventados nomes para novas vilas.
- Não foi introduzido Blender.

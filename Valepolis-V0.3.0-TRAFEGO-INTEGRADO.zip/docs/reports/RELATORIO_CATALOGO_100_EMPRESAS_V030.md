# Catálogo de 100 empresas — candidatos de morada V0.3.0

## Resultado estático
- 100 empresas propostas; 100 IDs únicos.
- 18 setores económicos.
- 100 moradas candidatas únicas, retiradas do cadastro existente e no bairro preferencial de cada empresa.
- Nenhuma candidata reutiliza as moradas reservadas no registo de 275 instalações propostas.
- Moradas comerciais fisicamente confirmadas: 0; edifícios confirmados: 0; trabalhadores atribuídos: 0.
- `address_id` e `building_id` permanecem nulos; `map_spawned=false`.

## Limite importante
As moradas atribuídas são **candidatas postais**, não confirmação de que exista um edifício comercial compatível nessa localização. Antes de criar estabelecimentos no mapa, validar uso, edifício, coordenadas 3D, acessos e eventuais conflitos.

## Estado dos testes
- Validações estáticas: ver `RELATORIO_CATALOGO_100_EMPRESAS_V030.json`.
- Godot runtime: NOT RUN.
- APK Android: NOT RUN.

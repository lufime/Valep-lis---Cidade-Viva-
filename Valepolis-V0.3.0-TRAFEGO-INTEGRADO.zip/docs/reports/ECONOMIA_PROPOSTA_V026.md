# Valepólis V0.3.0 — Proposta económica V26

**Estado: PROPOSTA — aguarda aprovação explícita.**

## Âmbito
Esta adenda organiza os parâmetros de protótipo encontrados nos documentos de calibração:
- seis bandas salariais mensais brutas;
- carga horária de referência;
- fórmula de preço proposta e limite semanal;
- elasticidades de procura propostas;
- regras de inventário, receitas e despesas.

## Proteções
- Não substitui `data/economy_config.json` nem altera as taxas fiscais aprovadas.
- Não inventa preços unitários, stocks iniciais, receitas, despesas, saldos ou quantidades.
- Não mapeia automaticamente profissões para bandas salariais sem uma tabela aprovada.
- Não ativa a fórmula de preços: a normalização e a aplicabilidade por categoria ainda exigem definição e testes.
- Não declara compilação, execução Godot ou APK validadas.

## Referências de calibração recuperadas
Os valores abaixo são propostas de protótipo documentadas, não decisões oficiais:
- Entrada: 1 000 €/mês bruto;
- Operacional qualificado: 1 250 €/mês bruto;
- Técnico: 1 650 €/mês bruto;
- Profissional superior: 2 100 €/mês bruto;
- Coordenação: 2 600 €/mês bruto;
- Direção: 3 400 €/mês bruto;
- Horário de referência: 40 h/semana integral, 20 h parcial, 10 h reduzido;
- Ajuste setorial/experiência/escassez proposto: -20% a +35%;
- Fórmula de preço proposta: Δ = 0,45C + 0,40D − 0,25K; variação semanal proposta limitada a ±10%, salvo choque documentado.

## Próximas decisões necessárias
1. Aprovar, alterar ou rejeitar as seis bandas de referência.
2. Confirmar que os valores específicos da tabela salarial por profissão prevalecem sobre as bandas.
3. Definir os limites de normalização C, D e K e as categorias de produtos a que a fórmula se aplica.
4. Integrar o catálogo de produtos/serviços e stocks iniciais aprovados, sem inventar quantidades.
5. Definir a origem e os períodos de cada custo e receita.

## Validação efetuada
- JSON parseado com sucesso.
- O ZIP base foi preservado e foi acrescentado apenas o ficheiro de proposta e este relatório.
- Não foi executado o Godot; não há validação de parser GDScript, runtime nem APK.

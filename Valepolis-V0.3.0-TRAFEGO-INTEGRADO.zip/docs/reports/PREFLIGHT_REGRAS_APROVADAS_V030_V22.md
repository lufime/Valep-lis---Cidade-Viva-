# PRE-FLIGHT por regras aprovadas — V22

Esta versão acrescenta um auditor de conformidade (`tools/preflight_rules.py`) ao PRE-FLIGHT ativo e sincroniza os dois catálogos populacionais antigos com a distribuição aprovada em `data/populacao_por_bairro_v030.json`.

## Regras verificadas
- Lista e ordem dos 25 bairros oficiais.
- População aprovada por bairro e soma exata de 1.000.000; catálogos de runtime têm de coincidir com a fonte aprovada.
- Seis influências culturais com atribuições registadas e dez identidades locais distintas; não inventar atribuições ainda pendentes.
- 200 episódios em 20 temporadas, dez por temporada.
- 275 instalações continuam propostas, sem criação automática no mapa; TNUR sem instalações independentes.
- Economia, salários e modelo fiscal continuam por definir.
- Versão ativa V0.3.0 e configuração Android.

## Regras de decisão
Uma regra verificada que não corresponda aos dados aprovados produz `FAIL`. A verificação estática não comprova geometria transitável, comportamento em runtime, execução no Android ou APK funcional. Essas etapas continuam dependentes do Godot e dos testes correspondentes.

## Limite conhecido
A matriz nominal dos dez bairros com identidade local continua pendente de recuperação da matriz oficial. O auditor confirma que não foram inventadas atribuições; não tenta adivinhar os dez nomes.

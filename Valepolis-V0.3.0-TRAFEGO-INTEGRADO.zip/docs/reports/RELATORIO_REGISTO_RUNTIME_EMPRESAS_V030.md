# Valepólis V0.3.0 — Registo runtime de empresas

## Alteração
- Adicionado `systems/valepolis_company_registry.gd` como autoload `ValepolisCompanies`.
- O registo carrega `data/catalogo_empresas_v030.json` e `data/enderecamento_valepolis.json`.
- Valida IDs de empresa e morada, existência das moradas candidatas e coincidência entre o bairro da empresa e o bairro do endereço.
- Expõe API para resumo, pesquisa por ID, listagem completa, pesquisa por bairro e obtenção da morada candidata.
- `get_map_spawnable_companies()` só devolve registos com aprovação explícita, `map_spawned=true`, `building_id` e coordenadas `map_position`. A existência de uma morada candidata não cria automaticamente um estabelecimento no mapa.

## Validação estática executada
- 100 empresas; 100 IDs únicos.
- 100 moradas candidatas únicas.
- 100/100 moradas candidatas encontradas no cadastro de endereços.
- 100/100 bairros da morada coincidem com o bairro preferencial da empresa.
- Autoload e seis métodos públicos encontrados.
- ZIP submetido a teste de integridade após empacotamento.

## Limitações e estado
- O executável Godot não está disponível neste ambiente; análise sintática e execução GDScript não foram executadas.
- As moradas continuam candidatas aprovadas como dados territoriais, mas não confirmam edifício físico, coordenadas, licença, atividade operacional ou relação de emprego.
- Não foram atribuídos trabalhadores, salários, receitas ou lucros.
- Não foram criadas empresas automaticamente no mapa 3D.
- A compilação da APK Android permanece por executar.

## Resultado
`STATIC_RESULT=PASS`; `GODOT_RUNTIME=NOT_RUN`; `ANDROID_BUILD=NOT_RUN`.

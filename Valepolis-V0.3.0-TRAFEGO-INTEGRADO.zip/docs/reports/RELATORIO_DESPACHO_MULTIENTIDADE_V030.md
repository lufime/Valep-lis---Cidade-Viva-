# Relatório — Despacho multientidade V0.3.0

## Âmbito
A rede rodoviária passa a ter um ponto de integração previsto no runtime para entidades operacionais, mantendo as funções distintas das instituições e dos serviços civis.

## Entidades cobertas
- **BRIGADA** — resposta operacional a incêndios, resgates, incidentes urbanos, intempéries, ocorrências rodoviárias e busca.
- **S.U.E.** — resposta clínica urgente e apoio médico em acidentes/resgates.
- **Polícia** — segurança pública, acidentes, buscas e apoio/controlo de tráfego.
- **TNUR** — planeamento de transporte não urgente; não recebe ocorrências urgentes.
- **Município** — apoio municipal em ocorrências que afetem o espaço público.
- **Serviços Públicos** — apoio a infraestrutura, acessos e manutenção.
- **Hospital** — destino/entidade recetora, não unidade de despacho.
- **Escola** e **Comércio** — entidades/localizações civis que podem ser afetadas, não unidades de despacho.

## Implementação
- `data/entity_response_capabilities.json`: capacidades, papéis e restrições de cada entidade.
- `systems/valepolis_systems_runtime.gd`: `dispatch_entity(...)`, `plan_non_urgent_transport(...)` e `get_dispatch_summary()`.
- `systems/valepolis_systems_self_test.gd`: verificações de presença do catálogo de entidades.
- Os IDs do gerador visual (por exemplo, `INC-MED`) são normalizados para os tipos operacionais usados no catálogo.

## Regras preservadas
- TNUR não é despachado para urgências.
- Veículos especializados do S.U.E. não são transferidos para a BRIGADA.
- Apenas uma ambulância AMBS pode ser cedida à BRIGADA mediante acordo explícito. Esta regra está documentada no catálogo; a transação de cedência ainda não está implementada como fluxo operacional.
- Entidades civis/de apoio não substituem resposta clínica, policial ou de resgate.

## Limitações
Os ficheiros foram inspecionados e verificados estaticamente. **Não foi executado o projeto no Godot nem compilado APK.** A simulação física dos veículos, a atribuição de viaturas e equipas reais do jogo, tempos de viagem, trânsito dinâmico e o fluxo operacional de cedência de ambulância continuam por integrar.

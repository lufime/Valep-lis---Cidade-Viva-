# Valepólis V0.3.0 — Integração e PRE-FLIGHT estático V31

## Alterações aplicadas ao ZIP completo recebido
- `systems/city_3d.gd`: acrescentados quatro níveis de detalhe de câmara: cidade inteira, bairros/estradas, ruas/edifícios e personagem/veículos. O nível 1 mantém as etiquetas dos 25 bairros; os níveis próximos reduzem a sobreposição das etiquetas.
- `main.gd`: os quatro controlos laterais do mapa passam a selecionar diretamente os níveis 1–4. A roda do rato e a pinça tátil continuam a fornecer zoom contínuo.
- `systems/valepolis_systems_runtime.gd`: corrigidos três dicionários inválidos nas respostas dos cálculos de crédito e seguros. A prestação do crédito usa taxa nominal anual dividida por 12, consistente com o campo `annual_nominal_rate`.
- `tools/preflight_v030_static.py`: adicionado auditor estrutural executável sem Godot.
- Os ficheiros restantes foram preservados no pacote; não foram alterados os dados aprovados dos bairros, culturas, populações ou regras fiscais.

## Resultado da verificação executada
O auditor estático foi executado após as alterações:
- 26 verificações PASS
- 0 verificações FAIL
- 81 ficheiros JSON analisados sem erro de sintaxe
- 34 referências literais `res://` verificadas sem referências em falta
- lista de 25 bairros única confirmada
- presença dos seis helpers económicos confirmada
- ligação dos quatro controlos de zoom confirmada

## Limites importantes
- O executável Godot 4.5 não está instalado neste ambiente.
- O projeto não foi aberto no editor Godot, não foi executado em runtime e não foi compilado para APK.
- Por isso, o resultado acima é **PRE-FLIGHT estático**, não certificação de compilação, teste visual, desempenho ou funcionamento em Android.
- Os helpers económicos validam/calculam valores; não criam saldos, stocks, empresas, apólices, empréstimos nem transações automaticamente.

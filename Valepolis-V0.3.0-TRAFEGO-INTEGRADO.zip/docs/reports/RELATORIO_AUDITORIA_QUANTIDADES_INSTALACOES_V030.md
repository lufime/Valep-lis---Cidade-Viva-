# Relatório de auditoria — Quantidades de instalações V0.3.0

**Estado:** auditoria estática concluída para as sobreposições identificadas; proposta continua não oficial e não aprovada.

## Decisões de contagem

- Bases BRIGADA: 13 locais propostos.
- Centros TNUR: 10 unidades integradas em bases BRIGADA; 0 locais independentes e 0 locais adicionais.
- Instalações policiais gerais: 15 locais propostos.
- Unidades policiais especializadas: 5 unidades alojadas nas 15 instalações policiais gerais; 0 locais adicionais.
- Instalações construídas/centros/estabelecimentos após eliminar a dupla contagem conhecida: 225.
- Parques e jardins públicos: 50 espaços.
- Total físico proposto após auditoria de sobreposição conhecida: 275 registos de localização (225 + 50).

## Verificações

- O JSON da proposta é válido.
- O total é coerente com as categorias que contam como locais físicos adicionais.
- TNUR permanece integrado na BRIGADA.
- As unidades policiais especializadas não aumentam a contagem física.
- `auto_create_installations` permanece `false`: a proposta não gera edifícios, moradas ou marcadores no mapa.
- Efetivos, economia, viaturas, inventário, orçamento e saldo permanecem por definir e não são preenchidos.

## Limitações e próximos passos

Esta é uma verificação estática dos dados. A contagem de 275 pressupõe que as outras categorias de instalações físicas ficam em locais distintos. Possíveis co-localizações entre instalações municipais, centros de serviços e outros equipamentos devem ser avaliadas quando forem atribuídas moradas e IDs únicos. A proposta continua não oficial. Não foi executado Godot nem compilada a APK.

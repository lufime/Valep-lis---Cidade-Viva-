# Valepólis V0.3.0 — Auditoria de integração de população, moradas e rotas

## Alterações efetuadas
- `systems/city_3d.gd`: adicionada `sync_population_agents()`, que associa os peões visuais existentes aos registos individuais persistentes por bairro, usando os IDs estáveis já existentes e propagando perfil de rotina, atividade e metadados de destino.
- `main.gd`: sincronização chamada depois da atualização das rotinas e quando a cidade 3D é criada.
- A sincronização não cria habitantes, moradas, empregos, destinos nem coordenadas novas. Peões sem correspondência ficam explicitamente marcados como não ligados.

## Dados de origem encontrados
- `data/enderecamento_valepolis.json`: 125 ruas e 6.250 registos de endereço.
- `main.gd`: amostra individual persistente com objetivo de 200 agentes e população agregada de referência de 1.000.000.
- Os edifícios 3D já guardam metadados de endereço quando existe registo correspondente.

## Verificações executadas nesta entrega
- Verificação estática dos pontos de integração: aprovada.
- JSON de endereçamento lido e contagens verificadas: aprovada (125 ruas, 6.250 endereços).
- Integridade estrutural do ZIP final: verificada após criação.
- Não foi possível executar importação, parser/runtime Godot, simulação visual, save/load em execução ou exportação APK neste ambiente: o executável Godot não está disponível. Estes testes ficam **NOT_RUN**, não aprovados.

## Limitações que permanecem
- Esta alteração liga os metadados dos peões visuais aos agentes persistentes; não transforma, por si só, as rotas gráficas locais em percursos de navegação real.
- O grafo rodoviário existente é lógico e não prova que cada troço geométrico seja transitável nem que evite todos os edifícios, água e relevo.
- Os destinos que já estejam vazios ou marcados como pendentes continuam pendentes. Não foram inventadas moradas de residência, empregadores, edifícios de destino ou percursos físicos.
- A validação final exige abrir/importar o projeto no Godot, executar testes funcionais e observar o mapa 3D; a APK não foi compilada nesta entrega.

## Resultado
Integração de dados dos peões visuais com a amostra persistente: **implementada no código e verificada estaticamente**. Integração completa de endereços/destinos com pathfinding geométrico e validação runtime: **ainda não demonstrada**.

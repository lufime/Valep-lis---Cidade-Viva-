# Relatório — Distribuição populacional e implantação territorial de empresas V0.3.0

Estado: distribuição populacional e bairros preferenciais das empresas aprovados pelo utilizador para integração. Endereços e edifícios físicos continuam pendentes de validação.

## População

O ficheiro `data/populacao_por_bairro_v030.json` distribui exatamente 1.000.000 de habitantes pelos 25 bairros canónicos. Os níveis de densidade são relativos; não se calculam habitantes/km² porque as áreas territoriais aprovadas não estão presentes neste conjunto de dados.

## Empresas

As 41 empresas do catálogo receberam um bairro preferencial segundo a função urbana e a adequação setorial. Atribuir um bairro não significa que exista uma instalação física aprovada nesse bairro. Todos os `address_id` e `building_id` permanecem nulos e `map_spawned=false`.

## Próxima fase necessária

1. Cruzar cada empresa com o registo de instalações aprovadas.
2. Encontrar morada e edifício existentes compatíveis com o setor e a matriz territorial.
3. Manter pendente qualquer empresa sem instalação compatível, sem criar moradas ou coordenadas inventadas.
4. Só depois ligar empregos e habitantes através de profissões compatíveis e registos válidos.
5. Validar no Godot e no APK; ainda não declarado testado em runtime.

## Verificações estáticas

- 25 bairros únicos.
- Soma populacional: 1.000.000.
- 41 empresas com bairro preferencial.
- IDs de empresa únicos.
- Nenhuma morada/edifício físico inventado.

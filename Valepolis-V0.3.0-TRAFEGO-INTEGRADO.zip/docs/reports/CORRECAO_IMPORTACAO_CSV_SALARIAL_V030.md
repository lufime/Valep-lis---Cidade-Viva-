# Correção da importação CSV salarial — Valepólis V0.3.0

## Alterações
- Adicionado `tools/validate_salary_csv.py`: leitor CSV com deteção de delimitador, suporte UTF-8/UTF-8 BOM, validação de cabeçalhos e colunas, validação de 800 linhas, IDs únicos, e comparação de IDs, profissões, salários e campos associados com o catálogo JSON canónico.
- Atualizado `.github/workflows/build.yml` para executar esta validação como gate separado antes do PRE-FLIGHT estático e registar PASS/FAIL no relatório, anexando o log.
- Nenhum salário, registo CSV ou registo JSON foi alterado.

## Teste local executado
`python3 tools/validate_salary_csv.py`
Resultado: `PASS|Importação CSV salarial|registos=800|IDs únicos=800|salários coincidem com JSON=800|dados não alterados`

## Limites
Este teste confirma a leitura e a consistência CSV/JSON neste ZIP. Não confirma a execução do GitHub Actions, a compilação Godot, nem a exportação/assinatura da APK. Essas etapas só ficam confirmadas após o workflow real terminar com sucesso e publicar o artefacto APK.

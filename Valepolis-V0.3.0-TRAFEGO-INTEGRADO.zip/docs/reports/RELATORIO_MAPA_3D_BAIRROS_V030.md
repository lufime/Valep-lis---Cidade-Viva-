# Relatório — Mapa 3D dos 25 bairros de Valepólis

**Projeto:** Valepólis V0.3.0  
**Alteração:** alinhamento territorial e marcos visuais por bairro  
**Estado:** auditoria estática concluída; execução visual no Godot/Android ainda não confirmada.

## O que foi alterado
- Reposicionadas as áreas dos 25 bairros para que os nomes e perfis territoriais coincidam melhor com a geografia aprovada.
- Mantido o núcleo central em Nexora.
- Marévia e Brisamar posicionados junto à costa norte; Marivora na zona noroeste de transição costeira/estuário.
- Rivéria e Ribeora associados à margem fluvial ocidental; Portávia à zona de porto/logística; Estúria às margens do estuário.
- Montélia, Altória, Ventúria, Pedrália e Pedravora aproximados das encostas e do relevo oriental; Pedravora foi explicitamente documentado como transição montanhosa.
- Mantidas zonas verdes, residenciais e de expansão a sul/sudeste.
- Adicionados marcos 3D procedurais simples para reforçar diferenças de cada bairro: cais, passeio costeiro, jardins, polo de conhecimento, fonte, infraestrutura logística, lago, mercado, campo desportivo e referências rochosas/energéticas.
- Reduzida a dispersão dos edifícios de cada conjunto para diminuir colisões visuais entre bairros.
- Registadas as coordenadas X/Z de composição visual e a função territorial de cada bairro em `bairros_valepolis.json`.

## Regras preservadas
- Os 25 bairros oficiais e a população de referência não foram alterados.
- O mapa não usa uma grelha rígida 5×5.
- Mar a norte, rio/estuário a oeste, montanhas a este, continuidade urbana a sul e as duas pontes existentes mantêm-se.
- As seis influências culturais permanecem sem associação a bairros, pois a lista definitiva dos 16 bairros culturais não foi recuperada. Não foram inventadas atribuições culturais.
- Não foram criadas novas instalações operacionais fictícias.

## Verificações realizadas
- `tools/preflight_project.py`: **PASS**, 40 verificações aprovadas e 0 falhas.
- JSON dos bairros: 25 entradas, todas com função territorial e coordenadas.
- Coordenadas no JSON e no gerador 3D: 25/25 coincidentes.
- Recursos `res://` e nomes de funções duplicados: sem problemas detetados pelo preflight.

## Limitações
Não foi possível executar a cena no Godot neste ambiente. A validação confirma consistência estática e referências, mas não certifica o aspeto final em tempo real, colisões físicas, desempenho Android nem compilação APK. Os marcos adicionais são geometria procedural simples, não modelos artísticos finais.

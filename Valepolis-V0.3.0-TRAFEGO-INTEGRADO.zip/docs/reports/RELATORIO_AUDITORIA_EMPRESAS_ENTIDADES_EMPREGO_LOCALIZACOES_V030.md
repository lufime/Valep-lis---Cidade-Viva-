# Auditoria cruzada — empresas, entidades, emprego e localizações (V0.3.0)

**Estado: auditoria estática; não equivale a teste runtime/Godot/APK.**

## Resumo

- Empresas propostas: **41** (catálogo inicial, não total definitivo).
- Entidades funcionais catalogadas: **9**.
- Propostas de instalações: **275**, ainda sem edifícios físicos aprovados.
- Endereços existentes no registo: **6250**.
- População distribuída: **1,000,000** em **25 bairros**.

## Controlos estáticos

- **PASS** — `company_ids_unique`: 41 empresas propostas
- **PASS** — `entity_ids_unique`: 9 entidades funcionais no catálogo
- **PASS** — `installation_ids_unique`: 275 propostas de instalações
- **PASS** — `population_total`: Total de população por bairro = 1.000.000
- **PASS** — `neighborhoods_25`: 25 bairros no cadastro populacional
- **PASS** — `company_neighborhoods_exist`: Bairros preferenciais das empresas existem na matriz populacional
- **PASS** — `companies_unbuilt`: Nenhuma empresa foi declarada construída sem aprovação física
- **PASS** — `installations_unbuilt`: Instalações continuam propostas, sem edifício físico atribuído
- **PASS** — `employment_not_invented`: Nenhum trabalhador foi atribuído sem registo de emprego validado

## Empresas por bairro

| Bairro | Habitantes propostos | Empresas propostas | Instalações propostas |
|---|---:|---:|---:|
| Nexora | 80,000 | 10 | 11 |
| Altavira | 48,000 | 2 | 11 |
| Rivéria | 54,000 | 2 | 11 |
| Marévia | 45,000 | 1 | 11 |
| Montélia | 30,000 | 0 | 11 |
| Lúmora | 42,000 | 2 | 11 |
| Florávia | 38,000 | 0 | 11 |
| Pedrália | 32,000 | 0 | 11 |
| Valeora | 48,000 | 3 | 11 |
| Brisamar | 43,000 | 1 | 11 |
| Fontélia | 35,000 | 0 | 11 |
| Silvéria | 40,000 | 0 | 11 |
| Portávia | 36,000 | 3 | 11 |
| Lacéria | 39,000 | 1 | 11 |
| Ventúria | 25,000 | 3 | 11 |
| Olivéria | 34,000 | 2 | 11 |
| Ribeora | 44,000 | 0 | 11 |
| Solária | 50,000 | 3 | 11 |
| Avelora | 35,000 | 0 | 11 |
| Terrávia | 38,000 | 1 | 11 |
| Altória | 28,000 | 1 | 11 |
| Marivora | 39,000 | 2 | 11 |
| Verdelis | 37,000 | 2 | 11 |
| Estúria | 32,000 | 0 | 11 |
| Pedravora | 28,000 | 2 | 11 |

## Campos pendentes no catálogo de empresas

| Campo | Registos por resolver |
|---|---:|
| `address_id_missing` | 41 |
| `building_id_missing` | 41 |
| `owner_id_missing` | 41 |
| `employees_empty` | 41 |
| `job_openings_empty` | 41 |
| `financial_profile_missing` | 41 |

## Conclusões

- The 41 companies are a starter proposal, not the complete citywide company count.
- Company neighborhood assignments are preferred territorial locations only; they do not create physical buildings.
- The 275 installation records are proposals and remain map_spawned=false with building_id=null.
- No employee assignments were invented; company employee lists are empty pending verified job relations.
- The population allocation is approved by the user for integration, but neighborhood land areas are null, so numeric residents/km² cannot be calculated.
- Runtime, Godot import, Android APK and visual map tests were not executed in this environment.

## Próximos passos

1. Audit source catalogues for existing employer/person/job IDs before creating employment links.
2. Approve and validate physical buildings and coordinates for installations.
3. Only after valid employer, person, profession and workplace records exist, create foreign-keyed employment relations.
4. Run Godot headless import and functional tests, then Android export and visual tests.

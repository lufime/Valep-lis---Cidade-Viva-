# Relatório — integração visual 3D e limpeza de placeholders V0.3.0

## Alterações aplicadas ao pacote

- Removidos `assets/characters/` e os painéis placeholder `assets/ui/panel_mapa.png` e `assets/ui/panel_personagem.png`.
- Atualizado `assets/assets_manifest.json` para não declarar a antiga biblioteca de retratos nem os dois painéis removidos.
- Atualizado `assets/assets_index.gd` para deixar de expor um caminho de biblioteca PNG de personagens.
- Atualizado `main.gd`: o painel Personagem usa uma pré-visualização 3D procedural; o painel Mapa usa uma pré-visualização da cena `City3D.tscn`. Os recursos de entidades e restantes painéis continuam preservados.
- Atualizado `systems/city_3d.gd`: edifícios, parques, árvores, ruas locais, passeios, instalações e ligações entre bairros consultam a altura do addon `valepolis_terrain`. As ligações entre bairros são segmentadas para acompanhar melhor o relevo.
- Atualizado `tools/preflight_project.py` com gates que detetam regressões das referências antigas e verificam a integração da geometria com o relevo.
- Atualizado `.github/workflows/build.yml`: remove o modo verbose excessivo da importação e desativa os plugins de editor apenas no checkout efémero do runner antes da importação, para evitar bloqueios na inicialização de plugins. Os scripts dos addons continuam a ser testados diretamente nas etapas próprias. O `project.godot` distribuído permanece com os plugins ativos.

## Verificações executadas neste ambiente

- `bash tools/preflight.sh`: PASS.
- `python tools/preflight_project.py`: PASS, 40 verificações, zero falhas.
- YAML do workflow: parse válido.
- JSON do manifesto: parse válido.
- Referências a Blender: nenhuma encontrada nos ficheiros do pacote analisados.
- Integridade do ZIP final: verificada após criação.

## Limitações não ocultadas

- Não havia executável Godot disponível neste ambiente; não foi possível validar a sintaxe GDScript com o motor, abrir/renderizar a cena nem compilar APK.
- As personagens continuam a ser modelos procedurais estilizados baseados em primitivas; este pacote liga a pré-visualização 3D à interface, mas não implementa ainda rigging e animações humanas avançadas.
- As estradas de ligação são segmentadas por amostras do terreno; é necessária validação visual no Godot para ajustar transições e cruzamentos.
- O workflow foi alterado dentro deste pacote, não diretamente no repositório GitHub.

# Relatório — Frotas, equipas e despacho V0.3.0

## Objetivo
Ligar o despacho multientidade a recursos concretos registados pelos sistemas de cada entidade, sem inventar efetivos, códigos de viaturas ou inventários iniciais.

## Cobertura
BRIGADA, S.U.E., Polícia, TNUR, Município, Hospital, Escola, Comércio e Serviços Públicos têm entrada no registo operacional. Só entidades marcadas como operacionais podem receber despacho. Hospital, Escola e Comércio continuam a ser entidades/localizações, não unidades de despacho.

## Alterações
- `data/entity_operations_registry.json`: modelo de registo por entidade, inicialmente vazio.
- `systems/valepolis_systems_runtime.gd`:
  - `register_entity_resources(...)` regista a base, equipas e viaturas.
  - `dispatch_entity(...)` valida competência, percurso, equipa e viatura disponíveis.
  - `tick(...)` avança o tempo de deslocação abstrato e muda o estado para `on_scene`.
  - `complete_dispatch(...)` conclui a operação e liberta equipa/viatura.
  - `plan_non_urgent_transport(...)` também exige recursos TNUR disponíveis.
- `systems/valepolis_systems_self_test.gd`: cenário de teste com recursos temporários, condicionado ao registo da cidade.

## Limites e próximos passos
- O registo começa vazio de propósito: não foram inventados códigos de viaturas, equipas ou quantidades por entidade.
- A deslocação ainda é temporal/abstrata; não move os modelos 3D e ainda não usa congestionamento por segmento.
- A cedência operacional de ambulância AMBS do S.U.E. à BRIGADA exige um fluxo próprio de acordo e transferência e continua por implementar.
- **Não foi executado no Godot nem compilado APK nesta sessão.** Os resultados indicados são verificações estáticas dos ficheiros.

# Auditoria de compatibilidade — entidades e profissões V0.3.0

- Entidades: 420 registos / 420 IDs únicos.
- Profissões: 800 registos / 800 IDs únicos.
- Compatibilidades: 934 linhas / 934 pares únicos.
- Entidades sem profissão compatível por ID: 0.
- Profissões sem entidade compatível por ID: 0.
- Referências inválidas a entidades: 0.
- Referências inválidas a profissões: 0.
- Nomes de entidades repetidos: 20 (nomes repetidos não significam necessariamente IDs duplicados).
- Nomes de profissões repetidos: 7 (podem ser usados em ramos distintos; requerem revisão semântica).

**Resultado estrutural por ID:** APROVADO.

Esta verificação confirma ligações por identificador, não a adequação semântica de cada ligação.


Fonte canónica no runtime: `data/entity_profession_taxonomy_v3.json`, importada do livro V3.0.0. As quatro entradas de taxonomia relacionadas com TNUR são mantidas na fonte, mas não são apresentadas como entidades independentes; a unidade é gerida dentro da BRIGADA.

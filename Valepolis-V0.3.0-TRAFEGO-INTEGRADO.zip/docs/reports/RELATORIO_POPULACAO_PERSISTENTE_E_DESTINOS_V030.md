# Valepólis V0.3.0 — População persistente, rotinas e destinos

## Objetivo
Evoluir a camada de população para que os agentes individuais mantenham identidade e estado de rotina ao longo do tempo, e distinguir esses agentes da população agregada de referência de 1.000.000 habitantes.

## Alterações desta revisão
- Mantida a referência populacional de 1.000.000, sem a representar como um milhão de modelos 3D simultâneos.
- Mantida a amostra detalhada alvo de 200 agentes individuais e o conjunto de 150 representantes visuais de peões, separados conceptualmente.
- Cada agente individual recebe campos persistentes para bairro de residência, bairro atual, perfil de rotina, atividade, tipo de destino, bairro de destino e estado da deslocação.
- As rotinas mudam por período horário e dia de semana, sem criar moradas, empregadores, famílias, edifícios ou instalações fictícios como se fossem dados aprovados.
- Os destinos sem correspondência num edifício/estabelecimento registado ficam explicitamente como pendentes (`destination_resolved = false`).
- A estrutura de estado já inclui `population_agents` no ficheiro de gravação; os novos campos são guardados através desse registo.
- Foram acrescentadas métricas separadas para população de referência, população agregada e contagens de rotinas/destinos.

## Limitações deliberadas
- Os 200 agentes não equivalem à totalidade dos habitantes.
- Os 150 peões 3D são representantes ambientais locais; ainda não estão ligados individualmente aos 200 agentes persistentes.
- Destinos físicos, moradas, edifícios de trabalho, transportes públicos e rotas porta-a-porta não são inventados. A resolução completa depende de dados de edifícios, endereços e rede transitável.
- Não foi definida distribuição demográfica oficial por bairro.

## Validação
- A alteração de código foi feita estaticamente.
- A presença dos novos campos, da contagem agregada e da gravação de `population_agents` deve ser verificada pelo teste estático do pacote.
- Godot não está disponível nesta sessão; parsing, importação, execução, gravação/carregamento real, desempenho e visualização Android NÃO foram testados.
- Não declarar PRE-FLIGHT aprovado até executar os testes reais no workflow Godot.

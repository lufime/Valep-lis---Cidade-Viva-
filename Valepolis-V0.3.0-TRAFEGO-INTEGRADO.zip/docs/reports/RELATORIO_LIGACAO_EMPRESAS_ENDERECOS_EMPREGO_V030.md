# Auditoria de ligação — empresas, endereços candidatos, edifícios e emprego (V0.3.0)

**Estado:** auditoria estática; não equivale a teste Godot/APK.

## Resultado

- Empresas propostas analisadas: 41.
- Endereços candidatos extraídos do cadastro existente e sem colisão com os IDs de morada usados pelas propostas de instalações: 41.
- Moradas empresariais confirmadas (`address_id`): 0.
- Edifícios físicos empresariais confirmados (`building_id`): 0.
- Relações de emprego confirmadas: 0.
- Instalações criadas no mapa por este processo: 0.

Os candidatos são referências de morada existentes e pertencem ao bairro atribuído à empresa. Permanecem candidatos: não comprovam que exista um edifício comercial adequado naquele local. Os campos `address_id` e `building_id` ficam nulos para não transformar uma hipótese numa localização física aprovada.

## Empresas por setor
- `agricultura`: 2
- `alojamento`: 2
- `comercio`: 4
- `comunicacao_media`: 1
- `construcao`: 3
- `educacao_privada`: 1
- `energia`: 2
- `financas`: 2
- `imobiliario`: 1
- `industria`: 4
- `logistica`: 2
- `mobilidade`: 2
- `restauracao`: 4
- `saude_privada`: 1
- `servicos_pessoais`: 2
- `servicos_profissionais`: 3
- `tecnologia`: 1
- `turismo_lazer`: 4

## Empresas por bairro preferencial
- Altavira: 2 empresas propostas
- Altória: 1 empresas propostas
- Brisamar: 1 empresas propostas
- Lacéria: 1 empresas propostas
- Lúmora: 2 empresas propostas
- Marivora: 2 empresas propostas
- Marévia: 1 empresas propostas
- Nexora: 10 empresas propostas
- Olivéria: 2 empresas propostas
- Pedravora: 2 empresas propostas
- Portávia: 3 empresas propostas
- Rivéria: 2 empresas propostas
- Solária: 3 empresas propostas
- Terrávia: 1 empresas propostas
- Valeora: 3 empresas propostas
- Ventúria: 3 empresas propostas
- Verdelis: 2 empresas propostas

## Emprego

O catálogo `employment_config.json` define estados do ciclo de emprego e regras contratuais, mas o catálogo de empresas não tem vagas verificadas nem IDs de trabalhador atribuídos. Os habitantes persistentes e as profissões não são suficientes, por si só, para concluir que uma pessoa trabalha numa empresa específica. Por isso não foram criados contratos ou trabalhadores fictícios.

## Próximos passos seguros
1. Confirmar geometria/building_id para cada morada candidata e uso compatível do edifício.
2. Confirmar relações de profissão/entidade e vagas antes de criar contratos.
3. Só após validação, preencher `address_id`, `building_id`, `employees` e `job_openings`.
4. Executar Godot headless, testes funcionais, exportação Android e testes visuais.

## Resultado de integridade

- IDs de empresas únicos: PASS.
- Candidatos de endereço únicos: PASS.
- Sem moradas empresariais confirmadas indevidamente: PASS.
- Sem edifícios criados automaticamente: PASS.
- Sem contratos de emprego inventados: PASS.
- Testes runtime Godot/APK: NOT RUN (não declarar aprovação).

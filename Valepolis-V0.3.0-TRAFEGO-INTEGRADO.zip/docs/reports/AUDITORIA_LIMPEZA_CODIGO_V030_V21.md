# Auditoria de limpeza de código — Valepólis V0.3.0 V21

Data: 2026-10-11
Base: Valepolis-V0.3.0-MAPA-25-BAIRROS-V20.zip

## Resultado da verificação estática

- PRE-FLIGHT independente: 19 PASS, 0 FAIL, 3 SKIP; resultado INCOMPLETE.
- 75 ficheiros JSON analisados: válidos.
- Referências literais `res://`: 19 verificadas, sem referências em falta.
- Funções e constantes duplicadas por script: nenhuma encontrada.
- Catálogo e mapa 3D: 25 bairros coincidem.
- Auditoria estrutural da rede rodoviária: terminou com código 0.
- Campos económicos ainda por definir foram preservados; não foram inventados valores.

## Limpeza aplicada

- Removido `docs/workflows/build-alternativo-nao-ativo.yml`, um workflow explicitamente identificado como alternativo/inativo e guardado fora de `.github/workflows/`. O workflow ativo `.github/workflows/build.yml` não foi alterado.
- Preservados relatórios e README históricos versionados para rastreabilidade; não são código executável.
- Não foram apagados scripts GDScript por ausência de referências textuais simples: addons e ferramentas podem ser carregados dinamicamente, pelo editor ou pelo PRE-FLIGHT. Removê-los sem executar o Godot seria inseguro.
- Não foram alteradas regras do jogo, os 25 bairros, os dados de população, os addons de terreno/3D, a interface ou as configurações Android.

## Limitações

Godot 4.x não está instalado neste ambiente. Importação real, execução funcional e exportação APK ficaram SKIP. Por isso o resultado é INCOMPLETE, não PASS. O workflow ativo deve continuar a ser executado no GitHub Actions para validar compilação e APK.

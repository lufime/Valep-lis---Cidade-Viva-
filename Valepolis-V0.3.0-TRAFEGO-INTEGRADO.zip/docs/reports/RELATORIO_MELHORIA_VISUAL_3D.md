# Valepólis V0.3.0 — melhoria visual do mapa e personagens

## Alterações nesta revisão

- Edifícios com footprints variados, perfis de altura diferenciados e janelas distribuídas por fachada.
- Varandas e entradas em parte dos edifícios para quebrar a aparência de blocos uniformes.
- Praças-base mais pequenas para reduzir sobreposição visual entre núcleos de bairros.
- Marcas de faixa nas avenidas principais.
- Personagem procedural com mais variedade de cabelo, orelhas, olhos, sobrancelhas, nariz, boca, camadas de vestuário, bolsos e detalhes de uniforme.
- Normalização da profissão para as classes visuais suportadas (Civil, BRIGADA, SUE, TNUR, Polícia).
- Ajuste moderado da distância e inclinação inicial da câmara.

## Preservação

- Mantida a lista existente dos 25 bairros e as posições existentes.
- Não foi inventada a associação cultural dos 16 bairros.
- Mantidos os dados de simulação e os registos territoriais existentes.

## Validação

- Validação de sintaxe/execução Godot: pendente, pois o executável Godot não está disponível neste ambiente.
- Teste visual em Android e compilação APK: pendentes.
- Esta revisão não deve ser considerada uma aprovação de runtime até executar o projeto e confirmar a cena no dispositivo.

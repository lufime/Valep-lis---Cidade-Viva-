# Relatório — Entidades funcionais V0.3.0

## Implementado neste pacote

- Catálogo canónico de entidades, finalidades, serviços, capacidades, dependências e restrições.
- TNUR definido como unidade integrada na BRIGADA, sem bases independentes.
- APIs runtime para consultar diretório/perfil, atualizar estado operacional, registar serviços e validar o catálogo.
- Casos de autoteste adicionados para a integridade do catálogo e para confirmar que os campos adiados permanecem vazios.
- Interface de gestão limpa de valores fictícios para efetivos, frota, instalações, recursos e orçamento.
- Ações antigas que inventavam valores foram neutralizadas até existir configuração acordada.

## Campos deixados propositadamente em aberto

1. Efetivos e composição de equipas.
2. Economia.
3. Quantidade e distribuição de instalações.
4. Quantidade, modelos e códigos de viaturas.
5. Inventário e consumíveis.
6. Orçamento por entidade.
7. Saldo por entidade.

## Limitações de validação

Foram feitas verificações estáticas dos ficheiros e dos catálogos. Não foi possível confirmar execução no Godot, compilação da APK ou comportamento visual no Android neste ambiente. O catálogo de 420 entidades e 800 profissões ainda requer auditoria semântica de nomes e ramos, embora a cobertura de compatibilidade por ID seja verificada no relatório técnico.

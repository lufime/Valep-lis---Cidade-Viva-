# Relatório — TNUR integrado na BRIGADA (V0.3.0)

Data: 2026-10-08

## Alterações

- O registo de centros TNUR exige o identificador de uma base BRIGADA previamente registada.
- Uma tentativa de registar TNUR como base independente é rejeitada.
- O runtime permite registar múltiplas bases BRIGADA e múltiplos centros TNUR associados às bases anfitriãs.
- Cada centro TNUR fica marcado como `is_independent_base: false` e `parent_entity_id: BRIGADA`.
- Equipas e viaturas TNUR mantêm identificadores operacionais próprios e referência à base BRIGADA anfitriã.
- Os centros TNUR são registados como metadados da base BRIGADA e não aumentam a contagem de bases.
- O self-test inclui casos para rejeição de TNUR independente, registo de duas bases BRIGADA, associação de dois centros TNUR e referências cruzadas.

## Verificações realizadas

- JSON da regra aprovado: válido.
- ZIP de saída: integridade verificada com `testzip`.
- Verificação estática: métodos e condições de validação presentes; testes TNUR presentes no self-test.

## Limitações

- O executável Godot não está disponível neste ambiente; o self-test não foi executado dentro do motor.
- Não foi compilado APK.
- A lógica de runtime está preparada para várias bases BRIGADA, mas a integração visual/gestão de bases na interface ainda precisa de ser ligada e testada.

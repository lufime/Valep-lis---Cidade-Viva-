# Valepólis V0.3.0 — População simulada e densidade visual

## Objetivo
Distinguir a população de referência da cidade (1.000.000 habitantes) dos modelos 3D que podem estar ativos em simultâneo. A cidade não deve ser representada por apenas três peões por bairro.

## Alterações nesta revisão
- Aumentado o conjunto local de peões ambientais de 3 para 6 por bairro: 150 representantes visuais distribuídos pelos 25 bairros.
- Cada representante recebe um identificador técnico estável, bairro e perfil de rotina (`pendular`, `local`, `servicos` ou `lazer`).
- A visibilidade varia com o perfil horário, com curvas diferentes para deslocações pendulares, serviços e lazer.
- Mantido o conjunto atual de 2 veículos ambientais por bairro (50 no total); a variação horária já existente controla a sua visibilidade e velocidade.
- Adicionado `data/population_simulation_v030.json` para explicitar a referência populacional, os limites da representação visual e os testes ainda por executar.

## Limites importantes
- Os 150 peões são representantes visuais técnicos, não a população total e não uma decisão demográfica oficial por bairro.
- Os IDs são estáveis dentro da geração da cena, mas ainda não constituem um sistema completo de persistência em gravações, nem associam todos os habitantes a moradas, famílias, emprego, relações e destinos individuais.
- As rotinas locais são perfis simplificados; não há ainda simulação global de casa-trabalho, transporte público ou pathfinding de todos os habitantes.
- Não foi alterado o número de referência de 1.000.000 habitantes.

## Validação
- Alteração estática do código efetuada.
- Godot não está disponível nesta sessão: parsing/importação, execução, desempenho e visualização Android NÃO foram testados.
- Não declarar PRE-FLIGHT aprovado até executar esses testes no workflow Godot.

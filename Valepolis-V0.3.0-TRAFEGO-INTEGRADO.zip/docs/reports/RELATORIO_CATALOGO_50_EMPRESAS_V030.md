# Catálogo de 50 empresas — Valepólis V0.3.0

Estado: **proposta de catálogo**, não prova de empresas operacionais no jogo.

- Empresas no catálogo: **50**
- IDs únicos: **50**
- Setores: **18**
- Bairros preferenciais preenchidos: **50**
- Moradas físicas confirmadas: **0**
- Edifícios físicos confirmados: **0**
- Trabalhadores atribuídos: **0**
- Empresas colocadas automaticamente no mapa: **0**

## Novas empresas adicionadas

- **Residencial Vale Vivo** — gestão de condomínios e serviços residenciais — Valeora.
- **Cooperativa dos Campos de Valepólis** — cooperativa agrícola, recolha e distribuição de produção — Olivéria.
- **Distribuição Ponte Norte** — distribuição urbana e abastecimento de comércio — Portávia.
- **Laboratório Nexora Digital** — desenvolvimento de software e serviços digitais — Nexora.
- **Manutenção Energética do Vale** — manutenção técnica e eficiência energética — Ventúria.
- **Padaria Trigo da Ribeira** — padaria, pastelaria e fabrico alimentar local — Ribeora.
- **Mobilidade Valepólis** — serviços privados de mobilidade e gestão de frota — Solária.
- **Lavandaria Brisa Limpa** — lavandaria e limpeza têxtil — Brisamar.
- **Estalagem Caminhos do Estuário** — alojamento turístico de pequena dimensão — Estúria.

## Regras de integridade

- Foram preservados os 41 registos anteriores e acrescentados 9 novos, sem substituir IDs existentes.
- As novas empresas não receberam moradas, edifícios, proprietários, trabalhadores, salários ou valores financeiros inventados.
- Os bairros são localizações preferenciais de proposta; não confirmam uma implantação física.
- A execução Godot e a compilação APK não foram testadas nesta atualização.

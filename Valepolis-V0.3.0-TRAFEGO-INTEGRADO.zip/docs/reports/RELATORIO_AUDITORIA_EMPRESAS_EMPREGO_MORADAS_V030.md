# Auditoria de empresas, emprego e moradas — Valepólis V0.3.0

**Estado:** auditoria estática; não é declaração de sistema funcional nem teste Godot.

## Ficheiros examinados
- `data/entity_master_catalog.json`
- `data/installation_registry_v030.json`
- `data/economy_config.json`
- `data/catalogo_v3.json`
- `data/enderecamento_valepolis.json`
- `data/population_simulation_v030.json`
- `main.gd`

## Resultados confirmados
- Catálogo mestre: **9 tipos de entidades funcionais**, incluindo COMERCIO como tipo de entidade, não um cadastro de empresas individuais.
- Catálogo taxonómico: **41 ramos, 220 subcategorias, 800 profissões, 420 entradas de entidades e 934 relações de compatibilidade**. Estas entradas são taxonomia, não empresas com instalações e trabalhadores.
- Registo de instalações: **275 propostas**; estado global `proposta_de_trabalho_nao_oficial`. Os registos declaram `building_id` por preencher, `map_spawned=false` e `record_status=proposta_nao_oficial_nao_criada_no_mapa` nos exemplos. Não devem ser tratados como empresas/edifícios construídos.
- Moradas: **125 ruas e 6250 moradas de referência**. O próprio ficheiro assinala códigos/moradas como dados fictícios para uso interno; a morada, por si só, não prova que exista empresa nesse edifício.
- Economia: `configured=False`, `status=awaiting_owner_definition`. A economia não está configurada para transações reais.
- População: o código mantém campos `profession`, `employment`, `destination_id`, `destination_type` e `destination_resolved`, mas o fluxo principal ainda usa valores como `employment="por_definir"` e tipos de destino `trabalho_ou_estudo_por_atribuir` / `servico_por_atribuir` quando não existe destino ligado.

## Falhas de integração identificadas
1. **Não foi encontrado um cadastro autónomo de empresas individuais** com ID permanente, nome próprio, atividade, titular/gestor, estado operacional e ligação a uma instalação física aprovada.
2. **Emprego sem ligação concreta:** os agentes persistentes não têm, por regra, `employer_id`/ID de empresa resolvido nem local de trabalho validado.
3. **Catálogo não é cadastro operacional:** os 420 registos taxonómicos de entidades não devem ser convertidos automaticamente em 420 empresas.
4. **Instalações são propostas:** não criar objetos 3D nem atribuir pessoal/receitas/capacidade até aprovação e ligação a `building_id`/coordenadas.
5. **Economia pendente:** não gerar salários, receitas, despesas, impostos ou saldos simulados enquanto `economy_config.json` continuar por configurar e as regras quantitativas não forem aprovadas.
6. **Morada sem georreferenciação operacional:** o registo de moradas não garante por si só coordenadas de edifício, acessos ou percurso rodoviário transitável.

## Próxima implementação segura
- Criar um `company_registry_v030.json` **apenas a partir de empresas explicitamente presentes em fontes aprovadas**. Se não existir fonte aprovada para empresas individuais, manter o registo vazio e emitir lista de dados em falta; não inventar nomes.
- Campos de contrato sugeridos para integração futura: `company_id`, `legal_or_display_name`, `activity_id`, `installation_id`, `address_id`, `building_id`, `operational_status`, `owner_id` e `source_record_id`. Campos sem fonte ficam `null`/pendentes, não estimados.
- Adicionar a agentes `employer_id`, `job_id` e `workplace_installation_id` apenas quando a compatibilidade profissão-entidade, a morada e a instalação física forem verificadas.
- Manter emprego e economia como pendentes quando faltarem dados; sem receitas, salários ou contratação fictícios.
- Fazer sincronização visual só para instalações aprovadas com objeto 3D e coordenadas válidas; depois validar as rotas no Godot.

## Verificações realizadas
- Leitura e análise estrutural dos JSON indicados: concluída.
- Pesquisa estática no `main.gd` por campos de emprego, empregador, destino e profissão: concluída.
- Execução de Godot, teste de runtime, teste de persistência e APK: **NÃO EXECUTADOS** neste relatório.

## Conclusão
O projeto já contém taxonomia de entidades/profissões, propostas de instalações, moradas e campos parciais de emprego. A auditoria não encontrou prova suficiente de um cadastro operacional de empresas individuais ou de ligações resolvidas entre empresa, instalação, trabalhador e destino 3D. A correção seguinte deve primeiro recuperar/identificar a fonte aprovada das empresas existentes; não deve fabricar um cadastro para mascarar a lacuna.

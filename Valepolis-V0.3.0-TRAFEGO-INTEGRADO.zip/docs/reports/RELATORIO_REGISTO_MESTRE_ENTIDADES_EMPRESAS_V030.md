# Relatório — Registo Mestre de Entidades e Empresas V0.3.0

## Objetivo
Criar um índice transversal que facilite a auditoria e integração dos catálogos existentes sem os fundir nem criar relações não comprovadas.

## Fontes cruzadas
- Catálogo de empresas propostas: 41
- Entidades funcionais no registo mestre: 9
- Tipos de entidade na taxonomia: 420
- Profissões: 800
- Relações profissão-entidade: 934
- Propostas de instalações: 275
- Bairros: 25
- População proposta total: 1,000,000

## O que foi feito
Criado `data/master_registry_v030.json`, um índice por bairro com IDs das empresas que têm esse bairro preferencial e IDs das propostas de instalações registadas nesse bairro. As referências apontam para os ficheiros de origem; não duplicam os registos completos.

Criado `tools/validate_master_registry.py` para verificar IDs únicos, 25 bairros, total populacional, bairros das empresas e contagens cruzadas.

## Limites importantes
- Os 41 registos continuam a ser propostas de empresas, não um universo empresarial definitivo.
- Os 275 registos são propostas de instalações; `map_spawned=false`/estado proposto não equivale a edifício operacional.
- Os tipos de entidade (taxonomia) não são automaticamente organizações concretas.
- Não foram atribuídos trabalhadores, empregadores, edifícios, coordenadas, salários ou transações sem fonte válida.
- Este índice não é ligado ainda ao runtime Godot; validação de execução e APK continuam pendentes.

## Próximas integrações
1. Resolver cada entidade funcional contra os tipos da taxonomia por ID e regra explícita, mantendo distinção entre categoria e organização.
2. Validar propostas de instalação contra edifícios físicos e moradas aprovadas.
3. Só depois associar empresas/entidades a instalações concretas.
4. Associar habitantes a empregadores apenas quando existir registo de emprego; não gerar relações artificiais.
5. Executar preflight no Godot e validar save/load e APK Android.

# Valepólis Terrain — geografia automática

Referência geográfica do addon próprio:

- Norte (Z negativo): mar e praias; o plano de água norte já está em `systems/city_3d.gd`.
- Oeste (X negativo): rio/estuário; o canal visual existente está centrado em X=-51.
- Centro: planície de baixa inclinação para preservar os 25 bairros e as estradas existentes.
- Este (X positivo): montanhas, cristas e vales; Pedravora ocupa a transição montanhosa, com arquitetura rochosa e volumes escalonados.
- Sul (Z positivo): colinas e transição para Santo André do Vale e Portela do Sul.

O addon calcula o relevo automaticamente a partir destas zonas e de ruído determinístico. Não foram inventadas coordenadas novas para os bairros, pontes ou instalações. Como Valepólis é uma geografia fictícia, não se afirma que o relevo derive de dados topográficos reais.

Validação pendente: abrir no Godot 4.5, executar `City3D.tscn`, verificar alinhamento visual do terreno/água/estradas, colisões e exportação Android.


## Distribuição territorial dos 25 bairros — mapa 3D V0.3.0

A colocação visual foi alinhada com o significado dos nomes e com a geografia aprovada:
- Norte: Marévia e Brisamar junto à costa; Marivora na transição entre costa e estuário.
- Oeste: Rivéria e Ribeora nas margens fluviais; Portávia junto ao estuário para porto/logística; Estúria junto às zonas húmidas do estuário.
- Centro: Nexora como núcleo metropolitano; Altavira, Lúmora, Valeora, Fontélia e Olivéria em continuidade urbana.
- Este: Montélia nas encostas; Altória em cota elevada; Ventúria junto à zona montanhosa; Pedrália e Pedravora com caráter pétreo, sendo Pedravora a transição montanhosa.
- Sul e sudeste: Florávia, Solária, Lacéria, Terrávia, Avelora e Verdelis compõem a transição verde, recreativa, residencial e de expansão.

As coordenadas X/Z em `bairros_valepolis.json` são coordenadas de composição visual do mapa 3D, não coordenadas geográficas reais. A distribuição cultural de seis influências permanece sem atribuição a bairros, conforme a regra existente; esta alteração não inventa essa associação.

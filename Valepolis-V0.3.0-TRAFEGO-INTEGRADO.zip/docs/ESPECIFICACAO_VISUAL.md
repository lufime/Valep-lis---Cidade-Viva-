# V0.3.0 — Especificação visual do gerador

O gerador passa a ter como alvo o nível visual da referência aprovada:

**3D cartoon realista de videojogo**

Não é pixel art e não é um boneco 2D simplificado.

### Características
- personagem humano de corpo inteiro;
- anatomia estilizada mas credível;
- rosto expressivo;
- cabelo e roupa detalhados;
- profissões reconhecíveis;
- iluminação natural/cinematográfica;
- materiais de videojogo;
- ambientes de Valepólis;
- animações fluidas;
- câmara a três quartos quando usada para previews.

### Anti-clones
Cada personagem recebe:
- identidade visual própria;
- proporções próprias;
- variante facial;
- cabelo;
- roupa;
- acessórios;
- postura;
- velocidade;
- passada;
- balanço dos braços;
- gestos;
- timing de idle;
- variantes de animação.

A mesma animação base pode ser partilhada pelo motor, mas o resultado final não deve ser visualmente idêntico entre personagens.

### Animações
Walk, Run, Idle, Talk, Phone, Sit, Work, Drive, Rescue,
Fire Response, Medical Response e Enter/Exit.

Os assets finais devem ser produzidos/importados como arte de qualidade de videojogo.
Os antigos placeholders pixelizados não fazem parte da arte final.

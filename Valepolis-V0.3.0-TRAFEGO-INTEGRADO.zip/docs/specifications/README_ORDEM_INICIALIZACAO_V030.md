# V0.3.0 — Correção da ordem de inicialização

## Alteração
A ordem canónica foi corrigida para:

1. calendário/relógio;
2. carregamento e inicialização do mundo;
3. inicialização do `ValepolisSystemsRuntime`;
4. sincronização do estado completo para o runtime;
5. construção/atualização da UI.

O `_ready()` do runtime deixou de inicializar automaticamente. A cena principal é agora a autoridade da ordem de inicialização.

## Objetivo
Evitar que o runtime receba um estado temporal incompleto/antigo antes de `main.gd` inicializar o relógio e o estado inicial da cidade.

## Limitação
Esta alteração foi verificada estaticamente. O Godot não foi executado neste ambiente, portanto não constitui teste de runtime ou APK.

# Registo oficial de aprovação global — Valepólis V0.3.0

**Estado da decisão:** APROVADO pelo utilizador em 2026-10-13.
**Âmbito:** integrar todas as propostas e regras pendentes documentadas que não contradigam decisões oficiais anteriores.

## Regras preservadas

- Versão de referência: Valepólis V0.3.0 — Cidade Viva.
- Cidade: 1.000.000 habitantes de referência e 25 bairros oficiais.
- Influências culturais: portuguesa, italiana, alemã, francesa, africana e asiática; a atribuição territorial definitiva só pode seguir a matriz documental existente.
- Organizações: BRIGADA, S.U.E., TNUR integrado nas bases BRIGADA e Polícia; não criar bases TNUR independentes.
- Progressão: 200 episódios em 20 temporadas, 10 episódios por temporada.
- A cidade autónoma, as suas relações e a simulação não são reiniciadas quando muda a perspetiva ou a progressão narrativa.
- Instalações propostas e efetivos não aprovados não são criados no mapa nem convertidos em dados operacionais.
- Preservar a interface e os dados já aprovados; não reintroduzir sistemas antigos nem alterar decisões anteriores por suposição.

## Aprovação da organização modular

Fica aprovada a organização dos conteúdos narrativos por temporadas, com manifesto e validação de integridade por temporada. A aprovação não autoriza remover conteúdo do pacote completo, nem declarar um mecanismo de transferência/instalação dinâmica Android como concluído sem implementação e teste específicos.

## Critérios obrigatórios de aceitação

1. O PRE-FLIGHT só pode emitir PASS para verificações efetivamente executadas.
2. O mapa 3D só pode ser considerado funcional quando o `SubViewport` está ativo, atualizado continuamente, contém a cidade e uma câmara ativa e a renderização é confirmada por teste apropriado.
3. A presença de nós ou ficheiros, por si só, não prova renderização, circulação, jogabilidade ou qualidade visual.
4. A exportação e a validação Android só podem ser declaradas após exportação bem-sucedida e teste correspondente.
5. Falhas devem permanecer explícitas no relatório; não podem ser ocultadas, ignoradas ou transformadas em PASS.
6. Nenhuma quantidade, instalação, efetivo, valor económico ou objetivo narrativo em falta deve ser inventado para preencher lacunas documentais.

## Estado técnico registado nesta integração

- Foi corrigida a ordem de configuração do `SubViewport`: a atualização contínua é configurada antes do retorno antecipado quando a cidade já existe na cena.
- Foi acrescentada uma verificação funcional para a atualização contínua, instância da cidade, câmara ativa, visibilidade e dimensões do viewport.
- Esta correção ainda exige execução do workflow Godot 4.5 e inspeção visual em Android. Este documento não declara a renderização visual nem a APK aprovadas.
- Os 200 episódios continuam sujeitos a auditoria de objetivos e condições de conclusão por episódio; títulos e duração variável não são, isoladamente, prova de conteúdo jogável completo.

## Registo de alterações

| Data | Alteração | Estado |
|---|---|---|
| 2026-10-13 | Aprovação global das propostas documentadas pendentes | Aprovado pelo utilizador |
| 2026-10-13 | Corrigida configuração antecipada do `SubViewport` e ativação da câmara | Implementado no código; runtime pendente |
| 2026-10-13 | Adicionado teste funcional de regressão do mapa | Implementado no código; CI pendente |
| 2026-10-13 | Instalação modular por temporadas | Organização aprovada; transferência dinâmica Android não declarada concluída |

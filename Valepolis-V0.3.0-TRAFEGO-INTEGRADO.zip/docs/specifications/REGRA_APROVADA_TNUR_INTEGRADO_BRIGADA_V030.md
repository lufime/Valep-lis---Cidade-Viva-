# Regra aprovada — integração do TNUR na BRIGADA

**Projeto:** Quando Toca a Sirene — Valepólis V0.3.0  
**Estado:** Aprovada pelo utilizador em 8 de outubro de 2026

## Regra obrigatória

1. Todos os centros e pontos operacionais do Transporte Não Urgente (TNUR) estão incorporados em bases da BRIGADA.
2. Não existem bases TNUR independentes, nem o TNUR é contabilizado como entidade institucional separada.
3. O TNUR conserva equipas, viaturas, escalas, inventário e planeamento operacional próprios.
4. Um centro TNUR só pode ser atribuído a uma base BRIGADA existente; a localização não pode ser tratada como uma base autónoma.
5. Os centros TNUR não se somam ao número de bases BRIGADA. Se houver 13 bases BRIGADA, o TNUR pode operar em algumas ou em todas essas mesmas bases, sem elevar esse total.
6. A quantidade de centros TNUR ativos depende das bases BRIGADA designadas para o serviço e da necessidade operacional.
7. O despacho técnico pode identificar recursos TNUR separadamente para aplicar as regras de transporte não urgente; essa separação técnica não altera a estrutura institucional.

## Estado da implementação

A regra está registada na configuração operacional. O registo técnico mantém a categoria TNUR para identificar recursos e validar despachos. Esta alteração documental/configuracional, por si só, não comprova que o runtime já bloqueie todas as localizações TNUR independentes; essa validação exige alteração e teste específicos no código. Não foi executado teste do motor Godot nem compilação APK nesta alteração.


## Validação técnica do runtime

- O runtime rejeita o registo de TNUR sem uma base BRIGADA anfitriã existente.
- É possível registar várias bases BRIGADA e vários centros TNUR, sempre associados a uma base anfitriã.
- Os centros TNUR são metadados internos da base BRIGADA; não contam como bases adicionais.
- Equipas e viaturas TNUR mantêm identificadores operacionais próprios, com referência à base BRIGADA anfitriã.
- Foram adicionados testes automáticos ao self-test do runtime para rejeição de base independente, registo de múltiplas bases e associação dos centros.
- Limitação de verificação: o executável Godot não está disponível neste ambiente; os testes do runtime ainda não foram executados.

# Integração total V0.3.0

Este pacote liga o `Main.tscn` ao runtime canónico e ao catálogo de dados/narrativa.

Fluxo canónico:
`UI -> main.gd -> ValepolisSystemsRuntime -> data/*.json + catálogo de episódios -> estado da cidade`

A cidade 3D é registada no runtime quando é criada pelo `main.gd`.

O catálogo `data/episodes_200.json` contém os 200 episódios (20 temporadas x 10), com duração variável.

## Limitação
A integração foi feita e auditada estaticamente. Não foi possível executar Godot, compilar APK ou validar o runtime Android neste ambiente.

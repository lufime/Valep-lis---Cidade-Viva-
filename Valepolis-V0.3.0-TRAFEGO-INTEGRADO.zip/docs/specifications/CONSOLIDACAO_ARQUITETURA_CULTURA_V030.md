# Consolidação de arquitetura e cultura — V0.3.0

- O Godot gera automaticamente os edifícios comuns, personagens e recursos modulares através de código próprio.
- A identidade arquitetónica varia por bairro, incluindo cores, pisos, proporções e geometria.
- A geração de terreno é responsabilidade do addon `valepolis_terrain`.
- O addon `valepolis_3d_studio` fornece a geração procedural de personagens e edifícios.
- A exportação para Android depende de testes reais de importação, runtime, desempenho e assinatura.

A primeira versão do gerador de personagens utiliza malhas primitivas e ainda necessita de rigging, animações e validação artística avançada.

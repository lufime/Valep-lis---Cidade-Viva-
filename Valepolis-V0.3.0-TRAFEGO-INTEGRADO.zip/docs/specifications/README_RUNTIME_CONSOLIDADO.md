# Quando Toca a Sirene — V0.3.0 Runtime Único Consolidado

Alterações desta consolidação:
- `ValepolisSystemsRuntime` passou de Autoload para nó direto de `Main.tscn`.
- `main.gd` usa a referência `v030_runtime` para inicialização e ticks.
- Removida a referência `/root/ValepolisSystems`.
- Removidas declarações globais duplicadas detetadas no bloco de integração expandida.
- Mantidas separadas as camadas de save de sessão/UI e world-core, porque fundi-las sem um migrador poderia provocar perda de estado.

Estado: auditoria estática. Não foi executado Godot nem exportado/testado um APK neste ambiente.

# Valepólis V0.3.0 — Remodelação Fase 12

## Alteração
Corrigida a atualização vertical dos agentes móveis em `systems/city_3d.gd`: os veículos mantêm o centro da carroçaria a 0,18 unidades acima do terreno em cada frame, em vez de perderem essa altura após o primeiro movimento. Os peões continuam ao nível do terreno, com pequena oscilação visual.

## Limites
Foi feita inspeção estática do código. Não foi possível executar o projeto com Godot neste ambiente; não se declara validada a aparência em execução, a transitabilidade das ruas nem a compilação APK.

# Valepolis V0.3.0 — Circulacao V16

Continua a partir da V15. Integra a auditoria estrutural da rede rodoviaria regional no runner principal `tools/preflight.py`, para que o PRE-FLIGHT execute `tools/preflight_regional_roads.py` quando o ficheiro estiver presente. O verificador inclui agora verificacoes estruturais para a API de diagnostico de rotas e para o uso de arestas rejeitadas pela heuristica.

## Interpretacao correta
- A auditoria e estatica: confirma presenca de elementos no codigo, nao a sua execucao nem a geometria real no mapa.
- O PRE-FLIGHT deve continuar a marcar importacao Godot, teste funcional e exportacao APK como SKIP/INCOMPLETE quando Godot nao estiver disponivel.
- A rede ainda nao tem validacao fisica completa de agua, instalacoes, arvores, colisao, continuidade das pontes ou transito real.

## Validacao deste pacote
ZIP verificado quanto a integridade e os scripts Python alterados verificados com `py_compile`. Nao foi executado Godot, nao foi compilado o projeto e nao foi exportada APK.

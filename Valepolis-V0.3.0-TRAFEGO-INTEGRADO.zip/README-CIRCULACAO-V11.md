# Valepólis V0.3.0 — Circulação V11

Continua a partir da V10. Acrescenta duas funções para integração controlada com os agentes móveis existentes:

- `get_ambient_vehicle_indices()` devolve os índices dos veículos ativos.
- `assign_vehicle_route(agent_index, origin, destination, reverse_route = false)` atribui explicitamente a um veículo os waypoints devolvidos pela rede rodoviária. Não redireciona toda a frota automaticamente.

Limitações: os eixos entre bairros continuam lineares e podem atravessar obstáculos; a função não executa validação física nem trata paragens, cruzamentos, semáforos ou pontes transitáveis. O percurso atribuído percorre os pontos e não garante um retorno automático ao ponto de origem. Integridade do ZIP verificada, mas o projeto não foi executado no Godot; compilação e comportamento por validar.

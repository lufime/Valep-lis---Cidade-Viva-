# Valepólis V0.3.0 — referência visual do mapa dos 25 bairros

Foi integrada a imagem `images/mapa_25_bairros_isometrico.png` como referência visual da cidade, com os 25 nomes oficiais, costa a norte, rio/estuário a oeste e relevo montanhoso a este.

## Integridade das regras
- A imagem é uma referência visual; não substitui o terreno 3D dinâmico nem a matriz territorial oficial.
- As posições e funções dos bairros em `bairros_valepolis.json` e `systems/city_3d.gd` foram preservadas.
- Não foram atribuídas culturas aos 16 bairros, porque a distribuição definitiva não está confirmada.
- A imagem de introdução `images/intro_valepolis.png`, a interface aprovada, os dados, as regras e o workflow foram preservados.

## Limite da aplicação
Esta integração adiciona o mapa ilustrado ao projeto como recurso. Não afirma que a imagem esteja ligada a um botão/visor no jogo nem que o mapa 3D tenha sido validado em Godot/Android. A validação visual e funcional em runtime continua pendente.

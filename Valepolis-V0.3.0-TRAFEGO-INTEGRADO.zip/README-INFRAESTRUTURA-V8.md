# Valepólis V0.3.0 — Circulação V8

Baseado na V7, preservando os restantes ficheiros. Acrescenta uma primeira regra de seguimento longitudinal entre veículos dos percursos locais: quando outro veículo está próximo, à frente e aproximadamente alinhado, a velocidade é reduzida progressivamente.

Limitações: não é física de colisão, não garante distância segura em todas as situações e não trata cruzamentos, prioridades, peões, semáforos ou pathfinding global. Os agentes continuam a usar circuitos locais predefinidos. Integridade do ZIP verificada; não executado no Godot, pelo que compilação e comportamento real precisam de teste.

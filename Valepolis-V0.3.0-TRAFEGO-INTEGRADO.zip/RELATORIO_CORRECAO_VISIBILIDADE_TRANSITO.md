# Valepólis V0.3.0 — Correção parcial da visibilidade do trânsito

## Alteração aplicada
- A seleção determinística de carros visíveis deixa de favorecer apenas os primeiros índices da frota.
- A circulação residual noturna passa a manter um mínimo de veículos visíveis; ao fim de semana também se preserva um mínimo.
- Não são criados veículos adicionais por este ajuste e não são alteradas regras de população ou de entidades.

## Limites importantes
Esta alteração procura corrigir o sintoma de ausência visual de carros nas capturas, mas não prova a circulação rodoviária funcional. Os veículos continuam a usar percursos locais simplificados; não existe comprovação aqui de pathfinding global, semáforos, colisão rodoviária ou ligação de todos os bairros. A ampliação da cidade e a remodelação de relevo/infraestrutura exigem alteração coordenada da geometria do terreno, estradas, pontes, edifícios, câmara e limites de movimento; não foram declaradas como concluídas.

## Validação
- Verificação textual do bloco de seleção de veículos: realizada.
- Execução no Godot 4.5: não realizada neste ambiente.
- APK Android: não exportada nem testada.
- Workflow `.github/workflows/build.yml`: não alterado nesta correção.

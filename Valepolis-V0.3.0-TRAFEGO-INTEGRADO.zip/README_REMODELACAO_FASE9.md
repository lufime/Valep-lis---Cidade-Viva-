# Valepólis V0.3.0 — Remodelação Fase 9

## Correção
Corrigida a condição de criação dos veículos locais em `systems/city_3d.gd`. O teste anterior chamava `_road_safe_position()` para posições intencionalmente colocadas nas ruas; essa função devolve falso precisamente nos corredores viários reservados, pelo que podia descartar os veículos antes de os criar.

A condição foi substituída por uma verificação de limites da área jogável. A criação continua limitada aos quatro veículos previstos por bairro, quando a posição está dentro desses limites.

## Limitações
Esta é uma correção estática de uma condição de geração. Não confirma que os 100 veículos apareçam todos, que os percursos sejam contínuos, nem que não haja colisões. A execução no Godot e a exportação Android não foram realizadas neste ambiente.

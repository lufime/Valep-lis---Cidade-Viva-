# Valepólis V0.3.0 — Limites territoriais virtuais

## Resultado

Foram calculados 25 polígonos territoriais operacionais no terreno virtual a partir dos centros X/Z já existentes em `bairros_valepolis.json`. A área de cada bairro é calculada matematicamente pelo polígono resultante, não por estimativa de densidade.

- Método: células de Voronoi, recortadas aos limites X=[-50, 50] e Z=[-45, 45].
- Escala espacial derivada: 0.236206 km por unidade do mundo.
- Extensão equivalente: 23.621 × 21.259 km.
- Área total repartida pelos 25 bairros: 502.14 km².
- População total: 1.000.000.
- Densidade média calculada: 1 991 hab./km².
- Limites: guardados em `data/limites_bairros_v030.json`.
- Matriz de densidade atualizada: `data/matriz_territorial_densidade_v030.json`.
- O mapa 3D desenha linhas discretas para mostrar os limites territoriais.

## Importante

Estes são limites operacionais para a cidade fictícia, calculados no terreno virtual. Não são fronteiras geográficas reais. A partição cobre o retângulo inteiro e, por isso, a área calculada inclui a totalidade do território repartido; a água, a costa e as áreas não edificáveis ainda não foram subtraídas bairro a bairro. A geometria precisa de validação visual no Godot 4.5, especialmente junto ao estuário, à costa, às montanhas, às estradas e às pontes.

A regra de máximo de 15 pisos na zona central não é automaticamente aplicada a todo o bairro Nexora. A fronteira própria da zona central continua a precisar de polígono separado.

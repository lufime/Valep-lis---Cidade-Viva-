# Valepólis V0.3.0 — Circulação V9

Continua a partir da V8. Acrescenta `get_vehicle_waypoints_between_neighborhoods(origin, destination)` em `systems/city_3d.gd`: consulta o grafo rodoviário, devolve o percurso entre bairros e converte cada nó em coordenadas 3D com altura do terreno. Em caso de origem/destino inválido, devolve erro e lista de pontos vazia.

Limitação essencial: esta API cria pontos de referência pelos centros dos bairros, não trajetórias de condução alinhadas com todas as estradas. Não foi ligada automaticamente aos agentes móveis existentes porque esses agentes usam circuitos locais próprios. É necessário gerar pontos a partir da geometria real das vias, tratar obstáculos/ponte e validar no Godot antes de usar em trânsito real.

Verificação: integridade do ZIP. Não executado no Godot; sintaxe, tipos, compilação e comportamento continuam por validar.

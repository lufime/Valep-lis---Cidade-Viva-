# Valepólis V0.3.0 — Território e áreas exteriores separados

## Decisão cartográfica aplicada

O mapa passa a distinguir explicitamente:

- **Território dos 25 bairros:** 502,1398 km² (502,14 km² arredondados).
- **Áreas exteriores não atribuídas a bairros:** 73,86 km².
- **Área total cartográfica:** 576,00 km².
- **População:** 1.000.000 habitantes.
- **Densidade média nos bairros:** aproximadamente 1.991 habitantes/km².
- **Dimensão total aproximada:** 24,802 × 23,224 km.

## Limites

Os 25 polígonos ocupam o retângulo interior X=[-50,50], Z=[-45,45]. O mapa total foi expandido para X=[-52,5,52,5], Z=[-49,161019,49,161019]. As faixas exteriores são separadas dos bairros:

| Área exterior | Tipo | Área |
|---|---|---:|
| Costa e mar norte | Água/costa, inclui cantos norte | 24,3765 km² |
| Estuário e margem oeste | Água/estuário | 12,5535 km² |
| Margem montanhosa exterior | Terreno não atribuído a bairro | 12,5535 km² |
| Transição sul e margens exteriores | Terreno não atribuído a bairro, inclui cantos sul | 24,3765 km² |
| **Total exterior** | | **73,86 km²** |

A soma fecha: 502,1398 km² + 73,86 km² = 575,9998 km², arredondado a 576,00 km².

## Alterações no projeto

- `data/limites_bairros_v030.json`: limites interiores, limites exteriores e áreas separadas.
- `data/matriz_territorial_densidade_v030.json`: áreas/densidades sincronizadas com os polígonos calculados.
- `systems/city_3d.gd`: mar norte e estuário oeste posicionados nas faixas exteriores em vez de ficarem afastados do mapa territorial.
- Este relatório documenta o cálculo e os limites.

## Estado da validação

Validados por script: JSON, 25 bairros, população total, áreas exteriores, soma de áreas e integridade do ZIP.

**Pendente:** execução visual no Godot 4.5 e confirmação de que o terreno, as estradas, as pontes, o estuário e o mar encaixam corretamente. As áreas são medidas no sistema de coordenadas virtual do jogo; não são um levantamento geográfico real. Os polígonos de Voronoi continuam a ser uma divisão operacional baseada nos centros existentes, não limites urbanísticos desenhados manualmente.

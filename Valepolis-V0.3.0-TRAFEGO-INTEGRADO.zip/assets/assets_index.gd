extends Resource
class_name ValepolisAssets

const ENTITY_DIR := "res://assets/entities/"
const UI_DIR := "res://assets/ui/"

static func entity(id: String) -> String:
    return ENTITY_DIR + id + ".png"

static func panel(id: String) -> String:
    return UI_DIR + "panel_" + id + ".png"

# Valepólis V0.3.0 — Remodelação Fase 4

## Alterações de código
- Alargadas as vias locais geradas em cada bairro, de modo a melhorar a leitura visual e reservar mais espaço de circulação.
- Alargados os passeios locais correspondentes para acompanhar a nova largura das vias.
- Aumentada a largura nominal das ligações entre bairros: vias principais 4,2 unidades base e secundárias 3,2 unidades base, antes do fator de expansão global.
- Mantida a lista dos 25 bairros, o grafo rodoviário, as duas pontes e os dados territoriais existentes.

## Validação
- Verificação textual das alterações: realizada.
- Integridade do ZIP: validada no empacotamento.
- Importação/execução Godot 4.5: não realizada (executável indisponível neste ambiente).
- Colisões edifício/estrada, ligação física de pontes, trânsito em movimento, FPS e APK: não testados.

## Limites
Esta fase melhora dimensões nominais das vias, mas não prova ausência de sobreposições com edifícios, água ou relevo. A expansão espacial dos 25 bairros e a reconstrução individual de quarteirões continuam a exigir validação visual no motor.

# Valepólis V0.3.0 — Circulação V12

Continua a partir da V11. Cada ligação rodoviária amostrada passa por uma heurística de declive entre pontos adjacentes. A função de percurso rejeita segmentos que excedam o limite configurado (0,45 unidades verticais por unidade horizontal), em vez de devolver silenciosamente uma rota potencialmente íngreme.

Limitações críticas: é apenas uma verificação heurística de relevo. Não deteta interseções com água, edifícios, instalações, tráfego ou falhas geométricas; também não valida fisicamente pontes. Pode rejeitar segmentos que seriam transitáveis e aceitar outros que não o são. A verificação não foi executada no Godot; ZIP apenas verificado quanto à integridade.

# Valepólis V0.3.0 — Infraestrutura e circulação visual V7

Base: pacote V6, com os restantes ficheiros preservados. Ajusta a atualização dos agentes móveis em `systems/city_3d.gd`: limita o deslocamento por frame e suaviza a rotação entre waypoints, mantendo a atualização de altura do terreno já existente.

Limitações: os percursos dos veículos continuam a ser circuitos locais predefinidos, não uma rede global calculada a partir da geometria de todas as estradas. Não foram adicionados semáforos funcionais, colisões de trânsito, travagem por obstáculos nem regras completas do Código da Estrada. Não executado no Godot; compilação, movimento, orientação e desempenho carecem de teste no jogo.

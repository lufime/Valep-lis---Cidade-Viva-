# Valepólis V0.3.0 — Circulação V14

Continua a partir da V13. Acrescenta `get_route_avoiding_edges()` ao grafo rodoviário e altera a criação de percursos de veículos para excluir ligações previamente rejeitadas pela heurística existente (declive e proximidade de edifícios). O sistema tenta encontrar um caminho alternativo com Dijkstra e concatena os pontos de estrada na orientação correta.

Limitações: só evita arestas que falharam essas heurísticas. Não verifica água, instalações, árvores, colisões complexas ou pontes; também não altera automaticamente os percursos dos veículos que já circulam. Se não houver rota alternativa, devolve erro em vez de inventar uma. ZIP verificado quanto à integridade, não executado no Godot; sintaxe, compilação e comportamento por validar.

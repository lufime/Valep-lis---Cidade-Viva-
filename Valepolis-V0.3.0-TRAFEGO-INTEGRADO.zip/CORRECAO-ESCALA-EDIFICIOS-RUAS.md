# Valepólis V0.3.0 — escala reduzida de edifícios e ruas

## Alterações
- Redução das alturas e pegadas dos edifícios procedurais dos bairros.
- Redução da dimensão das praças-base dos bairros.
- Ruas locais e arruamentos internos mais estreitos.
- Avenidas urbanas 15% mais estreitas e autoestradas 8% mais estreitas; passeios ajustados.
- Mantidos os nomes oficiais, perfis arquitetónicos, posições dos bairros e restantes ficheiros.

## Validação
- Arquivo ZIP reconstruído e testado quanto à integridade.
- Alterações verificadas no código-fonte por comparação textual.
- Não foi possível executar o Godot nesta sessão; o resultado visual em Android ainda requer teste no motor e na APK.

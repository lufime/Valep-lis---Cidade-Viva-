# Valepólis V0.3.0 — Remodelação Fase 10

## Objetivo
Corrigir a posição inicial dos veículos para que cada veículo seja criado num ponto explícito do circuito viário local.

## Alteração
- O circuito é definido antes da criação do veículo.
- Cada um dos quatro veículos do bairro recebe um dos quatro pontos do circuito como posição inicial.
- Mantida a verificação de limites da área jogável.
- Mantidos o movimento existente, os perfis horários de tráfego e a geração de peões.

## Limites da validação
- Verificação estática do código e integridade do ZIP: executadas.
- Execução no Godot, inspeção visual da posição real das faixas, colisões e exportação APK: não executadas neste ambiente; não declarar como aprovadas.
- O circuito continua a ser local por bairro; esta alteração não implementa pathfinding global nem garante trânsito contínuo entre bairros/pontes.

# Valepólis V0.3.0 — Consolidação das Fases 15–22

Esta versão reúne num único ZIP as alterações e auditorias possíveis neste ambiente. A câmara recebe suporte para arrasto tátil e pinch-zoom com limites de distância. Consulte `RELATORIO_CONSOLIDADO_FASES15_22.md` para resultados e limitações.

**Não é uma APK validada.** A execução Godot, a validação visual/geométrica e a compilação Android ainda exigem um runner com Godot 4.5 e SDK Android.

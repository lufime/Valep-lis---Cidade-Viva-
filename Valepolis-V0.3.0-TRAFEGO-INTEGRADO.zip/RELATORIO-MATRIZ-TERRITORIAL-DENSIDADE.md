# Matriz territorial e densidade — Valepólis V0.3.0

- Preservados os 25 nomes, populações e centros X/Z existentes.
- Adicionado `data/matriz_territorial_densidade_v030.json` com áreas e densidades-alvo propostas.
- Atualizado `data/populacao_por_bairro_v030.json` com área e densidade calculada para auditoria.
- `systems/city_3d.gd` lê a área proposta e adapta a extensão local de geração pela raiz quadrada da área relativa (referência de 16 km²), respeitando limites visuais para evitar que bairros se sobreponham.
- A quantidade de edifícios continua limitada pelos lotes candidatos válidos e pelos corredores reservados para estradas; a área não é tratada como polígono cadastral real.
- A zona central mantém a regra: máximo de 15 pisos apenas dentro do futuro polígono da zona central. Não foi aplicado um limite de 15 pisos a todo o bairro Nexora.
- Total das áreas propostas: 415,76 km²; densidade ponderada aproximada: 2.405 hab./km².

## Limites da validação

As áreas e densidades são uma proposta técnica de planeamento, não medições geográficas confirmadas. Os centros dos bairros são os já existentes no projeto; não foram criados limites poligonais nem atribuídas culturas aos bairros. Não foi possível executar Godot 4.5 ou compilar APK neste ambiente; esta entrega requer PRE-FLIGHT/runtime para confirmar sintaxe, geração visual, sobreposição e desempenho em Android.

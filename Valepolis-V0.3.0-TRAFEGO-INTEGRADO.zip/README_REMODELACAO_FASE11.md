# Valepólis V0.3.0 — Remodelação Fase 11

## Alteração

Os circuitos locais dos veículos passam a ser calculados por faixa e a posição inicial é alinhada com o primeiro waypoint do respetivo circuito. Isto elimina a discrepância entre a posição de criação e o percurso definido que existia no código.

## Limites de validação

- Verificação estática do trecho alterado: executada.
- Integridade do ZIP: verificada após criação.
- Execução Godot, colisões, circulação visual e APK: não executadas neste ambiente.
- Os circuitos continuam locais; esta alteração não implementa pathfinding global nem prova que todos os segmentos estejam livres de obstáculos.

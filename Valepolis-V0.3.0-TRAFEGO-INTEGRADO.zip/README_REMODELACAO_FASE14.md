# Valepólis V0.3.0 — Fase 14

## Âmbito
Auditoria estática mais rigorosa das ligações às duas pontes e limpeza do script de preflight regional.

## Alteração real
- Removida uma atribuição redundante/errada de caminho no início de `tools/preflight_regional_roads.py`.
- Acrescentadas verificações estáticas para o alinhamento dos extremos do tabuleiro e rampas, e compatibilidade da largura das rampas.

## Limitações
Estas verificações confirmam apenas que os valores e chamadas estão presentes no código. Não confirmam contacto físico entre malhas, colisões, inclinação aceitável, ligação à rede viária no mundo 3D, circulação de veículos, nem compilação APK. O teste runtime do Godot continua pendente.

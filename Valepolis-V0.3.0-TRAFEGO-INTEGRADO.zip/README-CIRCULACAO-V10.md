# Valepólis V0.3.0 — Circulação V10

Continua a partir da V9. Ao construir as ligações entre bairros, o sistema regista waypoints amostrados ao longo do mesmo eixo usado para desenhar cada ligação. `get_vehicle_waypoints_between_neighborhoods(origin, destination)` combina agora esses pontos segundo os segmentos devolvidos pelo algoritmo de rota, em vez de usar apenas os centros dos bairros.

Limitações: as ligações continuam a ser segmentos lineares; isto não deteta edifícios/água/terreno íngreme, não prova que as pontes estão transitáveis e ainda não liga estes percursos aos agentes móveis existentes. Os waypoints só existem depois de `_build_inter_neighborhood_roads()` construir a rede. Integridade do ZIP verificada; o projeto não foi executado no Godot, portanto compilação e comportamento por validar.

# Valepólis V0.3.0 — Remodelação Fase 5

## Alterações efetuadas
- Aumentada a praça-base de cada bairro de 13 × 13 para 18 × 18 unidades, criando um núcleo visual mais legível.
- Afastados os pontos de geração dos edifícios do centro do bairro: raio procedural alterado de 2,2–7,95 para 5,8–12,05 unidades, mantendo a verificação de corredores rodoviários reservados.
- Mantidos os 25 nomes oficiais, os dados territoriais, a rede lógica e as duas pontes.

## Validação realizada
- Alteração textual verificada no `systems/city_3d.gd`.
- Arquivo ZIP será verificado com `unzip -t`.
- Godot 4.5 não está disponível neste ambiente; não foram executados testes de cena, colisão, visualização ou tráfego e não foi exportada APK.

## Limitações conhecidas
A mudança aumenta a separação procedural dos edifícios em relação ao centro e aos corredores locais, mas não prova ausência de colisões com todas as estradas regionais. A distribuição das posições dos 25 bairros, a geometria de estradas/ponte e o relevo ainda precisam de inspeção em execução no Godot.

# Relatório de verificação — Fase 12

- Alteração aplicada apenas ao posicionamento vertical dos agentes durante o movimento.
- A posição Y dos veículos é agora calculada como `_ground_height(x, z) + 0.18`.
- A oscilação dos peões foi mantida.
- Não foi possível executar testes no motor Godot nem exportar APK.

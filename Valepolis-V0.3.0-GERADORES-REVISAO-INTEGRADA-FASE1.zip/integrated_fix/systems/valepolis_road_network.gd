extends RefCounted
class_name ValepolisRoadNetwork

## Grafo rodoviário lógico de Valepólis. Distâncias em unidades do mapa 3D.
## A malha é construída a partir dos 25 centros de bairro, com conectividade garantida.
var nodes: Dictionary = {}
var edges: Array[Dictionary] = []

func build_graph(neighborhood_names: Array, positions: Array) -> Dictionary:
    nodes.clear()
    edges.clear()
    var count: int = mini(neighborhood_names.size(), positions.size())
    for i in range(count):
        nodes[str(neighborhood_names[i])] = {
            "name": str(neighborhood_names[i]),
            "position": positions[i],
            "neighbors": []
        }
    if count < 2:
        return {"nodes": count, "edges": 0, "connected": count <= 1}

    # Árvore geradora mínima por Prim: garante que todos os bairros ficam ligados.
    var visited: Dictionary = {str(neighborhood_names[0]): true}
    while visited.size() < count:
        var best_from := ""
        var best_to := ""
        var best_distance := INF
        for from_name in visited.keys():
            var from_pos: Vector2 = nodes[from_name]["position"]
            for i in range(count):
                var to_name := str(neighborhood_names[i])
                if visited.has(to_name):
                    continue
                var to_pos: Vector2 = nodes[to_name]["position"]
                var distance: float = from_pos.distance_to(to_pos)
                if distance < best_distance:
                    best_distance = distance
                    best_from = str(from_name)
                    best_to = to_name
        if best_to.is_empty():
            break
        _connect(best_from, best_to, best_distance, "principal")
        visited[best_to] = true

    # Ligações secundárias: cada bairro procura um vizinho próximo.
    # Duplicados são ignorados pelo identificador canónico da aresta.
    for i in range(count):
        var source := str(neighborhood_names[i])
        var candidates: Array[Dictionary] = []
        for j in range(count):
            if i == j:
                continue
            var target := str(neighborhood_names[j])
            var source_pos: Vector2 = nodes[source]["position"]
            var target_pos: Vector2 = nodes[target]["position"]
            candidates.append({"name": target, "distance": source_pos.distance_to(target_pos)})
        candidates.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return float(a["distance"]) < float(b["distance"]))
        var added := 0
        for candidate in candidates:
            var target := str(candidate["name"])
            if _has_edge(source, target):
                continue
            _connect(source, target, float(candidate["distance"]), "secundaria")
            added += 1
            if added >= 1:
                break

    return {"nodes": nodes.size(), "edges": edges.size(), "connected": _is_connected()}

func _edge_key(a: String, b: String) -> String:
    return a + "|" + b if a < b else b + "|" + a

func _has_edge(a: String, b: String) -> bool:
    var key := _edge_key(a, b)
    for edge in edges:
        if str(edge["key"]) == key:
            return true
    return false

func _connect(a: String, b: String, distance: float, road_type: String) -> void:
    if a == b or not nodes.has(a) or not nodes.has(b) or _has_edge(a, b):
        return
    var edge_id := _edge_key(a, b)
    edges.append({"key": edge_id, "from": a, "to": b, "distance": distance, "type": road_type})
    nodes[a]["neighbors"].append({"name": b, "distance": distance, "edge_key": edge_id})
    nodes[b]["neighbors"].append({"name": a, "distance": distance, "edge_key": edge_id})

func _is_connected() -> bool:
    if nodes.is_empty():
        return true
    var first: String = str(nodes.keys()[0])
    var seen: Dictionary = {first: true}
    var queue: Array[String] = [first]
    while not queue.is_empty():
        var current: String = queue.pop_front()
        for neighbor in nodes[current]["neighbors"]:
            var next_name: String = str(neighbor["name"])
            if not seen.has(next_name):
                seen[next_name] = true
                queue.append(next_name)
    return seen.size() == nodes.size()

func get_route(start_name: String, destination_name: String) -> Dictionary:
    if not nodes.has(start_name) or not nodes.has(destination_name):
        return {"ok": false, "error": "Bairro de origem ou destino desconhecido.", "path": [], "distance": 0.0}
    if start_name == destination_name:
        return {"ok": true, "path": [start_name], "distance": 0.0, "segments": []}

    var distances: Dictionary = {}
    var previous: Dictionary = {}
    var unvisited: Dictionary = {}
    for node_name in nodes.keys():
        distances[node_name] = INF
        unvisited[node_name] = true
    distances[start_name] = 0.0

    while not unvisited.is_empty():
        var current := ""
        var current_distance := INF
        for candidate in unvisited.keys():
            if float(distances[candidate]) < current_distance:
                current_distance = float(distances[candidate])
                current = str(candidate)
        if current.is_empty() or is_inf(current_distance):
            break
        if current == destination_name:
            break
        unvisited.erase(current)
        for neighbor in nodes[current]["neighbors"]:
            var next_name: String = str(neighbor["name"])
            if not unvisited.has(next_name):
                continue
            var alternative: float = current_distance + float(neighbor["distance"])
            if alternative < float(distances[next_name]):
                distances[next_name] = alternative
                previous[next_name] = {"name": current, "edge_key": str(neighbor["edge_key"])}

    if is_inf(float(distances[destination_name])):
        return {"ok": false, "error": "Não existe percurso entre os bairros.", "path": [], "distance": 0.0}

    var path: Array[String] = [destination_name]
    var segments: Array[String] = []
    var cursor := destination_name
    while cursor != start_name:
        if not previous.has(cursor):
            return {"ok": false, "error": "Percurso incompleto.", "path": [], "distance": 0.0}
        var step: Dictionary = previous[cursor]
        segments.push_front(str(step["edge_key"]))
        cursor = str(step["name"])
        path.push_front(cursor)
    return {"ok": true, "path": path, "distance": float(distances[destination_name]), "segments": segments}

func get_network_summary() -> Dictionary:
    return {"nodes": nodes.size(), "edges": edges.size(), "connected": _is_connected()}

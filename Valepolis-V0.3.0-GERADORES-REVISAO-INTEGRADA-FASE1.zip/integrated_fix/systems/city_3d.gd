extends Node3D
class_name ValepolisCity3D

const NEIGHBORHOODS := [
    "Marévia", "Brisamar", "Avelora", "Rivéria", "Nexora", "Altavira", "Lúmora", "Florávia",
    "Pedrália", "Montélia", "Valeora", "Fontélia", "Silvéria", "Portávia", "Lacéria", "Ventúria",
    "Olivéria", "Ribeora", "Solária", "Terrávia", "Altória", "Marivora", "Verdelis", "Estúria", "Pedravora"
]
const POSITIONS := [
    Vector2(-25,-36), Vector2(-5,-39), Vector2(23,25), Vector2(-39,-10), Vector2(-3,-3),
    Vector2(16,-8), Vector2(7,8), Vector2(-20,15), Vector2(28,20), Vector2(31,-31),
    Vector2(13,12), Vector2(-12,5), Vector2(34,14), Vector2(-35,-24), Vector2(14,29),
    Vector2(39,-6), Vector2(2,15), Vector2(-38,8), Vector2(-18,29), Vector2(22,34),
    Vector2(40,8), Vector2(-31,-29), Vector2(31,30), Vector2(-40,26), Vector2(40,30)
]

var camera: Camera3D
var camera_target := Vector3.ZERO
var yaw := 14.0
var pitch := -48.0
var distance := 48.0
var dragging := false
var last_mouse := Vector2.ZERO
var touch_points: Dictionary = {}
var last_touch_distance := 0.0
var _architectural_profiles: Dictionary = {}
var _addresses_by_neighborhood: Dictionary = {}
var _streets_by_neighborhood: Dictionary = {}
var road_network: ValepolisRoadNetwork = ValepolisRoadNetwork.new()
var _road_material: Material
var _valepolis_terrain: Node3D
var player_character: Node3D
var player_world_position := Vector3(-3.0, 0.0, -3.0)
var player_move_speed := 7.0
var player_display_name := "VOCÊ"
var player_profession := ""
var _player_label: Label3D
var _player_marker: MeshInstance3D
var _ambient_agents: Array[Dictionary] = []
var _ambient_clock: float = 0.0

func _ready() -> void:
    _create_valepolis_terrain()
    _load_architectural_profiles()
    _load_address_registry()
    _build_world()
    _build_registered_installations()
    _create_player_character()
    _create_camera()
    _create_light()
    _create_atmosphere()

func _create_valepolis_terrain() -> void:
    # Addon próprio Valepólis Terrain: sem extensões nativas externas.
    var terrain_script: Script = preload("res://addons/valepolis_terrain/terrain_generator.gd")
    _valepolis_terrain = terrain_script.new() as Node3D
    _valepolis_terrain.name = "Relevo_Valepolis"
    add_child(_valepolis_terrain)

func _ground_height(x: float, z: float) -> float:
    # Uma única fonte de verdade para assentar ruas, edifícios e instalações.
    if is_instance_valid(_valepolis_terrain) and _valepolis_terrain.has_method("height_at"):
        return float(_valepolis_terrain.call("height_at", x, z))
    return 0.0

func _load_address_registry() -> void:
    var path := "res://data/enderecamento_valepolis.json"
    if not FileAccess.file_exists(path):
        push_warning("Cadastro de endereços de Valepólis não encontrado: " + path)
        return
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        push_warning("Não foi possível abrir o cadastro de endereços de Valepólis.")
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary):
        push_warning("Cadastro de endereços inválido.")
        return
    for street in parsed.get("streets", []):
        var neighborhood := str(street.get("bairro", ""))
        if not _streets_by_neighborhood.has(neighborhood):
            _streets_by_neighborhood[neighborhood] = []
        _streets_by_neighborhood[neighborhood].append(street)
    for address in parsed.get("addresses", []):
        var neighborhood := str(address.get("bairro", ""))
        if not _addresses_by_neighborhood.has(neighborhood):
            _addresses_by_neighborhood[neighborhood] = []
        _addresses_by_neighborhood[neighborhood].append(address)


func _load_architectural_profiles() -> void:
    var path := "res://data/architectural_identity_v030.json"
    if not FileAccess.file_exists(path):
        push_warning("Perfis arquitetónicos V0.3.0 não encontrados; a cidade usa valores predefinidos.")
        return
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        push_warning("Não foi possível abrir os perfis arquitetónicos V0.3.0.")
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary):
        push_warning("Perfis arquitetónicos V0.3.0 inválidos.")
        return
    for item in parsed.get("neighborhoods", []):
        if item is Dictionary and item.has("name"):
            _architectural_profiles[str(item["name"])] = item

func _mat(color: Color, roughness := 0.8) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, name := "Block") -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := BoxMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.position = pos
    n.material_override = material
    parent.add_child(n)
    return n

func _plane(parent: Node3D, pos: Vector3, size: Vector2, material: Material, name := "Surface") -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := PlaneMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.position = pos
    n.material_override = material
    parent.add_child(n)
    return n

func _label(text_value: String, pos: Vector3) -> void:
    var l := Label3D.new()
    l.text = text_value
    l.position = pos
    l.font_size = 28
    l.modulate = Color(0.92, 0.97, 1.0)
    l.outline_size = 8
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    add_child(l)

func _building_cluster(center: Vector2, index: int) -> void:
    var base := Node3D.new()
    base.name = "Bairro_%02d" % (index + 1)
    add_child(base)
    var neighborhood_name: String = NEIGHBORHOODS[index]
    var profile: Dictionary = _architectural_profiles.get(neighborhood_name, {})
    # Pequena praça/pavimento-base de cada núcleo, com contorno discreto.
    var plaza_color := Color(0.25, 0.29, 0.28) if index % 4 == 0 else Color(0.30, 0.32, 0.31)
    var plaza_x := center.x + 1.0
    var plaza_z := center.y + 1.0
    var plaza_y := _ground_height(plaza_x, plaza_z) + 0.025
    _plane(base, Vector3(plaza_x, plaza_y, plaza_z), Vector2(13.0, 13.0), _mat(plaza_color), "Pavimento_Bairro_%02d" % (index + 1))
    var rgb: Array = profile.get("base_color_rgb", [0.20 + float(index % 5) * 0.018, 0.25 + float(index % 4) * 0.018, 0.31 + float(index % 3) * 0.02])
    var district_mat := _mat(Color(float(rgb[0]), float(rgb[1]), float(rgb[2])))
    var min_floors: int = int(profile.get("min_floors", 2))
    var max_floors: int = int(profile.get("max_floors", 30))
    var footprint_base: float = float(profile.get("footprint_base", 2.5))
    var building_count: int = clampi(int(profile.get("buildings_per_cluster", 12)), 8, 12)
    # Gerador procedural existente preservado; o perfil do bairro ajusta cor, escala e alturas.
    for i in range(building_count):
        var a := float(i) * 0.49 + float(index) * 0.21
        var r := 2.2 + float((index + i) % 6) * 1.15
        var px := center.x + cos(a) * r
        var pz := center.y + sin(a) * r
        var p := Vector3(px, _ground_height(px, pz), pz)
        var floor_span: int = max(1, max_floors - min_floors + 1)
        var floor_count: int = min_floors + ((index * 7 + i * 3) % floor_span)
        # Variação de volumetria por bairro: torres no núcleo, blocos médios
        # nas zonas mistas e volumes baixos nas zonas verdes/costeiras.
        var h := 2.6 + float(floor_count) * 0.92
        if neighborhood_name in ["Nexora", "Altavira", "Lúmora"]:
            h *= 1.12 if i % 3 == 0 else 1.0
        elif neighborhood_name in ["Marévia", "Brisamar", "Florávia", "Silvéria", "Verdelis", "Pedravora"]:
            h *= 0.68 if i % 3 != 0 else 0.82
        var width_factor: float = [0.82, 1.0, 1.18, 0.92][(index + i * 3) % 4]
        var depth_factor: float = [1.12, 0.86, 1.0][(index * 2 + i) % 3]
        var footprint_x := maxf(2.0, (footprint_base + float((index + i) % 3) * 0.55) * width_factor)
        var footprint_z := maxf(2.0, (footprint_base + float((index + i) % 3) * 0.55) * depth_factor)
        var building := _box(base, p + Vector3(0,h/2.0,0), Vector3(footprint_x, h, footprint_z), district_mat, "Edificio_%02d_%02d" % [index, i])
        var roof_color := Color(0.16, 0.20, 0.27) if index % 3 == 0 else (Color(0.66, 0.63, 0.57) if index % 3 == 1 else Color(0.78, 0.80, 0.79))
        var roof_mat := _mat(roof_color)
        var roof_h := 0.22 if floor_count >= 5 else 0.14
        _box(base, p + Vector3(0, h + roof_h * 0.5, 0), Vector3(footprint_x + 0.18, roof_h, footprint_z + 0.18), roof_mat, "Cobertura_%02d_%02d" % [index, i])
        var window_mat := _mat(Color(0.42, 0.70, 0.84), 0.24)
        var trim_mat := _mat(Color(0.82, 0.84, 0.82), 0.68)
        if h >= 4.0:
            var rows := mini(7, maxi(2, int(floor_count / 2)))
            var cols := 2 if footprint_x < 4.0 else 3
            for wr in range(rows):
                var wy := p.y + 1.35 + float(wr) * maxf(1.25, (h - 2.0) / float(rows))
                if wy < p.y + h - 0.55:
                    for wc in range(cols):
                        var wx := px - footprint_x * 0.30 + float(wc) * footprint_x * 0.30
                        _box(base, Vector3(wx, wy, pz + footprint_z * 0.5 + 0.018), Vector3(0.28, 0.42, 0.035), window_mat, "JanelaF_%02d_%02d_%02d_%02d" % [index, i, wr, wc])
                    _box(base, Vector3(px - footprint_x * 0.5 - 0.018, wy, pz), Vector3(0.035, 0.38, footprint_z * 0.28), window_mat, "JanelaL_%02d_%02d_%02d" % [index, i, wr])
            # Varandas discretas em edifícios residenciais de altura média.
            if floor_count >= 3 and floor_count <= 10 and i % 2 == 0:
                for balcony in range(mini(3, rows)):
                    var by := p.y + 2.0 + float(balcony) * 2.4
                    if by < p.y + h - 0.5:
                        _box(base, Vector3(px, by, pz + footprint_z * 0.5 + 0.14), Vector3(footprint_x * 0.72, 0.07, 0.28), trim_mat, "Varanda_%02d_%02d_%02d" % [index, i, balcony])
        # Entrada e pala de acesso para que os blocos não pareçam cubos vazios.
        if i % 2 == 0:
            _box(base, Vector3(px, p.y + 0.72, pz + footprint_z * 0.5 + 0.025), Vector3(0.65, 1.35, 0.06), trim_mat, "Entrada_%02d_%02d" % [index, i])
        var district_addresses: Array = _addresses_by_neighborhood.get(NEIGHBORHOODS[index], [])
        if not district_addresses.is_empty():
            var address: Dictionary = district_addresses[i % district_addresses.size()]
            building.set_meta("address_id", address.get("id", ""))
            building.set_meta("bairro", address.get("bairro", NEIGHBORHOODS[index]))
            building.set_meta("arruamento", address.get("arruamento", ""))
            building.set_meta("numero_porta", address.get("numero_porta", 0))
            building.set_meta("codigo_postal", address.get("codigo_postal", ""))
            building.set_meta("morada_completa", address.get("morada_completa", ""))

    var label_height := maxf(8.0, _ground_height(center.x, center.y) + 4.0)
    _label(NEIGHBORHOODS[index], Vector3(center.x, label_height, center.y))

func _neighborhood_landmark(center: Vector2, neighborhood_name: String, index: int) -> void:
    # Marco visual 3D simples e distinto por bairro; não substitui a arquitetura
    # procedural nem atribui identidades culturais ainda pendentes.
    var stone := _mat(Color(0.48, 0.47, 0.43))
    var civic := _mat(Color(0.68, 0.70, 0.72))
    var green := _mat(Color(0.13, 0.34, 0.18))
    var water := _mat(Color(0.04, 0.31, 0.46), 0.32)
    var warm := _mat(Color(0.72, 0.52, 0.27))
    var px := center.x + 8.5
    var pz := center.y - 7.5
    var gy := _ground_height(px, pz)
    match neighborhood_name:
        "Nexora":
            _box(self, Vector3(px, gy + 10.0, pz), Vector3(3.5, 20.0, 3.5), civic, "Marco_Centro_Nexora")
        "Altavira":
            _box(self, Vector3(px, gy + 3.0, pz), Vector3(8.0, 6.0, 6.0), civic, "Edificio_Administrativo_Altavira")
        "Rivéria", "Ribeora":
            _box(self, Vector3(px, gy + 0.25, pz), Vector3(9.0, 0.5, 3.0), water, "Cais_" + neighborhood_name)
        "Marévia", "Brisamar", "Marivora":
            _box(self, Vector3(px, gy + 0.7, pz), Vector3(7.0, 1.4, 2.0), warm, "Passeio_Costeiro_" + neighborhood_name)
        "Montélia", "Pedravora", "Altória":
            _box(self, Vector3(px, gy + 2.2, pz), Vector3(5.0, 4.4, 5.0), stone, "Marco_Rochoso_" + neighborhood_name)
        "Lúmora":
            _box(self, Vector3(px, gy + 2.5, pz), Vector3(7.0, 5.0, 6.0), civic, "Polo_Conhecimento_Lumora")
        "Florávia", "Silvéria", "Verdelis":
            _plane(self, Vector3(px, gy + 0.06, pz), Vector2(8.0, 7.0), green, "Jardim_" + neighborhood_name)
            for t in range(3):
                _tree(Vector3(px - 2.0 + float(t) * 2.0, _ground_height(px - 2.0 + float(t) * 2.0, pz + 1.5), pz + 1.5), 0.7)
        "Pedrália", "Terrávia":
            _box(self, Vector3(px, gy + 2.0, pz), Vector3(5.5, 4.0, 5.5), stone, "Marco_Pedra_" + neighborhood_name)
        "Valeora", "Fontélia":
            _box(self, Vector3(px, gy + 0.8, pz), Vector3(3.0, 1.6, 3.0), water, "Fonte_Publica_" + neighborhood_name)
        "Portávia", "Estúria":
            _box(self, Vector3(px, gy + 1.0, pz), Vector3(8.0, 2.0, 5.0), stone, "Infraestrutura_Logistica_" + neighborhood_name)
        "Lacéria":
            _plane(self, Vector3(px, gy + 0.08, pz), Vector2(8.0, 5.0), water, "Lago_Laceria")
        "Ventúria":
            _box(self, Vector3(px, gy + 4.0, pz), Vector3(0.7, 8.0, 0.7), civic, "Torre_Energetica_Venturia")
            _box(self, Vector3(px, gy + 7.5, pz), Vector3(5.0, 0.35, 0.35), civic, "Pala_Venturia")
        "Olivéria":
            _box(self, Vector3(px, gy + 0.8, pz), Vector3(7.0, 1.6, 5.0), warm, "Mercado_Oliveria")
        "Solária":
            _box(self, Vector3(px, gy + 0.5, pz), Vector3(9.0, 1.0, 7.0), green, "Campo_Desportivo_Solaria")
        "Avelora":
            _box(self, Vector3(px, gy + 1.5, pz), Vector3(7.0, 3.0, 6.0), civic, "Nova_Construcao_Avelora")
        _:
            _box(self, Vector3(px, gy + 1.2, pz), Vector3(4.0, 2.4, 4.0), civic, "Marco_" + str(index + 1))

func _tree(pos: Vector3, scale_factor: float = 1.0) -> void:
    var trunk := _mat(Color(0.25,0.16,0.09))
    var leaves := _mat(Color(0.08,0.30,0.16))
    _box(self, pos + Vector3(0,1.0*scale_factor,0), Vector3(0.35,2.0*scale_factor,0.35), trunk, "Tronco")
    var crown := _box(self, pos + Vector3(0,2.5*scale_factor,0), Vector3(2.0*scale_factor,2.0*scale_factor,2.0*scale_factor), leaves, "Copa")
    crown.rotation_degrees = Vector3(0,45,0)

func _park(center: Vector2, index: int) -> void:
    var grass := _mat(Color(0.12,0.36,0.18))
    var park_y := _ground_height(center.x, center.y)
    _plane(self, Vector3(center.x, park_y + 0.04, center.y), Vector2(11,8), grass, "Parque_%02d" % index)
    for i in range(5):
        var tx := center.x - 4.0 + i * 2.0
        var tz := center.y - 2.2 + float((i+index)%3)
        _tree(Vector3(tx, _ground_height(tx, tz), tz), 0.75)

func _build_neighborhood_details(center: Vector2, index: int, neighborhood_name: String) -> void:
    # Elementos próprios gerados por código: árvores, passeios, mobiliário, carros e peões.
    var sidewalk := _mat(Color(0.48, 0.49, 0.46), 0.92)
    var asphalt := _mat(Color(0.07, 0.08, 0.09), 0.98)
    var car_colors := [Color(0.72,0.12,0.10), Color(0.10,0.28,0.58), Color(0.78,0.79,0.76), Color(0.12,0.14,0.15), Color(0.76,0.57,0.12)]
    # Passeios baixos ao longo das ruas locais.
    for side in [-1.0, 1.0]:
        var sx: float = center.x + float(side) * 5.8
        var sz: float = center.y + 8.0
        _box(self, Vector3(sx, _ground_height(sx, sz) + 0.12, sz), Vector3(0.65,0.22,15.0), sidewalk, "Passeio_%02d_%s" % [index, str(side)])
    # Árvores distribuídas em pequenas bolsas verdes fora do centro dos edifícios.
    for t in range(9):
        var angle := float(t) * 2.399 + float(index) * 0.31
        var radius := 8.8 + float(t % 3) * 1.25
        var tx := center.x + cos(angle) * radius
        var tz := center.y + sin(angle) * radius
        if absf(tx) < 47.0 and absf(tz) < 46.0 and not (absf(tx - center.x) < 3.2 and absf(tz - center.y) < 3.2):
            _tree(Vector3(tx, _ground_height(tx, tz), tz), 0.65 + float(t % 3) * 0.12)
    # Veículos com carroçaria, tejadilho, janelas e rodas geométricas próprias.
    for c in range(2):
        var cx := center.x + ( -6.2 if c == 0 else 6.2 )
        var cz := center.y + 8.0 + float((index + c) % 3) * 2.2
        var gy := _ground_height(cx, cz) + 0.18
        var vehicle := Node3D.new()
        vehicle.name = "Veiculo_%02d_%02d" % [index, c]
        vehicle.position = Vector3(cx, gy, cz)
        add_child(vehicle)
        var vehicle_path: Array[Vector3] = [
            Vector3(center.x - 6.2, 0.0, center.y + 8.0),
            Vector3(center.x + 5.0, 0.0, center.y + 8.0),
            Vector3(center.x + 5.0, 0.0, center.y + 5.0),
            Vector3(center.x - 6.2, 0.0, center.y + 5.0)
        ]
        _ambient_agents.append({
            "node": vehicle,
            "kind": "vehicle",
            "path": vehicle_path,
            "target": 1 if c == 0 else 3,
            "speed": 3.0 + float((index + c) % 3) * 0.45,
            "phase": float(index * 3 + c) * 0.37
        })
        var body_mat := _mat(car_colors[(index + c) % car_colors.size()], 0.38)
        var glass := _mat(Color(0.18,0.36,0.46), 0.22)
        _box(vehicle, Vector3.ZERO, Vector3(1.55,0.55,2.7), body_mat, "Carrocaria")
        _box(vehicle, Vector3(0,0.37,-0.12), Vector3(1.18,0.38,1.22), glass, "Vidros")
        var rubber := _mat(Color(0.025,0.028,0.03))
        for wx in [-0.78,0.78]:
            for wz in [-0.82,0.82]:
                var wheel := MeshInstance3D.new()
                var wm := CylinderMesh.new(); wm.top_radius=0.22; wm.bottom_radius=0.22; wm.height=0.14
                wheel.mesh=wm; wheel.material_override=rubber
                wheel.position=Vector3(wx,-0.18,wz); wheel.rotation_degrees.z=90
                vehicle.add_child(wheel)
    # Peões estilizados de baixa geometria, colocados junto dos passeios.
    for person_i in range(3):
        var px := center.x - 5.2 + float(person_i) * 5.2
        var pz := center.y + 5.3 + float((person_i + index) % 2) * 1.1
        var py := _ground_height(px, pz)
        var npc := Node3D.new(); npc.name = "Peao_%02d_%02d" % [index, person_i]
        npc.position = Vector3(px, py, pz); add_child(npc)
        var pedestrian_path: Array[Vector3] = [
            Vector3(center.x - 5.2, 0.0, center.y + 5.3),
            Vector3(center.x, 0.0, center.y + 5.3),
            Vector3(center.x + 5.2, 0.0, center.y + 6.4),
            Vector3(center.x, 0.0, center.y + 6.4)
        ]
        _ambient_agents.append({
            "node": npc,
            "kind": "pedestrian",
            "path": pedestrian_path,
            "target": (person_i + 1) % pedestrian_path.size(),
            "speed": 0.75 + float(person_i % 2) * 0.18,
            "phase": float(index * 5 + person_i) * 0.61
        })
        var skin := _mat([Color(0.72,0.52,0.38),Color(0.48,0.31,0.22),Color(0.88,0.70,0.55)][(index+person_i)%3])
        var clothes := _mat(car_colors[(index+person_i+2)%car_colors.size()])
        var head := MeshInstance3D.new(); var hm := SphereMesh.new(); hm.radius=0.17; hm.height=0.34
        head.mesh=hm; head.material_override=skin; head.position=Vector3(0,1.48,0); npc.add_child(head)
        _box(npc, Vector3(0,1.02,0), Vector3(0.38,0.65,0.24), clothes, "Corpo")
        for leg_x in [-0.11,0.11]:
            _box(npc, Vector3(leg_x,0.48,0), Vector3(0.12,0.42,0.14), _mat(Color(0.12,0.15,0.20)), "Perna")
    # Nome de bairro sempre visível como etiqueta no espaço do mapa.
    _label(neighborhood_name, Vector3(center.x, _ground_height(center.x, center.y) + 7.0, center.y))

func _local_roads(center: Vector2, index: int) -> void:
    var road := _mat(Color(0.055,0.065,0.075), 0.95)
    _box(self, Vector3(center.x, _ground_height(center.x, center.y + 8.0) + 0.08, center.y+8), Vector3(18,0.18,2.8), road, "Rua_%02d_A" % index)
    _box(self, Vector3(center.x+8, _ground_height(center.x + 8.0, center.y) + 0.08, center.y), Vector3(2.8,0.18,18), road, "Rua_%02d_B" % index)


func _named_street_network(center: Vector2, index: int) -> void:
    # Malha visual modular inicial: eixos locais e nomes fictícios por bairro.
    # Não equivale ainda a navegação rodoviária/pathfinding de veículos.
    var asphalt := _mat(Color(0.065, 0.075, 0.085), 0.96)
    var pavement := _mat(Color(0.34, 0.36, 0.37), 0.9)
    var names := [
        "Avenida", "Rua", "Praça", "Travessa", "Alameda"
    ]
    var samples := [
        ["Avenida da Inovação","Rua dos Navegantes","Praça da União","Travessa da Tecnologia","Alameda do Futuro"],
        ["Avenida das Colinas","Rua do Miradouro","Praça da Encosta","Travessa das Oliveiras","Alameda da Serra"],
        ["Avenida do Rio","Rua das Pontes","Praça Ribeira","Travessa da Água","Alameda do Vale"],
        ["Avenida do Atlântico","Rua das Marés","Praça da Praia","Travessa do Farol","Alameda da Costa"],
        ["Avenida das Montanhas","Rua da Encosta","Praça da Montanha","Travessa do Pinhal","Alameda dos Picos"],
        ["Avenida da Luz","Rua das Acácias","Praça Lúmora","Travessa do Jardim","Alameda das Fontes"],
        ["Avenida das Flores","Rua do Jardim","Praça Florávia","Travessa das Rosas","Alameda Verde"],
        ["Avenida da Pedra","Rua do Castelo","Praça Pedrália","Travessa da Fonte","Alameda das Pedras"],
        ["Avenida do Vale","Rua dos Plátanos","Praça Central","Travessa do Moinho","Alameda do Sol"],
        ["Avenida da Praia","Rua dos Pescadores","Praça Brisamar","Travessa da Marina","Alameda do Mar"],
        ["Avenida das Fontes","Rua da Nascente","Praça Fontélia","Travessa da Água","Alameda dos Lagos"],
        ["Avenida da Prata","Rua da Serra","Praça Silvéria","Travessa dos Cedros","Alameda Branca"],
        ["Avenida do Porto","Rua dos Armazéns","Praça Portávia","Travessa do Cais","Alameda Logística"],
        ["Avenida do Lago","Rua das Margens","Praça Lacéria","Travessa dos Juncos","Alameda da Lagoa"],
        ["Avenida dos Ventos","Rua da Brisa","Praça Ventúria","Travessa do Horizonte","Alameda do Vento"],
        ["Avenida das Oliveiras","Rua do Olival","Praça Olivéria","Travessa do Pomar","Alameda dos Montes"],
        ["Avenida Ribeirinha","Rua da Ribeira","Praça Ribeora","Travessa do Açude","Alameda do Rio"],
        ["Avenida do Sol","Rua do Poente","Praça Solária","Travessa da Aurora","Alameda Dourada"],
        ["Avenida da Avelã","Rua dos Jardins","Praça Avelora","Travessa das Árvores","Alameda da Fonte"],
        ["Avenida da Terra","Rua dos Campos","Praça Terrávia","Travessa Rural","Alameda do Campo"],
        ["Avenida da Altitude","Rua do Alto","Praça Altória","Travessa da Vista","Alameda das Colinas"],
        ["Avenida da Maré","Rua do Estuário","Praça Marivora","Travessa do Molhe","Alameda do Estuário"],
        ["Avenida Verde","Rua das Florestas","Praça Verdelis","Travessa do Bosque","Alameda das Árvores"],
        ["Avenida do Estuário","Rua dos Canais","Praça Estúria","Travessa da Doca","Alameda Ribeirinha"],
        ["Avenida das Pedras","Rua da Pedreira","Praça Pedravora","Travessa do Vale","Alameda Rochosa"]
    ]
    var street_names: Array = samples[index % samples.size()]
    # Ruas transversais e longitudinais ligam os quarteirões de cada bairro.
    var road_h := _box(self, Vector3(center.x, _ground_height(center.x, center.y + 5.0) + 0.095, center.y + 5.0), Vector3(22, 0.16, 2.5), asphalt, "Arruamento_H_%02d" % (index + 1))
    var road_v := _box(self, Vector3(center.x + 5.0, _ground_height(center.x + 5.0, center.y) + 0.096, center.y), Vector3(2.5, 0.16, 22), asphalt, "Arruamento_V_%02d" % (index + 1))
    var district_streets: Array = _streets_by_neighborhood.get(NEIGHBORHOODS[index], [])
    if not district_streets.is_empty():
        var main_street: Dictionary = district_streets[0]
        road_h.set_meta("arruamento_id", main_street.get("id", ""))
        road_h.set_meta("arruamento", main_street.get("nome", ""))
        road_h.set_meta("codigo_postal", main_street.get("codigo_postal", ""))
        if district_streets.size() > 1:
            var secondary_street: Dictionary = district_streets[1]
            road_v.set_meta("arruamento_id", secondary_street.get("id", ""))
            road_v.set_meta("arruamento", secondary_street.get("nome", ""))
            road_v.set_meta("codigo_postal", secondary_street.get("codigo_postal", ""))
    # Passeios laterais reutilizados como meshes simples.
    _box(self, Vector3(center.x, _ground_height(center.x, center.y + 3.35) + 0.105, center.y + 3.35), Vector3(22, 0.12, 0.45), pavement, "Passeio_HA_%02d" % (index + 1))
    _box(self, Vector3(center.x, _ground_height(center.x, center.y + 6.65) + 0.105, center.y + 6.65), Vector3(22, 0.12, 0.45), pavement, "Passeio_HB_%02d" % (index + 1))
    # Placa de orientação com o nome do eixo principal; os restantes nomes constam no cadastro.
    _label(street_names[0], Vector3(center.x, _ground_height(center.x, center.y + 5.0) + 1.1, center.y + 5.0))

func _terrain_following_road(start: Vector2, finish: Vector2, width: float, thickness: float, material: Material, road_name: String, segment_count: int = 12) -> Array[MeshInstance3D]:
    var result: Array[MeshInstance3D] = []
    var delta := finish - start
    var total_length := delta.length()
    if total_length < 0.1:
        return result
    var segments := maxi(1, segment_count)
    var segment_length := total_length / float(segments)
    for i in range(segments):
        var t0 := float(i) / float(segments)
        var t1 := float(i + 1) / float(segments)
        var midpoint := start.lerp(finish, (t0 + t1) * 0.5)
        var y := _ground_height(midpoint.x, midpoint.y) + thickness * 0.5 + 0.015
        var road := _box(self, Vector3(midpoint.x, y, midpoint.y), Vector3(segment_length + 0.18, thickness, width), material, "%s_%02d" % [road_name, i + 1])
        road.rotation.y = -atan2(delta.y, delta.x)
        result.append(road)
    return result

func _build_inter_neighborhood_roads() -> void:
    # A malha visual representa exatamente as arestas do grafo de navegação.
    var summary := road_network.build_graph(NEIGHBORHOODS, POSITIONS)
    var asphalt := _mat(Color(0.045, 0.055, 0.065), 0.97)
    for edge in road_network.edges:
        var from_name: String = str(edge["from"])
        var to_name: String = str(edge["to"])
        var from_pos: Vector2 = road_network.nodes[from_name]["position"]
        var to_pos: Vector2 = road_network.nodes[to_name]["position"]
        var delta := to_pos - from_pos
        var length := delta.length()
        if length < 0.1:
            continue
        # As ligações visuais começam fora do miolo de edifícios de cada bairro.
        var direction := delta.normalized()
        var visual_start := from_pos + direction * 12.0
        var visual_end := to_pos - direction * 12.0
        var visual_delta := visual_end - visual_start
        var visual_length := visual_delta.length()
        if visual_length < 0.1:
            continue
        var midpoint := (visual_start + visual_end) * 0.5
        var road_width := 1.7 if edge["type"] == "principal" else 1.15
        var road_parts := _terrain_following_road(visual_start, visual_end, road_width, 0.14, asphalt, "Ligacao_%s" % str(edge["key"]).replace("|", "_"), 12)
        if not road_parts.is_empty():
            # Os metadados ficam no primeiro segmento para preservar a consulta de rede.
            road_parts[0].set_meta("bairro_origem", from_name)
            road_parts[0].set_meta("bairro_destino", to_name)
            road_parts[0].set_meta("distancia_mapa", float(edge["distance"]))
            road_parts[0].set_meta("tipo_via", str(edge["type"]))
    print("Rede rodoviária Valepólis: ", summary)

func get_route_between_neighborhoods(origin: String, destination: String) -> Dictionary:
    return road_network.get_route(origin, destination)

func _build_registered_installations() -> void:
    var registry: Node = get_tree().root.get_node_or_null("ValepolisInstallations")
    if registry == null or not registry.has_method("get_map_spawnable_installations"):
        return
    var rows: Array = registry.call("get_map_spawnable_installations")
    var seen_buildings: Dictionary = {}
    for row in rows:
        if not (row is Dictionary):
            continue
        var building_id := str(row.get("building_id", "")).strip_edges()
        if building_id.is_empty() or seen_buildings.has(building_id):
            push_warning("Instalação ignorada: ID físico vazio ou duplicado.")
            continue
        var raw_position: Variant = row.get("map_position", null)
        if not (raw_position is Array) or raw_position.size() < 3:
            continue
        var position := Vector3(float(raw_position[0]), float(raw_position[1]), float(raw_position[2]))
        position.y = maxf(position.y, _ground_height(position.x, position.z))
        var entity_id := str(row.get("entity_id", ""))
        var size := Vector3(4.0, 3.0, 4.0)
        var tint := Color(0.24, 0.43, 0.55)
        if entity_id == "BRIGADA":
            tint = Color(0.75, 0.18, 0.14)
        elif entity_id == "SUE":
            tint = Color(0.88, 0.91, 0.95)
        elif entity_id == "POLICIA":
            tint = Color(0.08, 0.18, 0.36)
        elif entity_id == "MUNICIPIO":
            tint = Color(0.72, 0.62, 0.30)
        var mesh := _box(self, position + Vector3(0.0, size.y / 2.0, 0.0), size, _mat(tint), building_id)
        mesh.set_meta("installation_id", str(row.get("installation_id", "")))
        mesh.set_meta("entity_id", entity_id)
        mesh.set_meta("neighborhood", str(row.get("neighborhood_name", "")))
        mesh.set_meta("address", str(row.get("full_address", "")))
        mesh.set_meta("map_object_class", str(row.get("planned_map_object_class", "building")))
        seen_buildings[building_id] = true
        _label(str(row.get("display_name", building_id)), position + Vector3(0.0, size.y + 1.0, 0.0))

func _build_world() -> void:
    # O solo e as montanhas são gerados pelo addon próprio Valepólis Terrain.

    # Geografia continental: mar apenas a norte; o estuário entra pelo oeste
    # e termina na costa norte. Não existe água a envolver a margem sul/leste.
    var sea := _mat(Color(0.035,0.22,0.39), 0.32)
    _plane(self, Vector3(0,-0.42,-65.0), Vector2(150,18), sea, "Mar_Norte")

    # Canal longitudinal a oeste, com margem terrestre contínua a sul.
    # A extremidade norte encontra a costa; a extremidade sul termina antes
    # das localidades interiores, evitando o efeito de ilha.
    _box(self, Vector3(-56,-0.24,-1.0), Vector3(7.0,0.30,88.0), sea, "Rio_Estuario_Oeste")


    # Eixos viários principais seguem o relevo; nenhum tabuleiro longo fica a uma cota fixa.
    var road := _mat(Color(0.075,0.082,0.09), 0.96)
    _terrain_following_road(Vector2(-1,-43), Vector2(-1,43), 5.4, 0.16, road, "Avenida_Central", 48)
    _terrain_following_road(Vector2(-47,4), Vector2(47,4), 5.0, 0.16, road, "Avenida_Transversal", 48)
    _terrain_following_road(Vector2(-49,-20), Vector2(-4,-20), 3.2, 0.15, road, "Avenida_Norte", 24)
    _terrain_following_road(Vector2(3,24), Vector2(47,24), 3.2, 0.15, road, "Avenida_Sul", 24)
    var lane_mark := _mat(Color(0.92, 0.78, 0.38), 0.7)
    for mark_i in range(23):
        var mx := -43.0 + float(mark_i) * 3.8
        var my := _ground_height(mx, 4.0) + 0.27
        _box(self, Vector3(mx, my, 4.0), Vector3(1.35, 0.025, 0.10), lane_mark, "Marca_Transversal_%02d" % mark_i)

    # Pontes sobre o estuário.
    var bridge := _mat(Color(0.35,0.38,0.40))
    _box(self, Vector3(-44,1.0,-17), Vector3(27,2,5), bridge, "Ponte_da_Uniao")
    _box(self, Vector3(-44,1.0,23), Vector3(27,2,5), bridge, "Ponte_do_Horizonte")
    _label("Ponte da União", Vector3(-44,4,-17))
    _label("Ponte do Horizonte", Vector3(-44,4,23))

    for i in range(NEIGHBORHOODS.size()):
        _building_cluster(POSITIONS[i], i)
        _neighborhood_landmark(POSITIONS[i], NEIGHBORHOODS[i], i)
        _local_roads(POSITIONS[i], i)
        _named_street_network(POSITIONS[i], i)
        if i % 3 == 0:
            _park(POSITIONS[i] + Vector2(5,-5), i)
        _build_neighborhood_details(POSITIONS[i], i, NEIGHBORHOODS[i])

    _build_inter_neighborhood_roads()

    # Lago interior e zona portuária.
    var lake := _mat(Color(0.04,0.30,0.45), 0.3)
    _plane(self, Vector3(3,0.01,35), Vector2(20,9), lake, "Lago_Valepolis")
    _box(self, Vector3(-25,0.4,-39), Vector3(22,0.8,8), _mat(Color(0.30,0.30,0.32)), "Porto")
    _label("PORTO / MARINA", Vector3(-25,2.5,-39))

    # Centro de Valepólis.
    var civic := _mat(Color(0.30,0.36,0.43))
    _box(self, Vector3(0,7,4), Vector3(10,14,10), civic, "Centro_Valepolis")
    _label("VALEPÓLIS", Vector3(0,17,4))

    # Instalações funcionais só aparecem via registo aprovado em _build_registered_installations().


func _create_player_character() -> void:
    # A personagem selecionada passa a existir no mundo 3D, não apenas como
    # marcador 2D sobre o SubViewport. A posição inicial fica em Nexora.
    var character_script: Script = load("res://addons/valepolis_3d_studio/procedural_character.gd")
    if character_script == null:
        push_warning("Gerador de personagem 3D indisponível; mantém-se o marcador da interface.")
        return
    player_character = character_script.new() as Node3D
    if player_character == null:
        push_warning("Não foi possível instanciar a personagem 3D.")
        return
    player_character.name = "PersonagemSelecionada3D"
    player_character.set("seed_value", 20261010)
    player_character.set("role", "Civil")
    player_character.set("regenerate_on_ready", true)
    player_world_position.y = _ground_height(player_world_position.x, player_world_position.z)
    player_character.position = player_world_position
    add_child(player_character)
    _player_label = Label3D.new()
    _player_label.name = "EtiquetaPersonagemSelecionada"
    _player_label.text = player_display_name
    _player_label.position = player_world_position + Vector3(0.0, 2.7, 0.0)
    _player_label.font_size = 24
    _player_label.modulate = Color(1.0, 0.88, 0.30)
    _player_label.outline_size = 8
    _player_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    add_child(_player_label)
    _player_marker = MeshInstance3D.new()
    _player_marker.name = "MarcadorPosicaoJogador"
    var ring := CylinderMesh.new()
    ring.top_radius = 1.05
    ring.bottom_radius = 1.05
    ring.height = 0.08
    _player_marker.mesh = ring
    _player_marker.position = player_world_position + Vector3(0, 0.12, 0)
    var marker_mat := StandardMaterial3D.new()
    marker_mat.albedo_color = Color(1.0, 0.72, 0.12, 0.82)
    marker_mat.emission_enabled = true
    marker_mat.emission = Color(1.0, 0.42, 0.04)
    marker_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    _player_marker.material_override = marker_mat
    add_child(_player_marker)
    camera_target = player_world_position + Vector3(0.0, 4.0, 0.0)


func set_player_identity(character_name: String, profession: String = "") -> void:
    var clean_name := character_name.strip_edges()
    player_display_name = clean_name if clean_name != "" and clean_name != "PERSONAGEM" else "ESCOLHA PERSONAGEM"
    player_profession = profession.strip_edges()
    if is_instance_valid(_player_label):
        _player_label.text = player_display_name
    if is_instance_valid(player_character):
        var seed_value := int(abs(player_display_name.hash()))
        if player_character.get("seed_value") != null:
            player_character.set("seed_value", seed_value)
        if player_character.get("role") != null:
            var role_text := player_profession.to_lower()
            var visual_role := "Civil"
            if "brigada" in role_text:
                visual_role = "BRIGADA"
            elif "sue" in role_text or "médic" in role_text or "enfermeir" in role_text:
                visual_role = "SUE"
            elif "tnur" in role_text or "transporte não urgente" in role_text:
                visual_role = "TNUR"
            elif "polícia" in role_text or "policia" in role_text or "agente de polícia" in role_text:
                visual_role = "Policia"
            player_character.set("role", visual_role)
        if player_character.has_method("regenerate"):
            player_character.call("regenerate")

func _process(delta: float) -> void:
    _ambient_clock += delta
    _update_ambient_agents(delta)
    # Movimento básico de teste com teclado (WASD/setas), relativo ao mapa.
    # Em ecrãs táteis, os gestos continuam reservados à câmara.
    if not is_instance_valid(player_character):
        return
    var move := Vector2.ZERO
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        move.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        move.x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        move.y -= 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        move.y += 1.0
    if player_character.has_method("set_moving"):
        player_character.call("set_moving", move.length_squared() > 0.0)
    if move.length_squared() > 0.0:
        move = move.normalized()
        player_world_position.x += move.x * player_move_speed * delta
        player_world_position.z += move.y * player_move_speed * delta
        player_world_position.x = clampf(player_world_position.x, -48.0, 48.0)
        player_world_position.z = clampf(player_world_position.z, -48.0, 48.0)
        player_world_position.y = _ground_height(player_world_position.x, player_world_position.z)
        player_character.position = player_world_position
        if is_instance_valid(_player_label):
            _player_label.position = player_world_position + Vector3(0.0, 2.7, 0.0)
        if is_instance_valid(_player_marker):
            _player_marker.position = player_world_position + Vector3(0.0, 0.12, 0.0)
        camera_target = player_world_position + Vector3(0.0, 4.0, 0.0)
        _update_camera()

func _update_ambient_agents(delta: float) -> void:
    # Percursos locais sobre os eixos viários/passeios já gerados. É uma
    # primeira camada de movimento autónomo; não substitui pathfinding global.
    for agent in _ambient_agents:
        var node: Node3D = agent.get("node") as Node3D
        if not is_instance_valid(node):
            continue
        var path: Array = agent.get("path", [])
        if path.size() < 2:
            continue
        var target_index: int = int(agent.get("target", 0)) % path.size()
        var target: Vector3 = path[target_index]
        var current_flat := Vector2(node.position.x, node.position.z)
        var target_flat := Vector2(target.x, target.z)
        var offset := target_flat - current_flat
        var speed := float(agent.get("speed", 1.0))
        if offset.length() <= maxf(0.12, speed * delta):
            agent["target"] = (target_index + 1) % path.size()
            target_index = int(agent["target"])
            target = path[target_index]
            offset = Vector2(target.x - node.position.x, target.z - node.position.z)
        if offset.length_squared() > 0.0001:
            var direction := offset.normalized()
            node.position.x += direction.x * speed * delta
            node.position.z += direction.y * speed * delta
            node.position.y = _ground_height(node.position.x, node.position.z)
            node.rotation.y = atan2(direction.x, direction.y)
        if str(agent.get("kind", "")) == "pedestrian":
            node.position.y = _ground_height(node.position.x, node.position.z)
            node.position.y += absf(sin(_ambient_clock * 7.0 + float(agent.get("phase", 0.0)))) * 0.035
    # Guardar estado actualizado para o próximo frame.
    # Os dicionários são referências, por isso os alvos já ficam persistidos.

func _create_camera() -> void:
    camera = Camera3D.new()
    add_child(camera)
    camera.current = true
    camera.fov = 58.0
    camera.near = 0.1
    camera.far = 650.0
    _update_camera()

func _update_camera() -> void:
    if camera == null:
        return
    var basis := Basis.from_euler(Vector3(deg_to_rad(pitch), deg_to_rad(yaw), 0))
    camera.position = camera_target + basis * Vector3(0,0,distance)
    camera.look_at(camera_target, Vector3.UP)

func _create_light() -> void:
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52,-28,0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    add_child(sun)

func _create_atmosphere() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_material := ProceduralSkyMaterial.new()
    sky_material.sky_top_color = Color(0.12, 0.30, 0.52)
    sky_material.sky_horizon_color = Color(0.72, 0.80, 0.86)
    sky_material.ground_bottom_color = Color(0.18, 0.25, 0.20)
    sky_material.ground_horizon_color = Color(0.48, 0.56, 0.48)
    sky.sky_material = sky_material
    e.sky = sky
    e.background_color = Color(0.24,0.38,0.52)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.45,0.52,0.65)
    e.ambient_light_energy = 1.0
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_LEFT:
            dragging = event.pressed
            last_mouse = event.position
        elif event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
            distance = max(12.0, distance - 5.0)
            _update_camera()
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
            distance = min(150.0, distance + 5.0)
            _update_camera()
    elif event is InputEventMouseMotion and dragging:
        var delta: Vector2 = event.position - last_mouse
        last_mouse = event.position
        yaw -= delta.x * 0.25
        pitch = clampf(pitch - delta.y * 0.18, -78.0, -25.0)
        _update_camera()
    elif event is InputEventScreenTouch:
        if event.pressed:
            touch_points[event.index] = event.position
        else:
            touch_points.erase(event.index)
            last_touch_distance = 0.0
    elif event is InputEventScreenDrag:
        touch_points[event.index] = event.position
        if touch_points.size() == 1:
            yaw -= event.relative.x * 0.22
            pitch = clampf(pitch - event.relative.y * 0.16, -78.0, -25.0)
            _update_camera()
        elif touch_points.size() >= 2:
            var pts: Array = touch_points.values()
            var first_point: Vector2 = pts[0] as Vector2
            var second_point: Vector2 = pts[1] as Vector2
            var d: float = first_point.distance_to(second_point)
            if last_touch_distance > 0.0:
                distance = clampf(distance - (d - last_touch_distance) * 0.10, 12.0, 150.0)
                _update_camera()
            last_touch_distance = d


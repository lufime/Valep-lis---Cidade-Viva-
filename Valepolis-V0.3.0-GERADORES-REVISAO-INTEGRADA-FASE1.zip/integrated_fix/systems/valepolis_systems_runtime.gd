extends Node
class_name ValepolisSystemsRuntime

# V0.3.0 — Runtime bridge for Cidade Viva systems.
# Consumes the data/config contracts and exposes deterministic,
# testable state transitions to the main project.

var initialized := false
var paused := false
var sim_minute := 0
var day := 1
var economy := {"configured": false, "status": "por_definir", "balance": null, "transactions": []}
var employment := {}
var traffic := {}
var weather := {"state": "clear", "intensity": 0.0}
var incidents: Array = []
var dispatches: Array = []
var travel_speed_units_per_minute := 1.0
var traffic_delay_factor := 1.0
var maintenance := {}
var construction := {}
var progression := {"episode": 1, "season": 1}
var population: Array = []
var families: Dictionary = {}
var memories: Dictionary = {}

const DATA := "res://data/"

func _ready() -> void:
    # A cena principal controla a inicialização para garantir que o relógio,
    # calendário e estado inicial da cidade estejam prontos antes do runtime.
    pass

func initialize() -> Dictionary:
    _load_all_configs()
    var economy_config = _load_json("economy_config.json", {})
    economy = economy_config if economy_config is Dictionary else {}
    economy["configured"] = bool(economy.get("configured", false))
    economy["status"] = str(economy.get("status", "por_definir"))
    economy["balance"] = economy.get("balance", null)
    economy["transactions"] = economy.get("transactions", []) if economy.get("transactions", []) is Array else []
    employment = _load_json("employment_config.json", {})
    traffic = _load_json("traffic_config.json", {})
    weather = {"state": "clear", "intensity": 0.0}
    incidents = []
    dispatches = []
    entity_resources = {}
    entity_profiles = {}
    entity_services = {}
    for entity_data in entity_master_catalog.get("entities", []):
        if not entity_data is Dictionary:
            continue
        var profile_id := str(entity_data.get("id", "")).strip_edges()
        if profile_id == "":
            continue
        entity_profiles[profile_id] = {
            "id": profile_id,
            "name": str(entity_data.get("name", profile_id)),
            "organizational_status": str(entity_data.get("organizational_status", "entity")),
            "parent_entity_id": entity_data.get("parent_entity_id", null),
            "status": "not_configured",
            "purpose": str(entity_data.get("purpose", "")),
            "services": entity_data.get("services", []).duplicate(true),
            "dependencies": entity_data.get("dependencies", []).duplicate(true),
            "can_dispatch": bool(entity_data.get("can_dispatch", false)),
            "incident_types": entity_data.get("incident_types", []).duplicate(true),
            "staffing": null,
            "economy": null,
            "installation_count": null,
            "vehicles": null,
            "inventory": null,
            "budget": null,
            "balance": null,
            "constraints": entity_data.get("constraints", []).duplicate(true)
        }
        entity_services[profile_id] = []
    vehicle_registry = {}
    team_registry = {}
    for entity_data in entity_response_capabilities.get("entities", []):
        var entity_key := str(entity_data.get("id", ""))
        if not entity_key.is_empty():
            entity_resources[entity_key] = {"base_neighborhood": "", "base_id": "", "bases": {}, "tnur_centres": {}, "teams": [], "vehicles": [], "parent_entity_id": "BRIGADA" if entity_key == "TNUR" else "", "is_independent_base": false if entity_key == "TNUR" else true}
    maintenance = {}
    construction = {}
    progression = {"episode": 1, "season": 1}
    initialized = true
    _emit_runtime_changed()
    return get_status()

func _load_json(file_name: String, fallback: Variant) -> Variant:
    var path := DATA + file_name
    if not FileAccess.file_exists(path):
        return fallback
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        return fallback
    var parsed = JSON.parse_string(f.get_as_text())
    return parsed if parsed != null else fallback

func set_paused(value: bool) -> void:
    paused = value

func tick(minutes: int = 1) -> void:
    if not initialized or paused:
        return
    sim_minute += maxi(minutes, 0)
    if sim_minute >= 1440:
        sim_minute %= 1440
        day += 1
    _tick_incidents()
    _tick_dispatches(maxi(minutes, 0))
    _tick_maintenance()
    _tick_construction()

func create_incident(kind: String, neighborhood: String) -> Dictionary:
    var incident := {
        "id": "INC-%06d" % (incidents.size() + 1),
        "type": kind,
        "neighborhood": neighborhood,
        "state": "detected",
        "progress": 0.0,
        "assigned_resources": [],
        "history": [{"state": "detected", "day": day, "minute": sim_minute}],
        "created_day": day,
        "created_minute": sim_minute
    }
    incidents.append(incident)
    return incident

func advance_incident(id: String, new_state: String) -> bool:
    for i in incidents.size():
        if incidents[i].get("id") == id:
            incidents[i]["state"] = new_state
            incidents[i]["progress"] = 1.0 if new_state in ["resolved", "closed"] else incidents[i].get("progress", 0.0)
            return true
    return false

func add_transaction(kind: String, amount_cents: int, actor_id: String = "") -> Dictionary:
    if not bool(economy.get("configured", false)) or economy.get("balance", null) == null:
        return {"ok": false, "error": "Economia por definir; transação não registada."}
    var tx := {
        "id": "TX-%06d" % (economy.get("transactions", []).size() + 1),
        "kind": kind,
        "amount_cents": amount_cents,
        "actor_id": actor_id,
        "day": day,
        "minute": sim_minute
    }
    economy["balance"] = int(economy.get("balance", 0)) + amount_cents
    economy["transactions"].append(tx)
    tx["ok"] = true
    return tx

func set_weather(state: String, intensity: float = 0.0) -> void:
    weather = {"state": state, "intensity": clampf(intensity, 0.0, 1.0)}

func set_asset_state(asset_id: String, state: String) -> void:
    maintenance[asset_id] = state

func set_construction(site_id: String, state: String) -> void:
    construction[site_id] = state

func set_traffic_state(area_id: String, state: String) -> void:
    traffic[area_id] = state

func set_person_state(person_id: String, state: Dictionary) -> void:
    var existing: Dictionary = memories.get(person_id, {})
    existing["current"] = state
    memories[person_id] = existing

func set_family(family_id: String, members: Array) -> void:
    families[family_id] = members

func advance_episode() -> Dictionary:
    var season := int(progression.get("season", 1))
    var episode := int(progression.get("episode", 1))
    if season >= 20 and episode >= 10:
        progression["season"] = 20
        progression["episode"] = 10
        progression["completed"] = true
        return progression
    episode += 1
    if episode > 10:
        episode = 1
        season += 1
    progression["season"] = clampi(season, 1, 20)
    progression["episode"] = clampi(episode, 1, 10)
    progression["completed"] = false
    return progression


# ===== CANONICAL V0.3.0 INTEGRATION HUB =====
signal runtime_changed(status: Dictionary)
var systems_registry: Dictionary = {}
var entity_contracts: Dictionary = {}
var entity_response_capabilities: Dictionary = {}
var entity_operations_config: Dictionary = {}
var entity_master_catalog: Dictionary = {}
var entity_profiles: Dictionary = {}
var entity_services: Dictionary = {}
var entity_resources: Dictionary = {}
var vehicle_registry: Dictionary = {}
var team_registry: Dictionary = {}
var incident_config: Dictionary = {}
var weather_config: Dictionary = {}
var traffic_config: Dictionary = {}
var construction_config: Dictionary = {}
var maintenance_config: Dictionary = {}
var progression_config: Dictionary = {}
var animation_catalog: Dictionary = {}
var narrative: Dictionary = {}
var episodes_catalog: Dictionary = {}
var city_node: Node = null
var ui_state: Dictionary = {}
var external_world_state: Dictionary = {}

func _load_all_configs() -> void:
    systems_registry = _load_json("systems_registry.json", {})
    entity_contracts = _load_json("entity_contracts.json", {})
    entity_response_capabilities = _load_json("entity_response_capabilities.json", {})
    entity_operations_config = _load_json("entity_operations_registry.json", {})
    entity_master_catalog = _load_json("entity_master_catalog.json", {})
    incident_config = _load_json("incident_config.json", {})
    weather_config = _load_json("weather_config.json", {})
    traffic_config = _load_json("traffic_config.json", {})
    construction_config = _load_json("construction_config.json", {})
    maintenance_config = _load_json("maintenance_config.json", {})
    progression_config = _load_json("progression_config.json", {})
    animation_catalog = _load_json("animation_catalog.json", {})
    narrative = _load_json("V030_CONSOLIDACAO_TEMPORAL_NARRATIVA.json", {})
    episodes_catalog = _load_json("episodes_200.json", {})

func register_city(node: Node) -> void:
    city_node = node
    external_world_state["city_connected"] = is_instance_valid(node)
    _emit_runtime_changed()

func register_ui(state: Dictionary) -> void:
    ui_state = state.duplicate(true)
    _emit_runtime_changed()

func sync_world(state: Dictionary) -> void:
    external_world_state = state.duplicate(true)
    if state.has("weather"):
        set_weather(str(state["weather"]))
    if state.has("traffic"):
        set_traffic_state("city", str(state["traffic"]))
    if state.has("families") and state["families"] is Dictionary:
        families = state["families"].duplicate(true)
    if state.has("population") and state["population"] is Array:
        population = state["population"].duplicate(true)
    _emit_runtime_changed()

func sync_progression(season: int, episode: int) -> void:
    progression["season"] = clampi(season, 1, 20)
    progression["episode"] = clampi(episode, 1, 10)
    _emit_runtime_changed()

func get_current_episode() -> Dictionary:
    var season := int(progression.get("season", 1))
    var episode := int(progression.get("episode", 1))
    for item in episodes_catalog.get("episodes", []):
        if int(item.get("season", 0)) == season and int(item.get("episode", 0)) == episode:
            return item
    return {}

func get_narrative_state() -> Dictionary:
    var result := narrative.duplicate(true)
    result["current_season"] = int(progression.get("season", 1))
    result["current_episode"] = int(progression.get("episode", 1))
    return result

func get_integration_status() -> Dictionary:
    return {
        "runtime": initialized,
        "city": is_instance_valid(city_node),
        "ui": not ui_state.is_empty(),
        "systems_registry": not systems_registry.is_empty(),
        "entity_contracts": not entity_contracts.is_empty(),
        "entity_response_capabilities": not entity_response_capabilities.is_empty(),
        "dispatches": dispatches.size(),
        "registered_teams": team_registry.size(),
        "registered_vehicles": vehicle_registry.size(),
        "incidents": not incident_config.is_empty(),
        "weather": not weather_config.is_empty(),
        "traffic": not traffic_config.is_empty(),
        "construction": not construction_config.is_empty(),
        "maintenance": not maintenance_config.is_empty(),
        "progression": not progression_config.is_empty(),
        "animations": not animation_catalog.is_empty(),
        "narrative": not narrative.is_empty(),
        "episodes_catalog": not episodes_catalog.is_empty(),
        "episode": int(progression.get("episode", 1)),
        "season": int(progression.get("season", 1))
    }

func _emit_runtime_changed() -> void:
    runtime_changed.emit(get_status())

func get_status() -> Dictionary:
    return {
        "initialized": initialized,
        "paused": paused,
        "day": day,
        "sim_minute": sim_minute,
        "population_count": population.size(),
        "families_count": families.size(),
        "incidents_count": incidents.size(),
        "dispatches_count": dispatches.size(),
        "teams_count": team_registry.size(),
        "vehicles_count": vehicle_registry.size(),
        "economy_balance_cents": economy.get("balance", null),
        "economy_configured": bool(economy.get("configured", false)),
        "weather": weather,
        "maintenance_count": maintenance.size(),
        "construction_count": construction.size(),
        "traffic_areas": traffic.size(),
        "progression": progression
    }

func _tick_incidents() -> void:
    for incident in incidents:
        if incident["state"] in ["detected", "dispatch", "response", "on_scene", "stabilized"]:
            incident["progress"] = minf(float(incident.get("progress", 0.0)) + 0.01, 1.0)

func _tick_maintenance() -> void:
    # Reparação não avança por um prazo inventado. A transição é explícita
    # até serem definidos duração, recursos e critérios de inspeção.
    return

func _tick_construction() -> void:
    # Construção não passa automaticamente à inspeção sem prazos e condições
    # aprovados. O estado mantém-se até uma transição explícita.
    return

func advance_maintenance(asset_id: String, next_state: String) -> Dictionary:
    var allowed := ["operational", "degraded", "damaged", "offline", "under_repair", "restored"]
    if not maintenance.has(asset_id):
        return {"ok": false, "error": "Ativo não registado para manutenção."}
    if not next_state in allowed:
        return {"ok": false, "error": "Estado de manutenção inválido."}
    maintenance[asset_id] = next_state
    return {"ok": true, "asset_id": asset_id, "state": next_state}

func advance_construction(site_id: String, next_state: String) -> Dictionary:
    var allowed := ["planned", "licensed", "construction", "delayed", "inspection", "opened", "renovation", "demolition"]
    if not construction.has(site_id):
        return {"ok": false, "error": "Obra não registada."}
    if not next_state in allowed:
        return {"ok": false, "error": "Estado de construção inválido."}
    construction[site_id] = next_state
    return {"ok": true, "site_id": site_id, "state": next_state}


# ===== DESPACHO MULTIENTIDADE V0.3.0 =====
func get_entity_directory(include_integrated_units: bool = true) -> Array:
    var directory: Array = []
    for entity_data in entity_master_catalog.get("entities", []):
        if not entity_data is Dictionary:
            continue
        var organizational_status := str(entity_data.get("organizational_status", "entity"))
        if not include_integrated_units and organizational_status == "integrated_unit":
            continue
        var profile_id := str(entity_data.get("id", ""))
        var profile: Dictionary = entity_profiles.get(profile_id, {})
        directory.append({
            "id": profile_id,
            "name": str(entity_data.get("name", profile_id)),
            "organizational_status": organizational_status,
            "parent_entity_id": entity_data.get("parent_entity_id", null),
            "status": str(profile.get("status", "not_configured")),
            "purpose": str(entity_data.get("purpose", "")),
            "services": entity_data.get("services", []).duplicate(true),
            "can_dispatch": bool(entity_data.get("can_dispatch", false))
        })
    return directory

func get_entity_profile(entity_id: String) -> Dictionary:
    if not entity_profiles.has(entity_id):
        return {"ok": false, "error": "unknown_entity", "entity_id": entity_id}
    return {"ok": true, "profile": entity_profiles[entity_id].duplicate(true)}

func set_entity_operational_status(entity_id: String, new_status: String, reason: String = "") -> Dictionary:
    var allowed := ["not_configured", "operational", "restricted", "suspended", "under_construction", "closed"]
    if not entity_profiles.has(entity_id):
        return {"ok": false, "error": "unknown_entity", "entity_id": entity_id}
    if not allowed.has(new_status):
        return {"ok": false, "error": "invalid_status", "allowed": allowed}
    var profile: Dictionary = entity_profiles[entity_id]
    profile["status"] = new_status
    profile["status_reason"] = reason
    profile["status_day"] = day
    profile["status_minute"] = sim_minute
    entity_profiles[entity_id] = profile
    _emit_runtime_changed()
    return {"ok": true, "entity_id": entity_id, "status": new_status}

func register_entity_service(entity_id: String, service_id: String, service_name: String, service_status: String = "not_configured", supported_types: Array = []) -> Dictionary:
    if not entity_profiles.has(entity_id):
        return {"ok": false, "error": "unknown_entity", "entity_id": entity_id}
    if service_id.strip_edges() == "" or service_name.strip_edges() == "":
        return {"ok": false, "error": "service_id_and_name_required"}
    var services: Array = entity_services.get(entity_id, [])
    for existing in services:
        if str(existing.get("id", "")) == service_id:
            return {"ok": false, "error": "duplicate_service_id", "service_id": service_id}
    services.append({"id": service_id, "name": service_name, "status": service_status, "supported_types": supported_types.duplicate(true)})
    entity_services[entity_id] = services
    _emit_runtime_changed()
    return {"ok": true, "entity_id": entity_id, "service_id": service_id}

func get_entity_services(entity_id: String) -> Array:
    return entity_services.get(entity_id, []).duplicate(true)

func validate_entity_master_catalog() -> Dictionary:
    var errors: Array = []
    var ids: Dictionary = {}
    var rows: Array = entity_master_catalog.get("entities", [])
    for entity_data in rows:
        if not entity_data is Dictionary:
            errors.append("entity_row_not_dictionary")
            continue
        var entity_id := str(entity_data.get("id", "")).strip_edges()
        if entity_id == "":
            errors.append("entity_id_missing")
        elif ids.has(entity_id):
            errors.append("duplicate_entity_id:" + entity_id)
        else:
            ids[entity_id] = true
        for required in ["name", "organizational_status", "purpose", "services", "dependencies", "constraints"]:
            if not entity_data.has(required):
                errors.append("missing_field:%s:%s" % [entity_id, required])
        if str(entity_data.get("organizational_status", "")) == "integrated_unit":
            var parent := str(entity_data.get("parent_entity_id", ""))
            if parent == "" or not ids.has(parent):
                errors.append("integrated_unit_parent_missing:%s" % entity_id)
            if entity_id == "TNUR" and (parent != "BRIGADA" or bool(entity_data.get("standalone_base_allowed", false))):
                errors.append("tnur_integration_rule_invalid")
    var deferred: Array = entity_master_catalog.get("deferred_fields", [])
    for field in ["staffing", "economy", "installation_count", "vehicles", "inventory", "budget", "balance"]:
        if not deferred.has(field):
            errors.append("deferred_field_not_declared:" + field)
    return {"ok": errors.is_empty(), "entity_rows": rows.size(), "unique_ids": ids.size(), "errors": errors, "deferred_fields": deferred.duplicate(true)}

func get_entity_capability(entity_id: String) -> Dictionary:
    for entity in entity_response_capabilities.get("entities", []):
        if str(entity.get("id", "")) == entity_id:
            return entity.duplicate(true)
    return {}

func register_entity_resources(entity_id: String, base_neighborhood: String, teams: Array, vehicles: Array, base_id: String = "", host_brigada_base_id: String = "") -> Dictionary:
    var entity := get_entity_capability(entity_id)
    if entity.is_empty():
        return {"ok": false, "error": "Entidade desconhecida.", "entity_id": entity_id}
    if not base_neighborhood.is_empty() and is_instance_valid(city_node):
        if not city_node.has_method("get_route_between_neighborhoods"):
            return {"ok": false, "error": "A cidade não disponibiliza cálculo de percursos."}
        var validation: Dictionary = city_node.call("get_route_between_neighborhoods", base_neighborhood, base_neighborhood)
        if not validation.get("ok", false):
            return {"ok": false, "error": "Base/bairro desconhecido.", "base_neighborhood": base_neighborhood}

    # BRIGADA owns the physical bases. TNUR can only register a centre hosted
    # by an already registered BRIGADA base; it can never create a standalone base.
    if entity_id == "BRIGADA":
        var brigada_base_id := base_id.strip_edges()
        if brigada_base_id.is_empty():
            brigada_base_id = "BRIGADA-BASE-" + base_neighborhood.strip_edges().to_upper().replace(" ", "_")
        if base_neighborhood.strip_edges().is_empty():
            return {"ok": false, "error": "Uma base BRIGADA tem de indicar o bairro."}
        if not entity_resources.has("BRIGADA"):
            entity_resources["BRIGADA"] = {"base_neighborhood": "", "base_id": "", "bases": {}, "tnur_centres": {}, "teams": [], "vehicles": []}
        var brigada_data: Dictionary = entity_resources["BRIGADA"]
        var bases: Dictionary = brigada_data.get("bases", {})
        var existing_base: Dictionary = bases.get(brigada_base_id, {"base_id": brigada_base_id, "base_neighborhood": base_neighborhood, "tnur_centres": []})
        existing_base["base_id"] = brigada_base_id
        existing_base["base_neighborhood"] = base_neighborhood
        if not (existing_base.get("tnur_centres", []) is Array):
            existing_base["tnur_centres"] = []
        bases[brigada_base_id] = existing_base
        brigada_data["bases"] = bases
        if str(brigada_data.get("base_id", "")).is_empty():
            brigada_data["base_id"] = brigada_base_id
            brigada_data["base_neighborhood"] = base_neighborhood
        entity_resources["BRIGADA"] = brigada_data
        base_id = brigada_base_id
    elif entity_id == "TNUR":
        var brigada_data: Dictionary = entity_resources.get("BRIGADA", {})
        var brigada_bases: Dictionary = brigada_data.get("bases", {})
        var host_id := host_brigada_base_id.strip_edges()
        if host_id.is_empty() or not brigada_bases.has(host_id):
            return {"ok": false, "error": "TNUR não pode criar base própria. Indique uma base BRIGADA existente em host_brigada_base_id.", "entity_id": "TNUR", "standalone_base_allowed": false}
        var host_base: Dictionary = brigada_bases[host_id]
        if str(host_base.get("base_neighborhood", "")) != base_neighborhood:
            return {"ok": false, "error": "O centro TNUR tem de usar o bairro da base BRIGADA anfitriã.", "host_brigada_base_id": host_id}
        var centre_id := base_id.strip_edges()
        if centre_id.is_empty():
            centre_id = "TNUR-CENTRE-" + str(entity_resources.get("TNUR", {}).get("tnur_centres", {}).size() + 1).pad_zeros(3)
        var tnur_data: Dictionary = entity_resources.get("TNUR", {"base_neighborhood": "", "base_id": "", "bases": {}, "tnur_centres": {}, "teams": [], "vehicles": [], "parent_entity_id": "BRIGADA", "is_independent_base": false})
        var centres: Dictionary = tnur_data.get("tnur_centres", {})
        centres[centre_id] = {"centre_id": centre_id, "host_entity_id": "BRIGADA", "host_brigada_base_id": host_id, "base_neighborhood": base_neighborhood, "is_independent_base": false}
        tnur_data["tnur_centres"] = centres
        tnur_data["parent_entity_id"] = "BRIGADA"
        tnur_data["is_independent_base"] = false
        if str(tnur_data.get("base_neighborhood", "")).is_empty():
            tnur_data["base_neighborhood"] = base_neighborhood
        entity_resources["TNUR"] = tnur_data
        var hosted_centres: Array = host_base.get("tnur_centres", [])
        if not hosted_centres.has(centre_id):
            hosted_centres.append(centre_id)
        host_base["tnur_centres"] = hosted_centres
        brigada_bases[host_id] = host_base
        brigada_data["bases"] = brigada_bases
        entity_resources["BRIGADA"] = brigada_data

    var clean_teams: Array = []
    var clean_vehicles: Array = []
    for team_variant in teams:
        if not (team_variant is Dictionary):
            continue
        var team: Dictionary = team_variant.duplicate(true)
        var team_id := str(team.get("id", ""))
        if team_id.is_empty():
            continue
        team["entity_id"] = entity_id
        team["state"] = str(team.get("state", "available"))
        team["skills"] = team.get("skills", [])
        if entity_id == "TNUR":
            team["parent_entity_id"] = "BRIGADA"
            team["host_brigada_base_id"] = host_brigada_base_id
        team_registry[team_id] = team
        clean_teams.append(team_id)
    for vehicle_variant in vehicles:
        if not (vehicle_variant is Dictionary):
            continue
        var vehicle: Dictionary = vehicle_variant.duplicate(true)
        var vehicle_id := str(vehicle.get("id", ""))
        if vehicle_id.is_empty():
            continue
        vehicle["entity_id"] = entity_id
        vehicle["state"] = str(vehicle.get("state", "available"))
        vehicle["incident_types"] = vehicle.get("incident_types", [])
        if entity_id == "TNUR":
            vehicle["parent_entity_id"] = "BRIGADA"
            vehicle["host_brigada_base_id"] = host_brigada_base_id
        vehicle_registry[vehicle_id] = vehicle
        clean_vehicles.append(vehicle_id)

    var target_data: Dictionary = entity_resources.get(entity_id, {"base_neighborhood": "", "base_id": "", "bases": {}, "tnur_centres": {}, "teams": [], "vehicles": []})
    var all_teams: Array = target_data.get("teams", [])
    var all_vehicles: Array = target_data.get("vehicles", [])
    for team_id in clean_teams:
        if not all_teams.has(team_id): all_teams.append(team_id)
    for vehicle_id in clean_vehicles:
        if not all_vehicles.has(vehicle_id): all_vehicles.append(vehicle_id)
    target_data["teams"] = all_teams
    target_data["vehicles"] = all_vehicles
    if entity_id != "BRIGADA" and entity_id != "TNUR":
        target_data["base_neighborhood"] = base_neighborhood
        target_data["base_id"] = base_id
    entity_resources[entity_id] = target_data
    _emit_runtime_changed()
    return {"ok": true, "entity_id": entity_id, "base_id": base_id, "host_brigada_base_id": host_brigada_base_id if entity_id == "TNUR" else "", "standalone_base_allowed": false if entity_id == "TNUR" else true, "teams_registered": clean_teams.size(), "vehicles_registered": clean_vehicles.size()}

func unregister_entity_resource(resource_id: String) -> bool:
    if vehicle_registry.has(resource_id):
        if str(vehicle_registry[resource_id].get("state", "")) == "busy":
            return false
        vehicle_registry.erase(resource_id)
        for entity_id in entity_resources:
            entity_resources[entity_id]["vehicles"].erase(resource_id)
        _emit_runtime_changed()
        return true
    if team_registry.has(resource_id):
        if str(team_registry[resource_id].get("state", "")) == "busy":
            return false
        team_registry.erase(resource_id)
        for entity_id in entity_resources:
            entity_resources[entity_id]["teams"].erase(resource_id)
        _emit_runtime_changed()
        return true
    return false

func _resource_supports(resource: Dictionary, incident_type: String) -> bool:
    var supported: Array = resource.get("incident_types", [])
    return supported.is_empty() or supported.has(incident_type)

func _team_supports(team: Dictionary, incident_type: String) -> bool:
    var skills: Array = team.get("skills", [])
    return skills.is_empty() or skills.has(incident_type)

func _find_available_team(entity_id: String, incident_type: String) -> Dictionary:
    var entity_data: Dictionary = entity_resources.get(entity_id, {})
    for team_id in entity_data.get("teams", []):
        var team: Dictionary = team_registry.get(str(team_id), {})
        if team.get("state", "available") == "available" and _team_supports(team, incident_type):
            return team
    return {}

func _find_available_vehicle(entity_id: String, incident_type: String) -> Dictionary:
    var entity_data: Dictionary = entity_resources.get(entity_id, {})
    for vehicle_id in entity_data.get("vehicles", []):
        var vehicle: Dictionary = vehicle_registry.get(str(vehicle_id), {})
        if vehicle.get("state", "available") == "available" and _resource_supports(vehicle, incident_type):
            return vehicle
    return {}

func dispatch_entity(entity_id: String, incident_id: String, origin_neighborhood: String, destination_neighborhood: String = "") -> Dictionary:
    var entity := get_entity_capability(entity_id)
    if entity.is_empty():
        return {"ok": false, "error": "Entidade desconhecida.", "entity_id": entity_id}
    if not entity.get("dispatchable", false):
        if entity.get("non_urgent_transport", false):
            return {"ok": false, "error": "TNUR só executa transportes não urgentes planeados.", "entity_id": entity_id}
        return {"ok": false, "error": "Esta entidade não é uma unidade de despacho operacional.", "entity_id": entity_id}
    var incident: Dictionary = {}
    for item in incidents:
        if str(item.get("id", "")) == incident_id:
            incident = item
            break
    if incident.is_empty():
        return {"ok": false, "error": "Ocorrência não encontrada.", "incident_id": incident_id}
    var incident_type := _normalize_incident_type(str(incident.get("type", "")))
    var primary_types: Array = entity.get("incident_types", [])
    var support_types: Array = entity.get("support_types", [])
    var response_role := "primary"
    if not primary_types.has(incident_type):
        if support_types.has(incident_type):
            response_role = "support"
        else:
            return {"ok": false, "error": "A entidade não tem competência registada para esta ocorrência.", "entity_id": entity_id, "incident_type": incident_type}
    if not is_instance_valid(city_node) or not city_node.has_method("get_route_between_neighborhoods"):
        return {"ok": false, "error": "A cidade e a rede rodoviária ainda não estão ligadas ao runtime."}
    var entity_data: Dictionary = entity_resources.get(entity_id, {})
    var base_neighborhood := str(entity_data.get("base_neighborhood", origin_neighborhood))
    var route_destination := destination_neighborhood if not destination_neighborhood.is_empty() else str(incident.get("neighborhood", ""))
    var route: Dictionary = city_node.call("get_route_between_neighborhoods", base_neighborhood, route_destination)
    if not route.get("ok", false):
        return {"ok": false, "error": str(route.get("error", "Não foi possível calcular o percurso.")), "route": route}
    var team := _find_available_team(entity_id, incident_type)
    if team.is_empty():
        return {"ok": false, "error": "Não existe equipa disponível e habilitada nesta entidade.", "entity_id": entity_id}
    var vehicle := _find_available_vehicle(entity_id, incident_type)
    if vehicle.is_empty():
        return {"ok": false, "error": "Não existe viatura disponível e compatível nesta entidade.", "entity_id": entity_id}
    var distance := float(route.get("distance", 0.0))
    var travel_minutes := maxi(1, int(ceil(distance / maxf(travel_speed_units_per_minute, 0.01) * maxf(traffic_delay_factor, 1.0))))
    var dispatch_id := "DSP-%06d" % (dispatches.size() + 1)
    team["state"] = "busy"
    team["current_dispatch_id"] = dispatch_id
    team_registry[str(team["id"])] = team
    vehicle["state"] = "busy"
    vehicle["current_dispatch_id"] = dispatch_id
    vehicle_registry[str(vehicle["id"])] = vehicle
    var record := {
        "id": dispatch_id,
        "entity_id": entity_id,
        "entity_name": str(entity.get("name", entity_id)),
        "incident_id": incident_id,
        "incident_type": incident_type,
        "response_role": response_role,
        "team_id": str(team["id"]),
        "vehicle_id": str(vehicle["id"]),
        "origin_neighborhood": base_neighborhood,
        "destination_neighborhood": route_destination,
        "route": route.get("path", []),
        "distance": distance,
        "estimated_travel_minutes": travel_minutes,
        "elapsed_travel_minutes": 0,
        "state": "en_route",
        "created_day": day,
        "created_minute": sim_minute
    }
    dispatches.append(record)
    incident["state"] = "dispatch"
    if not incident.get("assigned_resources", []) is Array:
        incident["assigned_resources"] = []
    if not incident.get("history", []) is Array:
        incident["history"] = []
    incident["assigned_resources"].append({"entity_id": entity_id, "dispatch_id": dispatch_id, "team_id": str(team["id"]), "vehicle_id": str(vehicle["id"]), "role": response_role})
    incident["history"].append({"state": "dispatch", "entity_id": entity_id, "dispatch_id": dispatch_id, "day": day, "minute": sim_minute})
    _emit_runtime_changed()
    return {"ok": true, "dispatch": record.duplicate(true), "route": route.duplicate(true)}

func _tick_dispatches(minutes: int) -> void:
    if minutes <= 0:
        return
    for i in range(dispatches.size()):
        var record: Dictionary = dispatches[i]
        if str(record.get("state", "")) != "en_route":
            continue
        record["elapsed_travel_minutes"] = int(record.get("elapsed_travel_minutes", 0)) + minutes
        if int(record["elapsed_travel_minutes"]) >= int(record.get("estimated_travel_minutes", 1)):
            record["state"] = "on_scene"
            record["arrival_day"] = day
            record["arrival_minute"] = sim_minute
            _update_incident_for_dispatch(record, "on_scene")
        dispatches[i] = record

func _update_incident_for_dispatch(dispatch: Dictionary, new_state: String) -> void:
    for incident in incidents:
        if str(incident.get("id", "")) != str(dispatch.get("incident_id", "")):
            continue
        incident["state"] = new_state
        if not incident.get("history", []) is Array:
            incident["history"] = []
        incident["history"].append({"state": new_state, "dispatch_id": str(dispatch.get("id", "")), "day": day, "minute": sim_minute})
        break

func complete_dispatch(dispatch_id: String, incident_resolved: bool = false) -> Dictionary:
    for i in range(dispatches.size()):
        var record: Dictionary = dispatches[i]
        if str(record.get("id", "")) != dispatch_id:
            continue
        if str(record.get("state", "")) == "completed":
            return {"ok": false, "error": "Este despacho já foi concluído."}
        record["state"] = "completed"
        record["completed_day"] = day
        record["completed_minute"] = sim_minute
        dispatches[i] = record
        for resource_id in [str(record.get("team_id", "")), str(record.get("vehicle_id", ""))]:
            if team_registry.has(resource_id):
                team_registry[resource_id]["state"] = "available"
                team_registry[resource_id].erase("current_dispatch_id")
            if vehicle_registry.has(resource_id):
                vehicle_registry[resource_id]["state"] = "available"
                vehicle_registry[resource_id].erase("current_dispatch_id")
        if incident_resolved:
            _update_incident_for_dispatch(record, "resolved")
        _emit_runtime_changed()
        return {"ok": true, "dispatch": record.duplicate(true)}
    return {"ok": false, "error": "Despacho desconhecido.", "dispatch_id": dispatch_id}

func plan_non_urgent_transport(origin_neighborhood: String, destination_neighborhood: String, passenger_count: int = 1) -> Dictionary:
    if passenger_count < 1:
        return {"ok": false, "error": "O número de passageiros tem de ser pelo menos 1."}
    var entity := get_entity_capability("TNUR")
    if entity.is_empty() or not entity.get("non_urgent_transport", false):
        return {"ok": false, "error": "A capacidade TNUR não está configurada."}
    if not is_instance_valid(city_node) or not city_node.has_method("get_route_between_neighborhoods"):
        return {"ok": false, "error": "A rede rodoviária ainda não está disponível."}
    var route: Dictionary = city_node.call("get_route_between_neighborhoods", origin_neighborhood, destination_neighborhood)
    if not route.get("ok", false):
        return {"ok": false, "error": str(route.get("error", "Percurso indisponível."))}
    var team := _find_available_team("TNUR", "non_urgent_transport")
    var vehicle := _find_available_vehicle("TNUR", "non_urgent_transport")
    if team.is_empty() or vehicle.is_empty():
        return {"ok": false, "error": "Não existe equipa TNUR e viatura disponíveis para este transporte."}
    var transport_id := "TNUR-%06d" % (dispatches.size() + 1)
    team["state"] = "busy"
    team["current_dispatch_id"] = transport_id
    team_registry[str(team["id"])] = team
    vehicle["state"] = "busy"
    vehicle["current_dispatch_id"] = transport_id
    vehicle_registry[str(vehicle["id"])] = vehicle
    var record := {
        "id": transport_id,
        "entity_id": "TNUR",
        "entity_name": "TNUR",
        "service_type": "non_urgent_transport",
        "passenger_count": passenger_count,
        "team_id": str(team["id"]),
        "vehicle_id": str(vehicle["id"]),
        "origin_neighborhood": origin_neighborhood,
        "destination_neighborhood": destination_neighborhood,
        "route": route.get("path", []),
        "distance": float(route.get("distance", 0.0)),
        "estimated_travel_minutes": maxi(1, int(ceil(float(route.get("distance", 0.0)) / maxf(travel_speed_units_per_minute, 0.01) * maxf(traffic_delay_factor, 1.0)))),
        "elapsed_travel_minutes": 0,
        "state": "planned",
        "created_day": day,
        "created_minute": sim_minute
    }
    dispatches.append(record)
    _emit_runtime_changed()
    return {"ok": true, "transport": record.duplicate(true), "route": route.duplicate(true)}

func get_dispatch_summary() -> Dictionary:
    var by_entity := {}
    for record in dispatches:
        var key := str(record.get("entity_id", "unknown"))
        by_entity[key] = int(by_entity.get(key, 0)) + 1
    return {"count": dispatches.size(), "by_entity": by_entity}


func _normalize_incident_type(raw_type: String) -> String:
    var aliases := {
        "INC-FIRE": "fire_structure",
        "INC-ROAD": "traffic_collision",
        "INC-MED": "medical_response",
        "INC-RES": "rescue_person",
        "INC-FLOOD": "flood_water",
        "INC-STORM": "storm",
        "INC-VEH": "vehicle_hazard",
        "INC-URBAN": "urban_response",
        "INC-MISSING": "search_operation",
        "INC-FIRE-WILD": "wildfire"
    }
    return str(aliases.get(raw_type, raw_type))

#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REPORT="${1:-preflight-v0.3.0-report.txt}"
cd "$ROOT"
mkdir -p "$(dirname "$REPORT")"
touch "$REPORT"
pass(){ echo "PASS|$1" | tee -a "$REPORT"; }
fail(){ echo "FAIL|$1" | tee -a "$REPORT"; exit 1; }
need(){ test -f "$1" || fail "Ficheiro em falta: $1"; }
need project.godot; need Main.tscn; need main.gd; need export_presets.cfg

grep -q 'config/version="0.3.0"' project.godot || fail "Projeto não está em V0.3.0"
grep -q 'run/main_scene="res://Main.tscn"' project.godot || fail "Cena principal incorreta"
grep -q 'res://main.gd' Main.tscn || fail "Script principal não ligado"
grep -q 'name="Android"' export_presets.cfg || fail "Preset Android em falta"
grep -q 'version/name="0.3.0"' export_presets.cfg || fail "Preset Android não está em V0.3.0"
grep -q 'version/code=30000' export_presets.cfg || fail "versionCode incorreto"
# Validate active version metadata, not historical helper names or audit documents.
grep -q 'config/version="0.3.0"' project.godot || fail "Metadados ativos fora da V0.3.0"
grep -q 'version/name="0.3.0"' export_presets.cfg || fail "Preset Android fora da V0.3.0"
python3 - <<'PY'
import re, pathlib
s=pathlib.Path('main.gd').read_text()
funcs=re.findall(r'^func\s+([A-Za-z0-9_]+)\s*\(',s,re.M)
consts=re.findall(r'^const\s+([A-Za-z0-9_]+)',s,re.M)
assert len(funcs)==len(set(funcs)), 'funções duplicadas'
assert len(consts)==len(set(consts)), 'constantes duplicadas'
for fn in ['v030_initialize_all_systems','v030_update_all_systems','v030_save_state','v030_get_missions','v030_get_finance']:
    assert re.search(r'^func\s+'+re.escape(fn)+r'\s*\(',s,re.M), fn
assert 'money += 25.0' not in s and 'Dinheiro: €' not in s, 'economia pessoal de demonstração continua ativa'
assert 'salario\":1100.0' not in s and '\"renda\":250.0' not in s, 'valores salariais/despesas fictícios continuam ativos'
assert 'PREÇOS POR DEFINIR' in s and 'CUSTOS POR DEFINIR' in s, 'UI não assinala economia pendente'
runtime=pathlib.Path('systems/valepolis_systems_runtime.gd').read_text()
assert 'economy.get("balance", null) == null' in runtime, 'runtime permite transações sem saldo configurado'
city=pathlib.Path('systems/city_3d.gd').read_text()
assert '_build_registered_installations()' in city and 'get_map_spawnable_installations' in city, 'mapa 3D sem integração de instalações aprovadas'
print('STATIC|main.gd sem duplicados; economia bloqueada; instalações 3D com ativação explícita')
PY
pass "Estrutura V0.3.0"
pass "Android V0.3.0"
pass "Metadados ativos em V0.3.0"
pass "Funções/constantes sem duplicação"
pass "Sistemas principais V0.3.0 presentes"
python3 tools/preflight_installations.py | tee -a "$REPORT"
python3 tools/preflight_project.py | tee -a "$REPORT"
pass "Auditoria estática de referências, sistemas e regras concluída"
pass "Registo de instalações validado estaticamente"
python3 - <<'PY2'
import json, pathlib
b=json.loads(pathlib.Path("bairros_valepolis.json").read_text())
a=json.loads(pathlib.Path("data/architectural_identity_v030.json").read_text())
c=json.loads(pathlib.Path("data/cultural_identity_v030.json").read_text())
expected=[x["name"] for x in b["neighborhoods"]]
profiles=a.get("neighborhoods", [])
assert len(expected)==25 and len(set(expected))==25, "lista oficial de bairros inválida"
assert [x.get("name") for x in profiles]==expected, "perfis arquitetónicos não correspondem à lista oficial"
assert len(c.get("cultures", []))==6, "devem existir seis influências culturais"
expected_cultures = {
    "Portuguesa": "Portávia",
    "Italiana": "Solária",
    "Alemã": "Pedravora",
    "Francesa": "Altavira",
    "Asiática": "Lacéria",
    "Africana": "Ribeora",
}
actual_cultures = {x.get("name"): x.get("assigned_neighborhood") for x in c["cultures"]}
assert actual_cultures == expected_cultures, "atribuições culturais não correspondem à distribuição aprovada"
assert len(c.get("local_identities", []))==10, "devem existir dez identidades locais distintas"
assert len(set(x["name"] for x in c["local_identities"]))==10, "identidades locais duplicadas"
city=pathlib.Path("systems/city_3d.gd").read_text()
assert "_load_architectural_profiles()" in city and "_architectural_profiles.get" in city, "gerador 3D não carrega perfis arquitetónicos"
print("STATIC|25 perfis arquitetónicos e seis influências culturais validados")
PY2
pass "Perfis arquitetónicos e requisitos culturais validados estaticamente"
if grep -R -nE "^func v020_|^const V020_|^var v020_" --include="*.gd" . >/dev/null; then
  echo "INFO|Símbolos V0.2 encontrados; rever dependências antes de remover." | tee -a "$REPORT"
else
  echo "PASS|Sem funções/constantes/variáveis com prefixo V0.2 ativo." | tee -a "$REPORT"
fi
echo "RESULT=PASS" | tee -a "$REPORT"

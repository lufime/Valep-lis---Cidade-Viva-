# Valepólis V0.3.0 — FASE 6.2.16: auditoria e reorganização das layers

## Resultado da auditoria do código
- O renderizador desenhava `meshes` pela ordem em que eram adicionadas, sem prioridade semântica explícita.
- A cena mistura terreno, polígonos dos bairros, água, praia, relevo, estradas, marcações, edifícios, fachadas e vegetação.
- A ordem de desenho não substitui o teste de profundidade, mas a ordem implícita torna os empates de profundidade e superfícies quase coplanares difíceis de controlar.
- A rede viária continua a ser gerada proceduralmente entre centros de bairros; esta fase reorganiza o renderizador, não certifica a topologia da rede nem a geografia real.

## Nova ordem de layers
1. `TERRAIN` — terreno base
2. `DISTRICT_SURFACE` — superfícies e limites dos bairros
3. `WATER` — mar e estuário
4. `COAST` — praia
5. `RELIEF` — montanhas e cristas
6. `ROADS` — pavimento viário
7. `ROAD_MARKINGS` — marcações por cima do pavimento
8. `BUILDINGS` — volumes dos edifícios
9. `FACADES` — detalhes das fachadas
10. `VEGETATION_TRUNKS` — troncos
11. `VEGETATION_CROWNS` — copas

O teste de profundidade OpenGL permanece ativo. As layers são ordenadas explicitamente pela prioridade definida em `SceneLayer`.

## Validação
- Confirmado por inspeção estática: as malhas principais recebem layer explícita e o ciclo de desenho usa `sortedBy { it.layer.order }`.
- ZIP reaberto e listado após criação.
- A compilação Android e o teste visual em dispositivo não foram executados neste ambiente; a fase não deve ser marcada como aprovada até o workflow executar esses testes.

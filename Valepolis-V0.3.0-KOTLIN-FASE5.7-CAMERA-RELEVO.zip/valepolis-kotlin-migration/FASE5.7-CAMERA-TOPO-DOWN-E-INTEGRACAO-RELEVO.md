# Fase 5.7 — Câmara e integração do relevo

## Alterações feitas
- Aumentado o campo de visão para 42 graus para reduzir o efeito de faixa estreita no ecrã vertical.
- Alterada a posição da câmara para uma vista mais elevada, mantendo o alvo perto do centro do terreno.
- Recuada a base e a crista da cadeia montanhosa para o interior da área de mapa.
- Reduzida a amplitude da altura da cadeia para evitar uma faixa demasiado dominante.
- Preservados os dados territoriais existentes.

## Limitações
- Costa, estuário e montanha continuam a ser geometria ilustrativa codificada no renderizador.
- Não foram criados nomes ou dados de bairros novos.
- Não foi executada compilação Android nesta sessão; confirmar pelo workflow e testar no dispositivo.

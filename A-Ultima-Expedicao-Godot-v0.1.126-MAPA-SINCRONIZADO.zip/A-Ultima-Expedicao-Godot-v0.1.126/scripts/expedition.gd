extends Node3D

const PLAYER_SCRIPT := preload("res://scripts/player_controller.gd")
const INTERACTABLE_SCRIPT := preload("res://scripts/interactable_door.gd")
const COOP_SWITCH_SCRIPT := preload("res://scripts/coop_switch.gd")
const MODEL_ANIMATOR_SCRIPT := preload("res://scripts/procedural_model_animator.gd")
const PLAYER_EXPEDITION_MODEL_SCENE := preload("res://scenes/PlayerExpeditionSurvivor.tscn")
const PORT := 24567
const ENTITY_SYNC_INTERVAL := 0.08

var network_peer: ENetMultiplayerPeer
var remote_players: Dictionary = {}
var _last_authoritative_player_positions: Dictionary = {}
var switch_owners: Dictionary = {"A": 0, "B": 0}
var coop_solved := false
var network_status: Label
var ip_input: LineEdit
var coop_status: Label
var private_clue: Label
var mission_hub: PanelContainer
var mission_hub_body: Label
var mission_hub_title: Label
var mission_hub_tab := "OBJETIVOS"
var quick_comms_status: Label
var game_paused_by_menu := false
var local_player_id := 1
# Estado dos papéis secretos, mantido no servidor durante a sessão.
var traitor_peer_id: int = 0
var traitor_role_assigned: bool = false
# Single-player: o traidor é uma IA separada da criatura e permanece oculto.
var solo_traitor_timer := 0.0
var solo_traitor_next_action := 38.0
var solo_traitor_presence: Node3D
var solo_traitor_rng := RandomNumberGenerator.new()
var solo_traitor_sabotages := 0
var solo_traitor_glimpse_timer := 0.0
var role_notice_layer: CanvasLayer
var _sync_accumulator := 0.0
var _entity_sync_accumulator := 0.0
var _client_connect_elapsed := 0.0
const CLIENT_CONNECT_TIMEOUT := 12.0
var decision_votes: Dictionary = {}
var decision_resolved := false
var decision_status: Label
var accusation_button: Button
var defense_button: Button
var entity_presence: Node3D
var entity_reaction_label: Label
var entity_active := false
var entity_motion_time := 0.0
var entity_ai_state := "DORMANT"
var entity_waypoint_index := 0
# Navegação A*: grelha local reconstruída periodicamente para detetar portas e obstáculos dinâmicos.
var entity_path: Array[Vector3] = []
var entity_path_cursor := 0
var entity_path_refresh_timer := 0.0
var entity_path_goal := Vector3.ZERO
const ENTITY_PATH_GRID_SIZE := 25
const ENTITY_PATH_CELL_SIZE := 1.2
const ENTITY_PATH_REFRESH_SECONDS := 1.0
var entity_hidden_time := 0.0
var entity_state_time := 0.0
# Captura/sobrevivência: decisão autoritativa no anfitrião.
var capture_target_peer_id := 0
var capture_elapsed := 0.0
var capture_escape_presses := 0
var capture_target_node: Node3D
const CAPTURE_ESCAPE_SECONDS := 5.0
const CAPTURE_ESCAPE_PRESSES := 8
var capture_overlay: PanelContainer
var capture_message: Label
var capture_button: Button
var eliminated_peers: Dictionary = {}
var entity_notice_label: Label
var stealth_status: Label
var entity_last_notice := 0.0
var ambient_music: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var voice_player: AudioStreamPlayer
var _world_sound_cooldowns: Dictionary = {}
var _voice_cooldown := 0.0
var _last_voice_state := ""
var _previous_audio_state := "DORMANT"
var _danger_audio_cooldown := 0.0
var _lighting_time := 0.0
var _alarm_active := false
var exterior_weather_particles: GPUParticles3D
var exterior_beacon: OmniLight3D
var exterior_weather_phase := 0.0
var exterior_wind_player: AudioStreamPlayer
var exterior_weather_label: Label
var exterior_gust_strength := 0.0
# Abrigo seguro: independente do MRE, com bloqueio blindado e um ponto fraco reparável.
var safe_shelter: Node3D
var shelter_door: StaticBody3D
var shelter_door_open := false
var shelter_lock_damaged := false
var shelter_lock_damage_progress := 0.0
var shelter_creature_pressure := 0.0
var shelter_feedback_label: Label3D
var shelter_repair_parts_available := true
var exterior_is_player_outside := false
var intro_layer: CanvasLayer
var intro_progress: ProgressBar
var intro_percent: Label
var intro_elapsed := 0.0
const INTRO_DURATION := 4.0
var entity_waypoints: Array[Vector3] = [Vector3(-3.8, 0.0, -13.4), Vector3(3.6, 0.0, -11.7), Vector3(2.8, 0.0, -6.8), Vector3(-3.5, 0.0, -8.1)]

# Diretor de suspense: sinais ambientais antes do primeiro contacto visual.
var suspense_elapsed := 0.0
var suspense_next_event := 24.0
var suspense_event_index := 0
var creature_vocal_cooldown := 0.0
var creature_vocal_index := -1
var suspense_rng := RandomNumberGenerator.new()
# Investigação cooperativa da experiência original: dez fragmentos, um por zona.
var experiment_clues_found: Dictionary = {}
var special_investigation_found: Dictionary = {}
# Relações de provas confirmadas pelo jogador no dossiê; não basta possuir os objetos.
var evidence_comparisons_solved: Dictionary = {}
var secret_experiment_door: StaticBody3D
var secret_experiment_open := false
var evidence_synthesis_complete := false
var mission_completed := false
# Extração em fases: pedido, janela de sobrevivência e chegada ao ponto exterior.
var extraction_phase := "INACTIVE" # INACTIVE, COUNTDOWN, LANDING, COMPLETE
var extraction_countdown := 0.0
var extraction_last_broadcast_second := -1
var extraction_landing_marker: Node3D
var extraction_status_label: Label
const EXTRACTION_SURVIVAL_SECONDS := 35.0
const EXTRACTION_LANDING_RADIUS := 4.0
var extraction_terminal: StaticBody3D
var mission_ending_layer: CanvasLayer
var secret_combination_panel: PanelContainer
var secret_combination_input: LineEdit
var secret_synthesis_console: StaticBody3D
var secret_clue_status: Label
const SECRET_COMBINATION := "7314"
var evidence_journal: Array[String] = []
var secret_archive_evidence_found: Dictionary = {}
var evidence_dossier_panel: PanelContainer
var evidence_select_a: OptionButton
var evidence_select_b: OptionButton
var evidence_comparison_text: RichTextLabel
var evidence_dossier_status: Label
var suspense_messages: Array[String] = [
    "RÁDIO: interferência breve. A origem do sinal não foi identificada.",
    "ESTAÇÃO: um impacto metálico ecoa num corredor distante.",
    "SENSORES: movimento térmico inconclusivo junto à estrutura exterior.",
    "AVISO: rajada polar intensa. A visibilidade exterior está a diminuir.",
    "ÁUDIO: três passos no piso superior. Não há movimento registado nos sensores.",
    "ENERGIA: oscilação momentânea. Verifica a lanterna e o rádio."
]

func _ready() -> void:
	_setup_audio()
	_build_environment()
	_build_room()
	_build_exterior_world()
	_build_safe_shelter()
	_build_next_chamber()
	_build_remaining_zones()
	_build_world_foundation()
	_build_initial_zone_wings()
	_build_secret_experiment_area()
	_apply_cycle_layout()
	_build_global_visual_upgrade()
	_build_visual_quality_pass()
	_build_door()
	_build_coop_switches()
	_build_player()
	_build_hud()
	# A criatura existe em todas as partidas, mas a primeira aparição é precedida por sinais ambientais.
	suspense_rng.randomize()
	solo_traitor_rng.randomize()
	suspense_next_event = suspense_rng.randf_range(10.0, 17.0)
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	_build_main_menu()
	# Only dismiss the boot diagnostics after the full scene and UI were created.
	var boot := get_parent()
	if boot and boot.has_method("on_expedition_ready"):
		boot.call_deferred("on_expedition_ready")

func _setup_audio() -> void:
	# Original procedural ambience and cues are bundled locally; no network access required.
	ambient_music = AudioStreamPlayer.new()
	ambient_music.name = "AmbientMusic"
	ambient_music.stream = load("res://audio/ambient_tension.wav")
	ambient_music.volume_db = -19.0
	ambient_music.autoplay = false
	add_child(ambient_music)
	if ambient_music.stream:
		ambient_music.play()
		ambient_music.finished.connect(func():
			if ambient_music and ambient_music.stream:
				ambient_music.play()
		)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.name = "SituationSFX"
	sfx_player.volume_db = -7.0
	add_child(sfx_player)
	voice_player = AudioStreamPlayer.new()
	voice_player.name = "CharacterVoices"
	voice_player.volume_db = -10.0
	add_child(voice_player)
	exterior_wind_player = AudioStreamPlayer.new()
	exterior_wind_player.name = "ExteriorPolarWind"
	exterior_wind_player.stream = load("res://audio/polar_wind_loop.wav")
	exterior_wind_player.volume_db = -28.0
	add_child(exterior_wind_player)
	if exterior_wind_player.stream:
		exterior_wind_player.finished.connect(func():
			if exterior_wind_player and exterior_is_player_outside and exterior_wind_player.stream:
				exterior_wind_player.play()
		)

func _play_voice(file_name: String) -> void:
	if voice_player == null:
		return
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream:
		voice_player.stream = stream
		voice_player.pitch_scale = 1.0
		voice_player.volume_db = -10.0
		voice_player.play()

func _play_sfx(file_name: String) -> void:
	if sfx_player == null:
		return
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream:
		sfx_player.stream = stream
		sfx_player.play()

func _play_player_sound(file_name: String, world_position: Vector3, surface: String = "snow", pitch: float = 1.0) -> void:
	# Reproduz localmente e replica apenas eventos autorizados aos restantes jogadores.
	_play_spatial_sound(file_name, world_position, surface, pitch)
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	if multiplayer.is_server():
		rpc("receive_world_sound", multiplayer.get_unique_id(), file_name, world_position, surface, pitch)
	else:
		rpc_id(1, "request_world_sound", file_name, world_position, surface, pitch)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func request_world_sound(file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var allowed := ["footstep.wav", "cloth_rustle.wav", "flashlight_click.wav", "door_motor.wav", "voice_breathing.wav"]
	if not allowed.has(file_name):
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 1 or not remote_players.has(sender):
		return
	# Usa a posição que o servidor já conhece para evitar posições arbitrárias do cliente.
	var authoritative_position: Vector3 = (remote_players[sender] as Node3D).global_position
	if authoritative_position.distance_to(world_position) > 3.0:
		world_position = authoritative_position
	rpc("receive_world_sound", sender, file_name, world_position, surface, clampf(pitch, 0.75, 1.3))

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_world_sound(peer_id: int, file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	if peer_id == multiplayer.get_unique_id():
		return
	var allowed := ["footstep.wav", "cloth_rustle.wav", "flashlight_click.wav", "door_motor.wav", "voice_breathing.wav"]
	if not allowed.has(file_name):
		return
	_play_spatial_sound(file_name, world_position, surface, pitch)

func _play_spatial_sound(file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream == null:
		return
	var emitter := AudioStreamPlayer3D.new()
	emitter.name = "WorldSound"
	emitter.stream = stream
	emitter.global_position = world_position
	emitter.max_distance = 24.0
	emitter.unit_size = 4.0
	emitter.volume_db = -4.0 if file_name == "footstep.wav" else -8.0
	emitter.pitch_scale = clampf(pitch, 0.75, 1.3)
	match surface:
		"ice":
			emitter.pitch_scale *= 1.08
			emitter.volume_db -= 1.5
		"stone":
			emitter.pitch_scale *= 0.94
			emitter.volume_db += 1.0
		"metal":
			emitter.pitch_scale *= 1.12
			emitter.volume_db += 2.0
		"interior":
			emitter.volume_db -= 2.0
	add_child(emitter)
	emitter.finished.connect(emitter.queue_free)
	emitter.play()

func _play_context_voice(state: String) -> void:
	# Non-verbal vocal cues are intentionally sparse so they remain unsettling rather than repetitive.
	if _voice_cooldown > 0.0 or state == _last_voice_state:
		return
	_last_voice_state = state
	match state:
		"HUNT":
			_play_voice("voice_distant_whisper.wav")
			_voice_cooldown = 7.0
		"ATTACK_WARNING":
			_play_voice("voice_scream.wav")
			_voice_cooldown = 10.0
		"OBSERVED":
			_play_voice("voice_groan.wav")
			_voice_cooldown = 6.0
		"COOP_SOLVED":
			_play_voice("voice_choked_gasp.wav")
			_voice_cooldown = 5.0

func _material(color: Color, roughness := 0.86, metallic := 0.0) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	return mat

func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, mat: Material, collision := true) -> MeshInstance3D:
	var body: Node3D = parent
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.position = pos
	mesh_node.material_override = mat
	body.add_child(mesh_node)
	if collision:
		var static_body := StaticBody3D.new()
		static_body.name = node_name + "Collision"
		static_body.position = pos
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		static_body.add_child(shape_node)
		body.add_child(static_body)
	return mesh_node

func _get_local_ipv4_addresses() -> PackedStringArray:
	var addresses := PackedStringArray()
	for address in IP.get_local_addresses():
		# ENet on Android needs a reachable IPv4 address, not loopback or IPv6.
		if address.count(".") == 3 and not address.begins_with("127.") and not address == "0.0.0.0":
			addresses.append(address)
	return addresses

func _get_preferred_local_ipv4() -> String:
	var addresses := _get_local_ipv4_addresses()
	# Prefer common private LAN addresses when multiple adapters are available.
	for address in addresses:
		if address.begins_with("192.168.") or address.begins_with("10."):
			return address
		if address.begins_with("172."):
			var parts := address.split(".")
			if parts.size() == 4 and int(parts[1]) >= 16 and int(parts[1]) <= 31:
				return address
	if not addresses.is_empty():
		return addresses[0]
	return ""

func _sync_network_status_to_menu() -> void:
	# The menu and HUD have separate labels. Keep both updated after asynchronous
	# ENet callbacks, otherwise the menu can remain stuck on "A ligar...".
	if menu_status_label != null and network_status != null:
		menu_status_label.text = network_status.text

func host_game() -> void:
	if network_peer != null:
		var current_ip := _get_preferred_local_ipv4()
		if network_status:
			network_status.text = "Sessão já ativa · IP deste telemóvel: %s:%d" % [current_ip if not current_ip.is_empty() else "IP indisponível", PORT]
			_sync_network_status_to_menu()
		return
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_server(PORT, 7) # 1 anfitrião + até 7 clientes = 8 jogadores
	if result != OK:
		network_peer = null
		if network_status:
			network_status.text = "Erro ao criar sessão: %s" % error_string(result)
			_sync_network_status_to_menu()
		return
	multiplayer.multiplayer_peer = network_peer
	local_player_id = multiplayer.get_unique_id()
	var local_ip := _get_preferred_local_ipv4()
	if network_status:
		if local_ip.is_empty():
			network_status.text = "Sessão ativa na porta %d, mas não encontrei IP IPv4. Liga os telemóveis à mesma WLAN e tenta novamente." % PORT
			_sync_network_status_to_menu()
		else:
			var all_ips := ", ".join(_get_local_ipv4_addresses())
			network_status.text = "ANFITRIÃO ATIVO · IP sugerido: %s · IPs detetados: %s · PORTA UDP: %d. Partilha o IP WLAN correto." % [local_ip, all_ips, PORT]
			_sync_network_status_to_menu()
	if ip_input and not local_ip.is_empty():
		ip_input.text = local_ip
	_broadcast_local_state()

func join_game() -> void:
	if network_peer != null:
		if network_status:
			network_status.text = "Já existe uma sessão de rede neste telemóvel."
			_sync_network_status_to_menu()
		return
	var address := ip_input.text.strip_edges()
	if address.is_empty() or address == "127.0.0.1" or address == "localhost":
		if network_status:
			network_status.text = "Introduz o IP WLAN mostrado no telemóvel anfitrião; 127.0.0.1 não liga a outro telemóvel."
			_sync_network_status_to_menu()
		return
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_client(address, PORT)
	if result != OK:
		network_peer = null
		if network_status:
			network_status.text = "Erro ao iniciar ligação: %s" % error_string(result)
			_sync_network_status_to_menu()
		return
	multiplayer.multiplayer_peer = network_peer
	_client_connect_elapsed = 0.0
	if network_status:
		network_status.text = "A ligar a %s:%d…" % [address, PORT]
		_sync_network_status_to_menu()

func _on_connected_to_server() -> void:
	_client_connect_elapsed = 0.0
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	rpc_id(1, "request_initial_session_state")
	if network_status:
		network_status.text = "Ligado ao anfitrião · ID %d" % local_player_id
		_sync_network_status_to_menu()

func _on_connection_failed() -> void:
	_client_connect_elapsed = 0.0
	if network_status:
		network_status.text = "Ligação falhou. Verifica o IP do anfitrião, a mesma WLAN e se a rede permite comunicação entre dispositivos."
		_sync_network_status_to_menu()
	if network_peer != null:
		network_peer.close()
		network_peer = null
	multiplayer.multiplayer_peer = null

func _on_server_disconnected() -> void:
	if network_status:
		network_status.text = "Ligação ao anfitrião perdida. Volta a ligar à sessão WLAN."
		_sync_network_status_to_menu()
	if network_peer != null:
		network_peer.close()
		network_peer = null
	multiplayer.multiplayer_peer = null

func _on_peer_connected(peer_id: int) -> void:
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	if multiplayer.is_server() and not remote_players.has(peer_id):
		var host_player := get_node_or_null("Player") as Node3D
		var spawn_position := host_player.global_position + Vector3(1.5, 0.0, 1.5) if host_player else Vector3.ZERO
		var avatar := _make_remote_avatar(peer_id)
		avatar.global_position = spawn_position
		remote_players[peer_id] = avatar
		_last_authoritative_player_positions[peer_id] = spawn_position
	if multiplayer.is_server() and not traitor_role_assigned:
		_assign_hidden_roles()
	if multiplayer.is_server():
		if traitor_role_assigned:
			var is_traitor := peer_id == traitor_peer_id
			var role_message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
			rpc_id(peer_id, "receive_secret_role", is_traitor, role_message)
		_send_entity_state_to(peer_id)
	if network_status:
		network_status.text = "Ligado · novo jogador %d" % peer_id
		_sync_network_status_to_menu()

@rpc("any_peer", "call_remote", "reliable")
func request_initial_session_state() -> void:
	if not multiplayer.is_server():
		return
	var requester := multiplayer.get_remote_sender_id()
	if requester <= 1:
		return
	if traitor_role_assigned:
		var is_traitor := requester == traitor_peer_id
		var message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
		rpc_id(requester, "receive_secret_role", is_traitor, message)
	_send_entity_state_to(requester)
	rpc_id(requester, "client_sync_secret_progress", experiment_clues_found.keys(), evidence_synthesis_complete, secret_experiment_open)
	if mission_completed:
		rpc_id(requester, "client_mission_completed")
	elif extraction_phase != "INACTIVE":
		rpc_id(requester, "client_extraction_state", extraction_phase, extraction_countdown)

@rpc("authority", "call_remote", "reliable")
func client_sync_secret_progress(found_ids: Array, synthesis_done: bool, door_open: bool) -> void:
	experiment_clues_found.clear()
	for raw_id in found_ids:
		experiment_clues_found[int(raw_id)] = true
	evidence_synthesis_complete = synthesis_done
	secret_experiment_open = door_open
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: %02d / 12" % experiment_clues_found.size()
	if experiment_clues_found.size() >= 12:
		client_reveal_secret_console()
	if evidence_synthesis_complete:
		_unlock_secret_door()
	if door_open and secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)

func _assign_hidden_roles() -> void:
	if not multiplayer.is_server() or traitor_role_assigned:
		return
	var participants: Array[int] = [1]
	for peer_id in multiplayer.get_peers():
		participants.append(int(peer_id))
	if participants.size() < 2:
		return # The traitor is a human player; solo play has no human traitor.
	participants.shuffle()
	traitor_peer_id = participants[0]
	traitor_role_assigned = true
	for participant_id in participants:
		var is_traitor := participant_id == traitor_peer_id
		var message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
		if participant_id == 1:
			_show_role_notice(is_traitor, message)
		else:
			rpc_id(participant_id, "receive_secret_role", is_traitor, message)

@rpc("authority", "call_remote", "reliable")
func receive_secret_role(is_traitor: bool, message: String) -> void:
	_show_role_notice(is_traitor, message)

func _show_role_notice(is_traitor: bool, message: String) -> void:
	if role_notice_layer != null:
		role_notice_layer.queue_free()
	role_notice_layer = CanvasLayer.new()
	role_notice_layer.name = "PrivateRoleNotice"
	role_notice_layer.layer = 150
	add_child(role_notice_layer)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.008, 0.012, 0.018, 0.94)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	role_notice_layer.add_child(backdrop)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 24
	center.offset_right = -24
	center.offset_top = 24
	center.offset_bottom = -24
	role_notice_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(minf(560.0, get_viewport().get_visible_rect().size.x - 48.0), 0)
	center.add_child(panel)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 14)
	panel.add_child(stack)
	var heading := Label.new()
	heading.text = "INSTRUÇÃO CONFIDENCIAL" if is_traitor else "MISSÃO ATRIBUÍDA"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.add_theme_font_size_override("font_size", 23)
	heading.add_theme_color_override("font_color", Color(0.88, 0.19, 0.15) if is_traitor else Color(0.35, 0.82, 0.88))
	stack.add_child(heading)
	var body := Label.new()
	body.text = message
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.custom_minimum_size = Vector2(0, 100)
	body.add_theme_font_size_override("font_size", 17)
	stack.add_child(body)
	var confirm := Button.new()
	confirm.text = "COMPREENDI"
	confirm.custom_minimum_size = Vector2(0, 48)
	confirm.pressed.connect(func(): role_notice_layer.queue_free(); role_notice_layer = null)
	stack.add_child(confirm)

func _on_peer_disconnected(peer_id: int) -> void:
	if remote_players.has(peer_id):
		remote_players[peer_id].queue_free()
		remote_players.erase(peer_id)	
	_last_authoritative_player_positions.erase(peer_id)
	if multiplayer.is_server():
		for key in switch_owners.keys():
			if int(switch_owners[key]) == peer_id:
				switch_owners[key] = 0
		decision_votes.erase(peer_id)
		# Recalculate the objective after a participant leaves; a disconnected peer
		# must not keep a relay or the bulkhead permanently unlocked.
		coop_solved = switch_owners["A"] != 0 and switch_owners["B"] != 0 and switch_owners["A"] != switch_owners["B"]
		_broadcast_switch_state()
		# If a voter disconnects, recalculate the quorum using only connected peers.
		_try_resolve_decision()
	if network_status:
		network_status.text = "Jogador %d saiu" % peer_id
		_sync_network_status_to_menu()

func _process(delta: float) -> void:
	# ENet can remain in CONNECTING on some Android/network combinations.
	# Never leave the UI stuck indefinitely: stop the attempt and expose a useful status.
	if network_peer != null and network_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTING:
		_client_connect_elapsed += delta
		if _client_connect_elapsed >= CLIENT_CONNECT_TIMEOUT:
			if network_peer != null:
				network_peer.close()
				network_peer = null
			multiplayer.multiplayer_peer = null
			_client_connect_elapsed = 0.0
			if network_status:
				network_status.text = "Tempo esgotado: sem resposta de %s:%d. Verifica o IP do anfitrião, desativa VPN/hotspot alternativo e confirma que o router permite comunicação entre dispositivos na UDP %d." % [ip_input.text.strip_edges() if ip_input else "anfitrião", PORT, PORT]
				_sync_network_status_to_menu()
	if multiplayer.is_server():
		_update_suspense_director(delta)
	if multiplayer.multiplayer_peer == null or multiplayer.is_server():
		_update_extraction_sequence(delta)
	# Single-player traitor AI is independent from the creature AI and only runs offline.
	if multiplayer.multiplayer_peer == null and entity_active:
		_update_solo_traitor_ai(delta)
	_sync_accumulator += delta
	_lighting_time += delta
	_update_lighting_effects()
	_update_exterior_weather(delta)
	_voice_cooldown = maxf(0.0, _voice_cooldown - delta)
	creature_vocal_cooldown = maxf(0.0, creature_vocal_cooldown - delta)
	if intro_layer != null and intro_layer.visible:
		intro_elapsed = minf(INTRO_DURATION, intro_elapsed + delta)
		var intro_value := clampf(intro_elapsed / INTRO_DURATION, 0.0, 1.0)
		if intro_progress != null:
			intro_progress.value = intro_value * 100.0
		if intro_percent != null:
			intro_percent.text = "%03d%%" % int(round(intro_value * 100.0))
		if intro_elapsed >= INTRO_DURATION:
			intro_layer.visible = false
			if main_menu_layer != null:
				main_menu_layer.visible = true
	if entity_active:
		entity_motion_time += delta
		if multiplayer.is_server():
			entity_state_time += delta
			_update_shelter_weakpoint_ai(delta)
			_update_entity_ai(delta)
			_update_capture_state(delta)
			_entity_sync_accumulator += delta
			if _entity_sync_accumulator >= ENTITY_SYNC_INTERVAL:
				_entity_sync_accumulator = 0.0
				_broadcast_entity_state()
		var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
		if lamp:
			var flicker := 0.35 + absf(sin(entity_motion_time * (10.0 if entity_ai_state == "HUNT" else 6.0))) * (1.15 if entity_ai_state == "HUNT" else 0.65)
			lamp.light_energy = flicker
		_update_stealth_status()
	if _sync_accumulator >= 0.08:
		_sync_accumulator = 0.0
		_broadcast_local_state()
	if mission_hub != null and mission_hub.visible:
		_refresh_mission_hub()

func _broadcast_local_state() -> void:
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	var player := get_node_or_null("Player") as CharacterBody3D
	if player == null:
		return
	var pitch := 0.0
	var pivot := player.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pitch = pivot.rotation.x
	var peer_id := multiplayer.get_unique_id()
	if multiplayer.is_server():
		# The host is authoritative for its own state and relays it to clients.
		rpc("receive_player_state", peer_id, player.global_position, player.rotation.y, pitch)
	else:
		# Clients submit state only to the server; they cannot directly dictate other clients' avatars.
		rpc_id(1, "submit_player_state", player.global_position, player.rotation.y, pitch)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func submit_player_state(pos: Vector3, yaw: float, pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id <= 1 or not remote_players.has(sender_id):
		return
	var avatar := remote_players[sender_id] as Node3D
	if avatar == null or not is_instance_valid(avatar):
		return
	# Reject implausible position jumps. The tolerance accommodates packet jitter and frame stalls.
	var previous: Vector3 = _last_authoritative_player_positions.get(sender_id, avatar.global_position)
	if previous.distance_to(pos) > 2.5:
		return
	_last_authoritative_player_positions[sender_id] = pos
	# Keep the server-side avatar current; proximity checks for relays and sounds use this node.
	avatar.global_position = pos
	avatar.rotation.y = yaw
	var server_pivot := avatar.get_node_or_null("CameraPivot") as Node3D
	if server_pivot:
		server_pivot.rotation.x = clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0))
	rpc("receive_player_state", sender_id, pos, yaw, clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0)))

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_player_state(peer_id: int, pos: Vector3, yaw: float, pitch: float) -> void:
	# Only the server relays accepted states. The RPC sender is server ID 1; retain the peer ID in the payload.
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id > 0 and sender_id != 1:
		return
	if peer_id == multiplayer.get_unique_id():
		return
	var avatar: Node3D = remote_players.get(peer_id)
	if avatar == null:
		avatar = _make_remote_avatar(peer_id)
		remote_players[peer_id] = avatar
	avatar.global_position = pos
	avatar.rotation.y = yaw
	var pivot := avatar.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pivot.rotation.x = clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0))

func _make_remote_avatar(peer_id: int) -> Node3D:
	var avatar := Node3D.new()
	avatar.name = "RemotePlayer_%d" % peer_id
	# Usa o modelo 3D exportado para GLB, sem dependência do Blender em runtime.
	# O controlador de rede continua a controlar a posição/rotação deste Node3D.
	var player_visual := PLAYER_EXPEDITION_MODEL_SCENE.instantiate() as Node3D
	player_visual.name = "Player3D"
	player_visual.position.y = -0.02
	# Oito variantes visuais para distinguir os membros da equipa em multijogador.
	# Cada peer recebe uma combinação estável de fato, capacete e mochila.
	var player_variant: int = posmod(peer_id - 1, 8)
	_apply_player_visual_variant(player_visual, player_variant)
	player_visual.scale = Vector3(0.78, 0.78, 0.78) * [0.98, 1.02, 1.00, 0.96, 1.04, 0.99, 1.01, 0.97][player_variant]
	# O modelo fonte foi criado virado para +Z; os avatares Godot olham para -Z.
	player_visual.rotation.y = PI
	avatar.add_child(player_visual)
	var pivot := Node3D.new()
	pivot.name = "CameraPivot"
	pivot.position.y = 1.45
	avatar.add_child(pivot)
	add_child(avatar)
	return avatar

func _apply_player_visual_variant(root: Node, variant: int) -> void:
	var suit_colors: Array[Color] = [
		Color("#17464b"), Color("#344a63"), Color("#48513b"), Color("#5a3d35"),
		Color("#35383f"), Color("#28554b"), Color("#5a4d35"), Color("#354b54")
	]
	var helmet_colors: Array[Color] = [
		Color("#f07824"), Color("#e6c547"), Color("#e9e9e5"), Color("#cf493d"),
		Color("#f07824"), Color("#7aa7b5"), Color("#e6c547"), Color("#cf493d")
	]
	var pack_colors: Array[Color] = [
		Color("#303a3b"), Color("#8b4d2e"), Color("#333b50"), Color("#354b37"),
		Color("#4b3432"), Color("#303a3b"), Color("#514a35"), Color("#3d4149")
	]
	_apply_variant_recursive(root, suit_colors[variant], helmet_colors[variant], pack_colors[variant])

func _apply_variant_recursive(node: Node, suit_color: Color, helmet_color: Color, pack_color: Color) -> void:
	if node is MeshInstance3D:
		var mesh_node := node as MeshInstance3D
		var lower_name := mesh_node.name.to_lower()
		var tint := Color.WHITE
		if "helmet" in lower_name or "lamp" in lower_name:
			tint = helmet_color
		elif "backpack" in lower_name or "radio" in lower_name or "pouch" in lower_name:
			tint = pack_color
		elif "torso" in lower_name or "leg" in lower_name or "arm" in lower_name or "shoulder" in lower_name:
			tint = suit_color
		if tint != Color.WHITE:
			var material := StandardMaterial3D.new()
			material.albedo_color = tint
			material.roughness = 0.82
			mesh_node.material_override = material
	for child in node.get_children():
		_apply_variant_recursive(child, suit_color, helmet_color, pack_color)

func _is_solo_session() -> bool:
	# Sem um peer ENet ligado, a partida é local: todas as ações pertencem ao jogador 1.
	return network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED

func request_switch(switch_id: String) -> void:
	_play_sfx("object_latch.wav")
	if _is_solo_session():
		_server_toggle_switch(switch_id, 1)
		return
	if multiplayer.is_server():
		_server_toggle_switch(switch_id, multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_toggle_switch", switch_id)

@rpc("any_peer", "call_remote", "reliable")
func server_toggle_switch(switch_id: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	_server_toggle_switch(switch_id, sender)

# Portas interativas: o servidor valida distância, bloqueio e puzzle cooperativo.
# Só a autoridade altera o estado físico e replica o resultado aos restantes jogadores.
func request_door_toggle(door: Node, actor: Node) -> void:
	if door == null or actor == null or not is_instance_valid(door) or not is_instance_valid(actor):
		return
	var door_path: NodePath = get_path_to(door)
	if _is_solo_session():
		_server_toggle_door(door_path, 1)
	elif multiplayer.is_server():
		_server_toggle_door(door_path, multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_toggle_door", door_path)

@rpc("any_peer", "call_remote", "reliable")
func server_toggle_door(door_path: NodePath) -> void:
	if not multiplayer.is_server():
		return
	_server_toggle_door(door_path, multiplayer.get_remote_sender_id())

func _server_toggle_door(door_path: NodePath, peer_id: int) -> void:
	if not _is_solo_session() and not multiplayer.is_server():
		return
	if peer_id <= 0:
		return
	var door := get_node_or_null(door_path) as StaticBody3D
	if door == null or not door.has_method("apply_network_state") or not door.has_method("_set_opened"):
		return
	var actor: Node3D = null
	if peer_id == 1:
		actor = get_node_or_null("Player") as Node3D
	else:
		actor = remote_players.get(peer_id) as Node3D
	if actor == null or not is_instance_valid(actor):
		return
	if actor.global_position.distance_to(door.global_position) > 3.6:
		if peer_id == 1:
			_show_toast("APROXIMA-TE DA PORTA PARA INTERAGIR")
		return
	if bool(door.get("locked")):
		if peer_id == 1:
			_show_toast("PORTA BLOQUEADA — acesso elétrico sem energia ou autorização")
		return
	if bool(door.get("require_coop")) and not coop_solved:
		if peer_id == 1:
			_show_toast("ACESSO BLOQUEADO — os relés A e B têm de ser confirmados")
		return
	var target_open := not bool(door.get("opened"))
	door.call("apply_network_state", target_open)
	if not _is_solo_session() and multiplayer.is_server():
		rpc("client_apply_door_state", door_path, target_open)

@rpc("authority", "call_remote", "reliable")
func client_apply_door_state(door_path: NodePath, want_open: bool) -> void:
	var door := get_node_or_null(door_path) as StaticBody3D
	if door and door.has_method("apply_network_state"):
		door.call("apply_network_state", want_open)

func _server_toggle_switch(switch_id: String, peer_id: int) -> void:
	if (not _is_solo_session() and not multiplayer.is_server()) or not switch_owners.has(switch_id) or coop_solved:
		return
	if peer_id <= 0:
		return
	# Validate proximity on the authority. A client cannot activate a relay remotely
	# by sending the RPC without actually being near that station.
	var actor: Node3D = null
	if peer_id == 1:
		actor = get_node_or_null("Player") as Node3D
	else:
		actor = remote_players.get(peer_id) as Node3D
	var station := get_node_or_null("CoopSwitch" + switch_id) as Node3D
	if actor == null or station == null or not is_instance_valid(actor) or not is_instance_valid(station):
		return
	if actor.global_position.distance_to(station.global_position) > 5.0:
		if peer_id == 1 or _is_solo_session():
			_set_coop_status("APROXIMA-TE DO RELÉ PARA O ATIVAR")
		return
	if switch_owners[switch_id] == peer_id:
		switch_owners[switch_id] = 0
	else:
		switch_owners[switch_id] = peer_id
	# Single-player: the same person may walk between A and B and activate both.
	# Online co-op: preserve the original requirement for two different participants.
	var both_active: bool = int(switch_owners.get("A", 0)) != 0 and int(switch_owners.get("B", 0)) != 0
	coop_solved = both_active and (_is_solo_session() or switch_owners["A"] != switch_owners["B"])
	_broadcast_switch_state()

func _broadcast_switch_state() -> void:
	_apply_switch_state(switch_owners["A"], switch_owners["B"], coop_solved)
	if not _is_solo_session() and multiplayer.is_server():
		rpc("apply_switch_state", switch_owners["A"], switch_owners["B"], coop_solved)

@rpc("authority", "call_remote", "reliable")
func apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	_apply_switch_state(owner_a, owner_b, solved)

func _apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	switch_owners["A"] = owner_a
	switch_owners["B"] = owner_b
	var was_solved := coop_solved
	coop_solved = solved
	if solved and not was_solved:
		_play_context_voice("COOP_SOLVED")
	# O indicador físico e o texto do painel refletem o estado lógico replicado do relé.
	_update_relay_feedback("A", owner_a != 0)
	_update_relay_feedback("B", owner_b != 0)
	if solved:
		_set_coop_status("RELÉS A E B ATIVOS — ACESSO DESBLOQUEADO" if _is_solo_session() else "RELÉS ATIVOS POR JOGADORES DIFERENTES — CÂMARA DESBLOQUEADA")
		var door := get_node_or_null("InteractiveBulkhead")
		if door and door.has_method("open_for_coop"):
			door.open_for_coop()
	else:
		_set_coop_status("RELÉ A: %s   ·   RELÉ B: %s" % ["ATIVO" if owner_a != 0 else "PENDENTE", "ATIVO" if owner_b != 0 else "PENDENTE"])

func _update_relay_feedback(switch_id: String, active: bool) -> void:
	var station := get_node_or_null("CoopSwitch" + switch_id)
	if station == null:
		return
	var led := station.get_node_or_null("RelayStatusLED") as MeshInstance3D
	if led:
		var led_color := Color(0.12, 1.0, 0.38) if active else Color(1.0, 0.62, 0.08)
		var led_mat := _material(led_color, 0.22, 0.12)
		led_mat.emission_enabled = true
		led_mat.emission = led_color
		led_mat.emission_energy_multiplier = 2.2 if active else 0.8
		led.material_override = led_mat
	var status_label := station.get_node_or_null("RelayStateLabel") as Label3D
	if status_label:
		status_label.text = "SISTEMA ATIVO" if active else "À ESPERA"
		status_label.modulate = Color(0.35, 1.0, 0.52) if active else Color(1.0, 0.72, 0.24)
	var display := station.get_node_or_null("RelayStateDisplay") as MeshInstance3D
	if display:
		var display_color := Color(0.025, 0.20, 0.075) if active else Color(0.20, 0.12, 0.025)
		var display_mat := _material(display_color, 0.2, 0.1)
		display_mat.emission_enabled = true
		display_mat.emission = display_color
		display_mat.emission_energy_multiplier = 0.7
		display.material_override = display_mat

func _toggle_network_panel(panel: PanelContainer) -> void:
	if panel:
		panel.visible = not panel.visible

func _set_coop_status(message: String) -> void:
	if coop_status:
		coop_status.text = message

func _update_private_clue() -> void:
	if private_clue == null:
		return
	local_player_id = multiplayer.get_unique_id()
	var clue := ""
	match local_player_id:
		1:
			clue = "DOSSIÊ PRIVADO 01 — REGISTO DE CÂMARA: uma silhueta atravessou a porta às 02:13. O rosto não é identificável."
		2:
			clue = "DOSSIÊ PRIVADO 02 — REGISTO MAGNÉTICO: a porta permaneceu selada entre as 02:00 e as 02:20. Não há abertura registada."
		3:
			clue = "DOSSIÊ PRIVADO 03 — ÁUDIO RECUPERADO: às 02:13 ouvem-se duas vozes; uma diz «não o deixes entrar»."
		_:
			clue = "DOSSIÊ PRIVADO 04 — SENSOR TÉRMICO: às 02:13 foi detetado movimento, mas sem assinatura térmica humana compatível."
	private_clue.text = clue

func submit_decision(choice: String) -> void:
	if decision_resolved:
		_set_decision_status("A decisão desta missão já foi tomada.")
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	if _is_solo_session():
		# In solo, the player makes the decision; no second vote is required.
		_server_record_decision(1, choice)
		return
	if multiplayer.is_server():
		_server_record_decision(multiplayer.get_unique_id(), choice)
	else:
		rpc_id(1, "server_record_decision", choice)
	_set_decision_status("Voto registado em privado. Compara as provas antes de decidirem.")

@rpc("any_peer", "call_remote", "reliable")
func server_record_decision(choice: String) -> void:
	if not multiplayer.is_server() or decision_resolved:
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 0:
		return
	_server_record_decision(sender, choice)

func _server_record_decision(peer_id: int, choice: String) -> void:
	if decision_resolved or peer_id <= 0:
		return
	if not _is_solo_session():
		# Only the host and currently connected peers may vote; never count a stale ID.
		if peer_id != 1 and (network_peer == null or not network_peer.get_peers().has(peer_id)):
			return
	decision_votes[peer_id] = choice
	_try_resolve_decision()

func _try_resolve_decision() -> void:
	if decision_resolved:
		return
	var eligible_ids: Array[int] = [1]
	if not _is_solo_session() and network_peer != null:
		for connected_peer in network_peer.get_peers():
			eligible_ids.append(int(connected_peer))
	# Remove any vote from a peer who is no longer part of this session.
	for voter in decision_votes.keys():
		if not eligible_ids.has(int(voter)):
			decision_votes.erase(voter)
	var received := 0
	for eligible_id in eligible_ids:
		if decision_votes.has(eligible_id):
			received += 1
	if received < eligible_ids.size():
		_broadcast_decision_status("Votos recebidos: %d/%d. A decisão aguarda todos os jogadores ligados." % [received, eligible_ids.size()])
		return
	var accuse_count := 0
	var defend_count := 0
	for vote in decision_votes.values():
		if vote == "ACUSAR":
			accuse_count += 1
		else:
			defend_count += 1
	decision_resolved = true
	var outcome := ""
	if accuse_count > defend_count:
		outcome = "CONSEQUÊNCIA: ACUSAÇÃO — o alarme dispara e a estação entra em contenção. A equipa perde a confiança do operador."
		_set_alarm_state(true)
	elif defend_count > accuse_count:
		outcome = "CONSEQUÊNCIA: DEFESA — o operador mantém acesso, mas uma porta secundária desbloqueia-se sem explicação."
		_set_alarm_state(false)
	else:
		outcome = "CONSEQUÊNCIA: DIVISÃO — sem consenso, o sistema entra em bloqueio e a luz de emergência falha."
		_set_alarm_state(true)
	_broadcast_decision_result(outcome)

func _broadcast_decision_status(message: String) -> void:
	_set_decision_status(message)
	if not _is_solo_session() and multiplayer.is_server():
		rpc("apply_decision_status", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_status(message: String) -> void:
	_set_decision_status(message)

func _broadcast_decision_result(message: String) -> void:
	_apply_decision_result(message)
	if not _is_solo_session() and multiplayer.is_server():
		rpc("apply_decision_result", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_result(message: String) -> void:
	_apply_decision_result(message)

func _apply_decision_result(message: String) -> void:
	decision_resolved = true
	_activate_entity_reaction(message)
	_set_decision_status(message)
	_set_alarm_state(message.begins_with("CONSEQUÊNCIA: ACUSAÇÃO") or message.begins_with("CONSEQUÊNCIA: DIVISÃO"))
	if accusation_button:
		accusation_button.disabled = true
	if defense_button:
		defense_button.disabled = true

func _update_suspense_director(delta: float) -> void:
	# Diretor de atividade: acontecimentos ambientais mais frequentes, sem revelar
	# a criatura por temporizador e sem substituir as decisões dos jogadores.
	suspense_elapsed += delta
	if suspense_elapsed < suspense_next_event:
		return
	suspense_event_index += 1
	suspense_next_event = suspense_elapsed + suspense_rng.randf_range(12.0, 22.0)
	var event_kind := suspense_rng.randi_range(0, 5)
	if entity_reaction_label:
		entity_reaction_label.text = suspense_messages[event_kind]
	match event_kind:
		0:
			_play_sfx("radio_static.wav")
		1:
			_play_sfx("ice_stress_crack.wav")
		2:
			_play_sfx("relay_click.wav")
		3:
			# Rajada forte temporária no exterior; a meteorologia volta a variar naturalmente.
			exterior_gust_strength = minf(1.0, exterior_gust_strength + 0.35)
			_play_sfx("polar_wind_loop.wav")
		4:
			_play_sfx("relay_click.wav")
			var lamp := get_node_or_null("ResearchStationRoom/IntermittentCeilingLamp") as OmniLight3D
			if lamp:
				lamp.light_energy = 0.0
		5:
			_play_sfx("radio_static.wav")
			if entity_active and entity_ai_state == "PATROL":
				_play_creature_vocal("DISTANT")

func _activate_entity_reaction(outcome: String) -> void:
	# A criatura não é revelada por um temporizador. A sua aparição depende
	# de acontecimentos narrativos e de ações da investigação, nunca apenas do tempo.
	if outcome.begins_with("DELAYED:"):
		outcome = outcome.trim_prefix("DELAYED:")
	if outcome != "INITIAL_PATROL":
		_play_sfx("entity_sting.wav")
	if entity_active:
		return
	entity_active = true
	var room := get_node_or_null("ResearchStationRoom") as Node3D
	if room == null:
		return
	# A distant, deliberately ambiguous silhouette appears only after the team's decision.
	# A criatura move-se como corpo cinemático: alterar diretamente a posição de
	# um Node3D contornava a física e permitia atravessar paredes/portas.
	entity_presence = CharacterBody3D.new()
	entity_presence.name = "UnidentifiedPresence"
	entity_presence.position = entity_waypoints[entity_waypoint_index]
	entity_presence.collision_layer = 1
	entity_presence.collision_mask = 1
	room.add_child(entity_presence)
	var entity_model := Node3D.new()
	entity_model.name = "EntityCreatureModel"
	entity_model.position.y = 0.82
	entity_presence.add_child(entity_model)
	_add_creature_model(entity_model)
	entity_model.set_script(MODEL_ANIMATOR_SCRIPT)
	entity_model.set("creature_mode", true)
	# A forma de colisão tem de pertencer ao CharacterBody3D para que
	# move_and_slide() resolva contactos com paredes, folhas de porta e limites.
	var collision_shape := CollisionShape3D.new()
	collision_shape.name = "EntityCollisionShape"
	var collision_capsule := CapsuleShape3D.new()
	collision_capsule.radius = 0.34
	collision_capsule.height = 1.9
	collision_shape.shape = collision_capsule
	collision_shape.position.y = 1.0
	entity_presence.add_child(collision_shape)
	entity_ai_state = "PATROL"
	entity_state_time = 0.0
	if entity_reaction_label:
		if outcome.begins_with("CONSEQUÊNCIA: ACUSAÇÃO"):
			entity_reaction_label.text = "SINAL HOSTIL: a contenção chamou algo até à estação."
		elif outcome.begins_with("CONSEQUÊNCIA: DEFESA"):
			entity_reaction_label.text = "SINAL ANÓMALO: a presença apareceu depois de manterem o acesso."
		elif outcome == "INITIAL_PATROL":
			entity_reaction_label.text = "A estação permanece em silêncio. Há movimento não confirmado nos corredores."
		else:
			entity_reaction_label.text = "SINAL CRÍTICO: foi detetada uma anomalia na estação."

func _update_solo_traitor_ai(delta: float) -> void:
	# This character is never assigned to the player and is never the creature.
	# It manipulates station systems and leaves ambiguous evidence; it does not
	# reveal its identity in the public mission UI.
	solo_traitor_timer += delta
	if solo_traitor_glimpse_timer > 0.0:
		solo_traitor_glimpse_timer = maxf(0.0, solo_traitor_glimpse_timer - delta)
		if solo_traitor_glimpse_timer == 0.0 and solo_traitor_presence:
			solo_traitor_presence.visible = false
	if solo_traitor_timer < solo_traitor_next_action:
		return
	solo_traitor_timer = 0.0
	solo_traitor_next_action = solo_traitor_rng.randf_range(20.0, 32.0)
	solo_traitor_sabotages += 1
	# Sabotage is a temporary systems disturbance, not an arbitrary death or attack.
	_set_alarm_state(true)
	if entity_reaction_label:
		var messages := [
			"REGISTO ANÓMALO: uma ordem de manutenção foi executada sem credenciais válidas.",
			"COMUNICAÇÕES: pacote de diagnóstico alterado. A origem não foi identificada.",
			"ENERGIA: um circuito foi isolado manualmente. Não existe operador registado.",
			"SEGURANÇA: acesso autorizado com uma credencial que deveria estar desativada."
		]
		entity_reaction_label.text = messages[(solo_traitor_sabotages - 1) % messages.size()]
	# A brief human silhouette may be seen at a distant waypoint; no label identifies it.
	if solo_traitor_presence == null:
		solo_traitor_presence = Node3D.new()
		solo_traitor_presence.name = "UnidentifiedStaffSilhouette"
		var room := get_node_or_null("ResearchStationRoom") as Node3D
		if room:
			room.add_child(solo_traitor_presence)
			var model := Node3D.new()
			model.name = "StaffSilhouetteModel"
			model.position.y = 0.82
			solo_traitor_presence.add_child(model)
			_add_human_model(model, Color(0.10, 0.16, 0.19), true)
			model.set_script(MODEL_ANIMATOR_SCRIPT)
			var coat := StandardMaterial3D.new()
			coat.albedo_color = Color(0.035, 0.055, 0.065)
			coat.roughness = 0.95
			for child in model.get_children():
				if child is MeshInstance3D:
					child.material_override = coat
	var waypoint := solo_traitor_rng.randi_range(0, entity_waypoints.size() - 1)
	solo_traitor_presence.position = entity_waypoints[waypoint] + Vector3(0.0, 0.0, -1.2)
	solo_traitor_presence.visible = true
	solo_traitor_glimpse_timer = 2.2
	# The sabotage signal is transient. The player must investigate the evidence.
	get_tree().create_timer(5.0).timeout.connect(func():
		if is_instance_valid(self):
			_set_alarm_state(false)
	)

func _play_creature_vocal(context: String) -> void:
	# Use varied existing non-verbal clips, with pitch and timing variation to avoid a looped cue.
	if creature_vocal_cooldown > 0.0 or voice_player == null:
		return
	var clips := ["voice_groan.wav", "voice_choked_gasp.wav", "voice_distant_whisper.wav", "voice_breathing.wav"]
	if context == "DANGER":
		clips = ["voice_groan.wav", "voice_scream.wav", "voice_choked_gasp.wav"]
	var pick := suspense_rng.randi_range(0, clips.size() - 1)
	if clips.size() > 1 and pick == creature_vocal_index:
		pick = (pick + suspense_rng.randi_range(1, clips.size() - 1)) % clips.size()
	creature_vocal_index = pick
	var stream := load("res://audio/" + clips[pick]) as AudioStream
	if stream == null:
		return
	voice_player.stream = stream
	voice_player.pitch_scale = suspense_rng.randf_range(0.78, 1.16)
	voice_player.volume_db = -13.0 if context == "DISTANT" else -8.0
	voice_player.play()
	creature_vocal_cooldown = suspense_rng.randf_range(9.0, 18.0) if context == "DISTANT" else suspense_rng.randf_range(6.0, 12.0)

func _update_entity_ai(delta: float) -> void:
	# The host is the only authority allowed to decide AI movement/state.
	if not multiplayer.is_server() or entity_presence == null:
		return
	var player := _find_entity_target()
	if player == null:
		return
	var distance_to_player := entity_presence.global_position.distance_to(player.global_position)
	# Se o jogador estiver no abrigo, a criatura não o pode atacar nem atravessar as paredes.
	# Em vez de acampar na porta, abandona a zona e retoma a patrulha.
	if _is_player_inside_safe_shelter(player):
		var shelter_exit := safe_shelter.to_global(Vector3(0.0, 0.0, 3.35)) if safe_shelter else Vector3(0.0, 0.0, -25.65)
		var at_shelter := entity_presence.global_position.distance_to(shelter_exit) < 4.5
		# A criatura pode pressionar o ponto fraco por tempo limitado, mas não pode acampar.
		if at_shelter and not shelter_lock_damaged and shelter_creature_pressure < 9.0:
			return
		if at_shelter:
			entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
			entity_ai_state = "PATROL"
			entity_state_time = 0.0
			entity_presence.global_position = entity_waypoints[entity_waypoint_index]
			entity_presence.visible = true
			if entity_reaction_label:
				entity_reaction_label.text = "MOVIMENTO AFASTADO. A presença abandonou a entrada do abrigo."
		return
	# Resolve the temporary disappearance before checking whether the player is
	# still looking at the creature. Otherwise the observation branch below resets
	# entity_hidden_time to 2.6 every frame and the creature never reappears.
	if entity_ai_state == "OBSERVED":
		entity_hidden_time = maxf(0.0, entity_hidden_time - delta)
		if entity_hidden_time <= 0.0:
			entity_ai_state = "PATROL"
			entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
			entity_presence.global_position = entity_waypoints[entity_waypoint_index]
			entity_presence.visible = true
			entity_state_time = 0.0
			if entity_reaction_label:
				entity_reaction_label.text = "MOVIMENTO DETETADO NOUTRA ZONA. A entidade mudou de posição."
		return
	var observed := _is_entity_observed(player)
	var player_speed := 0.0
	if player is CharacterBody3D:
		player_speed = Vector2((player as CharacterBody3D).velocity.x, (player as CharacterBody3D).velocity.z).length()
	var crouching := bool(player.get("is_crouching")) if player.get("is_crouching") != null else false
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	var illuminated := _is_entity_lit_by_player(player, flashlight)
	# Fast movement creates noise; crouching reduces the detection radius. A beam on the entity can provoke it.
	if observed and distance_to_player < 19.0:
		entity_ai_state = "OBSERVED"
		_play_context_voice("OBSERVED")
		entity_hidden_time = 2.6
		entity_presence.visible = false
		entity_state_time = 0.0
		if entity_reaction_label:
			entity_reaction_label.text = "A PRESENÇA DESAPARECEU QUANDO A OBSERVASTE. O ruído continua no corredor…"
		return
	var noise_radius := 5.0 if crouching else 13.0
	var old_state := entity_ai_state
	if (player_speed > 2.25 and not crouching and distance_to_player < noise_radius) or (illuminated and distance_to_player < 15.0):
		entity_ai_state = "HUNT"
	else:
		entity_ai_state = "PATROL"
	if entity_ai_state == "HUNT" and old_state != "HUNT":
		_play_sfx("danger_pulse.wav")
		_play_context_voice("HUNT")
		_play_creature_vocal("DANGER")
	elif entity_ai_state == "PATROL" and old_state != "PATROL":
		_play_creature_vocal("DISTANT")
	elif entity_ai_state == "PATROL" and suspense_rng.randf() < delta * 0.025:
		_play_creature_vocal("DISTANT")
	var target := entity_waypoints[entity_waypoint_index]
	if entity_ai_state == "HUNT" and distance_to_player > 3.4:
		# A lit target is more compelling than sound alone, but crouching still lowers noise.
		target = player.global_position
	elif entity_presence.global_position.distance_to(target) < 0.7:
		entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
		target = entity_waypoints[entity_waypoint_index]
	var flat_target := Vector3(target.x, entity_presence.global_position.y, target.z)
	var step := 1.35 if entity_ai_state == "PATROL" else 2.15
	# Recalcula a rota com A* em grelha física local. As células ocupadas por
	# paredes/portas fechadas ficam bloqueadas; a rota é renovada para detetar
	# portas que entretanto abriram ou fecharam. A autoridade continua no servidor.
	entity_path_refresh_timer -= delta
	if entity_path_refresh_timer <= 0.0 or entity_path.is_empty() or entity_path_goal.distance_to(flat_target) > 2.0:
		entity_path = _calculate_entity_path(flat_target)
		entity_path_cursor = 1 if entity_path.size() > 1 else 0
		entity_path_goal = flat_target
		entity_path_refresh_timer = ENTITY_PATH_REFRESH_SECONDS
	# Nunca usar a linha direta até ao alvo quando não existe rota válida nem
	# ultrapassar o último ponto calculado enquanto a grelha é renovada.
	# Isso evita contornar o A* e tentar atravessar paredes por um instante.
	var movement_target := entity_presence.global_position
	var has_navigation_target := false
	if not entity_path.is_empty():
		while entity_path_cursor < entity_path.size() - 1 and entity_presence.global_position.distance_to(entity_path[entity_path_cursor]) < 0.55:
			entity_path_cursor += 1
		if entity_path_cursor < entity_path.size():
			movement_target = entity_path[entity_path_cursor]
		else:
			movement_target = entity_path[entity_path.size() - 1]
		has_navigation_target = true
	if entity_presence is CharacterBody3D:
		var creature_body := entity_presence as CharacterBody3D
		var offset := movement_target - creature_body.global_position
		if has_navigation_target and offset.length_squared() > 0.0001:
			var direction := offset.normalized()
			creature_body.velocity = Vector3(direction.x * step, 0.0, direction.z * step)
		else:
			creature_body.velocity = Vector3.ZERO
		creature_body.move_and_slide()
	else:
		# Compatibilidade defensiva caso uma cena externa substitua o corpo.
		# Sem rota válida, fica parado em vez de avançar através de geometria.
		if has_navigation_target:
			entity_presence.global_position = entity_presence.global_position.move_toward(movement_target, step * delta)
	if entity_presence.global_position.distance_to(player.global_position) < 1.15 and capture_target_peer_id == 0:
		_begin_player_capture(player)
		return
	if entity_presence.global_position.distance_to(player.global_position) < 1.35:
		if entity_ai_state != "ATTACK_WARNING":
			_play_sfx("danger_pulse.wav")
			_play_context_voice("ATTACK_WARNING")
			_play_creature_vocal("DANGER")
		entity_ai_state = "ATTACK_WARNING"
		if entity_reaction_label:
			entity_reaction_label.text = "PERIGO IMEDIATO: a presença chegou demasiado perto. Recuem e não façam ruído."
	elif entity_ai_state == "HUNT" and entity_reaction_label and entity_state_time > 1.8 and Time.get_ticks_msec() / 1000.0 - entity_last_notice > 2.5:
		entity_reaction_label.text = "A ENTIDADE DETETOU %s. %s" % ["a luz da lanterna" if illuminated else "o ruído", "Desliga a lanterna e agacha-te." if illuminated else "Agacha-te para reduzir o ruído."]
		entity_last_notice = Time.get_ticks_msec() / 1000.0


func _calculate_entity_path(target_world: Vector3) -> Array[Vector3]:
	var result: Array[Vector3] = []
	if entity_presence == null or not is_instance_valid(entity_presence):
		return result
	var space := get_world_3d().direct_space_state
	if space == null:
		return result
	var half_size := float(ENTITY_PATH_GRID_SIZE - 1) * ENTITY_PATH_CELL_SIZE * 0.5
	var origin_x := entity_presence.global_position.x - half_size
	var origin_z := entity_presence.global_position.z - half_size
	var astar := AStar2D.new()
	var excluded: Array[RID] = []
	# Jogadores e a própria criatura não são obstáculos estáticos para a grelha.
	for body in get_tree().root.find_children("*", "CharacterBody3D", true, false):
		if body is CollisionObject3D:
			excluded.append((body as CollisionObject3D).get_rid())
	var clearance := CapsuleShape3D.new()
	clearance.radius = 0.34
	clearance.height = 1.9
	var query := PhysicsShapeQueryParameters3D.new()
	query.shape = clearance
	query.collision_mask = 1
	query.collide_with_bodies = true
	query.collide_with_areas = false
	query.exclude = excluded
	var goal_x := clampi(roundi((target_world.x - origin_x) / ENTITY_PATH_CELL_SIZE), 0, ENTITY_PATH_GRID_SIZE - 1)
	var goal_z := clampi(roundi((target_world.z - origin_z) / ENTITY_PATH_CELL_SIZE), 0, ENTITY_PATH_GRID_SIZE - 1)
	var start_x := clampi(roundi((entity_presence.global_position.x - origin_x) / ENTITY_PATH_CELL_SIZE), 0, ENTITY_PATH_GRID_SIZE - 1)
	var start_z := clampi(roundi((entity_presence.global_position.z - origin_z) / ENTITY_PATH_CELL_SIZE), 0, ENTITY_PATH_GRID_SIZE - 1)
	var solid_cells: Dictionary = {}
	for z in range(ENTITY_PATH_GRID_SIZE):
		for x in range(ENTITY_PATH_GRID_SIZE):
			var point_id := z * ENTITY_PATH_GRID_SIZE + x
			var point_2d := Vector2(origin_x + float(x) * ENTITY_PATH_CELL_SIZE, origin_z + float(z) * ENTITY_PATH_CELL_SIZE)
			astar.add_point(point_id, point_2d)
			query.transform = Transform3D(Basis.IDENTITY, Vector3(point_2d.x, entity_presence.global_position.y + 1.0, point_2d.y))
			if not space.intersect_shape(query, 1).is_empty():
				astar.set_point_disabled(point_id, true)
				solid_cells[point_id] = true
	# Liga apenas vizinhos ortogonais; a cápsula testada em cada célula impede
	# atalhos diagonais através de cantos de paredes.
	for z in range(ENTITY_PATH_GRID_SIZE):
		for x in range(ENTITY_PATH_GRID_SIZE):
			var point_id := z * ENTITY_PATH_GRID_SIZE + x
			if solid_cells.has(point_id):
				continue
			if x + 1 < ENTITY_PATH_GRID_SIZE:
				var right_id := point_id + 1
				if not solid_cells.has(right_id):
					astar.connect_points(point_id, right_id, true)
			if z + 1 < ENTITY_PATH_GRID_SIZE:
				var down_id := point_id + ENTITY_PATH_GRID_SIZE
				if not solid_cells.has(down_id):
					astar.connect_points(point_id, down_id, true)
	var start_id := _nearest_entity_path_cell(start_x, start_z, solid_cells)
	var goal_id := _nearest_entity_path_cell(goal_x, goal_z, solid_cells)
	if start_id < 0 or goal_id < 0:
		return result
	var ids := astar.get_id_path(start_id, goal_id)
	for id in ids:
		var point := astar.get_point_position(id)
		result.append(Vector3(point.x, entity_presence.global_position.y, point.y))
	return result

func _nearest_entity_path_cell(center_x: int, center_z: int, solid_cells: Dictionary) -> int:
	for radius in range(ENTITY_PATH_GRID_SIZE):
		var best_id := -1
		var best_distance := INF
		for z in range(maxi(0, center_z - radius), mini(ENTITY_PATH_GRID_SIZE, center_z + radius + 1)):
			for x in range(maxi(0, center_x - radius), mini(ENTITY_PATH_GRID_SIZE, center_x + radius + 1)):
				if radius > 0 and maxi(absi(x - center_x), absi(z - center_z)) != radius:
					continue
				var point_id := z * ENTITY_PATH_GRID_SIZE + x
				if solid_cells.has(point_id):
					continue
				var distance := Vector2(float(x - center_x), float(z - center_z)).length_squared()
				if distance < best_distance:
					best_distance = distance
					best_id = point_id
		if best_id >= 0:
			return best_id
	return -1


func _peer_id_for_player(player: Node3D) -> int:
	if player == get_node_or_null("Player"):
		return 1
	for key in remote_players.keys():
		if remote_players[key] == player:
			return int(key)
	return 0

func _begin_player_capture(player: Node3D) -> void:
	if not multiplayer.is_server() or capture_target_peer_id != 0 or player == null:
		return
	var peer_id := _peer_id_for_player(player)
	if peer_id == 0 or eliminated_peers.has(peer_id):
		return
	capture_target_peer_id = peer_id
	capture_target_node = player
	capture_elapsed = 0.0
	capture_escape_presses = 0
	entity_ai_state = "CAPTURE"
	if entity_reaction_label:
		entity_reaction_label.text = "A CRIATURA AGARROU UM EXPLORADOR. LIBERTA-TE!"
	_apply_capture_state_to_peer(peer_id, true, false, "A CRIATURA AGARROU-TE! TOCA RAPIDAMENTE PARA TE LIBERTARES.")
	if peer_id != 1 and network_peer != null:
		rpc_id(peer_id, "client_capture_state", true, false, "A CRIATURA AGARROU-TE! TOCA RAPIDAMENTE PARA TE LIBERTARES.")
	elif peer_id == 1:
		_apply_capture_state_to_peer(1, true, false, "A CRIATURA AGARROU-TE! TOCA RAPIDAMENTE PARA TE LIBERTARES.")

func _apply_capture_state_to_peer(peer_id: int, captured: bool, eliminated: bool, message: String) -> void:
	if peer_id == 1:
		var local_player := get_node_or_null("Player")
		if local_player and local_player.has_method("set_capture_state"):
			local_player.call("set_capture_state", captured, eliminated)
		if capture_overlay:
			capture_overlay.visible = captured or eliminated
		if capture_message:
			capture_message.text = message
		if capture_button:
			capture_button.visible = captured and not eliminated

func _update_capture_state(delta: float) -> void:
	if not multiplayer.is_server() or capture_target_peer_id == 0:
		return
	capture_elapsed += delta
	if capture_target_node == null or not is_instance_valid(capture_target_node):
		_finish_capture(false)
		return
	if capture_escape_presses >= CAPTURE_ESCAPE_PRESSES and capture_elapsed <= CAPTURE_ESCAPE_SECONDS:
		_finish_capture(true)
	elif capture_elapsed >= CAPTURE_ESCAPE_SECONDS:
		_finish_capture(false)

func request_capture_escape() -> void:
	# Clients do not hold the authoritative target ID; the server validates the sender.
	if _is_solo_session() or multiplayer.is_server():
		_server_capture_escape(1)
	else:
		rpc_id(1, "server_capture_escape")

@rpc("any_peer", "call_remote", "reliable")
func server_capture_escape() -> void:
	if not multiplayer.is_server():
		return
	_server_capture_escape(multiplayer.get_remote_sender_id())

func _server_capture_escape(peer_id: int) -> void:
	if capture_target_peer_id != peer_id or capture_elapsed > CAPTURE_ESCAPE_SECONDS:
		return
	capture_escape_presses += 1
	var progress_text := "LIBERTAÇÃO: %d/%d" % [capture_escape_presses, CAPTURE_ESCAPE_PRESSES]
	if peer_id == 1:
		if capture_message:
			capture_message.text = progress_text + " — CONTINUA!"
	else:
		rpc_id(peer_id, "client_capture_progress", progress_text)

func _finish_capture(escaped: bool) -> void:
	var peer_id := capture_target_peer_id
	if peer_id == 0:
		return
	capture_target_peer_id = 0
	capture_elapsed = 0.0
	capture_escape_presses = 0
	if escaped:
		_apply_capture_state_to_peer(peer_id, false, false, "LIBERTASTE-TE! FOGE AGORA.")
		if peer_id != 1 and network_peer != null:
			rpc_id(peer_id, "client_capture_state", false, false, "LIBERTASTE-TE! FOGE AGORA.")
		entity_ai_state = "HUNT"
		entity_state_time = 0.0
		# Pequena janela de fuga: a entidade recua para retomar a perseguição.
		if entity_presence:
			entity_presence.global_position += (entity_presence.global_position - capture_target_node.global_position).normalized() * 2.5
	else:
		eliminated_peers[peer_id] = true
		_apply_capture_state_to_peer(peer_id, false, true, "FOSTE ELIMINADO. A EQUIPA PODE CONTINUAR A MISSÃO.")
		if peer_id != 1 and network_peer != null:
			rpc_id(peer_id, "client_capture_state", false, true, "FOSTE ELIMINADO. A EQUIPA PODE CONTINUAR A MISSÃO.")
		entity_ai_state = "HUNT"
		entity_state_time = 0.0
	capture_target_node = null

@rpc("authority", "call_remote", "reliable")
func client_capture_state(captured: bool, eliminated: bool, message: String) -> void:
	if multiplayer.is_server():
		return
	var local_player := get_node_or_null("Player")
	if local_player and local_player.has_method("set_capture_state"):
		local_player.call("set_capture_state", captured, eliminated)
	if capture_overlay:
		capture_overlay.visible = captured or eliminated
	if capture_message:
		capture_message.text = message
	if capture_button:
		capture_button.visible = captured and not eliminated

@rpc("authority", "call_remote", "reliable")
func handle_player_health_depleted(player: Node3D) -> void:
	# Falha fisiológica local: não substitui a captura da criatura; comunica claramente
	# que o jogador ficou incapacitado por exposição prolongada ao exterior.
	if player == null or not is_instance_valid(player):
		return
	if capture_overlay:
		capture_overlay.visible = true
	if capture_message:
		capture_message.text = "PERDESTE A CONSCIÊNCIA POR EXPOSIÇÃO AO FRIO. A MISSÃO FICA EM RISCO."
	if capture_button:
		capture_button.visible = false
	_play_sfx("danger_pulse.wav")
	var prompt_label := get_node_or_null("HUD/Prompt") as Label
	if prompt_label:
		prompt_label.text = "INCONSCIENTE — EXPOSIÇÃO CRÍTICA AO FRIO"

func client_capture_progress(message: String) -> void:
	if multiplayer.is_server():
		return
	if capture_message:
		capture_message.text = message

func _find_entity_target() -> Node3D:
	var best: Node3D = get_node_or_null("Player") as Node3D
	var best_distance := INF
	if best != null and is_instance_valid(best):
		best_distance = entity_presence.global_position.distance_to(best.global_position)
	for peer_id in remote_players.keys():
		var candidate := remote_players[peer_id] as Node3D
		if candidate == null or not is_instance_valid(candidate):
			continue
		var distance := entity_presence.global_position.distance_to(candidate.global_position)
		if distance < best_distance:
			best = candidate
			best_distance = distance
	return best

func _broadcast_entity_state() -> void:
	if not multiplayer.is_server() or entity_presence == null:
		return
	rpc("receive_entity_state", entity_presence.global_position, entity_presence.visible, entity_ai_state, entity_waypoint_index, entity_hidden_time, entity_state_time, entity_reaction_label.text if entity_reaction_label else "")

func _send_entity_state_to(peer_id: int) -> void:
	if not multiplayer.is_server() or entity_presence == null:
		return
	rpc_id(peer_id, "receive_entity_state", entity_presence.global_position, entity_presence.visible, entity_ai_state, entity_waypoint_index, entity_hidden_time, entity_state_time, entity_reaction_label.text if entity_reaction_label else "")

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_entity_state(position: Vector3, visible: bool, ai_state: String, waypoint_index: int, hidden_time: float, state_time: float, reaction_text: String) -> void:
	# Clients render the host's snapshot; they never simulate or decide the creature AI.
	if multiplayer.is_server():
		return
	if entity_presence == null:
		_activate_entity_reaction("INITIAL_PATROL")
	if entity_presence == null:
		return
	entity_active = true
	entity_presence.global_position = position
	entity_presence.visible = visible
	entity_ai_state = ai_state
	entity_waypoint_index = waypoint_index
	entity_hidden_time = hidden_time
	entity_state_time = state_time
	if entity_reaction_label and not reaction_text.is_empty():
		entity_reaction_label.text = reaction_text

func _is_entity_lit_by_player(player: Node3D, flashlight: SpotLight3D) -> bool:
	if flashlight == null or not flashlight.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - flashlight.global_position
	if to_entity.length() > flashlight.spot_range:
		return false
	var forward := -flashlight.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < cos(deg_to_rad(flashlight.spot_angle * 0.5)):
		return false
	var query := PhysicsRayQueryParameters3D.create(flashlight.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _update_stealth_status() -> void:
	if stealth_status == null:
		return
	var player := get_node_or_null("Player")
	if player == null:
		return
	var crouching := bool(player.get("is_crouching"))
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	stealth_status.text = "FURTIVIDADE: AGACHADO · RUÍDO BAIXO" if crouching else "FURTIVIDADE: DE PÉ · RUÍDO ELEVADO"
	if flashlight and flashlight.visible:
		stealth_status.text += " · LANTERNA LIGADA"

func _is_entity_observed(player: Node3D) -> bool:
	var camera := player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
	if camera == null or not entity_presence.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - camera.global_position
	if to_entity.length() > 17.0:
		return false
	var forward := -camera.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < 0.965:
		return false
	var query := PhysicsRayQueryParameters3D.create(camera.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _set_decision_status(message: String) -> void:
	if decision_status:
		decision_status.text = message

func _set_alarm_state(active: bool) -> void:
	_alarm_active = active
	var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
	if lamp:
		lamp.light_color = Color(1.0, 0.025, 0.01) if active else (Color(0.1, 0.9, 0.35) if coop_solved else Color(0.18, 0.48, 0.72))
		lamp.light_energy = 1.35 if active else (0.9 if coop_solved else 0.45)
	var beacon := get_node_or_null("ResearchStationRoom/AlarmBeacon") as OmniLight3D
	if beacon:
		beacon.visible = active
	var beacon_mesh := get_node_or_null("ResearchStationRoom/AlarmBeacon/BeaconMesh") as MeshInstance3D
	if beacon_mesh:
		beacon_mesh.visible = active

func _update_lighting_effects() -> void:
	# LEDs and luminaires respond to danger, relays and the emergency state.
	var room := get_node_or_null("ResearchStationRoom")
	if room == null:
		return
	var lamp := room.get_node_or_null("FailingEmergencyLamp") as OmniLight3D
	if lamp and entity_active:
		var speed := 15.0 if entity_ai_state == "HUNT" else 7.0
		var depth := 1.0 if entity_ai_state == "HUNT" else 0.45
		lamp.light_energy = (0.42 + absf(sin(_lighting_time * speed)) * depth) if not _alarm_active else (0.3 + absf(sin(_lighting_time * 13.0)) * 1.45)
	# A segunda luminária falha de forma irregular; o painel emissivo acompanha a luz.
	var intermittent := room.get_node_or_null("IntermittentCeilingLamp") as OmniLight3D
	if intermittent:
		var pulse := absf(sin(_lighting_time * 8.7) * cos(_lighting_time * 3.1))
		intermittent.light_energy = 0.0 if pulse < 0.28 else (0.25 + pulse * 0.9)
	var intermittent_panel := room.get_node_or_null("IntermittentLEDPanel") as MeshInstance3D
	if intermittent_panel and intermittent_panel.material_override is StandardMaterial3D:
		var panel_material := intermittent_panel.material_override as StandardMaterial3D
		var panel_on := absf(sin(_lighting_time * 8.7) * cos(_lighting_time * 3.1)) >= 0.28
		panel_material.emission_energy_multiplier = 1.0 if panel_on else 0.02
	var strip_a := room.get_node_or_null("LEDStripA") as MeshInstance3D
	var strip_b := room.get_node_or_null("LEDStripB") as MeshInstance3D
	var led_color := Color(1.0, 0.025, 0.01) if _alarm_active else (Color(0.05, 1.0, 0.35) if coop_solved else Color(0.05, 0.65, 1.0))
	for strip in [strip_a, strip_b]:
		if strip and strip.material_override is StandardMaterial3D:
			var mat := strip.material_override as StandardMaterial3D
			mat.albedo_color = led_color
			mat.emission = led_color
			mat.emission_energy_multiplier = 1.8 if not _alarm_active else (0.6 + absf(sin(_lighting_time * 12.0)) * 3.5)
	var exit_light := room.get_node_or_null("ExitIndicatorLight") as OmniLight3D
	if exit_light:
		exit_light.light_color = Color(0.05, 1.0, 0.25) if coop_solved else Color(0.1, 0.65, 0.35)
		exit_light.light_energy = 1.3 if coop_solved else 0.45

func _build_environment() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.015, 0.025, 0.04)
	sky_mat.sky_horizon_color = Color(0.06, 0.065, 0.07)
	sky_mat.ground_bottom_color = Color(0.008, 0.01, 0.012)
	sky_mat.ground_horizon_color = Color(0.035, 0.04, 0.045)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_color = Color(0.34, 0.40, 0.49)
	env.ambient_light_energy = 0.82
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.tonemap_exposure = 1.05
	# Névoa polar atmosférica: melhora a profundidade sem efeitos volumétricos pesados.
	env.fog_enabled = true
	env.fog_light_color = Color(0.43, 0.52, 0.62)
	env.fog_light_energy = 0.72
	env.fog_density = 0.0035
	env.fog_sky_affect = 0.22
	env.fog_depth_begin = 12.0
	env.fog_depth_end = 110.0
	# Bloom discreto para LEDs e alarmes; controlado para GPUs móveis.
	env.glow_enabled = true
	env.glow_intensity = 0.32
	env.glow_strength = 0.55
	env.glow_bloom = 0.06
	env.glow_hdr_threshold = 1.35
	world.environment = env
	add_child(world)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-42, -25, 0)
	moon.light_color = Color(0.52, 0.61, 0.78)
	moon.light_energy = 0.46
	moon.shadow_enabled = true
	add_child(moon)
	var fill_light := OmniLight3D.new()
	fill_light.name = "RoomFillLight"
	fill_light.position = Vector3(0, 2.7, -2.5)
	fill_light.light_color = Color(0.48, 0.57, 0.66)
	fill_light.light_energy = 1.0
	fill_light.omni_range = 17.0
	fill_light.shadow_enabled = false
	add_child(fill_light)



func _build_global_visual_upgrade() -> void:
	# Passe visual transversal: melhora profundidade e identidade industrial
	# sem alterar portas, colisões ou objetivos.
	var details := Node3D.new()
	details.name = "GlobalVisualUpgrade"
	add_child(details)
	# Kit modular GLB de detalhe industrial. As instâncias são apenas decorativas:
	# não introduzem colisões novas nem alteram os percursos jogáveis.
	var corridor_kit := load("res://assets/station_corridor_kit.glb") as PackedScene
	if corridor_kit != null:
		for bay_index in range(4):
			var bay := corridor_kit.instantiate() as Node3D
			if bay != null:
				bay.name = "CorridorArtBay_%02d" % bay_index
				bay.position = Vector3(0.0, 0.0, -22.0 - float(bay_index) * 20.0)
				details.add_child(bay)
	else:
		push_warning("Kit visual GLB não carregado: res://assets/station_corridor_kit.glb")
	var pipe_mat := _material(Color(0.075, 0.105, 0.12), 0.34, 0.72)
	var pipe_edge := _material(Color(0.22, 0.28, 0.30), 0.38, 0.62)
	var dark_panel := _material(Color(0.025, 0.035, 0.042), 0.78, 0.18)
	var hazard_yellow := _material(Color(0.82, 0.48, 0.08), 0.66, 0.12)
	var hazard_black := _material(Color(0.025, 0.03, 0.032), 0.72, 0.12)
	var led_cyan := StandardMaterial3D.new()
	led_cyan.albedo_color = Color(0.04, 0.36, 0.43)
	led_cyan.emission_enabled = true
	led_cyan.emission = Color(0.02, 0.45, 0.62)
	led_cyan.emission_energy_multiplier = 1.25
	var led_amber := StandardMaterial3D.new()
	led_amber.albedo_color = Color(0.55, 0.15, 0.025)
	led_amber.emission_enabled = true
	led_amber.emission = Color(0.95, 0.10, 0.015)
	led_amber.emission_energy_multiplier = 1.5

	# Condutas técnicas no teto ao longo da estação.
	for run_index in range(3):
		var x := -4.35 + float(run_index) * 4.35
		var pipe := MeshInstance3D.new()
		pipe.name = "CeilingServicePipe_%02d" % run_index
		var pipe_mesh := CylinderMesh.new()
		pipe_mesh.top_radius = 0.075 if run_index != 1 else 0.11
		pipe_mesh.bottom_radius = pipe_mesh.top_radius
		pipe_mesh.height = 174.0
		pipe.mesh = pipe_mesh
		pipe.position = Vector3(x, 3.30, -94.0)
		pipe.rotation_degrees.x = 90.0
		pipe.material_override = pipe_mat if run_index != 1 else pipe_edge
		details.add_child(pipe)
		for support_index in range(18):
			var support_z := -8.0 - float(support_index) * 9.5
			_box(details, "PipeSupport_%02d_%02d" % [run_index, support_index], Vector3(0.18, 0.08, 0.12), Vector3(x, 3.42, support_z), pipe_edge, false)

	# Ventilação, LEDs e sinalização em cada zona modular.
	for zone_index in range(8):
		var zone_number := zone_index + 3
		var center_z := -42.2 - float(zone_index) * 20.0
		for side in [-1.0, 1.0]:
			var vent_x: float = side * 5.72
			_box(details, "VentHousing_%02d_%s" % [zone_number, str(side)], Vector3(0.07, 0.58, 1.05), Vector3(vent_x, 2.35, center_z - 4.35), dark_panel, false)
			for slat_index in range(5):
				_box(details, "VentSlat_%02d_%s_%02d" % [zone_number, str(side), slat_index], Vector3(0.085, 0.035, 0.91), Vector3(vent_x - side * 0.045, 2.12 + float(slat_index) * 0.105, center_z - 4.35), pipe_edge, false)
			_box(details, "ServiceLED_%02d_%s" % [zone_number, str(side)], Vector3(0.055, 0.075, 0.52), Vector3(side * 5.70, 2.92, center_z + 4.65), led_cyan if zone_index % 3 != 1 else led_amber, false)
		for stripe_index in range(8):
			var stripe_x := -1.35 + float(stripe_index) * 0.39
			var stripe_mat: Material = hazard_yellow if stripe_index % 2 == 0 else hazard_black
			_box(details, "EntryHazardStripe_%02d_%02d" % [zone_number, stripe_index], Vector3(0.31, 0.014, 0.12), Vector3(stripe_x, 0.018, center_z + 5.95), stripe_mat, false)
		_box(details, "MaintenancePanel_%02d" % zone_number, Vector3(0.07, 0.78, 0.62), Vector3(-5.73, 1.45, center_z + 1.6), dark_panel, false)
		for indicator in range(3):
			_box(details, "MaintenanceLED_%02d_%02d" % [zone_number, indicator], Vector3(0.035, 0.055, 0.055), Vector3(-5.685, 1.68 - float(indicator) * 0.18, center_z + 1.6), led_cyan if indicator != 1 else led_amber, false)

	# Exterior: mastro de comunicações e projetores junto ao gerador.
	var exterior := get_node_or_null("PolarExterior")
	if exterior:
		var antenna_mat := _material(Color(0.13, 0.17, 0.19), 0.34, 0.78)
		var antenna := MeshInstance3D.new()
		antenna.name = "PolarCommunicationsMast"
		var mast_mesh := CylinderMesh.new()
		mast_mesh.top_radius = 0.055
		mast_mesh.bottom_radius = 0.10
		mast_mesh.height = 6.0
		antenna.mesh = mast_mesh
		antenna.position = Vector3(-10.5, 3.0, -44.5)
		antenna.material_override = antenna_mat
		exterior.add_child(antenna)
		for antenna_y in [4.0, 4.8, 5.6]:
			var ring := MeshInstance3D.new()
			ring.name = "MastAntennaRing_%s" % str(antenna_y)
			var ring_mesh := TorusMesh.new()
			ring_mesh.inner_radius = 0.10
			ring_mesh.outer_radius = 0.13
			ring_mesh.rings = 4
			ring_mesh.ring_segments = 8
			ring.mesh = ring_mesh
			ring.position = Vector3(-10.5, antenna_y, -44.5)
			ring.material_override = pipe_edge
			exterior.add_child(ring)
		for side in [-1.0, 1.0]:
			var flood := OmniLight3D.new()
			flood.name = "GeneratorFloodlight_%s" % str(side)
			flood.position = Vector3(-7.2 + side * 2.4, 3.15, -39.2)
			flood.light_color = Color(0.58, 0.78, 0.88)
			flood.light_energy = 0.65
			flood.omni_range = 7.0
			flood.shadow_enabled = false
			exterior.add_child(flood)
			_box(exterior, "FloodlightHousing_%s" % str(side), Vector3(0.38, 0.18, 0.22), Vector3(-7.2 + side * 2.4, 3.25, -39.2), pipe_mat, false)



func _build_world_foundation() -> void:
	# Piso contínuo de segurança sob todo o mapa jogável. A estação tem zonas até
	# aproximadamente z=-189, enquanto o terreno exterior antigo terminava em z=-78;
	# esta base elimina o vazio físico no fim do mapa e une as cotas do percurso.
	var foundation := Node3D.new()
	foundation.name = "ContinuousPlayableFoundation"
	add_child(foundation)
	var snow_ground := _material(Color(0.39, 0.48, 0.54), 0.98, 0.0)
	var edge_mat := _material(Color(0.16, 0.23, 0.28), 0.9, 0.0)
	# Topo a y=-0.01: alinha com os pisos modulares existentes (centro -0.16, altura 0.3).
	_box(foundation, "ContinuousGroundCollision", Vector3(76.0, 0.3, 232.0), Vector3(0.0, -0.16, -101.0), snow_ground, true)
	# Limites visíveis/colidíveis afastados da rota, para impedir que o jogador saia do mundo.
	_box(foundation, "PlayableBoundaryLeft", Vector3(0.6, 3.0, 232.0), Vector3(-38.0, 1.35, -101.0), edge_mat, true)
	_box(foundation, "PlayableBoundaryRight", Vector3(0.6, 3.0, 232.0), Vector3(38.0, 1.35, -101.0), edge_mat, true)
	_box(foundation, "PlayableBoundaryNorth", Vector3(76.0, 3.0, 0.6), Vector3(0.0, 1.35, 15.0), edge_mat, true)
	_box(foundation, "PlayableBoundarySouth", Vector3(76.0, 3.0, 0.6), Vector3(0.0, 1.35, -217.0), edge_mat, true)

func _build_exterior_world() -> void:
	# Zona exterior explorável ligada ao corredor de saída existente (aprox. z=-16.8).
	var outdoors := Node3D.new()
	outdoors.name = "PolarExterior"
	add_child(outdoors)
	var snow := _material(Color(0.48, 0.57, 0.63), 0.96, 0.0)
	var packed_snow := _material(Color(0.25, 0.32, 0.37), 0.94, 0.0)
	var dark_metal := _material(Color(0.075, 0.105, 0.125), 0.72, 0.62)
	var warning := StandardMaterial3D.new()
	warning.albedo_color = Color(0.12, 0.72, 0.82)
	warning.emission_enabled = true
	warning.emission = Color(0.02, 0.42, 0.58)
	warning.emission_energy_multiplier = 1.4
	# Snowfield begins at the corridor mouth and extends into an explorable yard.
	_box(outdoors, "ExteriorSnowfield", Vector3(64, 0.3, 208), Vector3(0, -0.15, -104), snow)
	_box(outdoors, "PackedPathToGenerator", Vector3(5.0, 0.035, 34), Vector3(0, -0.105, -37), packed_snow, false)
	# Snow banks frame the playable route without sealing it.
	for i in range(9):
		var side := -1.0 if i % 2 == 0 else 1.0
		var z := -23.0 - float(i) * 5.2
		var drift := _box(outdoors, "SnowDrift_%02d" % i, Vector3(3.2, 0.9 + float(i % 3) * 0.25, 2.8), Vector3(side * (5.4 + float(i % 2)), 0.1, z), snow, false)
		drift.rotation_degrees.z = side * float(4 + i % 5)
	# Montes de neve arredondados para quebrar a silhueta geométrica do cenário.
	for i in range(7):
		var mound := MeshInstance3D.new()
		mound.name = "RoundedSnowMound_%02d" % i
		var mound_mesh := SphereMesh.new()
		mound_mesh.radius = 1.0
		mound_mesh.height = 2.0
		mound.mesh = mound_mesh
		mound.scale = Vector3(2.4 + float(i % 3) * 0.55, 0.48 + float(i % 2) * 0.18, 1.8 + float(i % 2) * 0.4)
		mound.position = Vector3((-1.0 if i % 2 == 0 else 1.0) * (7.2 + float(i % 3) * 1.4), 0.04, -25.0 - float(i) * 4.2)
		mound.material_override = snow
		outdoors.add_child(mound)
	# Silhuetas de gelo facetado para quebrar a repetição de blocos no horizonte.
	var ice_mat := _material(Color(0.31, 0.43, 0.51), 0.3, 0.16)
	ice_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ice_mat.albedo_color.a = 0.82
	for i in range(11):
		var shard := MeshInstance3D.new()
		shard.name = "PolarIceSpire_%02d" % i
		var shard_mesh := CylinderMesh.new()
		shard_mesh.top_radius = 0.04 + float(i % 3) * 0.035
		shard_mesh.bottom_radius = 0.38 + float(i % 4) * 0.12
		shard_mesh.height = 1.6 + float(i % 5) * 0.48
		shard.mesh = shard_mesh
		shard.material_override = ice_mat
		var side := -1.0 if i % 2 == 0 else 1.0
		shard.position = Vector3(side * (10.5 + float(i % 3) * 2.0), shard_mesh.height * 0.5 - 0.03, -24.0 - float(i) * 3.15)
		shard.rotation_degrees.z = side * float(4 + i % 7)
		outdoors.add_child(shard)
	# Marcos de orientação industriais, legíveis sem depender de texto pequeno.
	var sign_back := _material(Color(0.035, 0.075, 0.09), 0.62, 0.48)
	var sign_glow := StandardMaterial3D.new()
	sign_glow.albedo_color = Color(0.08, 0.65, 0.78)
	sign_glow.emission_enabled = true
	sign_glow.emission = Color(0.025, 0.42, 0.58)
	sign_glow.emission_energy_multiplier = 1.25
	_box(outdoors, "GeneratorDirectionSign", Vector3(1.55, 0.62, 0.09), Vector3(-4.5, 2.05, -25.0), sign_back, false)
	_box(outdoors, "GeneratorDirectionArrow", Vector3(0.68, 0.075, 0.035), Vector3(-4.5, 2.05, -24.94), sign_glow, false)
	_box(outdoors, "GeneratorDirectionArrowHead", Vector3(0.16, 0.23, 0.035), Vector3(-4.18, 2.05, -24.94), sign_glow, false)
	# Industrial generator shed, physically reachable along the path.
	_box(outdoors, "GeneratorShedBody", Vector3(5.8, 3.2, 5.0), Vector3(-7.2, 1.35, -42), dark_metal)
	_box(outdoors, "GeneratorShedRoofSnow", Vector3(6.1, 0.22, 5.3), Vector3(-7.2, 3.05, -42), snow, false)
	_box(outdoors, "GeneratorDoor", Vector3(1.55, 2.35, 0.12), Vector3(-7.2, 1.15, -39.43), packed_snow, false)
	_box(outdoors, "GeneratorVentA", Vector3(0.85, 0.72, 0.12), Vector3(-8.9, 2.2, -39.36), dark_metal, false)
	_box(outdoors, "GeneratorVentB", Vector3(0.85, 0.72, 0.12), Vector3(-5.5, 2.2, -39.36), dark_metal, false)
	# Antenna mast and a distant instrument pole provide scale and navigation landmarks.
	_box(outdoors, "WeatherAntennaMast", Vector3(0.16, 7.5, 0.16), Vector3(8.8, 3.55, -49), dark_metal, false)
	_box(outdoors, "WeatherAntennaCrossbar", Vector3(2.3, 0.12, 0.12), Vector3(8.8, 6.1, -49), dark_metal, false)
	_box(outdoors, "WeatherInstrumentPole", Vector3(0.12, 3.8, 0.12), Vector3(12.5, 1.7, -31), dark_metal, false)
	_box(outdoors, "WeatherInstrumentHead", Vector3(0.8, 0.32, 0.8), Vector3(12.5, 3.65, -31), warning, false)
	# Low cyan guide lights remain visible through snow, but do not reveal the creature.
	for i in range(6):
		var guide := OmniLight3D.new()
		guide.name = "ExteriorGuideLight_%02d" % i
		guide.position = Vector3(0, 0.28, -22.0 - float(i) * 5.1)
		guide.light_color = Color(0.15, 0.72, 0.9)
		guide.light_energy = 0.48
		guide.omni_range = 3.4
		guide.shadow_enabled = false
		outdoors.add_child(guide)
		_box(outdoors, "ExteriorGuideMarker_%02d" % i, Vector3(0.22, 0.42, 0.22), Vector3(0, 0.12, -22.0 - float(i) * 5.1), warning, false)
	# Snow particles: wind-driven, volumetric box emitter around the yard.
	exterior_weather_particles = GPUParticles3D.new()
	exterior_weather_particles.name = "PolarSnowfall"
	exterior_weather_particles.amount = 520
	exterior_weather_particles.lifetime = 6.5
	exterior_weather_particles.preprocess = 2.0
	exterior_weather_particles.position = Vector3(0, 5.0, -39)
	var process_material := ParticleProcessMaterial.new()
	process_material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	process_material.emission_box_extents = Vector3(25, 7, 27)
	process_material.direction = Vector3(-1.0, -0.22, -0.18)
	process_material.spread = 18.0
	process_material.initial_velocity_min = 2.2
	process_material.initial_velocity_max = 5.8
	process_material.gravity = Vector3(-1.8, -1.2, -0.4)
	process_material.scale_min = 0.035
	process_material.scale_max = 0.085
	process_material.color = Color(0.82, 0.91, 1.0, 0.78)
	exterior_weather_particles.process_material = process_material
	var snow_mesh := SphereMesh.new()
	snow_mesh.radius = 0.035
	snow_mesh.height = 0.07
	var snow_visual := StandardMaterial3D.new()
	snow_visual.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	snow_visual.albedo_color = Color(0.82, 0.91, 1.0, 0.8)
	snow_visual.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	snow_mesh.material = snow_visual
	exterior_weather_particles.draw_pass_1 = snow_mesh
	outdoors.add_child(exterior_weather_particles)
	# A warm warning beacon marks the generator shed; intensity changes with gusts.
	exterior_beacon = OmniLight3D.new()
	exterior_beacon.name = "ExteriorStormBeacon"
	exterior_beacon.position = Vector3(-7.2, 3.35, -42)
	exterior_beacon.light_color = Color(1.0, 0.28, 0.08)
	exterior_beacon.light_energy = 0.75
	exterior_beacon.omni_range = 8.0
	exterior_beacon.shadow_enabled = false
	outdoors.add_child(exterior_beacon)
	# Ponto de extração visível no exterior, afastado do abrigo e do gerador.
	extraction_landing_marker = Node3D.new()
	extraction_landing_marker.name = "ExtractionLandingZone"
	extraction_landing_marker.position = Vector3(0.0, 0.0, -56.0)
	var landing_ring := MeshInstance3D.new()
	var ring_mesh := CylinderMesh.new()
	ring_mesh.top_radius = 2.8
	ring_mesh.bottom_radius = 2.8
	ring_mesh.height = 0.08
	landing_ring.mesh = ring_mesh
	landing_ring.material_override = _material(Color(0.05, 0.35, 0.25), 0.35, 0.2)
	landing_ring.visible = false
	landing_ring.name = "LandingZoneRing"
	extraction_landing_marker.add_child(landing_ring)
	var landing_light := OmniLight3D.new()
	landing_light.name = "LandingZoneLight"
	landing_light.position.y = 2.5
	landing_light.light_color = Color(0.18, 0.95, 0.65)
	landing_light.light_energy = 0.0
	landing_light.omni_range = 13.0
	landing_light.shadow_enabled = false
	extraction_landing_marker.add_child(landing_light)
	var landing_label := Label3D.new()
	landing_label.name = "LandingZoneLabel"
	landing_label.text = "PONTO DE EXTRAÇÃO"
	landing_label.position.y = 3.6
	landing_label.font_size = 22
	landing_label.modulate = Color(0.35, 1.0, 0.72)
	landing_label.visible = false
	extraction_landing_marker.add_child(landing_label)
	outdoors.add_child(extraction_landing_marker)

func _update_exterior_weather(delta: float) -> void:
	if exterior_weather_particles == null:
		return
	exterior_weather_phase += delta
	# Rajadas irregulares: neve, vento, visibilidade e luz respondem à meteorologia.
	var gust := 0.5 + 0.5 * sin(exterior_weather_phase * 0.31 + sin(exterior_weather_phase * 0.11) * 1.7)
	exterior_gust_strength = gust
	exterior_weather_particles.amount = int(280.0 + gust * 520.0)
	var pm := exterior_weather_particles.process_material as ParticleProcessMaterial
	if pm:
		pm.initial_velocity_min = 1.6 + gust * 1.7
		pm.initial_velocity_max = 3.8 + gust * 4.2
		pm.gravity = Vector3(-1.0 - gust * 2.8, -1.2, -0.4 - gust * 1.1)
	if exterior_beacon:
		exterior_beacon.light_energy = 0.45 + gust * 0.85
	var player := get_node_or_null("Player") as CharacterBody3D
	if player:
		# A saída do corredor situa-se em z=-16.8; a zona exterior começa depois dela.
		var outside_now := player.global_position.z < -17.2 or absf(player.global_position.x) > 13.2
		if outside_now != exterior_is_player_outside:
			exterior_is_player_outside = outside_now
			if exterior_wind_player:
				if outside_now and exterior_wind_player.stream:
					if not exterior_wind_player.playing:
						exterior_wind_player.play()
				else:
					exterior_wind_player.stop()
		if exterior_wind_player and outside_now:
			exterior_wind_player.volume_db = lerpf(-25.0, -9.0, gust)
		var camera := player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
		if camera:
			# A tempestade reduz a distância de visão no exterior, sem alterar o interior.
			camera.far = lerpf(62.0, 23.0, gust) if outside_now else 120.0
		if exterior_weather_label:
			exterior_weather_label.visible = outside_now
			if outside_now:
				var weather_name := "NEVE MODERADA" if gust < 0.38 else ("VENTO POLAR" if gust < 0.72 else "TEMPESTADE · VISIBILIDADE REDUZIDA")
				exterior_weather_label.text = "%s  ·  VENTO %d%%" % [weather_name, int(round(gust * 100.0))]

func _build_exterior_side_corridor(parent: Node3D, side_name: String, direction: float, wall_mat: Material, floor_mat: Material, metal_mat: Material) -> void:
	# Two lateral corridors lead from the station to separate exterior airlocks.
	var x_inner := direction * 6.0
	var x_mid := direction * 9.0
	var x_outer := direction * 12.0
	_box(parent, side_name + "ExteriorCorridorFloor", Vector3(6.4, 0.18, 2.6), Vector3(direction * 9.0, -0.16, -2.0), floor_mat)
	_box(parent, side_name + "ExteriorCorridorInnerWall", Vector3(6.4, 3.2, 0.18), Vector3(direction * 9.0, 1.5, -3.3), wall_mat)
	_box(parent, side_name + "ExteriorCorridorOuterWall", Vector3(6.4, 3.2, 0.18), Vector3(direction * 9.0, 1.5, -0.7), wall_mat)
	_box(parent, side_name + "ExteriorCorridorCeiling", Vector3(6.4, 0.18, 2.6), Vector3(direction * 9.0, 3.25, -2.0), wall_mat)
	# Porta exterior funcional: folha com colisão, detetável pelo raio de INTERAGIR.
	var door_mat := _material(Color(0.09, 0.16, 0.19), 0.4, 0.55)
	var door := StaticBody3D.new()
	door.name = side_name + "ExteriorDoor"
	door.set_script(INTERACTABLE_SCRIPT)
	door.require_coop = false
	door.slide_distance = -direction * 1.95
	door.position = Vector3(direction * 12.1, 1.2, -2.0)
	var leaf := MeshInstance3D.new()
	leaf.name = "DoorMesh"
	var leaf_mesh := BoxMesh.new()
	leaf_mesh.size = Vector3(0.12, 2.45, 1.75)
	leaf.mesh = leaf_mesh
	leaf.material_override = door_mat
	door.add_child(leaf)
	var collision := CollisionShape3D.new()
	collision.name = "DoorCollision"
	var collision_shape := BoxShape3D.new()
	collision_shape.size = Vector3(0.12, 2.45, 1.75)
	collision.shape = collision_shape
	door.add_child(collision)
	parent.add_child(door)
	_box(parent, side_name + "ExteriorDoorFrameTop", Vector3(0.28, 0.18, 2.05), Vector3(direction * 12.1, 2.55, -2.0), metal_mat, false)
	_box(parent, side_name + "ExteriorDoorFrameNear", Vector3(0.28, 2.6, 0.18), Vector3(direction * 12.1, 1.25, -3.0), metal_mat, false)
	_box(parent, side_name + "ExteriorDoorFrameFar", Vector3(0.28, 2.6, 0.18), Vector3(direction * 12.1, 1.25, -1.0), metal_mat, false)
	var indicator_mat := StandardMaterial3D.new()
	indicator_mat.albedo_color = Color(1.0, 0.12, 0.06)
	indicator_mat.emission_enabled = true
	indicator_mat.emission = Color(1.0, 0.04, 0.015)
	indicator_mat.emission_energy_multiplier = 1.4
	var indicator := MeshInstance3D.new()
	indicator.name = "LockIndicator"
	var indicator_mesh := BoxMesh.new()
	indicator_mesh.size = Vector3(0.08, 0.12, 0.08)
	indicator.mesh = indicator_mesh
	indicator.material_override = indicator_mat
	indicator.position = Vector3(-direction * 0.24, 0.95, -1.0)
	door.add_child(indicator)

func _build_visual_quality_pass() -> void:
	# Passe gráfico leve para Android: elementos visuais sem colisão,
	# sem alterar geometrias navegáveis, portas ou objetivos.
	var detail_root := Node3D.new()
	detail_root.name = "VisualQualityPass"
	add_child(detail_root)

	var graphite := _material(Color(0.018, 0.027, 0.034), 0.48, 0.58)
	var brushed_metal := _material(Color(0.19, 0.235, 0.255), 0.34, 0.76)
	var caution_dark := _material(Color(0.035, 0.039, 0.038), 0.68, 0.12)
	var cyan_screen := StandardMaterial3D.new()
	cyan_screen.albedo_color = Color(0.018, 0.15, 0.19)
	cyan_screen.roughness = 0.28
	cyan_screen.metallic = 0.18
	cyan_screen.emission_enabled = true
	cyan_screen.emission = Color(0.015, 0.30, 0.42)
	cyan_screen.emission_energy_multiplier = 0.72
	var amber_led := StandardMaterial3D.new()
	amber_led.albedo_color = Color(0.55, 0.19, 0.025)
	amber_led.emission_enabled = true
	amber_led.emission = Color(0.95, 0.16, 0.025)
	amber_led.emission_energy_multiplier = 1.1

	# Painéis de instrumentação sobre a secretária existente.
	_box(detail_root, "ConsoleMonitorHousingA", Vector3(0.78, 0.54, 0.10), Vector3(-4.05, 1.20, -4.12), graphite, false)
	_box(detail_root, "ConsoleMonitorScreenA", Vector3(0.68, 0.42, 0.018), Vector3(-4.05, 1.21, -4.055), cyan_screen, false)
	_box(detail_root, "ConsoleMonitorHousingB", Vector3(0.62, 0.46, 0.10), Vector3(-3.15, 1.16, -4.12), graphite, false)
	_box(detail_root, "ConsoleMonitorScreenB", Vector3(0.52, 0.34, 0.018), Vector3(-3.15, 1.17, -4.055), cyan_screen, false)

	# Botões físicos e indicadores dão escala aos terminais sem adicionar colisões.
	for i in range(5):
		var bx := -4.48 + float(i) * 0.32
		_box(detail_root, "ConsoleButton_%02d" % i, Vector3(0.12, 0.035, 0.10), Vector3(bx, 0.99, -3.43), brushed_metal, false)
		_box(detail_root, "ConsoleIndicator_%02d" % i, Vector3(0.055, 0.025, 0.025), Vector3(bx, 1.015, -3.365), amber_led if i == 3 else cyan_screen, false)

	# Marcação de segurança no piso junto à saída; plana para não interferir com o jogador.
	for i in range(7):
		var stripe_x := -1.35 + float(i) * 0.45
		_box(detail_root, "ExitHazardStripe_%02d" % i, Vector3(0.22, 0.014, 0.62), Vector3(stripe_x, 0.018, -8.78), caution_dark if i % 2 == 0 else amber_led, false)

	# Reforços metálicos discretos nas juntas da estação.
	for side in [-1.0, 1.0]:
		for i in range(4):
			var z := 2.0 - float(i) * 2.65
			_box(detail_root, "WallFastener_%s_%02d" % ["L" if side < 0.0 else "R", i], Vector3(0.045, 0.12, 0.12), Vector3(side * 5.69, 2.28, z), brushed_metal, false)

	# NOVO: painéis modulares, juntas de expansão e iluminação linear de leitura.
	# Tudo é decorativo e sem colisão, para não alterar a navegação validada.
	var wall_panel := _material(Color(0.055, 0.078, 0.091), 0.42, 0.72)
	var panel_edge := _material(Color(0.22, 0.29, 0.32), 0.32, 0.78)
	var led_cyan := StandardMaterial3D.new()
	led_cyan.albedo_color = Color(0.025, 0.28, 0.34)
	led_cyan.emission_enabled = true
	led_cyan.emission = Color(0.02, 0.62, 0.82)
	led_cyan.emission_energy_multiplier = 1.45
	var led_warm := StandardMaterial3D.new()
	led_warm.albedo_color = Color(0.38, 0.16, 0.055)
	led_warm.emission_enabled = true
	led_warm.emission = Color(0.95, 0.31, 0.075)
	led_warm.emission_energy_multiplier = 0.8

	for side in [-1.0, 1.0]:
		for panel_index in range(7):
			var panel_z := 4.1 - float(panel_index) * 2.12
			_box(detail_root, "WallModule_%s_%02d" % ["L" if side < 0.0 else "R", panel_index],
				Vector3(0.035, 0.82, 1.62), Vector3(side * 5.79, 2.18, panel_z), wall_panel, false)
			_box(detail_root, "WallModuleEdge_%s_%02d" % ["L" if side < 0.0 else "R", panel_index],
				Vector3(0.045, 0.035, 1.66), Vector3(side * 5.765, 2.61, panel_z), panel_edge, false)
			_box(detail_root, "WallModuleLowerEdge_%s_%02d" % ["L" if side < 0.0 else "R", panel_index],
				Vector3(0.045, 0.025, 1.66), Vector3(side * 5.765, 1.75, panel_z), panel_edge, false)
		# Uma faixa luminosa contínua de cada lado, para orientar a leitura espacial.
		_box(detail_root, "WallGuideLight_%s" % ("L" if side < 0.0 else "R"),
			Vector3(0.025, 0.055, 12.2), Vector3(side * 5.73, 2.92, -2.1), led_cyan, false)

	# Calhas de luz no teto, com segmentos âmbar a assinalar zonas de risco.
	for light_index in range(6):
		var light_z := 4.2 - float(light_index) * 2.45
		_box(detail_root, "CeilingLightHousing_%02d" % light_index,
			Vector3(1.72, 0.075, 0.18), Vector3(0.0, 3.39, light_z), graphite, false)
		_box(detail_root, "CeilingLightDiffuser_%02d" % light_index,
			Vector3(1.52, 0.022, 0.055), Vector3(0.0, 3.342, light_z), led_warm if light_index == 4 else led_cyan, false)

	# Grelhas técnicas no pavimento e fixações de serviço — geometria plana sem colisão.
	for grate_index in range(5):
		var grate_z := 3.7 - float(grate_index) * 3.0
		_box(detail_root, "FloorServiceGrateFrame_%02d" % grate_index,
			Vector3(1.05, 0.018, 0.56), Vector3(3.75, 0.022, grate_z), panel_edge, false)
		for slat_index in range(7):
			var grate_x := 3.30 + float(slat_index) * 0.15
			_box(detail_root, "FloorServiceGrateSlat_%02d_%02d" % [grate_index, slat_index],
				Vector3(0.025, 0.02, 0.48), Vector3(grate_x, 0.034, grate_z), graphite, false)

	# Pequenos indicadores de zona numerados por cor, sem texto 3D pesado.
	for marker_index in range(4):
		var marker_z := -1.4 - float(marker_index) * 3.0
		_box(detail_root, "ZoneStatusPlate_%02d" % marker_index,
			Vector3(0.035, 0.22, 0.42), Vector3(-5.73, 2.22, marker_z), panel_edge, false)
		_box(detail_root, "ZoneStatusLED_%02d" % marker_index,
			Vector3(0.045, 0.055, 0.055), Vector3(-5.70, 2.24, marker_z), led_warm if marker_index == 3 else led_cyan, false)

func _build_room() -> void:
	var room := Node3D.new()
	room.name = "ResearchStationRoom"
	add_child(room)
	var concrete := _material(Color(0.19, 0.205, 0.21))
	var floor_mat := _material(Color(0.075, 0.085, 0.09), 0.28, 0.18)
	var metal := _material(Color(0.11, 0.135, 0.15), 0.42, 0.62)
	var hazard := _material(Color(0.43, 0.19, 0.07), 0.65, 0.25)
	_box(room, "Floor", Vector3(12, 0.3, 16), Vector3(0, -0.15, -2), floor_mat)
	_box(room, "Ceiling", Vector3(12, 0.25, 16), Vector3(0, 3.6, -2), concrete)
	# Side walls are split to create two genuine corridor openings to the exterior.
	# The openings are kept clear of collision geometry so the player can pass through.
	_box(room, "LeftWallFront", Vector3(0.3, 3.6, 5.0), Vector3(-6, 1.65, 3.5), concrete)
	_box(room, "LeftWallRear", Vector3(0.3, 3.6, 8.5), Vector3(-6, 1.65, -6.25), concrete)
	_box(room, "RightWallFront", Vector3(0.3, 3.6, 5.0), Vector3(6, 1.65, 3.5), concrete)
	_box(room, "RightWallRear", Vector3(0.3, 3.6, 8.5), Vector3(6, 1.65, -6.25), concrete)
	_build_exterior_side_corridor(room, "West", -1.0, concrete, floor_mat, metal)
	_build_exterior_side_corridor(room, "East", 1.0, concrete, floor_mat, metal)
	# Split the rear wall around a real doorway; the previous solid wall made
	# the door appear interactive while physically blocking the exit.
	_box(room, "BackWallLeft", Vector3(4.7, 3.6, 0.3), Vector3(-3.65, 1.65, -10), concrete)
	_box(room, "BackWallRight", Vector3(4.7, 3.6, 0.3), Vector3(3.65, 1.65, -10), concrete)
	_box(room, "DoorLintel", Vector3(2.6, 0.65, 0.3), Vector3(0, 3.275, -10), concrete)
	# A short corridor makes the doorway lead somewhere instead of ending at a wall.
	_box(room, "ExitCorridorFloor", Vector3(3.0, 0.18, 7.0), Vector3(0, -0.16, -13.3), floor_mat)
	_box(room, "ExitCorridorLeft", Vector3(0.18, 3.3, 7.0), Vector3(-1.5, 1.5, -13.3), concrete)
	_box(room, "ExitCorridorRight", Vector3(0.18, 3.3, 7.0), Vector3(1.5, 1.5, -13.3), concrete)
	# Piso técnico com placas, juntas e desgaste: detalhe geométrico leve para Android.
	var floor_seam := _material(Color(0.025, 0.032, 0.038), 0.78, 0.28)
	var floor_edge := _material(Color(0.16, 0.20, 0.22), 0.52, 0.55)
	for row in range(5):
		var floor_z := 4.8 - float(row) * 2.65
		_box(room, "FloorPanelJoint_%02d" % row, Vector3(11.2, 0.012, 0.035), Vector3(0, 0.008, floor_z), floor_seam, false)
		_box(room, "FloorDrain_%02d" % row, Vector3(0.62, 0.016, 0.18), Vector3(4.55, 0.012, floor_z - 0.72), floor_edge, false)
		for slot in range(5):
			_box(room, "FloorDrainSlot_%02d_%02d" % [row, slot], Vector3(0.035, 0.018, 0.13), Vector3(4.32 + float(slot) * 0.11, 0.02, floor_z - 0.72), floor_seam, false)
	# Modular wall ribs and pipe runs establish scale and navigation cues.
	for i in range(5):
		var z := 4.0 - float(i) * 3.0
		_box(room, "WallRib_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(-5.72, 1.55, z), metal)
		_box(room, "WallRibR_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(5.72, 1.55, z), metal)
	_box(room, "PipeHorizontal", Vector3(0.18, 0.18, 12), Vector3(-5.55, 2.95, -2), hazard)
	_box(room, "ControlDesk", Vector3(2.3, 0.95, 0.8), Vector3(-3.7, 0.48, -3.8), metal)
	_box(room, "StorageCrate", Vector3(1.1, 1.2, 1.0), Vector3(3.8, 0.6, 1.2), concrete)
	var lamp := OmniLight3D.new()
	lamp.name = "FailingEmergencyLamp"
	lamp.position = Vector3(0, 3.15, -4)
	lamp.light_color = Color(0.65, 0.11, 0.055)
	lamp.light_energy = 0.9
	lamp.omni_range = 10
	lamp.shadow_enabled = true
	room.add_child(lamp)
	# Ceiling luminaires with emissive LED panels create visible pools of light.
	for i in range(3):
		var z := 2.0 - float(i) * 4.0
		var panel_mat := StandardMaterial3D.new()
		panel_mat.albedo_color = Color(0.55, 0.82, 1.0)
		panel_mat.emission_enabled = true
		panel_mat.emission = Color(0.24, 0.62, 1.0)
		panel_mat.emission_energy_multiplier = 1.1
		_box(room, "CeilingLEDPanel_%02d" % i, Vector3(1.45, 0.055, 0.42), Vector3(0, 3.43, z), panel_mat, false)
		var ceiling_light := OmniLight3D.new()
		ceiling_light.name = "CeilingLamp_%02d" % i
		ceiling_light.position = Vector3(0, 3.15, z)
		ceiling_light.light_color = Color(0.48, 0.72, 1.0)
		ceiling_light.light_energy = 0.7
		ceiling_light.omni_range = 5.5
		ceiling_light.shadow_enabled = false
		room.add_child(ceiling_light)
	# Deterioração visível: zonas danificadas, cabos soltos e luminárias avariadas.
	var damage_dark := _material(Color(0.025, 0.03, 0.035), 0.98, 0.0)
	var rust_mat := _material(Color(0.24, 0.095, 0.045), 0.94, 0.12)
	var glass_mat := StandardMaterial3D.new()
	glass_mat.albedo_color = Color(0.16, 0.22, 0.24, 0.72)
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	# Marcas de impacto e fissuras junto a painéis e no piso; apenas visuais.
	_box(room, "WallImpact_01", Vector3(0.035, 0.62, 0.48), Vector3(-5.81, 1.42, -1.4), damage_dark, false)
	_box(room, "WallImpact_02", Vector3(0.04, 0.28, 0.23), Vector3(5.81, 2.05, 2.1), rust_mat, false)
	_box(room, "FloorScorch_01", Vector3(1.35, 0.012, 0.72), Vector3(2.3, 0.008, -4.2), damage_dark, false)
	_box(room, "FallenCeilingPanel", Vector3(1.05, 0.09, 0.56), Vector3(3.6, 0.06, -2.8), metal, false)
	_box(room, "BrokenGlassShard_01", Vector3(0.24, 0.018, 0.09), Vector3(2.9, 0.018, -2.35), glass_mat, false)
	_box(room, "BrokenGlassShard_02", Vector3(0.16, 0.014, 0.07), Vector3(3.18, 0.016, -2.52), glass_mat, false)
	_box(room, "LooseCable_01", Vector3(0.045, 0.045, 1.8), Vector3(-4.9, 2.6, -5.0), rust_mat, false)
	# Uma lâmpada fundida (sem emissão) e outra intermitente, claramente distinguíveis.
	var dead_panel_mat := StandardMaterial3D.new()
	dead_panel_mat.albedo_color = Color(0.045, 0.055, 0.06)
	_box(room, "BurntOutLEDPanel", Vector3(1.1, 0.045, 0.34), Vector3(-3.7, 3.43, -5.8), dead_panel_mat, false)
	var dead_lamp := OmniLight3D.new()
	dead_lamp.name = "BurntOutCeilingLamp"
	dead_lamp.position = Vector3(-3.7, 3.12, -5.8)
	dead_lamp.light_color = Color(0.45, 0.65, 0.8)
	dead_lamp.light_energy = 0.0
	dead_lamp.omni_range = 4.0
	dead_lamp.shadow_enabled = false
	room.add_child(dead_lamp)
	var flicker_panel_mat := StandardMaterial3D.new()
	flicker_panel_mat.albedo_color = Color(0.45, 0.62, 0.68)
	flicker_panel_mat.emission_enabled = true
	flicker_panel_mat.emission = Color(0.2, 0.55, 0.72)
	flicker_panel_mat.emission_energy_multiplier = 0.6
	_box(room, "IntermittentLEDPanel", Vector3(0.95, 0.045, 0.32), Vector3(3.7, 3.43, 1.5), flicker_panel_mat, false)
	var flicker_lamp := OmniLight3D.new()
	flicker_lamp.name = "IntermittentCeilingLamp"
	flicker_lamp.position = Vector3(3.7, 3.12, 1.5)
	flicker_lamp.light_color = Color(0.28, 0.62, 0.85)
	flicker_lamp.light_energy = 0.65
	flicker_lamp.omni_range = 4.8
	flicker_lamp.shadow_enabled = false
	room.add_child(flicker_lamp)
	# Wall LED strips change from blue (normal) to red (alarm) and green (solved).
	var led_mat := StandardMaterial3D.new()
	led_mat.albedo_color = Color(0.05, 0.65, 1.0)
	led_mat.emission_enabled = true
	led_mat.emission = Color(0.05, 0.65, 1.0)
	led_mat.emission_energy_multiplier = 1.8
	_box(room, "LEDStripA", Vector3(0.055, 0.08, 10.5), Vector3(-5.78, 2.72, -2.0), led_mat, false)
	_box(room, "LEDStripB", Vector3(0.055, 0.08, 10.5), Vector3(5.78, 2.72, -2.0), led_mat, false)
	# Emergency beacon only flashes when an alarm/event is active.
	var beacon := OmniLight3D.new()
	beacon.name = "AlarmBeacon"
	beacon.position = Vector3(4.8, 3.0, -7.5)
	beacon.light_color = Color(1.0, 0.015, 0.005)
	beacon.light_energy = 2.2
	beacon.omni_range = 7.0
	beacon.visible = false
	beacon.shadow_enabled = false
	room.add_child(beacon)
	var beacon_mesh := MeshInstance3D.new()
	beacon_mesh.name = "BeaconMesh"
	var beacon_shape := SphereMesh.new()
	beacon_shape.radius = 0.16
	beacon_shape.height = 0.32
	beacon_mesh.mesh = beacon_shape
	var beacon_mat := StandardMaterial3D.new()
	beacon_mat.albedo_color = Color(1.0, 0.01, 0.005)
	beacon_mat.emission_enabled = true
	beacon_mat.emission = Color(1.0, 0.01, 0.005)
	beacon_mat.emission_energy_multiplier = 3.0
	beacon_mesh.material_override = beacon_mat
	beacon_mesh.position = Vector3.ZERO
	beacon.add_child(beacon_mesh)
	beacon_mesh.visible = false
	var green := StandardMaterial3D.new()
	green.albedo_color = Color(0.12, 0.8, 0.31)
	green.emission_enabled = true
	green.emission = Color(0.05, 1.0, 0.22)
	green.emission_energy_multiplier = 2.2
	_box(room, "ExitIndicator", Vector3(0.75, 0.12, 0.06), Vector3(0, 2.85, -9.72), green, false)
	var exit_light := OmniLight3D.new()
	exit_light.name = "ExitIndicatorLight"
	exit_light.position = Vector3(0, 2.75, -9.25)
	exit_light.light_color = Color(0.1, 0.65, 0.35)
	exit_light.light_energy = 0.45
	exit_light.omni_range = 3.0
	exit_light.shadow_enabled = false
	room.add_child(exit_light)


	# Camada de detalhe visual: juntas, placas de manutenção e fixações metálicas.
	# Elementos sem colisão para enriquecer a leitura visual sem bloquear o jogador.
	var panel_mat := _material(Color(0.105, 0.135, 0.155), 0.48, 0.52)
	var seam_mat := _material(Color(0.035, 0.052, 0.064), 0.72, 0.35)
	var bolt_mat := _material(Color(0.34, 0.40, 0.43), 0.3, 0.82)
	var hazard_mat := StandardMaterial3D.new()
	hazard_mat.albedo_color = Color(0.82, 0.34, 0.055)
	hazard_mat.roughness = 0.58
	hazard_mat.metallic = 0.25
	for side in [-1.0, 1.0]:
		for i in range(4):
			var panel_z := 2.1 - float(i) * 2.65
			_box(room, "WallServicePanel_%s_%02d" % ["L" if side < 0.0 else "R", i], Vector3(0.035, 0.82, 1.35), Vector3(side * 5.79, 1.55, panel_z), panel_mat, false)
			_box(room, "WallPanelSeam_%s_%02d" % ["L" if side < 0.0 else "R", i], Vector3(0.045, 0.025, 1.18), Vector3(side * 5.765, 1.55, panel_z), seam_mat, false)
			for bolt_y in [1.22, 1.88]:
				var bolt := MeshInstance3D.new()
				bolt.name = "WallPanelBolt_%s_%02d_%s" % ["L" if side < 0.0 else "R", i, str(bolt_y)]
				var bolt_mesh := SphereMesh.new()
				bolt_mesh.radius = 0.035
				bolt_mesh.height = 0.07
				bolt.mesh = bolt_mesh
				bolt.material_override = bolt_mat
				bolt.position = Vector3(side * 5.755, bolt_y, panel_z - 0.53)
				room.add_child(bolt)
	# Faixas de segurança junto às áreas técnicas e grelhas de ventilação decorativas.
	for i in range(8):
		_box(room, "FloorHazardStripe_%02d" % i, Vector3(0.34, 0.014, 0.075), Vector3(-1.35 + float(i) * 0.38, 0.012, -8.85), hazard_mat, false)
	var vent_mat := _material(Color(0.055, 0.075, 0.085), 0.55, 0.58)
	_box(room, "CeilingVentHousing", Vector3(1.65, 0.08, 0.72), Vector3(4.15, 3.38, -5.0), metal, false)
	for i in range(7):
		_box(room, "CeilingVentSlat_%02d" % i, Vector3(1.42, 0.025, 0.045), Vector3(4.15, 3.325, -5.29 + float(i) * 0.095), vent_mat, false)

func _build_next_chamber() -> void:
	# Zona 02: câmara de investigação ligada ao corredor de saída.
	# A entrada fica aberta; não existe uma parede sólida a bloquear a passagem.
	var zone := Node3D.new()
	zone.name = "InvestigationChamber02"
	add_child(zone)
	var concrete := _material(Color(0.16, 0.18, 0.20))
	var floor_mat := _material(Color(0.055, 0.065, 0.075), 0.3, 0.2)
	var metal := _material(Color(0.10, 0.13, 0.16), 0.4, 0.55)
	# Câmara centrada em z=-23.5; o piso sobrepõe ligeiramente o corredor.
	_box(zone, "Zone02Floor", Vector3(12.0, 0.3, 12.5), Vector3(0, -0.16, -23.45), floor_mat)
	_box(zone, "Zone02Ceiling", Vector3(12.0, 0.25, 12.5), Vector3(0, 3.6, -23.45), concrete)
	_box(zone, "Zone02LeftWall", Vector3(0.3, 3.6, 12.5), Vector3(-6.0, 1.65, -23.45), concrete)
	_box(zone, "Zone02RightWall", Vector3(0.3, 3.6, 12.5), Vector3(6.0, 1.65, -23.45), concrete)
	# Parede frontal com abertura central de 3 m para a continuação do corredor.
	_box(zone, "Zone02EntryWallLeft", Vector3(3.8, 3.6, 0.3), Vector3(-4.1, 1.65, -17.2), concrete)
	_box(zone, "Zone02EntryWallRight", Vector3(3.8, 3.6, 0.3), Vector3(4.1, 1.65, -17.2), concrete)
	_box(zone, "Zone02EntryLintel", Vector3(4.4, 0.55, 0.3), Vector3(0, 3.30, -17.2), concrete)
	# Equipamento de investigação como referência visual, sem bloquear a circulação.
	_box(zone, "EvidenceConsole", Vector3(2.0, 1.0, 0.65), Vector3(0, 0.5, -27.2), metal)
	var console_label := Label3D.new()
	console_label.name = "Zone02ObjectiveLabel"
	console_label.text = "ZONA 02  /  TERMINAL DE INVESTIGAÇÃO"
	console_label.position = Vector3(0, 1.35, -27.2)
	console_label.font_size = 28
	console_label.modulate = Color(0.55, 0.88, 0.95)
	zone.add_child(console_label)
	var glow_mat := StandardMaterial3D.new()
	glow_mat.albedo_color = Color(0.05, 0.55, 0.75)
	glow_mat.emission_enabled = true
	glow_mat.emission = Color(0.05, 0.65, 1.0)
	glow_mat.emission_energy_multiplier = 1.4
	_box(zone, "Zone02GuideLight", Vector3(1.2, 0.06, 0.08), Vector3(0, 2.8, -17.0), glow_mat, false)
	var lamp := OmniLight3D.new()
	lamp.name = "Zone02ColdLamp"
	lamp.position = Vector3(0, 3.0, -23.5)
	lamp.light_color = Color(0.25, 0.58, 0.72)
	lamp.light_energy = 0.85
	lamp.omni_range = 9.0
	lamp.shadow_enabled = false
	zone.add_child(lamp)


func _build_remaining_zones() -> void:
	# Zonas 03-10: módulos físicos consecutivos. As passagens ficam abertas
	# para que os jogadores possam avançar sem uma barreira invisível.
	var zone_names: Array[String] = [
		"03 / LABORATÓRIOS CIENTÍFICOS", "04 / CENTRAL ENERGÉTICA", "05 / ENFERMARIA",
		"06 / ARMAZÉM E MANUTENÇÃO", "07 / CONTENÇÃO EXPERIMENTAL", "08 / SEGURANÇA E VIGILÂNCIA",
		"09 / NÚCLEO DA ENTIDADE", "10 / EXTRAÇÃO E ARQUIVO CONFIDENCIAL"
	]
	var palettes: Array[Color] = [
		Color(0.28, 0.34, 0.36), Color(0.18, 0.32, 0.36),
		Color(0.38, 0.22, 0.12), Color(0.34, 0.10, 0.09),
		Color(0.26, 0.25, 0.22), Color(0.12, 0.20, 0.30),
		Color(0.25, 0.06, 0.08), Color(0.16, 0.28, 0.18)
	]
	var previous_end_z := -29.7 # saída da Zona 02
	for i in range(zone_names.size()):
		var zone_number := i + 3
		var center_z := -42.2 - float(i) * 20.0
		var front_z := center_z + 6.25
		var back_z := center_z - 6.25
		# Corredor de ligação entre módulos, sem colisões no eixo de passagem.
		var corridor_center := (previous_end_z + front_z) * 0.5
		var corridor_length := absf(previous_end_z - front_z) + 0.35
		var corridor := Node3D.new()
		corridor.name = "Connector_%02d" % zone_number
		add_child(corridor)
		var floor_mat := _material(Color(0.055, 0.065, 0.072), 0.32, 0.16)
		var wall_mat := _material(Color(0.14, 0.16, 0.18), 0.78, 0.18)
		_box(corridor, "Floor", Vector3(4.4, 0.18, corridor_length), Vector3(0, -0.16, corridor_center), floor_mat)
		_box(corridor, "LeftWall", Vector3(0.18, 3.2, corridor_length), Vector3(-2.2, 1.45, corridor_center), wall_mat)
		_box(corridor, "RightWall", Vector3(0.18, 3.2, corridor_length), Vector3(2.2, 1.45, corridor_center), wall_mat)
		_box(corridor, "Ceiling", Vector3(4.4, 0.18, corridor_length), Vector3(0, 3.12, corridor_center), wall_mat)
		# Cada ligação entre zonas tem uma moldura de porta e folhas deslizantes
		# recolhidas lateralmente: a passagem fica transitável, mas a porta é visível.
		var door_mat := _material(Color(0.12, 0.17, 0.20), 0.42, 0.62)
		var door_trim := _material(Color(0.20, 0.48, 0.55), 0.38, 0.45)
		for end_z in [previous_end_z, front_z]:
			_box(corridor, "DoorFrameLeft_%0.2f" % end_z, Vector3(0.12, 2.85, 0.18), Vector3(-2.05, 1.35, end_z), door_trim)
			_box(corridor, "DoorFrameRight_%0.2f" % end_z, Vector3(0.12, 2.85, 0.18), Vector3(2.05, 1.35, end_z), door_trim)
			_box(corridor, "DoorFrameTop_%0.2f" % end_z, Vector3(4.1, 0.16, 0.18), Vector3(0, 2.78, end_z), door_trim)
			_box(corridor, "SlidingDoorLeafLeft_%0.2f" % end_z, Vector3(0.12, 2.45, 0.12), Vector3(-2.28, 1.25, end_z), door_mat, false)
			_box(corridor, "SlidingDoorLeafRight_%0.2f" % end_z, Vector3(0.12, 2.45, 0.12), Vector3(2.28, 1.25, end_z), door_mat, false)
			_box(corridor, "DoorStatusLight_%0.2f" % end_z, Vector3(0.24, 0.07, 0.06), Vector3(0, 2.92, end_z), door_trim, false)
		var zone := Node3D.new()
		zone.name = "Zone%02d" % zone_number
		add_child(zone)
		var tint: Color = palettes[i]
		var concrete := _material(Color(0.13, 0.15, 0.17))
		var floor_material := _material(Color(0.045, 0.052, 0.06), 0.3, 0.25)
		var trim := _material(tint, 0.48, 0.3)
		var metal := _material(Color(0.10, 0.13, 0.16), 0.4, 0.55)
		_box(zone, "Floor", Vector3(12.0, 0.3, 12.5), Vector3(0, -0.16, center_z), floor_material)
		_box(zone, "Ceiling", Vector3(12.0, 0.25, 12.5), Vector3(0, 3.6, center_z), concrete)
		if zone_number == 10:
			# A parede esquerda da Zona 10 tem uma abertura real para o corredor secreto.
			_box(zone, "LeftWallFront", Vector3(0.3, 3.6, 4.3), Vector3(-6.0, 1.65, center_z + 4.1), concrete)
			_box(zone, "LeftWallBack", Vector3(0.3, 3.6, 4.3), Vector3(-6.0, 1.65, center_z - 4.1), concrete)
			_box(zone, "LeftWallLintel", Vector3(0.3, 0.55, 3.9), Vector3(-6.0, 3.30, center_z), concrete)
		else:
			_box(zone, "LeftWall", Vector3(0.3, 3.6, 12.5), Vector3(-6.0, 1.65, center_z), concrete)
		# Duas entradas laterais alinhadas com as portas das salas auxiliares.
		# A versão anterior deixava a abertura principal ao centro, mas as portas
		# das salas estavam deslocadas para +/-3.125 m: as paredes bloqueavam o acesso.
		_box(zone, "RightWallSegmentFront", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, center_z + 5.475), concrete)
		_box(zone, "RightWallSegmentMiddle", Vector3(0.3, 3.6, 3.10), Vector3(6.0, 1.65, center_z), concrete)
		_box(zone, "RightWallSegmentBack", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, center_z - 5.475), concrete)
		# Vergas por cima das duas aberturas; a altura livre é 3.05 m.
		_box(zone, "RightWallLintelFront", Vector3(0.3, 0.55, 3.15), Vector3(6.0, 3.30, center_z + 3.125), concrete)
		_box(zone, "RightWallLintelBack", Vector3(0.3, 0.55, 3.15), Vector3(6.0, 3.30, center_z - 3.125), concrete)
		# Parede de entrada e de saída segmentadas: abertura central de 3 m.
		for wall_z in [front_z, back_z]:
			_box(zone, "WallLeft_%0.2f" % wall_z, Vector3(3.8, 3.6, 0.3), Vector3(-4.1, 1.65, wall_z), concrete)
			_box(zone, "WallRight_%0.2f" % wall_z, Vector3(3.8, 3.6, 0.3), Vector3(4.1, 1.65, wall_z), concrete)
			_box(zone, "Lintel_%0.2f" % wall_z, Vector3(4.4, 0.55, 0.3), Vector3(0, 3.30, wall_z), concrete)
		# Console lateral deixa o eixo central livre para circulação cooperativa.
		_box(zone, "ObjectiveConsole", Vector3(1.8, 1.0, 0.65), Vector3(-3.9, 0.5, center_z), trim)
		# Equipamento de trabalho visível em todas as zonas: bancadas, cadeiras,
		# armários e racks variam por função e mantêm livre o corredor central.
		_box(zone, "WorkBench", Vector3(2.2, 0.14, 0.75), Vector3(3.65, 0.92, center_z - 3.2), trim)
		for leg_x in [-0.92, 0.92]:
			for leg_z in [-0.27, 0.27]:
				_box(zone, "BenchLeg_%s_%s" % [str(leg_x), str(leg_z)], Vector3(0.10, 0.78, 0.10), Vector3(3.65 + leg_x, 0.39, center_z - 3.2 + leg_z), metal)
		_box(zone, "EquipmentCabinet", Vector3(0.8, 1.75, 0.65), Vector3(5.0, 0.875, center_z + 3.0), concrete)
		_box(zone, "EquipmentCabinetDoor", Vector3(0.04, 1.35, 0.48), Vector3(4.57, 0.95, center_z + 3.0), trim, false)
		_box(zone, "ChairSeat", Vector3(0.65, 0.12, 0.62), Vector3(3.65, 0.52, center_z - 2.15), metal)
		_box(zone, "ChairBack", Vector3(0.62, 0.65, 0.12), Vector3(3.65, 0.83, center_z - 1.86), metal)
		# Fechadura elétrica identificável junto à passagem da zona. A luz vermelha
		# comunica estado bloqueado; o painel é equipamento visual, não uma prova.
		var lock_mat := StandardMaterial3D.new()
		lock_mat.albedo_color = Color(0.18, 0.045, 0.04)
		lock_mat.emission_enabled = true
		lock_mat.emission = Color(0.75, 0.025, 0.015)
		lock_mat.emission_energy_multiplier = 1.2
		_box(zone, "ElectricLockPanel", Vector3(0.16, 0.42, 0.24), Vector3(1.72, 1.65, front_z + 0.45), metal)
		_box(zone, "ElectricLockLED", Vector3(0.055, 0.09, 0.06), Vector3(1.62, 1.68, front_z + 0.45), lock_mat, false)
		var sign := Label3D.new()
		sign.name = "ZoneTitle"
		sign.text = "ZONA %02d  /  %s" % [zone_number, zone_names[i].split(" / ", true, 1)[1]]
		sign.position = Vector3(0, 2.65, front_z + 0.22)
		sign.font_size = 24
		sign.modulate = tint.lightened(0.45)
		zone.add_child(sign)
		var lamp := OmniLight3D.new()
		lamp.name = "ZoneLamp"
		lamp.position = Vector3(0, 3.0, center_z)
		lamp.light_color = tint.lightened(0.2)
		lamp.light_energy = 0.8
		lamp.omni_range = 9.0
		lamp.shadow_enabled = false
		zone.add_child(lamp)
		# Duas faixas luminosas dão uma referência visual sem marcadores no mini-mapa.
		_box(zone, "TrimLightLeft", Vector3(0.06, 0.08, 9.5), Vector3(-5.78, 2.7, center_z), trim, false)
		_box(zone, "TrimLightRight", Vector3(0.06, 0.08, 9.5), Vector3(5.78, 2.7, center_z), trim, false)
		_build_zone_side_rooms(zone, zone_number, center_z, tint)
		_build_detailed_zone_furnishings(zone, zone_number, center_z, tint)
		# Sinalética de orientação no piso, visível ao entrar em cada módulo.
		var wayfinding_mat := StandardMaterial3D.new()
		wayfinding_mat.albedo_color = tint.lightened(0.35)
		wayfinding_mat.emission_enabled = true
		wayfinding_mat.emission = tint.lightened(0.25)
		wayfinding_mat.emission_energy_multiplier = 0.45
		_box(zone, "ZoneWayfindingStripe", Vector3(1.65, 0.018, 0.12), Vector3(0, 0.025, front_z + 1.05), wayfinding_mat, false)
		# Cada zona contém uma prova física, escondida à vista entre equipamento e mobiliário.
		# As posições variam; não usar etiquetas nem luzes que revelem a prova à distância.
		_add_experiment_clue(zone, zone_number, _evidence_position_for_zone(zone_number, center_z))
		# Duas provas suplementares completam as 12 provas exteriores.
		if zone_number == 9:
			_add_experiment_clue(zone, 11, Vector3(-4.45, 0.82, center_z - 3.45))
		elif zone_number == 10:
			_add_experiment_clue(zone, 12, Vector3(4.35, 0.82, center_z - 3.65))
		# Cinco provas avançadas: objetos sem marcador de localização, acessíveis apenas
		# depois de cruzar os registos necessários no dossiê.
		var special_by_zone := {2: 16, 4: 17, 6: 18, 8: 19, 10: 20}
		if special_by_zone.has(zone_number):
			var special_id: int = int(special_by_zone[zone_number])
			var special_pos := Vector3(-3.85, 0.72, center_z + (2.15 if zone_number % 2 == 0 else -2.25))
			_add_experiment_clue(zone, special_id, special_pos)
		previous_end_z = back_z

func _apply_cycle_layout() -> void:
	# Circuito fechado das Zonas 03-10. As salas são posicionadas nos vértices
	# e cada corredor liga as faces das salas, não os seus centros.
	var ring_center := Vector3(0.0, 0.0, -74.2)
	var ring_radius := 32.0
	var room_depth := 12.5
	var targets: Array[Vector3] = []
	var room_angles: Array[float] = []
	for i in range(8):
		var theta := float(i) * TAU / 8.0
		var target := ring_center + Vector3(sin(theta) * ring_radius, 0.0, cos(theta) * ring_radius)
		targets.append(target)
		# Orientar a sala pela direção da corda até à zona seguinte.
		var next_theta := float(i + 1) * TAU / 8.0
		var next_target := ring_center + Vector3(sin(next_theta) * ring_radius, 0.0, cos(next_theta) * ring_radius)
		var outgoing := next_target - target
		var angle := atan2(outgoing.x, outgoing.z)
		room_angles.append(angle)
		var zone := get_node_or_null("Zone%02d" % (i + 3)) as Node3D
		if zone:
			var old_center_z := -42.2 - float(i) * 20.0
			var basis := Basis(Vector3.UP, angle)
			zone.rotation = Vector3(0.0, angle, 0.0)
			zone.position = target - basis * Vector3(0.0, 0.0, old_center_z)
	# Reposicionar e dimensionar os corredores existentes entre as faces das salas.
	for connector_number in range(4, 11):
		var connector := get_node_or_null("Connector_%02d" % connector_number) as Node3D
		var prev_idx := connector_number - 4
		var next_idx := connector_number - 3
		if connector and prev_idx >= 0 and next_idx < targets.size():
			var a: Vector3 = targets[prev_idx]
			var b: Vector3 = targets[next_idx]
			var direction := b - a
			var unit := direction.normalized()
			var start_face := a + unit * (room_depth * 0.5)
			var end_face := b - unit * (room_depth * 0.5)
			var span := end_face - start_face
			var length := span.length() + 0.4
			var midpoint := (start_face + end_face) * 0.5
			var angle := atan2(unit.x, unit.z)
			var old_center_z := -52.2 - float(connector_number - 4) * 20.0
			var basis := Basis(Vector3.UP, angle)
			connector.rotation = Vector3(0.0, angle, 0.0)
			connector.position = midpoint - basis * Vector3(0.0, 0.0, old_center_z)
			var old_length := 7.35
			var scale_z := length / old_length
			for part_name in ["Floor", "LeftWall", "RightWall", "Ceiling"]:
				var part := connector.get_node_or_null(part_name) as Node3D
				if part:
					part.scale.z = scale_z
	# Fechar o circuito com um corredor dimensionado apenas entre as faces.
	var closure := Node3D.new()
	closure.name = "CycleClosure_10_to_03"
	add_child(closure)
	var a: Vector3 = targets[7]
	var b: Vector3 = targets[0]
	var direction := b - a
	var unit := direction.normalized()
	var start_face := a + unit * (room_depth * 0.5)
	var end_face := b - unit * (room_depth * 0.5)
	var span := end_face - start_face
	var length := span.length() + 0.4
	var angle := atan2(unit.x, unit.z)
	closure.position = (start_face + end_face) * 0.5
	closure.rotation = Vector3(0.0, angle, 0.0)
	var floor_mat := _material(Color(0.055, 0.065, 0.072), 0.32, 0.16)
	var wall_mat := _material(Color(0.14, 0.16, 0.18), 0.78, 0.18)
	_box(closure, "CycleFloor", Vector3(4.4, 0.18, length), Vector3(0, -0.16, 0), floor_mat)
	_box(closure, "CycleLeftWall", Vector3(0.18, 3.2, length), Vector3(-2.2, 1.45, 0), wall_mat)
	_box(closure, "CycleRightWall", Vector3(0.18, 3.2, length), Vector3(2.2, 1.45, 0), wall_mat)
	_box(closure, "CycleCeiling", Vector3(4.4, 0.18, length), Vector3(0, 3.12, 0), wall_mat)
	# A câmara secreta mantém-se ancorada à Zona 10.
	var chamber := get_node_or_null("SecretOriginalExperimentChamber") as Node3D
	var zone10 := get_node_or_null("Zone10") as Node3D
	if chamber and zone10:
		var angle10 := room_angles[7]
		var basis10 := Basis(Vector3.UP, angle10)
		var old_anchor := Vector3(0.0, 0.0, -182.2)
		chamber.rotation = Vector3(0.0, angle10, 0.0)
		chamber.position = targets[7] - basis10 * old_anchor

func _build_detailed_zone_furnishings(zone: Node3D, zone_number: int, center_z: float, tint: Color) -> void:
	# Mobiliário 3D adicional para as dez áreas principais. Os volumes grandes
	# têm colisão; pequenos detalhes são apenas visuais para não bloquear a passagem.
	var metal := _material(Color(0.075, 0.095, 0.11), 0.38, 0.62)
	var cabinet_mat := _material(Color(0.20, 0.23, 0.25), 0.72, 0.28)
	var surface_mat := _material(Color(0.24, 0.27, 0.28), 0.45, 0.35)
	var screen_mat := StandardMaterial3D.new()
	screen_mat.albedo_color = Color(0.025, 0.11, 0.13)
	screen_mat.emission_enabled = true
	screen_mat.emission = Color(0.02, 0.38, 0.48)
	screen_mat.emission_energy_multiplier = 1.3
	# Armários modulares com puxadores e pés visíveis junto à parede oeste.
	for i in range(3):
		var z := center_z - 3.4 + float(i) * 1.35
		_box(zone, "DetailLocker_%02d_%d" % [zone_number, i], Vector3(0.78, 1.72, 0.82), Vector3(-5.05, 0.86, z), cabinet_mat)
		_box(zone, "LockerDoor_%02d_%d" % [zone_number, i], Vector3(0.035, 1.43, 0.72), Vector3(-4.64, 0.92, z), surface_mat, false)
		_box(zone, "LockerHandle_%02d_%d" % [zone_number, i], Vector3(0.035, 0.22, 0.035), Vector3(-4.60, 0.95, z - 0.22), metal, false)
		_box(zone, "LockerVent_%02d_%d" % [zone_number, i], Vector3(0.018, 0.025, 0.32), Vector3(-4.595, 1.28, z), metal, false)
	# Estante de peças com prateleiras, caixas e recipientes identificáveis.
	_box(zone, "DetailedStorageFrame_%02d" % zone_number, Vector3(0.12, 1.95, 1.45), Vector3(4.85, 0.98, center_z + 1.25), metal)
	for shelf in range(4):
		var y := 0.30 + float(shelf) * 0.48
		_box(zone, "StorageShelf_%02d_%d" % [zone_number, shelf], Vector3(0.72, 0.07, 1.38), Vector3(4.82, y, center_z + 1.25), surface_mat, false)
		_box(zone, "StorageBin_%02d_%d" % [zone_number, shelf], Vector3(0.38, 0.28, 0.42), Vector3(4.78, y + 0.17, center_z + 1.05), _material(tint.darkened(0.35)), false)
	# Segunda bancada técnica, monitores inclinados simulados por ecrãs e teclado.
	_box(zone, "InstrumentBench_%02d" % zone_number, Vector3(2.15, 0.14, 0.78), Vector3(-3.55, 0.94, center_z + 3.15), surface_mat)
	for leg_x in [-0.88, 0.88]:
		_box(zone, "InstrumentBenchLeg_%02d_%s" % [zone_number, str(leg_x)], Vector3(0.10, 0.86, 0.10), Vector3(-3.55 + leg_x, 0.43, center_z + 3.15), metal)
	for monitor in range(2):
		var mx := -4.12 + float(monitor) * 1.08
		_box(zone, "MonitorHousing_%02d_%d" % [zone_number, monitor], Vector3(0.72, 0.48, 0.10), Vector3(mx, 1.28, center_z + 2.88), metal, false)
		_box(zone, "MonitorScreen_%02d_%d" % [zone_number, monitor], Vector3(0.62, 0.36, 0.025), Vector3(mx, 1.29, center_z + 2.82), screen_mat, false)
		_box(zone, "MonitorStand_%02d_%d" % [zone_number, monitor], Vector3(0.10, 0.20, 0.10), Vector3(mx, 1.07, center_z + 2.91), metal, false)
	_box(zone, "Keyboard_%02d" % zone_number, Vector3(0.48, 0.035, 0.17), Vector3(-3.55, 1.035, center_z + 3.38), metal, false)
	# Cadeira completa: assento, costas, quatro pernas e apoios laterais.
	var chair_pos := Vector3(-3.55, 0.0, center_z + 1.95)
	_box(zone, "DetailChairSeat_%02d" % zone_number, Vector3(0.58, 0.13, 0.56), chair_pos + Vector3(0, 0.52, 0), _material(tint.darkened(0.12)))
	_box(zone, "DetailChairBack_%02d" % zone_number, Vector3(0.56, 0.60, 0.12), chair_pos + Vector3(0, 0.86, -0.22), _material(tint.darkened(0.18)))
	for lx in [-0.22, 0.22]:
		for lz in [-0.20, 0.20]:
			_box(zone, "DetailChairLeg_%02d_%s_%s" % [zone_number, str(lx), str(lz)], Vector3(0.055, 0.48, 0.055), chair_pos + Vector3(lx, 0.24, lz), metal)
	# Função visual varia por zona: leitos, bateria, laboratório, arquivo ou contenção.
	match zone_number:
		1:
			_build_bed_prop(zone, "TriageBed", Vector3(1.8, 0.0, center_z - 2.4), surface_mat, metal)
			_box(zone, "PPEBench", Vector3(1.35, 0.82, 0.55), Vector3(1.2, 0.41, center_z + 3.3), cabinet_mat)
		2:
			_box(zone, "CommsRack", Vector3(0.65, 2.0, 1.0), Vector3(-4.9, 1.0, center_z + 2.4), metal)
			for i in range(4):
				_box(zone, "CommsRackSlot_%d" % i, Vector3(0.06, 0.06, 0.66), Vector3(-4.55, 0.48 + float(i) * 0.4, center_z + 2.4), screen_mat, false)
		3:
			for i in range(3):
				_box(zone, "LabSampleCanister_%d" % i, Vector3(0.22, 0.48, 0.22), Vector3(1.0 + float(i) * 0.45, 1.22, center_z - 3.25), screen_mat, false)
		4:
			for i in range(3):
				_box(zone, "PowerBattery_%d" % i, Vector3(0.62, 1.15, 0.72), Vector3(-4.85, 0.58, center_z + 2.5 - float(i) * 1.25), cabinet_mat)
				_box(zone, "BatteryStatus_%d" % i, Vector3(0.12, 0.08, 0.08), Vector3(-4.48, 1.0, center_z + 2.5 - float(i) * 1.25), screen_mat, false)
		5:
			_build_bed_prop(zone, "MedicalBed", Vector3(-1.8, 0.0, center_z + 2.6), surface_mat, metal)
		6:
			_box(zone, "ToolChest", Vector3(1.05, 0.62, 0.65), Vector3(-4.75, 0.31, center_z + 2.7), cabinet_mat)
			for i in range(5):
				_box(zone, "ToolSlot_%d" % i, Vector3(0.10, 0.20, 0.06), Vector3(-4.9 + float(i) * 0.18, 0.65, center_z + 2.34), _material(tint.darkened(0.12)), false)
		7:
			_box(zone, "ContainmentGlassFrame", Vector3(0.12, 2.1, 2.2), Vector3(-5.2, 1.05, center_z + 2.2), metal)
			_box(zone, "ContainmentGlass", Vector3(0.035, 1.8, 1.9), Vector3(-5.12, 1.12, center_z + 2.2), screen_mat, false)
		8:
			for i in range(3):
				_box(zone, "SecurityMonitor_%d" % i, Vector3(0.72, 0.48, 0.09), Vector3(-4.5 + float(i) * 0.95, 1.85, center_z + 3.0), metal, false)
				_box(zone, "SecurityScreen_%d" % i, Vector3(0.62, 0.36, 0.025), Vector3(-4.5 + float(i) * 0.95, 1.86, center_z + 2.94), screen_mat, false)
		9:
			_box(zone, "EntityContainmentPod", Vector3(1.35, 2.15, 1.35), Vector3(-4.75, 1.08, center_z + 2.2), metal)
			_box(zone, "PodWindow", Vector3(0.04, 1.25, 0.75), Vector3(-4.04, 1.35, center_z + 2.2), screen_mat, false)
		10:
			for i in range(4):
				_box(zone, "ArchiveDrawer_%d" % i, Vector3(0.82, 0.26, 0.62), Vector3(-4.9, 0.35 + float(i) * 0.32, center_z + 2.3), cabinet_mat)
	# Placa funcional de identificação, fixada na parede sem bloquear circulação.
	var wall_label := Label3D.new()
	wall_label.name = "FurnishingZoneLabel"
	wall_label.text = ["TRIAGEM / EQUIPAMENTO", "COMUNICAÇÕES / MAPAS", "LABORATÓRIO / AMOSTRAS", "ENERGIA / BATERIAS", "CUIDADOS MÉDICOS", "MANUTENÇÃO / PEÇAS", "CONTENÇÃO / OBSERVAÇÃO", "SEGURANÇA / MONITORIZAÇÃO", "NÚCLEO / CONTENÇÃO", "ARQUIVO / EXTRAÇÃO"][clampi(zone_number - 1, 0, 9)]
	wall_label.position = Vector3(-5.72, 2.35, center_z - 4.65)
	wall_label.font_size = 12
	wall_label.modulate = tint.lightened(0.55)
	zone.add_child(wall_label)

func _build_bed_prop(parent: Node3D, prefix: String, pos: Vector3, surface_mat: Material, metal: Material) -> void:
	# Cama/maca com colchão, armação, pernas e cabeceira claramente legíveis.
	_box(parent, prefix + "Frame", Vector3(1.9, 0.13, 0.82), pos + Vector3(0, 0.55, 0), metal)
	_box(parent, prefix + "Mattress", Vector3(1.78, 0.18, 0.72), pos + Vector3(0, 0.70, 0), surface_mat)
	_box(parent, prefix + "Headboard", Vector3(0.08, 0.50, 0.82), pos + Vector3(-0.92, 0.78, 0), metal)
	for x in [-0.78, 0.78]:
		for z in [-0.29, 0.29]:
			_box(parent, prefix + "Leg_%s_%s" % [str(x), str(z)], Vector3(0.07, 0.52, 0.07), pos + Vector3(x, 0.26, z), metal)

func _build_detailed_auxiliary_furnishings(room: Node3D, zone_number: int, room_index: int, room_center_z: float, tint: Color) -> void:
	# Cada uma das 20 salas anexas recebe objetos próprios além da mesa/cadeira/rack-base.
	var metal := _material(Color(0.065, 0.085, 0.10), 0.4, 0.55)
	var cabinet := _material(Color(0.19, 0.22, 0.24), 0.75, 0.25)
	var pale := _material(Color(0.58, 0.66, 0.68), 0.62, 0.12)
	var screen := StandardMaterial3D.new()
	screen.albedo_color = Color(0.02, 0.12, 0.15)
	screen.emission_enabled = true
	screen.emission = Color(0.02, 0.36, 0.46)
	screen.emission_energy_multiplier = 1.25
	var room_tag := "Z%02dR%d" % [zone_number, room_index]
	# Armário com portas, puxadores e ventilação; fica encostado à parede exterior.
	_box(room, room_tag + "TallLocker", Vector3(0.72, 1.78, 0.72), Vector3(11.25, 0.89, room_center_z - 1.65), cabinet)
	_box(room, room_tag + "LockerFront", Vector3(0.035, 1.48, 0.62), Vector3(10.875, 0.96, room_center_z - 1.65), pale, false)
	for i in range(4):
		_box(room, room_tag + "LockerVent%d" % i, Vector3(0.018, 0.025, 0.28), Vector3(10.85, 1.22 + float(i) * 0.09, room_center_z - 1.65), metal, false)
	_box(room, room_tag + "LockerHandle", Vector3(0.035, 0.20, 0.035), Vector3(10.84, 0.96, room_center_z - 1.45), metal, false)
	# Recipientes, papéis e ferramentas na mesa existente, sem cobrir toda a superfície.
	_box(room, room_tag + "DeskTray", Vector3(0.42, 0.035, 0.28), Vector3(8.0, 0.97, room_center_z + 0.78), metal, false)
	_box(room, room_tag + "DocumentStack", Vector3(0.30, 0.035, 0.22), Vector3(8.52, 0.98, room_center_z + 0.78), pale, false)
	_box(room, room_tag + "DeskLampBase", Vector3(0.16, 0.035, 0.16), Vector3(8.78, 0.98, room_center_z + 0.62), metal, false)
	_box(room, room_tag + "DeskLampArm", Vector3(0.035, 0.28, 0.035), Vector3(8.78, 1.13, room_center_z + 0.62), metal, false)
	# Ecrã, suporte e teclado nas salas de trabalho; nos restantes casos, quadro informativo.
	if zone_number in [2, 3, 4, 8, 9] or (zone_number == 10 and room_index == 0):
		_box(room, room_tag + "TerminalHousing", Vector3(0.62, 0.43, 0.10), Vector3(8.2, 1.28, room_center_z + 1.02), metal, false)
		_box(room, room_tag + "TerminalScreen", Vector3(0.53, 0.33, 0.025), Vector3(8.2, 1.29, room_center_z + 0.96), screen, false)
		_box(room, room_tag + "TerminalStand", Vector3(0.10, 0.18, 0.10), Vector3(8.2, 1.08, room_center_z + 1.03), metal, false)
		_box(room, room_tag + "TerminalKeyboard", Vector3(0.38, 0.035, 0.13), Vector3(8.2, 1.00, room_center_z + 1.22), metal, false)
	else:
		_box(room, room_tag + "WallNoticeBoard", Vector3(0.055, 0.85, 1.25), Vector3(11.78, 1.95, room_center_z + 0.15), cabinet, false)
		for i in range(3):
			_box(room, room_tag + "NoticePaper%d" % i, Vector3(0.02, 0.22, 0.28), Vector3(11.745, 2.12 - float(i) * 0.24, room_center_z - 0.20 + float(i) * 0.32), pale, false)
	# Cadeira de escritório completa com pés/rodízios; colocada junto à mesa.
	_box(room, room_tag + "OfficeChairSeat", Vector3(0.48, 0.13, 0.48), Vector3(8.25, 0.49, room_center_z - 0.05), _material(tint.darkened(0.15)))
	_box(room, room_tag + "OfficeChairBack", Vector3(0.46, 0.55, 0.10), Vector3(8.25, 0.80, room_center_z - 0.27), _material(tint.darkened(0.2)))
	_box(room, room_tag + "OfficeChairStem", Vector3(0.08, 0.30, 0.08), Vector3(8.25, 0.27, room_center_z - 0.05), metal, false)
	for x in [-0.19, 0.19]:
		for z in [-0.19, 0.19]:
			_box(room, room_tag + "OfficeChairFoot_%s_%s" % [str(x), str(z)], Vector3(0.24, 0.045, 0.06), Vector3(8.25 + x, 0.08, room_center_z - 0.05 + z), metal, false)
	# Conteúdo de prateleiras: caixas e recipientes colocados em alturas distintas.
	for shelf in range(3):
		var y := 0.42 + float(shelf) * 0.45
		_box(room, room_tag + "RackShelf%d" % shelf, Vector3(0.42, 0.06, 0.95), Vector3(11.35, y, room_center_z + 1.0), metal, false)
		_box(room, room_tag + "RackBox%d" % shelf, Vector3(0.28, 0.24, 0.32), Vector3(11.32, y + 0.15, room_center_z + 0.88), _material(tint.darkened(0.25)), false)
	# Prop funcional visual específico, por função da sala.
	if zone_number in [1, 5] and room_index == 1:
		_build_bed_prop(room, room_tag + "MedicalCot", Vector3(9.55, 0.0, room_center_z + 0.05), pale, metal)
	elif zone_number == 3:
		for i in range(3):
			_box(room, room_tag + "SampleVial%d" % i, Vector3(0.12, 0.28, 0.12), Vector3(8.8 + float(i) * 0.28, 1.08, room_center_z + 0.78), screen, false)
		_box(room, room_tag + "MicroscopeBase", Vector3(0.35, 0.07, 0.25), Vector3(9.0, 1.03, room_center_z + 0.25), metal, false)
		_box(room, room_tag + "MicroscopeColumn", Vector3(0.07, 0.32, 0.07), Vector3(9.0, 1.22, room_center_z + 0.25), metal, false)
	elif zone_number == 4:
		for i in range(3):
			_box(room, room_tag + "BatteryPack%d" % i, Vector3(0.34, 0.58, 0.42), Vector3(9.0 + float(i) * 0.48, 0.29, room_center_z + 0.12), cabinet)
	elif zone_number == 6:
		for i in range(4):
			_box(room, room_tag + "Tool%d" % i, Vector3(0.08, 0.30, 0.08), Vector3(8.8 + float(i) * 0.22, 1.10, room_center_z + 0.75), metal, false)
	elif zone_number == 7 or zone_number == 9:
		_box(room, room_tag + "ReinforcedWindowFrame", Vector3(0.10, 1.45, 1.65), Vector3(11.76, 1.65, room_center_z + 0.1), metal, false)
		_box(room, room_tag + "ReinforcedWindow", Vector3(0.035, 1.22, 1.42), Vector3(11.70, 1.68, room_center_z + 0.1), screen, false)
	elif zone_number == 10:
		for i in range(3):
			_box(room, room_tag + "ArchiveFileBox%d" % i, Vector3(0.28, 0.18, 0.36), Vector3(10.85, 0.35 + float(i) * 0.42, room_center_z + 0.8), _material(tint.lightened(0.15)), false)

func _evidence_position_for_zone(clue_id: int, center_z: float) -> Vector3:
	# Objetos colocados em superfícies ou parcialmente resguardados por equipamento.
	# Todos permanecem alcançáveis e dentro da zona correspondente.
	match clue_id:
		1: return Vector3(-5.05, 1.78, center_z - 2.05) # topo do armário, atrás do alinhamento frontal
		2: return Vector3(3.65, 1.02, center_z - 3.38) # canto da bancada
		3: return Vector3(4.72, 1.78, center_z + 3.0) # bordo do armário
		4: return Vector3(3.05, 0.98, center_z - 3.15) # bancada, parcialmente tapado pelo equipamento
		5: return Vector3(-5.28, 1.30, center_z - 0.85) # recuado junto aos cacifos
		6: return Vector3(4.35, 0.78, center_z + 2.65) # prateleira inferior
		7: return Vector3(-4.78, 1.78, center_z + 1.85) # topo de armário lateral
		8: return Vector3(3.35, 1.00, center_z - 2.85) # junto a instrumentos da bancada
		9: return Vector3(4.85, 0.76, center_z + 2.20) # perto de caixas de manutenção
		_: return Vector3(-4.95, 1.42, center_z + 2.65) # junto às estantes, fora do eixo central

func _add_interaction_test_label(target: Node3D, label_text: String, offset: Vector3 = Vector3(0, 1.45, 0)) -> void:
	# Etiqueta temporária de teste: identifica apenas objetos que têm interação real.
	var world_label := Label3D.new()
	world_label.name = "InteractionTestLabel"
	world_label.text = label_text
	world_label.position = offset
	world_label.font_size = 22
	world_label.pixel_size = 0.004
	world_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	world_label.modulate = Color(0.55, 0.96, 1.0, 1.0)
	world_label.outline_size = 6
	world_label.outline_modulate = Color(0.015, 0.025, 0.035, 0.95)
	world_label.no_depth_test = true
	target.add_child(world_label)

func _add_experiment_clue(parent: Node3D, clue_id: int, clue_position: Vector3) -> void:
	# As provas são objetos físicos distintos, não cubos/ícones genéricos.
	var clue := StaticBody3D.new()
	clue.name = "ExperimentClue_%02d" % clue_id
	clue.add_to_group("collectible_evidence")
	clue.set_script(load("res://scripts/experiment_clue.gd"))
	clue.clue_id = clue_id
	clue.position = clue_position
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "EvidenceMesh"
	var mesh: Mesh
	var evidence_material: StandardMaterial3D
	match clue_id % 5:
		0:
			# Pequeno frasco de amostra criogénica.
			var vial := CylinderMesh.new()
			vial.top_radius = 0.075
			vial.bottom_radius = 0.09
			vial.height = 0.34
			mesh = vial
			evidence_material = _material(Color(0.28, 0.43, 0.44, 0.92), 0.32, 0.05)
		1:
			# Gravador de áudio portátil, alongado e com aspeto metálico.
			var recorder := BoxMesh.new()
			recorder.size = Vector3(0.29, 0.10, 0.16)
			mesh = recorder
			evidence_material = _material(Color(0.085, 0.10, 0.11), 0.42, 0.35)
		2:
			# Fotografia/documento recuperado, fino e retangular.
			var document := BoxMesh.new()
			document.size = Vector3(0.28, 0.015, 0.38)
			mesh = document
			evidence_material = _material(Color(0.47, 0.45, 0.39), 0.94, 0.0)
		3:
			# Módulo de dados com cantos arredondados simulados por corpo compacto.
			var data_module := CylinderMesh.new()
			data_module.top_radius = 0.105
			data_module.bottom_radius = 0.105
			data_module.height = 0.12
			data_module.radial_segments = 8
			mesh = data_module
			evidence_material = _material(Color(0.10, 0.23, 0.25), 0.38, 0.3)
		_:
			# Peça de equipamento danificada, com forma oval em vez de quadrada.
			var fragment := SphereMesh.new()
			fragment.radius = 0.14
			fragment.height = 0.22
			mesh = fragment
			evidence_material = _material(Color(0.28, 0.20, 0.14), 0.82, 0.08)
	mesh_node.mesh = mesh
	mesh_node.material_override = evidence_material
	if clue_id % 5 == 1:
		mesh_node.rotation.y = deg_to_rad(-18.0)
	elif clue_id % 5 == 2:
		mesh_node.rotation.x = deg_to_rad(-8.0)
	clue.add_child(mesh_node)
	# Pequenos detalhes visuais tornam os objetos reconhecíveis à distância.
	if clue_id % 5 == 1:
		var display := MeshInstance3D.new()
		display.name = "RecorderDisplay"
		var display_mesh := BoxMesh.new()
		display_mesh.size = Vector3(0.10, 0.012, 0.045)
		display.mesh = display_mesh
		display.position = Vector3(0.0, 0.057, -0.015)
		display.material_override = _material(Color(0.12, 0.95, 0.78), 0.25, 0.0)
		mesh_node.add_child(display)
	elif clue_id % 5 == 2:
		var marking := MeshInstance3D.new()
		marking.name = "DocumentMarking"
		var marking_mesh := BoxMesh.new()
		marking_mesh.size = Vector3(0.19, 0.004, 0.012)
		marking.mesh = marking_mesh
		marking.position = Vector3(0.0, 0.010, -0.08)
		marking.material_override = _material(Color(0.16, 0.24, 0.28), 0.9, 0.0)
		mesh_node.add_child(marking)
	elif clue_id % 5 == 0:
		# Tampa e faixa de identificação no frasco, sem texto flutuante.
		var vial_cap := MeshInstance3D.new()
		vial_cap.name = "VialCap"
		var cap_mesh := CylinderMesh.new()
		cap_mesh.top_radius = 0.082
		cap_mesh.bottom_radius = 0.082
		cap_mesh.height = 0.045
		vial_cap.mesh = cap_mesh
		vial_cap.position = Vector3(0.0, 0.19, 0.0)
		vial_cap.material_override = _material(Color(0.16, 0.18, 0.19), 0.48, 0.32)
		mesh_node.add_child(vial_cap)
		var vial_band := MeshInstance3D.new()
		vial_band.name = "VialIdentificationBand"
		var band_mesh := CylinderMesh.new()
		band_mesh.top_radius = 0.092
		band_mesh.bottom_radius = 0.092
		band_mesh.height = 0.035
		vial_band.mesh = band_mesh
		vial_band.position = Vector3(0.0, -0.025, 0.0)
		vial_band.material_override = _material(Color(0.62, 0.66, 0.61), 0.82, 0.0)
		mesh_node.add_child(vial_band)
	elif clue_id % 5 == 3:
		# Conector e pinos no módulo de dados.
		var connector := MeshInstance3D.new()
		connector.name = "DataModuleConnector"
		var connector_mesh := BoxMesh.new()
		connector_mesh.size = Vector3(0.09, 0.035, 0.045)
		connector.mesh = connector_mesh
		connector.position = Vector3(0.0, -0.065, 0.0)
		connector.material_override = _material(Color(0.36, 0.39, 0.39), 0.3, 0.72)
		mesh_node.add_child(connector)
	# Sem brilho nem etiqueta flutuante: a prova mistura-se com o cenário.
	# Um pequeno detalhe mate ajuda a reconhecê-la apenas de perto.
	var evidence_mark := MeshInstance3D.new()
	evidence_mark.name = "EvidenceWearMark"
	var mark_mesh := BoxMesh.new()
	mark_mesh.size = Vector3(0.045, 0.008, 0.025)
	evidence_mark.mesh = mark_mesh
	evidence_mark.position = Vector3(0.015, 0.055, -0.018)
	evidence_mark.material_override = _material(Color(0.20, 0.25, 0.25), 0.9, 0.0)
	mesh_node.add_child(evidence_mark)
	_add_interaction_test_label(clue, ("VESTÍGIO  ·  EXAMINAR" if clue_id >= 16 else "PISTA %02d  ·  INTERAGIR" % clue_id), Vector3(0, 0.48, 0))
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	# Área generosa de interação, mantendo o objeto visível e fácil de selecionar.
	shape.size = Vector3(1.7, 1.8, 1.7)
	shape_node.shape = shape
	clue.add_child(shape_node)
	parent.add_child(clue)

func request_experiment_clue(clue_id: int, player: Node = null) -> void:
	# As provas 16–20 exigem cruzamento prévio de informação; usam validação própria.
	if clue_id >= 16 and clue_id <= 20:
		request_special_investigation_evidence(clue_id, player)
		return
	# O servidor valida a proximidade; o cliente não pode recolher provas à distância.
	if _is_solo_session():
		_server_collect_experiment_clue(clue_id, 1)
	elif multiplayer.is_server():
		_server_collect_experiment_clue(clue_id, multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_collect_experiment_clue", clue_id)

@rpc("any_peer", "call_remote", "reliable")
func server_collect_experiment_clue(clue_id: int) -> void:
	if not multiplayer.is_server():
		return
	_server_collect_experiment_clue(clue_id, multiplayer.get_remote_sender_id())

func _server_collect_experiment_clue(clue_id: int, peer_id: int) -> void:
	if clue_id < 1 or clue_id > 12 or experiment_clues_found.has(clue_id):
		return
	var actor: Node3D = get_node_or_null("Player") as Node3D if peer_id == 1 else remote_players.get(peer_id) as Node3D
	var target: Node3D = null
	for evidence in get_tree().get_nodes_in_group("collectible_evidence"):
		if is_instance_valid(evidence) and int(evidence.get("clue_id")) == clue_id:
			target = evidence as Node3D
			break
	if actor == null or target == null or not is_instance_valid(actor) or not is_instance_valid(target):
		return
	if actor.global_position.distance_to(target.global_position) > 3.2:
		if peer_id == 1:
			_set_extraction_feedback("APROXIMA-TE DA PROVA PARA A RECOLHER")
		return
	experiment_clues_found[clue_id] = true
	collect_experiment_clue_local(clue_id)
	if not _is_solo_session():
		rpc("client_sync_experiment_clue", clue_id)
		rpc("client_sync_secret_progress", experiment_clues_found.keys(), evidence_synthesis_complete, secret_experiment_open)

@rpc("authority", "call_remote", "reliable")
func client_sync_experiment_clue(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 12:
		return
	experiment_clues_found[clue_id] = true
	collect_experiment_clue_local(clue_id)

func request_special_investigation_evidence(evidence_id: int, _player: Node = null) -> void:
	if evidence_id < 16 or evidence_id > 20 or special_investigation_found.has(evidence_id):
		return
	if _is_solo_session():
		_server_collect_special_investigation_evidence(evidence_id, 1)
	elif multiplayer.is_server():
		_server_collect_special_investigation_evidence(evidence_id, multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_collect_special_investigation_evidence", evidence_id)

@rpc("any_peer", "call_remote", "reliable")
func server_collect_special_investigation_evidence(evidence_id: int) -> void:
	if multiplayer.is_server():
		_server_collect_special_investigation_evidence(evidence_id, multiplayer.get_remote_sender_id())

func _server_collect_special_investigation_evidence(evidence_id: int, peer_id: int) -> void:
	if evidence_id < 16 or evidence_id > 20 or special_investigation_found.has(evidence_id):
		return
	var prerequisites := {16: [1, 3, 5], 17: [4, 6, 9], 18: [5, 6, 10], 19: [7, 10, 12], 20: [2, 8, 11, 12]}
	var required_comparison := {16: "3-5", 17: "4-9", 18: "6-10", 19: "7-10", 20: "2-12"}
	for required_id in prerequisites[evidence_id]:
		if not experiment_clues_found.has(required_id):
			if peer_id == 1:
				var prerequisite_labels := PackedStringArray()
				for prerequisite_id in prerequisites[evidence_id]:
					prerequisite_labels.append(str(prerequisite_id))
				_set_extraction_feedback("AINDA NÃO: recolhe e examina primeiro as provas %s; não sigas apenas os marcadores." % ", ".join(prerequisite_labels))
			return
	if not evidence_comparisons_solved.has(required_comparison[evidence_id]):
		if peer_id == 1:
			_set_extraction_feedback("ENIGMA POR RESOLVER: abre o DOSSIÊ / COMPARAR PROVAS e relaciona as provas %s. A conclusão ainda não foi demonstrada." % required_comparison[evidence_id].replace("-", " e "))
		return
	var actor: Node3D = get_node_or_null("Player") as Node3D if peer_id == 1 else remote_players.get(peer_id) as Node3D
	var target: Node3D = null
	for evidence in get_tree().get_nodes_in_group("collectible_evidence"):
		if is_instance_valid(evidence) and int(evidence.get("clue_id")) == evidence_id:
			target = evidence as Node3D
			break
	if actor == null or target == null or actor.global_position.distance_to(target.global_position) > 3.2:
		return
	special_investigation_found[evidence_id] = true
	target.queue_free()
	var details := {
		16: "PROVA ESPECIAL 16/20 — Energia e reator. A queda de energia foi seletiva: o circuito de contenção perdeu alimentação antes dos restantes sistemas. A sequência sugere intervenção deliberada, mas não identifica o autor.",
		17: "PROVA ESPECIAL 17/20 — Sistema de vida. O registo de ar e água diverge do relatório oficial durante a mesma janela temporal. A divergência confirma uma falha de registo; não prova, por si só, sabotagem.",
		18: "PROVA ESPECIAL 18/20 — Pesquisa geológica. O pó mineral recolhido na zona técnica não coincide com a amostra de referência. Compara a origem das amostras antes de concluir como chegou ali.",
		19: "PROVA ESPECIAL 19/20 — Hangar e drones. Um drone regressou com a memória de navegação parcialmente apagada, mas o último ponto guardado fica junto a uma área ausente da planta pública.",
		20: "PROVA ESPECIAL 20/20 — Observatório e antenas. O último pacote de telemetria foi retransmitido por uma antena auxiliar. O registo permite reconstruir a rota do sinal, não a identidade de quem o enviou."
	}
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = details[evidence_id] + "\n\nPROVAS ESPECIAIS: %d/5. Relaciona esta informação com as provas anteriores." % special_investigation_found.size()
	if not _is_solo_session():
		rpc("client_sync_special_investigation_evidence", evidence_id, special_investigation_found.size())

@rpc("authority", "call_remote", "reliable")
func client_sync_special_investigation_evidence(evidence_id: int, total_found: int) -> void:
	if evidence_id < 16 or evidence_id > 20:
		return
	special_investigation_found[evidence_id] = true
	for evidence in get_tree().get_nodes_in_group("collectible_evidence"):
		if is_instance_valid(evidence) and int(evidence.get("clue_id")) == evidence_id:
			evidence.queue_free()
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = "PROVAS ESPECIAIS: %d/5" % total_found

func collect_experiment_clue_local(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 12:
		return
	# A prova desaparece após recolha para não induzir o jogador a repetir a ação.
	for item in get_tree().get_nodes_in_group("collectible_evidence"):
		if is_instance_valid(item) and int(item.get("clue_id")) == clue_id:
			item.queue_free()
			break
	var clue_names := {
		1: "Registo de admissão",
		2: "Consentimento falsificado",
		3: "Relatório de manutenção",
		4: "Protocolo de incubação",
		5: "Falha de energia planeada",
		6: "Relatório de contenção",
		7: "Diário de laboratório",
		8: "Ordem de segurança",
		9: "Sequência de ativação",
		10: "Gravação da experiência",
		11: "Registo de manutenção secundário",
		12: "Planta técnica rasurada"
	}
	var combination_fragments := {
		2: "CHAVE DE LEITURA — NOTA DO ANALISTA: a fechadura pede quatro campos, nesta ordem: (1) alertas com confirmação operacional; (2) ciclos rejeitados antes da primeira leitura aceite; (3) identificador do circuito isolado primeiro; (4) número do ciclo da primeira leitura estável. Datas, turnos e IDs administrativos não pertencem à sequência.",
		4: "FOLHA DE INCUBAÇÃO — excerto recuperado: CICLO 01 / REJEITADO; CICLO 02 / REJEITADO; CICLO 03 / REJEITADO; CICLO 04 / LEITURA ESTÁVEL. As rejeições são estados do ensaio, não números de amostra.",
		7: "DIÁRIO DE ALARMES — resumo exportado: nove linhas visíveis. Duas estão marcadas TESTE e não têm confirmação operacional. As restantes linhas têm estado CONFIRMADO. O contador de exportação não é o total de alarmes válidos.",
		9: "CONTROLADOR DE ATIVAÇÃO — sequência registada: o circuito 1 foi isolado antes dos restantes. A primeira leitura estável está associada ao ciclo 04. A hora de registo e o número do operador são metadados, não parte do código."
	}
	var found := experiment_clues_found.size()
	var prompt := get_node_or_null("HUD/Prompt") as Label
	var trail_hints := {
		1: "INDÍCIO: o registo menciona mapas revistos depois de uma chamada interna. Procura sinais de comunicação fora do horário normal.",
		2: "INDÍCIO: a autorização foi validada com uma amostra que nunca entrou no inventário. Compara os registos científicos e os códigos de entrada.",
		3: "INDÍCIO: a falha não foi causada pelo frio. O relatório descreve uma interrupção seletiva e menciona circuitos isolados manualmente.",
		4: "INDÍCIO: alguém ocultou um efeito secundário nos registos clínicos. Procura diferenças entre observações médicas e relatórios oficiais.",
		5: "INDÍCIO: uma ferramenta foi requisitada, mas nunca devolvida. Segue o rasto da manutenção e observa o que parece ter sido mexido recentemente.",
		6: "INDÍCIO: o relatório de contenção descreve marcas no lado interior da barreira. Investiga a zona onde se registam as entradas e saídas.",
		7: "INDÍCIO: o diário contradiz a gravação de vigilância por alguns minutos. Compara horários e procura o ponto cego do sistema.",
		8: "INDÍCIO: a ordem de segurança foi assinada depois do encerramento da estação. Verifica quem tinha acesso e que equipamento foi ativado.",
		9: "INDÍCIO: a sequência de ativação foi dividida entre dois registos. Reúne os horários e procura a instalação que não aparece nas plantas públicas.",
		10: "SEQUÊNCIA COMPLETA: os registos apontam para uma área omitida das plantas. Compara as paredes, cablagens e documentação da estação; não há marcador de localização."
	}
	if prompt:
		var clue_message := "PROVA %02d/12: %s — fragmento registado. A próxima localização não foi marcada." % [found, clue_names[clue_id]]
		if combination_fragments.has(clue_id):
			clue_message += " " + combination_fragments[clue_id]
		if trail_hints.has(clue_id):
			clue_message += "\n\n" + trail_hints[clue_id]
		prompt.text = clue_message
	_refresh_evidence_dossier()
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: %02d / 12" % found
	if found == 3 and prompt:
		prompt.text += "\n\nPISTA ADICIONAL: o relatório de manutenção menciona uma parede falsa a oeste da Zona 10."
	elif found == 6 and prompt:
		prompt.text += "\n\nPISTA ADICIONAL: o relatório de contenção refere uma consola escondida junto à passagem selada, atrás da parede oeste da Zona 10."
	elif found == 12:
		_reveal_secret_access()
		if prompt:
			prompt.text += "\n\nACESSO DESCOBERTO: procura a passagem oculta e usa as pistas recolhidas para obter o código."

func _reveal_secret_access() -> void:
	# Só o anfitrião/servidor altera o estado partilhado.
	if not multiplayer.is_server():
		return
	if secret_synthesis_console:
		secret_synthesis_console.visible = true
		for child in secret_synthesis_console.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if not _is_solo_session():
		rpc("client_reveal_secret_console")

@rpc("authority", "call_remote", "reliable")
func client_reveal_secret_console() -> void:
	if secret_synthesis_console:
		secret_synthesis_console.visible = true
		for child in secret_synthesis_console.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: 12 / 12 · CONSOLA REVELADA"

func _unlock_secret_door() -> void:
	# Só a combinação correta revela e ativa a porta oculta.
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = true
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)

func interact_evidence_synthesis_console(_player: Node = null) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 12:
		if prompt:
			prompt.text = "CONSOLA BLOQUEADA — reúne as 12 provas exteriores e deduz os quatro algarismos a partir dos documentos."
		_play_sfx("radio_static.wav")
		return
	if secret_combination_panel:
		secret_combination_panel.visible = true
		if secret_combination_input:
			secret_combination_input.clear()
			secret_combination_input.grab_focus()
	if prompt:
		prompt.text = "FECHADURA VANTHIS — introduz a combinação deduzida a partir das provas."
	if not multiplayer.is_server():
		return

func _submit_secret_combination() -> void:
	if not secret_combination_input:
		return
	var entered_code := secret_combination_input.text.strip_edges()
	if not entered_code.is_valid_int() or entered_code.length() != 4:
		var prompt := get_node_or_null("HUD/Prompt") as Label
		if prompt:
			prompt.text = "CÓDIGO INVÁLIDO — são necessários quatro algarismos."
		return
	if multiplayer.is_server():
		_server_validate_secret_combination(entered_code)
	else:
		rpc_id(1, "server_validate_secret_combination", entered_code)

@rpc("any_peer", "call_remote", "reliable")
func server_validate_secret_combination(entered_code: String) -> void:
	if multiplayer.is_server():
		_server_validate_secret_combination(entered_code)

func _server_validate_secret_combination(entered_code: String) -> void:
	# Impede validação remota do código: a consola tem de estar acessível fisicamente.
	var peer_id := multiplayer.get_remote_sender_id()
	if peer_id <= 0:
		peer_id = multiplayer.get_unique_id()
	var actor: Node3D = get_node_or_null("Player") as Node3D if peer_id == 1 else remote_players.get(peer_id) as Node3D
	if actor == null or secret_synthesis_console == null or not is_instance_valid(actor) or not is_instance_valid(secret_synthesis_console) or actor.global_position.distance_to(secret_synthesis_console.global_position) > 4.0:
		return
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 12:
		if prompt:
			prompt.text = "ACESSO NEGADO — faltam provas exteriores para descobrir a combinação (%d/12)." % experiment_clues_found.size()
		return
	for clue_id in range(1, 13):
		if not experiment_clues_found.has(clue_id):
			if prompt:
				prompt.text = "SEQUÊNCIA INCOMPLETA — falta a prova exterior %02d." % clue_id
			return
	if entered_code != SECRET_COMBINATION:
		if prompt:
			prompt.text = "COMBINAÇÃO INCORRETA — cruza a cronologia dos registos e exclui alarmes de teste e números administrativos."
		_play_sfx("radio_static.wav")
		if not _is_solo_session():
			rpc("client_secret_combination_result", false)
		return
	evidence_synthesis_complete = true
	_unlock_secret_door()
	evidence_journal = [
		"CHAVE DE LEITURA: quatro campos por ordem — alertas confirmados; ciclos rejeitados; circuito isolado primeiro; ciclo da primeira leitura estável.",
		"DIÁRIO DE ALARMES: nove linhas exportadas; duas marcadas TESTE devem ser excluídas. Conta apenas as linhas com confirmação operacional.",
		"FOLHA DE INCUBAÇÃO: ciclos 01, 02 e 03 estão marcados REJEITADO; ciclo 04 está marcado LEITURA ESTÁVEL.",
		"CONTROLADOR: o circuito 1 foi isolado primeiro. Não confundas o identificador do circuito com o número do operador.",
		"SÍNTESE: cruza os quatro campos segundo a chave de leitura. Datas, horas, turnos e identificadores administrativos são distratores."
	]
	if prompt:
		prompt.text = "COMBINAÇÃO CORRETA. A fechadura VANTHIS foi desbloqueada. Interage com a porta secreta."
	if secret_clue_status:
		secret_clue_status.text = "PROVAS: 12/12 · COMBINAÇÃO VALIDADA"
	if secret_combination_panel:
		secret_combination_panel.visible = false
	_play_sfx("door_open.wav")
	if not _is_solo_session():
		rpc("client_sync_evidence_synthesis")
		rpc("client_secret_combination_result", true)
		rpc("client_unlock_secret_door")

@rpc("authority", "call_remote", "reliable")
func client_secret_combination_result(correct: bool) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if correct:
		if prompt:
			prompt.text = "COMBINAÇÃO CORRETA — fechadura desbloqueada. Interage com a porta secreta."
		if secret_combination_panel:
			secret_combination_panel.visible = false
		_unlock_secret_door()
	else:
		if prompt:
			prompt.text = "COMBINAÇÃO INCORRETA — verifica a ordem dos eventos e distingue registos válidos de testes."

@rpc("authority", "call_remote", "reliable")
func client_unlock_secret_door() -> void:
	_unlock_secret_door()

@rpc("authority", "call_remote", "reliable")
func client_sync_evidence_synthesis() -> void:
	evidence_synthesis_complete = true
	evidence_journal = [
		"CHAVE DE LEITURA: quatro campos por ordem — alertas confirmados; ciclos rejeitados; circuito isolado primeiro; ciclo da primeira leitura estável.",
		"DIÁRIO DE ALARMES: nove linhas exportadas; duas marcadas TESTE devem ser excluídas. Conta apenas as linhas com confirmação operacional.",
		"FOLHA DE INCUBAÇÃO: ciclos 01, 02 e 03 estão marcados REJEITADO; ciclo 04 está marcado LEITURA ESTÁVEL.",
		"CONTROLADOR: o circuito 1 foi isolado primeiro. Não confundas o identificador do circuito com o número do operador.",
		"SÍNTESE: cruza os quatro campos segundo a chave de leitura. Datas, horas, turnos e identificadores administrativos são distratores."
	]
	if secret_clue_status:
		secret_clue_status.text = "PROVAS: 12/12 · SÍNTESE VANTHIS CONCLUÍDA"

func interact_secret_experiment_door(_player: Node = null) -> void:
	if not multiplayer.is_server():
		rpc_id(1, "server_try_open_secret_door")
		return
	_server_try_open_secret_door()

@rpc("any_peer", "call_remote", "reliable")
func server_try_open_secret_door() -> void:
	if multiplayer.is_server():
		_server_try_open_secret_door()

func _server_try_open_secret_door() -> void:
	if secret_experiment_open:
		return
	# A porta só responde a uma interação feita fisicamente junto dela.
	var peer_id := multiplayer.get_remote_sender_id()
	if peer_id <= 0:
		peer_id = multiplayer.get_unique_id()
	var actor: Node3D = get_node_or_null("Player") as Node3D if peer_id == 1 else remote_players.get(peer_id) as Node3D
	if actor == null or secret_experiment_door == null or not is_instance_valid(actor) or not is_instance_valid(secret_experiment_door) or actor.global_position.distance_to(secret_experiment_door.global_position) > 4.0:
		return
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 12:
		var missing := 12 - experiment_clues_found.size()
		if prompt:
			prompt.text = "ACESSO NEGADO — faltam %d provas da experiência (%d/12)." % [missing, experiment_clues_found.size()]
		_play_sfx("radio_static.wav")
		return
	if not evidence_synthesis_complete:
		if prompt:
			prompt.text = "ACESSO NEGADO — tens de descobrir e introduzir a combinação correta na consola VANTHIS."
		_play_sfx("radio_static.wav")
		return
	# A sequência completa das dez provas é validada antes de libertar a porta.
	for clue_id in range(1, 13):
		if not experiment_clues_found.has(clue_id):
			if prompt:
				prompt.text = "SEQUÊNCIA INCOMPLETA — falta o fragmento %02d." % clue_id
			return
	secret_experiment_open = true
	rpc("client_open_secret_door")
	if secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if prompt:
		prompt.text = "ACESSO CONCEDIDO — ARQUIVO VANTHIS: EXPERIÊNCIA ORIGINAL. A porta foi desbloqueada."
	_play_sfx("door_open.wav")

@rpc("authority", "call_remote", "reliable")
func client_open_secret_door() -> void:
	secret_experiment_open = true
	if secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)

func _build_secret_experiment_area() -> void:
	# A câmara fica para lá da parede esquerda da Zona 10, fora da rota normal.
	var chamber := Node3D.new()
	chamber.name = "SecretOriginalExperimentChamber"
	add_child(chamber)
	var concrete := _material(Color(0.10, 0.12, 0.14), 0.45, 0.5)
	var floor_mat := _material(Color(0.035, 0.045, 0.052), 0.3, 0.25)
	var glass := _material(Color(0.10, 0.32, 0.38, 0.42), 0.15, 0.2)
	# Zona 10 está centrada em z=-182.2. A entrada abre na parede x=-6.
	var center_z := -182.2
	_box(chamber, "SecretFloor", Vector3(14.0, 0.25, 10.0), Vector3(-13.0, -0.16, center_z), floor_mat)
	_box(chamber, "SecretCeiling", Vector3(14.0, 0.25, 10.0), Vector3(-13.0, 3.6, center_z), concrete)
	_box(chamber, "SecretOuterWall", Vector3(0.25, 3.6, 10.0), Vector3(-20.0, 1.65, center_z), concrete)
	# Duas entradas independentes para o complexo: acesso principal e saída de serviço.
	# As paredes frontal/traseira são segmentadas para deixar uma abertura transitável em cada extremo.
	_box(chamber, "SecretFrontWallLeft", Vector3(5.0, 3.6, 0.25), Vector3(-17.5, 1.65, center_z + 5.0), concrete)
	_box(chamber, "SecretFrontWallRight", Vector3(5.0, 3.6, 0.25), Vector3(-8.5, 1.65, center_z + 5.0), concrete)
	_box(chamber, "SecretFrontLintel", Vector3(4.0, 0.55, 0.25), Vector3(-13.0, 3.30, center_z + 5.0), concrete)
	_box(chamber, "SecretBackWallLeft", Vector3(5.0, 3.6, 0.25), Vector3(-17.5, 1.65, center_z - 5.0), concrete)
	_box(chamber, "SecretBackWallRight", Vector3(5.0, 3.6, 0.25), Vector3(-8.5, 1.65, center_z - 5.0), concrete)
	_box(chamber, "SecretBackLintel", Vector3(4.0, 0.55, 0.25), Vector3(-13.0, 3.30, center_z - 5.0), concrete)
	# Corredor cíclico em anel retangular: quatro passagens ligadas em circuito em torno da câmara central.
	var loop_floor := _material(Color(0.055, 0.075, 0.085), 0.35, 0.4)
	# As quatro secções sobrepõem-se nos cantos e chegam às duas aberturas,
	# evitando descontinuidades no percurso visual do anel.
	_box(chamber, "CycleLoopNorthFloor", Vector3(10.0, 0.12, 2.6), Vector3(-13.0, 0.02, center_z + 3.7), loop_floor)
	_box(chamber, "CycleLoopSouthFloor", Vector3(10.0, 0.12, 2.6), Vector3(-13.0, 0.02, center_z - 3.7), loop_floor)
	_box(chamber, "CycleLoopWestFloor", Vector3(1.25, 0.12, 7.4), Vector3(-17.35, 0.02, center_z), loop_floor)
	_box(chamber, "CycleLoopEastFloor", Vector3(1.25, 0.12, 7.4), Vector3(-8.65, 0.02, center_z), loop_floor)
	var loop_light := StandardMaterial3D.new()
	loop_light.albedo_color = Color(0.03, 0.28, 0.32)
	loop_light.emission_enabled = true
	loop_light.emission = Color(0.02, 0.48, 0.58)
	loop_light.emission_energy_multiplier = 0.75
	for loop_i in range(8):
		_box(chamber, "CycleGuideNorth_%02d" % loop_i, Vector3(0.72, 0.025, 0.045), Vector3(-17.2 + float(loop_i) * 1.2, 0.10, center_z + 3.35), loop_light, false)
		_box(chamber, "CycleGuideSouth_%02d" % loop_i, Vector3(0.72, 0.025, 0.045), Vector3(-17.2 + float(loop_i) * 1.2, 0.10, center_z - 3.35), loop_light, false)
	var entrance_sign_a := Label3D.new()
	entrance_sign_a.text = "ENTRADA A · CICLO DE INVESTIGAÇÃO"
	entrance_sign_a.position = Vector3(-13.0, 2.7, center_z + 4.5)
	entrance_sign_a.font_size = 16
	entrance_sign_a.modulate = Color(0.35, 0.88, 0.92)
	chamber.add_child(entrance_sign_a)
	var entrance_sign_b := Label3D.new()
	entrance_sign_b.text = "ENTRADA B · ACESSO DE SERVIÇO"
	entrance_sign_b.position = Vector3(-13.0, 2.7, center_z - 4.5)
	entrance_sign_b.font_size = 16
	entrance_sign_b.modulate = Color(0.88, 0.58, 0.32)
	chamber.add_child(entrance_sign_b)
	# Corredor entre a porta e a câmara, com paredes e chão próprios.
	_box(chamber, "SecretAccessFloor", Vector3(3.0, 0.18, 4.0), Vector3(-7.5, -0.16, center_z), floor_mat)
	_box(chamber, "SecretAccessWallFront", Vector3(4.0, 3.2, 0.18), Vector3(-8.0, 1.45, center_z + 1.5), concrete)
	_box(chamber, "SecretAccessWallBack", Vector3(4.0, 3.2, 0.18), Vector3(-8.0, 1.45, center_z - 1.5), concrete)
	# Consola de síntese fica no corredor exterior: os jogadores têm de montar as provas antes de abrir a porta.
	secret_synthesis_console = StaticBody3D.new()
	secret_synthesis_console.name = "EvidenceSynthesisConsole"
	secret_synthesis_console.set_script(load("res://scripts/evidence_synthesis_console.gd"))
	secret_synthesis_console.position = Vector3(-4.7, 0.65, center_z)
	var console_mesh := MeshInstance3D.new()
	var console_box := BoxMesh.new()
	console_box.size = Vector3(0.75, 1.2, 0.65)
	console_mesh.mesh = console_box
	console_mesh.material_override = _material(Color(0.08, 0.34, 0.37), 0.35, 0.4)
	secret_synthesis_console.add_child(console_mesh)
	var console_shape_node := CollisionShape3D.new()
	var console_shape := BoxShape3D.new()
	console_shape.size = Vector3(1.2, 1.8, 1.2)
	console_shape_node.shape = console_shape
	secret_synthesis_console.add_child(console_shape_node)
	var console_label := Label3D.new()
	console_label.text = "SÍNTESE DE PROVAS"
	console_label.position = Vector3(0, 1.0, -0.36)
	console_label.font_size = 18
	console_label.modulate = Color(0.3, 0.9, 0.88)
	secret_synthesis_console.add_child(console_label)
	_add_interaction_test_label(secret_synthesis_console, "EQUIPAMENTO INTERATIVO · SÍNTESE", Vector3(0, 1.55, 0))
	chamber.add_child(secret_synthesis_console)

	secret_synthesis_console.visible = false
	for child in secret_synthesis_console.get_children():
		if child is CollisionShape3D:
			child.disabled = true

	secret_experiment_door = StaticBody3D.new()
	secret_experiment_door.name = "SecretExperimentDoor"
	secret_experiment_door.set_script(load("res://scripts/secret_experiment_door.gd"))
	secret_experiment_door.position = Vector3(-6.0, 1.4, center_z)
	var door_mesh := MeshInstance3D.new()
	var door_box := BoxMesh.new()
	door_box.size = Vector3(0.22, 2.8, 3.0)
	door_mesh.mesh = door_box
	door_mesh.material_override = _material(Color(0.16, 0.08, 0.07), 0.4, 0.8)
	secret_experiment_door.add_child(door_mesh)
	var door_shape_node := CollisionShape3D.new()
	var door_shape := BoxShape3D.new()
	door_shape.size = Vector3(0.25, 2.8, 3.0)
	door_shape_node.shape = door_shape
	secret_experiment_door.add_child(door_shape_node)
	var door_label := Label3D.new()
	door_label.text = "VANTHIS // ACESSO SELADO"
	door_label.position = Vector3(0.18, 0.35, 0)
	door_label.rotation.y = deg_to_rad(90)
	door_label.font_size = 22
	door_label.modulate = Color(0.9, 0.24, 0.15)
	secret_experiment_door.add_child(door_label)
	_add_interaction_test_label(secret_experiment_door, "PORTA INTERATIVA", Vector3(0, 2.0, 0))
	chamber.add_child(secret_experiment_door)
	# Porta bloqueada por defeito; só é revelada após validação da combinação.
	secret_experiment_door.visible = false
	for child in secret_experiment_door.get_children():
		if child is CollisionShape3D:
			child.disabled = true
	# A cápsula de contenção central sugere a experiência sem revelar a criatura no exterior.
	_box(chamber, "ExperimentPlatform", Vector3(3.2, 0.3, 2.2), Vector3(-13.0, 0.15, center_z), concrete)
	_box(chamber, "OriginalContainmentGlass", Vector3(2.5, 2.4, 0.12), Vector3(-13.0, 1.45, center_z), glass, false)
	_box(chamber, "ExperimentConsole", Vector3(1.5, 1.1, 0.6), Vector3(-16.0, 0.55, center_z + 2.7), _material(Color(0.12, 0.30, 0.34)))
	var title := Label3D.new()
	title.text = "VANTHIS — ARQUIVO DA EXPERIÊNCIA ORIGINAL"
	title.position = Vector3(-13.0, 3.0, center_z + 4.3)
	title.font_size = 24
	title.modulate = Color(0.4, 0.86, 0.88)
	chamber.add_child(title)
	var evidence := Label3D.new()
	evidence.text = "SUJEITO: CLASSIFICAÇÃO OMITIDA\nPROTOCOLO: AUTORIZAÇÃO FRAUDULENTA\nESTADO: CONTENÇÃO COMPROMETIDA\nREGISTO FINAL: NÃO ABRIR NOVAMENTE"
	evidence.position = Vector3(-16.0, 1.65, center_z + 2.35)
	evidence.font_size = 18
	evidence.modulate = Color(0.86, 0.82, 0.72)
	evidence.rotation.y = deg_to_rad(18)
	chamber.add_child(evidence)
	# Três provas exclusivas da sala secreta. São objetos interativos, não apenas texto decorativo.
	_add_secret_archive_evidence(chamber, 1, Vector3(-10.0, 0.45, center_z - 3.4), "REGISTO ORIGINAL", "Arquivo de experiência: a autorização original não inclui a alteração do protocolo de contenção.", Color(0.18, 0.42, 0.48))
	_add_secret_archive_evidence(chamber, 2, Vector3(-14.0, 0.45, center_z + 3.35), "RELATÓRIO DE CONTENÇÃO", "Inspeção final: o circuito de segurança foi desativado antes da perda de contenção. O registo não identifica quem ordenou a alteração.", Color(0.48, 0.30, 0.18))
	_add_secret_archive_evidence(chamber, 3, Vector3(-18.0, 0.45, center_z - 0.2), "ARQUIVO DE ENCERRAMENTO", "Última entrada: a experiência foi declarada encerrada, mas a lista de evacuação não confirma a saída do sujeito. O destino permanece por determinar.", Color(0.35, 0.28, 0.48))
	# Terminal final: só conclui a missão depois de todas as tarefas obrigatórias.
	extraction_terminal = StaticBody3D.new()
	extraction_terminal.name = "MissionExtractionTerminal"
	extraction_terminal.set_script(load("res://scripts/mission_extraction_terminal.gd"))
	extraction_terminal.position = Vector3(-17.0, 0.65, center_z - 2.7)
	var extraction_mesh := MeshInstance3D.new()
	var extraction_box := BoxMesh.new()
	extraction_box.size = Vector3(0.85, 1.25, 0.7)
	extraction_mesh.mesh = extraction_box
	extraction_mesh.material_override = _material(Color(0.08, 0.27, 0.20), 0.3, 0.45)
	extraction_terminal.add_child(extraction_mesh)
	var extraction_shape_node := CollisionShape3D.new()
	var extraction_shape := BoxShape3D.new()
	extraction_shape.size = Vector3(1.15, 1.8, 1.1)
	extraction_shape_node.shape = extraction_shape
	extraction_terminal.add_child(extraction_shape_node)
	var extraction_label := Label3D.new()
	extraction_label.text = "TRANSMISSÃO / EXTRAÇÃO"
	extraction_label.position = Vector3(0, 1.0, -0.38)
	extraction_label.font_size = 16
	extraction_label.modulate = Color(0.35, 0.95, 0.62)
	extraction_terminal.add_child(extraction_label)
	_add_interaction_test_label(extraction_terminal, "TERMINAL INTERATIVO · EXTRAÇÃO", Vector3(0, 1.65, 0))
	chamber.add_child(extraction_terminal)
	secret_clue_status = Label.new()
	secret_clue_status.name = "SecretClueStatus"
	secret_clue_status.text = "PROVAS EXTERIORES: 00 / 12"
	secret_clue_status.position = Vector2(18, 68)
	secret_clue_status.add_theme_font_size_override("font_size", 14)
	secret_clue_status.add_theme_color_override("font_color", Color(0.2, 0.78, 0.84))
	# HUD é criado depois; a etiqueta é adicionada quando o HUD existir.
	call_deferred("_attach_secret_clue_status")

func _add_secret_archive_evidence(parent: Node3D, evidence_id: int, pos: Vector3, title_text: String, detail_text: String, tint: Color) -> void:
	var item := StaticBody3D.new()
	item.name = "SecretArchiveEvidence_%02d" % evidence_id
	item.set_script(load("res://scripts/secret_archive_evidence.gd"))
	item.evidence_id = evidence_id
	item.position = pos
	item.set_meta("evidence_title", title_text)
	item.set_meta("evidence_detail", detail_text)
	var mesh_node := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.62, 0.12, 0.42)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(tint, 0.38, 0.3)
	item.add_child(mesh_node)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.8, 0.6, 0.7)
	shape_node.shape = shape
	shape_node.position.y = 0.12
	item.add_child(shape_node)
	var label := Label3D.new()
	label.text = title_text + "\nINTERAGIR PARA EXAMINAR"
	label.position = Vector3(0, 0.38, 0)
	label.font_size = 14
	label.modulate = Color(0.8, 0.95, 0.96)
	item.add_child(label)
	_add_interaction_test_label(item, "PROVA CONFIDENCIAL", Vector3(0, 0.65, 0))
	parent.add_child(item)

func request_secret_archive_evidence(evidence_id: int, _player: Node = null) -> void:
	if evidence_id < 1 or evidence_id > 3 or secret_archive_evidence_found.has(evidence_id):
		return
	if not _is_solo_session() and not multiplayer.is_server():
		rpc_id(1, "server_collect_secret_archive_evidence", evidence_id)
		return
	var peer_id := multiplayer.get_unique_id() if _is_solo_session() else multiplayer.get_remote_sender_id()
	if peer_id <= 0:
		peer_id = 1
	_server_collect_secret_archive_evidence(evidence_id, peer_id)

@rpc("any_peer", "call_remote", "reliable")
func server_collect_secret_archive_evidence(evidence_id: int) -> void:
	if multiplayer.is_server():
		_server_collect_secret_archive_evidence(evidence_id, multiplayer.get_remote_sender_id())

func _server_collect_secret_archive_evidence(evidence_id: int, peer_id: int) -> void:
	if evidence_id < 1 or evidence_id > 3 or secret_archive_evidence_found.has(evidence_id) or not secret_experiment_open:
		return
	var actor: Node3D = get_node_or_null("Player") as Node3D if peer_id == 1 else remote_players.get(peer_id) as Node3D
	var target := get_node_or_null("SecretOriginalExperimentChamber/SecretArchiveEvidence_%02d" % evidence_id) as Node3D
	if actor == null or target == null or actor.global_position.distance_to(target.global_position) > 3.2:
		return
	secret_archive_evidence_found[evidence_id] = true
	var title_text := str(target.get_meta("evidence_title", "Prova confidencial"))
	var detail_text := str(target.get_meta("evidence_detail", "Registo recuperado."))
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = "PROVA INTERIOR %d/3 — %s\n%s" % [secret_archive_evidence_found.size(), title_text, detail_text]
	target.queue_free()
	if secret_archive_evidence_found.size() >= 3:
		if prompt:
			prompt.text += "\nARQUIVO INTERIOR COMPLETO — podes solicitar a extração."
	if not _is_solo_session():
		rpc("client_secret_archive_evidence_collected", evidence_id, secret_archive_evidence_found.size())

@rpc("authority", "call_remote", "reliable")
func client_secret_archive_evidence_collected(evidence_id: int, total_found: int) -> void:
	secret_archive_evidence_found[evidence_id] = true
	var target := get_node_or_null("SecretOriginalExperimentChamber/SecretArchiveEvidence_%02d" % evidence_id)
	if target:
		target.queue_free()
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = "PROVAS DA SALA SECRETA: %d/3" % total_found

func interact_mission_extraction(_player: Node = null) -> void:
	if mission_completed or extraction_phase != "INACTIVE":
		return
	if _is_solo_session():
		_server_start_extraction(1)
	elif multiplayer.is_server():
		_server_start_extraction(multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_request_extraction")

@rpc("any_peer", "call_remote", "reliable")
func server_request_extraction() -> void:
	if not multiplayer.is_server():
		return
	_server_start_extraction(multiplayer.get_remote_sender_id())

func _server_start_extraction(peer_id: int) -> void:
	if mission_completed or extraction_phase != "INACTIVE":
		return
	var actor: Node3D = get_node_or_null("Player") as Node3D if peer_id == 1 else remote_players.get(peer_id) as Node3D
	if eliminated_peers.has(peer_id):
		if peer_id == 1:
			_set_extraction_feedback("EXTRAÇÃO INDISPONÍVEL — FOSTE ELIMINADO; A EQUIPA TEM DE CONTINUAR.")
		return
	if actor == null or extraction_terminal == null or not is_instance_valid(actor):
		return
	if actor.global_position.distance_to(extraction_terminal.global_position) > 4.5:
		if peer_id == 1:
			_set_extraction_feedback("APROXIMA-TE DO TERMINAL DE EXTRAÇÃO")
		return
	var missing: Array[String] = []
	if int(switch_owners.get("A", 0)) == 0: missing.append("ativar o Relé A")
	if int(switch_owners.get("B", 0)) == 0: missing.append("ativar o Relé B")
	if not coop_solved: missing.append("restabelecer a energia dos relés")
	if experiment_clues_found.size() < 12: missing.append("recolher as 12 provas exteriores (%d/12)" % experiment_clues_found.size())
	if not evidence_synthesis_complete: missing.append("validar a combinação VANTHIS")
	if not secret_experiment_open: missing.append("abrir o arquivo confidencial")
	if secret_archive_evidence_found.size() < 3: missing.append("examinar as 3 provas da sala secreta (%d/3)" % secret_archive_evidence_found.size())
	if special_investigation_found.size() < 5: missing.append("resolver e recolher as 5 provas especiais (%d/5)" % special_investigation_found.size())
	if not missing.is_empty():
		_set_extraction_feedback("EXTRAÇÃO BLOQUEADA — falta: " + "; ".join(missing) + ".")
		return
	extraction_phase = "COUNTDOWN"
	extraction_countdown = EXTRACTION_SURVIVAL_SECONDS
	# A criatura continua ativa durante a espera; não termina nem desaparece automaticamente.
	entity_active = true
	entity_state_time = 0.0
	_set_extraction_feedback("PEDIDO DE EXTRAÇÃO ENVIADO — SOBREVIVE DURANTE 35 SEGUNDOS")
	_update_extraction_ui()
	if not _is_solo_session():
		rpc("client_extraction_state", extraction_phase, extraction_countdown)

func _update_extraction_sequence(delta: float) -> void:
	if extraction_phase == "INACTIVE" or extraction_phase == "COMPLETE" or mission_completed:
		return
	if extraction_phase == "COUNTDOWN":
		extraction_countdown = maxf(0.0, extraction_countdown - delta)
		_update_extraction_ui()
		var second_left := int(ceil(extraction_countdown))
		if second_left != extraction_last_broadcast_second and second_left % 5 == 0 and extraction_countdown > 0.0:
			extraction_last_broadcast_second = second_left
			if not _is_solo_session():
				rpc("client_extraction_state", extraction_phase, extraction_countdown)
		if extraction_countdown <= 0.0:
			extraction_phase = "LANDING"
			_update_landing_zone_visuals(true)
			_set_extraction_feedback("RESGATE À VISTA — REÚNE OS SOBREVIVENTES NO PONTO DE EXTRAÇÃO")
			_update_extraction_ui()
			if not _is_solo_session():
				rpc("client_extraction_state", extraction_phase, 0.0)
	elif extraction_phase == "LANDING":
		# A equipa só conclui o resgate quando todos os sobreviventes ativos
		# alcançam a zona. Um único jogador não pode terminar a missão pelos outros.
		if _all_surviving_players_reached_landing_zone():
			_complete_extraction()

func _all_surviving_players_reached_landing_zone() -> bool:
	if extraction_landing_marker == null:
		return false
	var active_survivors := 0
	var host_player := get_node_or_null("Player") as Node3D
	if host_player != null and not eliminated_peers.has(1):
		active_survivors += 1
		if not _actor_reached_landing_zone(host_player):
			return false
	for raw_peer_id in remote_players.keys():
		var peer_id := int(raw_peer_id)
		if eliminated_peers.has(peer_id):
			continue
		var actor := remote_players.get(raw_peer_id) as Node3D
		if actor == null or not is_instance_valid(actor):
			continue
		active_survivors += 1
		if not _actor_reached_landing_zone(actor):
			return false
	# Never award a victory if every participant has been eliminated or no player exists.
	return active_survivors > 0

func _actor_reached_landing_zone(actor: Node3D) -> bool:
	if actor == null or not is_instance_valid(actor) or extraction_landing_marker == null:
		return false
	return actor.global_position.distance_to(extraction_landing_marker.global_position) <= EXTRACTION_LANDING_RADIUS

@rpc("authority", "call_remote", "reliable")
func client_extraction_state(phase: String, seconds_left: float) -> void:
	if mission_completed:
		return
	extraction_phase = phase
	extraction_countdown = seconds_left
	_update_landing_zone_visuals(phase == "LANDING")
	_update_extraction_ui()

func _update_landing_zone_visuals(active: bool) -> void:
	if extraction_landing_marker == null:
		return
	var ring := extraction_landing_marker.get_node_or_null("LandingZoneRing") as MeshInstance3D
	var light := extraction_landing_marker.get_node_or_null("LandingZoneLight") as OmniLight3D
	var label := extraction_landing_marker.get_node_or_null("LandingZoneLabel") as Label3D
	if ring: ring.visible = active
	if light: light.light_energy = 2.0 if active else 0.0
	if label: label.visible = active
	if active and exterior_beacon:
		exterior_beacon.light_color = Color(0.18, 0.95, 0.65)
		exterior_beacon.light_energy = 2.0

func _update_extraction_ui() -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	var message := ""
	match extraction_phase:
		"COUNTDOWN": message = "EXTRAÇÃO PEDIDA — SOBREVIVE: %02d s" % int(ceil(extraction_countdown))
		"LANDING": message = "RESGATE À VISTA — REÚNE OS SOBREVIVENTES NO FAROL VERDE"
		"COMPLETE": message = "EXTRAÇÃO CONFIRMADA"
	if prompt and not message.is_empty():
		prompt.text = message

func _complete_extraction() -> void:
	# A conclusão da missão é sempre decidida pelo anfitrião/servidor, nunca pelo cliente.
	if not _is_solo_session() and not multiplayer.is_server():
		return
	if mission_completed:
		return
	mission_completed = true
	extraction_phase = "COMPLETE"
	_update_extraction_ui()
	_show_mission_ending()
	if not _is_solo_session() and multiplayer.is_server():
		rpc("client_mission_completed")

@rpc("authority", "call_remote", "reliable")
func client_mission_completed() -> void:
	mission_completed = true
	extraction_phase = "COMPLETE"
	_update_landing_zone_visuals(false)
	_show_mission_ending()

func _server_try_complete_mission(peer_id: int) -> void:
	# Compatibilidade com versões antigas: interação no terminal inicia o procedimento,
	# não concede vitória instantânea.
	_server_start_extraction(peer_id)

func _set_extraction_feedback(message: String) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = message

func _show_mission_ending() -> void:
	if mission_ending_layer and is_instance_valid(mission_ending_layer):
		mission_ending_layer.visible = true
		return
	mission_ending_layer = CanvasLayer.new()
	mission_ending_layer.name = "MissionEndingLayer"
	mission_ending_layer.layer = 30
	add_child(mission_ending_layer)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.025, 0.03, 0.94)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mission_ending_layer.add_child(shade)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mission_ending_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(320, 280)
	center.add_child(panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 14)
	panel.add_child(content)
	var title := Label.new()
	title.text = "EXTRAÇÃO CONFIRMADA"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 27)
	title.add_theme_color_override("font_color", Color(0.45, 0.95, 0.68))
	content.add_child(title)
	var summary := Label.new()
	summary.text = "ESTAÇÃO VÉSPERA — OPERAÇÃO FINAL\n\n✓ Relés A e B ativos\n✓ 10 provas recuperadas\n✓ Evidências VANTHIS validadas\n✓ Arquivo confidencial aberto\n✓ Terminal de extração ativado\n\nO sinal de socorro foi aceite. A equipa alcançou o ponto exterior e os registos foram transmitidos.\n\nO que a VANTHIS fez com a experiência continua por revelar…"
	summary.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(summary)
	var close_button := Button.new()
	close_button.text = "CONTINUAR A EXPLORAR"
	close_button.pressed.connect(func(): mission_ending_layer.visible = false)
	content.add_child(close_button)
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = "EXTRAÇÃO CONFIRMADA — registos transmitidos."
	_play_sfx("door_open.wav")

func _attach_secret_clue_status() -> void:
	var hud := get_node_or_null("HUD")
	if hud and secret_clue_status and not secret_clue_status.is_inside_tree():
		hud.add_child(secret_clue_status)

func _build_initial_zone_wings() -> void:
	# Zonas 01 e 02 também recebem duas salas anexas, para manter a mesma escala.
	_build_zone_side_rooms(self, 1, -8.0, Color(0.18, 0.28, 0.34))
	_build_zone_side_rooms(self, 2, -23.45, Color(0.20, 0.32, 0.38))
	_build_detailed_zone_furnishings(self, 1, -2.0, Color(0.18, 0.28, 0.34))
	var investigation_zone := get_node_or_null("InvestigationChamber02") as Node3D
	if investigation_zone != null:
		_build_detailed_zone_furnishings(investigation_zone, 2, -23.45, Color(0.20, 0.32, 0.38))

func _build_zone_side_rooms(parent: Node3D, zone_number: int, center_z: float, tint: Color) -> void:
	# Salas laterais distintas por zona: cada zona tem dois espaços auxiliares
	# com finalidade, mobiliário, sinalética e iluminação próprios.
	var concrete := _material(Color(0.12, 0.14, 0.16))
	var floor_material := _material(Color(0.038, 0.046, 0.052), 0.28, 0.22)
	var trim := _material(tint, 0.5, 0.3)
	var metal := _material(Color(0.10, 0.13, 0.16), 0.4, 0.55)
	var room_catalog := [
		[["VESTIÁRIO E DESCONTAMINAÇÃO", "ARMÁRIO DE PROTEÇÃO"], ["POSTO DE TRIAGEM", "MACA DE EMERGÊNCIA"]],
		[["CENTRO DE COMUNICAÇÕES", "RÁDIO DE LONGO ALCANCE"], ["SALA DE MAPAS", "MAPA TÁTICO DA ESTAÇÃO"]],
		[["CÂMARA DE AMOSTRAS", "ARMÁRIO CRIOGÉNICO"], ["SALA DE ANÁLISE", "MESA DE MICROSCÓPIO"]],
		[["CONTROLO DE GERADORES", "PAINEL ELÉTRICO"], ["BANCO DE BATERIAS", "RACK DE ACUMULADORES"]],
		[["TRATAMENTO DE FERIMENTOS", "MACA CLÍNICA"], ["FARMÁCIA DE EMERGÊNCIA", "ARMÁRIO MÉDICO"]],
		[["OFICINA DE FERRAMENTAS", "BANCADA DE REPARAÇÃO"], ["ARMAZÉM DE PEÇAS", "PRATELEIRAS METÁLICAS"]],
		[["SALA DE OBSERVAÇÃO", "VIDRO DE CONTENÇÃO"], ["ANTECÂMARA", "PORTA DE PRESSURIZAÇÃO"]],
		[["MONITORIZAÇÃO", "CONSOLES DE VIGILÂNCIA"], ["EQUIPAMENTO DE EMERGÊNCIA", "ARMÁRIO DE PROTEÇÃO"]],
		[["OBSERVAÇÃO DA ENTIDADE", "JANELA REFORÇADA"], ["CONTROLO DO NÚCLEO", "CONSOLA DE CONTROLO"]],
		[["ARQUIVO CONFIDENCIAL", "ESTANTES DE DOSSIÊS VANTHIS"], ["PREPARAÇÃO DE EXTRAÇÃO", "CONTENTORES DE SOBREVIVÊNCIA"]]
	]
	var wing := Node3D.new()
	wing.name = "Zone%02dSideRooms" % zone_number
	parent.add_child(wing)
	var zone_rooms: Array = room_catalog[clampi(zone_number - 1, 0, room_catalog.size() - 1)]
	for room_index in range(2):
		var room_center_z := center_z + (3.125 if room_index == 0 else -3.125)
		var room_title: String = zone_rooms[room_index][0]
		var prop_title: String = zone_rooms[room_index][1]
		var room := Node3D.new()
		room.name = "Zone%02d_%s" % [zone_number, "AuxA" if room_index == 0 else "AuxB"]
		wing.add_child(room)
		_box(room, "Floor", Vector3(6.0, 0.3, 6.25), Vector3(9.0, -0.16, room_center_z), floor_material)
		_box(room, "Ceiling", Vector3(6.0, 0.25, 6.25), Vector3(9.0, 3.6, room_center_z), concrete)
		_box(room, "OuterWall", Vector3(0.3, 3.6, 6.25), Vector3(12.0, 1.65, room_center_z), concrete)
		_box(room, "NorthWall", Vector3(6.0, 3.6, 0.3), Vector3(9.0, 1.65, center_z + 6.25), concrete)
		_box(room, "SouthWall", Vector3(6.0, 3.6, 0.3), Vector3(9.0, 1.65, center_z - 6.25), concrete)
		_box(room, "InnerWallFront", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, room_center_z + 2.35), concrete)
		_box(room, "InnerWallBack", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, room_center_z - 2.35), concrete)
		_box(room, "InnerWallLintel", Vector3(0.3, 0.55, 1.6), Vector3(6.0, 3.30, room_center_z), concrete)
		# Elemento visual funcional por tipo: a geometria distingue as salas sem
		# alterar os corredores nem substituir os sistemas do jogo.
		if zone_number == 1 and room_index == 0:
			_box(room, "ThermalLocker", Vector3(1.0, 1.7, 0.65), Vector3(10.7, 0.85, room_center_z - 1.0), trim)
			_box(room, "Bench", Vector3(1.6, 0.5, 0.55), Vector3(10.6, 0.25, room_center_z + 1.0), concrete)
		elif zone_number == 1 and room_index == 1:
			_box(room, "EmergencyCot", Vector3(2.0, 0.28, 0.8), Vector3(10.2, 0.75, room_center_z), trim)
		elif zone_number in [3, 7, 9] and room_index == 0:
			_box(room, "SampleCabinet", Vector3(1.1, 1.8, 0.6), Vector3(10.7, 0.9, room_center_z - 1.1), trim)
			_box(room, "ObservationPanel", Vector3(0.12, 1.1, 1.5), Vector3(11.1, 1.8, room_center_z + 1.0), concrete)
		elif zone_number in [3, 5] and room_index == 1:
			_box(room, "LabBench", Vector3(1.8, 0.85, 0.7), Vector3(10.5, 0.425, room_center_z), trim)
			_box(room, "Instrument", Vector3(0.5, 0.45, 0.45), Vector3(10.4, 1.08, room_center_z), concrete)
		elif zone_number == 6:
			_box(room, "WorkshopBench", Vector3(2.0, 0.8, 0.75), Vector3(10.4, 0.4, room_center_z), trim)
			if room_index == 1:
				for shelf_index in range(3):
					_box(room, "PartsShelf%d" % shelf_index, Vector3(0.4, 1.5, 0.45), Vector3(11.2, 0.75, room_center_z - 1.4 + shelf_index * 1.2), concrete)
		elif zone_number == 4:
			_box(room, "ElectricalCabinet", Vector3(0.75, 2.0, 1.5), Vector3(11.0, 1.0, room_center_z), trim)
			if room_index == 1:
				for battery_index in range(3):
					_box(room, "BatteryUnit%d" % battery_index, Vector3(0.45, 0.9, 0.55), Vector3(9.0 + battery_index * 0.9, 0.45, room_center_z + 1.5), concrete)
		elif zone_number == 10:
			for shelf_index in range(3):
				_box(room, "ArchiveShelf%d" % shelf_index, Vector3(0.5, 2.0, 1.6), Vector3(10.9, 1.0, room_center_z - 1.6 + shelf_index * 1.6), trim)
			_box(room, "EvacuationCrate", Vector3(0.9, 0.9, 0.9), Vector3(10.5, 0.45, room_center_z - 1.1), trim)
			_box(room, "SupplyCrate", Vector3(0.9, 0.9, 0.9), Vector3(10.5, 0.45, room_center_z + 1.1), concrete)
		elif zone_number == 8:
			_box(room, "SecurityConsole", Vector3(1.7, 0.8, 0.7), Vector3(10.3, 0.4, room_center_z), trim)
			if room_index == 0:
				_box(room, "Monitor", Vector3(0.12, 0.7, 1.2), Vector3(11.0, 1.2, room_center_z), concrete)
		# Mobiliário-base em todas as salas auxiliares, além do equipamento específico
		# acima: mesa de trabalho, assento e armário/rack com colisão real.
		_box(room, "RoomWorkTable", Vector3(1.45, 0.12, 0.72), Vector3(8.25, 0.88, room_center_z + 0.85), trim)
		_box(room, "RoomTableLegA", Vector3(0.10, 0.82, 0.10), Vector3(7.65, 0.41, room_center_z + 0.58), concrete)
		_box(room, "RoomTableLegB", Vector3(0.10, 0.82, 0.10), Vector3(8.85, 0.41, room_center_z + 0.58), concrete)
		_box(room, "RoomChairSeat", Vector3(0.48, 0.12, 0.48), Vector3(8.25, 0.48, room_center_z - 0.05), metal)
		_box(room, "RoomChairBack", Vector3(0.46, 0.55, 0.10), Vector3(8.25, 0.77, room_center_z - 0.25), metal)
		_box(room, "RoomStorageRack", Vector3(0.38, 1.55, 1.15), Vector3(11.35, 0.78, room_center_z + 1.0), concrete)
		# Painel de controlo de acesso elétrico junto à porta interior da sala.
		var access_panel_mat := StandardMaterial3D.new()
		access_panel_mat.albedo_color = Color(0.20, 0.055, 0.045)
		access_panel_mat.emission_enabled = true
		access_panel_mat.emission = Color(0.8, 0.025, 0.012)
		access_panel_mat.emission_energy_multiplier = 1.1
		_box(room, "ElectricAccessPanel", Vector3(0.10, 0.38, 0.20), Vector3(6.28, 1.55, room_center_z - 0.55), trim)
		_box(room, "ElectricAccessRedLED", Vector3(0.035, 0.07, 0.05), Vector3(6.215, 1.58, room_center_z - 0.55), access_panel_mat, false)
		_build_detailed_auxiliary_furnishings(room, zone_number, room_index, room_center_z, tint)
		var label := Label3D.new()
		label.name = "RoomSign"
		label.text = "ZONA %02d · %s\n%s" % [zone_number, room_title, prop_title]
		label.position = Vector3(9.0, 2.55, room_center_z + 2.6)
		label.font_size = 11
		label.modulate = tint.lightened(0.55)
		room.add_child(label)
		var lamp := OmniLight3D.new()
		lamp.name = "RoomLamp"
		lamp.position = Vector3(9.0, 2.9, room_center_z)
		lamp.light_color = tint.lightened(0.18)
		lamp.light_energy = 0.45 if zone_number in [6, 9] else 0.65
		lamp.omni_range = 6.5
		lamp.shadow_enabled = false
		room.add_child(lamp)

func _show_toast(message: String) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = message
	if entity_reaction_label and is_instance_valid(entity_reaction_label):
		entity_reaction_label.text = message

func _build_safe_shelter() -> void:
	# Abrigo físico na zona exterior, ligado à rota de neve. Porta e paredes têm colisão.
	safe_shelter = Node3D.new()
	safe_shelter.name = "PermanentSafeShelter"
	safe_shelter.position = Vector3(0.0, 0.0, -29.0)
	add_child(safe_shelter)
	var wall := _material(Color(0.13, 0.18, 0.21), 0.58, 0.72)
	var interior := _material(Color(0.24, 0.31, 0.34), 0.88, 0.12)
	var warning := _material(Color(0.82, 0.23, 0.08), 0.5, 0.15)
	_box(safe_shelter, "ShelterFloor", Vector3(7.0, 0.25, 7.0), Vector3(0, -0.13, 0), interior)
	_box(safe_shelter, "ShelterBackWall", Vector3(7.0, 3.2, 0.3), Vector3(0, 1.5, -3.35), wall)
	_box(safe_shelter, "ShelterLeftWall", Vector3(0.3, 3.2, 7.0), Vector3(-3.35, 1.5, 0), wall)
	_box(safe_shelter, "ShelterRightWall", Vector3(0.3, 3.2, 7.0), Vector3(3.35, 1.5, 0), wall)
	_box(safe_shelter, "ShelterRoof", Vector3(7.0, 0.3, 7.0), Vector3(0, 3.15, 0), wall)
	# A parede frontal tem dois pilares; o vão central é ocupado pela porta blindada.
	_box(safe_shelter, "ShelterFrontLeft", Vector3(2.0, 3.2, 0.3), Vector3(-2.5, 1.5, 3.35), wall)
	_box(safe_shelter, "ShelterFrontRight", Vector3(2.0, 3.2, 0.3), Vector3(2.5, 1.5, 3.35), wall)
	shelter_door = StaticBody3D.new()
	shelter_door.name = "SafeShelterDoor"
	shelter_door.position = Vector3(0, 1.45, 3.35)
	shelter_door.set_script(load("res://scripts/safe_shelter_interactable.gd"))
	shelter_door.set("interaction_mode", "door")
	var door_mesh := MeshInstance3D.new()
	var door_box := BoxMesh.new()
	door_box.size = Vector3(3.0, 2.8, 0.22)
	door_mesh.mesh = door_box
	door_mesh.name = "ShelterBlastDoorMesh"
	door_mesh.material_override = wall
	shelter_door.add_child(door_mesh)
	var door_collision := CollisionShape3D.new()
	var door_shape := BoxShape3D.new()
	door_shape.size = Vector3(3.0, 2.8, 0.24)
	door_collision.shape = door_shape
	shelter_door.add_child(door_collision)
	var door_label := Label3D.new()
	door_label.text = "ABRIGO SEGURO // PORTA BLINDADA"
	door_label.position = Vector3(0, 1.65, -0.14)
	door_label.font_size = 20
	door_label.modulate = Color(0.7, 0.95, 1.0)
	shelter_door.add_child(door_label)
	_add_interaction_test_label(shelter_door, "PORTA INTERATIVA · ABRIGO", Vector3(0, 2.1, 0))
	safe_shelter.add_child(shelter_door)
	# Painel exterior vulnerável: a criatura pode danificá-lo se permanecer junto à entrada.
	var panel := StaticBody3D.new()
	panel.name = "ShelterWeakpointPanel"
	panel.position = Vector3(2.05, 1.15, 3.62)
	panel.set_script(load("res://scripts/safe_shelter_interactable.gd"))
	panel.set("interaction_mode", "panel")
	var panel_mesh := MeshInstance3D.new()
	var panel_box := BoxMesh.new()
	panel_box.size = Vector3(0.48, 0.72, 0.16)
	panel_mesh.mesh = panel_box
	panel_mesh.material_override = warning
	panel.add_child(panel_mesh)
	var panel_collision := CollisionShape3D.new()
	var panel_shape := BoxShape3D.new()
	panel_shape.size = Vector3(0.55, 0.8, 0.2)
	panel_collision.shape = panel_shape
	panel.add_child(panel_collision)
	_add_interaction_test_label(panel, "PAINEL INTERATIVO · REPARAÇÃO", Vector3(0, 0.62, 0))
	safe_shelter.add_child(panel)
	var inside_panel := StaticBody3D.new()
	inside_panel.name = "ShelterEmergencyOverride"
	inside_panel.position = Vector3(2.85, 1.1, 1.4)
	inside_panel.set_script(load("res://scripts/safe_shelter_interactable.gd"))
	inside_panel.set("interaction_mode", "repair")
	var override_mesh := MeshInstance3D.new()
	var override_box := BoxMesh.new()
	override_box.size = Vector3(0.16, 0.6, 0.45)
	override_mesh.mesh = override_box
	override_mesh.material_override = warning
	inside_panel.add_child(override_mesh)
	var override_collision := CollisionShape3D.new()
	var override_shape := BoxShape3D.new()
	override_shape.size = Vector3(0.2, 0.7, 0.5)
	override_collision.shape = override_shape
	inside_panel.add_child(override_collision)
	_add_interaction_test_label(inside_panel, "PAINEL INTERATIVO · EMERGÊNCIA", Vector3(0, 0.75, 0))
	safe_shelter.add_child(inside_panel)
	var light := OmniLight3D.new()
	light.name = "ShelterEmergencyLight"
	light.position = Vector3(0, 2.55, 0)
	light.light_color = Color(0.48, 0.82, 1.0)
	light.light_energy = 1.0
	light.omni_range = 9.0
	safe_shelter.add_child(light)
	var sign := Label3D.new()
	sign.text = "ABRIGO DE EMERGÊNCIA\nENERGIA INDEPENDENTE"
	sign.position = Vector3(0, 2.05, -2.9)
	sign.font_size = 22
	sign.modulate = Color(0.65, 0.9, 1.0)
	safe_shelter.add_child(sign)
	var supplies := _box(safe_shelter, "EmergencySupplies", Vector3(1.2, 0.55, 0.65), Vector3(-2.1, 0.28, -1.9), interior, false)
	supplies.rotation.y = deg_to_rad(-8)
	var radio := _box(safe_shelter, "EmergencyRadio", Vector3(0.42, 0.24, 0.28), Vector3(-2.0, 1.05, -1.8), warning, false)
	var notice := Label3D.new()
	notice.name = "ShelterWeakpointNotice"
	notice.text = "SISTEMA DE FECHO: NORMAL"
	notice.position = Vector3(0, 0.55, -2.9)
	notice.font_size = 18
	notice.modulate = Color(0.45, 1.0, 0.55)
	safe_shelter.add_child(notice)
	shelter_feedback_label = notice

func _is_player_inside_safe_shelter(player: Node3D) -> bool:
	if player == null or safe_shelter == null:
		return false
	var local_pos: Vector3 = safe_shelter.to_local(player.global_position)
	return absf(local_pos.x) < 2.95 and local_pos.z > -2.95 and local_pos.z < 2.85 and local_pos.y > -0.5 and local_pos.y < 2.7

func interact_safe_shelter_door() -> void:
	if shelter_lock_damaged:
		_show_toast("FECHO AVARIADO — usa o painel de emergência no interior para reparar o sistema.")
		return
	if shelter_door_open:
		shelter_door.position = Vector3(0, 1.45, 3.35)
		shelter_door_open = false
		_play_sfx("door_motor.wav")
		if shelter_feedback_label:
			shelter_feedback_label.text = "SISTEMA DE FECHO: NORMAL"
			shelter_feedback_label.modulate = Color(0.45, 1.0, 0.55)
	else:
		shelter_door.position = Vector3(3.1, 1.45, 3.35)
		shelter_door_open = true
		_play_sfx("door_motor.wav")
		_show_toast("ABRIGO SEGURO — entra e fecha a porta. O MRE não alimenta este sistema.")

func interact_shelter_weakpoint() -> void:
	if shelter_lock_damaged:
		_show_toast("PAINEL DANIFICADO — a fechadura perdeu a proteção normal. Repara pelo painel interior.")
	else:
		_show_toast("PONTO FRACO IDENTIFICADO: painel exterior do fecho. A proteção está ativa por agora.")

func repair_shelter_lock() -> void:
	if not shelter_lock_damaged:
		_show_toast("SISTEMA NORMAL — não é necessária reparação.")
		return
	# Reparação simples para não bloquear o modo individual; custo é tempo de exposição/ação.
	shelter_lock_damaged = false
	shelter_lock_damage_progress = 0.0
	shelter_creature_pressure = 0.0
	if shelter_door:
		shelter_door.position = Vector3(0, 1.45, 3.35) if not shelter_door_open else Vector3(3.1, 1.45, 3.35)
	if shelter_feedback_label:
		shelter_feedback_label.text = "SISTEMA DE FECHO: NORMAL"
		shelter_feedback_label.modulate = Color(0.45, 1.0, 0.55)
	_show_toast("FECHO REPARADO — a porta blindada voltou a proteger o abrigo.")

func _update_shelter_weakpoint_ai(delta: float) -> void:
	if not multiplayer.is_server() or entity_presence == null or shelter_lock_damaged or safe_shelter == null:
		return
	var panel_position: Vector3 = safe_shelter.to_global(Vector3(2.05, 1.15, 3.62))
	if entity_presence.global_position.distance_to(panel_position) < 2.2:
		shelter_creature_pressure += delta
		if shelter_creature_pressure >= 9.0:
			shelter_lock_damaged = true
			shelter_door_open = true
			if shelter_door:
				shelter_door.position = Vector3(3.1, 1.45, 3.35)
			if shelter_feedback_label:
				shelter_feedback_label.text = "AVARIA NO FECHO — REPARAÇÃO NECESSÁRIA"
				shelter_feedback_label.modulate = Color(1.0, 0.18, 0.08)
			_show_toast("AVISO: a criatura danificou o ponto fraco exterior do abrigo. Usa o comando de emergência no interior.")
	else:
		shelter_creature_pressure = maxf(0.0, shelter_creature_pressure - delta * 1.5)

func _build_door() -> void:
	var door := StaticBody3D.new()
	door.name = "InteractiveBulkhead"
	door.set_script(INTERACTABLE_SCRIPT)
	# A porta principal não pode exigir o puzzle cooperativo para permitir acesso às zonas.
	# O jogador individual tem de conseguir abrir a passagem e concluir a campanha.
	door.set("require_coop", false)
	door.position = Vector3(0, 1.4, -9.35)
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "DoorMesh"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(2.2, 2.8, 0.22)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(Color(0.13, 0.16, 0.18), 0.42, 0.7)
	door.add_child(mesh_node)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.2, 2.8, 0.22)
	shape_node.shape = shape
	door.add_child(shape_node)
	var label := Label3D.new()
	label.text = "CÂMARA DE CONTENÇÃO  /  01"
	label.position = Vector3(0, 1.72, -0.13)
	label.font_size = 32
	label.modulate = Color(0.82, 0.72, 0.52)
	door.add_child(label)
	add_child(door)

func _build_coop_switches() -> void:
	# Two separated stations: each must be activated by a different network peer.
	_create_switch("A", Vector3(-4.1, 0.0, -2.1), "RELÉ A  /  LEITURA")
	_create_switch("B", Vector3(4.1, 0.0, -6.0), "RELÉ B  /  CONFIRMAÇÃO")

func _create_switch(switch_id: String, pos: Vector3, caption: String) -> void:
	# Consola industrial detalhada: deixa de ser um bloco colorido de protótipo.
	var station := StaticBody3D.new()
	station.name = "CoopSwitch" + switch_id
	station.set_script(COOP_SWITCH_SCRIPT)
	station.switch_id = switch_id
	station.position = pos

	var housing := MeshInstance3D.new()
	housing.name = "IndustrialRelayHousing"
	var housing_mesh := BoxMesh.new()
	housing_mesh.size = Vector3(0.78, 0.92, 0.42)
	housing.mesh = housing_mesh
	housing.position = Vector3(0, 0.48, 0)
	housing.material_override = _material(Color(0.105, 0.135, 0.15), 0.72, 0.68)
	station.add_child(housing)

	var face := MeshInstance3D.new()
	face.name = "MetalControlFace"
	var face_mesh := BoxMesh.new()
	face_mesh.size = Vector3(0.64, 0.70, 0.035)
	face.mesh = face_mesh
	face.position = Vector3(0, 0.49, -0.229)
	face.material_override = _material(Color(0.20, 0.24, 0.25), 0.48, 0.78)
	station.add_child(face)

	# Faixa de identificação gravada no painel frontal.
	var strip := MeshInstance3D.new()
	strip.name = "RelayLabelStrip"
	var strip_mesh := BoxMesh.new()
	strip_mesh.size = Vector3(0.48, 0.09, 0.018)
	strip.mesh = strip_mesh
	strip.position = Vector3(0, 0.73, -0.253)
	strip.material_override = _material(Color(0.055, 0.075, 0.08), 0.6, 0.25)
	station.add_child(strip)

	var status_led := MeshInstance3D.new()
	status_led.name = "RelayStatusLED"
	var led_mesh := SphereMesh.new()
	led_mesh.radius = 0.035
	led_mesh.height = 0.07
	status_led.mesh = led_mesh
	status_led.position = Vector3(-0.19, 0.73, -0.276)
	var led_mat := _material(Color(0.05, 0.95, 0.72) if switch_id == "A" else Color(1.0, 0.48, 0.08), 0.28, 0.15)
	led_mat.emission_enabled = true
	led_mat.emission = led_mat.albedo_color
	led_mat.emission_energy_multiplier = 1.4
	status_led.material_override = led_mat
	station.add_child(status_led)

	# Pequeno ecrã de estado visível no próprio equipamento.
	var state_display := MeshInstance3D.new()
	state_display.name = "RelayStateDisplay"
	var display_mesh := BoxMesh.new()
	display_mesh.size = Vector3(0.25, 0.085, 0.012)
	state_display.mesh = display_mesh
	state_display.position = Vector3(0.105, 0.73, -0.276)
	state_display.material_override = _material(Color(0.20, 0.12, 0.025), 0.2, 0.1)
	station.add_child(state_display)

	var state_label := Label3D.new()
	state_label.name = "RelayStateLabel"
	state_label.text = "À ESPERA"
	state_label.position = Vector3(0.105, 0.73, -0.286)
	state_label.font_size = 10
	state_label.pixel_size = 0.0018
	state_label.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	state_label.modulate = Color(1.0, 0.72, 0.24)
	state_label.outline_size = 2
	state_label.outline_modulate = Color(0.01, 0.015, 0.01, 1.0)
	station.add_child(state_label)

	for button_index in range(3):
		var button := MeshInstance3D.new()
		button.name = "ControlButton%d" % button_index
		var button_mesh := CylinderMesh.new()
		button_mesh.top_radius = 0.045
		button_mesh.bottom_radius = 0.045
		button_mesh.height = 0.035
		button.mesh = button_mesh
		button.rotation.x = PI / 2.0
		button.position = Vector3(-0.13 + float(button_index) * 0.13, 0.35, -0.264)
		button.material_override = _material([Color(0.75, 0.16, 0.10), Color(0.12, 0.65, 0.9), Color(0.72, 0.75, 0.72)][button_index], 0.38, 0.28)
		station.add_child(button)

	var lower_vent := MeshInstance3D.new()
	lower_vent.name = "LowerVent"
	var vent_mesh := BoxMesh.new()
	vent_mesh.size = Vector3(0.43, 0.12, 0.02)
	lower_vent.mesh = vent_mesh
	lower_vent.position = Vector3(0, 0.19, -0.253)
	lower_vent.material_override = _material(Color(0.035, 0.045, 0.05), 0.9, 0.2)
	station.add_child(lower_vent)

	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.90, 1.05, 0.52)
	shape_node.position = Vector3(0, 0.49, 0)
	shape_node.shape = shape
	station.add_child(shape_node)

	var label := Label3D.new()
	label.name = "RelayWorldLabel"
	label.text = caption
	label.position = Vector3(0, 1.12, -0.30)
	label.font_size = 24
	label.pixel_size = 0.004
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.modulate = Color(0.82, 0.90, 0.92)
	label.outline_size = 6
	label.outline_modulate = Color(0.015, 0.025, 0.03, 0.95)
	station.add_child(label)
	_add_interaction_test_label(station, "RELÉ INTERATIVO · %s" % switch_id, Vector3(0, 1.65, 0))
	add_child(station)

func _human_part(parent: Node3D, part_name: String, mesh: PrimitiveMesh, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var part := MeshInstance3D.new()
	part.name = part_name
	part.mesh = mesh
	part.position = pos
	part.rotation = rot
	part.material_override = mat
	parent.add_child(part)
	return part

func _add_human_model(parent: Node3D, uniform_color: Color, include_head := true, include_camera_pivot := false) -> void:
	# Lightweight, fully procedural human silhouette: no external model downloads.
	# Equipamento polar visível: parka acolchoada, capuz, óculos, luvas e botas isolantes.
	var uniform := _material(uniform_color, 0.82, 0.02)
	var dark_fabric := _material(Color(0.055, 0.075, 0.085), 0.92)
	var insulation := _material(Color(0.16, 0.22, 0.27), 0.96)
	var trim := _material(Color(0.78, 0.84, 0.87), 0.62, 0.05)
	var lens := _material(Color(0.06, 0.25, 0.34), 0.28, 0.42)
	var skin := _material(Color(0.56, 0.37, 0.27), 0.9)
	var hair := _material(Color(0.035, 0.027, 0.025), 0.96)
	var boot_mesh := BoxMesh.new()
	boot_mesh.size = Vector3(0.24, 0.18, 0.36)
	for side in [-1.0, 1.0]:
		var leg := CapsuleMesh.new()
		leg.radius = 0.115
		leg.height = 0.62
		_human_part(parent, "Leg_%s" % str(side), leg, Vector3(side * 0.14, -0.42, 0.0), dark_fabric)
		_human_part(parent, "PolarBoot_%s" % str(side), boot_mesh, Vector3(side * 0.14, -0.76, -0.055), insulation)
		var gaiter := CylinderMesh.new()
		gaiter.top_radius = 0.105
		gaiter.bottom_radius = 0.12
		gaiter.height = 0.20
		_human_part(parent, "BootGaiter_%s" % str(side), gaiter, Vector3(side * 0.14, -0.60, 0.0), trim)
	var torso := CapsuleMesh.new()
	torso.radius = 0.255
	torso.height = 0.70
	_human_part(parent, "InsulatedPolarParka", torso, Vector3(0, 0.02, 0), uniform)
	var hood := SphereMesh.new()
	hood.radius = 0.205
	hood.height = 0.30
	_human_part(parent, "ParkaHood", hood, Vector3(0, 0.39, 0.035), insulation)
	var zipper := BoxMesh.new()
	zipper.size = Vector3(0.018, 0.40, 0.018)
	_human_part(parent, "ParkaFrontZipper", zipper, Vector3(0, 0.03, -0.253), trim)
	var chest_panel := BoxMesh.new()
	chest_panel.size = Vector3(0.12, 0.09, 0.025)
	_human_part(parent, "ExpeditionIDPanel", chest_panel, Vector3(0.105, 0.16, -0.251), insulation)
	var vest := BoxMesh.new()
	vest.size = Vector3(0.34, 0.31, 0.045)
	_human_part(parent, "ExpeditionVest", vest, Vector3(0, 0.05, -0.245), _material(Color(0.72, 0.24, 0.10), 0.7))
	var stripe := BoxMesh.new()
	stripe.size = Vector3(0.29, 0.035, 0.012)
	_human_part(parent, "ReflectiveVestStripe", stripe, Vector3(0, 0.075, -0.274), _material(Color(0.88, 0.78, 0.42), 0.48, 0.08))
	for side in [-1.0, 1.0]:
		var arm := CapsuleMesh.new()
		arm.radius = 0.085
		arm.height = 0.62
		_human_part(parent, "Arm_%s" % str(side), arm, Vector3(side * 0.31, 0.0, -0.01), uniform, Vector3(0, 0, side * -0.12))
		var hand := SphereMesh.new()
		hand.radius = 0.082
		hand.height = 0.16
		_human_part(parent, "InsulatedGlove_%s" % str(side), hand, Vector3(side * 0.34, -0.30, -0.025), insulation)
	var pack := BoxMesh.new()
	pack.size = Vector3(0.32, 0.43, 0.17)
	_human_part(parent, "PolarSurvivalPack", pack, Vector3(0, 0.10, 0.22), dark_fabric)
	var pack_flap := BoxMesh.new()
	pack_flap.size = Vector3(0.25, 0.10, 0.035)
	_human_part(parent, "PackFlap", pack_flap, Vector3(0, 0.28, 0.315), insulation)
	var radio := BoxMesh.new()
	radio.size = Vector3(0.07, 0.13, 0.045)
	_human_part(parent, "EmergencyRadio", radio, Vector3(0.205, 0.10, 0.015), dark_fabric)
	# Additional layered expedition gear gives the silhouette a more finished 3D read.
	var shoulder_pad := SphereMesh.new()
	shoulder_pad.radius = 0.125
	shoulder_pad.height = 0.22
	for side in [-1.0, 1.0]:
		_human_part(parent, "InsulatedShoulder_%s" % str(side), shoulder_pad, Vector3(side * 0.255, 0.235, -0.005), insulation)
		var knee_pad := BoxMesh.new()
		knee_pad.size = Vector3(0.19, 0.15, 0.075)
		_human_part(parent, "KneeProtection_%s" % str(side), knee_pad, Vector3(side * 0.14, -0.43, -0.095), dark_fabric)
		var boot_sole := BoxMesh.new()
		boot_sole.size = Vector3(0.25, 0.035, 0.37)
		_human_part(parent, "BootSole_%s" % str(side), boot_sole, Vector3(side * 0.14, -0.845, -0.06), dark_fabric)
	var belt := BoxMesh.new()
	belt.size = Vector3(0.42, 0.075, 0.29)
	_human_part(parent, "UtilityBelt", belt, Vector3(0, -0.17, 0), dark_fabric)
	var buckle := BoxMesh.new()
	buckle.size = Vector3(0.075, 0.055, 0.025)
	_human_part(parent, "UtilityBuckle", buckle, Vector3(0, -0.17, -0.157), trim)
	var oxygen_tank := CylinderMesh.new()
	oxygen_tank.top_radius = 0.065
	oxygen_tank.bottom_radius = 0.065
	oxygen_tank.height = 0.34
	for side in [-1.0, 1.0]:
		_human_part(parent, "EmergencyOxygen_%s" % str(side), oxygen_tank, Vector3(side * 0.105, 0.13, 0.265), insulation)
	var chest_patch := BoxMesh.new()
	chest_patch.size = Vector3(0.105, 0.055, 0.018)
	_human_part(parent, "ExpeditionChestPatch", chest_patch, Vector3(-0.105, 0.19, -0.278), trim)
	# High-detail wearable kit: stitched seams, webbing, clips, headlamp and weathered gear.
	var seam_mat := _material(Color(0.025, 0.038, 0.045), 0.98, 0.0)
	var webbing_mat := _material(Color(0.11, 0.14, 0.15), 0.88, 0.02)
	var metal_mat := _material(Color(0.42, 0.49, 0.50), 0.34, 0.72)
	for side in [-1.0, 1.0]:
		var harness := BoxMesh.new()
		harness.size = Vector3(0.055, 0.42, 0.035)
		_human_part(parent, "HarnessStrap_%s" % str(side), harness, Vector3(side * 0.105, 0.075, -0.272), webbing_mat, Vector3(0, 0, side * -0.22))
		var thigh_pocket := BoxMesh.new()
		thigh_pocket.size = Vector3(0.105, 0.14, 0.055)
		_human_part(parent, "CargoPocket_%s" % str(side), thigh_pocket, Vector3(side * 0.19, -0.24, -0.12), insulation)
		var pocket_latch := BoxMesh.new()
		pocket_latch.size = Vector3(0.045, 0.018, 0.012)
		_human_part(parent, "CargoPocketLatch_%s" % str(side), pocket_latch, Vector3(side * 0.19, -0.20, -0.153), metal_mat)
		var cuff := CylinderMesh.new()
		cuff.top_radius = 0.088
		cuff.bottom_radius = 0.092
		cuff.height = 0.075
		_human_part(parent, "WristCuff_%s" % str(side), cuff, Vector3(side * 0.33, -0.255, -0.02), dark_fabric, Vector3(0, 0, deg_to_rad(90)))
	# Multiple small stitch lines break up the large flat surfaces at close range.
	for stitch_index in range(4):
		var stitch := BoxMesh.new()
		stitch.size = Vector3(0.12, 0.008, 0.009)
		_human_part(parent, "ParkaStitch_%02d" % stitch_index, stitch, Vector3(0.0, 0.19 - float(stitch_index) * 0.075, -0.257), seam_mat)
	var headlamp_mount := BoxMesh.new()
	headlamp_mount.size = Vector3(0.105, 0.045, 0.045)
	_human_part(parent, "HeadlampHousing", headlamp_mount, Vector3(0, 0.735, -0.135), dark_fabric)
	var headlamp_lens := SphereMesh.new()
	headlamp_lens.radius = 0.023
	headlamp_lens.height = 0.03
	var lamp_mat := _material(Color(0.72, 0.88, 1.0), 0.22, 0.1)
	lamp_mat.emission_enabled = true
	lamp_mat.emission = Color(0.48, 0.72, 1.0)
	lamp_mat.emission_energy_multiplier = 1.15
	_human_part(parent, "HeadlampLens", headlamp_lens, Vector3(0, 0.735, -0.164), lamp_mat)
	var radio_antenna := CylinderMesh.new()
	radio_antenna.top_radius = 0.006
	radio_antenna.bottom_radius = 0.012
	radio_antenna.height = 0.18
	_human_part(parent, "RadioAntenna", radio_antenna, Vector3(0.23, 0.22, 0.025), metal_mat, Vector3(0, 0, deg_to_rad(-8)))
	var radio_screen := BoxMesh.new()
	radio_screen.size = Vector3(0.043, 0.035, 0.009)
	_human_part(parent, "RadioScreen", radio_screen, Vector3(0.205, 0.12, -0.012), lens)
	if include_head:
		var neck := CylinderMesh.new()
		neck.top_radius = 0.075
		neck.bottom_radius = 0.085
		neck.height = 0.13
		_human_part(parent, "Neck", neck, Vector3(0, 0.40, 0), skin)
		var head := SphereMesh.new()
		head.radius = 0.145
		head.height = 0.34
		_human_part(parent, "HumanHead", head, Vector3(0, 0.59, -0.005), skin)
		# Balaclava/cap silhouette and polar goggles are always part of the outfit.
		var balaclava := SphereMesh.new()
		balaclava.radius = 0.151
		balaclava.height = 0.24
		_human_part(parent, "PolarBalaclava", balaclava, Vector3(0, 0.61, 0.0), insulation)
		var goggles := BoxMesh.new()
		goggles.size = Vector3(0.23, 0.065, 0.035)
		_human_part(parent, "SnowGoggles", goggles, Vector3(0, 0.625, -0.132), lens)
		var hair_cap := SphereMesh.new()
		hair_cap.radius = 0.15
		hair_cap.height = 0.16
		_human_part(parent, "Hair", hair_cap, Vector3(0, 0.69, 0.0), hair)
		for side in [-1.0, 1.0]:
			var eye := SphereMesh.new()
			eye.radius = 0.018
			eye.height = 0.03
			_human_part(parent, "Eye_%s" % str(side), eye, Vector3(side * 0.05, 0.60, -0.139), dark_fabric)
			var brow := BoxMesh.new()
			brow.size = Vector3(0.055, 0.014, 0.018)
			_human_part(parent, "Brow_%s" % str(side), brow, Vector3(side * 0.05, 0.635, -0.145), hair, Vector3(0, 0, side * -0.10))
		var nose := SphereMesh.new()
		nose.radius = 0.025
		nose.height = 0.045
		_human_part(parent, "NoseBridge", nose, Vector3(0, 0.565, -0.15), skin)
		var respirator := BoxMesh.new()
		respirator.size = Vector3(0.16, 0.075, 0.055)
		_human_part(parent, "PolarRespirator", respirator, Vector3(0, 0.535, -0.145), dark_fabric)

func _add_creature_model(parent: Node3D) -> void:
	# Modelo 3D exportado em GLB, leve para Android. A colisão e a IA continuam
	# no CharacterBody3D; o GLB é apenas a representação visual.
	var creature_scene := load("res://assets/entity_creature.glb") as PackedScene
	if creature_scene != null:
		var creature_visual := creature_scene.instantiate() as Node3D
		if creature_visual != null:
			creature_visual.name = "BlenderCompatibleCreatureVisual"
			creature_visual.scale = Vector3(0.78, 0.78, 0.78)
			creature_visual.position.y = -0.82
			parent.add_child(creature_visual)
			return
	# Fallback original se o recurso GLB não puder ser carregado.
	# Distinct procedural creature silhouette: elongated anatomy, asymmetry, exposed ribs and hooked claws.
	# Kept lightweight for mobile rendering; all geometry is generated from Godot primitives.
	var hide_mat := _material(Color(0.012, 0.018, 0.022), 0.98, 0.0)
	var chitin := _material(Color(0.045, 0.065, 0.069), 0.62, 0.12)
	var bone := _material(Color(0.22, 0.27, 0.25), 0.82, 0.0)
	var wound := _material(Color(0.19, 0.018, 0.012), 0.7, 0.0)
	var glow := StandardMaterial3D.new()
	glow.albedo_color = Color(0.72, 0.018, 0.006)
	glow.emission_enabled = true
	glow.emission = Color(0.95, 0.012, 0.003)
	glow.emission_energy_multiplier = 2.4
	var torso := CapsuleMesh.new()
	torso.radius = 0.30
	torso.height = 0.96
	_human_part(parent, "NarrowTorso", torso, Vector3(0, 0.12, 0), hide_mat, Vector3(0, 0, deg_to_rad(-7.0)))
	var sternum := BoxMesh.new()
	sternum.size = Vector3(0.12, 0.66, 0.12)
	_human_part(parent, "ExposedSternum", sternum, Vector3(0, 0.10, -0.265), bone)
	for rib_index in range(5):
		var rib := TorusMesh.new()
		rib.inner_radius = 0.105
		rib.outer_radius = 0.135
		rib.rings = 5
		rib.ring_segments = 8
		var rib_node := _human_part(parent, "Rib_%02d" % rib_index, rib, Vector3(0, 0.28 - float(rib_index) * 0.13, -0.22), bone, Vector3(deg_to_rad(90), 0, 0))
		rib_node.scale = Vector3(1.55, 0.78, 1.0)
	var neck := CylinderMesh.new()
	neck.top_radius = 0.105
	neck.bottom_radius = 0.19
	neck.height = 0.42
	_human_part(parent, "ElongatedNeck", neck, Vector3(0, 0.68, 0.015), chitin, Vector3(0, 0, deg_to_rad(-8.0)))
	var skull := SphereMesh.new()
	skull.radius = 0.205
	skull.height = 0.53
	_human_part(parent, "WedgeSkull", skull, Vector3(0, 0.99, -0.035), hide_mat, Vector3(deg_to_rad(-12), 0, 0))
	# Secondary carapace ridges and wet-looking tendons give the creature a less blocky silhouette.
	var ridge_mat := _material(Color(0.075, 0.095, 0.095), 0.52, 0.18)
	for ridge_index in range(4):
		var ridge := CapsuleMesh.new()
		ridge.radius = 0.035
		ridge.height = 0.48 - float(ridge_index) * 0.045
		_human_part(parent, "DorsalRidge_%02d" % ridge_index, ridge, Vector3(-0.16 + float(ridge_index) * 0.105, 0.22, 0.18), ridge_mat, Vector3(deg_to_rad(16), 0, deg_to_rad(-12)))
	var face_plate := BoxMesh.new()
	face_plate.size = Vector3(0.22, 0.18, 0.09)
	_human_part(parent, "FacePlate", face_plate, Vector3(0, 0.91, -0.205), chitin, Vector3(deg_to_rad(-12), 0, 0))
	for side in [-1.0, 1.0]:
		var eye := SphereMesh.new()
		eye.radius = 0.038
		eye.height = 0.07
		_human_part(parent, "PredatorEye_%s" % str(side), eye, Vector3(side * 0.105, 1.035, -0.205), glow)
		var shoulder := SphereMesh.new()
		shoulder.radius = 0.19
		shoulder.height = 0.31
		_human_part(parent, "AsymmetricShoulder_%s" % str(side), shoulder, Vector3(side * 0.29, 0.40, 0.015), chitin, Vector3(0, 0, side * 0.2))
		var arm := CapsuleMesh.new()
		arm.radius = 0.105 if side < 0 else 0.13
		arm.height = 0.86 if side < 0 else 1.02
		_human_part(parent, "LongArm_%s" % str(side), arm, Vector3(side * 0.39, -0.08, -0.005), hide_mat, Vector3(0, 0, side * -0.18))
		var forearm := CapsuleMesh.new()
		forearm.radius = 0.075
		forearm.height = 0.55
		_human_part(parent, "ForearmPlate_%s" % str(side), forearm, Vector3(side * 0.46, -0.43, -0.02), chitin, Vector3(0, 0, side * -0.14))
		for claw_index in range(3):
			var claw: CylinderMesh = CylinderMesh.new()
			claw.top_radius = 0.0
			claw.bottom_radius = 0.025
			claw.height = 0.22
			_human_part(parent, "HookClaw_%s_%d" % [str(side), claw_index], claw, Vector3(side * (0.42 + float(claw_index) * 0.065), -0.76, -0.10), bone, Vector3(deg_to_rad(155), 0, side * -0.12))
		var thigh := CapsuleMesh.new()
		thigh.radius = 0.14
		thigh.height = 0.55
		_human_part(parent, "ReverseLeg_%s" % str(side), thigh, Vector3(side * 0.15, -0.48, 0.035), hide_mat, Vector3(deg_to_rad(7), 0, side * 0.08))
		var shin := CapsuleMesh.new()
		shin.radius = 0.075
		shin.height = 0.54
		_human_part(parent, "ShinSpur_%s" % str(side), shin, Vector3(side * 0.17, -0.76, -0.005), chitin, Vector3(deg_to_rad(-9), 0, side * -0.04))
	var tendril := CapsuleMesh.new()
	tendril.radius = 0.035
	tendril.height = 0.75
	_human_part(parent, "TrailingTendril", tendril, Vector3(0.08, 0.05, 0.28), wound, Vector3(deg_to_rad(35), 0, deg_to_rad(-24)))
	for plate_index in range(3):
		var plate := SphereMesh.new()
		plate.radius = 0.10
		plate.height = 0.16
		_human_part(parent, "BackSpine_%d" % plate_index, plate, Vector3(0, 0.35 - float(plate_index) * 0.19, 0.22), chitin, Vector3(deg_to_rad(22), 0, 0))

func _build_player() -> void:
	var player := CharacterBody3D.new()
	player.name = "Player"
	# Use exactly one capsule collider. Duplicate overlapping colliders can cause
	# unstable CharacterBody3D movement, especially through a narrow doorway.
	var collider := CollisionShape3D.new()
	collider.name = "CollisionShape3D"
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.75
	collider.shape = capsule
	player.add_child(collider)
	player.set_script(PLAYER_SCRIPT)
	player.position = Vector3(0, 0.95, 4.2)
	var camera_pivot := Node3D.new()
	camera_pivot.name = "CameraPivot"
	camera_pivot.position = Vector3(0, 0.55, 0)
	player.add_child(camera_pivot)
	var camera := Camera3D.new()
	camera.name = "Camera3D"
	camera.current = true
	camera.fov = 82
	camera_pivot.add_child(camera)
	var ray := RayCast3D.new()
	ray.name = "InteractionRay"
	ray.target_position = Vector3(0, 0, -2.8)
	ray.collide_with_areas = true
	ray.collide_with_bodies = true
	camera.add_child(ray)
	var flashlight := SpotLight3D.new()
	flashlight.name = "Flashlight"
	flashlight.position = Vector3(0.12, -0.08, -0.15)
	flashlight.rotation_degrees = Vector3(-3, 0, 0)
	flashlight.light_energy = 4.0
	flashlight.spot_range = 21
	flashlight.spot_angle = 42
	flashlight.shadow_enabled = true
	camera.add_child(flashlight)
	# First-person camera: do not render the local body around the camera.
	# The CharacterBody3D collider remains active; remote avatars keep their models.
	add_child(player)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUD"
	add_child(layer)
	capture_overlay = PanelContainer.new()
	capture_overlay.name = "CaptureOverlay"
	capture_overlay.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	capture_overlay.offset_left = -210
	capture_overlay.offset_top = -90
	capture_overlay.offset_right = 210
	capture_overlay.offset_bottom = 90
	capture_overlay.visible = false
	var capture_box := VBoxContainer.new()
	capture_box.add_theme_constant_override("separation", 12)
	capture_overlay.add_child(capture_box)
	capture_message = Label.new()
	capture_message.text = "A CRIATURA AGARROU-TE!"
	capture_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	capture_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	capture_message.add_theme_font_size_override("font_size", 18)
	capture_box.add_child(capture_message)
	capture_button = Button.new()
	capture_button.name = "EscapeCaptureButton"
	capture_button.text = "TOCA RAPIDAMENTE PARA TE LIBERTARES"
	capture_button.custom_minimum_size = Vector2(0, 58)
	capture_button.pressed.connect(request_capture_escape)
	capture_box.add_child(capture_button)
	layer.add_child(capture_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(center)
	var reticle := Label.new()
	reticle.text = "+"
	reticle.add_theme_font_size_override("font_size", 24)
	reticle.add_theme_color_override("font_color", Color(0.82, 0.88, 0.9, 0.85))
	center.add_child(reticle)
	var prompt := Label.new()
	prompt.name = "Prompt"
	prompt.text = "MOVER: joystick · OLHAR: arrasta à direita · INTERAGIR / LANTERNA / AGACHAR: botões"
	prompt.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	prompt.anchor_left = 0.06
	prompt.anchor_right = 0.94
	prompt.offset_top = -54
	prompt.offset_bottom = -14
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	prompt.add_theme_font_size_override("font_size", 14)
	prompt.add_theme_color_override("font_color", Color(0.78, 0.82, 0.84))
	layer.add_child(prompt)
	# Painel de combinação da porta secreta — aberto apenas ao interagir com a consola.
	secret_combination_panel = PanelContainer.new()
	secret_combination_panel.name = "SecretCombinationPanel"
	secret_combination_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	secret_combination_panel.offset_left = -190
	secret_combination_panel.offset_top = -120
	secret_combination_panel.offset_right = 190
	secret_combination_panel.offset_bottom = 120
	secret_combination_panel.visible = false
	var combo_box := VBoxContainer.new()
	combo_box.add_theme_constant_override("separation", 10)
	secret_combination_panel.add_child(combo_box)
	var combo_title := Label.new()
	combo_title.text = "FECHADURA VANTHIS"
	combo_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_title.add_theme_font_size_override("font_size", 20)
	combo_box.add_child(combo_title)
	var combo_hint := Label.new()
	combo_hint.text = "Cruza os registos de turno, os ciclos válidos, os avisos confirmados e a ordem real dos procedimentos. Nenhum documento contém o código completo."
	combo_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	combo_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_box.add_child(combo_hint)
	secret_combination_input = LineEdit.new()
	secret_combination_input.name = "SecretCombinationInput"
	secret_combination_input.placeholder_text = "Código de 4 algarismos"
	secret_combination_input.max_length = 4
	secret_combination_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	secret_combination_input.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	combo_box.add_child(secret_combination_input)
	var combo_buttons := HBoxContainer.new()
	combo_buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	combo_box.add_child(combo_buttons)
	var combo_submit := Button.new()
	combo_submit.text = "VALIDAR CÓDIGO"
	combo_submit.custom_minimum_size = Vector2(150, 44)
	combo_submit.pressed.connect(_submit_secret_combination)
	combo_buttons.add_child(combo_submit)
	var combo_cancel := Button.new()
	combo_cancel.text = "FECHAR"
	combo_cancel.custom_minimum_size = Vector2(90, 44)
	combo_cancel.pressed.connect(func(): secret_combination_panel.visible = false)
	combo_buttons.add_child(combo_cancel)
	layer.add_child(secret_combination_panel)
	var title := Label.new()
	title.text = "EXPEDIÇÃO 01  /  ESTAÇÃO VÉSPERA"
	title.position = Vector2(18, 14)
	title.add_theme_font_size_override("font_size", 15)
	title.add_theme_color_override("font_color", Color(0.73, 0.78, 0.81))
	layer.add_child(title)
	# HUD fisiológico sempre visível: pulsação e saúde, com leitura clara em Android.
	var physiology_panel := PanelContainer.new()
	physiology_panel.name = "PhysiologyPanel"
	physiology_panel.anchor_left = 1.0
	physiology_panel.anchor_right = 1.0
	physiology_panel.anchor_top = 0.0
	physiology_panel.anchor_bottom = 0.0
	physiology_panel.offset_left = -242.0
	physiology_panel.offset_right = -14.0
	physiology_panel.offset_top = 14.0
	physiology_panel.offset_bottom = 154.0
	physiology_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var physiology_style := StyleBoxFlat.new()
	physiology_style.bg_color = Color(0.025, 0.055, 0.075, 0.88)
	physiology_style.border_color = Color(0.24, 0.42, 0.49, 0.9)
	physiology_style.set_border_width_all(1)
	physiology_style.set_corner_radius_all(9)
	physiology_style.content_margin_left = 12.0
	physiology_style.content_margin_right = 12.0
	physiology_style.content_margin_top = 8.0
	physiology_style.content_margin_bottom = 8.0
	physiology_panel.add_theme_stylebox_override("panel", physiology_style)
	var physiology_box := VBoxContainer.new()
	physiology_box.add_theme_constant_override("separation", 4)
	physiology_panel.add_child(physiology_box)
	var physiology_header := Label.new()
	physiology_header.text = "ESTADO FÍSICO"
	physiology_header.add_theme_font_size_override("font_size", 12)
	physiology_header.add_theme_color_override("font_color", Color(0.75, 0.86, 0.9))
	physiology_box.add_child(physiology_header)
	var pulse_row := HBoxContainer.new()
	pulse_row.add_theme_constant_override("separation", 8)
	physiology_box.add_child(pulse_row)
	var pulse_title := Label.new()
	pulse_title.text = "♥ PULSO"
	pulse_title.custom_minimum_size.x = 74.0
	pulse_title.add_theme_font_size_override("font_size", 12)
	pulse_row.add_child(pulse_title)
	var pulse_bar := ProgressBar.new()
	pulse_bar.name = "PulseBar"
	pulse_bar.min_value = 40.0
	pulse_bar.max_value = 180.0
	pulse_bar.value = 72.0
	pulse_bar.show_percentage = false
	pulse_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pulse_bar.custom_minimum_size = Vector2(64, 15)
	var pulse_fill := StyleBoxFlat.new()
	pulse_fill.bg_color = Color(0.9, 0.28, 0.3)
	pulse_fill.set_corner_radius_all(4)
	pulse_bar.add_theme_stylebox_override("fill", pulse_fill)
	var pulse_bg := StyleBoxFlat.new()
	pulse_bg.bg_color = Color(0.13, 0.18, 0.21)
	pulse_bg.set_corner_radius_all(4)
	pulse_bar.add_theme_stylebox_override("background", pulse_bg)
	pulse_row.add_child(pulse_bar)
	var pulse_value := Label.new()
	pulse_value.name = "PulseValue"
	pulse_value.text = "72 BPM"
	pulse_value.custom_minimum_size.x = 54.0
	pulse_value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	pulse_value.add_theme_font_size_override("font_size", 11)
	pulse_row.add_child(pulse_value)
	var health_row := HBoxContainer.new()
	health_row.add_theme_constant_override("separation", 8)
	physiology_box.add_child(health_row)
	var health_title := Label.new()
	health_title.text = "SAÚDE"
	health_title.custom_minimum_size.x = 74.0
	health_title.add_theme_font_size_override("font_size", 12)
	health_row.add_child(health_title)
	var health_bar := ProgressBar.new()
	health_bar.name = "HealthBar"
	health_bar.min_value = 0.0
	health_bar.max_value = 100.0
	health_bar.value = 100.0
	health_bar.show_percentage = false
	health_bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	health_bar.custom_minimum_size = Vector2(64, 15)
	var health_fill := StyleBoxFlat.new()
	health_fill.bg_color = Color(0.25, 0.82, 0.56)
	health_fill.set_corner_radius_all(4)
	health_bar.add_theme_stylebox_override("fill", health_fill)
	var health_bg := StyleBoxFlat.new()
	health_bg.bg_color = Color(0.13, 0.18, 0.21)
	health_bg.set_corner_radius_all(4)
	health_bar.add_theme_stylebox_override("background", health_bg)
	health_row.add_child(health_bar)
	var health_value := Label.new()
	health_value.name = "HealthValue"
	health_value.text = "100%"
	health_value.custom_minimum_size.x = 34.0
	health_value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	health_value.add_theme_font_size_override("font_size", 11)
	health_row.add_child(health_value)
	var physiology_status := Label.new()
	physiology_status.name = "PhysiologyStatus"
	physiology_status.text = "ESTADO ESTÁVEL"
	physiology_status.add_theme_font_size_override("font_size", 10)
	physiology_status.add_theme_color_override("font_color", Color(0.48, 0.9, 0.68))
	physiology_box.add_child(physiology_status)
	layer.add_child(physiology_panel)
	exterior_weather_label = Label.new()
	exterior_weather_label.name = "ExteriorWeatherStatus"
	exterior_weather_label.position = Vector2(18, 96)
	exterior_weather_label.size = Vector2(520, 26)
	exterior_weather_label.visible = false
	exterior_weather_label.add_theme_font_size_override("font_size", 14)
	exterior_weather_label.add_theme_color_override("font_color", Color(0.64, 0.86, 0.96))
	layer.add_child(exterior_weather_label)
	stealth_status = Label.new()
	stealth_status.name = "StealthStatus"
	stealth_status.position = Vector2(18, 32)
	stealth_status.add_theme_font_size_override("font_size", 14)
	stealth_status.add_theme_color_override("font_color", Color(0.65, 0.82, 0.76))
	layer.add_child(stealth_status)
	private_clue = Label.new()
	private_clue.name = "PrivateClue"
	private_clue.position = Vector2(18, 52)
	private_clue.size = Vector2( minf(500.0, get_viewport().get_visible_rect().size.x * 0.48), 82)
	private_clue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	private_clue.add_theme_font_size_override("font_size", 17)
	private_clue.add_theme_color_override("font_color", Color(0.94, 0.78, 0.48))
	layer.add_child(private_clue)
	_update_private_clue()
	# Native Godot touch buttons for mobile. Buttons are deliberately large.
	var player := get_node_or_null("Player")
	if player:
		var action_box := VBoxContainer.new()
		action_box.name = "TouchActions"
		action_box.anchor_left = 1.0
		action_box.anchor_top = 1.0
		action_box.anchor_right = 1.0
		action_box.anchor_bottom = 1.0
		# Margens de segurança para ecrãs Android com proporções diferentes.
		action_box.offset_left = -174
		action_box.offset_top = -210
		action_box.offset_right = -18
		action_box.offset_bottom = -18
		action_box.add_theme_constant_override("separation", 12)
		layer.add_child(action_box)
		var interact_button := Button.new()
		interact_button.name = "InteractButton"
		interact_button.text = "INTERAGIR"
		interact_button.custom_minimum_size = Vector2(150, 52)
		interact_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		interact_button.add_theme_font_size_override("font_size", 16)
		interact_button.pressed.connect(Callable(player, "interact_now"))
		action_box.add_child(interact_button)
		var flashlight_button := Button.new()
		flashlight_button.name = "FlashlightButton"
		flashlight_button.text = "LANTERNA"
		flashlight_button.custom_minimum_size = Vector2(150, 48)
		flashlight_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		flashlight_button.add_theme_font_size_override("font_size", 15)
		flashlight_button.pressed.connect(Callable(player, "toggle_flashlight"))
		action_box.add_child(flashlight_button)
		var crouch_button := Button.new()
		crouch_button.name = "CrouchButton"
		# Texto curto para não ser cortado em ecrãs estreitos.
		crouch_button.text = "AGACHAR"
		crouch_button.tooltip_text = "Alternar entre agachado e de pé"
		crouch_button.custom_minimum_size = Vector2(150, 48)
		crouch_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		crouch_button.add_theme_font_size_override("font_size", 12)
		crouch_button.pressed.connect(Callable(player, "toggle_crouch"))
		action_box.add_child(crouch_button)
		# Guardar a referência real do botão já integrado na árvore.
		# O controlador consulta "crouch_button_ref" para atualizar AGACHAR/LEVANTAR.
		player.set_meta("crouch_button_ref", crouch_button)
	var decision_panel := PanelContainer.new()
	decision_panel.name = "ConfrontationPanel"
	decision_panel.position = Vector2(18, 138)
	decision_panel.custom_minimum_size = Vector2( minf(330.0, get_viewport().get_visible_rect().size.x * 0.46), 0)
	var decision_box := VBoxContainer.new()
	decision_box.add_theme_constant_override("separation", 8)
	decision_panel.add_child(decision_box)
	var decision_title := Label.new()
	decision_title.text = "CONFRONTO  /  OPERADOR 07"
	decision_title.add_theme_font_size_override("font_size", 16)
	decision_title.add_theme_color_override("font_color", Color(0.85, 0.78, 0.62))
	decision_box.add_child(decision_title)
	var decision_hint := Label.new()
	decision_hint.text = "Após partilharem as pistas, escolhe uma posição. A decisão conjunta altera a missão."
	decision_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_hint.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 44)
	decision_hint.add_theme_font_size_override("font_size", 14)
	decision_box.add_child(decision_hint)
	accusation_button = Button.new()
	accusation_button.text = "ACUSAR — ativar contenção"
	accusation_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	accusation_button.pressed.connect(submit_decision.bind("ACUSAR"))
	decision_box.add_child(accusation_button)
	defense_button = Button.new()
	defense_button.text = "DEFENDER — manter acesso"
	defense_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	defense_button.pressed.connect(submit_decision.bind("DEFENDER"))
	decision_box.add_child(defense_button)
	decision_status = Label.new()
	decision_status.text = "Decisão pendente: compara as pistas em voz alta."
	decision_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_status.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 30)
	decision_status.add_theme_font_size_override("font_size", 13)
	decision_status.add_theme_color_override("font_color", Color(0.72, 0.82, 0.86))
	decision_box.add_child(decision_status)
	entity_reaction_label = Label.new()
	entity_reaction_label.name = "EntityReaction"
	entity_reaction_label.text = "Sem presença confirmada."
	entity_reaction_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	entity_reaction_label.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 28)
	entity_reaction_label.add_theme_font_size_override("font_size", 13)
	entity_reaction_label.add_theme_color_override("font_color", Color(0.95, 0.3, 0.22))
	decision_box.add_child(entity_reaction_label)
	layer.add_child(decision_panel)
	# Joystick virtual visível, ao estilo dos jogos mobile (canto inferior esquerdo).
	var joystick := Control.new()
	joystick.name = "VirtualJoystick"
	joystick.set_script(load("res://scripts/virtual_joystick.gd"))
	joystick.anchor_left = 0.0
	joystick.anchor_top = 1.0
	joystick.anchor_right = 0.0
	joystick.anchor_bottom = 1.0
	joystick.offset_left = 22.0
	joystick.offset_top = -184.0
	joystick.offset_right = 178.0
	joystick.offset_bottom = -28.0
	joystick.z_index = 10
	layer.add_child(joystick)
	var player_for_joystick := get_node_or_null("Player")
	if player_for_joystick:
		joystick.value_changed.connect(Callable(player_for_joystick, "set_touch_move"))
	# LAN controls: host/join must be accessible in the actual HUD, not only in code.
	var network_panel := PanelContainer.new()
	network_panel.name = "NetworkPanel"
	network_panel.anchor_left = 1.0
	network_panel.anchor_right = 1.0
	network_panel.offset_left = -360
	network_panel.offset_top = 58
	network_panel.offset_right = -16
	network_panel.offset_bottom = 218
	network_panel.custom_minimum_size = Vector2(344, 160)
	network_panel.visible = false
	var network_box := VBoxContainer.new()
	network_box.add_theme_constant_override("separation", 5)
	network_panel.add_child(network_box)
	var network_title := Label.new()
	network_title.text = "COOPERAÇÃO LAN · UDP %d" % PORT
	network_title.add_theme_font_size_override("font_size", 14)
	network_box.add_child(network_title)
	ip_input = LineEdit.new()
	ip_input.name = "HostAddress"
	ip_input.placeholder_text = "IP do anfitrião (ex.: 192.168.1.35)"
	ip_input.text = ""
	ip_input.custom_minimum_size = Vector2(0, 36)
	network_box.add_child(ip_input)
	var network_buttons := HBoxContainer.new()
	var host_button := Button.new()
	host_button.text = "CRIAR SESSÃO"
	host_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	host_button.pressed.connect(host_game)
	network_buttons.add_child(host_button)
	var join_button := Button.new()
	join_button.text = "LIGAR À SESSÃO"
	join_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	join_button.pressed.connect(join_game)
	network_buttons.add_child(join_button)
	network_box.add_child(network_buttons)
	network_status = Label.new()
	network_status.name = "NetworkStatus"
	network_status.text = "Jogador 1: CRIAR SESSÃO. Jogador 2: introduz o IP do anfitrião e toca em LIGAR À SESSÃO. Mesma WLAN; internet não necessária."
	network_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	network_status.add_theme_font_size_override("font_size", 12)
	network_box.add_child(network_status)
	layer.add_child(network_panel)
	var network_toggle := Button.new()
	network_toggle.name = "NetworkToggle"
	network_toggle.text = "REDE LAN"
	network_toggle.anchor_left = 1.0
	network_toggle.anchor_right = 1.0
	network_toggle.offset_left = -124
	network_toggle.offset_top = 20
	network_toggle.offset_right = -16
	network_toggle.offset_bottom = 54
	network_toggle.pressed.connect(_toggle_network_panel.bind(network_panel))
	layer.add_child(network_toggle)
	# Mini-mapa global ampliado: complexo, salas e exterior, legível em ecrãs móveis.
	var mini_map := Control.new()
	mini_map.name = "MiniMapaSala"
	mini_map.set_script(load("res://scripts/mini_map.gd"))
	mini_map.anchor_left = 1.0
	mini_map.anchor_right = 1.0
	mini_map.anchor_top = 0.28
	mini_map.anchor_bottom = 0.28
	mini_map.offset_left = -330.0
	mini_map.offset_top = 8.0
	mini_map.offset_right = -16.0
	mini_map.offset_bottom = 390.0
	mini_map.z_index = 5
	layer.add_child(mini_map)
	# HUB DE JOGO: objetivos, inventário, equipa, dossier, comunicação rápida e pausa.
	var hub_toggle := Button.new()
	hub_toggle.name = "MissionHubToggle"
	hub_toggle.text = "MISSÃO  /  EQUIPA"
	hub_toggle.anchor_left = 0.0
	hub_toggle.anchor_right = 0.0
	hub_toggle.anchor_top = 0.0
	hub_toggle.anchor_bottom = 0.0
	hub_toggle.offset_left = 18
	hub_toggle.offset_top = 82
	hub_toggle.offset_right = 190
	hub_toggle.offset_bottom = 122
	hub_toggle.pressed.connect(_toggle_mission_hub)
	layer.add_child(hub_toggle)
	var pause_button := Button.new()
	pause_button.name = "PauseButton"
	pause_button.text = "Ⅱ  PAUSA"
	pause_button.anchor_left = 1.0
	pause_button.anchor_right = 1.0
	pause_button.offset_left = -124
	pause_button.offset_top = 60
	pause_button.offset_right = -16
	pause_button.offset_bottom = 98
	pause_button.pressed.connect(_toggle_pause_menu)
	layer.add_child(pause_button)
	mission_hub = PanelContainer.new()
	mission_hub.name = "MissionHub"
	mission_hub.anchor_left = 0.5
	mission_hub.anchor_top = 0.5
	mission_hub.anchor_right = 0.5
	mission_hub.anchor_bottom = 0.5
	mission_hub.offset_left = -minf(330.0, get_viewport().get_visible_rect().size.x * 0.44)
	mission_hub.offset_top = -minf(260.0, get_viewport().get_visible_rect().size.y * 0.40)
	mission_hub.offset_right = minf(330.0, get_viewport().get_visible_rect().size.x * 0.44)
	mission_hub.offset_bottom = minf(260.0, get_viewport().get_visible_rect().size.y * 0.40)
	mission_hub.visible = false
	mission_hub.z_index = 40
	var hub_stack := VBoxContainer.new()
	hub_stack.add_theme_constant_override("separation", 8)
	mission_hub.add_child(hub_stack)
	mission_hub_title = Label.new()
	mission_hub_title.text = "CENTRO DE MISSÃO"
	mission_hub_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mission_hub_title.add_theme_font_size_override("font_size", 20)
	hub_stack.add_child(mission_hub_title)
	var tab_row := GridContainer.new()
	tab_row.columns = 2
	tab_row.add_theme_constant_override("h_separation", 6)
	tab_row.add_theme_constant_override("v_separation", 6)
	for tab_name in ["OBJETIVOS", "INVENTÁRIO", "EQUIPA", "DOSSIÊ"]:
		var tab_button := Button.new()
		tab_button.text = tab_name
		tab_button.custom_minimum_size = Vector2(130, 40)
		tab_button.pressed.connect(_set_mission_hub_tab.bind(tab_name))
		tab_row.add_child(tab_button)
	hub_stack.add_child(tab_row)
	mission_hub_body = Label.new()
	mission_hub_body.name = "MissionHubBody"
	mission_hub_body.custom_minimum_size = Vector2(0, 185)
	mission_hub_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mission_hub_body.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	mission_hub_body.add_theme_font_size_override("font_size", 15)
	hub_stack.add_child(mission_hub_body)
	quick_comms_status = Label.new()
	quick_comms_status.text = "Comunicação rápida disponível em sessão LAN."
	quick_comms_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	quick_comms_status.add_theme_font_size_override("font_size", 12)
	hub_stack.add_child(quick_comms_status)
	var comms_row := HBoxContainer.new()
	for comm in ["ESTOU AQUI", "PRECISO DE AJUDA", "VEM AO RELÉ"]:
		var comm_button := Button.new()
		comm_button.text = comm
		comm_button.custom_minimum_size = Vector2(0, 40)
		comm_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		comm_button.pressed.connect(_send_quick_comms.bind(comm))
		comms_row.add_child(comm_button)
	hub_stack.add_child(comms_row)
	var hub_close := Button.new()
	hub_close.text = "VOLTAR AO JOGO"
	hub_close.custom_minimum_size = Vector2(0, 44)
	hub_close.pressed.connect(_toggle_mission_hub)
	hub_stack.add_child(hub_close)
	layer.add_child(mission_hub)
	_refresh_mission_hub()
	_build_evidence_dossier(layer)
	_apply_gamer_ui_style(layer)



func _build_evidence_dossier(layer: CanvasLayer) -> void:
	var open_button := Button.new()
	open_button.name = "EvidenceDossierButton"
	open_button.text = "DOSSIÊ / COMPARAR PROVAS"
	open_button.position = Vector2(18, 142)
	open_button.custom_minimum_size = Vector2(220, 44)
	open_button.pressed.connect(_toggle_evidence_dossier)
	layer.add_child(open_button)
	evidence_dossier_panel = PanelContainer.new()
	evidence_dossier_panel.name = "EvidenceDossierPanel"
	evidence_dossier_panel.anchor_left = 0.5
	evidence_dossier_panel.anchor_top = 0.5
	evidence_dossier_panel.anchor_right = 0.5
	evidence_dossier_panel.anchor_bottom = 0.5
	evidence_dossier_panel.offset_left = -minf(340.0, get_viewport().get_visible_rect().size.x * 0.45)
	evidence_dossier_panel.offset_top = -minf(250.0, get_viewport().get_visible_rect().size.y * 0.40)
	evidence_dossier_panel.offset_right = minf(340.0, get_viewport().get_visible_rect().size.x * 0.45)
	evidence_dossier_panel.offset_bottom = minf(250.0, get_viewport().get_visible_rect().size.y * 0.40)
	evidence_dossier_panel.visible = false
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 8)
	evidence_dossier_panel.add_child(box)
	var title := Label.new()
	title.text = "DOSSIÊ DE INVESTIGAÇÃO"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 20)
	box.add_child(title)
	evidence_dossier_status = Label.new()
	evidence_dossier_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	box.add_child(evidence_dossier_status)
	var row_a := HBoxContainer.new()
	box.add_child(row_a)
	var label_a := Label.new()
	label_a.text = "PROVA A"
	label_a.custom_minimum_size.x = 64
	row_a.add_child(label_a)
	evidence_select_a = OptionButton.new()
	evidence_select_a.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	evidence_select_a.custom_minimum_size.y = 42
	row_a.add_child(evidence_select_a)
	var row_b := HBoxContainer.new()
	box.add_child(row_b)
	var label_b := Label.new()
	label_b.text = "PROVA B"
	label_b.custom_minimum_size.x = 64
	row_b.add_child(label_b)
	evidence_select_b = OptionButton.new()
	evidence_select_b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	evidence_select_b.custom_minimum_size.y = 42
	row_b.add_child(evidence_select_b)
	var actions := HBoxContainer.new()
	box.add_child(actions)
	var compare := Button.new()
	compare.text = "COMPARAR"
	compare.custom_minimum_size.y = 44
	compare.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	compare.pressed.connect(_compare_selected_evidence)
	actions.add_child(compare)
	var close := Button.new()
	close.text = "FECHAR"
	close.custom_minimum_size.y = 44
	close.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	close.pressed.connect(_toggle_evidence_dossier)
	actions.add_child(close)
	evidence_comparison_text = RichTextLabel.new()
	evidence_comparison_text.bbcode_enabled = true
	evidence_comparison_text.scroll_active = true
	evidence_comparison_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	evidence_comparison_text.custom_minimum_size = Vector2(0, 145)
	evidence_comparison_text.text = "Recolhe pelo menos duas provas. O sistema distingue relações possíveis de factos confirmados."
	box.add_child(evidence_comparison_text)
	layer.add_child(evidence_dossier_panel)
	_refresh_evidence_dossier()

func _toggle_evidence_dossier() -> void:
	if evidence_dossier_panel:
		evidence_dossier_panel.visible = not evidence_dossier_panel.visible
		if evidence_dossier_panel.visible:
			_refresh_evidence_dossier()

func _evidence_catalog() -> Dictionary:
	# Descrições em estilo de relatório forense: observação, limite e próximo passo.
	# Os textos não identificam automaticamente o traidor nem revelam papéis secretos.
	return {
		1: ["Registo de admissão — cópia carbonada", "A folha apresenta pressão de escrita no campo da hora e uma correção feita com tinta diferente. O original não está no arquivo; a cópia, por si só, não identifica quem alterou o registo.", "Fotografa a folha antes de a manusear e compara a hora com o livro de entradas e o registo de chamadas internas."],
		2: ["Consentimento — formulário com anexo em falta", "O número de lote indicado no formulário não coincide com a listagem de amostras guardada no inventário. Não é possível concluir se houve falsificação ou erro de arquivo sem o documento original.", "Regista o número do lote e compara-o com os códigos de acesso e os registos científicos da mesma janela temporal."],
		3: ["Relatório de manutenção — circuito isolado", "A ordem de trabalho regista isolamento manual de um circuito. A assinatura está parcialmente borrada e falta a confirmação de fecho do serviço.", "Compara a hora da intervenção com o histórico de energia e a sequência de ativação; não atribuas a ação a uma pessoa sem confirmação."],
		4: ["Protocolo de incubação — folha de ciclos", "A folha contém três ciclos assinalados como rejeitados e uma leitura estável no ciclo 4. As anotações não explicam se as rejeições foram causadas por falha técnica ou por decisão operacional.", "Compara os horários com o registo automático do equipamento e separa os ciclos de teste dos ciclos autorizados."],
		5: ["Inventário de ferramentas — requisição por fechar", "Uma ferramenta de manutenção consta como levantada, mas o campo de devolução está vazio. A ausência de assinatura não prova que a ferramenta tenha sido usada na experiência.", "Verifica o armário de ferramentas, as ordens de trabalho e o histórico de acesso à zona técnica."],
		6: ["Relatório de contenção — marcas na barreira", "As fotografias anexas mostram riscos na face interior da barreira e resíduos junto à junta inferior. A imagem não permite determinar a direção do movimento nem a origem dos resíduos.", "Compara as fotografias com a inspeção da barreira, o registo de acessos e a planta da passagem selada."],
		7: ["Diário de laboratório — páginas com horários", "Duas anotações divergem da gravação de vigilância por alguns minutos. Sete alertas aparecem confirmados, mas os alertas de teste estão misturados no resumo exportado.", "Alinha os relógios das fontes antes de comparar eventos e exclui entradas marcadas TESTE; preserva a divergência como questão em aberto."],
		8: ["Ordem de segurança — autorização tardia", "A ordem tem uma hora de assinatura posterior ao encerramento registado da estação. O sistema não indica se foi assinada localmente ou sincronizada mais tarde.", "Compara o carimbo temporal, o histórico de autenticação e a ativação dos equipamentos abrangidos pela ordem."],
		9: ["Sequência de ativação — registo do controlador", "O controlador indica que o circuito 1 foi isolado primeiro e que a primeira leitura estável ocorreu no ciclo 4. O registo não inclui a identidade do operador.", "Compara a sequência com a folha de manutenção e o protocolo de incubação; verifica se os relógios dos equipamentos estavam sincronizados."],
		10: ["Gravação da experiência — fotogramas recuperados", "Os fotogramas mostram uma descontinuidade na parede e cablagem que não aparece na planta pública. A gravação não prova se o espaço foi construído depois ou omitido deliberadamente.", "Compara as dimensões no local com as plantas, as ordens de obra e o relatório de contenção antes de concluir que existe uma passagem."],
		11: ["Registo de manutenção secundário", "Uma segunda ordem menciona uma circulação técnica contínua junto ao arquivo, mas o mapa anexado está incompleto.", "Compara os números das portas e as marcas de desgaste com a planta rasurada."],
		12: ["Planta técnica rasurada", "O desenho revela duas entradas para um percurso que contorna a câmara central e regressa ao corredor principal.", "Compara a planta com a estrutura física antes de definir a sequência de acesso."]
	}

func _refresh_evidence_dossier() -> void:
	if evidence_select_a == null or evidence_select_b == null:
		return
	var catalog := _evidence_catalog()
	var old_a := int(evidence_select_a.get_item_metadata(evidence_select_a.selected)) if evidence_select_a.item_count > 0 and evidence_select_a.selected >= 0 else 0
	var old_b := int(evidence_select_b.get_item_metadata(evidence_select_b.selected)) if evidence_select_b.item_count > 0 and evidence_select_b.selected >= 0 else 0
	evidence_select_a.clear()
	evidence_select_b.clear()
	for raw_id in catalog.keys():
		var clue_id := int(raw_id)
		if not experiment_clues_found.has(clue_id):
			continue
		var item: Array = catalog[clue_id]
		for selector in [evidence_select_a, evidence_select_b]:
			selector.add_item("%02d · %s" % [clue_id, item[0]])
			selector.set_item_metadata(selector.item_count - 1, clue_id)
	if evidence_select_a.item_count > 0:
		var idx_a := _find_evidence_option(evidence_select_a, old_a)
		var idx_b := _find_evidence_option(evidence_select_b, old_b)
		evidence_select_a.select(idx_a if idx_a >= 0 else 0)
		evidence_select_b.select(idx_b if idx_b >= 0 else (1 if evidence_select_b.item_count > 1 else 0))
	if evidence_dossier_status:
		evidence_dossier_status.text = "PROVAS RECOLHIDAS: %d/12 · Só aparecem provas encontradas." % experiment_clues_found.size()
	if evidence_comparison_text and evidence_select_a.item_count < 2:
		evidence_comparison_text.text = "Recolhe pelo menos duas provas para comparar."

func _find_evidence_option(selector: OptionButton, clue_id: int) -> int:
	for i in range(selector.item_count):
		if int(selector.get_item_metadata(i)) == clue_id:
			return i
	return -1

func _compare_selected_evidence() -> void:
	if evidence_select_a == null or evidence_select_b == null or evidence_comparison_text == null:
		return
	if evidence_select_a.item_count < 2:
		evidence_comparison_text.text = "Ainda não existem duas provas recolhidas."
		return
	var id_a := int(evidence_select_a.get_item_metadata(evidence_select_a.selected))
	var id_b := int(evidence_select_b.get_item_metadata(evidence_select_b.selected))
	if id_a == id_b:
		evidence_comparison_text.text = "Seleciona duas provas diferentes."
		return
	var catalog := _evidence_catalog()
	var a: Array = catalog[id_a]
	var b: Array = catalog[id_b]
	var relation := "RELAÇÃO NÃO CONFIRMADA: os dados disponíveis não demonstram uma ligação direta. Trata a hipótese como provisória."
	if (id_a == 3 and id_b in [5, 9]) or (id_b == 3 and id_a in [5, 9]):
		relation = "RELAÇÃO POSSÍVEL: a manutenção pode explicar a interrupção seletiva. Confirma a sequência nos registos técnicos."
	elif (id_a == 4 and id_b == 9) or (id_b == 4 and id_a == 9):
		relation = "RELAÇÃO CRONOLÓGICA: três ciclos rejeitados antecedem a primeira leitura estável no ciclo 4."
	elif (id_a == 7 and id_b in [1, 8]) or (id_b == 7 and id_a in [1, 8]):
		relation = "INCONSISTÊNCIA A INVESTIGAR: compara horários do diário, registo administrativo e ordem de segurança."
	elif (id_a == 6 and id_b == 10) or (id_b == 6 and id_a == 10):
		relation = "PISTA ESPACIAL: as marcas interiores podem relacionar-se com a área omitida; a localização não está confirmada."
	elif (id_a == 2 and id_b in [1, 8]) or (id_b == 2 and id_a in [1, 8]):
		relation = "PISTA DE ACESSO: compara autorizações e documentação; não prova quem alterou o consentimento."
	# Regista apenas as combinações investigativas definidas como relevantes para desbloquear provas especiais.
	var pair := "%d-%d" % [mini(id_a, id_b), maxi(id_a, id_b)]
	var accepted_pairs := ["3-5", "4-9", "6-10", "7-10", "2-12"]
	if pair in accepted_pairs:
		evidence_comparisons_solved[pair] = true
		if not _is_solo_session() and multiplayer.is_server():
			rpc("client_sync_evidence_comparison", pair)
	elif not _is_solo_session() and not multiplayer.is_server():
		rpc_id(1, "server_register_evidence_comparison", pair)
	evidence_comparison_text.text = "[b]PROVA A — %s[/b]\n%s\n[b]A seguir:[/b] %s\n\n[b]PROVA B — %s[/b]\n%s\n[b]A seguir:[/b] %s\n\n[b]RESULTADO[/b]\n%s\n\n[font_size=12]Uma hipótese não identifica automaticamente o traidor nem revela os papéis secretos dos outros jogadores.[/font_size]" % [a[0], a[1], a[2], b[0], b[1], b[2], relation]

@rpc("any_peer", "call_remote", "reliable")
func server_register_evidence_comparison(pair: String) -> void:
	if not multiplayer.is_server() or pair not in ["3-5", "4-9", "6-10", "7-10", "2-12"]:
		return
	evidence_comparisons_solved[pair] = true
	rpc("client_sync_evidence_comparison", pair)

@rpc("authority", "call_remote", "reliable")
func client_sync_evidence_comparison(pair: String) -> void:
	if pair in ["3-5", "4-9", "6-10", "7-10", "2-12"]:
		evidence_comparisons_solved[pair] = true

func _toggle_mission_hub() -> void:
	if mission_hub == null:
		return
	mission_hub.visible = not mission_hub.visible
	if mission_hub.visible:
		_refresh_mission_hub()


func _set_mission_hub_tab(tab_name: String) -> void:
	mission_hub_tab = tab_name
	_refresh_mission_hub()


func _refresh_mission_hub() -> void:
	if mission_hub_body == null:
		return
	local_player_id = multiplayer.get_unique_id()
	var connected_count := multiplayer.get_peers().size() + 1 if multiplayer.multiplayer_peer != null else 1
	var objective_a := "CONCLUÍDO" if int(switch_owners.get("A", 0)) > 0 else "PENDENTE"
	var objective_b := "CONCLUÍDO" if int(switch_owners.get("B", 0)) > 0 else "PENDENTE"
	match mission_hub_tab:
		"OBJETIVOS":
			mission_hub_title.text = "OBJETIVOS DA EXPEDIÇÃO"
			if _is_solo_session():
				var evidence_objective := "Analisar os registos recolhidos" if experiment_clues_found.size() >= 12 else "Recolher provas e registos da estação"
				mission_hub_body.text = "MISSÃO: Estação Véspera — MODO INDIVIDUAL\n\n%s  Ativar o Relé A\n%s  Regressar e ativar o Relé B\n%s  Restabelecer a energia da câmara\n%s  Recolher as 12 provas exteriores e comparar os pares de evidências exigidos\n%s  %s\n\nAs provas especiais não são simples recolhas: exigem evidências anteriores e uma comparação válida no dossiê. Observa, compara e confirma antes de concluir." % ["✓" if objective_a == "CONCLUÍDO" else "○", "✓" if objective_b == "CONCLUÍDO" else "○", "✓" if coop_solved else "○", "✓" if experiment_clues_found.size() >= 12 else "○", "✓" if evidence_synthesis_complete else "○", evidence_objective]
			else:
				mission_hub_body.text = "MISSÃO: Estação Véspera\n\n%s  Ativar o Relé A\n%s  Ativar o Relé B\n%s  Usar dois participantes diferentes nos relés\n%s  Resolver o acesso à câmara de contenção\n\nTrabalha com outro jogador: os dois relés estão separados." % ["✓" if objective_a == "CONCLUÍDO" else "○", "✓" if objective_b == "CONCLUÍDO" else "○", "✓" if coop_solved else "○", "✓" if coop_solved else "○"]
		"INVENTÁRIO":
			mission_hub_title.text = "EQUIPAMENTO E INVENTÁRIO"
			mission_hub_body.text = "EQUIPAMENTO POLAR VISÍVEL\n• Parka térmica com capuz e proteção facial\n• Óculos de neve, luvas isolantes e botas polares\n• Mochila de sobrevivência e rádio de emergência\n• Lanterna — alternar no botão LANTERNA\n• Modo furtivo — botão AGACHAR\n\nA roupa é visual nesta revisão. Temperatura corporal, hipotermia e desgaste do equipamento ainda não são sistemas de sobrevivência funcionais."
		"EQUIPA":
			mission_hub_title.text = "ESTADO DA EQUIPA"
			var team_text := "Participantes na sessão: %d\n" % connected_count
			team_text += "Anfitrião: %s\n" % ("ligado" if multiplayer.multiplayer_peer != null else "sessão local")
			team_text += "Relé A: %s\nRelé B: %s\n" % ["ativo" if int(switch_owners.get("A", 0)) > 0 else "por ativar", "ativo" if int(switch_owners.get("B", 0)) > 0 else "por ativar"]
			team_text += "Cooperação: %s\n\nUsa a comunicação rápida abaixo para coordenar a equipa." % ("objetivo cooperativo concluído" if coop_solved else "a aguardar ações de participantes diferentes")
			mission_hub_body.text = team_text
		"DOSSIÊ":
			mission_hub_title.text = "DOSSIÊ PESSOAL"
			mission_hub_body.text = "REGISTO PRIVADO DO PARTICIPANTE\n\n%s\n\nAs pistas deste painel são pessoais. Partilha verbalmente a informação com a equipa; o painel não revela papéis secretos de outros jogadores." % (private_clue.text if private_clue != null else "Ainda não há registo disponível.")
	if quick_comms_status != null and multiplayer.multiplayer_peer == null:
		quick_comms_status.text = "Comunicação rápida: cria ou entra numa sessão LAN para enviar mensagens à equipa."


func _send_quick_comms(message: String) -> void:
	if multiplayer.multiplayer_peer == null:
		if quick_comms_status:
			quick_comms_status.text = "Sem sessão LAN. Abre REDE LAN e cria/entra numa sessão para comunicar."
		return
	if multiplayer.is_server():
		_apply_quick_comms(multiplayer.get_unique_id(), message)
		for peer_id in multiplayer.get_peers():
			rpc_id(int(peer_id), "receive_quick_comms", multiplayer.get_unique_id(), message)
	else:
		rpc_id(1, "server_quick_comms", message)


@rpc("any_peer", "call_remote", "reliable")
func server_quick_comms(message: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	_apply_quick_comms(sender, message)
	for peer_id in multiplayer.get_peers():
		if int(peer_id) != sender:
			rpc_id(int(peer_id), "receive_quick_comms", sender, message)


@rpc("authority", "call_remote", "reliable")
func receive_quick_comms(sender_id: int, message: String) -> void:
	_apply_quick_comms(sender_id, message)


func _apply_quick_comms(sender_id: int, message: String) -> void:
	if quick_comms_status:
		quick_comms_status.text = "EQUIPA · Jogador %d: %s" % [sender_id, message]
	if network_status:
		network_status.text = "Comunicação rápida · Jogador %d: %s" % [sender_id, message]


func _toggle_pause_menu() -> void:
	if game_paused_by_menu:
		game_paused_by_menu = false
		get_tree().paused = false
		return
	var pause_layer := get_node_or_null("PauseOverlay") as CanvasLayer
	if pause_layer:
		pause_layer.queue_free()
		pause_layer = null
	pause_layer = CanvasLayer.new()
	pause_layer.name = "PauseOverlay"
	pause_layer.layer = 120
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(pause_layer)
	var dim := ColorRect.new()
	dim.color = Color(0.005, 0.012, 0.018, 0.88)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(minf(420.0, get_viewport().get_visible_rect().size.x - 36.0), 0)
	center.add_child(panel)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 12)
	panel.add_child(stack)
	var heading := Label.new()
	heading.text = "EXPEDIÇÃO EM PAUSA"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 22)
	stack.add_child(heading)
	var resume := Button.new()
	resume.text = "RETOMAR EXPEDIÇÃO"
	resume.custom_minimum_size = Vector2(0, 48)
	resume.pressed.connect(func(): game_paused_by_menu = false; get_tree().paused = false; pause_layer.queue_free())
	stack.add_child(resume)
	var sound_info := Label.new()
	sound_info.text = "Áudio, ecrã e rede LAN estão disponíveis no menu de opções/rede. A sessão cooperativa não é terminada ao pausar."
	sound_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stack.add_child(sound_info)
	get_tree().paused = true
	game_paused_by_menu = true


func _gamer_style(bg: Color, border_color: Color, border_size: int = 1, radius: int = 8) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border_color
	style.set_border_width_all(border_size)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 12.0
	style.content_margin_right = 12.0
	style.content_margin_top = 7.0
	style.content_margin_bottom = 7.0
	return style


func _apply_gamer_ui_style(node: Node) -> void:
	# Tactical premium interface: deep blue-green surfaces, warm gold accents, large touch targets.
	if node is Button:
		var button := node as Button
		button.add_theme_stylebox_override("normal", _gamer_style(Color(0.035, 0.085, 0.105, 0.98), Color(0.14, 0.44, 0.49, 0.95), 1, 8))
		button.add_theme_stylebox_override("hover", _gamer_style(Color(0.07, 0.17, 0.19, 1.0), Color(0.82, 0.58, 0.28, 1.0), 2, 8))
		button.add_theme_stylebox_override("pressed", _gamer_style(Color(0.10, 0.20, 0.20, 1.0), Color(0.95, 0.72, 0.38, 1.0), 2, 8))
		button.add_theme_stylebox_override("focus", _gamer_style(Color(0.06, 0.15, 0.17, 1.0), Color(0.35, 0.82, 0.86, 1.0), 2, 8))
		button.add_theme_font_size_override("font_size", 15)
		button.add_theme_constant_override("outline_size", 1)
		button.add_theme_color_override("font_outline_color", Color(0.0, 0.025, 0.035, 0.95))
		button.add_theme_color_override("font_color", Color(0.91, 0.95, 0.96))
		button.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.55))
		button.add_theme_constant_override("shadow_offset_x", 1)
		button.add_theme_constant_override("shadow_offset_y", 1)
		button.add_theme_color_override("font_hover_color", Color(1.0, 0.84, 0.52))
		button.add_theme_color_override("font_pressed_color", Color(1.0, 0.88, 0.65))
		button.add_theme_color_override("font_focus_color", Color(1.0, 1.0, 1.0))
		button.add_theme_color_override("font_disabled_color", Color(0.40, 0.48, 0.52))
	elif node is PanelContainer:
		var panel := node as PanelContainer
		var panel_style := _gamer_style(Color(0.012, 0.028, 0.038, 0.94), Color(0.12, 0.48, 0.57, 0.98), 1, 12)
		panel_style.content_margin_left = 11.0
		panel_style.content_margin_right = 11.0
		panel_style.content_margin_top = 9.0
		panel_style.content_margin_bottom = 9.0
		panel.add_theme_stylebox_override("panel", panel_style)
	elif node is LineEdit:
		var edit := node as LineEdit
		edit.add_theme_stylebox_override("normal", _gamer_style(Color(0.02, 0.045, 0.06, 0.98), Color(0.12, 0.38, 0.46, 1.0), 1, 6))
		edit.add_theme_stylebox_override("focus", _gamer_style(Color(0.025, 0.065, 0.08, 1.0), Color(0.20, 0.88, 1.0, 1.0), 2, 6))
		edit.add_theme_color_override("font_color", Color(0.88, 0.96, 1.0))
		edit.add_theme_color_override("font_placeholder_color", Color(0.42, 0.58, 0.63))
	elif node is Label:
		var label := node as Label
		label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.9))
		label.add_theme_constant_override("outline_size", 1)
		label.add_theme_color_override("font_outline_color", Color(0.0, 0.018, 0.028, 0.82))
		label.add_theme_constant_override("shadow_offset_x", 1)
		label.add_theme_constant_override("shadow_offset_y", 1)
	for child in node.get_children():
		_apply_gamer_ui_style(child)


# Menu inicial gamer: configurações, ligação e regras detalhadas.
var main_menu_layer: CanvasLayer
var main_menu_content: VBoxContainer
var main_menu_ip: LineEdit
var menu_status_label: Label

func _build_main_menu() -> void:
	main_menu_layer = CanvasLayer.new()
	main_menu_layer.name = "MainMenu"
	main_menu_layer.layer = 100
	add_child(main_menu_layer)
	var menu_background := TextureRect.new()
	menu_background.name = "MenuCinematicBackground"
	menu_background.texture = load("res://art/menu_estacao_vespera.png") as Texture2D
	menu_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	menu_background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	menu_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	main_menu_layer.add_child(menu_background)
	var dim := ColorRect.new()
	# Escurece a arte para manter o texto e os controlos legíveis em telemóveis.
	dim.color = Color(0.008, 0.018, 0.028, 0.70)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main_menu_layer.add_child(dim)
	var outer := CenterContainer.new()
	outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	outer.offset_left = 18
	outer.offset_top = 12
	outer.offset_right = -18
	outer.offset_bottom = -12
	main_menu_layer.add_child(outer)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2( minf(620.0, get_viewport().get_visible_rect().size.x - 36.0), 0.0)
	outer.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	panel.add_child(root)
	var title := Label.new()
	title.text = "A ÚLTIMA EXPEDIÇÃO"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 26 if get_viewport().get_visible_rect().size.x < 520.0 else 30)
	title.add_theme_color_override("font_color", Color(0.96, 0.76, 0.43))
	root.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "UMA EXPEDIÇÃO. DUAS PERSPETIVAS. NENHUMA SAÍDA GARANTIDA."
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 13)
	subtitle.add_theme_color_override("font_color", Color(0.43, 0.82, 0.88))
	root.add_child(subtitle)
	var nav := GridContainer.new()
	# One column on narrow phones prevents clipped labels and tiny touch targets.
	nav.columns = 1 if get_viewport().get_visible_rect().size.x < 560.0 else 2
	nav.add_theme_constant_override("h_separation", 8)
	nav.add_theme_constant_override("v_separation", 8)
	root.add_child(nav)
	for item in [{"label":"JOGAR", "page":"play"}, {"label":"LIGAÇÃO WLAN", "page":"network"}, {"label":"SOM", "page":"sound"}, {"label":"VÍDEO", "page":"video"}, {"label":"REGRAS COMPLETAS", "page":"rules"}, {"label":"SAIR", "page":"exit"}]:
		var b := Button.new()
		b.text = item.label
		b.custom_minimum_size = Vector2(0, 46)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_show_main_menu_page.bind(item.page))
		nav.add_child(b)
	var sep := HSeparator.new()
	root.add_child(sep)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, minf(300.0, get_viewport().get_visible_rect().size.y * 0.40))
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(scroll)
	main_menu_content = VBoxContainer.new()
	main_menu_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_menu_content.add_theme_constant_override("separation", 8)
	scroll.add_child(main_menu_content)
	menu_status_label = Label.new()
	menu_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_status_label.add_theme_color_override("font_color", Color(0.58, 0.91, 0.78))
	root.add_child(menu_status_label)
	_apply_gamer_ui_style(main_menu_layer)
	_show_main_menu_page("home")
	_build_intro_screen()

func _build_intro_screen() -> void:
	intro_layer = CanvasLayer.new()
	intro_layer.name = "CinematicIntro"
	intro_layer.layer = 200
	add_child(intro_layer)
	var intro_background := TextureRect.new()
	intro_background.name = "IntroCinematicBackground"
	intro_background.texture = load("res://art/intro_estacao_vespera.png") as Texture2D
	intro_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	intro_background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	intro_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	intro_layer.add_child(intro_background)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.008, 0.018, 0.028, 0.48)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_layer.add_child(backdrop)
	var glow := ColorRect.new()
	glow.color = Color(0.04, 0.15, 0.18, 0.26)
	glow.anchor_left = 0.0
	glow.anchor_top = 0.35
	glow.anchor_right = 1.0
	glow.anchor_bottom = 0.72
	glow.offset_left = 0
	glow.offset_right = 0
	glow.offset_top = 0
	glow.offset_bottom = 0
	intro_layer.add_child(glow)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 24
	center.offset_right = -24
	intro_layer.add_child(center)
	var stack := VBoxContainer.new()
	stack.custom_minimum_size = Vector2(minf(560.0, get_viewport().get_visible_rect().size.x - 48.0), 0)
	stack.add_theme_constant_override("separation", 16)
	stack.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(stack)
	var overline := Label.new()
	overline.text = "REGISTO DE MISSÃO  /  ESTAÇÃO VÉSPERA"
	overline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overline.add_theme_font_size_override("font_size", 12)
	overline.add_theme_color_override("font_color", Color(0.38, 0.77, 0.81))
	stack.add_child(overline)
	var logo := Label.new()
	logo.text = "A ÚLTIMA\nEXPEDIÇÃO"
	logo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	logo.add_theme_font_size_override("font_size", 38 if get_viewport().get_visible_rect().size.x > 500 else 29)
	logo.add_theme_color_override("font_color", Color(0.95, 0.81, 0.57))
	stack.add_child(logo)
	var tagline := Label.new()
	tagline.text = "O QUE DESCOBRIRES LÁ DENTRO, LEVAS CONTIGO."
	tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tagline.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tagline.add_theme_font_size_override("font_size", 13)
	tagline.add_theme_color_override("font_color", Color(0.70, 0.80, 0.83))
	stack.add_child(tagline)
	var spacer := Control.new()
	spacer.custom_minimum_size.y = 28
	stack.add_child(spacer)
	intro_progress = ProgressBar.new()
	intro_progress.min_value = 0
	intro_progress.max_value = 100
	intro_progress.value = 0
	intro_progress.show_percentage = false
	intro_progress.custom_minimum_size = Vector2(0, 9)
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.08, 0.13, 0.15, 1)
	track.set_corner_radius_all(5)
	intro_progress.add_theme_stylebox_override("background", track)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.92, 0.55, 0.24, 1)
	fill.set_corner_radius_all(5)
	intro_progress.add_theme_stylebox_override("fill", fill)
	stack.add_child(intro_progress)
	intro_percent = Label.new()
	intro_percent.text = "000%"
	intro_percent.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	intro_percent.add_theme_font_size_override("font_size", 15)
	intro_percent.add_theme_color_override("font_color", Color(0.92, 0.94, 0.91))
	stack.add_child(intro_percent)
	var foot := Label.new()
	foot.text = "A PREPARAR A EXPEDIÇÃO · 4 SEGUNDOS"
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	foot.add_theme_font_size_override("font_size", 10)
	foot.add_theme_color_override("font_color", Color(0.43, 0.58, 0.62))
	stack.add_child(foot)
	main_menu_layer.visible = false
	intro_layer.visible = true
	intro_elapsed = 0.0

func _clear_menu_content() -> void:
	for child in main_menu_content.get_children():
		child.queue_free()

func _menu_heading(text_value: String) -> void:
	var heading := Label.new()
	heading.text = text_value
	heading.add_theme_font_size_override("font_size", 19)
	heading.add_theme_color_override("font_color", Color(0.35, 0.92, 1.0))
	main_menu_content.add_child(heading)

func _menu_text(text_value: String) -> void:
	var body := Label.new()
	body.text = text_value
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_font_size_override("font_size", 14)
	body.add_theme_color_override("font_color", Color(0.82, 0.88, 0.91))
	main_menu_content.add_child(body)

func _show_main_menu_page(page: String) -> void:
	_clear_menu_content()
	menu_status_label.text = ""
	match page:
		"home":
			_menu_heading("MENU PRINCIPAL")
			_menu_text("REGISTO DE MISSÃO 01\nHá vários dias que a Estação Véspera deixou de responder às comunicações externas. A última transmissão foi interrompida a meio de uma frase. A VANTHIS Corporation classificou o incidente como uma falha operacional e autorizou uma equipa a avaliar a situação. As condições meteorológicas estão a piorar e a janela de operação é limitada.\n\nMISSÃO: chegar à estação, restabelecer as comunicações, investigar o que aconteceu, recolher os dados necessários e encontrar uma forma de regressar em segurança. Não existe informação confirmada sobre o estado da equipa anterior.\n\nPara cooperar, os jogadores devem estar na mesma rede WLAN e um deles tem de criar a sessão.")
			var start := Button.new()
			start.text = "ENTRAR NA EXPEDIÇÃO"
			start.custom_minimum_size = Vector2(0, 48)
			start.pressed.connect(_close_main_menu)
			main_menu_content.add_child(start)
		"play":
			_menu_heading("PRONTO PARA JOGAR?")
			_menu_text("A exploração começa quando fechares este menu. Usa o joystick para te moveres, arrasta no lado direito para olhar e aproxima-te dos mecanismos para interagir. A cooperação completa requer um segundo jogador ligado.")
			var start := Button.new()
			start.text = "COMEÇAR / VOLTAR AO JOGO"
			start.custom_minimum_size = Vector2(0, 48)
			start.pressed.connect(_close_main_menu)
			main_menu_content.add_child(start)
		"network":
			_menu_heading("LIGAÇÃO AO JOGO · WLAN")
			_menu_text("Sem internet: liga os dois telemóveis à mesma rede Wi-Fi ou ao ponto de acesso de um deles. O anfitrião cria a sessão e partilha o IP mostrado. O segundo jogador introduz esse IP abaixo e carrega em LIGAR.")
			var host := Button.new()
			host.text = "CRIAR SESSÃO (ANFITRIÃO)"
			host.custom_minimum_size = Vector2(0, 44)
			host.pressed.connect(_menu_host_session)
			main_menu_content.add_child(host)
			var ip_label := Label.new()
			ip_label.text = "IP DO ANFITRIÃO"
			main_menu_content.add_child(ip_label)
			main_menu_ip = LineEdit.new()
			main_menu_ip.placeholder_text = "Ex.: 192.168.1.77"
			main_menu_ip.text = ""
			main_menu_ip.custom_minimum_size = Vector2(0, 42)
			main_menu_content.add_child(main_menu_ip)
			var join := Button.new()
			join.text = "LIGAR À SESSÃO"
			join.custom_minimum_size = Vector2(0, 44)
			join.pressed.connect(_menu_join_session)
			main_menu_content.add_child(join)
			_menu_text("Se a ligação falhar, confirma o IP, que ambos estão na mesma WLAN e que a rede não bloqueia a comunicação entre dispositivos. A porta de jogo é UDP %d." % PORT)
		"sound":
			_menu_heading("DEFINIÇÕES DE SOM")
			_menu_text("Ajusta o volume geral e da música. As alterações aplicam-se imediatamente.")
			_add_volume_slider("Volume geral", "Master", 1.0)
			_add_volume_slider("Música ambiente", "Music", 0.55)
			_add_volume_slider("Efeitos e vozes", "SFX", 0.8)
			_menu_text("Se os buses Music ou SFX não existirem no projeto, os controlos correspondentes ficam indisponíveis; o volume geral continua disponível.")
		"video":
			_menu_heading("DEFINIÇÕES DE VÍDEO")
			_menu_text("As opções de vídeo são locais neste dispositivo. Em telemóveis, o modo de ecrã inteiro é normalmente o comportamento recomendado.")
			var fullscreen := Button.new()
			fullscreen.text = "ALTERNAR ECRÃ INTEIRO"
			fullscreen.custom_minimum_size = Vector2(0, 44)
			fullscreen.pressed.connect(_toggle_fullscreen)
			main_menu_content.add_child(fullscreen)
			var brightness_label := Label.new()
			brightness_label.text = "Brilho da interface (pré-visualização)"
			main_menu_content.add_child(brightness_label)
			var brightness := HSlider.new()
			brightness.min_value = 0.65
			brightness.max_value = 1.35
			brightness.step = 0.05
			brightness.value = 1.0
			brightness.value_changed.connect(_set_ui_brightness)
			main_menu_content.add_child(brightness)
			_menu_text("A qualidade gráfica depende também das capacidades do dispositivo e das definições de renderização do projeto.")
		"exit":
			_menu_heading("SAIR DA EXPEDIÇÃO?")
			_menu_text("Fecha a aplicação. Se estiveres numa sessão cooperativa, avisa o outro jogador antes de sair.")
			var quit_button := Button.new()
			quit_button.text = "CONFIRMAR SAÍDA"
			quit_button.custom_minimum_size = Vector2(0, 46)
			quit_button.pressed.connect(get_tree().quit)
			main_menu_content.add_child(quit_button)
		"rules":
			_menu_heading("REGRAS DA EXPEDIÇÃO — GUIA DETALHADO")
			_menu_text("1. OBJETIVO\nInvestiga a Estação Véspera, recolhe pistas e decide como responder à presença desconhecida. Sobrevive e conclui os objetivos da missão.")
			_menu_text("2. MOVIMENTO E EXPLORAÇÃO\nUsa o joystick para caminhar e arrasta na zona direita para orientar a câmara. A lanterna ajuda a observar áreas escuras. Agacha-te quando precisares de avançar com cautela.")
			_menu_text("3. INTERAÇÃO\nAproxima-te de um mecanismo e carrega em INTERAGIR. Se estiveres demasiado longe, a ação não será executada. Observa as mensagens do jogo para perceber o resultado.")
			_menu_text("4. COOPERAÇÃO\nNo modo cooperativo, cada jogador deve comunicar as pistas e cumprir a sua parte. Os relés A e B exigem colaboração. A porta só deve abrir quando o objetivo cooperativo for concluído pelo sistema.")
			_menu_text("5. WLAN\nUm jogador cria a sessão e partilha o IP local apresentado. O outro introduz esse IP e liga-se. Ambos devem estar na mesma rede local. 127.0.0.1 nunca é o IP a partilhar com outro dispositivo.")
			_menu_text("6. ENTIDADE E CALOR\nOs indicadores térmicos representam deteções simuladas do jogo, não sensores físicos. Um sinal pode indicar proximidade; não garante que a entidade esteja visível. Usa o ambiente sonoro e visual para avaliar o risco.")
			_menu_text("7. DECISÕES\nQuando surgir uma escolha, lê as pistas e discute-as com o outro jogador antes de selecionar ACUSAR ou DEFENDER. As decisões podem alterar o rumo da missão.")
			_menu_text("8. DERROTA, FALHAS E RECONEXÃO\nSe perderes a ligação, verifica a WLAN e o IP do anfitrião e tenta ligar novamente. Não assumas que uma sessão está ligada até o painel confirmar o estado. Esta versão é um protótipo: algumas regras e funcionalidades ainda podem estar em desenvolvimento.")
			_menu_text("9. JOGO RESPONSÁVEL\nJoga com som num nível confortável. Faz pausas se os efeitos de suspense te causarem desconforto.")
	_apply_gamer_ui_style(main_menu_content)

func _close_main_menu() -> void:
	if main_menu_layer:
		main_menu_layer.visible = false

func _menu_host_session() -> void:
	host_game()
	if menu_status_label and network_status:
		menu_status_label.text = network_status.text

func _menu_join_session() -> void:
	if main_menu_ip and ip_input:
		ip_input.text = main_menu_ip.text.strip_edges()
	join_game()
	if menu_status_label and network_status:
		menu_status_label.text = network_status.text

func _add_volume_slider(label_text: String, bus_name: String, default_value: float) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	var label := Label.new()
	label.text = label_text + (" (indisponível)" if bus_index < 0 else "")
	main_menu_content.add_child(label)
	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = default_value
	slider.editable = bus_index >= 0
	slider.value_changed.connect(_set_bus_volume.bind(bus_name))
	main_menu_content.add_child(slider)

func _set_bus_volume(value: float, bus_name: String) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	if bus_index >= 0:
		AudioServer.set_bus_volume_db(bus_index, linear_to_db(maxf(value, 0.001)))
		AudioServer.set_bus_mute(bus_index, value <= 0.001)

func _toggle_fullscreen() -> void:
	if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

func _set_ui_brightness(value: float) -> void:
	if main_menu_layer:
		main_menu_layer.modulate = Color(value, value, value, 1.0)

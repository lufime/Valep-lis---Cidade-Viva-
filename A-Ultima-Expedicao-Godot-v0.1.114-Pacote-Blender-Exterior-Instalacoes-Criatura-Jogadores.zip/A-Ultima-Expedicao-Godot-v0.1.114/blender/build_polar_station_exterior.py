# A Última Expedição — Exterior da estação polar
# Abrir no Blender > Scripting > Run Script. Exporta assets/polar_station_exterior.glb.
import bpy, math, os
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
def material(name, color, metallic=0.15, roughness=0.78):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    bs=m.node_tree.nodes.get("Principled BSDF"); bs.inputs["Base Color"].default_value=(*color,1)
    bs.inputs["Metallic"].default_value=metallic; bs.inputs["Roughness"].default_value=roughness
    return m
snow=material("Snow_Ice",(0.78,0.88,0.92)); ice=material("Blue_Ice",(0.22,0.43,0.54))
metal=material("Station_Composite",(0.22,0.29,0.33)); dark=material("Dark_Metal",(0.07,0.10,0.13))
orange=material("Emergency_Orange",(0.92,0.28,0.08)); window=material("Frosted_Window",(0.12,0.45,0.58))
rock=material("Basalt_Rock",(0.17,0.20,0.23))
def cube(name, loc, scale, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc); o=bpy.context.object; o.name=name
    o.dimensions=scale; bpy.ops.object.transform_apply(location=False, rotation=False, scale=True); o.data.materials.append(mat); return o
def cyl(name, loc, radius, depth, mat):
    bpy.ops.mesh.primitive_cylinder_add(vertices=12, radius=radius, depth=depth, location=loc); o=bpy.context.object; o.name=name; o.data.materials.append(mat); return o
def ico(name, loc, scale, mat):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=1, location=loc); o=bpy.context.object; o.name=name; o.scale=scale; o.data.materials.append(mat); return o
cube("Snow_Base",(0,-.5,0),(46,.8,46),snow)
cube("Station_Main_Hull",(0,2,0),(16,4.2,8),metal); cube("Station_Roof",(0,4.32,0),(16.6,.45,8.6),dark)
cube("Front_Safety_Band",(0,1.15,4.06),(16.05,.35,.12),orange)
cube("Main_Airlock",(0,1.35,4.12),(2,2.6,.22),dark); cube("Airlock_Window",(0,1.85,4.25),(.8,.9,.05),window)
for x in [-6,-3,3,6]: cube("Front_Window_"+str(x),(x,2.55,4.12),(1.5,1,.12),window)
cube("Laboratory_Module",(10.5,1.5,-1.5),(6,3.2,5),metal); cube("Lab_Roof",(10.5,3.25,-1.5),(6.4,.35,5.4),dark)
cube("Lab_Window",(10.5,2,1.05),(2.2,1,.1),window)
cyl("Antenna_Mast",(-7,4.2,-3),.12,8,dark)
for y in [5.5,7,8]: cube("Antenna_Crossbar_"+str(y),(-7,y,-3),(2.4,.12,.12),orange)
cyl("Dish_Post",(7,5.1,-2),.08,2,dark)
for x in [-8,8]:
    cyl("Lamp_Post_"+str(x),(x,1.5,5.5),.09,3,dark); cube("Lamp_Head_"+str(x),(x,3.05,5.5),(.55,.18,.35),orange)
for i,(x,z) in enumerate([(-11,2),(-11,4),(-9,3),(13,-3),(13,-5)]): cube("Supply_Crate_"+str(i),(x,.6,z),(1.3,1.2,1.2),orange if i%2==0 else metal)
for i,x in enumerate([-4,4]): cube("Generator_"+str(i),(x,.6,-6),(2,1.2,1.5),dark)
for i,(x,z,s) in enumerate([(-18,-12,2.5),(-16,9,2.2),(18,12,3),(19,-8,2.6),(-13,-18,2.4),(10,18,2),(-20,2,2.2),(4,-19,2.8)]): ico("Snow_Rock_"+str(i),(x,s*.25,z),(s*1.3,s*.65,s),rock if i%2 else snow)
for i,(x,z) in enumerate([(-20,-18),(-14,-21),(-4,-21),(8,-21),(17,-17),(21,-7),(21,8),(16,21),(-18,19)]): ico("Ice_Ridge_"+str(i),(x,.2,z),(2.2,1.5,3.2),ice)
# export selected exterior model to GLB beside this script
out=os.path.join(os.path.dirname(bpy.data.filepath) or bpy.path.abspath("//"),"polar_station_exterior.glb")
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.gltf(filepath=out, export_format='GLB', use_selection=True)
print("Exportado:", out)

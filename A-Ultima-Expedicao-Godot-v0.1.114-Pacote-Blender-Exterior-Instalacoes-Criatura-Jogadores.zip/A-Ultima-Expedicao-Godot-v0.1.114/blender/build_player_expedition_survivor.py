# A Última Expedição — Jogador humano 3D de expedição
# Executar no Blender 4.x: Scripting > Run Script.
# Gera personagem editável, armature de referência e exporta GLB.
import bpy, math, os
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.armatures):
    pass
def mat(name, color, metallic=0.05, roughness=0.8):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    bs=m.node_tree.nodes.get("Principled BSDF")
    bs.inputs["Base Color"].default_value=(*color,1); bs.inputs["Metallic"].default_value=metallic; bs.inputs["Roughness"].default_value=roughness
    return m
fabric=mat("Expedition_Suit_Deep_Teal",(0.07,.20,.24)); orange=mat("Rescue_Orange",(.95,.25,.055))
black=mat("Boots_Gloves",(.035,.05,.06)); visor=mat("Helmet_Visor",(.10,.24,.30),.65,.28)
skin=mat("Face_Skin",(.62,.43,.31)); pack=mat("Survival_Backpack",(.13,.17,.18)); metal=mat("Equipment_Metal",(.35,.41,.43),.45,.4)
def cube(n,loc,scale,ma):
    bpy.ops.mesh.primitive_cube_add(size=1,location=loc); o=bpy.context.object; o.name=n; o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); o.data.materials.append(ma); return o
def uv(n,loc,scale,ma):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=1,location=loc); o=bpy.context.object; o.name=n; o.scale=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True); o.data.materials.append(ma); return o
def cyl(n,loc,r,depth,ma):
    bpy.ops.mesh.primitive_cylinder_add(vertices=12,radius=r,depth=depth,location=loc); o=bpy.context.object; o.name=n; o.data.materials.append(ma); return o
# boots and legs
cube("Boot_Left",(-.24,.12,.12),(.34,.22,.52),black); cube("Boot_Right",(.24,.12,.12),(.34,.22,.52),black)
for side,x in [('Left',-.24),('Right',.24)]:
    cyl(side+"_Leg",(x,.68,0),.17,.74,fabric); uv(side+"_Knee",(x,.75,.16),(.18,.15,.09),black)
cube("Waist_Belt",(0,1.16,0),(.58,.18,.34),black)
uv("Torso",(0,1.55,0),(.43,.60,.27),fabric)
cube("Chest_Rescue_Panel",(0,1.63,.285),(.38,.22,.06),orange); cube("Chest_ID_Plate",(0,1.72,.326),(.16,.08,.035),metal)
for side,x in [('Left',-.48),('Right',.48)]:
    uv(side+"_Shoulder",(x,1.78,0),(.19,.19,.19),orange)
    cyl(side+"_UpperArm",(x*1.08,1.48,0),.13,.42,fabric)
    cyl(side+"_Forearm",(x*1.145,1.16,.06),.12,.36,fabric)
    uv(side+"_Glove",(x*1.145,.91,.08),(.13,.12,.13),black)
cyl("Neck",(0,1.95,0),.12,.18,skin); uv("Head",(0,2.20,.015),(.22,.27,.20),skin)
uv("Helmet",(0,2.36,0),(.27,.22,.25),orange); cube("Visor",(0,2.25,.205),(.34,.13,.055),visor)
cube("Helmet_Lamp",(0,2.43,.24),(.10,.055,.06),metal)
cube("Backpack_Main",(0,1.58,-.30),(.43,.54,.22),pack); cube("Backpack_Top",(0,1.90,-.30),(.32,.16,.24),orange)
cube("Backpack_Reflective_Stripe",(0,1.58,-.425),(.45,.07,.035),orange); cube("Radio",(.38,1.44,-.08),(.12,.22,.10),black)
cyl("Radio_Antenna",(.38,1.68,-.08),.018,.28,metal)
for i,x in enumerate([-.34,.34]): cube("Belt_Pouch_"+str(i),(x,1.16,.22),(.14,.18,.12),orange)
for side,x in [('Left',-.24),('Right',.24)]: cube(side+"_Harness",(x,1.58,.29),(.07,.48,.045),orange)
# Reference armature. This is a starting rig; geometry is not yet skinned for deforming animation.
bpy.ops.object.select_all(action='DESELECT')
bpy.ops.object.armature_add(enter_editmode=True, location=(0,0,0))
arm=bpy.context.object; arm.name="Player_Armature"; arm.data.name="Player_Skeleton"
eb=arm.data.edit_bones; root=eb[0]; root.name="Root"; root.head=(0,.1,0); root.tail=(0,.5,0)
def bone(name,head,tail,parent="Root"):
    b=eb.new(name); b.head=head; b.tail=tail; b.parent=eb.get(parent)
bone("Spine",(0,.5,0),(0,1.6,0)); bone("Neck",(0,1.6,0),(0,2.0,0),"Spine"); bone("Head",(0,2.0,0),(0,2.4,0),"Neck")
bone("UpperArm.L",(-.4,1.8,0),(-.55,1.3,0),"Spine"); bone("LowerArm.L",(-.55,1.3,0),(-.55,.95,0),"UpperArm.L")
bone("UpperArm.R",(.4,1.8,0),(.55,1.3,0),"Spine"); bone("LowerArm.R",(.55,1.3,0),(.55,.95,0),"UpperArm.R")
bone("Leg.L",(-.24,1.0,0),(-.24,.2,0),"Root"); bone("Leg.R",(.24,1.0,0),(.24,.2,0),"Root")
bpy.ops.object.mode_set(mode='OBJECT')
# Export all model parts and armature to GLB; rigid prototype geometry retained as separate meshes.
bpy.ops.object.select_all(action='SELECT')
out=os.path.join(os.path.dirname(bpy.data.filepath) or bpy.path.abspath("//"),"player_expedition_survivor.glb")
bpy.ops.export_scene.gltf(filepath=out,export_format='GLB',use_selection=True)
print("Exportado:",out)

# Blender 4.x — criatura da Última Expedição: gera .blend editável e GLB.
import bpy, math, os
from mathutils import Vector
root=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
assets=os.path.join(root,'assets'); os.makedirs(assets,exist_ok=True)
for o in list(bpy.data.objects): bpy.data.objects.remove(o,do_unlink=True)
def mat(n,c,metal=0,rough=.7):
 m=bpy.data.materials.new(n); m.diffuse_color=(*c,1); m.use_nodes=True; p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*c,1); p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
hide=mat('Creature_Skin_Charcoal',(.035,.055,.06),.15,.4); bone=mat('Pale_Bone',(.45,.52,.49),.1,.55); eye=mat('Bioluminescent_Eye',(.7,.025,.012),.2,.25); claw=mat('Claws',(.13,.15,.15),.35,.3)
def ell(n,loc,scale,ma):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma);return o
def cone(n,a,b,r1,r2,ma):
 d=Vector(b)-Vector(a);mid=(Vector(a)+Vector(b))/2;bpy.ops.mesh.primitive_cone_add(vertices=12,radius1=r1,radius2=r2,depth=d.length,location=mid);o=bpy.context.object;o.name=n;o.rotation_mode='QUATERNION';o.rotation_quaternion=d.to_track_quat('Z','Y');o.data.materials.append(ma);return o
ell('Creature_Torso',(0,1.65,0),(.55,.85,.36),hide);ell('Creature_Thorax',(0,1.25,.02),(.48,.55,.34),hide);ell('Creature_Skull',(0,2.48,.12),(.36,.43,.32),hide)
for s in [-1,1]:
 ell('Eye_'+str(s),(s*.22,2.53,.39),(.075,.09,.035),eye)
 cone('Horn_'+str(s),(s*.23,2.75,.08),(s*.43,3.15,.06),.13,.015,bone)
 cone('Arm_'+str(s),(s*.38,2.08,0),(s*.63,1.43,.05),.19,.12,hide);ell('Hand_'+str(s),(s*.65,1.36,.08),(.16,.13,.16),hide)
 for i in range(3): cone('Claw_'+str(s)+'_'+str(i),(s*(.58+i*.07),1.33,.17),(s*(.62+i*.07),1.12,.19),.045,.005,claw)
 cone('Leg_'+str(s),(s*.23,1.05,0),(s*.28,.28,.06),.23,.13,hide);ell('Foot_'+str(s),(s*.29,.17,.18),(.22,.13,.36),hide)
for i in range(7): ell('Dorsal_Ridge_'+str(i),(0,2.15-i*.17,-.30),(.12,.11,.16),bone)
# Armature, with root/spine/head/limbs for later animation authoring
bpy.ops.object.armature_add(enter_editmode=True); arm=bpy.context.object;arm.name='Creature_Armature';eb=arm.data.edit_bones;eb[0].name='Root';eb[0].head=(0,0,0);eb[0].tail=(0,.5,0)
def bn(n,h,t,p): b=eb.new(n);b.head=h;b.tail=t;b.parent=eb.get(p)
bn('Spine',(0,.5,0),(0,1.8,0),'Root');bn('Head',(0,1.8,0),(0,2.7,0),'Spine')
for s in [-1,1]: bn('Arm.'+str(s),(s*.3,2,0),(s*.65,1.35,0),'Spine');bn('Leg.'+str(s),(s*.2,1.1,0),(s*.28,.2,0),'Root')
bpy.ops.object.mode_set(mode='OBJECT')
# Save native source and export all geometry. Note: geometry is not yet skinned to this armature.
bpy.ops.object.select_all(action='SELECT');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(assets,'creature_entity.blend'));bpy.ops.export_scene.gltf(filepath=os.path.join(assets,'entity_creature.glb'),export_format='GLB',use_selection=True)
print('Criatura .blend e GLB exportados')

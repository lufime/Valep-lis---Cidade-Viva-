CORREÇÃO DO BUILD — A ÚLTIMA EXPEDIÇÃO 3D

O erro atual ocorre porque o workflow que está no GitHub foi escrito para uma aplicação web/Capacitor e exige package.json, capacitor.config.json e www/index.html. O projeto entregue é Godot 4.5 e tem project.godot, pelo que o workflow antigo rejeita corretamente o ZIP.

AÇÃO NECESSÁRIA NO GITHUB:
1. Abra o repositório e vá a .github/workflows.
2. Edite o workflow que apresenta o erro “Nenhum ZIP contém package.json, capacitor.config.json e www/index.html”.
3. Substitua TODO o conteúdo desse workflow pelo conteúdo de .github/workflows/build.yml deste pacote. Para evitar dois workflows a correr em paralelo, desative/remova o workflow antigo depois de confirmar que foi substituído.
4. Confirme que o ZIP A-Ultima-Expedicao-3D-v0.1.8-VALIDACAO-CORRIGIDA.zip está na raiz do repositório (ou numa subpasta); não é necessário extrair o ZIP no GitHub.
5. Vá a Actions, escolha “A Última Expedição — Godot 4.5 Android Build” e execute Run workflow.
6. Se falhar, descarregue os logs/artifacts e partilhe-os.

Este workflow procura project.godot dentro dos ZIPs e executa importação, teste de arranque headless e exportação APK. A APK só existirá se todas as etapas passarem. O workflow ainda precisa de ser executado no GitHub para confirmar o resultado real.

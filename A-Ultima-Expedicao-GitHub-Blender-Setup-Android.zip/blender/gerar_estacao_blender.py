# A Última Expedição — Estação Modular Completa
# Blender 4.x / 5.x
# Uso: Blender > Scripting > Open > executar este ficheiro.
# Gera a cena, guarda .blend e exporta GLB para Godot.
import bpy, math, os
from mathutils import Vector

# ---------- CONFIGURAÇÃO ----------
OUTPUT_DIR = os.environ.get("OUTPUT_DIR", bpy.path.abspath("//") if bpy.data.filepath else os.path.expanduser("~/A_Ultima_Expedicao_Blender"))
BLEND_NAME = "A_Ultima_Expedicao_Estacao_Completa.blend"
GLB_NAME = "A_Ultima_Expedicao_Estacao_Completa.glb"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# Limpar a cena
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.materials, bpy.data.curves, bpy.data.meshes, bpy.data.cameras, bpy.data.lights):
    for block in list(datablocks):
        if block.users == 0:
            datablocks.remove(block)

# Coleções organizadas
def collection(name):
    c = bpy.data.collections.new(name)
    bpy.context.scene.collection.children.link(c)
    return c

COL = {
    "Architecture": collection("01_ARQUITETURA"),
    "Details": collection("02_DETALHES"),
    "Props": collection("03_EQUIPAMENTO"),
    "Lights": collection("04_ILUMINACAO"),
    "Signs": collection("05_SINALIZACAO"),
    "Cameras": collection("06_CAMERAS"),
}
CURRENT = "Architecture"

def move_to(obj, key=None):
    key = key or CURRENT
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    COL[key].objects.link(obj)
    return obj

def mat(name, color, metallic=0.0, rough=0.45, emission=None, strength=0.0):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get("Principled BSDF")
    bs.inputs["Base Color"].default_value = (*color, 1)
    bs.inputs["Metallic"].default_value = metallic
    bs.inputs["Roughness"].default_value = rough
    if emission:
        if "Emission Color" in bs.inputs:
            bs.inputs["Emission Color"].default_value = (*emission, 1)
            bs.inputs["Emission Strength"].default_value = strength
        elif "Emission" in bs.inputs:
            bs.inputs["Emission"].default_value = (*emission, 1)
    return m

M = {
    "hull": mat("Hull | titanium graphite", (0.105,0.14,0.17), .72, .32),
    "panel": mat("Panels | brushed steel", (.27,.34,.38), .68, .3),
    "dark": mat("Rubber | deep charcoal", (.025,.035,.042), .12, .7),
    "floor": mat("Deck | anti-slip composite", (.12,.16,.18), .45, .62),
    "white": mat("Ceramic | off white", (.72,.78,.78), .24, .3),
    "cyan": mat("System | cyan", (.02,.55,.72), .35, .25, (.02,.45,.8), 1.7),
    "red": mat("Warning | red", (.7,.035,.025), .2, .3, (1,.015,.005), 2.5),
    "amber": mat("Warning | amber", (.95,.32,.025), .15, .3, (1,.18,.005), 1.8),
    "green": mat("Status | green", (.03,.48,.2), .15, .3, (.01,.8,.12), 1.2),
    "glass": mat("Glass | dark blue", (.015,.07,.095), .4, .18),
    "screen": mat("Display | interface blue", (.005,.08,.13), .12, .22, (.0,.3,.65), 1.0),
    "stain": mat("Scorch | old damage", (.055,.035,.025), .0, .9),
}

def cube(name, loc, scale, material, bevel=0, key=None):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o = bpy.context.object
    o.name = name
    o.dimensions = scale
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if material: o.data.materials.append(material)
    if bevel:
        mod = o.modifiers.new("Edge highlights", "BEVEL")
        mod.width = bevel
        mod.segments = 2
        o.modifiers.new("Weighted corner normals", "WEIGHTED_NORMAL")
    return move_to(o, key)

def cyl(name, loc, radius, depth, material, rotation=(0,0,0), key="Details", vertices=16):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=loc, rotation=rotation)
    o=bpy.context.object; o.name=name
    if material: o.data.materials.append(material)
    return move_to(o,key)

def text_obj(body, loc, size, material, rot=(math.pi/2,0,0), key="Signs"):
    cu=bpy.data.curves.new("Text_"+body.replace(" ","_"), 'FONT')
    cu.body=body; cu.size=size; cu.extrude=.001
    ob=bpy.data.objects.new(body,cu); COL[key].objects.link(ob)
    ob.location=loc; ob.rotation_euler=rot
    if material: cu.materials.append(material)
    return ob

def area_light(name, loc, energy, color, size, target):
    data=bpy.data.lights.new(name,'AREA'); data.energy=energy; data.color=color; data.shape='RECTANGLE'; data.size=size; data.size_y=size*.35
    o=bpy.data.objects.new(name,data); COL["Lights"].objects.link(o); o.location=loc
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    return o

# Architectural coordinate system: X east-west, Y north-south, Z up.
# Main corridor connects five room modules; all units are metres.
def floor_box(x,y,w,d,material=None,name="Deck"):
    return cube(name,(x,y,-.12),(w,d,.24),material or M["floor"],.035)

def wall(x,y,z,w,d,h,material=None,name="Bulkhead"):
    return cube(name,(x,y,z),(w,d,h),material or M["hull"],.045)

def door_frame(cx, y, label="AIRLOCK"):
    # wall plane faces corridor on +Y
    wall(cx-1.05,y,1.45,.16,.22,2.9,M["panel"],"Door frame L")
    wall(cx+1.05,y,1.45,.16,.22,2.9,M["panel"],"Door frame R")
    wall(cx,y,2.83,2.25,.22,.14,M["panel"],"Door lintel")
    cube("Sliding blast door",(cx,y+.03,1.35),(1.82,.12,2.55),M["dark"],.035,"Architecture")
    cube("Door status strip",(cx,y-.045,2.57),(1.45,.025,.055),M["cyan"],.01,"Details")
    for dx in (-.83,.83):
        cube("Door red indicator",(cx+dx,y-.09,1.4),(.035,.025,.38),M["red"],.006,"Details")
    text_obj(label,(cx-.7,y-.105,2.1),.12,M["white"])

def wall_panel_run(y, x1, x2, z=2.35):
    x=x1
    while x <= x2:
        cube("Wall inset panel",(x,y,z),(.78,.055,.9),M["panel"],.025,"Details")
        cube("Panel seam",(x,y-.034,z),(.018,.012,.78),M["dark"],.003,"Details")
        x+=.95

def ceiling_lamp(x,y,color="cyan"):
    cube("Recessed light housing",(x,y,3.18),(.85,.22,.09),M["dark"],.025,"Details")
    cube("LED diffuser",(x,y,3.125),(.68,.12,.025),M[color],.01,"Details")

def vent(x,y,z=2.65, vertical=False):
    for i in range(7):
        cube("Vent slat",(x+i*.075-.225,y,z),(.025,.035,.42),M["dark"],.004,"Details")
    cube("Vent border",(x,y,z+.23),(.62,.05,.035),M["panel"],.005,"Details")
    cube("Vent border",(x,y,z-.23),(.62,.05,.035),M["panel"],.005,"Details")

def console(x,y,z=1.15,w=1.5):
    cube("Console pedestal",(x,y,z-.28),(w,.52,.65),M["hull"],.045,"Props")
    cube("Console top",(x,y-.04,z+.07),(w+.08,.62,.12),M["panel"],.025,"Props")
    cube("Touchscreen",(x,y-.20,z+.43),(w*.82,.055,.45),M["screen"],.018,"Props")
    for i in range(4):
        cube("Console key",(x-w*.32+i*w*.21,y-.24,z+.10),(.09,.045,.035),M["cyan"] if i==0 else M["dark"],.006,"Props")

def cabinet(x,y,z=1.2,label="SUPPLIES"):
    cube("Storage cabinet",(x,y,z),(.75,.48,1.55),M["panel"],.035,"Props")
    for zz in (.75,1.15,1.55):
        cube("Cabinet door seam",(x,y-.247,zz),(.65,.012,.018),M["dark"],.002,"Details")
    cube("Cabinet label plate",(x,y-.258,1.75),(.42,.018,.12),M["dark"],.006,"Props")
    text_obj(label,(x-.19,y-.272,1.72),.065,M["white"])

def pipe_run(start,end,r=.045,material=None):
    a,b=Vector(start),Vector(end); delta=b-a
    mid=(a+b)/2
    ob=cyl("Utility conduit",mid,r,delta.length,material or M["panel"],key="Details",vertices=12)
    ob.rotation_euler=delta.to_track_quat('Z','Y').to_euler()
    return ob

def sign_panel(x,y,z,label,color="cyan"):
    cube("Wayfinding sign",(x,y,z),(.8,.07,.28),M["dark"],.02,"Signs")
    cube("Sign light",(x,y-.041,z),(.68,.012,.035),M[color],.005,"Signs")
    text_obj(label,(x-.32,y-.05,z-.045),.105,M["white"])

# Main corridor: 4m wide, 30m long, room branches on both sides
floor_box(0,0,4.2,32,name="Main corridor floor")
wall(-2.12,0,1.65,.22,32,3.3,name="Port corridor wall")
wall(2.12,0,1.65,.22,32,3.3,name="Starboard corridor wall")
wall(0,0,3.32,4.45,32,.22,name="Corridor ceiling")
# Deck plating
for y in range(-15,16,2):
    cube("Deck plate seam",(0,y,.012),(3.95,.025,.018),M["dark"],.003,"Details")
# Side wall paneling, lights, conduit, vents, signs
for y in range(-14,15,2):
    for side in (-1,1):
        cube("Bulkhead service panel",(side*2.0,y,1.65),(.07,1.3,1.25),M["panel"],.025,"Details")
        cube("Panel warning strip",(side*1.955,y-.55,1.15),(.018,.16,.055),M["amber"],.004,"Details")
    ceiling_lamp(0,y,"cyan" if y%4 else "white")
    vent(-1.75,y,2.65); vent(1.75,y,2.65)
    sign_panel(-1.96,y+.55,2.45,"SECTOR 0"+str((abs(y)//6)%5+1))
# Main overhead conduits
for x in (-1.3,-.95,.95,1.3):
    pipe_run((x,-15,2.98),(x,15,2.98),.035,M["cyan"] if x in (-1.3,1.3) else M["panel"])
# Hazard stripe at corridor junctions
for y in (-10,-4,2,8,14):
    for i in range(12):
        cube("Hazard floor marking",(-1.5+i*.27,y,.025),(.13,.18,.025),M["amber"],.002,"Details")
# End airlock
door_frame(0,15.85,"AIRLOCK 01")
sign_panel(0,15.65,3.0,"DOCKING BAY","amber")

# Branch room modules, on alternating sides. Rooms are 7m wide x 6m deep.
rooms = [
    {"name":"01_COMMAND","label":"COMMAND","x":-6.1,"y":-10,"kind":"command"},
    {"name":"02_LAB_VANTHIS","label":"VANTHIS LAB","x":6.1,"y":-10,"kind":"lab"},
    {"name":"03_MEDICAL","label":"MEDICAL","x":-6.1,"y":-2,"kind":"medical"},
    {"name":"04_QUARANTINE","label":"QUARANTINE","x":6.1,"y":-2,"kind":"quarantine"},
    {"name":"05_CREW_QUARTERS","label":"CREW QUARTERS","x":-6.1,"y":6,"kind":"crew"},
    {"name":"06_POWER_CORE","label":"POWER CORE","x":6.1,"y":6,"kind":"power"},
    {"name":"07_STORAGE","label":"STORAGE","x":-6.1,"y":13,"kind":"storage"},
    {"name":"08_SECURITY","label":"SECURITY","x":6.1,"y":13,"kind":"security"},
]
for r in rooms:
    x,y,k=r["x"],r["y"],r["kind"]
    # room box around centre, opening on corridor-facing side
    floor_box(x,y,7.0,6.0,name=r["label"]+" floor")
    wall(x,y-3.0,1.6,7,.18,3.2,name=r["label"]+" rear wall")
    wall(x-3.5,y, .0,.18,6,3.2,name=r["label"]+" outer wall")
    wall(x+3.5,y,1.6,.18,6,3.2,name=r["label"]+" outer wall")
    # corridor-side wall split around 2m door opening
    near_y = y+3 if x<0 else y-3
    wall(x-2.45,near_y,1.6,2.1,.18,3.2,name=r["label"]+" entry wall")
    wall(x+2.45,near_y,1.6,2.1,.18,3.2,name=r["label"]+" entry wall")
    wall(x,near_y,3.12,2.8,.18,.16,name=r["label"]+" entry lintel")
    # Sliding door and bright jambs
    cube(r["label"]+" door",(x,near_y,1.35),(2.05,.10,2.55),M["dark"],.025,"Architecture")
    cube(r["label"]+" access light",(x,near_y-.07 if x<0 else near_y+.07,2.62),(.9,.035,.07),M["green"] if k not in ("quarantine","lab") else M["red"],.01,"Details")
    # interior fixtures by room role
    if k=="command":
        for xx in (x-1.7,x,x+1.7): console(xx,y+1.25,1.05,1.25)
        cube("Command holomap table",(x,y-.25,.8),(2.4,1.25,1.2),M["hull"],.06,"Props")
        cube("Holomap projection",(x,y-.25,1.43),(1.9,.85,.035),M["cyan"],.01,"Props")
        for i in range(3):
            cube("Wall display",(x-2+i*2,y-2.86,2.15),(1.25,.05,.75),M["screen"],.02,"Props")
        sign_panel(x,y-2.78,2.75,"COMMAND")
    elif k=="lab":
        for xx in (x-2,x,x+2):
            cube("Laboratory workbench",(xx,y-.8,.82),(1.45,.72,.95),M["white"],.035,"Props")
            cube("Lab instrument screen",(xx,y-1.18,1.45),(.72,.045,.42),M["screen"],.015,"Props")
        cyl("Specimen containment cylinder",(x,y+1.1,1.35),.62,2.3,M["glass"],key="Props",vertices=32)
        cyl("Containment base",(x,y+1.1,.22),.72,.3,M["panel"],key="Props",vertices=32)
        cyl("Containment cap",(x,y+1.1,2.48),.72,.22,M["panel"],key="Props",vertices=32)
        for z in (.65,1.35,2.0): cyl("Containment ring",(x,y+1.1,z),.68,.055,M["red"],key="Details",vertices=32)
        sign_panel(x,y-2.78,2.75,"VANTHIS","red")
    elif k=="medical":
        for xx in (x-1.6,x+1.2):
            cube("Medical bed",(xx,y+.3,.55),(1.0,2.0,.35),M["white"],.05,"Props")
            cube("Bed mattress",(xx,y+.25,.77),(.86,1.55,.12),M["cyan"],.04,"Props")
            cube("Bed monitor",(xx,y-1.0,1.45),(.42,.2,.55),M["screen"],.02,"Props")
        cabinet(x+2.55,y+1.3,1.1,"MED KIT")
        sign_panel(x,y-2.78,2.75,"MEDICAL","green")
    elif k=="quarantine":
        # Containment cell / thick glass
        cube("Quarantine glass wall",(x,y+.25,1.45),(2.7,.09,2.5),M["glass"],.025,"Props")
        for xx in (x-1.4,x+1.4):
            wall(xx,y+.25,1.45,.12,.18,2.8,M["panel"],"Containment support")
        cube("Quarantine observation console",(x,y-1.5,1.1),(1.6,.55,.9),M["hull"],.04,"Props")
        cube("Quarantine red status",(x,y-1.8,1.55),(.9,.025,.2),M["red"],.008,"Props")
        sign_panel(x,y-2.78,2.75,"QUARANTINE","red")
    elif k=="crew":
        for xx in (x-2,x+2):
            cube("Crew bunk frame",(xx,y+.25,1.0),(1.15,2.1,1.75),M["hull"],.035,"Props")
            for zz in (.55,1.35):
                cube("Crew bunk mattress",(xx,y+.25,zz),(.96,1.72,.12),M["white"],.025,"Props")
        cabinet(x,y-1.3,1.0,"PERSONAL")
        sign_panel(x,y-2.78,2.75,"CREW")
    elif k=="power":
        for xx in (x-2,x,x+2):
            cube("Power distribution cabinet",(xx,y+.3,1.5),(1.15,.75,2.45),M["hull"],.045,"Props")
            for zz in (.85,1.3,1.75,2.1):
                cube("Power status light",(xx-.35,y-.11,zz),(.08,.025,.08),M["green"] if zz<1.4 else M["amber"],.01,"Details")
        pipe_run((x-2.5,y+1.3,2.75),(x+2.5,y+1.3,2.75),.08,M["amber"])
        sign_panel(x,y-2.78,2.75,"POWER CORE","amber")
    elif k=="storage":
        for xx in (x-2.3,x,x+2.3):
            cabinet(xx,y+.6,1.1,"SUPPLIES")
            cube("Supply crate",(xx,y-1.0,.42),(.85,.8,.75),M["hull"],.035,"Props")
        sign_panel(x,y-2.78,2.75,"STORAGE")
    elif k=="security":
        for xx in (x-1.8,x,x+1.8): console(xx,y+1.2,1.05,1.25)
        for xx in (x-2,x,x+2):
            cube("Security display",(xx,y-2.15,2.0),(1.15,.05,.75),M["screen"],.02,"Props")
        cabinet(x+2.5,y+.9,1.2,"LOCKERS")
        sign_panel(x,y-2.78,2.75,"SECURITY","red")
    # room ceiling light and pipes
    ceiling_lamp(x,y,"red" if k in ("lab","quarantine") else "cyan")
    for xx in (x-2.8,x+2.8):
        pipe_run((xx,y-2.3,2.8),(xx,y+2.3,2.8),.025,M["panel"])

# Wall-mounted emergency stations and environmental storytelling
for y in (-12,-6,0,6,12):
    for side in (-1,1):
        cube("Emergency equipment locker",(side*1.78,y,1.15),(.32,.52,.85),M["red"],.025,"Props")
        cube("Emergency locker glass",(side*1.60,y,1.15),(.025,.34,.58),M["glass"],.01,"Props")
        text_obj("EMERGENCY",(side*1.61,y-.22,1.37),.055,M["white"],rot=(math.pi/2,0,math.pi/2))
# Damage marks and loose cables near lab/quarantine for narrative clues
for i in range(5):
    cube("Scorch mark",(-1.72+i*.17,-2.8,.035),(.12,.3,.018),M["stain"],.005,"Details")
pipe_run((-1.8,-3.2,.16),(-1.15,-3.7,.16),.018,M["dark"])
# Small floor arrows to communicate navigation
for y, direction in ((-13,"N"),(-7,"N"),(-1,"N"),(5,"N"),(11,"N")):
    cube("Navigation arrow shaft",(0,y,.035),(.055,.65,.02),M["white"],.005,"Signs")
    # arrow head as a simple triangular mesh
    mesh=bpy.data.meshes.new("ArrowheadMesh")
    verts=[(-.22,y+.18,.045),(.22,y+.18,.045),(0,y+.48,.045)]
    faces=[(0,1,2)]
    mesh.from_pydata(verts,[],faces); mesh.materials.append(M["cyan"])
    ob=bpy.data.objects.new("Navigation arrowhead",mesh); COL["Signs"].objects.link(ob)

# Scene settings, lighting, camera and floor surroundings
cube("Station foundation",(0,0,-.42),(19,34,.38),M["dark"],.08,"Architecture")
# Outside ground only as a studio base, not part of exported walkable interior
area_light("Corridor key light",(0,-2,3.0),850,(.52,.72,1.0),7,(0,0,1))
area_light("Lab fill light",(6,-10,3.0),450,(.25,.55,1.0),4,(6,-10,1))
area_light("Command fill light",(-6,-10,3.0),500,(.35,.65,1.0),4,(-6,-10,1))
area_light("Quarantine warning light",(6,-2,2.9),280,(1,.04,.025),3,(6,-2,1))
# A wide overview camera
cam_data=bpy.data.cameras.new("Station Overview Camera")
cam=bpy.data.objects.new("Station Overview Camera",cam_data); COL["Cameras"].objects.link(cam)
cam.location=(19,-27,24); target=Vector((0,0,0.8)); cam.rotation_euler=(target-Vector(cam.location)).to_track_quat('-Z','Y').to_euler()
cam_data.lens=34; bpy.context.scene.camera=cam

scene=bpy.context.scene
scene.render.engine='CYCLES'
scene.cycles.samples=32
scene.render.resolution_x=1600; scene.render.resolution_y=1000; scene.render.resolution_percentage=100
scene.world.color=(.018,.025,.035)
scene.view_settings.view_transform='AgX'
scene.render.image_settings.file_format='PNG'
scene.render.filepath=os.path.join(OUTPUT_DIR,"A_Ultima_Expedicao_Overview.png")
# Helpful metadata
scene["Project"]="A Última Expedição"
scene["Asset"]="Modular space station environment"
scene["Version"]="Blender scene generator 1.0"
scene["Notes"]="Fictional VANTHIS station. Creature and traitor are gameplay systems, not modeled as player-controlled characters."

# Set viewport to material preview-like solid and select root architecture
bpy.ops.object.select_all(action='DESELECT')
if bpy.context.screen:
    for area in bpy.context.screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_distance=35
            area.spaces.active.region_3d.view_location=(0,0,1)

# Save native Blender scene
blend_path=os.path.join(OUTPUT_DIR,BLEND_NAME)
bpy.ops.wm.save_as_mainfile(filepath=blend_path)
# Export full scene as GLB for Godot. Keep transforms and materials.
bpy.ops.object.select_all(action='SELECT')
bpy.ops.export_scene.gltf(filepath=os.path.join(OUTPUT_DIR,GLB_NAME),
                          export_format='GLB', use_selection=False,
                          export_apply=True, export_lights=True, export_cameras=False)
print("A ÚLTIMA EXPEDIÇÃO: Blender scene and GLB export generated in", OUTPUT_DIR)

package pt.ultimaexpedicao.nearby;

import android.Manifest;
import android.os.Build;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.android.gms.nearby.Nearby;
import com.google.android.gms.nearby.connection.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@CapacitorPlugin(name = "NearbyLink", permissions = {
    @Permission(alias = "nearby", strings = {
        Manifest.permission.BLUETOOTH_SCAN,
        Manifest.permission.BLUETOOTH_CONNECT,
        Manifest.permission.BLUETOOTH_ADVERTISE,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.NEARBY_WIFI_DEVICES
    })
})
public class NearbyLinkPlugin extends Plugin {
    private final String serviceId = "pt.ultimaexpedicao.game.nearby";
    private final Strategy strategy = Strategy.P2P_STAR;
    private final Set<String> endpoints = new LinkedHashSet<>();
    private final Map<String, String> pendingActions = new HashMap<>();
    private final Map<String, String> names = new HashMap<>();

    private final PayloadCallback payloadCallback = new PayloadCallback() {
        @Override public void onPayloadReceived(String endpointId, Payload payload) {
            if (payload.getType() == Payload.Type.BYTES && payload.asBytes() != null) {
                String data = new String(payload.asBytes(), StandardCharsets.UTF_8);
                JSObject event = new JSObject(); event.put("endpointId", endpointId); event.put("data", data);
                notifyListeners("nearbyMessage", event);
            }
        }
        @Override public void onPayloadTransferUpdate(String endpointId, PayloadTransferUpdate update) {}
    };

    private final ConnectionLifecycleCallback lifecycle = new ConnectionLifecycleCallback() {
        @Override public void onConnectionInitiated(String endpointId, ConnectionInfo info) {
            names.put(endpointId, info.getEndpointName());
            Nearby.getConnectionsClient(getContext()).acceptConnection(endpointId, payloadCallback);
            JSObject event = new JSObject(); event.put("message", "A aceitar ligação de " + info.getEndpointName() + "…");
            notifyListeners("nearbyStatus", event);
        }
        @Override public void onConnectionResult(String endpointId, ConnectionResolution result) {
            if (result.getStatus().isSuccess()) {
                endpoints.add(endpointId);
                JSObject event = new JSObject(); event.put("endpointId", endpointId); event.put("name", names.containsKey(endpointId) ? names.get(endpointId) : "Dispositivo");
                notifyListeners("nearbyConnected", event);
            } else {
                JSObject event = new JSObject(); event.put("message", "A ligação falhou (" + result.getStatus().getStatusCode() + ").");
                notifyListeners("nearbyStatus", event);
            }
        }
        @Override public void onDisconnected(String endpointId) {
            endpoints.remove(endpointId); JSObject event = new JSObject(); event.put("endpointId", endpointId); notifyListeners("nearbyDisconnected", event);
        }
    };

    private final EndpointDiscoveryCallback discovery = new EndpointDiscoveryCallback() {
        @Override public void onEndpointFound(String endpointId, DiscoveredEndpointInfo info) {
            names.put(endpointId, info.getEndpointName());
            JSObject event = new JSObject(); event.put("endpointId", endpointId); event.put("name", info.getEndpointName()); notifyListeners("deviceFound", event);
        }
        @Override public void onEndpointLost(String endpointId) {
            JSObject event = new JSObject(); event.put("message", "Um dispositivo deixou de estar visível."); notifyListeners("nearbyStatus", event);
        }
    };

    @PluginMethod public void startHost(PluginCall call) {
        requestNearbyPermissions(call, "host");
    }
    @PluginMethod public void startScan(PluginCall call) {
        requestNearbyPermissions(call, "scan");
    }
    private void requestNearbyPermissions(PluginCall call, String action) {
        if (getPermissionState("nearby") != PermissionState.GRANTED) {
            pendingActions.put(call.getCallbackId(), action);
            requestPermissionForAlias("nearby", call, "nearbyPermissionCallback");
            return;
        }
        executeAction(call, action);
    }
    @PermissionCallback private void nearbyPermissionCallback(PluginCall call) {
        String action = pendingActions.remove(call.getCallbackId());
        if (getPermissionState("nearby") != PermissionState.GRANTED) { call.reject("Permissões de dispositivos próximos recusadas"); return; }
        executeAction(call, action == null ? "scan" : action);
    }
    private void executeAction(PluginCall call, String action) {
        if ("host".equals(action)) {
            String name = call.getString("name", "Anfitrião");
            Nearby.getConnectionsClient(getContext()).startAdvertising(name, serviceId, lifecycle, new AdvertisingOptions.Builder().setStrategy(strategy).build())
                .addOnSuccessListener(unused -> { call.resolve(); JSObject event = new JSObject(); event.put("message", "Sala anunciada."); notifyListeners("nearbyStatus", event); })
                .addOnFailureListener(e -> call.reject("Falha ao anunciar sala: " + e.getMessage()));
        } else {
            Nearby.getConnectionsClient(getContext()).startDiscovery(serviceId, discovery, new DiscoveryOptions.Builder().setStrategy(strategy).build())
                .addOnSuccessListener(unused -> call.resolve())
                .addOnFailureListener(e -> call.reject("Falha ao procurar dispositivos: " + e.getMessage()));
        }
    }
    @PluginMethod public void connect(PluginCall call) {
        String id = call.getString("endpointId");
        if (id == null) { call.reject("endpointId obrigatório"); return; }
        String name = call.getString("name", "Investigador");
        Nearby.getConnectionsClient(getContext()).requestConnection(name, id, lifecycle)
            .addOnSuccessListener(unused -> call.resolve()).addOnFailureListener(e -> call.reject("Falha ao pedir ligação: " + e.getMessage()));
    }
    @PluginMethod public void send(PluginCall call) {
        String data = call.getString("data");
        if (data == null) { call.reject("data obrigatório"); return; }
        byte[] bytes = data.getBytes(StandardCharsets.UTF_8);
        if (bytes.length > 30000) { call.reject("Mensagem demasiado grande"); return; }
        if (endpoints.isEmpty()) { call.reject("Não há dispositivos ligados"); return; }
        Nearby.getConnectionsClient(getContext()).sendPayload(new ArrayList<>(endpoints), Payload.fromBytes(bytes))
            .addOnSuccessListener(unused -> call.resolve()).addOnFailureListener(e -> call.reject("Falha ao enviar mensagem: " + e.getMessage()));
    }
    @PluginMethod public void stop(PluginCall call) {
        Nearby.getConnectionsClient(getContext()).stopAdvertising(); Nearby.getConnectionsClient(getContext()).stopDiscovery(); Nearby.getConnectionsClient(getContext()).stopAllEndpoints();
        endpoints.clear(); names.clear(); call.resolve(); JSObject event = new JSObject(); event.put("message", "Ligação terminada."); notifyListeners("nearbyStatus", event);
    }
}

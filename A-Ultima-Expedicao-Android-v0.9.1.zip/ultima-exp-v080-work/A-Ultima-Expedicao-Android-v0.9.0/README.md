# A Última Expedição v0.9.1

Esta versão corrige a deteção e inclusão da bridge JavaScript do plugin Capacitor Nearby. Abrir `www/index.html` num navegador normal **não** dá acesso ao Bluetooth nativo; a bridge só é ativada dentro da APK Capacitor Android.

## Compilação

1. Coloque o conteúdo deste projeto no repositório GitHub, preservando `.github/workflows/android-apk.yml`.
2. Execute **Actions → A Última Expedição v0.9.1 — Testes de protocolo e APK Android**.
3. Descarregue o artefacto `A-Ultima-Expedicao-Android-v0.9.1-debug` quando o workflow terminar com sucesso.
4. Instale a APK nos dispositivos Android e aceite as permissões de dispositivos próximos.

## Limitações e validação

- A bridge é compilada pelo esbuild e incluída em `www/js/nearby-bridge.bundle.js`.
- O plugin Android usa Google Play services Nearby Connections, que negocia Bluetooth/Wi-Fi conforme a disponibilidade.
- Este ZIP não contém uma APK pré-compilada. A compilação deve ser executada no GitHub Actions.
- A comunicação real entre dois Android, permissões e reconexão ainda requerem testes físicos. Não considerar validado até esses testes passarem.

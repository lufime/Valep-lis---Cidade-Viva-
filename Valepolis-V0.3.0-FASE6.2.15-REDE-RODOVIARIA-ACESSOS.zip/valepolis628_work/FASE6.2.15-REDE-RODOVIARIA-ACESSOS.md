# Valepólis V0.3.0 — FASE 6.2.15

## Correções implementadas no código
- A rede rodoviária gerada passa a guardar os segmentos efetivamente desenhados para reutilização na colocação urbana.
- A seleção de locais para edifícios rejeita pontos dentro da plataforma rodoviária e de uma faixa de segurança junto às estradas.
- A colocação dos edifícios usa amostragem espacial com distância mínima entre centros para reduzir sobreposições entre volumes.
- A matriz territorial dos 25 bairros e os perfis arquitetónicos existentes não são alterados.

## Limites da validação
- A compilação Android ainda não foi executada neste ambiente (não existe Gradle wrapper no projeto e o comando `gradle` não está instalado).
- Não se declara a rede como cartografia real nem como topologicamente validada. A rede continua a ser procedural e derivada dos centros dos bairros.
- A exclusão de edifícios da faixa rodoviária reduz colisões, mas ainda é necessário testar visualmente no APK e validar acessos de cada edifício e conectividade completa do grafo.

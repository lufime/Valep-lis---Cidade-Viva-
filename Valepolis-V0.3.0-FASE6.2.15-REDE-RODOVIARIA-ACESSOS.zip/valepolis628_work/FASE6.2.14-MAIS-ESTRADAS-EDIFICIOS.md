# Valepólis V0.3.0 — Fase 6.2.14

## Alterações implementadas no código
- Identificação da aplicação atualizada para Fase 6.2.14 / BUILD 633.
- Rede visual de ligações entre centros de bairros: até 8 vizinhos próximos por bairro (antes 5), com vias mais largas.
- Densidade de edifícios aumentada: alvo derivado do perfil arquitetónico multiplicado por 5, limitado a 48–140 por bairro.
- Grelha de amostragem aumentada de 32×32 para 48×48 pontos candidatos por bairro.
- Pegada visual dos edifícios aumentada moderadamente.
- Mantidos os 25 polígonos territoriais e os perfis arquitetónicos existentes; não se inventam coordenadas cartográficas oficiais.

## Limitações e validação
As estradas são ligações visuais procedurais entre centros territoriais, não uma rede cartográfica real validada. As quantidades de edifícios são geração visual, não inventário oficial. Esta versão ainda precisa de compilação Android e inspeção visual/performance num dispositivo; não declarar aprovada antes desses testes.

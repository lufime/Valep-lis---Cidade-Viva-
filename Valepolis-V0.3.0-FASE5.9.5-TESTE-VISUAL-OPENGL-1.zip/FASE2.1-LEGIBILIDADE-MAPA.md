# Fase 2.1 — Legibilidade do mapa

- Marcadores numéricos no mapa para evitar colisões entre nomes de bairros.
- Lista abaixo do mapa preserva os nomes completos e associa-se aos números pela ordem.
- Identificação do cabeçalho atualizada para Fase 2.
- A visualização continua 2D esquemática. Necessita de compilação e teste no Android.

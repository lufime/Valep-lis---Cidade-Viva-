#!/usr/bin/env python3
"""Static PRE-FLIGHT for Valepólis V0.3.0 Kotlin project. Does not certify visual 3D completeness."""
import json, hashlib, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = []
def check(name, condition, detail=''):
    checks.append((name, bool(condition), detail))

def load_json(rel):
    try:
        return json.loads((ROOT / rel).read_text(encoding='utf-8'))
    except Exception as e:
        check(f'JSON válido: {rel}', False, str(e))
        return None

# Android/Gradle structure
for rel in ['settings.gradle.kts','build.gradle.kts','app/build.gradle.kts','app/src/main/AndroidManifest.xml',
            'app/src/main/java/pt/valepolis/quandotocaasirene/MainActivity.kt']:
    check(f'Ficheiro obrigatório: {rel}', (ROOT/rel).is_file())

# Main neighborhood dataset
b = load_json('app/src/main/assets/data/bairros_valepolis.json')
if isinstance(b, dict):
    ns = b.get('neighborhoods')
    check('Projeto identifica Valepólis', b.get('city') == 'Valepólis', repr(b.get('city')))
    check('Contagem declarada de 25 bairros', b.get('neighborhood_count') == 25)
    check('Existem exatamente 25 registos', isinstance(ns, list) and len(ns) == 25, f'{len(ns) if isinstance(ns,list) else "inválido"}')
    if isinstance(ns, list):
        ids = [x.get('id') for x in ns if isinstance(x,dict)]
        names = [x.get('name') for x in ns if isinstance(x,dict)]
        check('IDs dos bairros únicos', len(ids)==25 and len(set(ids))==25)
        check('Nomes dos bairros preenchidos e únicos', len(names)==25 and all(isinstance(n,str) and n.strip() for n in names) and len(set(names))==25)
        check('Posições X/Z válidas', all(isinstance(x.get('world_position_xz'),dict) and isinstance(x['world_position_xz'].get('x'),(int,float)) and isinstance(x['world_position_xz'].get('z'),(int,float)) for x in ns if isinstance(x,dict)))

# Boundary geometry dataset
limits = load_json('app/src/main/assets/data/limites_bairros_v030.json')
if isinstance(limits, dict):
    lns = limits.get('neighborhoods')
    check('Limites declaram 25 bairros', limits.get('neighborhood_count') == 25)
    check('Existem 25 geometrias territoriais', isinstance(lns,list) and len(lns)==25, f'{len(lns) if isinstance(lns,list) else "inválido"}')
    if isinstance(lns,list):
        ids=[x.get('id') for x in lns if isinstance(x,dict)]
        check('IDs das geometrias únicos', len(ids)==25 and len(set(ids))==25)
        def has_geometry(x):
            # Accept documented polygon/points/vertices representations, but require at least 3 coordinate pairs.
            if not isinstance(x,dict): return False
            for key in ('boundary_xz','polygon_xz','polygon','points','vertices','coordinates'):
                arr=x.get(key)
                if isinstance(arr,list) and len(arr)>=3:
                    if all(isinstance(p,(list,tuple)) and len(p)>=2 and all(isinstance(v,(int,float)) for v in p[:2]) for p in arr): return True
                    if all(isinstance(p,dict) and isinstance(p.get('x'),(int,float)) and isinstance(p.get('z',p.get('y')),(int,float)) for p in arr): return True
            return False
        geom_count=sum(has_geometry(x) for x in lns)
        # Dataset may use alternative shape; report as inspection, do not invent schema.
        check('Cada bairro tem geometria poligonal reconhecida', geom_count==25, f'{geom_count}/25 formatos de polígono reconhecidos')

# Source/resource byte consistency, if source copies exist
pairs=[('source/bairros_valepolis.json','app/src/main/assets/data/bairros_valepolis.json'),
       ('source/data/limites_bairros_v030.json','app/src/main/assets/data/limites_bairros_v030.json')]
for src,dst in pairs:
    if (ROOT/src).is_file() and (ROOT/dst).is_file():
        same=hashlib.sha256((ROOT/src).read_bytes()).digest()==hashlib.sha256((ROOT/dst).read_bytes()).digest()
        check(f'Fonte e recurso iguais: {Path(dst).name}',same)

# APK gate: strict default false; all criteria and real visual evidence required.
gate=load_json('quality_gate_3d.json')
release_ok=False
if isinstance(gate,dict):
    criteria=gate.get('criteria',{})
    evidence=gate.get('evidence',{})
    all_criteria=isinstance(criteria,dict) and bool(criteria) and all(v is True for v in criteria.values())
    screenshots=evidence.get('screenshots',[]) if isinstance(evidence,dict) else []
    screenshot_files=all(isinstance(p,str) and p.strip() and (ROOT/p).is_file() for p in screenshots) if isinstance(screenshots,list) else False
    evidence_ok=bool(evidence.get('device_model','').strip() and evidence.get('android_version','').strip() and evidence.get('validation_notes','').strip() and isinstance(screenshots,list) and len(screenshots)>0 and screenshot_files)
    release_ok=(gate.get('approved') is True and gate.get('status')=='APPROVED' and all_criteria and evidence_ok)
    check('Barreira APK configurada em modo seguro', gate.get('approved') is False or release_ok,
          'APK só pode ser libertado com aprovação explícita, todos os critérios verdadeiros e capturas de ecrã existentes no repositório')
else:
    check('Existe quality_gate_3d.json válido',False)

fails=sum(not ok for _,ok,_ in checks)
print('PRE-FLIGHT VALÉPOLIS V0.3.0 — KOTLIN / 3D')
print('='*58)
for name,ok,detail in checks:
    print(f"{'PASS' if ok else 'FAIL'} | {name}" + (f' — {detail}' if detail else ''))
print('-'*58)
print(f'TOTAL_PASS={len(checks)-fails} TOTAL_FAIL={fails}')
print('APK_RELEASE_APPROVED=' + ('true' if release_ok and fails==0 else 'false'))
print('NOTA: verificações estáticas não certificam a qualidade visual nem substituem testes reais no Android.')
# Fail only on static integrity/data issues; an unapproved gate is not itself a failed preflight.
critical=[name for name,ok,_ in checks if not ok and name != 'Barreira APK configurada em modo seguro']
sys.exit(1 if critical else 0)

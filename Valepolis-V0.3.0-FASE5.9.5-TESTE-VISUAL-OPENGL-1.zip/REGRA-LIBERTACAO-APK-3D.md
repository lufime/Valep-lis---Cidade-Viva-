# Regra de libertação do APK — Valepólis V0.3.0

O APK não deve ser compilado nem publicado enquanto o mundo 3D não estiver integralmente definido, implementado, testado e visualmente validado.

## Critérios obrigatórios
- Território e relevo coerentes com a matriz aprovada.
- Os 25 bairros com limites, centros, nomes e características validadas.
- Mar, costa, rio/estuário, montanhas e transições de terreno.
- Rede viária, edifícios e distribuição urbana implementados, não apenas ilustrados por cubos genéricos.
- Arquitetura e influências culturais sem inventar atribuições em falta.
- Vegetação, água, materiais, iluminação, sinalização e detalhe ambiental.
- Câmara com rotação, zoom, deslocamento e níveis de detalhe funcionais.
- Colisões e interações previstas para o mundo implementadas.
- Testes automatizados sem falhas e validação visual num dispositivo Android real.
- Evidência registada em `quality_gate_3d.json`.

## Estado inicial
`approved=false` e todos os critérios estão falsos. O workflow deve parar antes da compilação/publicação do APK.

## Limitação importante
O ficheiro de aprovação é uma barreira de processo, não uma prova automática de qualidade. A inspeção visual e os testes reais continuam obrigatórios; um workflow verde ou uma compilação bem-sucedida não significam que o 3D esteja a 100%.

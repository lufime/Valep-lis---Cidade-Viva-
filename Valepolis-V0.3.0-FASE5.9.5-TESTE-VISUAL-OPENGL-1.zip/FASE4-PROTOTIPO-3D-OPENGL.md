# Fase 4 — Protótipo 3D nativo

- Ecrã `MAPA 3D` com `GLSurfaceView` e OpenGL ES 2.0.
- Terreno base, zona costeira, vias esquemáticas, volumes de edifícios e montanhas procedurais.
- Controlos para rodar a vista.
- Limitações: não é ainda a malha oficial de Valepólis; não há edifícios detalhados, rede viária real, personagens, trânsito nem sistemas de jogo.
- Requer compilação no GitHub Actions e teste num dispositivo Android.

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "pt.valepolis.quandotocaasirene"
    compileSdk = 35
    defaultConfig {
        applicationId = "pt.valepolis.quandotocaasirene"
        minSdk = 26
        targetSdk = 35
        versionCode = 300
        versionName = "0.3.0-kotlin-alpha"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.android.filament:filament-android:1.56.0")
    implementation("com.google.android.filament:filament-utils-android:1.56.0")
    implementation("com.google.android.filament:gltfio-android:1.56.0")
}

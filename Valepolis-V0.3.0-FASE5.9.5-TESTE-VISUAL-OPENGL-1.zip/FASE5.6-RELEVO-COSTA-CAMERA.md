# Fase 5.6 — Ajuste do relevo, água e câmara

- Substituída a faixa montanhosa larga por uma cadeia oriental mais estreita, com 48 secções e três bandas de elevação gradual.
- Reduzida a altura dos cumes para evitar a aparência de grande placa isolada.
- Estreitada a representação ilustrativa do estuário ocidental para reduzir a intrusão na área urbana.
- Recentrada a câmara e reduzido o campo de visão para tentar enquadrar melhor a cidade.
- Dados dos 25 bairros preservados.

Limitações: relevo e estuário continuam ilustrativos. Não foi executada compilação Android nem validação em dispositivo nesta sessão.

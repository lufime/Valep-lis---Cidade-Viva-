# Valepólis V0.3.0 — Fase 5.9.5: teste visual OpenGL

Esta build é exclusivamente DEBUG/diagnóstico, não é RELEASE.

- Acrescenta um triângulo magenta desenhado em clip-space com matriz identidade.
- O triângulo não depende da câmara, do terreno nem dos polígonos dos bairros.
- Se o triângulo aparecer, a superfície e o caminho básico de shader/desenho estão a apresentar píxeis; o problema fica provavelmente na câmara, projeção ou geometria da cidade.
- Se o triângulo não aparecer apesar de a indicação de primeiro frame surgir, investigar superfície EGL/framebuffer/composição da janela e confirmar que a APK instalada foi gerada deste ZIP.
- O teste fica por cima do mapa e é intencionalmente temporário. Não representa a arte final.

Validação realizada neste pacote: integridade ZIP e verificação estática da alteração. Não foi executada compilação Android nem teste num dispositivo.

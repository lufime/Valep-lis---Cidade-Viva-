# Correções de compilação — Fase 4

Erros observados no GitHub Actions:
- `Class is prohibited here`: a classe `Mesh` estava declarada dentro da classe interna do renderer. Foi movida para o nível da Activity.
- `Unresolved reference: map`: os controlos de zoom referiam a variável `map` antes da sua declaração. A vista é agora criada antes dos listeners.

Estas correções tratam os dois erros indicados no log. A compilação ainda precisa de ser repetida no GitHub Actions; não é declarada como aprovada.

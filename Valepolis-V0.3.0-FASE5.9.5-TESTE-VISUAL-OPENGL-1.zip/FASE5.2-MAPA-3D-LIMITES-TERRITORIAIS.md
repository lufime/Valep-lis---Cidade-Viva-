# Fase 5.2 — Integração territorial no mapa 3D

## Alterações
- O renderizador OpenGL lê `app/src/main/assets/data/limites_bairros_v030.json`.
- Os 25 polígonos `boundary_xz` são normalizados para a área de visualização e desenhados individualmente.
- São desenhados contornos entre bairros, em vez da antiga grelha viária artificial.
- Os volumes urbanos são posicionados a partir de `center_xz` dos registos existentes.
- Mantêm-se costa a norte e uma representação ilustrativa do estuário a oeste e relevo a este.
- A câmara foi reajustada para melhorar o enquadramento.

## Limitações conhecidas
- Os limites do ficheiro estão identificados como virtuais e pendentes de validação visual.
- Edifícios, relevo e estuário continuam a ser representações ilustrativas.
- Não foi inventada uma rede viária oficial.
- Esta alteração não declara a APK compilada ou testada num dispositivo. É necessária uma execução real do workflow Android e validação visual no telefone.

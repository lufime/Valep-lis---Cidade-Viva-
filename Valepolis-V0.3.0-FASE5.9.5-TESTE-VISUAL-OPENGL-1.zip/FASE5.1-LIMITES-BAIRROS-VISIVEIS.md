# Fase 5.1 — Limites territoriais visíveis

- Desenha os polígonos existentes de `limites_bairros_v030.json` e os seus contornos.
- Usa `bairros_valepolis.json` para colocar volumes ilustrativos nos centros existentes.
- Remove a grelha de estradas genérica não apoiada por geometria aprovada.
- Mantém o mar a norte e a faixa fluvial/estuário a oeste como referências esquemáticas.
- Os limites continuam virtuais e pendentes de validação visual; alturas de edifícios e relevo são apenas ilustrativos.
- Necessita de compilação e teste Android.

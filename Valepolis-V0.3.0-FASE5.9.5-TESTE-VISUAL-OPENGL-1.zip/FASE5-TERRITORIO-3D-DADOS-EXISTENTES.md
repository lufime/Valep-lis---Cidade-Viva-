# Fase 5 — Território 3D a partir dos dados existentes

- Usa `source/data/limites_bairros_v030.json` para polígonos territoriais existentes.
- Usa `source/bairros_valepolis.json` para centros X/Z dos 25 bairros.
- Mantém mar a norte, faixa fluvial/estuário a oeste e relevo esquemático a este.
- Volumes de edifícios e estradas permanecem ilustrativos; não são dados oficiais.
- O ficheiro de limites declara explicitamente que os polígonos virtuais estão pendentes de validação visual.
- Necessita de compilação e teste no Android.

# Fase 4.2 — Diagnóstico visível do OpenGL

O vídeo mostra a área 3D vazia apesar de o ecrã abrir. Esta versão:
- muda a composição da `GLSurfaceView` para `setZOrderOnTop(true)`;
- acrescenta um estado visível para indicar se o renderer inicializou, quantas malhas carregou e o tamanho da superfície;
- regista a dimensão da superfície e erros de shader/inicialização em Logcat;
- altera a cor de fundo da área para distinguir a superfície de uma área sem conteúdo.

Não é possível garantir a correção sem nova compilação e teste no dispositivo. Se continuar vazio, a mensagem de estado e os logs `Valepolis3D` permitem localizar a causa com maior precisão.

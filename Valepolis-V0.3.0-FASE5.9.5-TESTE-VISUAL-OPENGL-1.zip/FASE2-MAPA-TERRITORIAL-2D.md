# Fase 2 — Mapa territorial 2D

- Desenha os 25 bairros a partir de `world_position_xz` no JSON.
- Orientação esquemática: mar a norte, rio/estuário a oeste e montanhas a este.
- Tocar num bairro destaca o ponto e apresenta o nome e o papel territorial.
- As estradas são linhas esquemáticas; não representam a rede real.
- Não é ainda o mapa 3D. O renderizador 3D e os sistemas de simulação continuam pendentes.
- Esta entrega ainda necessita de compilação no GitHub Actions e teste num dispositivo Android.

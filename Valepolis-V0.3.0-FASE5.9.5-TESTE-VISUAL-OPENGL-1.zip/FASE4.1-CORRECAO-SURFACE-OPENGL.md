# Fase 4.1 — Diagnóstico e composição OpenGL

A gravação de ecrã mostra que o ecrã MAPA 3D abre, mas a área OpenGL fica vazia. Esta revisão:
- define explicitamente a composição da `GLSurfaceView` como media overlay e formato opaco;
- aumenta ligeiramente a área da superfície;
- regista no Logcat o sucesso da inicialização ou a exceção do renderer (`Valepolis3D`);
- corrige a aplicação da rotação através de uma matriz separada.

Isto é uma correção direcionada para o sintoma observado, não uma confirmação de que o problema está resolvido. É necessário compilar e testar a APK. Se a superfície continuar vazia, recolher Logcat filtrado por `Valepolis3D`, `OpenGLRenderer` e `GLSurfaceView`.

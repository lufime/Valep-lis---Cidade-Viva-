# Valepólis V0.3.0 — Fase 5.9.2

## Alterações
- Aumentada a distância inicial da câmara para enquadrar melhor a área territorial em ecrãs estreitos.
- Aumentado o campo de visão e o plano distante da projeção.
- Se a inicialização dos shaders/OpenGL falhar, a superfície passa a vermelho escuro e o erro é enviado para o estado da interface e para Logcat (`Valepolis3D`).
- Atualizada a identificação técnica para Fase 5.9.2.

## Limites de validação
Esta alteração foi aplicada ao código-fonte do ZIP anterior. Não foi possível executar uma compilação Android nem validar num dispositivo neste ambiente. O vermelho é um diagnóstico deliberado de falha de inicialização, não o aspeto final desejado.

# Fase 5.4 — Cadeia montanhosa e enquadramento

- Substituídas as colinas circulares isoladas por uma faixa montanhosa contínua no lado oriental, com cumes e vales variáveis.
- Ajustada a perspetiva e o alvo da câmara para reduzir o corte do terreno.
- Aumentada a variação de alturas e pegadas dos volumes urbanos, mantendo os centros existentes dos bairros.
- Não foram alterados os dados territoriais, os nomes, nem a distribuição cultural dos bairros.
- O relevo e os edifícios continuam ilustrativos; esta versão ainda precisa de compilação Android e validação visual no dispositivo.

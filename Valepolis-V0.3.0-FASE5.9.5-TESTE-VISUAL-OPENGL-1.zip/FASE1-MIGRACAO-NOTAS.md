# Fase 1 — Migração Kotlin

Alterações:
- `app/src/main/java/pt/valepolis/quandotocaasirene/MainActivity.kt`: interface com texto maior, botões maiores, navegação em três filas, secção de bairros alimentada pelo JSON e validação visual da contagem de episódios.
- `README.md`: regista o alcance e as limitações desta fase.

Não declarar migração completa. O mapa 3D e os sistemas operacionais ainda não foram implementados nesta fase.

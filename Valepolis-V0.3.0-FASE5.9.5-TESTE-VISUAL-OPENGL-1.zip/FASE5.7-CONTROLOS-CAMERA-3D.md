# Valepólis V0.3.0 — Fase 5.7: controlos de câmara 3D

## Implementado nesta fase
- Controlos no ecrã para rodar à esquerda/direita.
- Controlos no ecrã para aproximar/afastar a câmara.
- Botão para recentrar a câmara.
- Gesto de dois dedos para zoom.
- Arrasto de um dedo para rodar e ajustar a deslocação vertical da vista.
- Limites de zoom e deslocação para reduzir o risco de perder o mapa da vista.
- Texto de interface que declara explicitamente que o relevo continua ilustrativo e o APK permanece bloqueado.

## Limitações conhecidas
- Esta fase não transforma o terreno ilustrativo em relevo geográfico validado.
- Não cria nem inventa uma rede viária oficial.
- Não certifica a fidelidade visual, o desempenho em dispositivos Android nem a compilação.
- A definição detalhada de edifícios, texturas, iluminação, água, vegetação, circulação, personagens e instalações continua pendente de implementação e validação.

## Regra de libertação
`quality_gate_3d.json` permanece com `approved: false`. Não publicar nem libertar APK com base nesta fase.

## Verificação executada
- Integridade do ZIP: a validar no empacotamento.
- JSON territorial: a validar no empacotamento.
- Compilação Android e teste visual em dispositivo: NÃO executados neste ambiente.

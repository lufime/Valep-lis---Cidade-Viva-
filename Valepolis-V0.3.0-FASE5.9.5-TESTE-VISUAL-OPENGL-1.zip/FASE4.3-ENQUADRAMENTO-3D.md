# Fase 4.3 — Enquadramento e controlo da vista 3D

- Ajuste de câmara e campo de visão para preencher melhor o ecrã.
- Grelha viária esquemática mais densa e quarteirões com alturas variadas.
- Rotação da cena por arrastamento horizontal.
- Limitação: geometria provisória; não é o mapa oficial 3D de Valepólis.
- Compilar e testar antes de considerar funcional.

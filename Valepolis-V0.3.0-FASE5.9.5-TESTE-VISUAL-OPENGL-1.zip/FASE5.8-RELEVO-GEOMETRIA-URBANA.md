# Valepólis V0.3.0 — Fase 5.8: relevo e geometria urbana

## Alterações implementadas no código
- Adicionada uma malha contínua de terreno de 80 × 80 células, com altimetria procedural.
- Os polígonos territoriais existentes passam a acompanhar a elevação calculada nos vértices, mantendo os dados oficiais dos 25 bairros.
- Os edifícios assentam na elevação do terreno em vez de começarem todos na cota zero.
- Adicionadas linhas geométricas de janelas às fachadas dos edifícios gerados.
- Mantida a implementação OpenGL ES 2.0 e os controlos existentes, sem introduzir dependências novas.

## Limitações e validação
- A altimetria é procedural e ilustrativa; não é um levantamento topográfico real.
- As janelas são geometria simples, não texturas PBR nem interiores.
- Não foi possível executar uma compilação Android neste ambiente. Esta entrega é uma alteração de código, não uma APK validada.
- Antes de qualquer lançamento, executar o workflow Android e inspecionar capturas reais em vários níveis de zoom. A APK de lançamento permanece bloqueada.

# Fase 5.3 — Correção visual do mapa 3D

- Substitui pirâmides triangulares grandes por malhas de colinas facetadas, com anéis de elevação e topos suaves.
- Reduz a altura das formas do relevo e distribui-as junto à margem oriental.
- Ajusta ligeiramente a câmara e a perspetiva.
- Aumenta a variação ilustrativa dos volumes urbanos.
- Mantém intacto o JSON territorial e os 25 registos existentes.

Limitações: relevo e edifícios continuam a ser ilustrativos; os limites são os do ficheiro territorial atual e carecem de validação visual. Esta alteração não foi compilada nem testada num dispositivo nesta sessão.

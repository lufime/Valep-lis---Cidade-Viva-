# Valepólis V0.3.0 — PRE-FLIGHT 3D e bloqueio do APK

## O que faz
- Valida a estrutura Android/Gradle e a integridade dos JSON territoriais.
- Verifica os 25 bairros, IDs e nomes únicos, posições e geometrias territoriais reconhecidas.
- Compara as cópias de origem com os recursos incluídos na aplicação.
- Executa `:app:compileDebugKotlin` para detetar erros de compilação Kotlin, sem empacotar APK.
- Só permite construir/publicar APK release quando `quality_gate_3d.json` está explicitamente aprovado, todos os critérios estão `true` e a evidência de validação real está presente.

## Estado inicial
O gate está deliberadamente em `approved: false`, `status: NOT_APPROVED` e critérios por validar. Assim, a tarefa `build-apk` fica ignorada. Não alterar estes valores apenas para fazer o workflow ficar verde.

## Aprovação futura
A aprovação exige validação técnica e visual real no Android. Registar o modelo do dispositivo, versão Android, notas e caminhos de capturas de ecrã guardadas no repositório. Só marcar um critério como `true` depois de ser realmente implementado e verificado. As capturas são evidência para revisão humana; o script não consegue provar automaticamente que o mundo 3D está perfeito.

## Instalação no GitHub
Colocar o conteúdo desta pasta na raiz do repositório, preservando `.github/workflows/preflight-3d.yml` e `tools/preflight_3d.py`. Depois abrir **Actions** e executar **Valepólis V0.3.0 — PRE-FLIGHT 3D e APK bloqueado**.

## Limitações
Este PRE-FLIGHT é uma auditoria estática mais uma verificação de compilação Kotlin. Não substitui a inspeção visual no dispositivo, testes de navegação/câmara, desempenho, colisões ou validação do mundo 3D completo. Não foi executado no GitHub durante a preparação deste pacote.

# Fase 3 — Navegação territorial

- Controlos de zoom para ampliar/reduzir e repor a vista.
- Arrastamento para deslocar a área territorial.
- Mantém seleção de bairro e marcadores numerados.
- Limitação: continua a ser mapa 2D esquemático; não é o mapa 3D final.
- A rede viária real ainda não foi migrada; `traffic_config.json` só define modos/reacções de tráfego.
- Requer compilação no GitHub Actions e teste em dispositivo Android.

# Fase 5.5 — Correção do relevo e enquadramento

## Alterações
- Confirmado que a expressão `ya1` da triangulação já estava correta nesta cópia da Fase 5.4; por isso não foi alterada artificialmente.
- Recuada a borda exterior da cadeia montanhosa para dentro do enquadramento.
- Reduzida e suavizada a altura da crista para diminuir o aspeto de bloco destacado.
- Ajustada a posição da câmara para reduzir o ângulo lateral e melhorar o enquadramento da zona oriental.

## Limitações
- A cadeia montanhosa continua a ser geometria ilustrativa gerada em Kotlin, não topografia real.
- Não foram alterados os dados territoriais dos 25 bairros.
- Não foi executada compilação Android nesta sessão. Validar no GitHub Actions e no dispositivo antes de considerar a correção concluída.

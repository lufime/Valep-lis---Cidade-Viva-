# Valepólis V0.3.0 — Fase 5.9.4

## Objetivo
Diagnosticar o mapa 3D vazio sem presumir que a compilação comprova a renderização.

## Alterações
- Cabeçalho visível `Fase 5.9.4 · BUILD 594`.
- Ao mudar de secção, repõe o ScrollView no topo para evitar ocultar os cartões de estado.
- O renderizador regista a criação da superfície, a inicialização dos shaders e a primeira chamada de desenho.
- O primeiro frame regista o número de chamadas de desenho, vértices enviados e o primeiro código `glGetError()`.
- Desativa explicitamente face culling e blending, para reduzir diferenças de estado herdadas no contexto OpenGL.
- Mantém os dados territoriais existentes e não altera a distribuição dos bairros.

## Validação
- ZIP derivado do projeto Fase 5.9.2 disponível na conversa.
- A integridade do ZIP e a presença do JSON territorial devem ser verificadas.
- A compilação Android e a execução em dispositivo NÃO foram validadas neste ambiente.
- O primeiro frame deve produzir no estado da interface uma mensagem `BUILD 594 · PRIMEIRO FRAME`.
- Se essa mensagem não aparecer, o problema é anterior ao desenho da geometria (a superfície/callback não está a atualizar a interface).
- Se aparecer com `chamadas=0` ou `vértices=0`, a cena não está a fornecer geometria.
- Se aparecer com chamadas e vértices positivos mas a superfície continuar vazia, investigar matriz MVP, viewport e estado GL.

A APK de lançamento permanece bloqueada até validação visual e técnica completa.

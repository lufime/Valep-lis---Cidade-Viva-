package pt.valepolis.quandotocaasirene

import android.app.Activity
import android.util.Log
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.absoluteValue
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

/**
 * Fase 5.4: mapa territorial 3D com relevo ilustrativo e dados territoriais V0.3.0.
 * Não representa ainda o motor 3D nem os sistemas operacionais completos.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(5, 20, 30)
    private val panel = Color.rgb(10, 34, 49)
    private val panelAlt = Color.rgb(16, 46, 62)
    private val accent = Color.rgb(239, 202, 94)
    private val muted = Color.rgb(190, 205, 214)
    private lateinit var content: LinearLayout
    private var section = "PAINEL"
    private var mapZoom = 1.0f
    private var mapPanX = 0f
    private var mapPanY = 0f
    private val localePt = Locale("pt", "PT")
    private val numberFormat: NumberFormat = NumberFormat.getIntegerInstance(localePt)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showShell()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(
        text: String,
        size: Float,
        color: Int = Color.WHITE,
        bold: Boolean = false
    ): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        gravity = Gravity.CENTER_VERTICAL
        setLineSpacing(dp(2).toFloat(), 1.05f)
        contentDescription = text
    }

    private fun showShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(label("VALEPÓLIS — CIDADE VIVA", 24f, accent, true))
        root.addView(label("V0.3.0 · Migração Kotlin nativo · Fase 5.4", 15f, muted))

        val scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(12))
        }
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        listOf(
            listOf("PAINEL", "BAIRROS"),
            listOf("OPERAÇÕES", "EQUIPAS"),
            listOf("VEÍCULOS", "INSTALAÇÕES"),
            listOf("MAPA 3D")
        ).forEach { names ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            names.forEach { name ->
                row.addView(navButton(name), LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                    marginEnd = dp(4)
                    bottomMargin = dp(4)
                })
            }
            nav.addView(row)
        }
        root.addView(nav)
        setContentView(root)
        renderSection()
    }

    private fun navButton(name: String) = Button(this).apply {
        text = name
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(if (section == name) Color.rgb(100, 78, 29) else panel)
        setPadding(dp(6), dp(6), dp(6), dp(6))
        minHeight = dp(54)
        minWidth = dp(0)
        setOnClickListener {
            section = name
            renderSection()
        }
    }

    private fun card(title: String): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        layout.addView(label(title, 22f, accent, true))
        return layout
    }

    private fun addCard(view: View) {
        content.addView(view, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(12)
        })
    }

    private fun renderSection() {
        content.removeAllViews()
        when (section) {
            "BAIRROS" -> renderNeighborhoods()
            "MAPA 3D" -> render3DMap()
            "OPERAÇÕES" -> {
                val c = card("CENTRO DE OPERAÇÕES")
                c.addView(label(
                    "Módulo em migração. Esta versão ainda não despacha ocorrências reais.",
                    17f
                ))
                c.addView(label(
                    "Regra de integridade: uma missão só poderá ser despachada quando existir uma equipa e uma viatura registadas, disponíveis e compatíveis.",
                    16f, muted
                ))
                addCard(c)
            }
            "EQUIPAS" -> {
                val c = card("EQUIPAS E SERVIÇOS")
                c.addView(label(
                    "BRIGADA e TNUR\nTNUR permanece integrada nas bases BRIGADA; não são criadas bases TNUR independentes.",
                    17f
                ))
                c.addView(label(
                    "Os efetivos e a disponibilidade só serão apresentados quando os registos operacionais forem ligados e validados.",
                    16f, muted
                ))
                addCard(c)
            }
            "VEÍCULOS" -> {
                val c = card("GESTÃO DE VIATURAS")
                c.addView(label(
                    "O catálogo de veículos ainda não está ligado ao despacho. Não são atribuídos veículos fictícios nem disponibilidades presumidas.",
                    17f
                ))
                addCard(c)
            }
            "INSTALAÇÕES" -> {
                val c = card("INSTALAÇÕES")
                c.addView(label(
                    "Os registos de instalações estão incluídos nos dados do projeto, mas a visualização e a validação operacional ainda precisam de integração.",
                    17f
                ))
                c.addView(label(
                    "Propostas não aprovadas não são tratadas como instalações oficiais.",
                    16f, muted
                ))
                addCard(c)
            }
            else -> renderDashboard()
        }
    }

    private fun render3DMap() {
        val info = card("MAPA 3D — PROTÓTIPO NATIVO")
        info.addView(label(
            "Vista 3D experimental baseada nos polígonos territoriais V0.3.0, com limites dos bairros, costa, estuário, relevo ilustrativo e volumes urbanos. A rede viária real e a validação visual final continuam pendentes.",
            16f, muted
        ))
        addCard(info)
        val status = label(
            "A iniciar renderizador OpenGL… Se a cena não aparecer, esta indicação ajuda a distinguir falha de inicialização.",
            15f, muted
        )
        val statusCard = card("ESTADO DO RENDERIZADOR")
        statusCard.addView(status)
        addCard(statusCard)
        val surface = object : GLSurfaceView(this) {
            private var lastX = 0f
            override fun onTouchEvent(event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { lastX = event.x; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val delta = event.x - lastX
                        mapRotation += delta * 0.008f
                        lastX = event.x
                        return true
                    }
                }
                return true
            }
        }.apply {
            // A superfície deve ser composta acima do conteúdo normal da janela.
            setZOrderOnTop(true)
            holder.setFormat(PixelFormat.OPAQUE)
            setEGLContextClientVersion(2)
            setRenderer(Valepolis3DRenderer { message ->
                runOnUiThread { status.text = message }
            })
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setBackgroundColor(Color.rgb(18, 48, 61))
            contentDescription = "Vista 3D experimental de Valepólis; arrasta para rodar"
        }
        content.addView(surface, LinearLayout.LayoutParams(-1, dp(520)).apply {
            bottomMargin = dp(12)
            topMargin = dp(4)
        })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Rodar à esquerda", "Rodar à direita").forEach { text ->
            val b = Button(this).apply {
                this.text = text
                textSize = 14f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(panelAlt)
                setOnClickListener {
                    if (text.contains("esquerda")) mapRotation -= 0.18f else mapRotation += 0.18f
                }
            }
            controls.addView(b, LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginEnd = dp(6) })
        }
        addCard(controls)
    }

    private var mapRotation = 0f

    /**
     * Protótipo OpenGL ES 2.0 sem dependência de motor externo.
     * A geometria é gerada proceduralmente; não pretende reproduzir a malha final da cidade.
     */
    private data class Mesh(val vertices: FloatArray, val color: FloatArray, val mode: Int = GLES20.GL_TRIANGLES)

    private inner class Valepolis3DRenderer(
        private val reportStatus: (String) -> Unit
    ) : GLSurfaceView.Renderer {
        private val vertexShader = """
            attribute vec3 aPosition;
            uniform mat4 uMVP;
            void main() { gl_Position = uMVP * vec4(aPosition, 1.0); }
        """.trimIndent()
        private val fragmentShader = """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """.trimIndent()
        private var program = 0
        private var positionHandle = 0
        private var mvpHandle = 0
        private var colorHandle = 0
        private val projection = FloatArray(16)
        private val view = FloatArray(16)
        private val model = FloatArray(16)
        private val mvp = FloatArray(16)
        private val identity = FloatArray(16)
        private val meshes = mutableListOf<Mesh>()


        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0.02f, 0.07f, 0.10f, 1f)
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            try {
                program = createProgram(vertexShader, fragmentShader)
                positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
                mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
                colorHandle = GLES20.glGetUniformLocation(program, "uColor")
                Matrix.setIdentityM(identity, 0)
                buildMeshes()
                Log.i("Valepolis3D", "Renderer inicializado; malhas=${meshes.size}")
                reportStatus("OpenGL inicializado · ${meshes.size} elementos gráficos carregados.")
            } catch (error: Exception) {
                program = 0
                Log.e("Valepolis3D", "Falha ao inicializar renderizador OpenGL", error)
                reportStatus("ERRO OpenGL: ${error.message ?: error.javaClass.simpleName}")
            }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
            val ratio = width.toFloat() / height.coerceAtLeast(1)
            Matrix.perspectiveM(projection, 0, 32f, ratio, 0.1f, 180f)
            Log.i("Valepolis3D", "Superfície OpenGL: ${width}x${height}")
            reportStatus("Superfície OpenGL ativa · ${width} × ${height}px · malhas=${meshes.size}")
        }

        override fun onDrawFrame(gl: GL10?) {
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            if (program == 0) return
            Matrix.setLookAtM(view, 0, 0f, 25f, 38f, 0f, 0.25f, 0f, 0f, 1f, 0f)
            val rotation = FloatArray(16)
            Matrix.setRotateM(rotation, 0, mapRotation * 57.2958f, 0f, 1f, 0f)
            val rotatedView = FloatArray(16)
            Matrix.multiplyMM(rotatedView, 0, view, 0, rotation, 0)
            GLES20.glUseProgram(program)
            meshes.forEach { mesh ->
                val buffer = ByteBuffer.allocateDirect(mesh.vertices.size * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer()
                buffer.put(mesh.vertices).position(0)
                Matrix.setIdentityM(model, 0)
                Matrix.multiplyMM(mvp, 0, rotatedView, 0, model, 0)
                Matrix.multiplyMM(mvp, 0, projection, 0, mvp, 0)
                GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
                GLES20.glUniform4fv(colorHandle, 1, mesh.color, 0)
                GLES20.glEnableVertexAttribArray(positionHandle)
                GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, buffer)
                GLES20.glDrawArrays(mesh.mode, 0, mesh.vertices.size / 3)
                GLES20.glDisableVertexAttribArray(positionHandle)
            }
        }

        private fun buildMeshes() {
            meshes.clear()

            // Carregar polígonos territoriais reais do registo V0.3.0.
            // As coordenadas do JSON são normalizadas para a área de renderização,
            // preservando a topologia e os 25 limites existentes.
            val boundaryRoot = readBoundaryData()
            val neighborhoods = boundaryRoot?.optJSONArray("neighborhoods")
            val bounds = boundaryRoot?.optJSONObject("world_bounds_xz")
            val minX = bounds?.optDouble("min_x", -52.5)?.toFloat() ?: -52.5f
            val maxX = bounds?.optDouble("max_x", 52.5)?.toFloat() ?: 52.5f
            val minZ = bounds?.optDouble("min_z", -49.16)?.toFloat() ?: -49.16f
            val maxZ = bounds?.optDouble("max_z", 49.16)?.toFloat() ?: 49.16f

            fun sx(x: Float) = -9.6f + ((x - minX) / (maxX - minX).coerceAtLeast(0.001f)) * 19.2f
            fun sz(z: Float) = -8.8f + ((z - minZ) / (maxZ - minZ).coerceAtLeast(0.001f)) * 17.6f

            // Superfície base: polígonos de bairro desenhados individualmente,
            // em vez da antiga grelha artificial de ruas e blocos repetidos.
            if (neighborhoods != null && neighborhoods.length() == 25) {
                val palette = arrayOf(
                    floatArrayOf(0.20f,0.38f,0.29f,1f),
                    floatArrayOf(0.23f,0.41f,0.31f,1f),
                    floatArrayOf(0.25f,0.40f,0.30f,1f),
                    floatArrayOf(0.19f,0.35f,0.28f,1f),
                    floatArrayOf(0.28f,0.43f,0.32f,1f)
                )
                for (i in 0 until neighborhoods.length()) {
                    val district = neighborhoods.optJSONObject(i) ?: continue
                    val polygon = district.optJSONArray("boundary_xz") ?: continue
                    if (polygon.length() < 3) continue
                    val pts = mutableListOf<Pair<Float, Float>>()
                    for (j in 0 until polygon.length()) {
                        val point = polygon.optJSONObject(j) ?: continue
                        pts.add(sx(point.optDouble("x", 0.0).toFloat()) to
                                sz(point.optDouble("z", 0.0).toFloat()))
                    }
                    if (pts.size < 3) continue

                    // Fan triangulation; estes polígonos Voronoi são convexos.
                    val triangles = mutableListOf<Float>()
                    val centerX = pts.map { it.first }.average().toFloat()
                    val centerZ = pts.map { it.second }.average().toFloat()
                    for (j in pts.indices) {
                        val a = pts[j]
                        val b = pts[(j + 1) % pts.size]
                        triangles.addAll(listOf(centerX, 0.02f, centerZ,
                            a.first, 0.02f, a.second, b.first, 0.02f, b.second))
                    }
                    meshes.add(Mesh(triangles.toFloatArray(), palette[i % palette.size]))

                    // Contorno fino para que cada limite de bairro seja visível.
                    val outline = mutableListOf<Float>()
                    for (j in pts.indices) {
                        val a = pts[j]
                        val b = pts[(j + 1) % pts.size]
                        val dx = b.first - a.first
                        val dz = b.second - a.second
                        val length = kotlin.math.sqrt(dx * dx + dz * dz).coerceAtLeast(0.001f)
                        val lift = 0.055f
                        outline.addAll(listOf(a.first, lift, a.second, b.first, lift, b.second))
                    }
                    meshes.add(Mesh(outline.toFloatArray(),
                        floatArrayOf(0.78f, 0.72f, 0.49f, 1f), GLES20.GL_LINES))
                }
            } else {
                // Falhar visivelmente se os dados territoriais não puderem ser lidos.
                Log.e("Valepolis3D", "Dados de limites territoriais indisponíveis ou sem 25 bairros")
                meshes.add(Mesh(floatArrayOf(
                    -9.6f,0f,-8.8f, 9.6f,0f,-8.8f, 9.6f,0f,8.8f,
                    -9.6f,0f,-8.8f, 9.6f,0f,8.8f, -9.6f,0f,8.8f
                ), floatArrayOf(0.18f,0.30f,0.22f,1f)))
            }

            // Mar a norte (z negativo), fora do perímetro urbano.
            meshes.add(Mesh(floatArrayOf(
                -9.6f,0.0f,-9.8f, 9.6f,0.0f,-9.8f, 9.6f,0.0f,-8.95f,
                -9.6f,0.0f,-9.8f, 9.6f,0.0f,-8.95f, -9.6f,0.0f,-8.95f
            ), floatArrayOf(0.035f,0.22f,0.37f,1f)))

            // Estuário ocidental: faixa sinuosa em polígonos, sem rede viária inventada.
            val estuary = floatArrayOf(
                -9.6f,0.035f,-8.8f, -9.15f,0.035f,-8.8f, -8.55f,0.035f,8.8f,
                -9.6f,0.035f,-8.8f, -8.55f,0.035f,8.8f, -9.6f,0.035f,8.8f
            )
            meshes.add(Mesh(estuary, floatArrayOf(0.06f,0.28f,0.39f,1f)))

            // Cadeia montanhosa oriental contínua: perfil irregular com vales e cumes.
            // Evita ilhas circulares separadas; a crista acompanha o limite leste do mapa.
            meshes.add(mountainRange())

            // Volumes urbanos derivados dos centros registados dos bairros:
            // cada bairro recebe um conjunto pequeno e irregular de edifícios
            // para evitar o aspeto de grelha uniforme anterior.
            if (neighborhoods != null) {
                for (i in 0 until neighborhoods.length()) {
                    val district = neighborhoods.optJSONObject(i) ?: continue
                    val center = district.optJSONObject("center_xz") ?: continue
                    val cx = sx(center.optDouble("x", 0.0).toFloat())
                    val cz = sz(center.optDouble("z", 0.0).toFloat())
                    val offsets = arrayOf(
                        floatArrayOf(-0.42f,-0.31f), floatArrayOf(0.31f,-0.27f),
                        floatArrayOf(-0.12f,0.33f), floatArrayOf(0.49f,0.38f),
                        floatArrayOf(-0.50f,0.13f), floatArrayOf(0.12f,0.08f)
                    )
                    offsets.forEachIndexed { j, offset ->
                        val x = (cx + offset[0]).coerceIn(-8.8f, 8.8f)
                        val z = (cz + offset[1]).coerceIn(-8.0f, 8.0f)
                        val height = when ((i * 7 + j * 5) % 9) {
                            0 -> 0.82f
                            1, 4 -> 0.58f
                            2, 6 -> 0.42f
                            else -> 0.24f + ((i + j) % 3) * 0.09f
                        }
                        val half = if (j % 3 == 0) 0.13f else 0.095f
                        val depth = if (j % 2 == 0) 0.12f else 0.085f
                        meshes.add(cube(x, z, half, height, depth))
                    }
                }
            }
        }

        private fun cube(cx:Float, cz:Float, half:Float, h:Float, depth:Float): Mesh {
            val x0=cx-half; val x1=cx+half; val z0=cz-depth; val z1=cz+depth
            val v=floatArrayOf(
                x0,0f,z0, x1,0f,z0, x1,h,z0, x0,0f,z0, x1,h,z0, x0,h,z0,
                x1,0f,z0, x1,0f,z1, x1,h,z1, x1,0f,z0, x1,h,z1, x1,h,z0,
                x1,0f,z1, x0,0f,z1, x0,h,z1, x1,0f,z1, x0,h,z1, x1,h,z1,
                x0,0f,z1, x0,0f,z0, x0,h,z0, x0,0f,z1, x0,h,z0, x0,h,z1,
                x0,h,z0, x1,h,z0, x1,h,z1, x0,h,z0, x1,h,z1, x0,h,z1
            )
            val shade=0.38f + ((cx+cz+30).toInt().absoluteValue%4)*0.08f
            return Mesh(v,floatArrayOf(shade,shade+0.08f,shade+0.12f,1f))
        }

        private fun mountainRange(): Mesh {
            // Cadeia oriental estreita, com base no terreno e transições graduais.
            // Evita a grande face plana que surgia quando a faixa exterior era larga.
            val vertices = mutableListOf<Float>()
            val sections = 48
            val zStart = -8.15f
            val zEnd = 8.15f

            fun height(t: Float): Float {
                val broad = 0.30f + 0.16f * kotlin.math.sin(t * 5.7f + 0.4f)
                val peaks = 0.18f * kotlin.math.abs(kotlin.math.sin(t * 17.0f + 0.8f))
                val shoulders = 0.05f * kotlin.math.sin(t * 31f)
                return (broad + peaks + shoulders).coerceIn(0.18f, 0.58f)
            }

            for (i in 0 until sections) {
                val t0 = i.toFloat() / sections
                val t1 = (i + 1).toFloat() / sections
                val z0 = zStart + (zEnd - zStart) * t0
                val z1 = zStart + (zEnd - zStart) * t1
                val h0 = height(t0)
                val h1 = height(t1)
                val xBase0 = 9.25f
                val xBase1 = 9.25f
                val xLow0 = 8.95f + 0.04f * kotlin.math.sin(t0 * 9f)
                val xLow1 = 8.95f + 0.04f * kotlin.math.sin(t1 * 9f)
                val xMid0 = 8.62f + 0.08f * kotlin.math.sin(t0 * 11f + 0.3f)
                val xMid1 = 8.62f + 0.08f * kotlin.math.sin(t1 * 11f + 0.3f)
                val xRidge0 = 8.35f + 0.12f * kotlin.math.sin(t0 * 12f)
                val xRidge1 = 8.35f + 0.12f * kotlin.math.sin(t1 * 12f)

                fun quad(
                    xa0: Float, ya0: Float, xa1: Float, ya1: Float,
                    xb0: Float, yb0: Float, xb1: Float, yb1: Float,
                    za: Float, zb: Float
                ) {
                    vertices.addAll(listOf(
                        xa0, ya0, za, xb0, yb0, za, xb1, yb1, zb,
                        xa0, ya0, za, xb1, yb1, zb, xa1, ya1, zb
                    ))
                }

                // Faixa exterior quase plana, seguida de duas encostas baixas.
                quad(xBase0, 0.035f, xBase1, 0.035f,
                     xLow0, h0 * 0.18f, xLow1, h1 * 0.18f, z0, z1)
                quad(xLow0, h0 * 0.18f, xLow1, h1 * 0.18f,
                     xMid0, h0 * 0.48f, xMid1, h1 * 0.48f, z0, z1)
                quad(xMid0, h0 * 0.48f, xMid1, h1 * 0.48f,
                     xRidge0, h0, xRidge1, h1, z0, z1)
            }
            return Mesh(vertices.toFloatArray(), floatArrayOf(0.30f, 0.38f, 0.31f, 1f))
        }

        private fun hill(cx: Float, cz: Float, radius: Float, height: Float, seed: Int): Mesh {
            // Malha radial com anéis de elevação; cria silhueta natural sem picos pontiagudos.
            val vertices = mutableListOf<Float>()
            val segments = 12
            val rings = arrayOf(
                1.00f to 0.02f,
                0.78f to height * 0.30f,
                0.52f to height * 0.66f,
                0.25f to height * 0.91f
            )
            val phase = seed * 0.37f
            for (ringIndex in 0 until rings.size - 1) {
                val (r0, y0) = rings[ringIndex]
                val (r1, y1) = rings[ringIndex + 1]
                for (i in 0 until segments) {
                    val a0 = (2.0 * Math.PI * i / segments + phase)
                    val a1 = (2.0 * Math.PI * (i + 1) / segments + phase)
                    fun px(r: Float, a: Double) = cx + kotlin.math.cos(a).toFloat() * radius * r *
                        (1f + 0.07f * kotlin.math.sin(a * 3.0 + seed).toFloat())
                    fun pz(r: Float, a: Double) = cz + kotlin.math.sin(a).toFloat() * radius * r *
                        (1f + 0.06f * kotlin.math.cos(a * 2.0 + seed).toFloat())
                    val x00 = px(r0, a0); val z00 = pz(r0, a0)
                    val x01 = px(r0, a1); val z01 = pz(r0, a1)
                    val x10 = px(r1, a0); val z10 = pz(r1, a0)
                    val x11 = px(r1, a1); val z11 = pz(r1, a1)
                    vertices.addAll(listOf(
                        x00,y0,z00, x10,y1,z10, x11,y1,z11,
                        x00,y0,z00, x11,y1,z11, x01,y0,z01
                    ))
                }
            }
            // Fechar o topo com um pequeno platô, não um vértice agudo.
            val (r, y) = rings.last()
            for (i in 0 until segments) {
                val a0 = 2.0 * Math.PI * i / segments + phase
                val a1 = 2.0 * Math.PI * (i + 1) / segments + phase
                val x0 = cx + kotlin.math.cos(a0).toFloat() * radius * r
                val z0 = cz + kotlin.math.sin(a0).toFloat() * radius * r
                val x1 = cx + kotlin.math.cos(a1).toFloat() * radius * r
                val z1 = cz + kotlin.math.sin(a1).toFloat() * radius * r
                vertices.addAll(listOf(cx,y + height * 0.035f,cz, x0,y,z0, x1,y,z1))
            }
            return Mesh(vertices.toFloatArray(), floatArrayOf(0.27f,0.36f,0.30f,1f))
        }

        private fun createProgram(vs:String, fs:String): Int {
            fun compile(type:Int, source:String):Int {
                val shader=GLES20.glCreateShader(type)
                GLES20.glShaderSource(shader,source)
                GLES20.glCompileShader(shader)
                val status=IntArray(1)
                GLES20.glGetShaderiv(shader,GLES20.GL_COMPILE_STATUS,status,0)
                if(status[0]==0) {
                    val error=GLES20.glGetShaderInfoLog(shader)
                    GLES20.glDeleteShader(shader)
                    throw IllegalStateException("Shader compilation failed: $error")
                }
                return shader
            }
            val vertex=compile(GLES20.GL_VERTEX_SHADER,vs)
            val fragment=compile(GLES20.GL_FRAGMENT_SHADER,fs)
            val p=GLES20.glCreateProgram()
            GLES20.glAttachShader(p,vertex); GLES20.glAttachShader(p,fragment)
            GLES20.glLinkProgram(p)
            val status=IntArray(1); GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,status,0)
            if(status[0]==0) throw IllegalStateException("OpenGL link failed: "+GLES20.glGetProgramInfoLog(p))
            return p
        }
    }

    private fun renderDashboard() {
        val c = card("CENTRO DE COMANDO")
        c.addView(label("A IA aconselha. O jogador comanda. A cidade reage.", 18f, Color.WHITE, true))
        c.addView(label("População oficial: 1 000 000", 19f, Color.WHITE, true))
        c.addView(label("Bairros: ${readNeighborhoods().length()} / 25", 18f))
        val episodeCount = readEpisodes()?.optJSONArray("episodes")?.length()
        c.addView(label("Narrativa: ${episodeCount ?: "—"} episódios · 20 temporadas", 18f))
        c.addView(label(
            "Estado da migração: interface e leitura territorial em implementação. O mapa 3D e os sistemas operacionais ainda não estão concluídos.",
            16f, muted
        ))
        addCard(c)

        val dataCard = card("DADOS CARREGADOS")
        val neighborhoods = readNeighborhoods()
        val episodes = readEpisodes()
        dataCard.addView(label(
            if (neighborhoods.length() == 25) "✓ Registo territorial: 25 bairros encontrados"
            else "⚠ Registo territorial: ${neighborhoods.length()} bairros encontrados",
            16f,
            if (neighborhoods.length() == 25) Color.rgb(145, 220, 170) else accent
        ))
        dataCard.addView(label(
            if (episodes?.optJSONArray("episodes")?.length() == 200) "✓ Registo narrativo: 200 episódios encontrados"
            else "⚠ Registo narrativo incompleto ou indisponível",
            16f,
            if (episodes?.optJSONArray("episodes")?.length() == 200) Color.rgb(145, 220, 170) else accent
        ))
        addCard(dataCard)
    }

    private fun renderNeighborhoods() {
        val root = card("TERRITÓRIO DE VALEPÓLIS")
        root.addView(label(
            "Mapa territorial 2D baseado nas coordenadas oficiais dos registos. Ainda não é o renderizador 3D.",
            16f, muted
        ))
        val arr = readNeighborhoods()
        val map = NeighborhoodMapView(arr)
        val mapControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("−", "Repor mapa", "+").forEach { title ->
            val b = Button(this).apply {
                text = title
                textSize = 16f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(panelAlt)
                minHeight = dp(48)
                setOnClickListener {
                    when (title) {
                        "+" -> mapZoom = (mapZoom * 1.25f).coerceAtMost(3.0f)
                        "−" -> mapZoom = (mapZoom / 1.25f).coerceAtLeast(0.75f)
                        else -> { mapZoom = 1.0f; mapPanX = 0f; mapPanY = 0f }
                    }
                    map.invalidate()
                }
            }
            mapControls.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginEnd = dp(4)
            })
        }
        root.addView(mapControls)
        root.addView(map, LinearLayout.LayoutParams(-1, dp(340)).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })
        if (arr.length() == 0) {
            root.addView(label("Não foi possível ler o registo de bairros.", 17f))
        } else {
            root.addView(label(
                "No mapa, cada número corresponde à mesma posição na lista abaixo. Toca num ponto para o destacar.",
                15f, muted
            ))
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("name", "Bairro sem nome")
                val population = item.optLong("population", -1L)
                val role = item.optString("territorial_role", "")
                val active = item.optBoolean("active", true)
                val entry = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(if (i % 2 == 0) panelAlt else panel)
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                entry.addView(label("${item.optInt("id", i + 1)}. $name", 19f, Color.WHITE, true))
                if (population >= 0) {
                    entry.addView(label("População de referência: ${numberFormat.format(population)}", 16f, muted))
                }
                if (role.isNotBlank()) entry.addView(label(role, 16f))
                entry.addView(label(if (active) "Estado do registo: ativo" else "Estado do registo: inativo", 14f, muted))
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply {
                    topMargin = dp(4)
                })
            }
        }
        addCard(root)
    }


    /**
     * Mapa territorial 2D interativo: posições e rótulos são lidos do JSON oficial.
     * A geografia (mar a norte, estuário a oeste e montanhas a este) é uma camada
     * esquemática orientativa; não substitui o terreno/renderizador 3D.
     */
    private inner class NeighborhoodMapView(private val neighborhoods: JSONArray) : View(this@MainActivity) {
        private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(12, 29, 39) }
        private val seaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(23, 74, 101) }
        private val riverPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(32, 100, 128) }
        private val landPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(42, 77, 59) }
        private val mountainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(82, 87, 82) }
        private val roadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(185, 174, 135); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
        }
        private val districtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; style = Paint.Style.FILL }
        private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat()
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = sp(10f); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(dp(2).toFloat(), 0f, 1f, Color.BLACK)
        }
        private val regionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(218, 229, 232); textSize = sp(11f); typeface = Typeface.DEFAULT_BOLD
        }
        private var selectedIndex = -1
        private val points = mutableListOf<Pair<Float, Float>>()
        private var lastTouchX = 0f
        private var lastTouchY = 0f
        private var moved = false

        private fun sp(v: Float) = v * resources.displayMetrics.scaledDensity

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), dp(10).toFloat(), dp(10).toFloat(), backgroundPaint)
            val w = width.toFloat()
            val h = height.toFloat()
            // Norte no topo: costa superior e estuário a oeste.
            canvas.drawRect(0f, 0f, w, h * .18f, seaPaint)
            canvas.drawText("MAR · NORTE", dp(12).toFloat(), dp(22).toFloat(), regionPaint)

            val river = Path().apply {
                moveTo(0f, h * .18f)
                cubicTo(w * .12f, h * .30f, w * .02f, h * .42f, w * .13f, h * .55f)
                cubicTo(w * .18f, h * .66f, w * .06f, h * .78f, w * .11f, h)
                lineTo(0f, h)
                close()
            }
            canvas.drawPath(river, riverPaint)
            canvas.drawText("RIO / ESTUÁRIO", dp(7).toFloat(), h * .48f, regionPaint)

            val mountain = Path().apply {
                moveTo(w * .82f, h * .18f)
                lineTo(w, h * .18f)
                lineTo(w, h)
                lineTo(w * .70f, h)
                lineTo(w * .78f, h * .72f)
                lineTo(w * .74f, h * .52f)
                close()
            }
            canvas.drawPath(mountain, mountainPaint)
            canvas.drawText("MONTANHAS", w * .75f, h - dp(12).toFloat(), regionPaint)

            val mapLeft = w * .17f
            val mapRight = w * .77f
            val mapTop = h * .22f
            val mapBottom = h * .91f
            val mapCenterX = (mapLeft + mapRight) / 2f
            val mapCenterY = (mapTop + mapBottom) / 2f
            canvas.save()
            canvas.translate(mapPanX, mapPanY)
            canvas.scale(mapZoom, mapZoom, mapCenterX, mapCenterY)
            // Eixos viários esquemáticos; não representam ainda a rede viária navegável.
            canvas.drawLine(mapLeft, mapTop + (mapBottom-mapTop)*.48f, mapRight, mapTop + (mapBottom-mapTop)*.48f, roadPaint)
            canvas.drawLine(mapLeft + (mapRight-mapLeft)*.52f, mapTop, mapLeft + (mapRight-mapLeft)*.52f, mapBottom, roadPaint)
            canvas.drawLine(mapLeft, mapBottom*.80f, mapRight, mapTop + (mapBottom-mapTop)*.22f, roadPaint)

            points.clear()
            var minX = -45.0
            var maxX = 45.0
            var minZ = -45.0
            var maxZ = 45.0
            for (i in 0 until neighborhoods.length()) {
                val obj = neighborhoods.optJSONObject(i) ?: continue
                val pos = obj.optJSONObject("world_position_xz") ?: continue
                minX = minOf(minX, pos.optDouble("x", 0.0))
                maxX = maxOf(maxX, pos.optDouble("x", 0.0))
                minZ = minOf(minZ, pos.optDouble("z", 0.0))
                maxZ = maxOf(maxZ, pos.optDouble("z", 0.0))
            }
            val usableLeft = mapLeft + dp(8)
            val usableRight = mapRight - dp(8)
            val usableTop = mapTop + dp(8)
            val usableBottom = mapBottom - dp(8)
            for (i in 0 until neighborhoods.length()) {
                val obj = neighborhoods.optJSONObject(i) ?: continue
                val pos = obj.optJSONObject("world_position_xz") ?: continue
                val x = pos.optDouble("x", 0.0)
                val z = pos.optDouble("z", 0.0)
                val px = usableLeft + ((x - minX) / (maxX - minX)).toFloat() * (usableRight - usableLeft)
                val py = usableTop + ((z - minZ) / (maxZ - minZ)).toFloat() * (usableBottom - usableTop)
                points.add(px to py)
                if (i == selectedIndex) canvas.drawCircle(px, py, dp(9).toFloat(), selectedPaint)
                canvas.drawCircle(px, py, dp(4.5f.toInt()).toFloat(), districtPaint)
                // Numerar os pontos evita a sobreposição de nomes no ecrã móvel.
                // A lista imediatamente abaixo do mapa associa cada número ao nome completo.
                val markerNumber = (i + 1).toString()
                val numberPaint = Paint(textPaint).apply {
                    textSize = sp(10f)
                    textAlign = Paint.Align.CENTER
                    color = Color.rgb(5, 20, 30)
                    clearShadowLayer()
                }
                canvas.drawCircle(px, py, dp(8).toFloat(), districtPaint)
                canvas.drawText(markerNumber, px, py + dp(3).toFloat(), numberPaint)
            }
            canvas.restore()
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.x
                    lastTouchY = event.y
                    moved = false
                    return true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    if (kotlin.math.abs(dx) > dp(3) || kotlin.math.abs(dy) > dp(3)) moved = true
                    if (moved) {
                        mapPanX = (mapPanX + dx).coerceIn(-width.toFloat(), width.toFloat())
                        mapPanY = (mapPanY + dy).coerceIn(-height.toFloat(), height.toFloat())
                        invalidate()
                    }
                    lastTouchX = event.x
                    lastTouchY = event.y
                    return true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (moved) return true
                var nearest = -1
                var distance = Float.MAX_VALUE
                points.forEachIndexed { index, point ->
                    val dx = event.x - point.first
                    val dy = event.y - point.second
                    val d = dx * dx + dy * dy
                    if (d < distance) { distance = d; nearest = index }
                }
                if (nearest >= 0 && distance < dp(36).toFloat() * dp(36).toFloat()) {
                    selectedIndex = nearest
                    invalidate()
                    val obj = neighborhoods.optJSONObject(nearest)
                    if (obj != null) {
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "${obj.optString("name")} · ${obj.optString("territorial_role")}",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
                    return true
                }
            }
            return true
        }
    }

    private fun readJsonObject(file: String): JSONObject? = try {
        assets.open("data/$file").bufferedReader(Charsets.UTF_8).use {
            JSONObject(it.readText())
        }
    } catch (_: Exception) {
        null
    }

    private fun readBoundaryData(): JSONObject? = try {
        assets.open("data/limites_bairros_v030.json").bufferedReader(Charsets.UTF_8).use {
            JSONObject(it.readText())
        }
    } catch (error: Exception) {
        Log.e("Valepolis3D", "Não foi possível ler limites_bairros_v030.json", error)
        null
    }

    private fun readNeighborhoods(): JSONArray =
        readJsonObject("bairros_valepolis.json")?.optJSONArray("neighborhoods") ?: JSONArray()

    private fun readEpisodes(): JSONObject? = readJsonObject("episodes_200.json")
}

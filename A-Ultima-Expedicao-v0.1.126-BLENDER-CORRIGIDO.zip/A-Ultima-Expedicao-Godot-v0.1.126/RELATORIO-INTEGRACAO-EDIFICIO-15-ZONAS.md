# Integração do edifício em ciclo — V0.1.126

## Alterações aplicadas
- A função `_apply_cycle_layout()` passou a definir 15 posições em anel e 15 ligações de corredor, incluindo `DoorToDoor_15_to_01`.
- Foram acrescentados cascos físicos procedurais para `CycleZone01` e `CycleZone02`, com piso, teto, paredes, aberturas de portas e colisões.
- As Zonas 03–15 existentes são reposicionadas no anel para preservar os respetivos conteúdos de missão.
- Os conectores lineares antigos são removidos para evitar duplicação de colisões.
- O minimapa foi atualizado para representar as 15 zonas do ciclo e os corredores novos.
- Foram removidos todos os ficheiros `.glb`, mantendo a fonte Blender `.blend` e cenas-base sem referência direta a GLB.
- A auditoria estática foi ajustada para refletir a política de não incluir GLB.

## Verificação realizada
- `python tests/quality_audit.py`: PASS, 95 verificações estáticas.
- Confirmado: não existem ficheiros `.glb` no ZIP.
- Não foi possível executar Godot neste ambiente. Portanto, a sintaxe GDScript em runtime, a navegação física dentro do jogo, o multijogador e a exportação APK continuam por validar no motor Godot.

## Nota técnica
As Zonas 01 e 02 do ciclo são cascos procedurais novos (`CycleZone01` e `CycleZone02`) para evitar quebrar os nós e sistemas antigos associados à entrada/investigação. O projeto mantém os restantes sistemas do jogo e os elementos legados necessários às missões.

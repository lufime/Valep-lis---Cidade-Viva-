#!/usr/bin/env python3
"""Valepólis V0.3.0 offline structural PRE-FLIGHT. Does not replace Godot runtime tests."""
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
passes, failures, warnings = [], [], []

def ok(msg): passes.append(msg)
def fail(msg): failures.append(msg)
def warn(msg): warnings.append(msg)

required = [
    "project.godot", "Main.tscn", "main.gd",
    "systems/valepolis_systems_runtime.gd",
    "tools/preflight_functional.gd", "tools/preflight_regional_roads.py",
    "export_presets.cfg",
]
for rel in required:
    (ok if (ROOT / rel).is_file() else fail)(f"Ficheiro obrigatório para projeto 2D: {rel}")

# Validate every JSON file, including configuration and game data.
json_files = list(ROOT.rglob("*.json"))
for path in json_files:
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"JSON inválido: {path.relative_to(ROOT)} ({exc})")
if json_files:
    ok(f"JSON válidos: {len(json_files)} ficheiros verificados")

# Validate every literal res:// reference used in scenes/scripts/config text.
resource_exts = {".gd", ".tscn", ".tres", ".godot", ".cfg", ".json"}
checked_refs, missing_refs = 0, []
for path in ROOT.rglob("*"):
    if not path.is_file() or path.suffix not in resource_exts:
        continue
    # Historical manifests may describe removed optional 3D addons; they are not active scene dependencies.
    if path.relative_to(ROOT).as_posix() == "docs/manifests/VALEPOLIS_3D_STUDIO.json":
        continue
    try:
        content = path.read_text(encoding="utf-8")
    except Exception:
        continue
    for match in re.finditer(r'res://([^"\s)]+)', content):
        rel = match.group(1).rstrip(",;")
        # Only audit literal file paths; skip dynamically composed paths and
        # prose fragments that happen to begin with res://.
        if any(token in rel for token in ["%", "{", "}", "+", "$"]):
            continue
        if Path(rel).suffix not in {".gd", ".tscn", ".tres", ".png", ".jpg", ".webp", ".svg", ".json", ".cfg", ".wav", ".ogg", ".ttf", ".otf", ".md"}:
            continue
        checked_refs += 1
        if not (ROOT / rel).exists():
            missing_refs.append((path.relative_to(ROOT), rel))
for source, target in missing_refs:
    fail(f"Referência res:// em falta: {source} -> {target}")
if not missing_refs:
    ok(f"Referências res:// encontradas: {checked_refs}")

# Catch the specific invalid dictionary syntax that existed in V30.
runtime = (ROOT / "systems/valepolis_systems_runtime.gd").read_text(encoding="utf-8")
if re.search(r'"status"\s*:\s*"[^"]+"\s*:', runtime):
    fail("Sintaxe suspeita em dicionário: chave status contém um segundo ':'")
else:
    ok("Dicionários do runtime sem o padrão de sintaxe inválido V30")
for fn in ["calculate_market_price", "validate_stock_sale", "validate_public_expense",
           "calculate_credit_installment", "calculate_insurance_premium",
           "calculate_insurance_payout"]:
    (ok if f"func {fn}(" in runtime else fail)(f"Função económica: {fn}")

# This project is now 2D: never require the removed 3D scene/controller/addons.
main = (ROOT / "main.gd").read_text(encoding="utf-8")
scene = (ROOT / "Main.tscn").read_text(encoding="utf-8")
hoods_path = ROOT / "bairros_valepolis.json"

if "name=\"MapBody\"" in scene and "name=\"Map\"" in scene:
    ok("Cena principal contém painel de mapa 2D")
else:
    fail("Cena principal sem painel de mapa 2D")
if not any(token in scene for token in ["Camera3D", "Node3D", "SubViewport3D", "Map3D"]):
    ok("Cena principal sem nós de mapa 3D")
else:
    fail("A cena principal ainda contém referências estruturais a 3D")

print("VALEPÓLIS V0.3.0 — PRE-FLIGHT ESTÁTICO (MAPA 2D)")
print(f"PASS={len(passes)} FAIL={len(failures)} WARN={len(warnings)}")
for item in passes: print("PASS | " + item)
for item in warnings: print("WARN | " + item)
for item in failures: print("FAIL | " + item)
if failures:
    sys.exit(1)

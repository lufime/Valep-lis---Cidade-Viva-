# Valepólis V0.3.0 — Relevos 2D aplicados

Foi integrada uma textura de mapa 2D detalhado em `assets/ui/valepolis_relief_map.png` e ligada ao nó `ReliefMap` em `Main.tscn`.

A imagem representa costa e praias a norte, estuário/curso de água a oeste, montanhas a este, zonas verdes e urbanas centrais, lago urbano e vias principais. Mantém-se a cena 2D e não foi reintroduzida geometria 3D.

## Limitações / validação
- A textura foi integrada na cena principal; a imagem contém cartografia ilustrativa e alguns rótulos visuais incorporados.
- A posição de marcadores dinâmicos e a escala em ecrãs diferentes devem ser confirmadas no jogo.
- Não foi possível executar Godot neste ambiente; compilação, importação e APK ainda carecem de validação pelo GitHub Actions.

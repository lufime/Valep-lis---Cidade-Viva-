# Valepólis V0.3.0 — Nova interface de estado do jogo

## O que mudou

A camada principal da interface foi remodelada para um dashboard de jogo adaptativo a telemóveis:

- Cabeçalho HUD com identidade de Valepólis, calendário e estado geral.
- Mapa como área central principal.
- Quatro cartões de estado atualizados pela simulação: tempo do jogo, cidade, atividade e personagem/entidade.
- Barra de navegação persistente na parte inferior, com destinos diferentes para Personagem e Entidade.
- Ecrã **Mais / Centro de Controlo** para aceder aos restantes painéis sem remover funcionalidades existentes.
- Ações de guardar e carregar continuam disponíveis no Centro de Controlo.
- Layout adaptativo: os cartões passam para duas colunas em ecrãs estreitos e quatro colunas em ecrãs largos.
- A escala automática antiga é impedida de aumentar os cartões e a navegação nova para não cortar os controlos.

## Dados apresentados

- Calendário, hora, dia, estação e meteorologia vêm do estado da simulação.
- População de 1.000.000 e 25 bairros refletem os dados oficiais do projeto.
- Trânsito vem de `v030_city_state`.
- Contagem de missões vem de `v030_get_missions()`.
- Eventos/ocorrências mostra a contagem dos registos existentes; não é apresentado como número de ocorrências ativas.
- O cartão de personagem usa saúde, energia e fome já existentes no estado do jogo.
- No modo Entidade, efetivos, frota e saldo continuam explicitamente «por definir» quando não estão configurados. Não são inventados valores.

## Navegação

### Modo Personagem / Cidade
- **Cidade** — mapa livre.
- **Vida** — modo de personagem.
- **Pessoas** — telefone/contactos.
- **Missões** — estado das missões.
- **Mais** — inventário, notícias, finanças, temporadas, definições, guardar e carregar.

### Modo Entidade
- **Painel** — regressa ao painel da entidade.
- **Base** — perfil e funções da entidade.
- **Instalações** — registo de instalações propostas.
- **Operações** — painel de operações/missões.
- **Mais** — equipas, veículos, recursos, finanças e relatórios.

## Preservação das regras

A alteração é de interface e ligação à lógica existente. Não atribui efetivos, viaturas, instalações físicas, saldo, preços ou distribuição cultural novos. TNUR continua integrado nas bases BRIGADA e as propostas de instalações não são criadas automaticamente no mapa.

## Validação

Executado localmente `bash tools/preflight.sh`: `RESULT=PASS`, incluindo auditoria de regras (`32/32`) e auditoria de projeto (`44/44`).

**Limitação:** este ambiente não tem o executável Godot instalado; por isso não foi possível executar o parser/runtime Godot, gerar screenshot de runtime ou testar a APK num dispositivo Android. O resultado é de auditoria estática, não uma declaração de funcionamento visual/runtime confirmado. Antes de distribuir, executar o workflow Godot do projeto e validar a APK num telemóvel.

# Valepólis V0.3.0 — correção da interface móvel

## Problemas observados na captura
- Barra de separadores horizontais ultrapassa a largura do ecrã e corta nomes.
- Temporadas/episódios só eram acessíveis no menu inicial.
- Vista inicial do mapa demasiado aproximada para mostrar a escala da cidade.

## Alterações neste patch
- A barra de navegação do modo personagem passou a ter deslocamento horizontal por gesto, botões com largura mínima e tipografia compacta; os nomes deixam de depender da largura disponível para caber todos ao mesmo tempo.
- Adicionado o separador `TEMPORADAS` à navegação persistente. Abre o catálogo existente de 20 temporadas/200 episódios sem criar conteúdo narrativo inventado.
- A ação de abrir temporadas durante a partida encaminha para o catálogo e mantém o fluxo existente de seleção/confirmar.
- Reduzido o zoom inicial do mapa para uma vista mais ampla; o zoom manual e os níveis de detalhe continuam disponíveis.
- Cartões de temporada/episódio aumentados para toque e texto ajustado para retrato.

## Validação
- ZIP validado com `unzip -t`.
- Verificação estática confirma o botão `TEMPORADAS`, o handler, o ScrollContainer e os valores de zoom.
- Não foi possível executar a aplicação Godot neste ambiente; a aparência final, proporções físicas da cidade e funcionamento em Android necessitam de novo PRE-FLIGHT e teste no dispositivo.
- Esta alteração melhora o enquadramento inicial; não declara a escala física de todos os edifícios como corrigida. A calibração completa deve usar a matriz territorial e alturas por bairro já aprovadas, sem aplicar um fator global cego.

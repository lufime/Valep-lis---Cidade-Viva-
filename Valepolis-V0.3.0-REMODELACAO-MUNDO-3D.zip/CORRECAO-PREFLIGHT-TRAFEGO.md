# Correção PRE-FLIGHT — Gestor de Trânsito V0.3.0

## Erro observado
`ERROR: Instance count must be 0 to change the transform format.`
em `systems/traffic_manager.gd`, durante `_setup_multimesh()`.

## Correção
A configuração do `MultiMesh` passa primeiro `instance_count` para zero, depois define `transform_format`, atribui a malha e restaura a capacidade configurada. Esta ordem respeita a condição exigida pelo Godot 4.5.

## Verificações realizadas aqui
- ZIP original íntegro.
- Alteração aplicada apenas a `systems/traffic_manager.gd` e adição deste relatório.
- Verificação textual confirma que `instance_count = 0` precede `transform_format`.
- ZIP de saída testado com `unzip`/CRC.

## Limites
Esta correção ainda precisa de um novo workflow Godot 4.5 para confirmar que o erro desapareceu em execução. Os avisos independentes do `SubViewportContainer.stretch` permanecem por resolver neste patch.

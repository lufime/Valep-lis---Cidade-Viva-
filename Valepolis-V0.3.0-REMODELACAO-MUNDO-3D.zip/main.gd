extends Control

# V0.3.0 — recursos visuais auxiliares; mapa/personagens são gerados pelo Godot.
const V030_ENTITY_ASSETS := "res://assets/entities/"
const V030_UI_ASSETS := "res://assets/ui/"

func _v030_asset_path(kind: String, id: String) -> String:
    match kind:
        "entity":
            return V030_ENTITY_ASSETS + id + ".png"
        "panel":
            return V030_UI_ASSETS + "panel_" + id + ".png"
        _:
            return ""

func _v030_apply_visual_placeholder(target: TextureRect, kind: String, id: String) -> void:
    if target == null:
        return
    var path := _v030_asset_path(kind, id)
    if ResourceLoader.exists(path):
        target.texture = load(path)
        target.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        target.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED


# =========================
# V0.3.0 COMPLETION LAYER
# =========================
const V030_COMPLETION_LAYER := "0.3.0-COMPLETE"
const V030_CHARACTER_GENERATOR = preload("res://character_generator/character_generator.gd")

var v030_weather := "limpo"
var v030_season := "inverno"
var v030_holiday := false
var v030_weekend := false
var v030_school_day := true
var v030_city_event := ""
var v030_neighborhood_profile: Dictionary = {}
var v030_school_state: Dictionary = {}
var v030_work_state: Dictionary = {}
var v030_daily_activity: Dictionary = {}
var v030_population_materialized: Dictionary = {}
var v030_residence_moves: Array = []
var v030_calendar_history: Array = []
var v030_world_state_v030: Dictionary = {}
var v030_npc_daily_needs: Dictionary = {}
var v030_npc_activity_log: Dictionary = {}
var v030_service_usage: Dictionary = {}
var v030_social_events: Array = []
var v030_npc_social_state: Dictionary = {}
var v030_social_relations: Dictionary = {}

# V0.3.0 — estado central partilhado pelos sistemas existentes.
# As coleções começam neutras; não atribuem efetivos, instalações, saldos ou stock.
var v030_current_neighborhood: String = "Nexora"
var v030_entities: Dictionary = {}
var v030_jobs: Dictionary = {}
var v030_public_services: Dictionary = {}
var v030_player_interactions: Array = []
var v030_routes: Dictionary = {}
var v030_city_traffic: Dictionary = {}
var v030_ai_decisions: Dictionary = {}
var v030_professions_catalog: Dictionary = {}
var v030_entities_catalog: Dictionary = {}
var v030_establishments: Dictionary = {}
var v030_family_economy: Dictionary = {"configured": false, "status": "por_definir"}
var v030_npc_profiles: Dictionary = {}
var v030_npc_relationships: Dictionary = {}
var v030_city_events: Array = []
var v030_city_event_history: Array = []
var v030_service_state: Dictionary = {}
var v030_player_actions: Array = []
var v030_unemployment: Dictionary = {}
var v030_household_expenses: Dictionary = {}
var v030_economic_history: Array = []
var v030_world_metrics: Dictionary = {}

const SAVE_PATH := "user://valepolis_v0_3_0_save.json"
const ENTITIES := {
    "Município de Valepólis": "Administração municipal",
    "Hospital Municipal": "Saúde",
    "Comércio Local": "Comércio",
    "Escola de Valepólis": "Educação",
}

const PROFESSIONS := {
    "Professora": "Escola de Valepólis",
    "Comerciante": "Comércio Local",
    "Técnica": "Município de Valepólis",
}

const ENTITY_WORKPLACE := {
    "Escola de Valepólis": "Trabalho",
    "Comércio Local": "Comércio",
    "Município de Valepólis": "Trabalho",
    "Hospital Municipal": "Hospital",
}

# Horários funcionais da V0.3.0. Cada profissão liga a entidade,
# local de trabalho e janela de trabalho. O fim de semana usa rotina social.
const PROFESSION_SCHEDULES := {
    "Professora": {"start": 8, "end": 17, "break_start": 12, "break_end": 13},
    "Comerciante": {"start": 9, "end": 19, "break_start": 13, "break_end": 14},
    "Técnica": {"start": 8, "end": 16, "break_start": 12, "break_end": 13},
}

const LOCATIONS := {
    "Casa": Vector2(325, 330),
    "Trabalho": Vector2(430, 255),
    "Comércio": Vector2(300, 475),
    "Hospital": Vector2(220, 385),
}

# Geografia orgânica oficial: a posição de cada bairro deriva do significado
# do nome e da geografia aprovada de Valepólis. Não é uma grelha 5x5.
const V030_NEIGHBORHOODS: Array[String] = [
    "Nexora",
    "Altavira",
    "Rivéria",
    "Marévia",
    "Montélia",
    "Lúmora",
    "Florávia",
    "Pedrália",
    "Valeora",
    "Brisamar",
    "Fontélia",
    "Silvéria",
    "Portávia",
    "Lacéria",
    "Ventúria",
    "Olivéria",
    "Ribeora",
    "Solária",
    "Avelora",
    "Terrávia",
    "Altória",
    "Marivora",
    "Verdelis",
    "Estúria",
    "Pedravora",
]

const V030_NEIGHBORHOOD_POSITIONS := {
    "Marévia": Vector2(118, 55), "Brisamar": Vector2(245, 48), "Avelora": Vector2(385, 62),
    "Rivéria": Vector2(92, 175), "Nexora": Vector2(325, 300), "Altavira": Vector2(470, 145),
    "Lúmora": Vector2(180, 285), "Florávia": Vector2(245, 215), "Pedrália": Vector2(565, 115),
    "Montélia": Vector2(555, 70), "Valeora": Vector2(420, 205), "Fontélia": Vector2(145, 390), "Silvéria": Vector2(540, 220),
    "Portávia": Vector2(105, 510), "Lacéria": Vector2(270, 550), "Ventúria": Vector2(500, 330),
    "Olivéria": Vector2(385, 420), "Ribeora": Vector2(175, 515), "Solária": Vector2(315, 425),
    "Terrávia": Vector2(430, 535), "Altória": Vector2(585, 300),
    "Marivora": Vector2(80, 95), "Verdelis": Vector2(525, 455), "Estúria": Vector2(205, 95),
    "Pedravora": Vector2(600, 535)
}

var day := 1
var hour := 7
var weekday := 1 # 1=Segunda-feira ... 7=Domingo
var year := 0
var month := 0
var month_day := 0

var v030_personal_economy_configured := false
var energy := 80
var hunger := 20
var health := 100
var current_place := "Casa"
var selected_place := "Casa"
var event_day := 0
var event_open := false

# NPCs iniciais: personagens autónomas com rotina própria.
var npcs := [
    {"name":"Arel Valara", "place":"Casa", "residence":"Casa", "profession":"Professora", "entity":"Escola de Valepólis", "workplace":"Trabalho", "work_start":8, "work_end":17, "break_start":12, "break_end":13, "activity":"Casa", "next_destination":"Trabalho", "relationship":0, "memory":[]},
    {"name":"Néria Nerova", "place":"Casa", "residence":"Casa", "profession":"Comerciante", "entity":"Comércio Local", "workplace":"Comércio", "work_start":9, "work_end":19, "break_start":13, "break_end":14, "activity":"Casa", "next_destination":"Comércio", "relationship":0, "memory":[]},
    {"name":"Varel Loreno", "place":"Casa", "residence":"Casa", "profession":"Técnica", "entity":"Município de Valepólis", "workplace":"Trabalho", "work_start":8, "work_end":16, "break_start":12, "break_end":13, "activity":"Casa", "next_destination":"Trabalho", "relationship":0, "memory":[]},
]
var npc_markers: Dictionary = {}
var npc_dialog: Panel
var social_notice_day := {}
var autonomous_event_day := 0
var autonomous_event_text := ""
var npc_event_memory: Array = []
var npc_relations: Dictionary = {}

# Tempo dinâmico do universo: quando não existe nada relevante, o relógio
# acelera automaticamente. Interações e acontecimentos relevantes reduzem
# temporariamente a velocidade para não esconder eventos importantes.
var auto_time_enabled := true
var auto_time_accumulator := 0.0


@onready var v030_runtime: ValepolisSystemsRuntime = $ValepolisSystemsRuntime

@onready var stats: Label = $UI/Stats
@onready var subtitle: Label = $UI/Header/Sub
@onready var status: Label = $UI/Status
@onready var player_marker: ColorRect = $UI/Map/MapBody/Player
@onready var map_body: ColorRect = $UI/Map/MapBody



var v030_autosave_accumulator: float = 0.0
const V030_AUTOSAVE_SECONDS := 15.0
var v030_has_loaded_existing_save: bool = false
var v030_control_mode := ""
var v030_selected_branch := ""
var v030_selected_subcategory := ""
var v030_selected_profession := ""
var v030_selected_cargo := ""
var v030_selected_entity := ""
var v030_selected_character := ""
var v030_player_custom_name := ""
var v030_player_photo_path := ""
var v030_player_profile: Dictionary = {}
var v030_player_photo_preview: TextureRect
var v030_start_menu: Panel
var v030_start_content: VBoxContainer
# Interface de progressão narrativa: 20 temporadas, 10 episódios por temporada.
var v030_season_catalog: Dictionary = {}
var v030_selected_season_ui: int = 1
var v030_selected_episode_ui: int = 1
var v030_episode_selection_confirmed: bool = false
var v030_episode_completed: Array[String] = []
var v030_ui_city_background: SubViewportContainer
var v030_ui_city_viewport: SubViewport
var v030_master_catalog: Dictionary = {}
var v030_catalog_loaded: bool = false
var v030_catalog_validation: Dictionary = {}
var v030_entity_management: Dictionary = {}
var v030_entity_action_log: Array = []
var v030_entity_budget: Variant = null
var v030_new_game_pending := false

func _init_real_world_clock() -> void:
    # Uma nova partida começa no momento real em que é criada.
    # Depois disso, o calendário pertence ao universo do jogo e avança
    # apenas com o desenrolar da simulação.
    var now := Time.get_datetime_dict_from_system()
    year = int(now.get("year", 2026))
    month = int(now.get("month", 1))
    month_day = int(now.get("day", 1))
    hour = int(now.get("hour", 0))
    var minute := int(now.get("minute", 0))
    weekday = int(now.get("weekday", 1))
    # O motor atual trabalha em horas inteiras; a data/hora inicial é
    # arredondada para a hora atual e os minutos não são persistidos nesta camada.
    auto_time_accumulator = 0.0

func _weekday_name() -> String:
    var names := ["", "Segunda-feira", "Terça-feira", "Quarta-feira", "Quinta-feira", "Sexta-feira", "Sábado", "Domingo"]
    return names[clamp(weekday, 1, 7)]

func _date_text() -> String:
    return "%02d/%02d/%04d" % [month_day, month, year]

func _is_weekend() -> bool:
    return weekday >= 6

func _advance_calendar_day() -> void:
    v030_update_social_life()
    v030_update_social_relations()
    v030_update_service_life()
    v030_update_npc_daily_life()
    v030_apply_travel_conditions()
    v030_update_npc_travel()
    v030_update_npc_routine_positions()
    v030_complete_tick()
    v030_update_dependent_states()
    v030_update_family_member_state()
    v030_update_family_routines()
    day += 1
    weekday += 1
    if weekday > 7:
        weekday = 1
    month_day += 1
    if month_day > 30:
        month_day = 1
        month += 1
        if month > 12:
            month = 1
            year += 1
    _update_npc_routines()
    _update_npc_health()
    _generate_autonomous_event()
    _simulate_npc_social_life()

func _process(delta: float) -> void:
    # Escala visual global: verifica novos controlos a cada meio segundo,
    # evitando percorrer a árvore completa em todos os fotogramas.
    v030_ui_scale_accumulator += delta
    if v030_ui_scale_accumulator >= 0.5:
        v030_ui_scale_accumulator = 0.0
        _v030_apply_game_ui_scale(self)
    # Autosave independente da simulação: também grava se o relógio estiver
    # parado ou se estiver aberto um diálogo.
    v030_autosave_accumulator += delta
    if v030_autosave_accumulator >= V030_AUTOSAVE_SECONDS:
        v030_autosave_accumulator = 0.0
        _save_game_silent()

    if not auto_time_enabled or npc_dialog != null and npc_dialog.visible:
        return

    var speed := _world_time_speed()
    var seconds_per_game_hour := 10.0 / float(speed)
    auto_time_accumulator += delta

    if auto_time_accumulator >= seconds_per_game_hour:
        auto_time_accumulator = 0.0
        _advance_hour(true)
        v030_update_world()
        v030_integrated_tick()
        _check_social_encounters()
        _maybe_event()
        _refresh()


# UI MOBILE — escala e apresentação de jogo aplicadas uma única vez a cada nó.
# A função percorre também menus dinâmicos (ramos, subcategorias, profissões,
# entidades, diálogos e opções) sem alterar os dados ou callbacks dos controlos.
func _v030_apply_game_ui_scale(node: Node) -> void:
    if node == null:
        return
    var compact_hud := false
    if node is Control:
        var control := node as Control
        var node_path := str(control.get_path())
        compact_hud = node_path.contains("/ReferenceUI/CharacterNavigation") or node_path.contains("/ReferenceUI/EntityNavigation") or node_path.contains("/ReferenceUI/StateDashboard") or node_path.contains("/ReferenceUI/ReferenceEntityActions")
        if compact_hud:
            # O HUD novo já usa tipografia e alturas adaptativas próprias; a escala
            # global antiga não deve inflar os cartões nem empurrar a barra inferior.
            control.set_meta("v030_game_ui_scaled", true)
        elif not control.has_meta("v030_game_ui_scaled"):
            control.set_meta("v030_game_ui_scaled", true)
            var font_size := control.get_theme_font_size("font_size")
            if font_size > 0:
                var factor := 1.38 if control is Button else (1.24 if control is Label else 1.20)
                control.add_theme_font_size_override("font_size", maxi(14, int(round(float(font_size) * factor))))
            if control is Button:
                var button := control as Button
                button.custom_minimum_size.y = maxf(button.custom_minimum_size.y, 76.0)
                button.add_theme_color_override("font_hover_color", Color("#ffffff"))
                button.add_theme_color_override("font_pressed_color", Color("#ffe08a"))
                for state in ["normal", "hover", "pressed", "focus"]:
                    var original := button.get_theme_stylebox(state)
                    if original is StyleBoxFlat:
                        var polished := (original as StyleBoxFlat).duplicate() as StyleBoxFlat
                        polished.set_border_width_all(maxi(polished.border_width_left, 2))
                        polished.shadow_size = 7 if state == "hover" or state == "focus" else 3
                        polished.shadow_color = Color(0.02, 0.38, 0.62, 0.38) if state == "hover" or state == "focus" else Color(0.0, 0.0, 0.0, 0.30)
                        polished.content_margin_left = maxf(polished.content_margin_left, 16.0)
                        polished.content_margin_right = maxf(polished.content_margin_right, 16.0)
                        polished.content_margin_top = maxf(polished.content_margin_top, 12.0)
                        polished.content_margin_bottom = maxf(polished.content_margin_bottom, 12.0)
                        button.add_theme_stylebox_override(state, polished)
            elif control is CheckButton or control is CheckBox:
                control.custom_minimum_size.y = maxf(control.custom_minimum_size.y, 60.0)
        # Aumenta o espaçamento dos contentores sem mudar a ordem nem as ações.
        if (node is VBoxContainer or node is HBoxContainer) and not compact_hud:
            var container := node as BoxContainer
            container.add_theme_constant_override("separation", maxi(container.get_theme_constant("separation"), 12))
    for child in node.get_children():
        _v030_apply_game_ui_scale(child)

func _world_time_speed() -> int:
    # 1x: jogador/interação/ocorrência relevante.
    if event_open:
        return 1

    # Se há um NPC no mesmo local, o mundo mantém uma velocidade mais lenta
    # para permitir que encontros sociais sejam observados.
    for npc in npcs:
        if str(npc.get("place", "")) == current_place:
            return 2

    # Trabalho/serviços do jogador: atividade normal.
    if current_place in ["Trabalho", "Hospital", "Comércio"]:
        return 2

    # Rotina normal da cidade.
    if hour >= 7 and hour < 23:
        return 4

    # Períodos de pouca atividade.
    if hour >= 23 or hour < 6:
        return 16

    return 8

func _time_speed_text() -> String:
    return "AUTO %d×" % _world_time_speed()

func _v030_neighborhood_for_place(place: String) -> String:
    # Associação inicial estável entre os pontos principais e bairros.
    var mapping := {
        "Casa": "Nexora",
        "Trabalho": "Altavira",
        "Comércio": "Marévia",
        "Hospital": "Lúmora"
    }
    return str(mapping.get(place, v030_current_neighborhood))

var v030_neighborhood_badge: Label
var v030_map_neighborhood_labels: Array[Label] = []
var v030_map_scale: float = 1.0
var v030_map_origin: Vector2 = Vector2.ZERO

# Controlo interativo do mapa: zoom por botões, roda/pinça e deslocação.
var v030_map_zoom: float = 0.72
const V030_MAP_ZOOM_MIN: float = 0.58
const V030_MAP_ZOOM_MAX: float = 2.40
var v030_map_pan: Vector2 = Vector2.ZERO
var v030_touch_points: Dictionary = {}
var v030_pinch_active: bool = false
var v030_pinch_distance: float = 0.0
var v030_pinch_zoom: float = 1.0
var v030_pinch_center: Vector2 = Vector2.ZERO
var v030_map_dragging: bool = false
var v030_map_drag_last: Vector2 = Vector2.ZERO
var v030_zoom_in_button: Button
var v030_zoom_out_button: Button
var v030_detail_buttons: Array[Button] = []
var v030_center_button: Button
var v030_overview_button: Button
var v030_2d_map_button: Button
var v030_2d_map_panel: PanelContainer

func _v030_create_neighborhood_overlay() -> void:
    # Bairro atual fica visível no próprio mapa.
    v030_neighborhood_badge = Label.new()
    v030_neighborhood_badge.name = "BairroAtual"
    v030_neighborhood_badge.position = Vector2(12, 6)
    v030_neighborhood_badge.size = Vector2(300, 26)
    v030_neighborhood_badge.add_theme_font_size_override("font_size", 13)
    v030_neighborhood_badge.add_theme_color_override("font_color", Color(1, 0.88, 0.35, 1))
    v030_neighborhood_badge.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v030_neighborhood_badge.z_index = 20
    map_body.add_child(v030_neighborhood_badge)

    for child in map_body.get_children():
        if child.name.begins_with("Bairro_"):
            child.queue_free()
    v030_map_neighborhood_labels.clear()

    # Distribuição orgânica: costa/estuário a norte e oeste, centro urbano em Nexora,
    # encostas e zonas pedregosas a leste. Os nomes permanecem legíveis e afastados.
    for name in V030_NEIGHBORHOOD_POSITIONS.keys():
        if not name in V030_NEIGHBORHOODS:
            continue
        var label := Label.new()
        label.name = "Bairro_" + name.replace("á", "a").replace("é", "e").replace("í", "i").replace("ó", "o")
        label.text = name
        label.position = V030_NEIGHBORHOOD_POSITIONS[name] - Vector2(48, 12)
        label.size = Vector2(96, 24)
        label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
        label.add_theme_font_size_override("font_size", 10)
        label.add_theme_color_override("font_color", Color(1, 1, 1, 0.72))
        label.mouse_filter = Control.MOUSE_FILTER_IGNORE
        label.z_index = 15
        map_body.add_child(label)
        v030_map_neighborhood_labels.append(label)
    _v030_update_neighborhood_overlay()

func _v030_update_neighborhood_overlay() -> void:
    if is_instance_valid(v030_neighborhood_badge):
        v030_neighborhood_badge.text = "BAIRRO ATUAL: " + v030_current_neighborhood
        v030_neighborhood_badge.move_to_front()
    for label in v030_map_neighborhood_labels:
        if is_instance_valid(label):
            label.move_to_front()
    for i in range(v030_map_neighborhood_labels.size()):
        var label: Label = v030_map_neighborhood_labels[i]
        var name := str(label.text)
        if name == v030_current_neighborhood:
            label.add_theme_color_override("font_color", Color(1, 0.88, 0.35, 0.95))
            label.add_theme_font_size_override("font_size", 12)
        else:
            label.add_theme_color_override("font_color", Color(1, 1, 1, 0.58))
            label.add_theme_font_size_override("font_size", 10)


func v030_load_master_catalog() -> void:
    v030_master_catalog = {}
    v030_catalog_loaded = false
    v030_catalog_validation = {}
    # O catálogo de execução vive em data/. O ficheiro antigo na raiz fica
    # como fallback para preservar compatibilidade com instalações anteriores.
    var catalog_path := "res://data/entity_profession_taxonomy_v3.json"
    if not FileAccess.file_exists(catalog_path):
        catalog_path = "res://data/catalogo_v3.json"
    if not FileAccess.file_exists(catalog_path):
        push_warning("Catálogo de profissões e entidades V3.0.0 não encontrado.")
        return
    var file := FileAccess.open(catalog_path, FileAccess.READ)
    if file == null:
        push_warning("Não foi possível abrir o catálogo mestre.")
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        push_warning("Catálogo mestre inválido.")
        return
    v030_master_catalog = parsed
    v030_catalog_loaded = true
    v030_catalog_validation = _v030_validate_profession_entity_catalog()
    if not bool(v030_catalog_validation.get("ok", false)):
        push_warning("Auditoria do catálogo de entidades/profissões encontrou erros: %s" % str(v030_catalog_validation.get("errors", [])))

func _v030_validate_profession_entity_catalog() -> Dictionary:
    var errors: Array = []
    var profession_ids: Dictionary = {}
    var entity_ids: Dictionary = {}
    var compatibility_professions: Dictionary = {}
    var compatibility_entities: Dictionary = {}
    var compatibility_pairs: Dictionary = {}
    var branches: Array = v030_master_catalog.get("ramos", [])
    var subcategories: Array = v030_master_catalog.get("subcategorias", [])
    var professions: Array = v030_master_catalog.get("profissoes", [])
    var entities: Array = v030_master_catalog.get("entidades", [])
    var compatibilities: Array = v030_master_catalog.get("compatibilidade", [])
    for row in professions:
        if not row is Dictionary:
            errors.append("profession_row_invalid")
            continue
        var pid := str(row.get("ID", "")).strip_edges()
        if pid == "":
            errors.append("profession_id_missing")
        elif profession_ids.has(pid):
            errors.append("duplicate_profession_id:" + pid)
        else:
            profession_ids[pid] = true
    for row in entities:
        if not row is Dictionary:
            errors.append("entity_row_invalid")
            continue
        var eid := str(row.get("ID", "")).strip_edges()
        if eid == "":
            errors.append("entity_id_missing")
        elif entity_ids.has(eid):
            errors.append("duplicate_entity_id:" + eid)
        else:
            entity_ids[eid] = true
    for row in compatibilities:
        if not row is Dictionary:
            errors.append("compatibility_row_invalid")
            continue
        var pid := str(row.get("Profissão ID", "")).strip_edges()
        var eid := str(row.get("Entidade ID", "")).strip_edges()
        if not profession_ids.has(pid):
            errors.append("unknown_compatibility_profession:" + pid)
        if not entity_ids.has(eid):
            errors.append("unknown_compatibility_entity:" + eid)
        var pair := pid + "|" + eid
        if compatibility_pairs.has(pair):
            errors.append("duplicate_compatibility:" + pair)
        compatibility_pairs[pair] = true
        compatibility_professions[pid] = true
        compatibility_entities[eid] = true
    for pid in profession_ids.keys():
        if not compatibility_professions.has(pid):
            errors.append("profession_without_entity:" + str(pid))
    for eid in entity_ids.keys():
        if not compatibility_entities.has(eid):
            errors.append("entity_without_profession:" + str(eid))
    var metadata: Dictionary = v030_master_catalog.get("metadata", {})
    var expected: Dictionary = metadata.get("counts", {})
    var actual: Dictionary = {"ramos": branches.size(), "subcategorias": subcategories.size(), "profissoes": professions.size(), "entidades": entities.size(), "compatibilidade": compatibilities.size()}
    for key in actual.keys():
        if expected.has(key) and int(expected[key]) != int(actual[key]):
            errors.append("count_mismatch:%s" % str(key))
    var deferred_fields: Array = metadata.get("deferred_fields", [])
    return {"ok": errors.is_empty(), "counts": actual, "unique_profession_ids": profession_ids.size(), "unique_entity_ids": entity_ids.size(), "compatibility_pairs": compatibility_pairs.size(), "errors": errors, "deferred_fields": deferred_fields.duplicate(true)}

func _v030_is_tnur_internal_catalog_entity(entity_name: String) -> bool:
    # O catálogo de taxonomia conserva os nomes funcionais Base/Central/Serviço
    # TNUR, mas estes não podem ser selecionados como entidades independentes.
    return entity_name.to_lower().contains("tnur")

func _v030_catalog_ramos() -> Array:
    var result: Array = []
    for row in v030_master_catalog.get("ramos", []):
        var name := str(row.get("Ramo", "")).strip_edges()
        if name != "": result.append(name)
    return result

func _v030_catalog_subcategories(branch: String) -> Array:
    var result: Array = []
    for row in v030_master_catalog.get("subcategorias", []):
        if str(row.get("Ramo", "")) == branch:
            var name := str(row.get("Subcategoria", "")).strip_edges()
            if name != "": result.append(name)
    return result

func _v030_catalog_professions(branch: String, subcategory: String) -> Array:
    var result: Array = []
    for row in v030_master_catalog.get("profissoes", []):
        if str(row.get("Ramo", "")) == branch and str(row.get("Subcategoria", "")) == subcategory:
            var name := str(row.get("Profissão", "")).strip_edges()
            if name != "": result.append(name)
    return result

func _v030_catalog_entities(branch: String, subcategory: String) -> Array:
    var result: Array = []
    var valid_names: Dictionary = {}
    # A entidade não depende de uma personagem. A subcategoria filtra a
    # navegação quando existe correspondência de profissão/compatibilidade.
    for row in v030_master_catalog.get("entidades", []):
        var catalog_entity_name := str(row.get("Entidade", "")).strip_edges()
        if str(row.get("Ramo", "")) == branch and catalog_entity_name != "" and not _v030_is_tnur_internal_catalog_entity(catalog_entity_name):
            valid_names[catalog_entity_name] = true
    if valid_names.is_empty():
        return result
    if subcategory == "":
        return valid_names.keys()
    var profession_ids: Dictionary = {}
    for row in v030_master_catalog.get("profissoes", []):
        if str(row.get("Ramo", "")) == branch and str(row.get("Subcategoria", "")) == subcategory:
            profession_ids[str(row.get("ID", ""))] = true
    var entity_ids: Dictionary = {}
    for row in v030_master_catalog.get("compatibilidade", []):
        if profession_ids.has(str(row.get("Profissão ID", ""))):
            var eid := str(row.get("Entidade ID", ""))
            if eid != "": entity_ids[eid] = true
    for row in v030_master_catalog.get("entidades", []):
        var eid := str(row.get("ID", ""))
        var ename := str(row.get("Entidade", "")).strip_edges()
        if str(row.get("Ramo", "")) == branch and (entity_ids.is_empty() or entity_ids.has(eid)) and ename != "" and not _v030_is_tnur_internal_catalog_entity(ename):
            if not result.has(ename): result.append(ename)
    return result

func _v030_catalog_entity_record(entity_name: String) -> Dictionary:
    for row in v030_master_catalog.get("entidades", []):
        if str(row.get("Entidade", "")).strip_edges() == entity_name:
            return row.duplicate(true)
    return {}

func _v030_build_player_profile() -> void:
    if v030_control_mode != "personagem":
        v030_player_profile = {}
        return
    var identity := "%s|%s|%s|%s" % [v030_player_custom_name, v030_selected_branch, v030_selected_profession, v030_selected_cargo]
    var seed_value: int = abs(identity.hash())
    var personalities: Array = ["Calmo", "Determinado", "Sociável", "Prudente", "Curioso", "Resiliente", "Organizado", "Empático"]
    var aptitudes: Array = ["Comunicação", "Liderança", "Análise", "Coordenação", "Criatividade", "Precisão", "Resolução de problemas", "Trabalho em equipa"]
    var educations: Array = ["Formação básica", "Formação profissional", "Curso técnico", "Ensino superior", "Formação especializada"]
    var goals: Array = ["Estabilidade", "Progressão profissional", "Aprendizagem", "Independência", "Reconhecimento", "Família", "Serviço à comunidade"]
    v030_player_profile = {
        "nome": v030_player_custom_name,
        "ramo": v030_selected_branch,
        "subcategoria": v030_selected_subcategory,
        "profissao": v030_selected_profession,
        "cargo": v030_selected_cargo,
        "fotografia": v030_player_photo_path,
        "residencia": current_place,
        "bairro": v030_current_neighborhood,
        "idade": 18 + (seed_value % 43),
        "personalidade": personalities[seed_value % personalities.size()],
        "aptidao_principal": aptitudes[(seed_value / 7) % aptitudes.size()],
        "formacao": educations[(seed_value / 13) % educations.size()],
        "experiencia_anos": seed_value % 16,
        "objetivo": goals[(seed_value / 19) % goals.size()],
        "energia_base": 70 + (seed_value % 31),
        "competencia_profissional": 55 + ((seed_value / 23) % 46),
        "sociabilidade": 40 + ((seed_value / 29) % 61),
        "resiliencia": 40 + ((seed_value / 31) % 61)
    }

func _v030_player_profile_text() -> String:
    if v030_player_profile.is_empty():
        return "Características ainda não geradas."
    return "Nome: %s\nIdade: %d\nPersonalidade: %s\nAptidão principal: %s\nFormação: %s\nExperiência: %d anos\nObjetivo: %s\nCompetência profissional: %d/100\nSociabilidade: %d/100\nResiliência: %d/100" % [str(v030_player_profile.get("nome", v030_player_custom_name)),
        int(v030_player_profile.get("idade", 0)), str(v030_player_profile.get("personalidade", "")),
        str(v030_player_profile.get("aptidao_principal", "")), str(v030_player_profile.get("formacao", "")),
        int(v030_player_profile.get("experiencia_anos", 0)), str(v030_player_profile.get("objetivo", "")),
        int(v030_player_profile.get("competencia_profissional", 0)), int(v030_player_profile.get("sociabilidade", 0)),
        int(v030_player_profile.get("resiliencia", 0))
    ]

func _v030_generic_cargos(profession: String) -> Array:
    var existing: Array = V030_PROFESSION_CARGOS.get(profession, [])
    if not existing.is_empty():
        return existing
    # O catálogo mestre não fixa cargos; a seleção mantém-se no fluxo de
    # jogo sem atribuir cargos específicos ao catálogo profissional.
    return ["Profissional", "Responsável"]

# =========================
# V0.3.0 — CIDADE VIVA AVANÇADA
# =========================
const V030_VERSION := "0.3.0"
const V030_CORE_STATE_PATH := "user://valepolis_v0_3_0_state.json"
var v030_initialized := false
var v030_city_state: Dictionary = {
    "crime": 8.0, "satisfaction": 72.0, "employment": null,
    "traffic": 28.0, "commerce": 64.0, "public_services": 70.0,
    "news": [], "history": []
}
var v030_character_ai: Dictionary = {}
# IA pessoal: assume tarefas repetitivas e de manutenção básica sem exigir microgestão.
# Decisões relevantes continuam sob controlo do jogador.
var v030_personal_ai: Dictionary = {
    "enabled": true,
    "last_action": "nenhuma",
    "last_reason": "",
    "action_count": 0,
    "manual_override_tick": 0,
    "routine_target": ""
}
var v030_relationship_events: Array = []
var v030_incidents: Array = []
var v030_traffic_routes: Dictionary = {}
var v030_entity_metrics: Dictionary = {}
var v030_economy: Dictionary = {"configured": false, "status": "por_definir", "history": []}
var v030_news: Array = []
var v030_simulation_ticks := 0


# =========================
# V0.3.0 — UI PROFISSIONAL INTEGRADA
# =========================
var v030_ui_ready := false
var v030_mode_nav: HBoxContainer
var v030_context_panel: Panel
var v030_context_title: Label
var v030_context_info: Label
var v030_mode_hint: Label
var v030_ui_scale_accumulator: float = 0.0

func _v030_style_panel(panel: Panel, color: Color = Color(0.035, 0.075, 0.11, 0.96), border: Color = Color(0.12, 0.28, 0.38, 1.0)) -> void:
    var style := StyleBoxFlat.new()
    style.bg_color = color
    style.border_color = border
    style.set_border_width_all(1)
    style.set_corner_radius_all(12)
    style.content_margin_left = 12
    style.content_margin_right = 12
    style.content_margin_top = 8
    style.content_margin_bottom = 8
    panel.add_theme_stylebox_override("panel", style)

func _v030_make_mode_button(name_value: String, text_value: String) -> Button:
    var b := Button.new()
    b.name = name_value
    b.text = text_value
    b.focus_mode = Control.FOCUS_NONE
    b.custom_minimum_size = Vector2(0, 58)
    b.add_theme_font_size_override("font_size", 16)
    b.add_theme_color_override("font_color", Color("#dbeaf2"))
    b.add_theme_color_override("font_hover_color", Color("#ffffff"))
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color("#081724")
    normal.border_color = Color("#17364a")
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(10)
    var hover := normal.duplicate()
    hover.bg_color = Color("#0d2a3b")
    hover.border_color = Color("#2aa8dc")
    var pressed := normal.duplicate()
    pressed.bg_color = Color("#123b50")
    pressed.border_color = Color("#57c7ef")
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", pressed)
    b.add_theme_stylebox_override("focus", pressed)
    return b

func _v030_style_action_button(button: Button, accent: String = "#2aa8dc") -> void:
    button.focus_mode = Control.FOCUS_NONE
    button.add_theme_font_size_override("font_size", 16)
    button.add_theme_color_override("font_color", Color("#e7f3fa"))
    button.add_theme_color_override("font_hover_color", Color("#ffffff"))
    button.add_theme_color_override("font_disabled_color", Color("#70808a"))
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color("#07131e")
    normal.border_color = Color("#17384d")
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(10)
    normal.content_margin_left = 8
    normal.content_margin_right = 8
    var hover := normal.duplicate()
    hover.bg_color = Color("#0c2535")
    hover.border_color = Color(accent)
    var pressed := normal.duplicate()
    pressed.bg_color = Color("#12384c")
    pressed.border_color = Color(accent)
    button.add_theme_stylebox_override("normal", normal)
    button.add_theme_stylebox_override("hover", hover)
    button.add_theme_stylebox_override("pressed", pressed)
    button.add_theme_stylebox_override("focus", pressed)

func _v030_add_professional_nav_item(text_value: String, name_value: String) -> Button:
    var b := _v030_make_mode_button(name_value, text_value)
    b.custom_minimum_size = Vector2(104, 54)
    b.add_theme_font_size_override("font_size", 14)
    v030_mode_nav.add_child(b)
    return b

func _v030_ref_button(text_value: String, name_value: String, accent: String = "#2aa8dc") -> Button:
    var b := Button.new()
    b.name = name_value
    b.text = text_value
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", 15)
    b.custom_minimum_size = Vector2(0, 58)
    b.add_theme_color_override("font_color", Color("#dbeaf2"))
    b.add_theme_color_override("font_hover_color", Color("#ffffff"))
    var normal := StyleBoxFlat.new()
    normal.bg_color = Color("#071827")
    normal.border_color = Color("#16384e")
    normal.set_border_width_all(1)
    normal.set_corner_radius_all(9)
    normal.content_margin_left = 6
    normal.content_margin_right = 6
    var hover := normal.duplicate()
    hover.bg_color = Color("#0d2b3c")
    hover.border_color = Color(accent)
    var pressed := normal.duplicate()
    pressed.bg_color = Color("#12394d")
    pressed.border_color = Color(accent)
    b.add_theme_stylebox_override("normal", normal)
    b.add_theme_stylebox_override("hover", hover)
    b.add_theme_stylebox_override("pressed", pressed)
    b.add_theme_stylebox_override("focus", pressed)
    return b

func _v030_ref_panel(name_value: String) -> Panel:
    var p := Panel.new()
    p.name = name_value
    _v030_style_panel(p, Color("#061522e8"), Color("#173b50"))
    return p

func _v030_ref_label(parent: Node, text_value: String, size_px: int = 12, color_hex: String = "#dbeaf2") -> Label:
    var l := Label.new()
    l.text = text_value
    l.add_theme_font_size_override("font_size", size_px)
    l.add_theme_color_override("font_color", Color(color_hex))
    parent.add_child(l)
    return l

func _v030_build_professional_ui() -> void:
    if v030_ui_ready:
        return
    v030_ui_ready = true
    var ui: Control = $UI

    # Interface V0.3.0 — dashboard de estado com navegação persistente.
    # A camada antiga continua na árvore para manter compatibilidade com a simulação
    # e com os testes; a apresentação principal passa a ser construída aqui.
    var ref_root := Control.new()
    ref_root.name = "ReferenceUI"
    ref_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    ref_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(ref_root)
    ref_root.move_to_front()

    var char_nav := HBoxContainer.new()
    char_nav.name = "CharacterNavigation"
    char_nav.add_theme_constant_override("separation", 6)
    char_nav.mouse_filter = Control.MOUSE_FILTER_STOP
    ref_root.add_child(char_nav)
    var char_items := [
        ["⌖  CIDADE", "City", "#2aa8dc"],
        ["◉  VIDA", "Life", "#42d98a"],
        ["♙  PESSOAS", "People", "#2aa8dc"],
        ["▤  MISSÕES", "Missions", "#f1b24a"],
        ["☰  MAIS", "More", "#8ca8bd"]
    ]
    for item in char_items:
        var b := _v030_ref_button(str(item[0]), str(item[1]), str(item[2]))
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.custom_minimum_size = Vector2(0, 54)
        b.add_theme_font_size_override("font_size", 13)
        char_nav.add_child(b)
        match str(item[1]):
            "City": b.pressed.connect(_v030_set_mode.bind("mapa"))
            "Life": b.pressed.connect(_v030_set_mode.bind("personagem"))
            "People": b.pressed.connect(_v030_open_section.bind("Telefone"))
            "Missions": b.pressed.connect(_v030_open_section.bind("Missoes"))
            _: b.pressed.connect(_v030_open_section.bind("Mais"))

    var entity_nav := HBoxContainer.new()
    entity_nav.name = "EntityNavigation"
    entity_nav.add_theme_constant_override("separation", 6)
    entity_nav.mouse_filter = Control.MOUSE_FILTER_STOP
    ref_root.add_child(entity_nav)
    var entity_items := [
        ["⌖  PAINEL", "EntityPanel", "#2aa8dc"],
        ["▣  BASE", "Base", "#42d98a"],
        ["📍 INSTALAÇÕES", "Instalacoes", "#2aa8dc"],
        ["🚨  OPERAÇÕES", "Ops", "#e35b62"],
        ["☰  MAIS", "More", "#8ca8bd"]
    ]
    for item in entity_items:
        var b := _v030_ref_button(str(item[0]), str(item[1]), str(item[2]))
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.custom_minimum_size = Vector2(0, 54)
        b.add_theme_font_size_override("font_size", 13)
        entity_nav.add_child(b)
        match str(item[1]):
            "EntityPanel": b.pressed.connect(_v030_set_mode.bind("entidade"))
            "Base": b.pressed.connect(_v030_open_section.bind("Base"))
            "Instalacoes": b.pressed.connect(_v030_open_section.bind("Instalacoes"))
            "Ops": b.pressed.connect(_v030_open_section.bind("MissoesE"))
            _: b.pressed.connect(_v030_open_section.bind("Mais"))

    # Compatibilidade: os painéis de contexto antigos continuam disponíveis,
    # mas o dashboard novo é o painel de estado principal.
    var entity_filters := _v030_ref_panel("EntityFilters")
    ref_root.add_child(entity_filters)
    entity_filters.visible = false
    var context := _v030_ref_panel("ReferenceContext")
    ref_root.add_child(context)
    var context_title := _v030_ref_label(context, "ESTADO DO JOGO", 13, "#f3d56f")
    context_title.name = "ContextTitle"
    var context_info := _v030_ref_label(context, "A sincronizar com a simulação…", 11, "#c8d7df")
    context_info.name = "ContextInfo"
    context_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    var entity_context := _v030_ref_panel("EntityContext")
    ref_root.add_child(entity_context)
    var entity_title := _v030_ref_label(entity_context, "ENTIDADE ATIVA", 13, "#f3d56f")
    entity_title.name = "EntityTitle"
    var entity_info := _v030_ref_label(entity_context, "Configuração operacional por validar.", 11, "#c8d7df")
    entity_info.name = "EntityInfo"
    entity_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART

    var state_panel := _v030_ref_panel("StateDashboard")
    ref_root.add_child(state_panel)
    var state_grid := GridContainer.new()
    state_grid.name = "StateGrid"
    state_grid.add_theme_constant_override("h_separation", 7)
    state_grid.add_theme_constant_override("v_separation", 6)
    state_panel.add_child(state_grid)
    var state_cards := [
        ["WORLD", "StateWorld", "TEMPO DO JOGO", "A sincronizar…", "Data e calendário"],
        ["CITY", "StateCity", "ESTADO DA CIDADE", "25 bairros", "Trânsito e meteorologia"],
        ["ACTIVITY", "StateActivity", "ATIVIDADE", "A preparar…", "Missões e eventos registados"],
        ["PLAYER", "StatePlayer", "ESTADO ATUAL", "Sem seleção", "Dados reais da partida"]
    ]
    for item in state_cards:
        var card := PanelContainer.new()
        card.name = str(item[1])
        card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        card.custom_minimum_size = Vector2(0, 60)
        card.add_theme_stylebox_override("panel", _v030_premium_style("#0a1b28", "#244b60", 10))
        state_grid.add_child(card)
        var stack := VBoxContainer.new()
        stack.add_theme_constant_override("separation", 1)
        card.add_child(stack)
        var heading := Label.new()
        heading.name = "Heading"
        heading.text = str(item[2])
        heading.add_theme_font_size_override("font_size", 10)
        heading.add_theme_color_override("font_color", Color("#8fb4c8"))
        stack.add_child(heading)
        var value := Label.new()
        value.name = "Value"
        value.text = str(item[3])
        value.add_theme_font_size_override("font_size", 15)
        value.add_theme_color_override("font_color", Color("#f3d56f"))
        value.clip_text = true
        stack.add_child(value)
        var detail := Label.new()
        detail.name = "Detail"
        detail.text = str(item[4])
        detail.add_theme_font_size_override("font_size", 10)
        detail.add_theme_color_override("font_color", Color("#b9ccd7"))
        detail.clip_text = true
        stack.add_child(detail)

    var entity_tabs := HBoxContainer.new()
    entity_tabs.name = "EntityTabs"
    ref_root.add_child(entity_tabs)
    entity_tabs.visible = false
    var vehicles := _v030_ref_panel("EntityVehicles")
    ref_root.add_child(vehicles)
    vehicles.visible = false
    var vehicle_title := _v030_ref_label(vehicles, "FROTA", 12, "#dbeaf2")
    vehicle_title.name = "VehicleTitle"
    var entity_actions := HBoxContainer.new()
    entity_actions.name = "ReferenceEntityActions"
    entity_actions.add_theme_constant_override("separation", 6)
    ref_root.add_child(entity_actions)
    for item in [["OPERAÇÕES", "MissoesE", "#e35b62"], ["EQUIPAS", "Equipas", "#2aa8dc"], ["VEÍCULOS", "Veiculos", "#42d98a"], ["INSTALAÇÕES", "Instalacoes", "#2aa8dc"], ["RECURSOS", "RecursosE", "#f1b24a"]]:
        var b := _v030_ref_button(str(item[0]), "EntityAction" + str(entity_actions.get_child_count()), str(item[2]))
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.custom_minimum_size = Vector2(0, 62)
        b.add_theme_font_size_override("font_size", 12)
        entity_actions.add_child(b)
        b.pressed.connect(_v030_open_section.bind(str(item[1])))

    # A navegação é persistente; a barra antiga deixa de ocupar espaço visual.
    $UI/Bottom.visible = false
    $UI/Status.visible = false
    $UI/Actions.visible = true
    _v030_update_state_dashboard()

func _v030_close_section() -> void:
    var panel := get_node_or_null("UI/ReferenceUI/SectionPanel") as Control
    if panel != null:
        panel.visible = false
    if has_node("UI/Map"):
        $UI/Map.visible = true

func _v030_runtime_entity_id(entity_name: String) -> String:
    var normalized := entity_name.to_lower().strip_edges()
    if "brigada" in normalized: return "BRIGADA"
    if "s.u.e" in normalized or normalized == "sue" or "serviço de urgência" in normalized: return "SUE"
    if "tnur" in normalized or "transporte não urgente" in normalized: return "TNUR"
    if "polícia" in normalized or "policia" in normalized or "esquadra" in normalized: return "POLICIA"
    if "município" in normalized or "municipio" in normalized or "câmara" in normalized: return "MUNICIPIO"
    if "hospital" in normalized or "clínica" in normalized: return "HOSPITAL"
    if "escola" in normalized or "educação" in normalized: return "ESCOLA"
    if "comércio" in normalized or "comercio" in normalized or "mercado" in normalized or "empresa" in normalized: return "COMERCIO"
    if "serviço público" in normalized or "servicos publicos" in normalized or "infraestrutura" in normalized: return "SERVICOS_PUBLICOS"
    return entity_name if v030_runtime.entity_profiles.has(entity_name) else ""

func _v030_section_asset(section: String) -> String:
    match section:
        "Cidade": return "cidade"
        "Operacoes", "Missoes", "MissoesE": return "operacoes"
        "Base", "PessoasE", "RecursosE", "Veiculos", "Equipas", "FinancasE", "Instalacoes": return "entidades"
        "Telefone": return "telefone"
        _: return "cidade"

func _v030_entity_asset_id() -> String:
    var name := str(v030_selected_entity).to_lower()
    if "brigada" in name: return "brigada"
    if "s.u.e" in name or "sue" in name: return "sue"
    if "tnur" in name: return "tnur"
    if "polícia" in name or "policia" in name: return "policia"
    if "hospital" in name: return "hospital"
    if "escola" in name: return "escola"
    if "comércio" in name or "comercio" in name or "mercado" in name: return "comercio"
    return "servicos_publicos"

func _v030_premium_style(bg: String, border_color: String, radius: int = 12) -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = Color(bg)
    style.border_color = Color(border_color)
    style.set_border_width_all(1)
    style.set_corner_radius_all(radius)
    style.content_margin_left = 12.0
    style.content_margin_right = 12.0
    style.content_margin_top = 10.0
    style.content_margin_bottom = 10.0
    return style

func _v030_premium_card(parent: Control, heading: String, value: String, detail: String = "") -> PanelContainer:
    var card := PanelContainer.new()
    card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    card.add_theme_stylebox_override("panel", _v030_premium_style("#0b1d2a", "#28536b", 10))
    parent.add_child(card)
    var content := VBoxContainer.new()
    content.add_theme_constant_override("separation", 4)
    card.add_child(content)
    var title_label := Label.new()
    title_label.text = heading
    title_label.add_theme_font_size_override("font_size", 12)
    title_label.add_theme_color_override("font_color", Color("#b9ccd7"))
    content.add_child(title_label)
    var value_label := Label.new()
    value_label.text = value
    value_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    value_label.add_theme_font_size_override("font_size", 18)
    value_label.add_theme_color_override("font_color", Color("#f3d56f"))
    content.add_child(value_label)
    if detail != "":
        var detail_label := Label.new()
        detail_label.text = detail
        detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        detail_label.add_theme_font_size_override("font_size", 11)
        detail_label.add_theme_color_override("font_color", Color("#b9ccd7"))
        content.add_child(detail_label)
    return card

func _relation_label(value: Variant) -> String:
    var score := int(value) if value is int or value is float else 0
    if score >= 60:
        return "Relação próxima"
    if score >= 20:
        return "Relação positiva"
    if score <= -60:
        return "Relação conflituosa"
    if score <= -20:
        return "Relação tensa"
    return "Relação neutra"

func _v030_section_add_text(content_box: VBoxContainer, value: String, size_px: int = 17) -> void:
    var label := RichTextLabel.new()
    label.bbcode_enabled = true
    label.fit_content = true
    label.scroll_active = false
    label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    label.text = value
    label.add_theme_font_size_override("normal_font_size", size_px)
    content_box.add_child(label)

func _v030_section_add_card_row(content_box: VBoxContainer, cards: Array) -> void:
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation", 8)
    row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content_box.add_child(row)
    for card in cards:
        _v030_premium_card(row, str(card[0]), str(card[1]), str(card[2]))

func _v030_open_section(section: String) -> void:
    if not has_node("UI/ReferenceUI"):
        return
    var root: Control = $UI/ReferenceUI
    var panel := root.get_node_or_null("SectionPanel") as PanelContainer
    if panel == null:
        panel = PanelContainer.new()
        panel.name = "SectionPanel"
        panel.mouse_filter = Control.MOUSE_FILTER_STOP
        panel.z_index = 20
        root.add_child(panel)
        var panel_style := _v030_premium_style("#07131d", "#214a63", 16)
        panel.add_theme_stylebox_override("panel", panel_style)

        var outer := VBoxContainer.new()
        outer.name = "Outer"
        outer.add_theme_constant_override("separation", 8)
        panel.add_child(outer)

        var hero := PanelContainer.new()
        hero.name = "Hero"
        hero.custom_minimum_size = Vector2(0, 104)
        hero.add_theme_stylebox_override("panel", _v030_premium_style("#0a2030", "#2b6b8a", 14))
        outer.add_child(hero)
        var hero_row := HBoxContainer.new()
        hero_row.name = "HeroRow"
        hero_row.add_theme_constant_override("separation", 12)
        hero.add_child(hero_row)
        var image := TextureRect.new()
        image.name = "HeroImage"
        image.custom_minimum_size = Vector2(96, 88)
        image.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
        image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        hero_row.add_child(image)
        var hero_text := VBoxContainer.new()
        hero_text.name = "HeroText"
        hero_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        hero_row.add_child(hero_text)
        var title := Label.new()
        title.name = "Title"
        title.add_theme_font_size_override("font_size", 21)
        title.add_theme_color_override("font_color", Color("#f3d56f"))
        hero_text.add_child(title)
        var subtitle := Label.new()
        subtitle.name = "Subtitle"
        subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        subtitle.add_theme_font_size_override("font_size", 11)
        subtitle.add_theme_color_override("font_color", Color("#b9ccd7"))
        hero_text.add_child(subtitle)

        var scroll := ScrollContainer.new()
        scroll.name = "Scroll"
        scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
        scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
        outer.add_child(scroll)
        var content := VBoxContainer.new()
        content.name = "Content"
        content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        content.add_theme_constant_override("separation", 10)
        scroll.add_child(content)

    var hero: PanelContainer = panel.get_node("Outer/Hero")
    var hero_image: TextureRect = panel.get_node("Outer/Hero/HeroRow/HeroImage")
    var title_label: Label = panel.get_node("Outer/Hero/HeroRow/HeroText/Title")
    var subtitle_label: Label = panel.get_node("Outer/Hero/HeroRow/HeroText/Subtitle")
    var content_box: VBoxContainer = panel.get_node("Outer/Scroll/Content")
    # O cartão da personagem precisa de altura suficiente para uma pré-visualização
    # vertical. Um viewport panorâmico cortava a cabeça e as pernas no Android.
    hero.custom_minimum_size = Vector2(0, 220) if section == "Personagem" else Vector2(0, 104)
    for child in content_box.get_children():
        child.queue_free()

    title_label.text = section.to_upper()
    subtitle_label.text = "VALEPÓLIS • V0.3.0 • Estado atualizado pela simulação"
    var asset_kind := "panel"
    var asset_id := _v030_section_asset(section)
    var hero_row: Node = hero_image.get_parent()
    for stale_preview_name in ["Generated3DCharacterHero", "Generated3DMapHero"]:
        var stale_preview := hero_row.get_node_or_null(stale_preview_name)
        if stale_preview != null:
            stale_preview.free()
    if section in ["Mapa", "MapaE", "Personagem"]:
        # Mapa/personagem usam previews nativas do Godot, nunca os placeholders antigos.
        hero_image.visible = false
        var preview_name := "Generated3DCharacterHero" if section == "Personagem" else "Generated3DMapHero"
        var generated_preview: Control
        if section == "Personagem":
            var character_seed: int = int(abs((str(v030_selected_character) + str(v030_selected_profession)).hash()))
            generated_preview = _v030_create_runtime_character_preview(character_seed, true, str(v030_selected_entity) + " " + str(v030_selected_profession))
        else:
            generated_preview = _v030_create_runtime_map_preview()
        generated_preview.name = preview_name
        hero_row.add_child(generated_preview)
        hero_row.move_child(generated_preview, 0)
    else:
        if section in ["Base", "PessoasE", "RecursosE", "Veiculos", "Equipas", "FinancasE", "Instalacoes"]:
            asset_kind = "entity"
            asset_id = _v030_entity_asset_id()
        var asset_path := _v030_asset_path(asset_kind, asset_id)
        hero_image.texture = load(asset_path) if ResourceLoader.exists(asset_path) else null
        hero_image.visible = true


    match section:
        "Personagem":
            _v030_section_add_text(content_box, "[font_size=20][b]PERFIL DA PERSONAGEM[/b][/font_size]\nVida, trabalho, relações, necessidades e evolução.")
            _v030_section_add_card_row(content_box, [["NOME", v030_player_custom_name if v030_player_custom_name != "" else "PERSONAGEM", "#29a9ff"], ["PROFISSÃO", v030_selected_profession if v030_selected_profession != "" else "—", "#f3d56f"], ["BAIRRO", v030_current_neighborhood, "#35d58a"]])
            var profile_details := _v030_player_profile_text()
            if v030_selected_character == "" or v030_selected_character == "PERSONAGEM":
                profile_details = "Ainda não escolheste uma personagem. A pré-visualização 3D é gerada automaticamente; confirma a personagem para criar o perfil individual."
            elif v030_player_profile.is_empty():
                profile_details = "Personagem selecionada. A preparar os dados do perfil individual."
            _v030_section_add_text(content_box, profile_details + "\n\nLocal: %s\nEconomia pessoal: por definir\nEnergia: %d\nFome: %d/100\nSaúde: %d" % [current_place, energy, hunger, health])
        "PessoasE":
            _v030_section_add_text(content_box, "[font_size=20][b]PESSOAS DA ENTIDADE[/b][/font_size]\n\nEfetivos, funções, turnos e composição das equipas ficam por definir em conjunto. Não foi atribuído qualquer número de trabalhadores.")
            _v030_section_add_text(content_box, "Entidade: %s\nEstado do registo: catálogo funcional disponível; dimensionamento pendente." % v030_selected_entity)
        "RecursosE":
            _v030_section_add_text(content_box, "[font_size=20][b]RECURSOS DA ENTIDADE[/b][/font_size]\n\nQuantidade de instalações, viaturas e inventário, assim como orçamento e saldo, ficam deliberadamente por definir. Não foram inventados valores iniciais.")
            _v030_section_add_card_row(content_box, [["INSTALAÇÕES", "Por definir", "#29a9ff"], ["VIATURAS / INVENTÁRIO", "Por definir", "#35d58a"], ["ORÇAMENTO / SALDO", "Por definir", "#f3d56f"]])
        "Operacoes":
            _v030_section_add_text(content_box, "[font_size=20][b]OPERAÇÕES[/b][/font_size]\nO catálogo define competências e restrições por entidade. O despacho real depende do registo posterior de equipas e viaturas compatíveis.")
            _v030_section_add_card_row(content_box, [["CATÁLOGO", "Disponível", "#29a9ff"], ["RECURSOS", "Por registar", "#55d99a"], ["DESPACHO", "A validar", "#ffb84d"]])
            if event_open:
                _v030_section_add_text(content_box, "[font_size=17][color=#f3d56f][b]⚠ NOVA OCORRÊNCIA[/b][/color][/font_size]\nInformação incompleta: alguém precisa de ajuda perto do hospital.")
                var actions := HBoxContainer.new()
                actions.add_theme_constant_override("separation", 8)
                content_box.add_child(actions)
                var help := Button.new(); help.text = "AJUDAR"; help.pressed.connect(_event_help); actions.add_child(help)
                var ignore := Button.new(); ignore.text = "IGNORAR"; ignore.pressed.connect(_event_ignore); actions.add_child(ignore)
        "Mais":
            _v030_section_add_text(content_box, "[font_size=20][b]CENTRO DE CONTROLO[/b][/font_size]\nEscolhe um painel. Os dados refletem o estado registado pela simulação; valores não configurados permanecem identificados como pendentes.")
            var more_grid := GridContainer.new()
            more_grid.columns = 2 if get_viewport_rect().size.x < 620.0 else 3
            more_grid.add_theme_constant_override("h_separation", 8)
            more_grid.add_theme_constant_override("v_separation", 8)
            more_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            content_box.add_child(more_grid)
            var more_items: Array = []
            if v030_control_mode == "entidade":
                more_items = [["BASE", "Base"], ["INSTALAÇÕES", "Instalacoes"], ["VEÍCULOS", "Veiculos"], ["EQUIPAS", "Equipas"], ["OPERAÇÕES", "MissoesE"], ["FINANÇAS", "FinancasE"], ["RELATÓRIOS", "Relatorios"], ["DEFINIÇÕES", "OpcoesE"]]
            else:
                more_items = [["PERSONAGEM", "Personagem"], ["INVENTÁRIO", "Inventario"], ["TELEFONE", "Telefone"], ["MISSÕES", "Missoes"], ["NOTÍCIAS", "Noticias"], ["FINANÇAS", "Financas"], ["TEMPORADAS", "Temporadas"], ["CIDADE", "Cidade"], ["DEFINIÇÕES", "Opcoes"]]
            for item in more_items:
                var more_button := _v030_ref_button(str(item[0]), "More" + str(item[1]), "#2aa8dc")
                more_button.custom_minimum_size = Vector2(0, 58)
                more_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
                more_grid.add_child(more_button)
                if str(item[1]) == "Temporadas":
                    more_button.pressed.connect(_open_seasons_from_game)
                else:
                    more_button.pressed.connect(_v030_open_section.bind(str(item[1])))
            var utility_row := HBoxContainer.new()
            utility_row.add_theme_constant_override("separation", 8)
            content_box.add_child(utility_row)
            var save_button := _v030_ref_button("GUARDAR PARTIDA", "MoreSave", "#42d98a")
            save_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            save_button.pressed.connect(_save_game)
            utility_row.add_child(save_button)
            var load_button := _v030_ref_button("CARREGAR PARTIDA", "MoreLoad", "#f1b24a")
            load_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            load_button.pressed.connect(_load_game)
            utility_row.add_child(load_button)
        "NovoJogo":
            _v030_section_add_text(content_box, "[font_size=20][b]NOVA PARTIDA[/b][/font_size]\nExiste uma partida guardada. Começar uma nova partida substitui a atual.")
            var start := Button.new(); start.text = "COMEÇAR NOVO JOGO"; start.pressed.connect(_start_new_game); content_box.add_child(start)
        "Sobre":
            _v030_section_add_text(content_box, "[font_size=20][b]QUANDO TOCA A SIRENE[/b][/font_size]\nVALÉPOLIS • V0.3.0\n\nCidade viva e simulação autónoma.\nConceito e desenvolvimento: lufime")
        "Inventario":
            _v030_section_add_text(content_box, "[font_size=18][b]RECURSOS E INVENTÁRIO[/b][/font_size]\n\n%s" % _v030_dictionary_lines(v030_get_inventories()))
        "Telefone":
            var phone_text := "[font_size=18][b]CONTACTOS[/b][/font_size]\n\n"
            for npc in npcs:
                var n := str(npc.get("name", "Habitante")); var rel := int(npc.get("relationship", npc_relations.get(n, 0)))
                phone_text += "• %s — %s\n" % [n, _relation_label(rel)]
            _v030_section_add_text(content_box, phone_text + "\nTelefone e mensagens: comunicação contextual entre personagens.")
        "Missoes", "MissoesE":
            var missions := v030_get_missions(); var mission_text := "[font_size=18][b]MISSÕES[/b][/font_size]\n\n"
            if missions.is_empty(): mission_text += "Sem missões pendentes neste momento."
            else:
                for m in missions: mission_text += "• %s — %s\n" % [str(m.get("id", "MISSÃO")), str(m.get("status", "pendente"))]
            if section == "MissoesE": mission_text += "\nEntidade ativa: %s" % v030_selected_entity
            _v030_section_add_text(content_box, mission_text)
        "Noticias":
            var news := v030_get_news(); var news_text := "[font_size=18][b]NOTÍCIAS DE VALEPÓLIS[/b][/font_size]\n\n"
            if news.is_empty(): news_text += "Ainda não existem notícias."
            else:
                for item in news.slice(max(0, news.size() - 12), news.size()): news_text += "• %s\n" % str(item.get("text", item))
            _v030_section_add_text(content_box, news_text)
        "Financas", "FinancasE":
            if section == "FinancasE":
                _v030_section_add_text(content_box, "[font_size=18][b]FINANÇAS DA ENTIDADE[/b][/font_size]\n\nEconomia, orçamento e saldo desta entidade ficam por definir. Nenhum valor inicial foi atribuído.\n\nA economia geral da personagem/cidade não é apresentada como saldo da entidade.")
            else:
                _v030_section_add_text(content_box, _v030_finance_text())
        "Opcoes", "OpcoesE":
            _v030_section_add_text(content_box, "[font_size=18][b]OPÇÕES[/b][/font_size]\n\nVelocidade da simulação: %s\nModo atual: %s\nEntidade ativa: %s" % [_time_speed_text(), v030_control_mode, v030_selected_entity if v030_selected_entity != "" else "—"])
        "Base":
            var taxonomy_record: Dictionary = _v030_catalog_entity_record(v030_selected_entity)
            var runtime_id := _v030_runtime_entity_id(v030_selected_entity)
            var entity_profile_result: Dictionary = v030_runtime.get_entity_profile(runtime_id) if runtime_id != "" else {}
            var entity_profile: Dictionary = entity_profile_result.get("profile", {})
            var services_text := ""
            for service_id in entity_profile.get("services", []):
                services_text += "• %s\n" % str(service_id).replace("_", " ").capitalize()
            if services_text == "": services_text = "Funções operacionais específicas ainda por configurar.\n"
            var tnur_note := ""
            if runtime_id == "BRIGADA":
                tnur_note = "\n[b]TNUR[/b]\nTodos os centros TNUR funcionam dentro de bases BRIGADA. TNUR não tem bases independentes e não aumenta a contagem de bases.\n"
            _v030_section_add_text(content_box, "[font_size=18][b]ENTIDADE / BASE[/b][/font_size]\n\nEntidade: %s\nID de catálogo: %s\nRamo: %s\nTipo: %s\nFinalidade operacional: %s\nEstado de configuração: %s\n\n[b]Serviços e funções[/b]\n%s%s\nEfetivos, economia, quantidade de instalações, viaturas, inventário, orçamento e saldo: por definir em conjunto." % [v030_selected_entity, str(taxonomy_record.get("ID", "—")), str(taxonomy_record.get("Ramo", "—")), str(taxonomy_record.get("Tipo", "—")), str(entity_profile.get("purpose", "Descrição operacional específica por completar")), str(entity_profile.get("status", "catalogued_not_configured")), services_text, tnur_note])
        "Instalacoes":
            var summary: Dictionary = ValepolisInstallations.get_registry_summary()
            var validation: Dictionary = ValepolisInstallations.validate_registry()
            var entity_id := _v030_runtime_entity_id(v030_selected_entity)
            var rows: Array = ValepolisInstallations.get_installations_for_entity(entity_id) if entity_id != "" else ValepolisInstallations.get_all_installations()
            var intro := "[font_size=18][b]INSTALAÇÕES DE VALEPÓLIS[/b][/font_size]\n\nProposta não oficial. Os registos têm IDs e moradas provisórias; não criam edifícios no mapa.\n\nLocais físicos propostos: %s\nUnidades integradas sem local próprio: %s\nEstado da validação: %s\n" % [str(summary.get("physical_installations", "—")), str(summary.get("embedded_units", "—")), "Sem erros estruturais" if validation.get("ok", false) else "Existem erros a rever"]
            intro += "\nEfetivos, viaturas, inventário, economia, orçamento, saldo, capacidade e horários continuam por definir.\nTNUR está sempre integrado nas bases BRIGADA."
            _v030_section_add_text(content_box, intro)
            if rows.is_empty():
                _v030_section_add_text(content_box, "Não há instalações físicas propostas para esta entidade. O catálogo geral mantém-se disponível.")
            else:
                for row in rows:
                    _v030_section_add_text(content_box, "[b]%s — %s[/b]\nID: %s\nBairro: %s\nMorada provisória: %s\nObjeto 3D previsto: %s (%s)\nEstado: não criado no mapa" % [str(row.get("display_name", "Instalação")), str(row.get("entity_id", "")), str(row.get("installation_id", "")), str(row.get("neighborhood_name", "")), str(row.get("full_address", "por atribuir")), str(row.get("planned_map_object_id", "—")), str(row.get("planned_map_object_class", "por definir"))], 12)
            var distribution := ValepolisInstallations.get_neighborhood_distribution()
            var distribution_text := "[font_size=16][b]DISTRIBUIÇÃO PROVISÓRIA POR BAIRRO[/b][/font_size]\n"
            for item in distribution:
                distribution_text += "• %s — %s registos\n" % [str(item.get("neighborhood_name", "")), str(item.get("physical_installation_records", 0))]
            _v030_section_add_text(content_box, distribution_text, 12)
        "Veiculos":
            _v030_section_add_text(content_box, "[font_size=18][b]VEÍCULOS[/b][/font_size]\n\nEntidade: %s\n\nA quantidade, os modelos, os códigos e o estado da frota serão definidos numa fase posterior. Não existem viaturas de demonstração contabilizadas como reais." % v030_selected_entity)
        "Equipas":
            _v030_section_add_text(content_box, "[font_size=18][b]EQUIPAS E EFETIVOS[/b][/font_size]\n\nEntidade: %s\n\nComposição, efetivos, funções, turnos e disponibilidade ficam por definir.\n\nTNUR mantém equipas próprias do ponto de vista operacional, integradas na BRIGADA." % v030_selected_entity)
        "Manutencao":
            _v030_section_add_text(content_box, "[font_size=18][b]MANUTENÇÃO[/b][/font_size]\n\nFrota e instalações da entidade selecionada.\nVeículos indisponíveis por manutenção não podem ser despachados.")
        "Formacao":
            _v030_section_add_text(content_box, "[font_size=18][b]FORMAÇÃO[/b][/font_size]\n\nCompetências, disponibilidade e progressão dos operacionais.")
        "Relatorios":
            var directory_check: Dictionary = v030_runtime.validate_entity_master_catalog()
            _v030_section_add_text(content_box, "[font_size=18][b]RELATÓRIO DA ENTIDADE[/b][/font_size]\n\nCatálogo funcional: %s\nRegistos no catálogo: %d\nCampos de dimensionamento pendentes: efetivos, economia, instalações, viaturas, inventário, orçamento e saldo.\n\nValidação estrutural: %s" % ["Disponível" if directory_check.get("ok", false) else "Com erros", int(directory_check.get("entity_rows", 0)), "Aprovada" if directory_check.get("ok", false) else str(directory_check.get("errors", []))])
        "Cidade":
            _v030_section_add_text(content_box, "[font_size=18][b]CIDADE[/b][/font_size]\n\nBairro atual: %s\nTrânsito: %.0f%%\nClima: %s\n\nA cidade continua a ser simulada pela IA." % [v030_current_neighborhood, float(v030_city_state.get("traffic", 0.0)), v030_weather])
        _:
            _v030_section_add_text(content_box, "[font_size=18][b]%s[/b][/font_size]\n\nSecção disponível na interface V0.3.0." % section.to_upper())

    # Navegação por ecrãs persistentes: a página substitui o mapa na área central;
    # não é uma janela modal nem exige botão de fechar.
    panel.visible = true
    if has_node("UI/Map"):
        $UI/Map.visible = false
    panel.move_to_front()
    _v030_layout_professional_ui($UI.size, 12.0, 0.0, 0.0, 0.0, 0.0)

func _v030_dictionary_lines(value: Variant) -> String:
    if value is Dictionary:
        var out := ""
        for k in value.keys():
            out += "• %s: %s\n" % [str(k), str(value[k])]
        return out if out != "" else "Sem recursos registados."
    return str(value)

func _v030_finance_text() -> String:
    var f := v030_get_finance()
    if not bool(f.get("configured", false)) or f.get("balance", null) == null:
        return "[font_size=15]FINANÇAS[/font_size]\n\nEconomia, saldo, receitas e despesas: por definir.\nNenhum valor financeiro inicial foi atribuído."
    var income_value: Variant = f.get("income", null)
    var expenses_value: Variant = f.get("expenses", null)
    var income_text := "por definir" if income_value == null else "€%.2f" % float(income_value)
    var expenses_text := "por definir" if expenses_value == null else "€%.2f" % float(expenses_value)
    return "[font_size=15]FINANÇAS[/font_size]\n\nSaldo: €%.2f\nReceitas: %s\nDespesas: %s" % [float(f.get("balance", 0.0)), income_text, expenses_text]

func _v030_set_mode(mode: String) -> void:
    _v030_close_section()
    if mode == "entidade":
        if v030_selected_entity == "":
            if not v030_entities.is_empty():
                v030_selected_entity = str(v030_entities.keys()[0])
            elif not ENTITIES.is_empty():
                v030_selected_entity = str(ENTITIES.keys()[0])
    v030_control_mode = mode
    # Não criar uma seleção fictícia ao abrir o separador.
    # A personagem só fica selecionada depois da confirmação explícita no fluxo de criação.
    if mode == "personagem" and v030_selected_character == "" and v030_player_custom_name != "":
        v030_selected_character = v030_player_custom_name
    _refresh()
    _layout()

func _v030_update_professional_ui() -> void:
    if not v030_ui_ready or not has_node("UI/ReferenceUI"):
        return
    var root: Control = $UI/ReferenceUI
    var is_entity := v030_control_mode == "entidade"
    root.get_node("CharacterNavigation").visible = not is_entity
    root.get_node("EntityNavigation").visible = is_entity
    # Os cartões de estado substituem os antigos blocos de contexto duplicados.
    root.get_node("ReferenceContext").visible = false
    root.get_node("EntityContext").visible = false
    root.get_node("EntityFilters").visible = false
    root.get_node("EntityTabs").visible = false
    root.get_node("EntityVehicles").visible = false
    root.get_node("ReferenceEntityActions").visible = is_entity
    root.get_node("StateDashboard").visible = true
    $UI/Actions.visible = not is_entity
    $UI/Bottom.visible = false

    if not is_entity:
        var profile_name := v030_player_custom_name if v030_player_custom_name != "" else v030_selected_character
        var info: Label = root.get_node("ReferenceContext/ContextInfo")
        var title: Label = root.get_node("ReferenceContext/ContextTitle")
        if v030_control_mode == "mapa":
            title.text = "MUNDO EM TEMPO REAL"
            info.text = "%s • %s • %s\nBairro: %s • Trânsito: %.0f%% • Simulação: %s" % [_date_text(), "%02d:00" % hour, _weekday_name(), v030_current_neighborhood, float(v030_city_state.get("traffic", 25.0)), _time_speed_text()]
        else:
            title.text = "ESTADO DA PERSONAGEM • %s" % current_place.to_upper()
            var ai_action: String = str(v030_personal_ai.get("last_action", "rotina autónoma"))
            info.text = "%s • %s\n%s • %s\nEnergia %d • Fome %d/100 • Saúde %d\nIA: %s" % [current_place, v030_current_neighborhood, profile_name if profile_name != "" else "Personagem por escolher", v030_selected_profession if v030_selected_profession != "" else "Profissão por definir", energy, hunger, health, ai_action]
    else:
        var entity_title: Label = root.get_node("EntityContext/EntityTitle")
        var entity_info: Label = root.get_node("EntityContext/EntityInfo")
        entity_title.text = str(v030_selected_entity).to_upper() if v030_selected_entity != "" else "ENTIDADE POR ESCOLHER"
        var taxonomy_record: Dictionary = _v030_catalog_entity_record(v030_selected_entity)
        var runtime_id := _v030_runtime_entity_id(v030_selected_entity)
        var profile_result: Dictionary = v030_runtime.get_entity_profile(runtime_id) if runtime_id != "" else {}
        var profile: Dictionary = profile_result.get("profile", {})
        entity_info.text = "%s\nRamo: %s • Estado do catálogo: %s\nEfetivos, instalações, viaturas, inventário e saldo: por definir" % [str(profile.get("purpose", "Entidade catalogada; operação específica por configurar")), str(taxonomy_record.get("Ramo", "—")), str(profile.get("status", "catalogued_not_configured"))]
    _v030_update_state_dashboard()

func _v030_update_state_dashboard() -> void:
    if not has_node("UI/ReferenceUI/StateDashboard/StateGrid"):
        return
    var grid: GridContainer = $UI/ReferenceUI/StateDashboard/StateGrid
    var date_value := "%s • DIA %d • %02d:00" % [_date_text(), day, hour]
    _v030_set_state_card(grid, "StateWorld", date_value, "%s • %s • %s" % [_weekday_name(), v030_season.capitalize(), v030_weather.capitalize()])

    var traffic := float(v030_city_state.get("traffic", 25.0))
    var traffic_text := "Fluido" if traffic < 35.0 else ("Condicionado" if traffic < 70.0 else "Intenso")
    _v030_set_state_card(grid, "StateCity", "1.000.000 habitantes", "25 bairros • Trânsito %.0f%% (%s)" % [traffic, traffic_text])

    var missions: Array = v030_get_missions()
    var event_count := v030_city_events.size() + v030_incidents.size()
    _v030_set_state_card(grid, "StateActivity", "%d missões" % missions.size(), "%d eventos/ocorrências registados • Tick %d" % [event_count, v030_simulation_ticks])

    if v030_control_mode == "entidade":
        var entity_name := v030_selected_entity if v030_selected_entity != "" else "Entidade por escolher"
        _v030_set_state_card(grid, "StatePlayer", entity_name, "Efetivos, frota e saldo: por definir")
    else:
        var character_name := v030_player_custom_name if v030_player_custom_name != "" else v030_selected_character
        if character_name == "": character_name = "Personagem por escolher"
        _v030_set_state_card(grid, "StatePlayer", "Saúde %d%% • Energia %d%%" % [health, energy], "%s • Fome %d/100 • Economia por definir" % [character_name, hunger])

func _v030_set_state_card(grid: GridContainer, card_name: String, value_text: String, detail_text: String) -> void:
    var card := grid.get_node_or_null(card_name)
    if card == null:
        return
    var value := card.get_node_or_null("VBoxContainer/Value") as Label
    var detail := card.get_node_or_null("VBoxContainer/Detail") as Label
    if value != null: value.text = value_text
    if detail != null: detail.text = detail_text

func _v030_layout_professional_ui(s: Vector2, margin: float, nav_top: float, nav_h: float, context_top: float, context_h: float) -> void:
    if not v030_ui_ready or not has_node("UI/ReferenceUI"):
        return
    var root: Control = $UI/ReferenceUI
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var is_entity := v030_control_mode == "entidade"
    var gap: float = clampf(s.y * 0.008, 5.0, 9.0)
    var header_h: float = clampf(s.y * 0.075, 68.0, 86.0)
    var nav_h2: float = clampf(s.y * 0.065, 56.0, 68.0)
    var actions_h: float = clampf(s.y * 0.088, 78.0, 88.0)
    var dashboard_h: float = 132.0 if s.x < 620.0 else 88.0
    var nav_y: float = s.y - margin - nav_h2
    var actions_y: float = nav_y - gap - actions_h
    var dashboard_y: float = actions_y - gap - dashboard_h
    var map_y: float = margin + header_h + gap
    var map_h: float = maxf(210.0, dashboard_y - gap - map_y)

    $UI/Header.position = Vector2(margin, margin)
    $UI/Header.size = Vector2(maxf(0.0, s.x - margin * 2.0), header_h)
    var compact_header := s.x < 620.0
    var stats_left := maxf(margin + (190.0 if compact_header else 250.0), s.x * (0.54 if compact_header else 0.57))
    var stats_width := maxf(120.0, s.x - stats_left - margin - 4.0)
    var left_width := maxf(120.0, stats_left - margin - 18.0)
    $UI/Stats.position = Vector2(stats_left, margin + 5.0)
    $UI/Stats.size = Vector2(stats_width, header_h - 10.0)
    $UI/Header/Title.position = Vector2(14.0, 6.0)
    $UI/Header/Sub.position = Vector2(14.0, 39.0)
    $UI/Header/Title.size = Vector2(left_width, 29.0)
    $UI/Header/Sub.size = Vector2(left_width, header_h - 43.0)
    $UI/Header/Title.clip_text = true
    $UI/Header/Sub.clip_text = true
    $UI/Stats.clip_text = true
    $UI/Header/Title.add_theme_font_size_override("font_size", int(clamp(s.x * 0.032, 15.0, 23.0)))
    $UI/Header/Sub.add_theme_font_size_override("font_size", int(clamp(s.x * 0.021, 11.0, 15.0)))
    $UI/Stats.add_theme_font_size_override("font_size", int(clamp(s.x * 0.020, 11.0, 15.0)))

    var char_nav: Control = root.get_node("CharacterNavigation")
    var entity_nav: Control = root.get_node("EntityNavigation")
    var nav: Control = entity_nav if is_entity else char_nav
    nav.position = Vector2(margin, nav_y)
    nav.size = Vector2(maxf(0.0, s.x - margin * 2.0), nav_h2)
    for c in nav.get_children():
        if c is Control:
            c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            c.custom_minimum_size.y = nav_h2

    $UI/Map.position = Vector2(margin, map_y)
    $UI/Map.size = Vector2(maxf(0.0, s.x - margin * 2.0), map_h)
    $UI/Map.clip_contents = true
    map_body.clip_contents = true
    $UI/Map/MapTitle.position = Vector2(12.0, 6.0)
    $UI/Map/MapTitle.size = Vector2(maxf(0.0, $UI/Map.size.x - 110.0), 25.0)
    _v030_apply_map_transform()
    if v030_zoom_in_button != null:
        v030_zoom_in_button.position = Vector2(maxf(8.0, $UI/Map.size.x - 52.0), 8.0)
        v030_zoom_in_button.size = Vector2(40.0, 40.0)
    if v030_zoom_out_button != null:
        v030_zoom_out_button.position = Vector2(maxf(8.0, $UI/Map.size.x - 52.0), 54.0)
        v030_zoom_out_button.size = Vector2(40.0, 40.0)

    var dashboard: Control = root.get_node("StateDashboard")
    dashboard.position = Vector2(margin, dashboard_y)
    dashboard.size = Vector2(maxf(0.0, s.x - margin * 2.0), dashboard_h)
    var state_grid: GridContainer = dashboard.get_node("StateGrid")
    state_grid.position = Vector2(7.0, 7.0)
    state_grid.size = Vector2(maxf(0.0, dashboard.size.x - 14.0), maxf(0.0, dashboard.size.y - 14.0))
    state_grid.columns = 2 if s.x < 620.0 else 4
    for card in state_grid.get_children():
        if card is Control:
            card.custom_minimum_size = Vector2(0.0, 54.0 if s.x < 620.0 else 62.0)

    var context: Control = root.get_node("ReferenceContext")
    context.position = Vector2(margin, dashboard_y)
    context.size = Vector2(maxf(0.0, s.x - margin * 2.0), dashboard_h)
    var entity_context: Control = root.get_node("EntityContext")
    entity_context.position = context.position
    entity_context.size = context.size
    var entity_actions: Control = root.get_node("ReferenceEntityActions")
    entity_actions.position = Vector2(margin, actions_y)
    entity_actions.size = Vector2(maxf(0.0, s.x - margin * 2.0), actions_h)
    for c in entity_actions.get_children():
        if c is Control:
            c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            c.custom_minimum_size.y = actions_h

    $UI/Actions.position = Vector2(margin, actions_y)
    $UI/Actions.size = Vector2(maxf(0.0, s.x - margin * 2.0), actions_h)
    _layout_action_buttons()
    $UI/Bottom.visible = false

    var section_overlay := root.get_node_or_null("SectionPanel") as Control
    if section_overlay != null:
        section_overlay.position = Vector2(margin + 4.0, map_y + 4.0)
        section_overlay.size = Vector2(maxf(260.0, s.x - margin * 2.0 - 8.0), maxf(180.0, map_h - 8.0))
        section_overlay.z_index = 100
        section_overlay.clip_contents = true
    _v030_sync_map_viewport_size()

func _v030_setup_ui_city_background() -> void:
    # Fundo estático da cidade para os ecrãs da interface.
    # O City3D.tscn continua reservado ao mapa livre; não é renderizado atrás dos menus.
    var existing := get_node_or_null("ValepolisStaticUIBackground") as TextureRect
    if existing != null:
        existing.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
        return
    var image_path := "res://images/intro_valepolis.png"
    if not ResourceLoader.exists(image_path):
        push_warning("Imagem de fundo da cidade não encontrada: " + image_path)
        return
    var background := TextureRect.new()
    background.name = "ValepolisStaticUIBackground"
    background.texture = load(image_path) as Texture2D
    background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    background.mouse_filter = Control.MOUSE_FILTER_IGNORE
    background.focus_mode = Control.FOCUS_NONE
    background.z_index = -100
    add_child(background)
    move_child(background, 0)

func _v030_sync_map_viewport_size() -> void:
    # Ajusta a resolução à dimensão real do mapa em cada dispositivo/orientação.
    var container := get_node_or_null("UI/Map/MapBody/Map3D") as SubViewportContainer
    var viewport := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport") as SubViewport
    if container == null or viewport == null:
        return
    # Regra de robustez: a rotina de sincronização também reassegura a atualização
    # contínua, evitando depender apenas da configuração inicial da cena.
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    # Corrige o problema observado em telemóveis: o SubViewportContainer
    # ficava preso a 660x668 no canto superior esquerdo, deixando o resto
    # do MapBody vazio. A vista 3D passa a ocupar toda a área útil do painel.
    container.set_anchors_preset(Control.PRESET_FULL_RECT)
    container.offset_left = 0.0
    container.offset_top = 0.0
    container.offset_right = 0.0
    container.offset_bottom = 0.0
    container.position = Vector2.ZERO
    container.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    container.size_flags_vertical = Control.SIZE_EXPAND_FILL
    container.stretch = true
    container.mouse_filter = Control.MOUSE_FILTER_STOP
    # Corrige o painel antigo de dimensões fixas (660x668): em telemóveis
    # verticais deixava o mapa pequeno no topo e uma grande área vazia abaixo.
    var map_panel := get_node_or_null("UI/Map") as Control
    var map_body := get_node_or_null("UI/Map/MapBody") as Control
    if map_panel != null and map_body != null:
        map_body.set_anchors_preset(Control.PRESET_FULL_RECT)
        map_body.offset_left = 14.0
        map_body.offset_top = 48.0
        map_body.offset_right = -14.0
        map_body.offset_bottom = -14.0
        map_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        map_body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    var display_size := container.size
    if display_size.x < 2.0 or display_size.y < 2.0:
        return
    # Renderiza a 1,5x do tamanho apresentado, com limite para proteger a memória
    # dos telemóveis de alta resolução.
    var render_size := Vector2i(
        clampi(int(round(display_size.x * 1.35)), 360, 1440),
        clampi(int(round(display_size.y * 1.35)), 360, 1440)
    )
    if viewport.size != render_size:
        viewport.size = render_size

func _v030_setup_3d_map() -> void:
    # V0.3.0 — mapa 3D navegável de Valepólis. A simulação existente continua a fornecer os dados.
    var container := get_node_or_null("UI/Map/MapBody/Map3D") as SubViewportContainer
    var viewport := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport") as SubViewport
    if container == null or viewport == null:
        push_warning("MAP_RENDER_FAIL: container ou SubViewport em falta")
        return

    # Configurar o viewport ANTES de verificar se a cidade já existe. A cena pode
    # vir pré-preenchida por Main.tscn; sair cedo antes desta configuração deixa
    # o SubViewport no modo herdado/desativado e produz um painel preto.
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    viewport.transparent_bg = false
    container.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    container.stretch = true
    container.mouse_filter = Control.MOUSE_FILTER_STOP
    container.visible = true

    var existing_city := viewport.get_node_or_null("ValepolisCity3D")
    if existing_city != null:
        _v030_prepare_city_camera(existing_city)
        if is_instance_valid(v030_runtime):
            v030_runtime.register_city(existing_city)
        return

    var scene := load("res://City3D.tscn")
    if scene == null:
        push_warning("MAP_RENDER_FAIL: City3D.tscn não foi carregada")
        return
    # O mapa 3D passa a ser a camada visual principal; os elementos 2D antigos
    # permanecem no projeto para compatibilidade com os sistemas de navegação.
    # A camada 2D antiga era criada por cima do viewport e ocultava o relevo.
    # Esconde todos os filhos CanvasItem legados, preservando Map3D como superfície.
    var map_body := get_node_or_null("UI/Map/MapBody")
    if map_body is Node:
        for child in map_body.get_children():
            if child != container and child is CanvasItem:
                child.visible = false
    container.visible = true
    container.z_index = 20
    container.move_to_front()
    var city = scene.instantiate()
    city.name = "ValepolisCity3D"
    viewport.add_child(city)
    _v030_prepare_city_camera(city)
    if city.has_method("set_traffic_hour"):
        city.call("set_traffic_hour", hour, _is_weekend())
    if city.has_method("sync_population_agents") and not v030_population_agents.is_empty():
        var sync_result: Variant = city.call("sync_population_agents", v030_population_agents)
        if sync_result is Dictionary:
            v030_world_metrics["population_visual_sync"] = sync_result
    if is_instance_valid(v030_runtime):
        v030_runtime.register_city(city)


func _v030_prepare_city_camera(city: Node) -> void:
    # A câmara deve pertencer ao viewport ativo e ser explicitamente current.
    if city == null or not is_instance_valid(city):
        return
    var cameras: Array[Node] = city.find_children("*", "Camera3D", true, false)
    for camera_node in cameras:
        var camera := camera_node as Camera3D
        if camera == null:
            continue
        camera.current = true
        camera.make_current()
        break


func _v030_sync_canonical_runtime() -> void:
    if not is_instance_valid(v030_runtime):
        return
    var world := {
        "day": day,
        "hour": hour,
        "weekday": weekday,
        "year": year,
        "month": month,
        "month_day": month_day,
        "weather": v030_weather,
        "traffic": str(v030_city_state.get("traffic", "normal")),
        "families": v030_families,
        "population": npcs,
        "incidents": v030_incidents,
        "economy": v030_economy,
        "neighborhood": v030_current_neighborhood
    }
    v030_runtime.sync_world(world)
    v030_runtime.register_ui({"control_mode": v030_control_mode, "selected_entity": v030_selected_entity})
    v030_runtime.sync_progression(int(v030_runtime.progression.get("season", 1)), int(v030_runtime.progression.get("episode", 1)))

func _v030_integration_status() -> Dictionary:
    if not is_instance_valid(v030_runtime):
        return {"runtime": false}
    return v030_runtime.get_integration_status()

func _v030_rename_nested_names(value: Variant, mapping: Dictionary) -> Variant:
    if value is Dictionary:
        var result: Dictionary = {}
        for key in value.keys():
            var renamed_key: Variant = _v030_rename_nested_names(str(key), mapping)
            result[renamed_key] = _v030_rename_nested_names(value[key], mapping)
        return result
    if value is Array:
        var result_array: Array = []
        for item in value:
            result_array.append(_v030_rename_nested_names(item, mapping))
        return result_array
    if value is String:
        var renamed: String = str(value)
        for old_name in mapping.keys():
            renamed = renamed.replace(str(old_name), str(mapping[old_name]))
        return renamed
    return value

func _v030_migrate_legacy_npc_names() -> void:
    var mapping := {"Marta": "Arel Valara", "Rui": "Néria Nerova", "Inês": "Varel Loreno"}
    npcs = _v030_rename_nested_names(npcs, mapping)
    v030_families = _v030_rename_nested_names(v030_families, mapping)
    v030_npc_profiles = _v030_rename_nested_names(v030_npc_profiles, mapping)
    v030_npc_relationships = _v030_rename_nested_names(v030_npc_relationships, mapping)
    v030_social_relations = _v030_rename_nested_names(v030_social_relations, mapping)
    npc_relations = _v030_rename_nested_names(npc_relations, mapping)
    v030_character_ai = _v030_rename_nested_names(v030_character_ai, mapping)
    v030_npc_life = _v030_rename_nested_names(v030_npc_life, mapping)
    v030_job_progression = _v030_rename_nested_names(v030_job_progression, mapping)
    v030_population_agents = _v030_rename_nested_names(v030_population_agents, mapping)
    v030_population_materialized = _v030_rename_nested_names(v030_population_materialized, mapping)
    v030_npc_daily_needs = _v030_rename_nested_names(v030_npc_daily_needs, mapping)
    v030_npc_activity_log = _v030_rename_nested_names(v030_npc_activity_log, mapping)
    v030_daily_activity = _v030_rename_nested_names(v030_daily_activity, mapping)
    v030_social_events = _v030_rename_nested_names(v030_social_events, mapping)
    v030_relationships = _v030_rename_nested_names(v030_relationships, mapping)
    v030_jobs = _v030_rename_nested_names(v030_jobs, mapping)
    v030_unemployment = _v030_rename_nested_names(v030_unemployment, mapping)

func _v030_reset_unapproved_economy() -> void:
    # Único ponto de sanitização: nenhum saldo, salário, preço ou despesa de
    # demonstração sobrevive à inicialização ou ao carregamento de uma gravação.
    v030_personal_economy_configured = false
    v030_economy = {"configured": false, "status": "por_definir", "history": []}
    v030_finance = {"configured": false, "balance": null, "income": null, "expenses": null, "contracts": [], "loans": [], "history": []}
    v030_family_economy.clear()
    v030_household_expenses.clear()
    v030_economic_history.clear()
    # Limpar recursos de demonstração guardados por versões anteriores.
    # Nenhuma equipa, viatura, instalação física, capacidade ou stock foi
    # aprovada para V0.3.0; as definições futuras virão dos catálogos oficiais.
    v030_teams.clear()
    v030_vehicles.clear()
    v030_vehicle_state.clear()
    v030_entity_staff.clear()
    v030_entity_schedules.clear()
    v030_inventories.clear()
    v030_properties.clear()
    v030_buildings.clear()
    v030_entity_metrics.clear()
    v030_service_state.clear()
    v030_establishments.clear()
    v030_entities_catalog.clear()
    for mission_index in range(v030_missions.size()):
        var mission: Dictionary = v030_missions[mission_index]
        var assigned_team := str(mission.get("assigned_team", ""))
        var assigned_vehicle := str(mission.get("assigned_vehicle", ""))
        if str(mission.get("status", "")) in ["em resposta", "em curso", "no local", "estabilizada"] and (assigned_team.is_empty() or assigned_vehicle.is_empty()):
            mission["status"] = "aberta"
            mission["assigned_team"] = ""
            mission["assigned_vehicle"] = ""
            mission["outcome"] = "aguarda recursos oficialmente configurados"
            v030_missions[mission_index] = mission
    if v030_world_metrics is Dictionary:
        v030_world_metrics["empregados"] = null
        v030_world_metrics["desempregados"] = null
        v030_world_metrics["receita_cidade"] = null
    for profile_name in v030_npc_profiles.keys():
        var profile: Dictionary = v030_npc_profiles[profile_name]
        profile["salario"] = null
        profile["emprego"] = null
        v030_npc_profiles[profile_name] = profile
    for unemployment_name in v030_unemployment.keys():
        v030_unemployment[unemployment_name] = null
    for npc in npcs:
        npc.erase("money")
        npc.erase("daily_income")
        npc.erase("daily_expenses")
        npc.erase("economy_day")

func _ready() -> void:
    # Ordem canónica V0.3.0: calendário -> mundo -> runtime -> sincronização -> UI.
    # O relógio deve existir antes de o runtime receber o primeiro estado.
    _init_real_world_clock()
    v030_load_master_catalog()
    v030_systems_initialize()
    v030_systems_update()
    v030_complete_initialize()
    v030_complete_update()
    v030_update_social_life()
    v030_update_service_life()
    v030_update_npc_daily_life()
    v030_update_npc_travel()
    v030_update_npc_routine_positions()
    v030_initialize_neighborhood_profiles()
    v030_complete_tick()
    v030_seed_initial_families()
    v030_initialize()
    v030_update_world()
    v030_initialize_advanced_world()
    v030_update_advanced_world()
    _v030_migrate_legacy_npc_names()
    _v030_reset_unapproved_economy()
    # Runtime canónico recebe apenas o estado inicial já completo.
    if is_instance_valid(v030_runtime):
        if not v030_runtime.initialized:
            v030_runtime.initialize()
        _v030_sync_canonical_runtime()
    _v030_build_professional_ui()
    status.text = "V0.3.0 — nova interface de Valepólis."
    # A imagem estática da cidade fica atrás dos ecrãs da UI.
    # A cena 3D é usada apenas no mapa livre.
    call_deferred("_v030_setup_ui_city_background")
    var ui_background := get_node_or_null("UI/Background") as ColorRect
    if ui_background != null:
        ui_background.color = Color(0.008, 0.022, 0.04, 0.18)
    # Cabeçalho premium: identidade à esquerda e estado vivo à direita.
    $UI/Header/Title.text = "VALEPÓLIS — CIDADE VIVA"
    $UI/Header/Sub.text = "V0.3.0  •  CIDADE VIVA  •  SIMULAÇÃO AUTÓNOMA"
    if has_node("UI/Map/MapTitle"):
        $UI/Map/MapTitle.text = "MAPA URBANO • VALEPÓLIS"
    get_viewport().size_changed.connect(_layout)
    if has_node("UI/Actions/Work"):
        $UI/Actions/Work.pressed.connect(_work)
    if has_node("UI/Actions/Shop"):
        $UI/Actions/Shop.pressed.connect(_shop)
    # Ações principais: manter sempre quatro posições estáveis.
    # O hospital ocupa a quarta posição, sem deslocar o estado de saúde.
    if has_node("UI/Actions/Hospital"):
        $UI/Actions/Hospital.queue_free()
    var hospital_button := Button.new()
    hospital_button.name = "Hospital"
    hospital_button.text = "HOSPITAL"
    hospital_button.custom_minimum_size = Vector2(120, 52)
    hospital_button.pressed.connect(_hospital)
    $UI/Actions.add_child(hospital_button)
    _layout_action_buttons()
    if has_node("UI/Actions/Move"):
        $UI/Actions/Move.pressed.connect(_move)
    if has_node("UI/Bottom/Character"):
        $UI/Bottom/Character.pressed.connect(_character)
    if has_node("UI/Bottom/Save"):
        $UI/Bottom/Save.pressed.connect(_save_game)
    if has_node("UI/Bottom/Load"):
        $UI/Bottom/Load.pressed.connect(_load_game)
    if has_node("UI/Bottom/Credits"):
        $UI/Bottom/Credits.pressed.connect(_credits)
    _create_map_location_buttons()
    _v030_create_neighborhood_overlay()
    _v030_build_geography()
    _create_npc_markers()
    _v030_create_map_zoom_controls()
    _create_npc_dialog()
    # Primeiro calcular o layout móvel; depois montar o SubViewport 3D.
    # Evita criar o mapa com dimensões iniciais nulas/antigas.
    _layout()
    call_deferred("_v030_setup_3d_map")
    call_deferred("_v030_sync_map_viewport_size")
    _refresh()
    _check_social_encounters()

    # A entrada da V0.3.0 começa sempre pelo menu.
    # Uma partida existente é recuperada apenas quando o jogador escolhe CONTINUAR.
    _show_start_menu()

func _update_action_buttons() -> void:
    if has_node("UI/Bottom/Character"):
        $UI/Bottom/Character.text = "PAINEL ENTIDADE" if v030_control_mode == "entidade" else "PERFIL"
    if v030_control_mode == "entidade":
        if has_node("UI/Actions/Move"):
            $UI/Actions/Move.text = "GESTÃO"
            $UI/Actions/Move.disabled = false
        if has_node("UI/Actions/Work"):
            $UI/Actions/Work.disabled = false
            $UI/Actions/Work.text = "PESSOAS"
        if has_node("UI/Actions/Shop"):
            $UI/Actions/Shop.disabled = false
            $UI/Actions/Shop.text = "RECURSOS"
        if has_node("UI/Actions/Hospital"):
            $UI/Actions/Hospital.disabled = false
            $UI/Actions/Hospital.text = "OPERAÇÕES"
        return
    var hospital := get_node_or_null("UI/Actions/Hospital")
    if hospital == null:
        return
    var work := get_node_or_null("UI/Actions/Work")
    var shop := get_node_or_null("UI/Actions/Shop")
    if work:
        work.text = "TRABALHAR" if current_place == "Trabalho" else ("FECHADO" if hour < 8 or hour >= 18 else "TRABALHAR")
        work.disabled = hour < 8 or hour >= 18
    if shop:
        shop.text = "COMPRAR" if current_place == "Comércio" else ("FECHADO" if hour < 8 or hour >= 20 else "COMPRAR")
        shop.disabled = hour < 8 or hour >= 20
    hospital.text = "HOSPITAL"
    hospital.disabled = false

func _v030_build_geography() -> void:
    # V0.3.0 — mapa urbano alinhado com a realidade oficial de Valepólis.
    if has_node("UI/Map/MapBody/Road1"):
        $UI/Map/MapBody/Road1.visible = false
    if has_node("UI/Map/MapBody/Road2"):
        $UI/Map/MapBody/Road2.visible = false
    # Norte = mar/praias; oeste = rio/estuário; este = montanhas; sul = cidades vizinhas.
    # A cidade é orgânica: a rede viária não é uma cruz nem uma grelha rígida.
    for node_name in ["Road1", "Road2", "Water"]:
        var legacy := map_body.get_node_or_null(node_name)
        if legacy != null:
            legacy.visible = false
    for child in map_body.get_children():
        if child.name.begins_with("Geo_"):
            child.queue_free()

    var land := ColorRect.new()
    land.name = "Geo_Land"
    land.position = Vector2.ZERO
    land.size = Vector2(660, 668)
    land.color = Color("#315c43")
    land.mouse_filter = Control.MOUSE_FILTER_IGNORE
    land.z_index = 0
    map_body.add_child(land)

    var sea := ColorRect.new()
    sea.name = "Geo_Sea"
    sea.position = Vector2(0, 0)
    sea.size = Vector2(660, 92)
    sea.color = Color("#12506d")
    sea.mouse_filter = Control.MOUSE_FILTER_IGNORE
    sea.z_index = 1
    map_body.add_child(sea)

    var beach := Polygon2D.new()
    beach.name = "Geo_Beach"
    beach.polygon = PackedVector2Array([
        Vector2(0, 92), Vector2(150, 88), Vector2(285, 96),
        Vector2(420, 87), Vector2(660, 94), Vector2(660, 116),
        Vector2(430, 111), Vector2(280, 119), Vector2(130, 110), Vector2(0, 114)
    ])
    beach.color = Color("#d6c27b")
    beach.z_index = 2
    map_body.add_child(beach)

    var river := Polygon2D.new()
    river.name = "Geo_River"
    river.polygon = PackedVector2Array([
        Vector2(0, 126), Vector2(62, 138), Vector2(105, 194),
        Vector2(118, 248), Vector2(92, 305), Vector2(112, 368),
        Vector2(95, 432), Vector2(122, 500), Vector2(86, 568),
        Vector2(0, 608), Vector2(0, 126)
    ])
    river.color = Color("#176080")
    river.z_index = 3
    map_body.add_child(river)

    var estuary := Polygon2D.new()
    estuary.name = "Geo_Estuary"
    estuary.polygon = PackedVector2Array([
        Vector2(0, 108), Vector2(84, 120), Vector2(132, 155),
        Vector2(116, 198), Vector2(65, 174), Vector2(0, 165)
    ])
    estuary.color = Color("#1b6d88")
    estuary.z_index = 4
    map_body.add_child(estuary)

    var lake := Polygon2D.new()
    lake.name = "Geo_Lake"
    lake.polygon = PackedVector2Array([
        Vector2(330, 505), Vector2(365, 486), Vector2(408, 493),
        Vector2(425, 520), Vector2(405, 548), Vector2(360, 554), Vector2(328, 535)
    ])
    lake.color = Color("#23728a")
    lake.z_index = 3
    map_body.add_child(lake)

    var mountain_base := Polygon2D.new()
    mountain_base.name = "Geo_MountainBase"
    mountain_base.polygon = PackedVector2Array([
        Vector2(505, 126), Vector2(542, 84), Vector2(570, 126),
        Vector2(603, 66), Vector2(637, 120), Vector2(660, 86),
        Vector2(660, 668), Vector2(545, 668), Vector2(558, 574),
        Vector2(536, 484), Vector2(558, 392), Vector2(532, 300), Vector2(548, 220)
    ])
    mountain_base.color = Color("#273b35")
    mountain_base.z_index = 4
    map_body.add_child(mountain_base)

    for spec in [
        ["Geo_Peak1", PackedVector2Array([Vector2(495, 160), Vector2(545, 86), Vector2(584, 160)]), Color("#344b42")],
        ["Geo_Peak2", PackedVector2Array([Vector2(558, 152), Vector2(608, 72), Vector2(653, 154)]), Color("#344b42")]
    ]:
        var peak := Polygon2D.new()
        peak.name = str(spec[0])
        peak.polygon = spec[1]
        peak.color = spec[2]
        peak.z_index = 5
        map_body.add_child(peak)

    # Rede viária orgânica principal da cidade.
    var roads := [
        PackedVector2Array([Vector2(118, 196), Vector2(190, 224), Vector2(285, 250), Vector2(395, 248), Vector2(505, 214)]),
        PackedVector2Array([Vector2(112, 374), Vector2(205, 350), Vector2(302, 330), Vector2(405, 344), Vector2(535, 315)]),
        PackedVector2Array([Vector2(135, 510), Vector2(235, 475), Vector2(335, 452), Vector2(440, 458), Vector2(540, 420)]),
        PackedVector2Array([Vector2(250, 118), Vector2(262, 205), Vector2(300, 300), Vector2(330, 402), Vector2(360, 510)]),
        PackedVector2Array([Vector2(440, 110), Vector2(425, 185), Vector2(430, 270), Vector2(455, 350), Vector2(470, 455)])
    ]
    for i in range(roads.size()):
        var road := Line2D.new()
        road.name = "Geo_Road_%02d" % i
        road.points = roads[i]
        road.width = 13.0
        road.default_color = Color("#3d4546")
        road.joint_mode = Line2D.LINE_JOINT_ROUND
        road.begin_cap_mode = Line2D.LINE_CAP_ROUND
        road.end_cap_mode = Line2D.LINE_CAP_ROUND
        road.z_index = 6
        map_body.add_child(road)

        var road_center := Line2D.new()
        road_center.name = "Geo_RoadCenter_%02d" % i
        road_center.points = roads[i]
        road_center.width = 2.0
        road_center.default_color = Color("#777b72")
        road_center.joint_mode = Line2D.LINE_JOINT_ROUND
        road_center.z_index = 7
        map_body.add_child(road_center)

    # Pontes reais sobre o rio, ligando a cidade às duas cidades da margem oposta.
    for spec in [
        ["Geo_Union", Vector2(46, 202), Vector2(170, 14), 4.0, "PONTE DA UNIÃO"],
        ["Geo_Horizon", Vector2(42, 447), Vector2(178, 14), -3.0, "PONTE DO HORIZONTE"]
    ]:
        var bridge := ColorRect.new()
        bridge.name = str(spec[0])
        bridge.position = spec[1]
        bridge.size = spec[2]
        bridge.rotation_degrees = float(spec[3])
        bridge.color = Color("#b69b62")
        bridge.mouse_filter = Control.MOUSE_FILTER_IGNORE
        bridge.z_index = 10
        map_body.add_child(bridge)

        var bridge_label := Label.new()
        bridge_label.name = str(spec[0]) + "_Label"
        bridge_label.text = str(spec[4])
        bridge_label.position = spec[1] + Vector2(28, -22)
        bridge_label.size = Vector2(130, 20)
        bridge_label.add_theme_font_size_override("font_size", 8)
        bridge_label.add_theme_color_override("font_color", Color("#f5e7b5"))
        bridge_label.mouse_filter = Control.MOUSE_FILTER_IGNORE
        bridge_label.z_index = 11
        map_body.add_child(bridge_label)

    _v030_add_map_label("Geo_SeaLabel", "MAR • COSTA DE VALEPÓLIS", Vector2(18, 18), 11, Color("#b9e5f2"), 12)
    _v030_add_map_label("Geo_BeachLabel", "PRAIAS", Vector2(535, 96), 9, Color("#fff0b0"), 12)
    _v030_add_map_label("Geo_NexoraLabel", "NEXORA • CENTRO", Vector2(278, 278), 11, Color("#ffe58a"), 12)
    _v030_add_map_label("Geo_LakeLabel", "LAGO URBANO", Vector2(342, 520), 8, Color("#b9e5f2"), 12)
    _v030_add_map_label("Geo_MountainLabel", "MONTANHAS", Vector2(535, 185), 9, Color("#d5dfd7"), 12)
    _v030_add_map_label("Geo_SantoAndre", "SANTO ANDRÉ DO VALE", Vector2(8, 600), 9, Color("#f2d98b"), 12)
    _v030_add_map_label("Geo_Portela", "PORTELA DO SUL", Vector2(185, 620), 9, Color("#f2d98b"), 12)

func _v030_add_map_label(node_name: String, text_value: String, pos: Vector2, font_size: int, color: Color, z: int) -> void:
    var label := Label.new()
    label.name = node_name
    label.text = text_value
    label.position = pos
    label.size = Vector2(180, 24)
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", color)
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    label.z_index = z
    map_body.add_child(label)

func _create_map_location_buttons() -> void:
    for child_node: Node in map_body.get_children():
        if child_node is Button and child_node.name.begins_with("Location_"):
            child_node.queue_free()

    for place in LOCATIONS.keys():
        var button := Button.new()
        button.name = "Location_" + place.replace("é", "e").replace("ó", "o")
        # O botão é apenas uma zona de toque invisível. O nome do local é desenhado
        # pelo Label fixo do mapa para evitar duplicação/caixas sobre os nomes.
        button.text = ""
        button.position = LOCATIONS[place] - Vector2(82, 45)
        button.size = Vector2(164, 90)
        button.flat = true
        button.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
        button.focus_mode = Control.FOCUS_NONE
        var empty := StyleBoxEmpty.new()
        button.add_theme_stylebox_override("normal", empty)
        button.add_theme_stylebox_override("hover", empty)
        button.add_theme_stylebox_override("pressed", empty)
        button.add_theme_stylebox_override("focus", empty)
        button.pressed.connect(_select_location.bind(place))
        map_body.add_child(button)


func _create_npc_markers() -> void:
    for child in map_body.get_children():
        if child.name.begins_with("NPC_"):
            child.queue_free()
    npc_markers.clear()
    for npc in npcs:
        var key := str(npc["name"])
        var marker := Button.new()
        marker.name = "NPC_" + key
        marker.text = "● " + key
        marker.flat = true
        marker.focus_mode = Control.FOCUS_NONE
        marker.custom_minimum_size = Vector2(90, 38)
        marker.add_theme_font_size_override("font_size", 14)
        marker.add_theme_color_override("font_color", Color("#9ee7ff"))
        marker.pressed.connect(_interact_npc.bind(key))
        map_body.add_child(marker)
        npc_markers[key] = marker
    _update_npc_markers()

func _npc_target_place(npc_name: String) -> String:
    # A rotina é determinada pela profissão/entidade, não por um destino
    # arbitrário. Fins de semana privilegiam vida pessoal e lazer.
    for npc in npcs:
        if str(npc.get("name", "")) != npc_name:
            continue
        var profession := str(npc.get("profession", ""))
        var schedule: Dictionary = PROFESSION_SCHEDULES.get(profession, {})
        var workplace := str(npc.get("workplace", ENTITY_WORKPLACE.get(str(npc.get("entity", "")), "Trabalho")))
        var start_hour := int(npc.get("work_start", schedule.get("start", 8)))
        var end_hour := int(npc.get("work_end", schedule.get("end", 17)))

        if _is_weekend():
            if hour >= 10 and hour < 17:
                return "Comércio"
            return "Casa"

        if hour >= start_hour and hour < end_hour:
            return workplace
        if hour >= end_hour and hour < 21:
            return "Comércio"
        return "Casa"
    return "Casa"

func _npc_activity_text(npc: Dictionary) -> String:
    var place := str(npc.get("place", "Casa"))
    var profession := str(npc.get("profession", ""))
    var entity := str(npc.get("entity", ""))
    var start_hour := int(npc.get("work_start", 8))
    var end_hour := int(npc.get("work_end", 17))
    var break_start := int(npc.get("break_start", 12))
    var break_end := int(npc.get("break_end", 13))
    if place == str(npc.get("workplace", "Trabalho")) and hour >= break_start and hour < break_end:
        return "Pausa"
    if place == str(npc.get("workplace", "Trabalho")) and hour >= start_hour and hour < end_hour:
        return "%s • %s" % [profession, entity]
    if place == "Comércio":
        return "Vida pessoal / compras"
    return "Casa / rotina pessoal"

func _update_npc_routines() -> void:
    _update_npc_economy()
    for npc in npcs:
        var name := str(npc.get("name", ""))
        var target := _npc_target_place(name)
        npc["next_destination"] = target
        npc["place"] = target
        npc["activity"] = _npc_activity_text(npc)
    _update_npc_markers()

func _generate_autonomous_event() -> void:
    if autonomous_event_day == day:
        return
    autonomous_event_day = day
    var options := [
        "Movimento normal na cidade: os moradores seguem as suas rotinas.",
        "Pequeno encontro social: dois moradores cruzaram-se durante a rotina.",
        "Comércio movimentado: houve maior movimento durante parte do dia.",
        "Rotina tranquila: não foi registada nenhuma ocorrência relevante.",
        "Alteração de rotina: alguns moradores permaneceram mais tempo em casa."
    ]
    autonomous_event_text = options[(day + weekday) % options.size()]
    npc_event_memory.append("Dia %d: %s" % [day, autonomous_event_text])
    if npc_event_memory.size() > 12:
        npc_event_memory = npc_event_memory.slice(npc_event_memory.size() - 12, npc_event_memory.size())

func _update_npc_economy() -> void:
    # A economia dos NPCs fica inativa até salários, preços e despesas serem
    # definidos em conjunto. Não atribuir saldos nem gerar dinheiro de exemplo.
    return

func _update_npc_health() -> void:
    # Saúde dos NPCs é autónoma e persistente; pequenos efeitos evitam
    # transformar a V0.3.0 num simulador médico complexo.
    for npc in npcs:
        var npc_health := int(npc.get("health", 100))
        var npc_energy := int(npc.get("energy", 80))
        var npc_hunger := int(npc.get("hunger", 20))
        npc_hunger = min(100, npc_hunger + 8)
        npc_energy = max(0, npc_energy - 5)
        if npc_hunger >= 90:
            npc_health = max(0, npc_health - 1)
        if npc_energy <= 10:
            npc_health = max(0, npc_health - 1)
        # Rotina automática do NPC: refeições e descanso.
        if npc_hunger >= 60:
            # A necessidade biológica é simulada sem inventar um preço.
            npc_hunger = max(0, npc_hunger - 30)
        npc_energy = min(100, npc_energy + 20)
        if npc_health < 60:
            # Recuperação abstrata; cuidados e custos detalhados ficam por definir.
            npc_health = min(100, npc_health + 5)
        npc["health"] = npc_health
        npc["energy"] = npc_energy
        npc["hunger"] = npc_hunger

func _npc_pair_key(a: String, b: String) -> String:
    return a + "|" + b if a < b else b + "|" + a

func _simulate_npc_social_life() -> void:
    # Relações entre NPCs também existem sem intervenção do jogador.
    # Um encontro só acontece quando dois NPCs partilham o mesmo local.
    var by_place: Dictionary = {}
    for npc in npcs:
        var place := str(npc.get("place", "Casa"))
        if not by_place.has(place):
            by_place[place] = []
        by_place[place].append(str(npc.get("name", "NPC")))

    for place in by_place.keys():
        var names: Array = by_place[place]
        if names.size() < 2:
            continue
        for i in range(names.size()):
            for j in range(i + 1, names.size()):
                var a := str(names[i])
                var b := str(names[j])
                var key := _npc_pair_key(a, b)
                var rel := int(npc_relations.get(key, 0))
                var change := 1 if ((day + i + j) % 3 != 0) else -1
                rel = clamp(rel + change, -100, 100)
                npc_relations[key] = rel
                npc_event_memory.append("Dia %d: %s e %s encontraram-se em %s (relação %d)." % [day, a, b, place, rel])

    if npc_event_memory.size() > 20:
        npc_event_memory = npc_event_memory.slice(npc_event_memory.size() - 20, npc_event_memory.size())

func _update_npc_markers() -> void:
    for npc in npcs:
        var key := str(npc["name"])
        if not npc_markers.has(key) or not LOCATIONS.has(str(npc["place"])):
            continue
        var marker: Button = npc_markers[key]
        # Se o jogador tem o mesmo nome que um NPC, o marcador do NPC é
        # ocultado para nunca haver duas entidades visualmente indistinguíveis.
        marker.visible = not (v030_control_mode == "personagem" and key == v030_selected_character)
        var pos: Vector2 = LOCATIONS[str(npc["place"])]
        marker.position = _v030_find_npc_label_position(pos, marker, key)

func _v030_find_npc_label_position(base: Vector2, marker: Control, key: String) -> Vector2:
    var candidates := [
        Vector2(-48, 28), Vector2(24, 28), Vector2(-48, -34), Vector2(24, -34),
        Vector2(-72, 8), Vector2(42, 8), Vector2(-72, 52), Vector2(42, 52)
    ]
    var desired := Vector2.ZERO
    for offset in candidates:
        var candidate := Rect2(base + offset, marker.size)
        var collision := false
        for other_key in npc_markers.keys():
            if str(other_key) == key:
                continue
            var other = npc_markers[other_key] as Control
            if other == null or not other.visible:
                continue
            if candidate.grow(4.0).intersects(Rect2(other.position, other.size).grow(4.0)):
                collision = true
                break
        if not collision:
            desired = offset
            break
    return base + desired

func _check_social_encounters() -> void:
    # Encontros sociais são discretos: a IA reconhece o jogador, mas não força uma ação.
    for npc in npcs:
        var name := str(npc.get("name", "NPC"))
        if str(npc.get("place", "")) != current_place:
            continue
        var key := "%s:%d" % [name, day]
        if social_notice_day.has(key):
            continue
        social_notice_day[key] = true
        var rel := int(npc.get("relationship", 0))
        var memories: Array = npc.get("memory", [])
        var note := "Encontrou-se com %s." % name
        if rel >= 25:
            note = "%s reconheceu-o e pareceu contente por o ver." % name
        elif rel <= -10:
            note = "%s reconheceu-o, mas manteve alguma distância." % name
        else:
            note = "%s reconheceu-o como conhecido." % name
        status.text = note
        memories.append("Encontro casual: %s — Dia %d às %02d:00." % [name, day, hour])
        if memories.size() > 8:
            memories = memories.slice(memories.size() - 8, memories.size())
        npc["memory"] = memories
        break

func _create_npc_dialog() -> void:
    # V0.3.0 sem pop-ups: interações de NPC usam o painel de Personagem.
    npc_dialog = null


func _interact_npc(npc_name: String) -> void:
    for npc in npcs:
        if str(npc["name"]) != npc_name:
            continue
        var place := str(npc["place"])
        if place != current_place:
            status.text = "%s está em %s. Está atualmente em %s." % [npc_name, place, current_place]
            _refresh()
            return
        _show_npc_dialog(npc)
        return

func _show_npc_dialog(npc: Dictionary) -> void:
    v030_selected_character = str(npc.get("name", ""))
    v030_player_custom_name = v030_selected_character
    v030_control_mode = "personagem"
    _v030_open_section("Personagem")


func _npc_dialog_line(npc: Dictionary) -> String:
    var rel := int(npc.get("relationship", 0))
    var name := str(npc.get("name", "NPC"))
    if rel >= 60:
        return "%s demonstra grande confiança em si." % name
    if rel >= 25:
        return "%s parece confortável consigo." % name
    if rel <= -25:
        return "%s mantém alguma distância e desconfiança." % name
    if rel < 0:
        return "%s ainda está um pouco desconfortável." % name
    return "%s trata-o como um conhecido." % name

func _npc_action(npc: Dictionary, action: String) -> void:
    var name := str(npc["name"])
    var rel := int(npc.get("relationship", 0))
    var memories: Array = npc.get("memory", [])
    var result := ""
    if action == "greet":
        rel = clamp(rel + 1, -100, 100)
        result = "Cumprimentou %s." % name
        memories.append("Cumprimento: %s — Dia %d às %02d:00." % [name, day, hour])
    elif action == "talk":
        var gain := 2
        if rel >= 25:
            gain = 3
        rel = clamp(rel + gain, -100, 100)
        result = "Conversou com %s." % name
        memories.append("Conversa: %s — Dia %d às %02d:00." % [name, day, hour])
    elif action == "compliment":
        var gain := 3
        if rel < 0:
            gain = 1
        rel = clamp(rel + gain, -100, 100)
        result = "Elogiou %s. A relação melhorou." % name
        memories.append("Elogio: %s — Dia %d às %02d:00." % [name, day, hour])
    else:
        result = "Despediram-se de %s." % name
        memories.append("Despedida: %s — Dia %d às %02d:00." % [name, day, hour])
    if memories.size() > 8:
        memories = memories.slice(memories.size() - 8, memories.size())
    npc["relationship"] = rel
    npc["memory"] = memories
    status.text = "%s Relação: %d — %s." % [result, rel, _relation_label(rel)]
    npc_dialog.hide()
    _refresh()

func _v030_create_map_zoom_controls() -> void:
    if not has_node("UI/Map"):
        return
    for node_name in ["ZoomIn", "ZoomOut", "MapCenter", "MapOverview", "MapLevel1", "MapLevel2", "MapLevel3", "MapLevel4"]:
        var old: Node = $UI/Map.get_node_or_null(node_name)
        if old != null:
            old.queue_free()
    v030_detail_buttons.clear()

    # Controlos explícitos de zoom, enquadramento e níveis de detalhe, adequados a ecrãs táteis.
    v030_zoom_in_button = _v030_make_map_button("ZoomIn", "+", _v030_zoom_in, 24)
    v030_zoom_in_button.tooltip_text = "Aumentar zoom"
    v030_zoom_out_button = _v030_make_map_button("ZoomOut", "−", _v030_zoom_out, 24)
    v030_zoom_out_button.tooltip_text = "Diminuir zoom"
    v030_center_button = _v030_make_map_button("MapCenter", "◎", _v030_center_camera, 22)
    v030_center_button.tooltip_text = "Centrar mapa na personagem"
    v030_overview_button = _v030_make_map_button("MapOverview", "⌂", _v030_overview_camera, 22)
    v030_overview_button.tooltip_text = "Ver cidade inteira"
    v030_detail_buttons = [
        _v030_make_map_button("MapLevel1", "1", _v030_set_detail_level.bind(1), 16),
        _v030_make_map_button("MapLevel2", "2", _v030_set_detail_level.bind(2), 16),
        _v030_make_map_button("MapLevel3", "3", _v030_set_detail_level.bind(3), 16),
        _v030_make_map_button("MapLevel4", "4", _v030_set_detail_level.bind(4), 16)
    ]
    var detail_tooltips := ["Nível 1 — cidade e 25 bairros", "Nível 2 — bairros e estradas", "Nível 3 — ruas e edifícios", "Nível 4 — personagem e veículos"]
    for i in range(v030_detail_buttons.size()):
        v030_detail_buttons[i].tooltip_text = detail_tooltips[i]
    v030_2d_map_button = _v030_make_map_button("Map2D", "2D", _v030_toggle_2d_city_map, 16)
    v030_2d_map_button.tooltip_text = "Abrir mapa 2D com os 25 bairros"
    _v030_build_2d_city_map()

func _v030_make_map_button(node_name: String, caption: String, callback: Callable, font_size: int) -> Button:
    var button := Button.new()
    button.name = node_name
    button.text = caption
    button.focus_mode = Control.FOCUS_NONE
    button.mouse_filter = Control.MOUSE_FILTER_STOP
    button.custom_minimum_size = Vector2(52, 52)
    button.add_theme_font_size_override("font_size", font_size)
    button.pressed.connect(callback)
    $UI/Map.add_child(button)
    button.z_index = 40
    return button

func _v030_layout_map_controls() -> void:
    if not has_node("UI/Map"):
        return
    var map_size: Vector2 = $UI/Map.size
    var x: float = maxf(8.0, map_size.x - 62.0)
    var controls: Array[Button] = [v030_zoom_in_button, v030_zoom_out_button, v030_center_button, v030_overview_button]
    if is_instance_valid(v030_2d_map_button):
        v030_2d_map_button.position = Vector2(x, 42.0 + float(controls.size()) * 58.0)
        v030_2d_map_button.size = Vector2(52, 46)
    for i in range(controls.size()):
        var button: Button = controls[i]
        if is_instance_valid(button):
            button.position = Vector2(x, 42.0 + float(i) * 58.0)
            button.size = Vector2(52, 52)
    # Níveis 1–4 numa faixa horizontal: não ocupam a coluna dos gestos/zoom.
    for i in range(v030_detail_buttons.size()):
        var detail_button: Button = v030_detail_buttons[i]
        if is_instance_valid(detail_button):
            detail_button.position = Vector2(12.0 + float(i) * 42.0, 42.0)
            detail_button.size = Vector2(36.0, 36.0)
    if is_instance_valid(v030_2d_map_button):
        v030_2d_map_button.position = Vector2(x, 42.0 + float(controls.size()) * 58.0)
        v030_2d_map_button.size = Vector2(52, 46)

func _v030_build_2d_city_map() -> void:
    # Atlas interativo: 25 mapas isolados, um por bairro. Cada cartão apresenta
    # a identidade territorial, área/população e abre a vista 3D focada no bairro.
    if not has_node("UI/Map"):
        return
    var old := $UI/Map.get_node_or_null("CityMap2DPanel")
    if old != null:
        old.queue_free()
    v030_2d_map_panel = PanelContainer.new()
    v030_2d_map_panel.name = "CityMap2DPanel"
    v030_2d_map_panel.visible = false
    v030_2d_map_panel.z_index = 80
    v030_2d_map_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    v030_2d_map_panel.offset_left = 12
    v030_2d_map_panel.offset_top = 12
    v030_2d_map_panel.offset_right = -12
    v030_2d_map_panel.offset_bottom = -12
    v030_2d_map_panel.add_theme_stylebox_override("panel", _v030_map_panel_style())
    $UI/Map.add_child(v030_2d_map_panel)
    var outer := VBoxContainer.new()
    outer.add_theme_constant_override("separation", 8)
    v030_2d_map_panel.add_child(outer)
    var header := HBoxContainer.new()
    outer.add_child(header)
    var title := Label.new()
    title.text = "VALEPÓLIS • ATLAS DOS 25 BAIRROS"
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    title.add_theme_font_size_override("font_size", 19)
    title.add_theme_color_override("font_color", Color("#f4d982"))
    header.add_child(title)
    var close := Button.new()
    close.text = "✕ FECHAR"
    close.custom_minimum_size = Vector2(90, 42)
    close.pressed.connect(_v030_toggle_2d_city_map)
    header.add_child(close)
    var hint := Label.new()
    hint.text = "Mapa geral interativo • toca num bairro para abrir a vista 3D; os 25 mapas individuais permanecem abaixo"
    hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    hint.add_theme_font_size_override("font_size", 12)
    outer.add_child(hint)
    # Mapa composto da cidade: os polígonos vêm da matriz territorial oficial.
    # Os cartões abaixo continuam como acessos aos 25 mapas individuais.
    var overview_script := load("res://systems/neighborhood_overview_map.gd") as Script
    if overview_script != null:
        var overview := Control.new()
        overview.set_script(overview_script)
        overview.name = "MapaGeral25Bairros"
        overview.custom_minimum_size = Vector2(0, 220 if get_viewport_rect().size.x < 700 else 270)
        overview.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        overview.size_flags_vertical = Control.SIZE_SHRINK_END
        overview.mouse_filter = Control.MOUSE_FILTER_STOP
        outer.add_child(overview)
        overview.connect("neighborhood_selected", _v030_select_2d_map_neighborhood)
    var scroll := ScrollContainer.new()
    scroll.name = "NeighborhoodAtlasScroll"
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    outer.add_child(scroll)
    var grid := GridContainer.new()
    grid.name = "NeighborhoodAtlasGrid"
    grid.columns = 2 if get_viewport_rect().size.x < 700 else 3
    grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    grid.add_theme_constant_override("h_separation", 8)
    grid.add_theme_constant_override("v_separation", 8)
    scroll.add_child(grid)
    var territory := {}
    var territory_file := "res://data/limites_bairros_v030.json"
    if FileAccess.file_exists(territory_file):
        var f := FileAccess.open(territory_file, FileAccess.READ)
        if f != null:
            var parsed: Variant = JSON.parse_string(f.get_as_text())
            if parsed is Dictionary:
                for item in parsed.get("neighborhoods", []):
                    if item is Dictionary:
                        territory[str(item.get("name", ""))] = item
    var palette: Array[Color] = [Color("#3f806c"), Color("#547e9e"), Color("#9c8455"), Color("#4b7355"), Color("#6c7198")]
    for idx in range(V030_NEIGHBORHOODS.size()):
        var neighborhood := V030_NEIGHBORHOODS[idx]
        var data: Dictionary = territory.get(neighborhood, {})
        var card := PanelContainer.new()
        card.name = "MapaIsolado_" + neighborhood
        card.custom_minimum_size = Vector2(0, 168)
        card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        card.add_theme_stylebox_override("panel", _v030_map_panel_style())
        grid.add_child(card)
        var content := VBoxContainer.new()
        content.add_theme_constant_override("separation", 4)
        card.add_child(content)
        var map_preview := ColorRect.new()
        map_preview.custom_minimum_size = Vector2(0, 74)
        map_preview.color = Color("#163c4a")
        map_preview.mouse_filter = Control.MOUSE_FILTER_IGNORE
        content.add_child(map_preview)
        # Costa/rio/montanha sugeridos por identidade; o preview é um mapa esquemático
        # individual, não substitui a vista 3D real aberta ao selecionar.
        var terrain := ColorRect.new()
        terrain.position = Vector2(0, 0)
        terrain.size = Vector2(0, 0)
        terrain.color = palette[idx % palette.size()]
        terrain.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
        terrain.anchor_left = 0.08
        terrain.anchor_top = 0.12
        terrain.anchor_right = 0.92
        terrain.anchor_bottom = 0.88
        terrain.mouse_filter = Control.MOUSE_FILTER_IGNORE
        map_preview.add_child(terrain)
        var road := ColorRect.new()
        road.color = Color("#d7cba5")
        road.anchor_left = 0.08
        road.anchor_top = 0.46
        road.anchor_right = 0.92
        road.anchor_bottom = 0.51
        road.mouse_filter = Control.MOUSE_FILTER_IGNORE
        map_preview.add_child(road)
        var map_name := Label.new()
        map_name.text = "%02d  %s" % [idx + 1, neighborhood.to_upper()]
        map_name.add_theme_font_size_override("font_size", 14)
        map_name.add_theme_color_override("font_color", Color("#ffffff"))
        content.add_child(map_name)
        var area_km2 := float(data.get("area_km2_measured_from_polygon", 0.0))
        var population := int(data.get("population", v030_get_population(neighborhood)))
        var metrics := Label.new()
        metrics.text = "%.2f km²  •  %s habitantes" % [area_km2, String.num_int64(population)]
        metrics.add_theme_font_size_override("font_size", 11)
        metrics.add_theme_color_override("font_color", Color("#c7d7df"))
        content.add_child(metrics)
        var open_button := Button.new()
        open_button.text = "ABRIR MAPA 3D"
        open_button.custom_minimum_size = Vector2(0, 34)
        open_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        open_button.pressed.connect(_v030_select_2d_map_neighborhood.bind(neighborhood))
        content.add_child(open_button)

func _v030_map_panel_style() -> StyleBoxFlat:
    var style := StyleBoxFlat.new()
    style.bg_color = Color(0.035, 0.075, 0.095, 0.97)
    style.border_color = Color("#6e9da7")
    style.set_border_width_all(2)
    style.set_corner_radius_all(12)
    style.set_content_margin_all(10)
    return style

func _v030_toggle_2d_city_map() -> void:
    if not is_instance_valid(v030_2d_map_panel):
        _v030_build_2d_city_map()
    if is_instance_valid(v030_2d_map_panel):
        v030_2d_map_panel.visible = not v030_2d_map_panel.visible
        if is_instance_valid(v030_2d_map_button):
            v030_2d_map_button.text = "3D" if v030_2d_map_panel.visible else "2D"
        if v030_2d_map_panel.visible:
            v030_2d_map_panel.move_to_front()

func _v030_select_2d_map_neighborhood(neighborhood: String) -> void:
    v030_current_neighborhood = neighborhood
    if is_instance_valid(v030_2d_map_panel):
        v030_2d_map_panel.visible = false
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    if city != null and city.has_method("focus_neighborhood"):
        city.call("focus_neighborhood", neighborhood)
    status.text = "Mapa individual de %s aberto em 3D." % neighborhood
    _v030_update_neighborhood_overlay()

func _v030_set_detail_level(level: int) -> void:
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    if city != null and city.has_method("set_detail_level"):
        var result: Variant = city.call("set_detail_level", level)
        if result is Dictionary and bool(result.get("ok", false)):
            status.text = "Mapa: " + str(result.get("label", "nível %d" % level)) + "."
            return
    # Fallback seguro se a cena 3D ainda não tiver sido carregada.
    v030_map_zoom = [0.85, 1.0, 1.7, 2.2, 2.4][clampi(level, 1, 4)]
    _v030_apply_map_transform()
    status.text = "Mapa: nível de detalhe %d." % clampi(level, 1, 4)

func _v030_center_camera() -> void:
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    if city != null and city.has_method("center_camera_on_player"):
        city.call("center_camera_on_player")
    v030_map_zoom = 1.0
    _v030_apply_map_transform()

func _v030_overview_camera() -> void:
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    v030_map_zoom = 0.62
    _v030_apply_map_transform()
    if city != null and city.has_method("show_city_overview"):
        city.call("show_city_overview")

func _v030_map_rect_global() -> Rect2:
    if map_body == null:
        return Rect2()
    return map_body.get_global_rect()

func _v030_point_on_map(global_point: Vector2) -> bool:
    return _v030_map_rect_global().has_point(global_point)

func _v030_apply_map_transform() -> void:
    # O painel e o SubViewport mantêm sempre o tamanho total disponível.
    # O zoom é aplicado à Camera3D, nunca à escala do MapBody: isto evita
    # que o mapa encolha para um quadrado com margens pretas.
    if map_body == null or not has_node("UI/Map"):
        return
    map_body.set_anchors_preset(Control.PRESET_FULL_RECT)
    map_body.offset_left = 14.0
    map_body.offset_top = 48.0
    map_body.offset_right = -14.0
    map_body.offset_bottom = -14.0
    map_body.position = Vector2.ZERO
    map_body.scale = Vector2.ONE
    map_body.clip_contents = true
    v030_map_scale = 1.0
    v030_map_pan = Vector2.ZERO
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    if city != null and city.has_method("set_external_zoom"):
        city.call("set_external_zoom", v030_map_zoom)

func _v030_set_zoom_at(new_zoom: float, _focus_global: Vector2) -> void:
    if map_body == null or not has_node("UI/Map"):
        return
    v030_map_zoom = clampf(new_zoom, V030_MAP_ZOOM_MIN, V030_MAP_ZOOM_MAX)
    _v030_apply_map_transform()

func _v030_zoom_at(factor: float, focus_global: Vector2) -> void:
    _v030_set_zoom_at(v030_map_zoom * factor, focus_global)

func _v030_zoom_in() -> void:
    var focus: Vector2 = $UI/Map.get_global_rect().get_center()
    _v030_zoom_at(1.20, focus)

func _v030_zoom_out() -> void:
    var focus: Vector2 = $UI/Map.get_global_rect().get_center()
    _v030_zoom_at(1.0 / 1.20, focus)

func _v030_pan_by(delta: Vector2) -> void:
    # O arrasto do mapa não move nem escala o painel. A rotação da vista 3D
    # é tratada pelo controlador da cidade, evitando o mapa reduzido/descentrado.
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    if city != null and city.has_method("rotate_camera_by"):
        city.call("rotate_camera_by", delta)


func _input(event: InputEvent) -> void:
    if map_body == null:
        return

    if event is InputEventMouseButton:
        var mouse: InputEventMouseButton = event as InputEventMouseButton
        if not _v030_point_on_map(mouse.position):
            return
        if mouse.button_index == MOUSE_BUTTON_WHEEL_UP and mouse.pressed:
            _v030_zoom_at(1.15, mouse.position)
            get_viewport().set_input_as_handled()
        elif mouse.button_index == MOUSE_BUTTON_WHEEL_DOWN and mouse.pressed:
            _v030_zoom_at(1.0 / 1.15, mouse.position)
            get_viewport().set_input_as_handled()
        return

    if event is InputEventScreenTouch:
        var touch: InputEventScreenTouch = event as InputEventScreenTouch
        if touch.pressed:
            if _v030_point_on_map(touch.position):
                v030_touch_points[touch.index] = touch.position
                if v030_touch_points.size() == 1:
                    v030_map_dragging = true
                    v030_map_drag_last = touch.position
                elif v030_touch_points.size() == 2:
                    var points: Array = v030_touch_points.values()
                    v030_pinch_distance = (points[0] as Vector2).distance_to(points[1] as Vector2)
                    v030_pinch_center = ((points[0] as Vector2) + (points[1] as Vector2)) * 0.5
                    v030_pinch_zoom = v030_map_zoom
                    v030_pinch_active = v030_pinch_distance > 1.0
                    v030_map_dragging = false
        else:
            v030_touch_points.erase(touch.index)
            if v030_touch_points.size() < 2:
                v030_pinch_active = false
            if v030_touch_points.size() == 1:
                v030_map_dragging = true
                v030_map_drag_last = v030_touch_points.values()[0]
            else:
                v030_map_dragging = false
        return

    if event is InputEventScreenDrag:
        var drag: InputEventScreenDrag = event as InputEventScreenDrag
        if not v030_touch_points.has(drag.index):
            return
        v030_touch_points[drag.index] = drag.position
        if v030_touch_points.size() >= 2:
            var points: Array = v030_touch_points.values()
            var a: Vector2 = points[0]
            var b: Vector2 = points[1]
            var distance: float = a.distance_to(b)
            var center: Vector2 = (a + b) * 0.5
            if v030_pinch_active and v030_pinch_distance > 1.0:
                var ratio: float = distance / v030_pinch_distance
                var desired_zoom: float = clamp(v030_pinch_zoom * ratio, V030_MAP_ZOOM_MIN, V030_MAP_ZOOM_MAX)
                _v030_set_zoom_at(desired_zoom, center)
                v030_pinch_center = center
            return
        if v030_map_dragging:
            var delta: Vector2 = drag.position - v030_map_drag_last
            v030_map_drag_last = drag.position
            _v030_pan_by(delta)
            get_viewport().set_input_as_handled()

func _layout() -> void:
    var s: Vector2 = get_viewport_rect().size
    var margin: float = clamp(s.x * 0.018, 8.0, 16.0)
    var gap: float = clamp(s.y * 0.006, 6.0, 9.0)
    var header_h: float = clamp(s.y * 0.085, 78.0, 94.0)
    var nav_h: float = 58.0
    var context_h: float = clamp(s.y * 0.095, 92.0, 112.0)
    var bottom_h: float = clamp(s.y * 0.060, 60.0, 72.0)
    var actions_h: float = clamp(s.y * 0.125, 118.0, 142.0)
    var header_top := margin
    var nav_top := header_top + header_h + gap
    var map_top := nav_top + nav_h + gap
    var bottom_top := s.y - margin - bottom_h
    var actions_top := bottom_top - gap - actions_h
    var context_top := actions_top - gap - context_h
    var map_h: float = maxf(360.0, context_top - gap - map_top)

    $UI/Header.position = Vector2(margin, header_top)
    $UI/Header.size = Vector2(max(0.0, s.x - margin * 2.0), header_h)
    var compact_header: bool = s.x < 700.0
    var stats_left: float = max(margin + (220.0 if compact_header else 270.0), s.x * (0.52 if compact_header else 0.56))
    var stats_width: float = max(150.0, s.x - stats_left - margin)
    var left_width: float = max(145.0, stats_left - margin - 18.0)
    $UI/Stats.position = Vector2(stats_left, margin + 6.0)
    $UI/Stats.size = Vector2(stats_width, header_h - 12.0)
    $UI/Header/Title.position = Vector2(18.0, 7.0)
    $UI/Header/Sub.position = Vector2(18.0, 43.0)
    $UI/Header/Title.size = Vector2(left_width, 31.0)
    $UI/Header/Sub.size = Vector2(left_width, header_h - 48.0)
    $UI/Header/Title.clip_text = true
    $UI/Header/Sub.clip_text = true
    $UI/Stats.clip_text = true
    $UI/Header/Title.add_theme_font_size_override("font_size", int(clamp(s.x * 0.030, 16.0, 23.0)))
    $UI/Header/Sub.add_theme_font_size_override("font_size", int(clamp(s.x * 0.020, 13.0, 17.0)))
    $UI/Stats.add_theme_font_size_override("font_size", int(clamp(s.x * 0.018, 12.0, 16.0)))

    _v030_layout_professional_ui(s, margin, nav_top, nav_h, context_top, context_h)

    $UI/Map.position = Vector2(margin, map_top)
    $UI/Map.size = Vector2(max(0.0, s.x - margin * 2.0), map_h)
    $UI/Map/MapTitle.position = Vector2(14.0, 8.0)
    $UI/Map/MapTitle.size = Vector2(max(0.0, $UI/Map.size.x - 120.0), 26.0)
    _v030_apply_map_transform()
    if v030_zoom_in_button != null:
        v030_zoom_in_button.position = Vector2(max(8.0, $UI/Map.size.x - 58.0), 12.0)
        v030_zoom_in_button.size = Vector2(42.0, 42.0)
    if v030_zoom_out_button != null:
        v030_zoom_out_button.position = Vector2(max(8.0, $UI/Map.size.x - 58.0), 60.0)
        v030_zoom_out_button.size = Vector2(42.0, 42.0)

    # O painel contextual fica imediatamente abaixo do mapa: nunca existe um
    # grande vazio entre o mapa e a informação operacional.
    $UI/Status.visible = false
    $UI/Status.position = Vector2(margin, context_top)
    $UI/Status.size = Vector2(max(0.0, s.x - margin * 2.0), 1.0)
    $UI/Actions.position = Vector2(margin, actions_top)
    $UI/Actions.size = Vector2(max(0.0, s.x - margin * 2.0), actions_h)
    _layout_action_buttons()
    $UI/Bottom.position = Vector2(margin, bottom_top)
    $UI/Bottom.size = Vector2(max(0.0, s.x - margin * 2.0), bottom_h)
    _v030_sync_map_viewport_size()

func _layout_action_buttons() -> void:
    if not has_node("UI/Actions"):
        return
    var actions: Control = $UI/Actions
    var buttons: Array[Control] = []
    for node_name in ["Move", "Work", "Shop", "Hospital"]:
        var node: Node = actions.get_node_or_null(node_name)
        if node is Control:
            buttons.append(node as Control)
    if buttons.is_empty():
        return
    var gap: float = clamp(actions.size.x * 0.012, 5.0, 10.0)
    var count: int = buttons.size()
    var width: float = max(56.0, (actions.size.x - gap * float(count - 1)) / float(count))
    for i in range(count):
        var button: Control = buttons[i]
        button.position = Vector2(float(i) * (width + gap), 0.0)
        button.size = Vector2(width, actions.size.y)
        button.custom_minimum_size = Vector2(0.0, 0.0)
        _v030_style_action_button(button, "#2aa8dc" if i == 0 else ("#42d98a" if i == 1 else ("#f1b24a" if i == 2 else "#b88cff")))
        # Não aplicar presets de anchors depois de definir posição/tamanho:
        # isso já causou sobreposição dos quatro botões no PRE-FLIGHT.

func _refresh() -> void:
    if v030_control_mode == "personagem" and not v030_player_profile.is_empty():
        v030_player_profile["nome"] = v030_player_custom_name
        v030_player_profile["ramo"] = v030_selected_branch
        v030_player_profile["subcategoria"] = v030_selected_subcategory
        v030_player_profile["profissao"] = v030_selected_profession
        v030_player_profile["cargo"] = v030_selected_cargo
        v030_player_profile["fotografia"] = v030_player_photo_path
        v030_player_profile["residencia"] = current_place
        v030_player_profile["bairro"] = v030_current_neighborhood
    _update_action_buttons()
    var calendar_tag := "FIM DE SEMANA" if _is_weekend() else "DIA ÚTIL"
    # A personagem escolhida é persistente e independente do separador aberto.
    # Ao visualizar o mapa, não mostrar "SEM ESCOLHA" se já existe um perfil válido.
    var control_text := "SEM ESCOLHA"
    var entity_state: Dictionary = {}
    var persistent_character_name := v030_selected_character.strip_edges()
    if persistent_character_name == "" and not v030_player_profile.is_empty():
        persistent_character_name = str(v030_player_profile.get("nome", "")).strip_edges()
    if persistent_character_name == "" and v030_player_custom_name.strip_edges() != "":
        persistent_character_name = v030_player_custom_name.strip_edges()
    if v030_control_mode == "personagem":
        if persistent_character_name != "":
            control_text = "👤 %s • %s • %s" % [persistent_character_name, v030_selected_profession if v030_selected_profession != "" else "Profissão por definir", v030_selected_cargo if v030_selected_cargo != "" else "Cargo por definir"]
        stats.text = "%s\nDia %d  •  %02d:00  •  %s\nEconomia por definir   Energia %d   Fome %d/100   Saúde %d" % [_date_text(), day, hour, _weekday_name(), energy, hunger, health]
    elif persistent_character_name != "" and v030_control_mode != "entidade":
        control_text = "👤 %s • %s" % [persistent_character_name, v030_selected_profession if v030_selected_profession != "" else "Profissão por definir"]
        stats.text = "%s\nDia %d  •  %02d:00  •  %s" % [_date_text(), day, hour, _weekday_name()]
    elif v030_control_mode == "entidade":
        control_text = "🏢 GERIR %s" % v030_selected_entity
        entity_state = v030_entity_management.get(v030_selected_entity, {})
        stats.text = "%s\nDia %d  •  %02d:00  •  %s\nEntidade: %s\nEfetivos, recursos e saldo: por definir" % [_date_text(), day, hour, _weekday_name(), v030_selected_entity]
        if has_node("UI/Map/MapTitle"):
            $UI/Map/MapTitle.text = "CENTRO OPERACIONAL • %s" % v030_selected_entity
    else:
        stats.text = "%s\nDia %d  •  %02d:00  •  %s" % [_date_text(), day, hour, _weekday_name()]
    subtitle.text = "V0.3.0  •  %s  •  %s\n%s  •  ⏱ %s" % [_weekday_name(), calendar_tag, control_text, _time_speed_text()]
    # Sincronizar identidade persistente com a instância 3D do mundo, mesmo ao mudar de separador.
    var city_viewport := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport")
    if city_viewport != null:
        var city_node := city_viewport.get_node_or_null("ValepolisCity3D")
        if city_node != null and city_node.has_method("set_player_identity"):
            var identity_name := persistent_character_name
            if identity_name == "" or identity_name == "PERSONAGEM":
                identity_name = ""
            city_node.call("set_player_identity", identity_name, v030_selected_profession)
    if v030_control_mode == "entidade":
        status.text = "Entidade: %s  •  Catálogo funcional ativo  •  Dimensionamento por definir" % v030_selected_entity
    else:
        status.text = "Local: %s  •  Bairro: %s  •  Destino: %s  •  Trânsito %d%%" % [current_place, v030_current_neighborhood, selected_place, int(v030_traffic_routes.get("city_congestion", 25.0))]
    var world_tag := "Mundo: %s" % autonomous_event_text if autonomous_event_text != "" else "Mundo autónomo ativo"
    var compact_world := str(world_tag)
    if compact_world.length() > 22:
        compact_world = compact_world.substr(0, 22) + "…"
    if v030_control_mode == "entidade":
        status.text = "Entidade: %s  •  Bairro: %s  •  Operação: %s  •  Trânsito %.0f%%  •  %s" % [v030_selected_entity, v030_current_neighborhood, str(entity_state.get("estado", "Operacional")), float(v030_city_state.get("traffic", 0.0)), compact_world]
    else:
        status.text = "Local: %s  •  Bairro: %s  •  Destino: %s  •  Trânsito %.0f%%  •  %s" % [current_place, v030_current_neighborhood, selected_place, float(v030_city_state.get("traffic", 0.0)), compact_world]
    _v030_update_professional_ui()
    _v030_update_state_dashboard()
    _v030_update_neighborhood_overlay()
    _update_player_marker()
    _update_npc_markers()
    if v030_control_mode == "entidade":
        $UI/Actions/Move.disabled = false
        $UI/Actions/Move.text = "GESTÃO"
        $UI/Actions/Work.disabled = false
        $UI/Actions/Work.text = "PESSOAS"
        $UI/Actions/Shop.disabled = false
        $UI/Actions/Shop.text = "RECURSOS"
        var entity_hospital: Button = $UI/Actions/Hospital
        entity_hospital.disabled = false
        entity_hospital.text = "OPERAÇÕES"
    elif v030_control_mode == "mapa":
        if has_node("UI/Map/MapTitle"):
            $UI/Map/MapTitle.text = "MAPA LIVRE • VALEPÓLIS"
        $UI/Actions/Move.disabled = true
        $UI/Actions/Move.text = "EXPLORAR"
        $UI/Actions/Work.disabled = true
        $UI/Actions/Work.text = "MAPA"
        $UI/Actions/Shop.disabled = true
        $UI/Actions/Shop.text = "CAMADAS"
        var free_map_hospital: Button = $UI/Actions/Hospital
        free_map_hospital.disabled = true
        free_map_hospital.text = "INFO"
    else:
        var work_open := hour >= 7 and hour < 21
        var shop_open := hour >= 8 and hour < 22
        $UI/Actions/Work.disabled = current_place != "Trabalho" or not work_open or energy < 10
        $UI/Actions/Work.text = "TRABALHAR" if work_open else "FECHADO"
        $UI/Actions/Shop.disabled = true
        $UI/Actions/Shop.text = "PREÇOS POR DEFINIR"
        var hospital_button: Button = $UI/Actions/Hospital
        hospital_button.disabled = true
        hospital_button.text = "CUSTOS POR DEFINIR" if health < 100 else "SAÚDE %d" % health

func _update_player_marker() -> void:
    if not LOCATIONS.has(current_place):
        return
    var pos: Vector2 = LOCATIONS[current_place]
    var is_character := v030_control_mode == "personagem" and v030_selected_character != ""
    player_marker.position = pos - Vector2(13, 13)
    player_marker.size = Vector2(26, 26)
    player_marker.z_index = 32
    $UI/Map/MapBody/Player.position = pos - Vector2(13, 13)
    $UI/Map/MapBody/Player.size = Vector2(26, 26)
    $UI/Map/MapBody/Player.z_index = 32
    if has_node("UI/Map/MapBody/You"):
        var player_label: Label = $UI/Map/MapBody/You
        # Etiqueta do jogador fica acima e ligeiramente à direita do marcador,
        # com largura suficiente para nomes compostos e sem colidir com o quadrado.
        player_label.position = pos + Vector2(18, -48)
        player_label.size = Vector2(190, 32)
        player_label.z_index = 33
        player_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
        player_label.clip_text = false
        player_label.add_theme_font_size_override("font_size", 15)
        player_label.add_theme_color_override("font_color", Color(1, 0.88, 0.25, 1))
        player_label.text = "★ " + v030_selected_character if is_character else ("🏢 " + v030_selected_entity if v030_control_mode == "entidade" and v030_selected_entity != "" else "VOCÊ")
    $UI/Map/CurrentLocation.text = ""
    _update_location_highlight()
    _v030_apply_control_view()

func _v030_apply_control_view() -> void:
    # PERSONAGEM e ENTIDADE partilham o mesmo mundo, mas não a mesma interface.
    # No modo ENTIDADE não podem permanecer elementos da vida pessoal.
    var is_entity := v030_control_mode == "entidade"
    var personal_nodes := ["Casa", "Trabalho", "Comercio", "Hospital"]
    for node_name in personal_nodes:
        var n := get_node_or_null("UI/Map/MapBody/" + node_name)
        if n != null:
            n.visible = not is_entity

    # As zonas de toque dos locais pessoais também ficam desligadas/ocultas.
    for child_node: Node in map_body.get_children():
        if child_node is Button and child_node.name.begins_with("Location_"):
            child_node.visible = not is_entity

    # O marcador pessoal não representa a entidade.
    if has_node("UI/Map/MapBody/You"):
        $UI/Map/MapBody/You.visible = not is_entity
    if has_node("UI/Map/MapBody/Player"):
        $UI/Map/MapBody/Player.visible = not is_entity
    if player_marker != null:
        player_marker.visible = not is_entity

    # NPCs continuam a existir no mundo, mas não são apresentados como
    # acompanhantes pessoais do gestor da entidade.
    for key in npc_markers.keys():
        var marker: Button = npc_markers[key]
        marker.visible = not is_entity

    if has_node("UI/Map/CurrentLocation"):
        $UI/Map/CurrentLocation.text = "SEDE / ÁREA DE GESTÃO" if is_entity else ""

    # Reforça o cabeçalho correto no modo ENTIDADE.
    if is_entity:
        var entity_name := v030_selected_entity if v030_selected_entity != "" else "Entidade"
        subtitle.text = "V0.3.0  •  🏢 GERIR %s  •  ⏱ %s" % [entity_name, _time_speed_text()]

func _update_location_highlight() -> void:
    var labels := {
        "Casa": $UI/Map/MapBody/Casa,
        "Trabalho": $UI/Map/MapBody/Trabalho,
        "Comércio": $UI/Map/MapBody/Comercio,
        "Hospital": $UI/Map/MapBody/Hospital,
    }
    for place in labels.keys():
        var label: Label = labels[place]
        label.modulate = Color(1.0, 0.9, 0.3, 1.0) if place == selected_place else Color(1, 1, 1, 1)

func _select_location(place: String) -> void:
    selected_place = place
    var selected_neighborhood := _v030_neighborhood_for_place(place)
    if selected_neighborhood in V030_NEIGHBORHOODS:
        v030_current_neighborhood = selected_neighborhood
        _v030_update_neighborhood_overlay()
    if place == current_place:
        status.text = "Já está em %s. Escolha uma ação abaixo." % place
        _refresh()
        return
    status.text = "%s selecionado. Toque em MOVER para deslocar-se." % place
    _refresh()

func _v030_mark_manual_personal_action() -> void:
    # A interação explícita do jogador tem prioridade temporária sobre a IA.
    v030_personal_ai["manual_override_tick"] = v030_simulation_ticks + 2
    v030_personal_ai["last_action"] = "decisão do jogador"
    v030_personal_ai["last_reason"] = "microgestão temporariamente desativada"

func _move() -> void:
    _v030_mark_manual_personal_action()
    if v030_control_mode == "entidade":
        _show_entity_management()
        return
    if selected_place == current_place:
        status.text = "Selecione outro local no mapa para se deslocar."
        return
    if energy < 5:
        status.text = "Está demasiado cansado para se deslocar."
        return
    current_place = selected_place
    v030_current_neighborhood = _v030_neighborhood_for_place(current_place)
    _v030_update_neighborhood_overlay()
    energy = max(0, energy - 5)
    _advance_hour(false)
    status.text = "Chegou a %s. Demorou 1 hora." % current_place
    _refresh()
    _check_social_encounters()
    _maybe_event()

func _work() -> void:
    _v030_mark_manual_personal_action()
    if v030_control_mode == "entidade":
        _show_entity_people()
        return
    if current_place != "Trabalho":
        status.text = "Primeiro selecione TRABALHO no mapa e toque em MOVER."
        return
    if hour < 7 or hour >= 21:
        status.text = "O horário de trabalho é das 07:00 às 21:00."
        return
    if energy < 10:
        status.text = "Está demasiado cansado para trabalhar."
        return
    energy = max(0, energy - 15)
    hunger = min(100, hunger + 8)
    _advance_hour(false)
    status.text = "Trabalhou 1 hora. Remuneração por definir; energia e fome foram atualizadas."
    _refresh()
    _maybe_event()

func _shop() -> void:
    _v030_mark_manual_personal_action()
    if v030_control_mode == "entidade":
        _show_entity_resources()
        return
    if current_place != "Comércio":
        status.text = "Primeiro selecione COMÉRCIO no mapa e toque em MOVER."
        return
    status.text = "Compras indisponíveis: preços e regras económicas ainda não foram definidos."
    _refresh()
    return

func _hospital() -> void:
    _v030_mark_manual_personal_action()
    if v030_control_mode == "entidade":
        _show_entity_operations()
        return
    if current_place != "Hospital":
        status.text = "Primeiro selecione HOSPITAL no mapa e toque em MOVER."
        return
    if health >= 100:
        status.text = "A saúde já está a 100%."
        return
    status.text = "Tratamento pago indisponível: custos e regras de acesso ainda não foram definidos."
    _refresh()
    return


func _maybe_event() -> void:
    if event_open or event_day == day or hour < 10:
        return
    event_day = day
    event_open = true
    status.text = "NOVA OCORRÊNCIA • informação incompleta recebida perto do hospital."
    _refresh()
    _v030_open_section("Operacoes")

func _event_help(_unused: Variant = null) -> void:
    event_open = false
    energy = max(0, energy - 10)
    hunger = min(100, hunger + 5)
    _advance_hour(false)
    status.text = "Ajudou. Gastou tempo e energia, mas resolveu a ocorrência."
    _refresh()
    _v030_close_section()

func _event_ignore(_unused: Variant = null) -> void:
    event_open = false
    _advance_hour(false)
    status.text = "Ignorou a ocorrência e continuou a sua rotina."
    _refresh()
    _v030_close_section()

func _advance_hour(_legacy: bool = true) -> void:
    v030_systems_update()
    v030_update_npc_daily_life()
    _update_npc_routines()
    v030_update_npc_travel()
    v030_update_social_life()
    v030_update_social_relations()
    v030_complete_update()
    hour += 1

    # O tempo quotidiano tem efeitos moderados. A personagem não deve ficar
    # exausta a meio de um dia normal; alimentação e sono são autónomos.
    energy = max(0, energy - 1)
    hunger = min(100, hunger + 2)

    _run_automatic_routine()

    # Consequências apenas quando existe uma necessidade realmente crítica.
    if hunger >= 95:
        health = max(0, health - 1)
    if energy <= 5:
        health = max(0, health - 1)

    if hour >= 24:
        hour = 0
        _advance_calendar_day()

func _run_automatic_routine() -> void:
    # Necessidades biológicas são simuladas sem atribuir preços.
    if hour in [8, 13, 20]:
        hunger = max(0, hunger - 30)
        energy = min(100, energy + 2)
        status.text = "Rotina automática: refeição simulada; custo por definir."

    # Sono automático. Não existe botão DORMIR.
    # Ao fim do dia regressa a casa e inicia o dia seguinte recuperada.
    if hour >= 23:
        current_place = "Casa"
        selected_place = "Casa"
        energy = 100
        hunger = min(100, hunger + 8)
        # O avanço do relógio é feito por _advance_hour(); não reiniciar
        # manualmente a hora aqui.

func _character() -> void:
    if v030_control_mode == "entidade":
        _show_entity_management()
        return
    _v030_open_section("Personagem")

func _show_entity_management() -> void:
    if v030_selected_entity == "":
        return
    _v030_open_section("Base")

func _show_entity_people() -> void:
    _v030_open_section("PessoasE")

func _show_entity_resources() -> void:
    _v030_open_section("RecursosE")

func _show_entity_operations() -> void:
    _v030_open_section("Operacoes")

func _v030_entity_action_management(state: Dictionary, update_info: Callable, action: String) -> void:
    # Efetivos, recursos, instalações e economia foram deliberadamente deixados por definir.
    status.text = "Ação não aplicada: é necessário configurar primeiro os dados da entidade em conjunto."
    if update_info.is_valid():
        update_info.call()

func _v030_entity_people_hire(state: Dictionary, info: Label) -> void:
    info.text = "Contratação indisponível até definirmos efetivos, funções, turnos e orçamento da entidade."

func _v030_entity_resources_action(state: Dictionary, info: Label, action: String) -> void:
    info.text = "Gestão de recursos indisponível até definirmos instalações, viaturas, inventário, orçamento e saldo."

func _v030_entity_launch_operation(state: Dictionary, info: Label) -> void:
    info.text = "O despacho operacional requer a integração e registo de equipas e viaturas compatíveis."

func v030_register_entity_action(action: String) -> void:
    # Regista apenas a tentativa/ação de interface; não cria efetivos, frota,
    # instalações, inventário, orçamento, saldo ou disponibilidade fictícios.
    v030_entity_action_log.append({"dia":day,"hora":hour,"acao":action,"entidade":v030_selected_entity})
    if v030_entity_action_log.size() > 100:
        v030_entity_action_log.pop_front()
    _save_game_silent()

func _open_player_photo_dialog(name_edit: LineEdit) -> void:
    status.text = "Fotografia: seleção externa desativada nesta interface sem pop-ups."
    _v030_open_section("Personagem")

func _confirm_new_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        _start_new_game()
        return
    _v030_open_section("NovoJogo")

func _start_new_game() -> void:
    if FileAccess.file_exists(SAVE_PATH):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
    v030_control_mode = ""
    v030_selected_branch = ""
    v030_selected_subcategory = ""
    v030_selected_profession = ""
    v030_selected_cargo = ""
    v030_selected_entity = ""
    v030_selected_character = ""
    v030_player_custom_name = ""
    v030_player_photo_path = ""
    v030_selected_season_ui = 1
    v030_selected_episode_ui = 1
    v030_episode_selection_confirmed = false
    v030_episode_completed.clear()
    if is_instance_valid(v030_runtime):
        v030_runtime.sync_progression(1, 1)
    v030_player_profile = {}
    v030_entity_management = {}
    v030_entity_action_log = []
    v030_entity_budget = null
    v030_personal_economy_configured = false
    energy = 80
    hunger = 20
    health = 100
    current_place = "Casa"
    selected_place = "Casa"
    _init_real_world_clock()
    _show_start_menu()
    status.text = "Novo jogo: escolha PERSONAGEM ou ENTIDADE."

func _continue_saved_game() -> void:
    if FileAccess.file_exists(SAVE_PATH):
        _load_game()
        _hide_start_menu()
        _refresh()
    else:
        _menu_home()

func _credits() -> void:
    _v030_open_section("Sobre")

func _save_game() -> void:
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify({
            "version":"0.3.0",
            "narrative_season":v030_selected_season_ui,
            "narrative_episode":v030_selected_episode_ui,
            "narrative_selection_confirmed":v030_episode_selection_confirmed,
            "narrative_completed":v030_episode_completed,
            "control_mode":v030_control_mode,"selected_branch":v030_selected_branch,"selected_subcategory":v030_selected_subcategory,"selected_profession":v030_selected_profession,"selected_cargo":v030_selected_cargo,"selected_entity":v030_selected_entity,"selected_character":v030_selected_character,"player_custom_name":v030_player_custom_name,"player_photo_path":v030_player_photo_path,"player_profile":v030_player_profile,"entity_management":v030_entity_management,"entity_action_log":v030_entity_action_log,"entity_budget":v030_entity_budget,
            "day":day,"hour":hour,"weekday":weekday,
            "year":year,"month":month,"month_day":month_day,
            "personal_economy_configured":false,"energy":energy,"hunger":hunger,"health":health,
            "place":current_place,"selected":selected_place,
            "current_neighborhood":v030_current_neighborhood,
            "event_day":event_day,
            "autonomous_event_day":autonomous_event_day,
            "autonomous_event_text":autonomous_event_text,
            "npc_event_memory":npc_event_memory,
            "npc_relations":npc_relations,
            "social_events":v030_social_events,
            "npc_social_state":v030_npc_social_state,
            "social_relations":v030_social_relations,
            "service_usage":v030_service_usage,
            "daily_activity":v030_daily_activity,
            "school_state":v030_school_state,
            "work_state":v030_work_state,
            "population_materialized":v030_population_materialized,
            "residence_moves":v030_residence_moves,
            "calendar_history":v030_calendar_history,
            "world_state":v030_world_state_v030,
            "npc_daily_needs":v030_npc_daily_needs,
            "npc_activity_log":v030_npc_activity_log,
            "neighborhood_profile":v030_neighborhood_profile,
            "jobs":v030_jobs,
            "entities":v030_entities,
            "public_services":v030_public_services,
            "economy":v030_economy,
            "player_interactions":v030_player_interactions,
            "routes":v030_routes,
            "city_traffic":v030_city_traffic,
            "ai_decisions":v030_ai_decisions,
            "professions_catalog":v030_professions_catalog,
            "entities_catalog":v030_entities_catalog,
            "establishments":v030_establishments,
            "family_economy":v030_family_economy,
            "npc_profiles":v030_npc_profiles,
            "npc_relationships":v030_npc_relationships,
            "city_events":v030_city_events,
            "city_event_history":v030_city_event_history,
            "service_state":v030_service_state,
            "player_actions":v030_player_actions,
            "unemployment":v030_unemployment,
            "household_expenses":v030_household_expenses,
            "economic_history":v030_economic_history,
            "world_metrics":v030_world_metrics,
            
            "player_daily_income":null,
            "auto_time_enabled":auto_time_enabled,
            "npcs":npcs
        }))
        f.close()
        status.text = "Jogo guardado."

func _load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        status.text = "Ainda não existe uma gravação."
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    var data = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(data) == TYPE_DICTIONARY:
        v030_selected_season_ui = clampi(int(data.get("narrative_season", 1)), 1, 20)
        v030_selected_episode_ui = clampi(int(data.get("narrative_episode", 1)), 1, 10)
        v030_episode_selection_confirmed = bool(data.get("narrative_selection_confirmed", false))
        var saved_completed = data.get("narrative_completed", [])
        v030_episode_completed.clear()
        if saved_completed is Array:
            for completed_key in saved_completed:
                if completed_key is String and not v030_episode_completed.has(completed_key):
                    v030_episode_completed.append(completed_key)
        v030_control_mode = str(data.get("control_mode", ""))
        v030_selected_branch = str(data.get("selected_branch", ""))
        v030_selected_subcategory = str(data.get("selected_subcategory", ""))
        v030_selected_profession = str(data.get("selected_profession", ""))
        v030_selected_cargo = str(data.get("selected_cargo", ""))
        v030_selected_entity = str(data.get("selected_entity", ""))
        v030_selected_character = str(data.get("selected_character", ""))
        v030_player_custom_name = str(data.get("player_custom_name", v030_selected_character))
        v030_player_photo_path = str(data.get("player_photo_path", ""))
        v030_player_profile = data.get("player_profile", {}) if typeof(data.get("player_profile", {})) == TYPE_DICTIONARY else {}
        # Ignora registos de gestão antigos: podem conter quantidades de demonstração.
        # A configuração real das entidades será feita em conjunto numa fase posterior.
        v030_entity_management = {}
        v030_entity_action_log = data.get("entity_action_log", []) if data.get("entity_action_log", []) is Array else []
        v030_entity_budget = null
        day = int(data.get("day", 1))
        hour = int(data.get("hour", 7))
        weekday = int(data.get("weekday", ((day - 1) % 7) + 1))
        year = int(data.get("year", 1))
        month = int(data.get("month", 1))
        month_day = int(data.get("month_day", ((day - 1) % 30) + 1))
        # Não importar saldos antigos: eram valores de demonstração não aprovados.
        v030_personal_economy_configured = false
        energy = int(data.get("energy", 80))
        hunger = int(data.get("hunger", 20))
        health = int(data.get("health", 100))
        current_place = str(data.get("place", "Casa"))
        selected_place = str(data.get("selected", current_place))
        v030_current_neighborhood = str(data.get("current_neighborhood", _v030_neighborhood_for_place(current_place)))
        event_day = int(data.get("event_day", 0))
        autonomous_event_day = int(data.get("autonomous_event_day", 0))
        autonomous_event_text = str(data.get("autonomous_event_text", ""))
        auto_time_enabled = bool(data.get("auto_time_enabled", true))
        auto_time_accumulator = 0.0
        var saved_world_events = data.get("npc_event_memory", [])
        if saved_world_events is Array:
            npc_event_memory = saved_world_events
        var saved_npc_relations = data.get("npc_relations", {})
        if saved_npc_relations is Dictionary:
            npc_relations = saved_npc_relations
        var saved_social_events = data.get("social_events", [])
        if saved_social_events is Array:
            v030_social_events = saved_social_events
        var saved_social_state = data.get("npc_social_state", {})
        if saved_social_state is Dictionary:
            v030_npc_social_state = saved_social_state
        var saved_social_relations = data.get("social_relations", {})
        if saved_social_relations is Dictionary:
            v030_social_relations = saved_social_relations
        var saved_service_usage = data.get("service_usage", {})
        if saved_service_usage is Dictionary:
            v030_service_usage = saved_service_usage
        var saved_daily_activity = data.get("daily_activity", {})
        if saved_daily_activity is Dictionary:
            v030_daily_activity = saved_daily_activity
        var saved_school_state = data.get("school_state", {})
        if saved_school_state is Dictionary:
            v030_school_state = saved_school_state
        var saved_work_state = data.get("work_state", {})
        if saved_work_state is Dictionary:
            v030_work_state = saved_work_state
        var saved_population = data.get("population_materialized", {})
        if saved_population is Dictionary:
            v030_population_materialized = saved_population
        var saved_moves = data.get("residence_moves", [])
        if saved_moves is Array:
            v030_residence_moves = saved_moves
        var saved_calendar = data.get("calendar_history", [])
        if saved_calendar is Array:
            v030_calendar_history = saved_calendar
        var saved_world = data.get("world_state", {})
        if saved_world is Dictionary:
            v030_world_state_v030 = saved_world
        var saved_needs = data.get("npc_daily_needs", {})
        if saved_needs is Dictionary:
            v030_npc_daily_needs = saved_needs
        var saved_activity_log = data.get("npc_activity_log", {})
        if saved_activity_log is Dictionary:
            v030_npc_activity_log = saved_activity_log
        var saved_profiles = data.get("neighborhood_profile", {})
        if saved_profiles is Dictionary:
            v030_neighborhood_profile = saved_profiles
        var saved_jobs = data.get("jobs", {})
        if saved_jobs is Dictionary:
            v030_jobs = saved_jobs
        var saved_entities = data.get("entities", {})
        if saved_entities is Dictionary:
            v030_entities = saved_entities
        var saved_services = data.get("public_services", {})
        if saved_services is Dictionary:
            v030_public_services = saved_services
        var saved_economy = data.get("economy", {})
        if saved_economy is Dictionary:
            v030_economy = {"configured": false, "status": "por_definir", "history": []}
        var saved_interactions = data.get("player_interactions", [])
        if saved_interactions is Array:
            v030_player_interactions = saved_interactions
        var saved_routes = data.get("routes", {})
        if saved_routes is Dictionary:
            v030_routes = saved_routes
        var saved_traffic = data.get("city_traffic", {})
        if saved_traffic is Dictionary:
            v030_city_traffic = saved_traffic
        var saved_ai = data.get("ai_decisions", {})
        if saved_ai is Dictionary:
            v030_ai_decisions = saved_ai
        var saved_professions = data.get("professions_catalog", {})
        if saved_professions is Dictionary:
            v030_professions_catalog = saved_professions
        var saved_entities_catalog = data.get("entities_catalog", {})
        if saved_entities_catalog is Dictionary:
            v030_entities_catalog = saved_entities_catalog
        var saved_establishments = data.get("establishments", {})
        if saved_establishments is Dictionary:
            v030_establishments = saved_establishments
        var saved_family_economy = data.get("family_economy", {})
        if saved_family_economy is Dictionary:
            v030_family_economy = saved_family_economy
        var saved_profiles2 = data.get("npc_profiles", {})
        if saved_profiles2 is Dictionary:
            v030_npc_profiles = saved_profiles2
        var saved_relationships2 = data.get("npc_relationships", {})
        if saved_relationships2 is Dictionary:
            v030_npc_relationships = saved_relationships2
        var saved_city_events2 = data.get("city_events", [])
        if saved_city_events2 is Array:
            v030_city_events = saved_city_events2
        var saved_city_history2 = data.get("city_event_history", [])
        if saved_city_history2 is Array:
            v030_city_event_history = saved_city_history2
        var saved_service_state2 = data.get("service_state", {})
        if saved_service_state2 is Dictionary:
            v030_service_state = saved_service_state2
        var saved_player_actions2 = data.get("player_actions", [])
        if saved_player_actions2 is Array:
            v030_player_actions = saved_player_actions2
        var saved_unemployment2 = data.get("unemployment", {})
        if saved_unemployment2 is Dictionary:
            v030_unemployment = saved_unemployment2
        var saved_household_expenses2 = data.get("household_expenses", {})
        if saved_household_expenses2 is Dictionary:
            v030_household_expenses = saved_household_expenses2
        var saved_economic_history2 = data.get("economic_history", [])
        if saved_economic_history2 is Array:
            v030_economic_history = saved_economic_history2
        var saved_world_metrics2 = data.get("world_metrics", {})
        if saved_world_metrics2 is Dictionary:
            v030_world_metrics = saved_world_metrics2
        if saved_ai is Dictionary:
            v030_ai_decisions = saved_ai

        var saved_npcs = data.get("npcs", [])
        if saved_npcs is Array and saved_npcs.size() == npcs.size():
            npcs = saved_npcs
            for npc in npcs:
                if not npc.has("memory"):
                    npc["memory"] = []
                if not npc.has("residence"):
                    npc["residence"] = "Casa"
                if not npc.has("profession"):
                    npc["profession"] = "Atividade"
                if not npc.has("entity"):
                    npc["entity"] = PROFESSIONS.get(str(npc.get("profession", "")), "Município de Valepólis")
                # Remover valores económicos legados não aprovados.
                npc.erase("money")
                npc.erase("daily_income")
                npc.erase("daily_expenses")
                npc.erase("economy_day")
                if not npc.has("health"):
                    npc["health"] = 100
                if not npc.has("energy"):
                    npc["energy"] = 80
                if not npc.has("hunger"):
                    npc["hunger"] = 20
                var profession_name := str(npc.get("profession", ""))
                var schedule: Dictionary = PROFESSION_SCHEDULES.get(profession_name, {})
                if not npc.has("workplace"):
                    npc["workplace"] = ENTITY_WORKPLACE.get(str(npc.get("entity", "")), "Trabalho")
                if not npc.has("work_start"):
                    npc["work_start"] = int(schedule.get("start", 8))
                if not npc.has("work_end"):
                    npc["work_end"] = int(schedule.get("end", 17))
                if not npc.has("break_start"):
                    npc["break_start"] = int(schedule.get("break_start", 12))
                if not npc.has("break_end"):
                    npc["break_end"] = int(schedule.get("break_end", 13))
                if not npc.has("activity"):
                    npc["activity"] = "Casa / rotina pessoal"
                if not npc.has("next_destination"):
                    npc["next_destination"] = "Casa"
        _v030_migrate_legacy_npc_names()
        _v030_reset_unapproved_economy()
        v030_load_integrated_state()
        if is_instance_valid(v030_runtime):
            v030_runtime.sync_progression(v030_selected_season_ui, v030_selected_episode_ui)
        _update_npc_routines()
        social_notice_day.clear()
        status.text = "Jogo carregado."
        _check_social_encounters()
        _refresh()


# --- CIRCULACAO_DESLOCACOES_V0_3_0 ---
# Circulação e deslocações — V0.3.0
# Camada autónoma para integrar com o estado dos NPCs.
# Não substitui a rotina existente; fornece cálculo de viagem e atualização.

const TRAVEL_SPEED_KMH := 4.5
const MIN_TRAVEL_MINUTES := 3

var npc_travel_state: Dictionary = {}

func _travel_minutes(from_location: String, to_location: String) -> int:
    if from_location == to_location:
        return 0
    var key := from_location + ">" + to_location
    var distances := {
        "Casa>Trabalho": 18, "Trabalho>Casa": 18,
        "Casa>Comércio": 10, "Comércio>Casa": 10,
        "Casa>Hospital": 14, "Hospital>Casa": 14,
        "Trabalho>Comércio": 9, "Comércio>Trabalho": 9,
        "Trabalho>Hospital": 11, "Hospital>Trabalho": 11,
        "Comércio>Hospital": 8, "Hospital>Comércio": 8
    }
    return max(MIN_TRAVEL_MINUTES, int(distances.get(key, 12)))

func start_npc_travel(npc_id: String, from_location: String, destination: String) -> void:
    var minutes := _travel_minutes(from_location, destination)
    npc_travel_state[npc_id] = {
        "origin": from_location,
        "destination": destination,
        "remaining_minutes": minutes,
        "traveling": minutes > 0
    }

func advance_npc_travel(npc_id: String, elapsed_minutes: int) -> Dictionary:
    if not npc_travel_state.has(npc_id):
        return {}
    var state: Dictionary = npc_travel_state[npc_id]
    state["remaining_minutes"] = max(0, int(state["remaining_minutes"]) - elapsed_minutes)
    if int(state["remaining_minutes"]) == 0:
        state["traveling"] = false
        state["current_location"] = state["destination"]
    npc_travel_state[npc_id] = state
    return state

func get_npc_travel(npc_id: String) -> Dictionary:
    return npc_travel_state.get(npc_id, {})

func serialize_travel_state() -> Dictionary:
    return npc_travel_state.duplicate(true)

func restore_travel_state(data: Dictionary) -> void:
    npc_travel_state = data.duplicate(true)



# --- TRANSITO_BASICO_V0_3_0 ---
# Camada inicial de trânsito: intensidade por período e estado de circulação.
var traffic_state: Dictionary = {
    "level": "normal",
    "vehicles_active": 0,
    "incidents": 0
}

func update_traffic(hour: int, relevant_event: bool = false) -> Dictionary:
    if relevant_event:
        traffic_state["level"] = "high"
    elif hour >= 7 and hour <= 9:
        traffic_state["level"] = "busy"
    elif hour >= 17 and hour <= 19:
        traffic_state["level"] = "busy"
    elif hour >= 23 or hour <= 5:
        traffic_state["level"] = "low"
    else:
        traffic_state["level"] = "normal"
    return traffic_state

func get_traffic_state() -> Dictionary:
    return traffic_state.duplicate(true)

func serialize_traffic_state() -> Dictionary:
    return traffic_state.duplicate(true)

func restore_traffic_state(data: Dictionary) -> void:
    traffic_state = data.duplicate(true)


# --- V0_3_0_FINAL_INTEGRATION ---

# --- V0_3_0_FINAL_INTEGRATION ---
# Fecho da fundação V0.3.0:
# estado global persistente, ciclo diário e integração básica dos subsistemas.

const V030_SAVE_VERSION := 1
const V030_SAVE_PATH := "user://valepolis_v0.3.0.save"

var v030_world_state: Dictionary = {
    "version": V030_SAVE_VERSION,
    "day": 1,
    "hour": 8,
    "minute": 0,
    "player": {},
    "npcs": {},
    "relations": {},
    "memories": [],
    "economy": {},
    "health": {},
    "routines": {},
    "locations": {},
    "travel": {},
    "traffic": {},
    "events": []
}

func v030_build_state() -> Dictionary:
    var state := v030_world_state.duplicate(true)
    if has_method("serialize_travel_state"):
        state["travel"] = serialize_travel_state()
    if has_method("serialize_traffic_state"):
        state["traffic"] = serialize_traffic_state()
    return state

func v030_advance_time(minutes: int) -> void:
    minutes = max(0, minutes)
    var total := int(v030_world_state.get("hour", 8)) * 60 + int(v030_world_state.get("minute", 0)) + minutes
    var new_day := int(v030_world_state.get("day", 1))
    while total >= 1440:
        total -= 1440
        new_day += 1
    v030_world_state["day"] = new_day
    v030_world_state["hour"] = total / 60
    v030_world_state["minute"] = total % 60

func v030_get_neighborhoods() -> Array:
    return V030_NEIGHBORHOODS.duplicate()



# --- V0_3_0_POPULACAO ---
const V030_CITY_POPULATION := 1000000
var v030_population_by_neighborhood: Dictionary = {}

func v030_initialize_population() -> void:
    if not v030_population_by_neighborhood.is_empty():
        return
    var names := v030_get_neighborhoods() if has_method("v030_get_neighborhoods") else []
    if names.is_empty():
        names = ["Nexora"]
    var base := int(V030_CITY_POPULATION / names.size())
    var remainder := V030_CITY_POPULATION - (base * names.size())
    for i in range(names.size()):
        v030_population_by_neighborhood[names[i]] = base + (1 if i < remainder else 0)

func v030_get_population(neighborhood: String = "") -> int:
    v030_initialize_population()
    if neighborhood == "":
        return V030_CITY_POPULATION
    return int(v030_population_by_neighborhood.get(neighborhood, 0))



# --- V0_3_0_RESIDENCIAS ---
var v030_residences: Dictionary = {}
var v030_families: Dictionary = {}
var v030_family_counter := 0
var v030_family_id_by_npc: Dictionary = {}
var v030_family_relationships: Array = []
var v030_family_member_state: Dictionary = {}
var v030_dependent_state: Dictionary = {}



const V030_FAMILY_RELATION_TYPES := ["conjuge", "pai", "mae", "filho", "irmao", "avo", "neto", "tutor", "dependente"]

const V030_FAMILY_ROLES := ["adulto", "criança", "idoso", "dependente"]

var v030_residence_counter := 0

func v030_create_family(family_name: String, residence_id: String = "") -> String:
    v030_family_counter += 1
    var family_id := "FAM%05d" % v030_family_counter
    v030_families[family_id] = {
        "id": family_id,
        "nome": family_name,
        "residencia_id": residence_id,
        "membros": [],
        "criada_dia": day,
    }
    return family_id

func v030_add_family_member(family_id: String, npc_name: String, role: String = "adulto") -> bool:
    if not v030_families.has(family_id):
        return false
    if role not in V030_FAMILY_ROLES:
        role = "adulto"
    var members: Array = v030_families[family_id].get("membros", [])
    if npc_name not in members:
        members.append(npc_name)
    v030_families[family_id]["membros"] = members
    return true

func v030_assign_family_to_residence(family_id: String, residence_id: String) -> bool:
    if not v030_families.has(family_id) or not v030_residences.has(residence_id):
        return false
    v030_families[family_id]["residencia_id"] = residence_id
    var occupants: Array = v030_residences[residence_id].get("ocupantes", [])
    for npc_name in v030_families[family_id].get("membros", []):
        if npc_name not in occupants:
            occupants.append(npc_name)
    var capacity := int(v030_residences[residence_id].get("capacidade", 1))
    if occupants.size() > capacity:
        return false
    v030_residences[residence_id]["ocupantes"] = occupants
    return true

func v030_seed_initial_families() -> void:
    if not v030_families.is_empty():
        return
    var fam := v030_create_family("Agregado Nexora")
    v030_link_npc_to_family("Arel Valara", fam, "adulto")
    v030_link_npc_to_family("Néria Nerova", fam, "adulto")
    v030_add_family_relationship("Arel Valara", "Néria Nerova", "conjuge")
    var residence_id := ""
    if not v030_residences.is_empty():
        residence_id = str(v030_residences.keys()[0])
        v030_assign_family_to_residence(fam, residence_id)
    v030_update_family_member_state()



func v030_update_family_routines() -> void:
    # A família partilha a residência como ponto de origem, mas cada membro
    # mantém a sua profissão/rotina individual.
    for family_id in v030_families.keys():
        var family: Dictionary = v030_families[family_id]
        var residence_id := str(family.get("residencia_id", ""))
        var residence: Dictionary = v030_residences.get(residence_id, {})
        var neighborhood := str(residence.get("bairro", ""))
        family["bairro"] = neighborhood
        family["ultima_atualizacao_dia"] = day
        family["ultima_atualizacao_hora"] = hour
        v030_families[family_id] = family

func v030_link_npc_to_family(npc_name: String, family_id: String, role: String = "adulto") -> bool:
    if not v030_families.has(family_id):
        return false
    if not v030_add_family_member(family_id, npc_name, role):
        return false
    v030_family_id_by_npc[npc_name] = family_id
    return true

func v030_add_family_relationship(npc_a: String, npc_b: String, relation: String) -> bool:
    if npc_a == npc_b:
        return false
    if relation not in V030_FAMILY_RELATION_TYPES:
        return false
    if str(v030_family_id_by_npc.get(npc_a, "")) == "" or str(v030_family_id_by_npc.get(npc_b, "")) == "":
        return false
    for item in v030_family_relationships:
        if str(item.get("a", "")) == npc_a and str(item.get("b", "")) == npc_b and str(item.get("relacao", "")) == relation:
            return true
    v030_family_relationships.append({
        "a": npc_a,
        "b": npc_b,
        "relacao": relation,
        "criada_dia": day
    })
    return true

func v030_update_family_member_state() -> void:
    # Estado familiar deriva do relógio do jogo; não cria controlos manuais.
    for family_id in v030_families.keys():
        var family: Dictionary = v030_families[family_id]
        for npc_name in family.get("membros", []):
            var state := str(v030_family_member_state.get(npc_name, "em_casa"))
            var role := "adulto"
            for rel in v030_family_relationships:
                if str(rel.get("a", "")) == npc_name or str(rel.get("b", "")) == npc_name:
                    role = "adulto"
                    break
            if hour >= 8 and hour < 18:
                state = "atividade_diurna"
            elif hour >= 18 and hour < 23:
                state = "regresso_ou_lazer"
            else:
                state = "em_casa"
            v030_family_member_state[npc_name] = {
                "estado": state,
                "familia_id": family_id,
                "dia": day,
                "hora": hour,
                "papel": role
            }

func v030_update_dependent_states() -> void:
    # Crianças/dependentes têm uma rotina automática própria.
    for family_id in v030_families.keys():
        var family: Dictionary = v030_families[family_id]
        for npc_name in family.get("membros", []):
            var state: Dictionary = v030_family_member_state.get(npc_name, {})
            var role := str(state.get("papel", "adulto"))
            if role == "criança" or role == "dependente":
                var activity := "em_casa"
                if hour >= 8 and hour < 16:
                    activity = "escola_ou_atividade"
                elif hour >= 16 and hour < 20:
                    activity = "regresso_ou_lazer"
                v030_dependent_state[npc_name] = {
                    "estado": activity,
                    "familia_id": family_id,
                    "dia": day,
                    "hora": hour
                }

func v030_initialize_neighborhood_profiles() -> void:
    if not v030_neighborhood_profile.is_empty():
        return
    for i in range(V030_NEIGHBORHOODS.size()):
        var name := str(V030_NEIGHBORHOODS[i])
        var density := 0.6 + float(i % 5) * 0.08
        v030_neighborhood_profile[name] = {
            "nome": name,
            "densidade": density,
            "residencias": 0,
            "comercio": 1 + (i % 3),
            "servicos": 1 + (i % 4),
            "atividade": "normal"
        }

func v030_update_calendar_world() -> void:
    v030_weekend = weekday == 6 or weekday == 7
    v030_school_day = not v030_weekend and not v030_holiday
    var m := month
    if m in [12, 1, 2]:
        v030_season = "inverno"
    elif m in [3, 4, 5]:
        v030_season = "primavera"
    elif m in [6, 7, 8]:
        v030_season = "verão"
    else:
        v030_season = "outono"
    var seed_value := int(year * 10000 + month * 100 + month_day)
    var weather_options := ["limpo", "nublado", "chuva", "vento"]
    v030_weather = weather_options[abs(seed_value) % weather_options.size()]
    # Feriados nacionais base simples, extensível.
    v030_holiday = (month == 1 and month_day == 1) or (month == 4 and month_day == 25) or (month == 5 and month_day == 1) or (month == 6 and month_day == 10) or (month == 8 and month_day == 15) or (month == 10 and month_day == 5) or (month == 11 and month_day == 1) or (month == 12 and month_day == 1) or (month == 12 and month_day == 8) or (month == 12 and month_day == 25)
    v030_school_day = not v030_weekend and not v030_holiday

func v030_run_school_and_work() -> void:
    for npc_name in ["Arel Valara", "Néria Nerova", "Varel Loreno"]:
        var state := {"estado": "em_casa", "hora": hour, "dia": day}
        if npc_name == "Arel Valara":
            if v030_school_day and hour >= 8 and hour < 17:
                state["estado"] = "na_escola"
                state["local"] = "Trabalho"
            else:
                state["local"] = "Casa"
        elif npc_name == "Néria Nerova":
            if hour >= 9 and hour < 19 and not v030_weekend:
                state["estado"] = "no_comercio"
                state["local"] = "Comércio"
            else:
                state["local"] = "Casa"
        else:
            if hour >= 8 and hour < 16 and not v030_weekend:
                state["estado"] = "no_trabalho"
                state["local"] = "Trabalho"
            else:
                state["local"] = "Casa"
        v030_daily_activity[npc_name] = state

func v030_update_city_life() -> void:
    v030_city_event = ""
    if v030_weather == "chuva":
        v030_city_event = "chuva"
    elif v030_weekend:
        v030_city_event = "fim_de_semana"
    elif hour >= 8 and hour < 10:
        v030_city_event = "hora_de_ponta_manha"
    elif hour >= 17 and hour < 19:
        v030_city_event = "hora_de_ponta_tarde"
    else:
        v030_city_event = "rotina_urbana"

func v030_update_materialized_population() -> void:
    # Não cria 1 milhão de objetos. Mantém apenas a população relevante materializada.
    var nearby: Array = []
    for npc_name in ["Arel Valara", "Néria Nerova", "Varel Loreno"]:
        nearby.append(npc_name)
    for npc_name in nearby:
        v030_population_materialized[npc_name] = {
            "nome": npc_name,
            "bairro": v030_current_neighborhood,
            "hora": hour,
            "dia": day,
            "ativo": true
        }

func v030_complete_tick() -> void:
    v030_initialize_neighborhood_profiles()
    v030_update_calendar_world()
    v030_run_school_and_work()
    v030_update_city_life()
    v030_update_materialized_population()
    v030_update_family_routines()
    v030_update_family_member_state()
    v030_update_dependent_states()



func v030_update_npc_routine_positions() -> void:
    # A rotina passa agora a ter representação física no mapa.
    # Não cria NPCs novos: apenas reposiciona os três NPCs já materializados.
    var targets := {
        "Arel Valara": Vector2(445, 110),
        "Néria Nerova": Vector2(445, 330),
        "Varel Loreno": Vector2(445, 110)
    }
    var home := Vector2(105, 150)
    for npc in npcs:
        var name := str(npc.get("name", ""))
        if not targets.has(name):
            continue
        var target := home
        var active := false
        if name == "Arel Valara":
            active = v030_school_day and hour >= 8 and hour < 17
        elif name == "Néria Nerova":
            active = (not v030_weekend) and hour >= 9 and hour < 19
        elif name == "Varel Loreno":
            active = (not v030_weekend) and hour >= 8 and hour < 16
        if active:
            target = targets[name]
        npc["map_position"] = target
        npc["atividade_mapa"] = "atividade" if active else "casa"
    _update_npc_markers()

func v030_update_npc_travel() -> void:
    v030_apply_travel_conditions()
    # Deslocação gradual entre casa e atividade.
    # O NPC não salta instantaneamente de um ponto para outro.
    var home := Vector2(105, 150)
    var work_place := Vector2(445, 110)
    var commerce := Vector2(445, 330)

    for npc in npcs:
        var name := str(npc.get("name", ""))
        var target := home
        var active := false

        if name == "Arel Valara":
            active = v030_school_day and hour >= 8 and hour < 17
            target = work_place
        elif name == "Néria Nerova":
            active = (not v030_weekend) and hour >= 9 and hour < 19
            target = commerce
        elif name == "Varel Loreno":
            active = (not v030_weekend) and hour >= 8 and hour < 16
            target = work_place

        var current: Vector2 = npc.get("map_position", home)
        var destination := target if active else home
        var minutes_left := int(npc.get("travel_minutes_left", 0))

        if current.distance_to(destination) > 2.0:
            if minutes_left <= 0:
                minutes_left = 15
                npc["travel_base_minutes"] = 15
                npc["travel_state"] = "a_deslocar"
                npc["travel_destination"] = destination
            var step: Vector2 = current.direction_to(destination) * min(70.0, current.distance_to(destination))
            npc["map_position"] = current + step
            npc["travel_minutes_left"] = max(0, minutes_left - 5)
        else:
            npc["map_position"] = destination
            npc["travel_minutes_left"] = 0
            npc["travel_state"] = "na_atividade" if active else "em_casa"

func v030_apply_travel_conditions() -> void:
    # Trânsito e meteorologia influenciam o tempo de deslocação.
    # Mantém a simulação leve: os valores afetam a viagem, não criam tráfego
    # individual para 1 milhão de habitantes.
    var traffic_factor := 1.0
    if typeof(traffic_state) == TYPE_DICTIONARY:
        var level := str(traffic_state.get("level", "normal"))
        match level:
            "low":
                traffic_factor = 0.85
            "busy":
                traffic_factor = 1.25
            "high":
                traffic_factor = 1.55

    var weather_factor := 1.0
    if v030_weather == "chuva":
        weather_factor = 1.30
    elif v030_weather == "vento":
        weather_factor = 1.15

    for npc in npcs:
        if str(npc.get("travel_state", "")) != "a_deslocar":
            continue
        var base_minutes := int(npc.get("travel_base_minutes", 15))
        npc["travel_minutes_left"] = max(1, int(ceil(float(base_minutes) * traffic_factor * weather_factor)))

func v030_update_npc_daily_life() -> void:
    # Vida quotidiana automática: atividade, compras/lazer e regresso a casa.
    for npc in npcs:
        var name := str(npc.get("name", ""))
        if name == "":
            continue

        var activity := "em_casa"
        var place := "Casa"

        if name == "Arel Valara":
            if v030_school_day and hour >= 8 and hour < 17:
                activity = "trabalho"
                place = "Trabalho"
            elif hour >= 17 and hour < 20:
                activity = "lazer_ou_compras"
                place = "Comércio"
        elif name == "Néria Nerova":
            if not v030_weekend and hour >= 9 and hour < 19:
                activity = "comercio"
                place = "Comércio"
            elif hour >= 19 and hour < 21:
                activity = "lazer"
                place = "Comércio"
        elif name == "Varel Loreno":
            if not v030_weekend and hour >= 8 and hour < 16:
                activity = "trabalho"
                place = "Trabalho"
            elif hour >= 16 and hour < 19:
                activity = "lazer_ou_compras"
                place = "Comércio"

        v030_npc_daily_needs[name] = {
            "atividade": activity,
            "local": place,
            "dia": day,
            "hora": hour,
            "bairro": v030_current_neighborhood
        }

        if not v030_npc_activity_log.has(name):
            v030_npc_activity_log[name] = []
        var log: Array = v030_npc_activity_log[name]
        var entry := "%02d:00 — %s" % [hour, activity]
        if log.is_empty() or str(log[-1]) != entry:
            log.append(entry)
            if log.size() > 12:
                log.pop_front()
        v030_npc_activity_log[name] = log

func v030_update_service_life() -> void:
    # Serviços da cidade usados automaticamente conforme a rotina.
    for npc in npcs:
        var name := str(npc.get("name", ""))
        if name == "":
            continue
        var uses: Array = v030_service_usage.get(name, [])
        if hour == 12 or hour == 18:
            var service := "Comércio"
            if name == "Varel Loreno" and hour == 18:
                service = "Hospital"
            var entry := "%02d:00 — %s" % [hour, service]
            if uses.is_empty() or str(uses[-1]) != entry:
                uses.append(entry)
                if uses.size() > 10:
                    uses.pop_front()
        v030_service_usage[name] = uses

func v030_update_social_life() -> void:
    # Vida social automática quando NPCs coincidem em locais e horários.
    if npcs.size() < 2:
        return
    for i in range(npcs.size()):
        for j in range(i + 1, npcs.size()):
            var a: Dictionary = npcs[i]
            var b: Dictionary = npcs[j]
            var name_a := str(a.get("name", ""))
            var name_b := str(b.get("name", ""))
            if name_a == "" or name_b == "":
                continue
            var place_a := "Casa"
            var place_b := "Casa"
            if name_a in v030_daily_activity:
                place_a = str(v030_daily_activity[name_a].get("local", "Casa"))
            if name_b in v030_daily_activity:
                place_b = str(v030_daily_activity[name_b].get("local", "Casa"))
            if place_a == place_b and place_a != "Casa":
                var key := "%02d:00 — %s e %s em %s" % [hour, name_a, name_b, place_a]
                if v030_social_events.is_empty() or str(v030_social_events[-1]) != key:
                    v030_social_events.append(key)
                    if v030_social_events.size() > 20:
                        v030_social_events.pop_front()
                v030_npc_social_state[name_a] = {"estado": "interacao_social", "com": name_b, "local": place_a}
                v030_npc_social_state[name_b] = {"estado": "interacao_social", "com": name_a, "local": place_b}

func v030_update_social_relations() -> void:
    # Relações sociais evoluem lentamente através de encontros.
    for event in v030_social_events:
        var parts := str(event).split(" — ")
        if parts.size() < 2:
            continue
        var names := parts[1].split(" em ")
        if names.size() < 2:
            continue
        var pair := names[0].split(" e ")
        if pair.size() < 2:
            continue
        var a := str(pair[0])
        var b := str(pair[1])
        var key := a + "|" + b if a < b else b + "|" + a
        var relation: Dictionary = v030_social_relations.get(key, {"valor": 0, "encontros": 0, "estado": "conhecidos"})
        relation["encontros"] = int(relation.get("encontros", 0)) + 1
        relation["valor"] = clampi(int(relation.get("valor", 0)) + 1, -100, 100)
        var value := int(relation["valor"])
        relation["estado"] = "amizade" if value >= 10 else ("conhecidos" if value >= 0 else "distantes")
        v030_social_relations[key] = relation

func v030_complete_initialize() -> void:
    if v030_entities.is_empty():
        # Registo de tipos funcionais apenas; não representa instalações colocadas no mapa.
        for entity_data in v030_runtime.get_entity_directory(true):
            var entity_id := str(entity_data.get("id", ""))
            if entity_id != "":
                v030_entities[entity_id] = {
                    "tipo": str(entity_data.get("organizational_status", "entity")),
                    "catalog_id": entity_id,
                    "placed": false,
                    "instalacoes": [],
                    "parent_entity_id": entity_data.get("parent_entity_id", null)
                }
    if v030_public_services.is_empty():
        v030_public_services = {
            "educacao":{"aberto":true},
            "saude":{"aberto":true},
            "municipal":{"aberto":true},
            "comercio":{"aberto":true}
        }
    if v030_jobs.is_empty():
        v030_jobs = {
            "Arel Valara":{"profissao":"professora","entidade":"Escola de Valepólis","horario":"08:00-17:00"},
            "Néria Nerova":{"profissao":"comerciante","entidade":"Comércio Local","horario":"09:00-19:00"},
            "Varel Loreno":{"profissao":"técnica","entidade":"Município de Valepólis","horario":"08:00-16:00"}
        }
    v030_economy = {"configured": false, "status": "por_definir", "historico": []}

func v030_complete_update() -> void:
    v030_complete_initialize()
    var rush := (hour >= 8 and hour <= 9) or (hour >= 17 and hour <= 19)
    if hour < 7 or hour >= 21:
        v030_city_traffic = {"nivel":"baixo","fator":0.9}
    elif rush:
        v030_city_traffic = {"nivel":"elevado","fator":1.35}
    else:
        v030_city_traffic = {"nivel":"normal","fator":1.0}
    for npc_name in v030_jobs.keys():
        var job: Dictionary = v030_jobs[npc_name]
        v030_ai_decisions[npc_name] = {
            "objetivo":"trabalho" if hour >= 8 and hour < 18 else "casa",
            "entidade":job.get("entidade",""),
            "hora":hour
        }

func v030_systems_initialize() -> void:
    if not v030_professions_catalog.is_empty():
        return

    v030_professions_catalog = {
        "administração": {"categoria":"serviços", "horario":[8,17]},
        "comércio": {"categoria":"comércio", "horario":[9,19]},
        "saúde": {"categoria":"saúde", "horario":[8,16]},
        "educação": {"categoria":"educação", "horario":[8,17]},
        "transportes": {"categoria":"transportes", "horario":[7,18]},
        "restauração": {"categoria":"restauração", "horario":[10,23]},
        "construção": {"categoria":"construção", "horario":[8,17]},
        "tecnologia": {"categoria":"tecnologia", "horario":[9,18]},
        "segurança": {"categoria":"segurança", "horario":[0,23]},
        "serviços municipais": {"categoria":"público", "horario":[8,17]}
    }

    # Não criar instalações físicas por defeito. A localização e a quantidade
    # de cada instalação serão definidas após a auditoria territorial conjunta.
    v030_entities_catalog = {}

    for entity_name in v030_entities_catalog.keys():
        v030_establishments[entity_name] = {
            "aberto": true,
            "trabalhadores": 0,
            "utilizadores": 0,
            "receita_dia": 0.0
        }

    for npc in npcs:
        var name := str(npc.get("name", ""))
        if name == "":
            continue
        var profession := "administração"
        if name == "Néria Nerova":
            profession = "comércio"
        elif name == "Arel Valara":
            profession = "educação"
        elif name == "Varel Loreno":
            profession = "serviços municipais"
        var pdata: Dictionary = v030_professions_catalog.get(profession, {})
        v030_npc_profiles[name] = {
            "profissao": profession,
            "salario": null,
            "emprego": null,
            "experiencia": 0,
            "humor": 50,
            "objetivo": "manter rotina"
        }
        v030_unemployment[name] = null
        v030_household_expenses[name] = {}
        v030_npc_relationships[name] = {}

    v030_service_state = {} # Capacidades por entidade/instalação a definir posteriormente.
    v030_world_metrics = {
        "populacao_referencia":1000000,
        "npc_materializados":npcs.size(),
        "empregados":null,
        "desempregados":null,
        "eventos_hoje":0,
        "receita_cidade":null,
        "atividade_social":0
    }

func v030_systems_update() -> void:
    v030_systems_initialize()

    for entity_name in v030_establishments.keys():
        var e: Dictionary = v030_establishments[entity_name]
        var entity: Dictionary = v030_entities_catalog.get(entity_name, {})
        var opening := int(hour) >= 8 and int(hour) < 20
        if entity.get("tipo","") == "segurança":
            opening = true
        if entity.get("tipo","") == "restauração":
            opening = int(hour) >= 10 and int(hour) < 23
        e["aberto"] = opening
        e["utilizadores"] = 0
        v030_establishments[entity_name] = e

    var employed := 0
    var unemployed := 0
    var employment_records := 0
    for name in v030_npc_profiles.keys():
        var profile: Dictionary = v030_npc_profiles[name]
        var profession := str(profile.get("profissao",""))
        var pdata: Dictionary = v030_professions_catalog.get(profession,{})
        var schedule: Array = pdata.get("horario",[8,17])
        var at_work := int(hour) >= int(schedule[0]) and int(hour) < int(schedule[1])
        var employment_status: Variant = profile.get("emprego", null)
        if employment_status is bool:
            employment_records += 1
            if employment_status:
                employed += 1
            else:
                unemployed += 1
            if at_work and employment_status:
                var entity_name := _v030_entity_for_profession(profession)
                if entity_name != "":
                    var e: Dictionary = v030_establishments.get(entity_name,{})
                    e["trabalhadores"] = int(e.get("trabalhadores",0)) + 1
                    v030_establishments[entity_name] = e
                profile["experiencia"] = int(profile.get("experiencia",0)) + 1
        v030_npc_profiles[name] = profile

    v030_world_metrics["empregados"] = employed if employment_records > 0 else null
    v030_world_metrics["desempregados"] = unemployed if employment_records > 0 else null
    v030_world_metrics["npc_materializados"] = v030_population_agents.size() if not v030_population_agents.is_empty() else npcs.size()
    v030_world_metrics["npc_visiveis_no_mapa"] = npcs.size()

    _v030_update_services()
    _v030_core_update_economy()
    _v030_update_social_network()
    _v030_update_city_events()

func _v030_entity_for_profession(profession: String) -> String:
    match profession:
        "comércio": return "Mercado Central"
        "saúde": return "Hospital Central"
        "educação": return "Escola Central"
        "serviços municipais": return "Câmara Municipal"
        "transportes": return "Terminal Central"
        "restauração": return "Restaurante Central"
        "tecnologia": return "Centro Tecnológico"
        "segurança": return "Base de Segurança"
        "construção": return "Obras Municipais"
        _: return "Câmara Municipal"

func _v030_update_services() -> void:
    for key in v030_service_state.keys():
        var state: Dictionary = v030_service_state[key]
        state["utilizacao"] = 0
        v030_service_state[key] = state

    for name in v030_npc_profiles.keys():
        var place := "Casa"
        if v030_daily_activity.has(name):
            place = str(v030_daily_activity[name].get("local","Casa"))
        var service := ""
        if place == "Hospital":
            service = "saude"
        elif place == "Comércio":
            service = "comercio"
        elif place == "Trabalho":
            var profession := str(v030_npc_profiles[name].get("profissao",""))
            if profession == "educação":
                service = "educacao"
            elif profession == "serviços municipais":
                service = "municipal"
            elif profession == "transportes":
                service = "transportes"
        if service != "":
            var state: Dictionary = v030_service_state.get(service,{})
            state["utilizacao"] = int(state.get("utilizacao",0)) + 1
            v030_service_state[service] = state

func _v030_core_update_economy() -> void:
    # Sem valores económicos aprovados, não calcular salários, despesas,
    # saldos nem receitas municipais. A estrutura mantém-se disponível.
    v030_family_economy.clear()
    v030_world_metrics["receita_cidade"] = null
    return

func _v030_update_social_network() -> void:
    var active := 0
    for name in v030_npc_profiles.keys():
        var state: Dictionary = v030_npc_social_state.get(name,{})
        if not state.is_empty():
            active += 1
        var relations: Dictionary = v030_npc_relationships.get(name,{})
        for other in v030_npc_profiles.keys():
            if other == name:
                continue
            if relations.has(other):
                relations[other] = clampi(int(relations[other]) + 0, -100, 100)
        v030_npc_relationships[name] = relations
    v030_world_metrics["atividade_social"] = active

func _v030_update_city_events() -> void:
    # Events are infrequent and deterministic enough for save/load.
    if int(hour) == 12 and v030_city_events.is_empty():
        v030_city_events.append({"dia":day,"hora":hour,"tipo":"rotina","texto":"Movimento normal no centro da cidade."})
        v030_city_event_history.append(v030_city_events[-1])
    elif int(hour) == 18:
        var exists := false
        for event in v030_city_events:
            if int(event.get("dia",-1)) == day and int(event.get("hora",-1)) == hour:
                exists = true
        if not exists:
            var event: Dictionary = {"dia":day,"hora":hour,"tipo":"cidade","texto":"Aumento do movimento ao fim do dia."}
            v030_city_events.append(event)
            v030_city_event_history.append(event)
    while v030_city_events.size() > 20:
        v030_city_events.pop_front()
    while v030_city_event_history.size() > 100:
        v030_city_event_history.pop_front()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST:
        _save_game_silent()

func _save_game_silent() -> void:
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify({
            "version":"0.3.0",
            "narrative_season":v030_selected_season_ui,
            "narrative_episode":v030_selected_episode_ui,
            "narrative_selection_confirmed":v030_episode_selection_confirmed,
            "narrative_completed":v030_episode_completed,
            "control_mode":v030_control_mode,"selected_branch":v030_selected_branch,"selected_subcategory":v030_selected_subcategory,"selected_profession":v030_selected_profession,"selected_cargo":v030_selected_cargo,"selected_entity":v030_selected_entity,"selected_character":v030_selected_character,"player_custom_name":v030_player_custom_name,"player_photo_path":v030_player_photo_path,"player_profile":v030_player_profile,"entity_management":v030_entity_management,"entity_action_log":v030_entity_action_log,"entity_budget":v030_entity_budget,
            "day":day,"hour":hour,"weekday":weekday,
            "year":year,"month":month,"month_day":month_day,
            "personal_economy_configured":false,"energy":energy,"hunger":hunger,"health":health,
            "place":current_place,"selected":selected_place,
            "current_neighborhood":v030_current_neighborhood,
            "event_day":event_day,
            "autonomous_event_day":autonomous_event_day,
            "autonomous_event_text":autonomous_event_text,
            "npc_event_memory":npc_event_memory,
            "npc_relations":npc_relations,
            "social_events":v030_social_events,
            "npc_social_state":v030_npc_social_state,
            "social_relations":v030_social_relations,
            "service_usage":v030_service_usage,
            "daily_activity":v030_daily_activity,
            "school_state":v030_school_state,
            "work_state":v030_work_state,
            "population_materialized":v030_population_materialized,
            "residence_moves":v030_residence_moves,
            "calendar_history":v030_calendar_history,
            "world_state":v030_world_state_v030,
            "npc_daily_needs":v030_npc_daily_needs,
            "npc_activity_log":v030_npc_activity_log,
            "neighborhood_profile":v030_neighborhood_profile,
            "jobs":v030_jobs,
            "entities":v030_entities,
            "public_services":v030_public_services,
            "economy":v030_economy,
            "player_interactions":v030_player_interactions,
            "routes":v030_routes,
            "city_traffic":v030_city_traffic,
            "ai_decisions":v030_ai_decisions,
            "professions_catalog":v030_professions_catalog,
            "entities_catalog":v030_entities_catalog,
            "establishments":v030_establishments,
            "family_economy":v030_family_economy,
            "npc_profiles":v030_npc_profiles,
            "npc_relationships":v030_npc_relationships,
            "city_events":v030_city_events,
            "city_event_history":v030_city_event_history,
            "service_state":v030_service_state,
            "player_actions":v030_player_actions,
            "unemployment":v030_unemployment,
            "household_expenses":v030_household_expenses,
            "economic_history":v030_economic_history,
            "world_metrics":v030_world_metrics,
            "player_daily_income":null,
            "auto_time_enabled":auto_time_enabled,
            "npcs":npcs
        }))
        f.close()
    v030_core_save_state()
    v030_save_state()


# =========================
# V0.3.0 — MENU DE ENTRADA E ESCOLHA DO CENTRO DA EXPERIÊNCIA
# =========================
const V030_BRANCHES := ["Administração", "Comércio", "Saúde", "Educação", "Transportes", "Restauração", "Construção", "Tecnologia", "Segurança", "Serviços Municipais", "Emergência e Resgate", "Vida Civil"]
const V030_BRANCH_PROFESSIONS := {
    "Administração": ["Técnica"], "Comércio": ["Comerciante"], "Saúde": ["Profissional de Saúde"],
    "Educação": ["Professora"], "Transportes": ["Profissional de Transportes"], "Restauração": ["Profissional de Restauração"],
    "Construção": ["Profissional de Construção"], "Tecnologia": ["Profissional de Tecnologia"], "Segurança": ["Profissional de Segurança"],
    "Serviços Municipais": ["Técnica"], "Emergência e Resgate": ["Brigadista"], "Vida Civil": ["Trabalhador/a"]
}
const V030_PROFESSION_CARGOS := {
    "Técnica": ["Técnica", "Coordenadora"], "Comerciante": ["Comerciante", "Responsável de Loja"],
    "Professora": ["Professora", "Coordenadora Pedagógica"], "Profissional de Saúde": ["Profissional", "Responsável de Serviço"],
    "Profissional de Transportes": ["Operador/a", "Responsável de Operações"], "Profissional de Restauração": ["Profissional", "Responsável de Serviço"],
    "Profissional de Construção": ["Profissional", "Encarregado/a"], "Profissional de Tecnologia": ["Técnico/a", "Responsável de Tecnologia"],
    "Profissional de Segurança": ["Agente", "Responsável de Serviço"], "Brigadista": ["Brigadista", "Chefe de Equipa"], "Trabalhador/a": ["Trabalhador/a", "Responsável"]
}

func _hide_start_menu() -> void:
    if is_instance_valid(v030_start_menu):
        v030_start_menu.queue_free()
    v030_start_menu = null
    $UI.visible = true

func _ui_style_box(bg: Color, border: Color, radius: int = 14, border_width: int = 1) -> StyleBoxFlat:
    var box := StyleBoxFlat.new()
    box.bg_color = bg
    box.border_color = border
    box.set_border_width_all(border_width)
    box.set_corner_radius_all(radius)
    box.content_margin_left = 14
    box.content_margin_right = 14
    box.content_margin_top = 12
    box.content_margin_bottom = 12
    return box

func _ui_menu_button(text_value: String, callback: Callable, accent: Color, minimum_height: float = 62.0) -> Button:
    var b := Button.new()
    b.text = text_value
    b.custom_minimum_size = Vector2(0, minimum_height)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    b.add_theme_font_size_override("font_size", 20)
    b.add_theme_color_override("font_color", Color("#eaf4ff"))
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", _ui_style_box(Color("#081725cc"), Color("#26465f"), 16, 1))
    b.add_theme_stylebox_override("hover", _ui_style_box(Color("#102a40ee"), accent, 16, 2))
    b.add_theme_stylebox_override("pressed", _ui_style_box(Color("#06111bee"), accent, 16, 2))
    b.pressed.connect(callback)
    return b

func _show_start_menu() -> void:
    if is_instance_valid(v030_start_menu):
        v030_start_menu.queue_free()
    $UI.visible = false

    # Menu principal redesenhado para telemóveis: hierarquia de jogo,
    # alvos de toque grandes e cartões empilhados em ecrãs verticais.
    var screen := get_viewport_rect().size
    var portrait := screen.y >= screen.x
    v030_start_menu = Panel.new()
    v030_start_menu.name = "MenuInicialV030"
    v030_start_menu.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    v030_start_menu.add_theme_stylebox_override("panel", _ui_style_box(Color(0.008, 0.022, 0.04, 0.12), Color("#16364e"), 0, 0))
    add_child(v030_start_menu)

    # Usa a imagem vertical da cidade como fundo estático da interface.
    # O mapa 3D continua disponível no ecrã de mapa livre.
    call_deferred("_v030_setup_ui_city_background")
    var shade := ColorRect.new()
    shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    shade.color = Color(0.008, 0.022, 0.04, 0.20)
    shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    v030_start_menu.add_child(shade)

    var root := MarginContainer.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    root.add_theme_constant_override("margin_left", 28 if portrait else 42)
    root.add_theme_constant_override("margin_right", 28 if portrait else 42)
    root.add_theme_constant_override("margin_top", 34 if portrait else 24)
    root.add_theme_constant_override("margin_bottom", 34 if portrait else 24)
    v030_start_menu.add_child(root)

    var scroll := ScrollContainer.new()
    scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    root.add_child(scroll)

    v030_start_content = VBoxContainer.new()
    v030_start_content.add_theme_constant_override("separation", 22 if portrait else 16)
    v030_start_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    scroll.add_child(v030_start_content)

    # Identidade da cidade e do jogo.
    var header := PanelContainer.new()
    header.custom_minimum_size = Vector2(0, 132 if portrait else 104)
    header.add_theme_stylebox_override("panel", _ui_style_box(Color("#061522e8"), Color("#49b8ec"), 24, 2))
    v030_start_content.add_child(header)
    var header_row := HBoxContainer.new()
    header_row.add_theme_constant_override("separation", 18)
    header_row.add_theme_constant_override("separation", 18)
    header.add_child(header_row)

    var logo := Label.new()
    logo.text = "VALEPÓLIS"
    logo.custom_minimum_size = Vector2(0, 0)
    logo.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    logo.add_theme_font_size_override("font_size", 34 if portrait else 30)
    logo.add_theme_color_override("font_color", Color("#f5d36b"))
    header_row.add_child(logo)

    var header_info := VBoxContainer.new()
    header_info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    header_info.size_flags_vertical = Control.SIZE_SHRINK_CENTER
    header_info.add_theme_constant_override("separation", 6)
    header_row.add_child(header_info)
    var title := Label.new()
    title.text = "QUANDO TOCA A SIRENE"
    title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    title.add_theme_font_size_override("font_size", 24 if portrait else 22)
    title.add_theme_color_override("font_color", Color("#eef7ff"))
    header_info.add_child(title)
    var subtitle_entry := Label.new()
    subtitle_entry.text = "CIDADE VIVA  •  V0.3.0"
    subtitle_entry.add_theme_font_size_override("font_size", 15 if portrait else 13)
    subtitle_entry.add_theme_color_override("font_color", Color("#a9d7ee"))
    header_info.add_child(subtitle_entry)

    var welcome := Label.new()
    welcome.text = "A CIDADE É TUA. A HISTÓRIA COMEÇA AGORA."
    welcome.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    welcome.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    welcome.add_theme_font_size_override("font_size", 24 if portrait else 22)
    welcome.add_theme_color_override("font_color", Color("#ffe08a"))
    v030_start_content.add_child(welcome)

    var intro := Label.new()
    intro.text = "Escolhe como queres viver e transformar Valepólis."
    if v030_episode_selection_confirmed:
        intro.text = "EPISÓDIO SELECIONADO • T%02d · E%02d — escolhe agora como entrar na cidade." % [v030_selected_season_ui, v030_selected_episode_ui]
    intro.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    intro.add_theme_font_size_override("font_size", 18 if portrait else 16)
    intro.add_theme_color_override("font_color", Color("#edf6ff"))
    v030_start_content.add_child(intro)

    # Modos principais: cartões grandes no formato vertical; três colunas só em paisagem.
    var modes := GridContainer.new()
    modes.columns = 1 if portrait else 3
    modes.add_theme_constant_override("h_separation", 16)
    modes.add_theme_constant_override("v_separation", 16)
    modes.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v030_start_content.add_child(modes)

    var card_height := 172 if portrait else 210
    var character_card := _ui_menu_button("👤  JOGAR COMO PERSONAGEM\n\nCria a tua vida\nRelações • trabalho • evolução", Callable(_menu_choose_character_mode), Color("#29a9ff"), card_height)
    var entity_card := _ui_menu_button("🚨  GERIR ENTIDADES\n\nCoordena equipas e operações\nVeículos • serviços • ocorrências", Callable(_menu_choose_entity_mode), Color("#ffb84d"), card_height)
    var map_card := _ui_menu_button("🌆  EXPLORAR A CIDADE\n\nEntra no mapa livre\n25 bairros • costa • rio • montanhas", Callable(_menu_free_map), Color("#35d58a"), card_height)
    for card in [character_card, entity_card, map_card]:
        card.add_theme_font_size_override("font_size", 23 if portrait else 21)
        card.add_theme_stylebox_override("normal", _ui_style_box(Color("#061725e8"), Color("#8bc9e8"), 22, 2))
        card.add_theme_stylebox_override("hover", _ui_style_box(Color("#102e45f5"), Color("#ffe08a"), 22, 3))
        card.add_theme_stylebox_override("pressed", _ui_style_box(Color("#07111df5"), Color("#ffe08a"), 22, 3))
        modes.add_child(card)

    var divider := HSeparator.new()
    v030_start_content.add_child(divider)
    var actions_title := Label.new()
    actions_title.text = "PARTIDA"
    actions_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    actions_title.add_theme_font_size_override("font_size", 18 if portrait else 16)
    actions_title.add_theme_color_override("font_color", Color("#d5e8f5"))
    v030_start_content.add_child(actions_title)

    var secondary := GridContainer.new()
    secondary.columns = 2 if portrait else 5
    secondary.add_theme_constant_override("h_separation", 12)
    secondary.add_theme_constant_override("v_separation", 12)
    secondary.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v030_start_content.add_child(secondary)
    var action_height := 88 if portrait else 76
    var new_game := _ui_menu_button("▶  NOVO JOGO", Callable(_confirm_new_game), Color("#39b7ff"), action_height)
    var load_game := _ui_menu_button("↻  CARREGAR", Callable(_continue_saved_game), Color("#39b7ff"), action_height)
    var seasons := _ui_menu_button("▤  TEMPORADAS\nE EPISÓDIOS", Callable(_open_season_episode_ui), Color("#f0c96a"), action_height)
    var settings := _ui_menu_button("⚙  DEFINIÇÕES", Callable(_menu_settings), Color("#9db4c8"), action_height)
    var credits := _ui_menu_button("★  CRÉDITOS", Callable(_credits), Color("#9db4c8"), action_height)
    var exit_game := _ui_menu_button("✕  SAIR", Callable(_menu_exit), Color("#ff7777"), action_height)
    for action in [new_game, load_game, seasons, settings, credits, exit_game]:
        action.add_theme_font_size_override("font_size", 20 if portrait else 17)
        secondary.add_child(action)

    if not FileAccess.file_exists(SAVE_PATH):
        var note := Label.new()
        note.text = "Ainda não existe uma partida guardada. Escolhe NOVO JOGO para começar."
        note.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        note.add_theme_font_size_override("font_size", 15 if portrait else 12)
        note.add_theme_color_override("font_color", Color("#d0e2ee"))
        v030_start_content.add_child(note)

    var footer := Label.new()
    footer.text = "UMA CIDADE VIVA • UM MILHÃO DE HISTÓRIAS • AS TUAS ESCOLHAS MUDAM TUDO"
    footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    footer.add_theme_font_size_override("font_size", 13 if portrait else 11)
    footer.add_theme_color_override("font_color", Color("#c0d5e2"))
    v030_start_content.add_child(footer)

func _v030_load_season_catalog() -> Dictionary:
    if not v030_season_catalog.is_empty():
        return v030_season_catalog
    var path := "res://data/episodes_200.json"
    if not FileAccess.file_exists(path):
        status.text = "Catálogo narrativo em falta: data/episodes_200.json"
        return {}
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        status.text = "Não foi possível abrir o catálogo de episódios."
        return {}
    var parsed = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(parsed) != TYPE_DICTIONARY or typeof(parsed.get("episodes", null)) != TYPE_ARRAY:
        status.text = "Catálogo de episódios inválido."
        return {}
    v030_season_catalog = parsed
    return v030_season_catalog

func _open_seasons_from_game() -> void:
    # Reutiliza o ecrã de catálogo existente, mas torna-o acessível durante o jogo.
    _show_start_menu()
    call_deferred("_open_season_episode_ui")

func _open_season_episode_ui() -> void:
    var catalog := _v030_load_season_catalog()
    if catalog.is_empty():
        _menu_clear("TEMPORADAS E EPISÓDIOS", "Não foi possível carregar o catálogo. Verifica data/episodes_200.json.")
        _menu_button("← VOLTAR AO MENU", _show_start_menu)
        return
    var current := 1
    var current_episode := 1
    if is_instance_valid(v030_runtime):
        current = int(v030_runtime.progression.get("season", v030_selected_season_ui))
        current_episode = int(v030_runtime.progression.get("episode", v030_selected_episode_ui))
    v030_selected_season_ui = clampi(v030_selected_season_ui if v030_episode_selection_confirmed else current, 1, 20)
    v030_selected_episode_ui = clampi(v030_selected_episode_ui if v030_episode_selection_confirmed else current_episode, 1, 10)
    _v030_render_season_picker()

func _v030_render_season_picker() -> void:
    var catalog := _v030_load_season_catalog()
    if catalog.is_empty():
        return
    _menu_clear("TEMPORADAS E EPISÓDIOS", "200 episódios · 20 temporadas · 10 episódios por temporada")
    var screen := get_viewport_rect().size
    var portrait := screen.y >= screen.x
    var summary := Label.new()
    summary.text = "PROGRESSO DA HISTÓRIA  •  %d/200 episódios catalogados" % (v030_episode_completed.size())
    summary.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    summary.add_theme_font_size_override("font_size", 16)
    summary.add_theme_color_override("font_color", Color("#a9d7ee"))
    v030_start_content.add_child(summary)

    var season_title := ""
    var episodes: Array = catalog.get("episodes", [])
    for item in episodes:
        if int(item.get("season", 0)) == v030_selected_season_ui:
            season_title = str(item.get("season_title", "Temporada %02d" % v030_selected_season_ui))
            break
    var section := Label.new()
    section.text = "ESCOLHE A TEMPORADA"
    section.add_theme_font_size_override("font_size", 20)
    section.add_theme_color_override("font_color", Color("#ffe08a"))
    v030_start_content.add_child(section)

    var season_grid := GridContainer.new()
    season_grid.columns = 2 if portrait else 4
    season_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    season_grid.add_theme_constant_override("h_separation", 10)
    season_grid.add_theme_constant_override("v_separation", 10)
    v030_start_content.add_child(season_grid)
    for season_number in range(1, 21):
        var title_for_season := "Temporada %02d" % season_number
        for item in episodes:
            if int(item.get("season", 0)) == season_number:
                title_for_season = str(item.get("season_title", title_for_season))
                break
        var season_button := Button.new()
        season_button.text = "%02d  %s" % [season_number, title_for_season]
        season_button.custom_minimum_size = Vector2(0, 88 if portrait else 82)
        season_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        season_button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        season_button.add_theme_font_size_override("font_size", 13 if portrait else 14)
        season_button.add_theme_color_override("font_color", Color("#f0f6ff"))
        var selected := season_number == v030_selected_season_ui
        season_button.add_theme_stylebox_override("normal", _ui_style_box(Color("#15364a") if selected else Color("#081725"), Color("#f0c96a") if selected else Color("#31536a"), 14, 2 if selected else 1))
        season_button.add_theme_stylebox_override("hover", _ui_style_box(Color("#1a4058"), Color("#ffe08a"), 14, 2))
        season_button.pressed.connect(_v030_select_season_ui.bind(season_number))
        season_grid.add_child(season_button)

    var chosen_title := Label.new()
    chosen_title.text = "TEMPORADA %02d  •  %s" % [v030_selected_season_ui, season_title]
    chosen_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    chosen_title.add_theme_font_size_override("font_size", 21)
    chosen_title.add_theme_color_override("font_color", Color("#ffe08a"))
    v030_start_content.add_child(chosen_title)
    var episodes_grid := VBoxContainer.new()
    episodes_grid.add_theme_constant_override("separation", 8)
    episodes_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v030_start_content.add_child(episodes_grid)
    for item in episodes:
        if int(item.get("season", 0)) != v030_selected_season_ui:
            continue
        var episode_number := int(item.get("episode", 0))
        var episode_key := "%02d-%02d" % [v030_selected_season_ui, episode_number]
        var is_completed := v030_episode_completed.has(episode_key)
        var is_selected := episode_number == v030_selected_episode_ui
        var episode_button := Button.new()
        var state_label := "CONCLUÍDO" if is_completed else ("SELECIONADO" if is_selected else "DISPONÍVEL NO CATÁLOGO")
        episode_button.text = "%s  ·  EPISÓDIO %02d\n%s\n%s" % ["✓" if is_completed else ("▶" if is_selected else "○"), episode_number, str(item.get("title", "Episódio %02d" % episode_number)), state_label]
        episode_button.custom_minimum_size = Vector2(0, 100 if portrait else 86)
        episode_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        episode_button.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        episode_button.add_theme_font_size_override("font_size", 14 if portrait else 16)
        episode_button.add_theme_color_override("font_color", Color("#f0f6ff"))
        episode_button.add_theme_stylebox_override("normal", _ui_style_box(Color("#15364a") if is_selected else Color("#081725"), Color("#f0c96a") if is_selected else Color("#31536a"), 14, 2 if is_selected else 1))
        episode_button.add_theme_stylebox_override("hover", _ui_style_box(Color("#1a4058"), Color("#ffe08a"), 14, 2))
        episode_button.pressed.connect(_v030_select_episode_ui.bind(episode_number))
        episodes_grid.add_child(episode_button)

    var selected_episode: Dictionary = {}
    for item in episodes:
        if int(item.get("season", 0)) == v030_selected_season_ui and int(item.get("episode", 0)) == v030_selected_episode_ui:
            selected_episode = item
            break
    var details := PanelContainer.new()
    details.add_theme_stylebox_override("panel", _ui_style_box(Color("#061522"), Color("#49b8ec"), 18, 2))
    v030_start_content.add_child(details)
    var detail_column := VBoxContainer.new()
    detail_column.add_theme_constant_override("separation", 8)
    details.add_child(detail_column)
    var detail_heading := Label.new()
    detail_heading.text = "EPISÓDIO SELECIONADO"
    detail_heading.add_theme_font_size_override("font_size", 15)
    detail_heading.add_theme_color_override("font_color", Color("#a9d7ee"))
    detail_column.add_child(detail_heading)
    var detail_name := Label.new()
    detail_name.text = str(selected_episode.get("title", "Episódio não encontrado"))
    detail_name.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    detail_name.add_theme_font_size_override("font_size", 23)
    detail_name.add_theme_color_override("font_color", Color("#ffffff"))
    detail_column.add_child(detail_name)
    var detail_note := Label.new()
    detail_note.text = "A seleção define o ponto narrativo de referência. Os objetivos e a conclusão só serão registados quando existirem condições de missão implementadas; não são inventados pelo catálogo."
    detail_note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    detail_note.add_theme_font_size_override("font_size", 14)
    detail_note.add_theme_color_override("font_color", Color("#b9cad6"))
    detail_column.add_child(detail_note)

    _menu_button("✓  CONFIRMAR EPISÓDIO E VOLTAR", _v030_confirm_episode_selection)
    _menu_button("←  VOLTAR AO MENU PRINCIPAL", _show_start_menu)

func _v030_select_season_ui(season_number: int) -> void:
    v030_selected_season_ui = clampi(season_number, 1, 20)
    v030_selected_episode_ui = 1
    _v030_render_season_picker()

func _v030_select_episode_ui(episode_number: int) -> void:
    v030_selected_episode_ui = clampi(episode_number, 1, 10)
    _v030_render_season_picker()

func _v030_confirm_episode_selection() -> void:
    v030_episode_selection_confirmed = true
    if is_instance_valid(v030_runtime):
        v030_runtime.sync_progression(v030_selected_season_ui, v030_selected_episode_ui)
    _save_game_silent()
    _show_start_menu()

func _menu_free_map() -> void:
    v030_control_mode = "mapa"
    v030_selected_character = ""
    v030_selected_entity = ""
    _hide_start_menu()
    status.text = "MAPA LIVRE • Explora Valepólis sem gestão operacional ativa."
    _refresh()

func _menu_settings() -> void:
    _v030_open_section("Opcoes")

func _menu_exit() -> void:
    get_tree().quit()

func _menu_clear(title_text: String, subtitle_text: String) -> void:
    if not is_instance_valid(v030_start_content): return
    for child in v030_start_content.get_children(): child.queue_free()
    var title := Label.new(); title.text = title_text; title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; title.add_theme_font_size_override("font_size", 34); title.add_theme_color_override("font_color", Color("#ffe08a")); v030_start_content.add_child(title)
    var sub := Label.new(); sub.text = subtitle_text; sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; sub.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; sub.add_theme_font_size_override("font_size", 20); sub.add_theme_color_override("font_color", Color("#b9cad6")); v030_start_content.add_child(sub)

func _menu_button(text_value: String, callback: Callable) -> void:
    var b := Button.new()
    b.text = text_value
    b.custom_minimum_size = Vector2(0, 76)
    b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    b.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    b.add_theme_font_size_override("font_size", 20)
    b.add_theme_color_override("font_color", Color("#f1f7ff"))
    b.add_theme_color_override("font_hover_color", Color.WHITE)
    b.add_theme_stylebox_override("normal", _ui_style_box(Color("#071827eF"), Color("#31536a"), 14, 1))
    b.add_theme_stylebox_override("hover", _ui_style_box(Color("#12344aF5"), Color("#ffe08a"), 14, 2))
    b.add_theme_stylebox_override("pressed", _ui_style_box(Color("#0b2638F5"), Color("#ffe08a"), 14, 2))
    b.pressed.connect(callback)
    v030_start_content.add_child(b)

func _menu_home() -> void:
    _menu_clear("VALEPÓLIS — CIDADE VIVA", "Escolha como pretende iniciar a experiência.")
    if FileAccess.file_exists(SAVE_PATH):
        _menu_button("▶ CONTINUAR", _continue_saved_game)
    _menu_button("🆕 NOVO JOGO", _confirm_new_game)
    _menu_button("👤 PERSONAGEM", _menu_choose_character_mode)
    _menu_button("🏢 ENTIDADE", _menu_choose_entity_mode)

func _menu_choose_character_mode() -> void:
    v030_control_mode = "personagem"
    var branches: Array = _v030_catalog_ramos() if v030_catalog_loaded else V030_BRANCHES
    var catalog_info := "Catálogo mestre ativo" if v030_catalog_loaded else "Catálogo base"
    _menu_clear("ESCOLHER PERSONAGEM", "Escolha o ramo. • %s" % catalog_info)
    for branch in branches: _menu_button(str(branch), _menu_choose_character_branch.bind(str(branch)))
    _menu_button("← VOLTAR", _menu_home)

func _menu_choose_entity_mode() -> void:
    v030_control_mode = "entidade"
    var branches: Array = _v030_catalog_ramos() if v030_catalog_loaded else V030_BRANCHES
    var catalog_info := "Catálogo mestre ativo" if v030_catalog_loaded else "Catálogo base"
    _menu_clear("GERIR ENTIDADE", "Escolha o ramo e depois a entidade.\nNão é escolhida nenhuma personagem. • %s" % catalog_info)
    for branch in branches: _menu_button(str(branch), _menu_choose_entity_branch.bind(str(branch)))
    _menu_button("← VOLTAR", _menu_home)

func _menu_choose_character_branch(branch: String) -> void:
    v030_selected_branch = branch
    v030_selected_subcategory = ""
    v030_selected_profession = ""
    v030_selected_cargo = ""
    var subs: Array = _v030_catalog_subcategories(branch) if v030_catalog_loaded else []
    _menu_clear("ESCOLHER SUBCATEGORIA", "Ramo: %s" % branch)
    if subs.is_empty():
        _menu_button("Sem subcategorias disponíveis", _menu_choose_character_mode)
    else:
        for sub in subs:
            _menu_button(str(sub), _menu_choose_character_subcategory.bind(str(sub)))
    _menu_button("← VOLTAR", _menu_choose_character_mode)

func _menu_choose_character_subcategory(subcategory: String) -> void:
    v030_selected_subcategory = subcategory
    v030_selected_profession = ""
    v030_selected_cargo = ""
    var professions: Array = _v030_catalog_professions(v030_selected_branch, subcategory) if v030_catalog_loaded else V030_BRANCH_PROFESSIONS.get(v030_selected_branch, [])
    _menu_clear("ESCOLHER PROFISSÃO", "%s • %s" % [v030_selected_branch, subcategory])
    if professions.is_empty():
        _menu_button("Sem profissões disponíveis", _menu_choose_character_subcategory.bind(subcategory))
    else:
        for profession in professions:
            _menu_button(str(profession), _menu_choose_character_profession.bind(str(profession)))
    _menu_button("← VOLTAR", _menu_choose_character_branch.bind(v030_selected_branch))

func _menu_choose_character_profession(profession: String) -> void:
    v030_selected_profession = profession
    v030_selected_cargo = ""
    _menu_clear("ESCOLHER CARGO", "%s • %s • %s" % [v030_selected_branch, v030_selected_subcategory, profession])
    var cargos := _v030_generic_cargos(profession)
    for cargo in cargos:
        _menu_button(str(cargo), _menu_choose_character_cargo.bind(str(cargo)))
    _menu_button("← VOLTAR", _menu_choose_character_subcategory.bind(v030_selected_subcategory))

func _menu_choose_character_cargo(cargo: String) -> void:
    v030_selected_cargo = cargo
    _menu_clear("PERSONALIZAR PERSONAGEM?", "%s • %s • %s • %s" % [v030_selected_branch, v030_selected_subcategory, v030_selected_profession, cargo])
    var info := Label.new()
    info.text = "Pode personalizar a personagem ou deixar o jogo gerar automaticamente uma personagem única."
    info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    v030_start_content.add_child(info)
    _menu_button("✏️ PERSONALIZAR", _menu_customize_character)
    _menu_button("🎲 GERAR PERSONAGEM AUTOMATICAMENTE", _menu_generate_character)
    _menu_button("← VOLTAR", _menu_choose_character_profession.bind(v030_selected_profession))

func _menu_generate_character() -> void:
    v030_player_custom_name = ""
    v030_selected_character = ""
    v030_selected_entity = ""
    v030_player_photo_path = ""
    _v030_build_generated_character()
    _finish_character_selection()

func _menu_customize_character() -> void:
    _menu_clear("PERSONALIZAR PERSONAGEM", "%s • %s • %s • %s" % [v030_selected_branch, v030_selected_subcategory, v030_selected_profession, v030_selected_cargo])
    # A personagem 3D é construída pelo próprio Godot/Android em tempo de execução.
    # Geração nativa Godot: não requer modeladores externos nem ficheiros de modelo.
    var preview_seed_text := "%s|%s|%s|%s" % [v030_selected_character, v030_selected_profession, v030_selected_branch, v030_selected_cargo]
    var preview_seed: int = abs(preview_seed_text.hash())
    v030_start_content.add_child(_v030_create_runtime_character_preview(preview_seed))
    var preview_caption := Label.new()
    preview_caption.text = "MODELO 3D GERADO NA APP • APARÊNCIA ESTÁVEL POR PERSONAGEM"
    preview_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    preview_caption.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    preview_caption.add_theme_font_size_override("font_size", 12)
    preview_caption.add_theme_color_override("font_color", Color("#a9c7d8"))
    v030_start_content.add_child(preview_caption)
    var name_label := Label.new()
    name_label.text = "NOME DA PERSONAGEM"
    v030_start_content.add_child(name_label)
    var name_edit := LineEdit.new()
    name_edit.text = v030_player_custom_name
    name_edit.placeholder_text = "Nome da personagem"
    name_edit.custom_minimum_size = Vector2(0, 52)
    name_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v030_start_content.add_child(name_edit)
    var photo_info := Label.new()
    photo_info.text = "FOTOGRAFIA (opcional)"
    v030_start_content.add_child(photo_info)
    v030_player_photo_preview = TextureRect.new()
    v030_player_photo_preview.custom_minimum_size = Vector2(0, 180)
    v030_player_photo_preview.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    v030_player_photo_preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    v030_player_photo_preview.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
    if v030_player_photo_path != "" and FileAccess.file_exists(v030_player_photo_path):
        var image := Image.load_from_file(v030_player_photo_path)
        if image:
            v030_player_photo_preview.texture = ImageTexture.create_from_image(image)
    v030_start_content.add_child(v030_player_photo_preview)
    _menu_button("📷 CARREGAR FOTOGRAFIA", func(): _open_player_photo_dialog(name_edit))
    _menu_button("CONFIRMAR PERSONAGEM", func(): _finish_character_customization(name_edit))
    _menu_button("← VOLTAR", _menu_choose_character_cargo.bind(v030_selected_cargo))

func _v030_create_runtime_map_preview() -> Control:
    var container := SubViewportContainer.new()
    container.name = "Runtime3DMapPreview"
    container.custom_minimum_size = Vector2(96, 88)
    container.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
    container.stretch = true
    var viewport := SubViewport.new()
    viewport.name = "MapViewport"
    viewport.size = Vector2i(384, 288)
    viewport.msaa_3d = Viewport.MSAA_2X
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    viewport.transparent_bg = false
    container.add_child(viewport)
    var city_scene := load("res://City3D.tscn") as PackedScene
    if city_scene != null:
        var city_instance := city_scene.instantiate()
        city_instance.name = "GeneratedCityMapPreview"
        viewport.add_child(city_instance)
    else:
        push_warning("City3D.tscn indisponível para a pré-visualização do mapa.")
    return container

func _v030_create_runtime_character_preview(seed_value: int, compact: bool = false, entity_role: String = "Civil") -> Control:
    var container := SubViewportContainer.new()
    container.name = "Runtime3DCharacterPreview"
    # Pré-visualização vertical: proporção próxima de um retrato de corpo inteiro.
    # Evita o recorte que ocorria quando o modelo de ~2 m era colocado num viewport 220x96.
    container.custom_minimum_size = Vector2(180, 240) if compact else Vector2(0, 380)
    container.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN if compact else Control.SIZE_EXPAND_FILL
    container.size_flags_vertical = Control.SIZE_EXPAND_FILL if not compact else Control.SIZE_SHRINK_CENTER
    container.stretch = true
    container.mouse_filter = Control.MOUSE_FILTER_IGNORE

    var viewport := SubViewport.new()
    viewport.name = "CharacterViewport"
    viewport.size = Vector2i(540, 750) if compact else Vector2i(720, 1080)
    viewport.msaa_3d = Viewport.MSAA_2X
    viewport.transparent_bg = false
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    # Um World3D próprio evita que o SubViewport fique só com a cor de fundo
    # em alguns dispositivos Android quando a pré-visualização é criada por código.
    viewport.world_3d = World3D.new()
    container.add_child(viewport)

    var world := Node3D.new()
    world.name = "CharacterWorld"
    viewport.add_child(world)
    var environment := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#172634")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#c4d5e3")
    env.ambient_light_energy = 0.65
    environment.environment = env
    world.add_child(environment)

    var camera := Camera3D.new()
    camera.name = "CharacterPreviewCamera"
    camera.position = Vector3(0.0, 1.12, 5.1 if compact else 4.6)
    camera.fov = 34.0 if not compact else 38.0
    camera.near = 0.05
    camera.far = 100.0
    world.add_child(camera)
    # SubViewport não deve depender da seleção automática da câmara: sem current,
    # o viewport pode mostrar apenas a cor de fundo (o retângulo azul observado).
    camera.current = true
    # A pré-visualização é construída antes de o SubViewportContainer entrar na árvore.
    # Reativar a câmara depois da entrada na SceneTree evita o viewport ficar apenas
    # com a cor de fundo em alguns dispositivos Android/Godot.
    camera.look_at_from_position(camera.position, Vector3(0.0, 0.96, 0.0), Vector3.UP)
    call_deferred("_v030_activate_character_preview_camera", camera, viewport)

    var key_light := DirectionalLight3D.new()
    key_light.rotation_degrees = Vector3(-25.0, -25.0, 0.0)
    key_light.light_energy = 1.35
    world.add_child(key_light)
    var fill_light := OmniLight3D.new()
    fill_light.position = Vector3(-2.0, 2.0, 2.0)
    fill_light.light_energy = 0.55
    fill_light.omni_range = 8.0
    world.add_child(fill_light)

    var rng := RandomNumberGenerator.new()
    rng.seed = seed_value
    var skin_palette: Array[Color] = [Color("#f0c5a2"), Color("#d9a47d"), Color("#b87955"), Color("#8c563e"), Color("#603b2e")]
    var hair_palette: Array[Color] = [Color("#211a18"), Color("#493026"), Color("#79502f"), Color("#b27c43"), Color("#d7c39c")]
    var outfit_palette: Array[Color] = [Color("#24577a"), Color("#315b4c"), Color("#4d536f"), Color("#6b4052"), Color("#a05a32"), Color("#d4d9df")]
    var skin: Color = skin_palette[rng.randi_range(0, skin_palette.size() - 1)]
    var hair: Color = hair_palette[rng.randi_range(0, hair_palette.size() - 1)]
    var outfit: Color = outfit_palette[rng.randi_range(0, outfit_palette.size() - 1)]
    var role_key := entity_role.to_lower()
    if "brigada" in role_key: outfit = Color("#263c4a")
    elif "sue" in role_key: outfit = Color("#f1f3f4")
    elif "tnur" in role_key: outfit = Color("#f2f2f2")
    elif "policia" in role_key or "polícia" in role_key or "agente de polícia" in role_key: outfit = Color("#152d50")
    var body_scale := rng.randf_range(0.94, 1.06)
    var head_scale := rng.randf_range(0.92, 1.08)
    var hair_style := rng.randi_range(0, 2)

    # Personagem low-poly estilizada construída com malhas 3D nativas.
    _v030_preview_add_capsule(world, "Torso", Vector3(0, 1.02, 0), Vector3(0.38 * body_scale, 0.62, 0.23), outfit)
    _v030_preview_add_capsule(world, "Neck", Vector3(0, 1.48, 0), Vector3(0.105, 0.18, 0.105), skin)
    _v030_preview_add_sphere(world, "Head", Vector3(0, 1.72, 0), Vector3(0.255 * head_scale, 0.31 * head_scale, 0.235 * head_scale), skin)
    _v030_preview_add_capsule(world, "LeftArm", Vector3(-0.43 * body_scale, 1.02, 0), Vector3(0.105, 0.40, 0.105), outfit, Vector3(0, 0, -8))
    _v030_preview_add_capsule(world, "RightArm", Vector3(0.43 * body_scale, 1.02, 0), Vector3(0.105, 0.40, 0.105), outfit, Vector3(0, 0, 8))
    _v030_preview_add_capsule(world, "LeftLeg", Vector3(-0.15, 0.43, 0), Vector3(0.13, 0.48, 0.13), Color("#26323d"))
    _v030_preview_add_capsule(world, "RightLeg", Vector3(0.15, 0.43, 0), Vector3(0.13, 0.48, 0.13), Color("#26323d"))
    _v030_preview_add_sphere(world, "LeftHand", Vector3(-0.45, 0.73, 0), Vector3(0.095, 0.11, 0.095), skin)
    _v030_preview_add_sphere(world, "RightHand", Vector3(0.45, 0.73, 0), Vector3(0.095, 0.11, 0.095), skin)
    _v030_preview_add_sphere(world, "LeftEye", Vector3(-0.09, 1.76, 0.211), Vector3(0.027, 0.035, 0.018), Color("#17202a"))
    _v030_preview_add_sphere(world, "RightEye", Vector3(0.09, 1.76, 0.211), Vector3(0.027, 0.035, 0.018), Color("#17202a"))
    # Detalhes faciais e de vestuário gerados proceduralmente.
    _v030_preview_add_sphere(world, "Nose", Vector3(0.0, 1.705, 0.238), Vector3(0.035, 0.052, 0.035), skin)
    _v030_preview_add_capsule(world, "EyebrowL", Vector3(-0.09, 1.815, 0.213), Vector3(0.045, 0.012, 0.012), hair)
    _v030_preview_add_capsule(world, "EyebrowR", Vector3(0.09, 1.815, 0.213), Vector3(0.045, 0.012, 0.012), hair)
    _v030_preview_add_capsule(world, "Mouth", Vector3(0.0, 1.645, 0.229), Vector3(0.045, 0.009, 0.009), Color("#8b5148"))
    # Calçado separado para evitar que as pernas terminem em pontas arredondadas.
    _v030_preview_add_box(world, "LeftShoe", Vector3(-0.15, 0.09, 0.075), Vector3(0.18, 0.12, 0.34), Color("#18232c"))
    _v030_preview_add_box(world, "RightShoe", Vector3(0.15, 0.09, 0.075), Vector3(0.18, 0.12, 0.34), Color("#18232c"))
    # Gola e fecho da camisola/colete.
    _v030_preview_add_box(world, "UniformCollar", Vector3(0.0, 1.355, 0.19), Vector3(0.19, 0.10, 0.055), Color("#d7e0e5") if "sue" in role_key else Color("#1b2933"))
    _v030_preview_add_box(world, "UniformZip", Vector3(0.0, 1.05, 0.224), Vector3(0.018, 0.42, 0.018), Color("#d3dce2"))
    if "brigada" in role_key or "tnur" in role_key or "sue" in role_key:
        var reflective := Color("#e7c94e") if "brigada" in role_key else Color("#dce7eb")
        _v030_preview_add_box(world, "ReflectiveBand", Vector3(0.0, 0.98, 0.226), Vector3(0.58, 0.055, 0.025), reflective)
    if hair_style == 0:
        _v030_preview_add_sphere(world, "Hair", Vector3(0, 1.91, 0.005), Vector3(0.26 * head_scale, 0.14, 0.24 * head_scale), hair)
    elif hair_style == 1:
        _v030_preview_add_capsule(world, "Hair", Vector3(0, 1.88, 0.02), Vector3(0.24 * head_scale, 0.15, 0.22 * head_scale), hair)
        _v030_preview_add_sphere(world, "HairBack", Vector3(0, 1.68, 0.13), Vector3(0.23, 0.22, 0.12), hair)
    else:
        _v030_preview_add_sphere(world, "Hair", Vector3(0, 1.90, 0.0), Vector3(0.27 * head_scale, 0.11, 0.24 * head_scale), hair)
        _v030_preview_add_sphere(world, "HairSide", Vector3(0.20, 1.77, 0.01), Vector3(0.07, 0.16, 0.13), hair)

    var floor := MeshInstance3D.new()
    var floor_mesh := CylinderMesh.new()
    floor_mesh.top_radius = 0.72
    floor_mesh.bottom_radius = 0.72
    floor_mesh.height = 0.06
    floor.mesh = floor_mesh
    floor.position = Vector3(0, 0.02, 0)
    var floor_mat := StandardMaterial3D.new()
    floor_mat.albedo_color = Color("#2c4657")
    floor_mat.roughness = 0.9
    floor.material_override = floor_mat
    world.add_child(floor)
    return container

func _v030_activate_character_preview_camera(camera: Camera3D, viewport: SubViewport) -> void:
    if not is_instance_valid(camera) or not is_instance_valid(viewport):
        return
    if not camera.is_inside_tree() or not viewport.is_inside_tree():
        return
    viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
    camera.current = true
    camera.make_current()
    camera.force_update_transform()

func _v030_preview_add_box(parent: Node3D, node_name: String, pos: Vector3, dimensions: Vector3, color_value: Color) -> void:
    var instance := MeshInstance3D.new()
    instance.name = node_name
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    instance.mesh = mesh
    instance.position = pos
    var material := StandardMaterial3D.new()
    material.albedo_color = color_value
    material.roughness = 0.8
    instance.material_override = material
    parent.add_child(instance)

func _v030_preview_add_capsule(parent: Node3D, node_name: String, pos: Vector3, dimensions: Vector3, color_value: Color, rotation_deg: Vector3 = Vector3.ZERO) -> void:
    var instance := MeshInstance3D.new()
    instance.name = node_name
    var mesh := CapsuleMesh.new()
    mesh.radius = dimensions.x
    mesh.height = max(dimensions.y * 2.0, dimensions.x * 2.0)
    instance.mesh = mesh
    instance.position = pos
    instance.rotation_degrees = rotation_deg
    instance.scale = Vector3(1.0, 1.0, max(0.55, dimensions.z / max(0.001, dimensions.x)))
    var material := StandardMaterial3D.new()
    material.albedo_color = color_value
    material.roughness = 0.82
    instance.material_override = material
    parent.add_child(instance)

func _v030_preview_add_sphere(parent: Node3D, node_name: String, pos: Vector3, dimensions: Vector3, color_value: Color) -> void:
    var instance := MeshInstance3D.new()
    instance.name = node_name
    var mesh := SphereMesh.new()
    mesh.radius = 1.0
    mesh.height = 2.0
    instance.mesh = mesh
    instance.position = pos
    instance.scale = dimensions
    var material := StandardMaterial3D.new()
    material.albedo_color = color_value
    material.roughness = 0.78
    instance.material_override = material
    parent.add_child(instance)

func _menu_confirm_character(character_name: String) -> void:
    v030_selected_character = character_name
    v030_player_custom_name = character_name
    v030_selected_entity = ""
    _menu_customize_character()

func _finish_character_customization(name_edit: LineEdit) -> void:
    var custom_name := name_edit.text.strip_edges()
    if custom_name == "":
        custom_name = _v030_generated_name()
    v030_player_custom_name = custom_name
    v030_selected_character = custom_name
    v030_selected_entity = ""
    _v030_build_player_profile()
    _finish_character_selection()

func _v030_generated_name() -> String:
    var seed_value: int = abs(int(("%s|%s|%s|%s|%s" % [v030_selected_branch, v030_selected_subcategory, v030_selected_profession, v030_selected_cargo, Time.get_ticks_msec()]).hash()))
    var used_names: Dictionary = {}
    for npc in npcs:
        var existing_name := str(npc.get("name", ""))
        if not existing_name.is_empty():
            used_names[existing_name] = true
    for attempt in range(100):
        var candidate := str(V030_CHARACTER_GENERATOR.generate_name(seed_value + attempt, used_names))
        if not used_names.has(candidate):
            return candidate
    return "Habitante-%06d" % seed_value

func _v030_build_generated_character() -> void:
    v030_player_custom_name = _v030_generated_name()
    v030_selected_character = v030_player_custom_name
    _v030_build_player_profile()

func _finish_character_selection() -> void:
    v030_control_mode = "personagem"
    $UI.visible = true
    if is_instance_valid(v030_start_menu):
        v030_start_menu.queue_free()
    status.text = "A controlar %s • %s • %s • %s." % [v030_player_custom_name, v030_selected_branch, v030_selected_profession, v030_selected_cargo]
    _save_game_silent()
    _refresh()

func _menu_choose_entity_branch(branch: String) -> void:
    v030_selected_branch = branch
    var subs: Array = _v030_catalog_subcategories(branch) if v030_catalog_loaded else []
    _menu_clear("ESCOLHER SUBCATEGORIA", "Ramo: %s" % branch)
    for sub in subs: _menu_button(str(sub), _menu_choose_entity_subcategory.bind(str(sub)))
    _menu_button("← VOLTAR", _menu_choose_entity_mode)

func _menu_choose_entity_subcategory(subcategory: String) -> void:
    var entities: Array = _v030_catalog_entities(v030_selected_branch, subcategory) if v030_catalog_loaded else []
    var intro := "%s • %s\nEscolha a entidade que pretende gerir." % [v030_selected_branch, subcategory]
    if subcategory.to_lower() == "tnur":
        intro += "\nTNUR é uma unidade interna da BRIGADA; não possui entidade nem base independente."
    _menu_clear("ESCOLHER ENTIDADE", intro)
    for entity_name in entities: _menu_button(str(entity_name), _menu_confirm_entity.bind(str(entity_name)))
    if entities.is_empty():
        var info := Label.new()
        if subcategory.to_lower() == "tnur":
            info.text = "As funções TNUR são geridas através da BRIGADA e das suas bases anfitriãs. Esta subcategoria não cria uma entidade selecionável independente."
        else:
            info.text = "Não existe uma entidade compatível nesta subcategoria."
        info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
        v030_start_content.add_child(info)
    _menu_button("← VOLTAR", _menu_choose_entity_branch.bind(v030_selected_branch))

func _menu_confirm_entity(entity_name: String) -> void:
    v030_selected_entity = entity_name; v030_selected_character = ""; v030_selected_profession = ""; v030_selected_cargo = ""; v030_player_custom_name = ""
    $UI.visible = true; if is_instance_valid(v030_start_menu): v030_start_menu.queue_free()
    status.text = "A GERIR ENTIDADE: %s • Ramo: %s." % [v030_selected_entity, v030_selected_branch]
    _save_game_silent(); _refresh()


# ================================================================
# V0.3.0 — MUNDO VIVO EXPANDIDO
# ================================================================
# Esta camada expande os sistemas existentes sem alterar o fluxo oficial
# PERSONAGEM/ENTIDADE da V0.3.0. Tudo é simulado de forma seletiva: a
# população de referência continua a ser 1.000.000, sem criar 1M de nós.

const V030_STATE_PATH := "user://valepolis_v030_state.json"

# --- V0.3.0 PERSONAGENS / RELACOES / ROTINAS ---
var v030_character_profiles: Dictionary = {}
var v030_relationships: Dictionary = {}
var v030_routine_state: Dictionary = {}
var v030_social_day_marker: int = -1

const V030_PERSONALITIES := ["Calmo", "Sociável", "Prudente", "Curioso", "Determinado", "Empático", "Organizado", "Resiliente"]
const V030_GOALS := ["Estabilidade", "Progressão profissional", "Aprendizagem", "Família", "Independência", "Serviço à comunidade", "Reconhecimento"]
var v030_character_progress: Dictionary = {}
var v030_npc_life: Dictionary = {}
var v030_job_progression: Dictionary = {}
var v030_neighborhood_state: Dictionary = {}
var v030_event_history: Array = []
var v030_activity_history: Array = []
var v030_day_marker: int = -1
var v030_hour_marker: int = -1

func v030_initialize_character_system() -> void:
    # A V0.3.0 continua a ser a baseline. A V0.3.0 apenas acrescenta estado
    # social e rotina, sem substituir os dados existentes.
    if v030_character_profiles.is_empty():
        for npc in npcs:
            var name: String = str(npc.get("name", "NPC"))
            if name == "":
                continue
            var seed: int = abs(name.hash())
            v030_character_profiles[name] = {
                "nome": name,
                "personalidade": V030_PERSONALITIES[seed % V030_PERSONALITIES.size()],
                "objetivo": V030_GOALS[(seed / V030_PERSONALITIES.size()) % V030_GOALS.size()],
                "profissao": str(npc.get("profession", "Atividade")),
                "entidade": str(npc.get("entity", "")),
                "bairro": v030_current_neighborhood,
                "autonomia": true
            }
    if v030_selected_character != "" and not v030_character_profiles.has(v030_selected_character):
        var seed_player: int = abs(v030_selected_character.hash())
        v030_character_profiles[v030_selected_character] = {
            "nome": v030_selected_character,
            "personalidade": V030_PERSONALITIES[seed_player % V030_PERSONALITIES.size()],
            "objetivo": V030_GOALS[(seed_player / V030_PERSONALITIES.size()) % V030_GOALS.size()],
            "profissao": v030_selected_profession,
            "entidade": v030_selected_entity,
            "bairro": v030_current_neighborhood,
            "autonomia": false
        }
    for npc in npcs:
        var name: String = str(npc.get("name", "NPC"))
        if name == "":
            continue
        if not v030_routine_state.has(name):
            v030_routine_state[name] = {
                "atividade": "casa",
                "destino": "Casa",
                "ultima_mudanca": "%02d:00" % hour,
                "dia": day
            }
    if v030_social_day_marker < 0:
        v030_social_day_marker = day

func v030_relationship_key(a: String, b: String) -> String:
    return a + "|" + b

func v030_get_relationship(a: String, b: String) -> int:
    if a == b:
        return 100
    return int(v030_relationships.get(v030_relationship_key(a, b), 0))

func v030_set_relationship(a: String, b: String, value: int) -> void:
    var v: int = clampi(value, -100, 100)
    v030_relationships[v030_relationship_key(a, b)] = v
    v030_relationships[v030_relationship_key(b, a)] = v

func v030_routine_for_npc(npc: Dictionary) -> Dictionary:
    var work_start: int = int(npc.get("work_start", 8))
    var work_end: int = int(npc.get("work_end", 17))
    var break_start: int = int(npc.get("break_start", 12))
    var break_end: int = int(npc.get("break_end", 13))
    var weekend: bool = weekday >= 6
    if hour < 7 or hour >= 22:
        return {"atividade":"casa", "destino":"Casa"}
    if weekend:
        if hour < 11:
            return {"atividade":"casa", "destino":"Casa"}
        return {"atividade":"lazer", "destino":"Comércio"}
    if hour >= work_start and hour < work_end:
        if hour >= break_start and hour < break_end:
            return {"atividade":"pausa", "destino":str(npc.get("workplace", "Trabalho"))}
        return {"atividade":"trabalho", "destino":str(npc.get("workplace", "Trabalho"))}
    if hour >= 18 and hour < 21:
        return {"atividade":"lazer", "destino":"Comércio"}
    return {"atividade":"casa", "destino":"Casa"}

func v030_update_character_system() -> void:
    v030_initialize_character_system()
    for npc in npcs:
        var name: String = str(npc.get("name", "NPC"))
        if name == "":
            continue
        var routine: Dictionary = v030_routine_for_npc(npc)
        var previous: Dictionary = v030_routine_state.get(name, {})
        var state: Dictionary = {
            "atividade": str(routine.get("atividade", "casa")),
            "destino": str(routine.get("destino", "Casa")),
            "ultima_mudanca": str(previous.get("ultima_mudanca", "%02d:00" % hour)),
            "dia": day
        }
        if str(previous.get("destino", "")) != state["destino"] or str(previous.get("atividade", "")) != state["atividade"]:
            state["ultima_mudanca"] = "%02d:00" % hour
            npc["next_destination"] = state["destino"]
            npc["activity"] = state["atividade"]
        v030_routine_state[name] = state
        var profile: Dictionary = v030_character_profiles.get(name, {})
        profile["bairro"] = _v030_neighborhood_for_place(str(npc.get("place", "Casa")))
        v030_character_profiles[name] = profile

    # Relações entre NPCs evoluem lentamente quando partilham o mesmo local.
    if v030_social_day_marker != day:
        v030_social_day_marker = day
        for i in range(npcs.size()):
            for j in range(i + 1, npcs.size()):
                var a: String = str(npcs[i].get("name", ""))
                var b: String = str(npcs[j].get("name", ""))
                if a == "" or b == "":
                    continue
                if str(npcs[i].get("place", "")) == str(npcs[j].get("place", "")):
                    var current: int = v030_get_relationship(a, b)
                    v030_set_relationship(a, b, current + 1)

    # A relação jogador-NPC continua compatível com a V0.3.0.
    if v030_selected_character != "":
        for npc in npcs:
            var npc_name: String = str(npc.get("name", ""))
            if npc_name == "":
                continue
            v030_set_relationship(v030_selected_character, npc_name, int(npc.get("relationship", 0)))

func v030_get_character_profile(name: String) -> Dictionary:
    return v030_character_profiles.get(name, {}).duplicate(true)


# ================================================================
# V0.3.0 — COMPLETAÇÃO: OCORRÊNCIAS + VEÍCULOS + EQUIPAS + ECONOMIA
# ================================================================
var v030_incident_history: Array = []
var v030_vehicles: Dictionary = {}
var v030_entity_staff: Dictionary = {}
var v030_vehicle_counter: int = 0

const V030_VEHICLE_TYPES := ["Ligeiro", "Serviço", "Emergência", "Transporte"]

func v030_initialize_world_systems() -> void:
    # Sem frota ou efetivos iniciais inventados. Estes registos são adicionados
    # apenas quando forem configurados com o utilizador.
    if v030_vehicles.is_empty():
        v030_vehicles = {}
    if v030_entity_staff.is_empty():
        v030_entity_staff = {}

func v030_spawn_incident() -> void:
    if not v030_incidents.is_empty():
        return
    var types := ["Avaria urbana", "Acidente de trânsito", "Pessoa a precisar de assistência", "Interrupção de serviço"]
    var places := ["Nexora", "Hospital", "Comércio", "Trabalho"]
    var idx: int = abs(day * 31 + hour) % types.size()
    var incident: Dictionary = {
        "id": "INC-%04d" % (v030_incident_history.size() + 1),
        "dia": day, "hora": hour, "tipo": types[idx], "local": places[idx],
        "estado": "aberto", "gravidade": 1 + (idx % 3)
    }
    v030_incidents.append(incident)
    v030_incident_history.append(incident.duplicate(true))
    v030_record_event("%s em %s" % [incident["tipo"], incident["local"]], "ocorrencia")

func v030_core_update_incidents() -> void:
    # A cidade gera ocorrências ocasionais, sem spam e sem bloquear a simulação.
    if hour >= 9 and hour <= 21 and v030_incidents.is_empty() and abs(day * 13 + hour) % 29 == 0:
        v030_spawn_incident()
    if not v030_incidents.is_empty() and hour % 6 == 0:
        var incident: Dictionary = v030_incidents[0]
        incident["estado"] = "resolvido"
        v030_incident_history.append(incident.duplicate(true))
        v030_incidents.clear()

func v030_assign_vehicle(vehicle_id: String, destination: String) -> bool:
    if not v030_vehicles.has(vehicle_id):
        return false
    var vehicle: Dictionary = v030_vehicles[vehicle_id]
    if str(vehicle.get("estado", "")) != "disponível":
        return false
    vehicle["estado"] = "em serviço"
    vehicle["destino"] = destination
    v030_vehicles[vehicle_id] = vehicle
    return true

func v030_release_vehicle(vehicle_id: String, location: String = "Nexora") -> void:
    if not v030_vehicles.has(vehicle_id):
        return
    var vehicle: Dictionary = v030_vehicles[vehicle_id]
    vehicle["estado"] = "disponível"
    vehicle["local"] = location
    vehicle.erase("destino")
    vehicle["integridade"] = max(0, int(vehicle.get("integridade", 100)) - 1)
    v030_vehicles[vehicle_id] = vehicle

func v030_update_completion_systems() -> void:
    v030_initialize_world_systems()
    v030_core_update_incidents()
    # Inventário e economia de cada entidade só evoluem depois de configurados.


func v030_integrated_system_tick() -> void:
    # V0.3.0: ponto único de integração dos sistemas. Não duplica dados dos painéis.
    # A personagem, entidade, veículo, ocorrência e economia consultam o mesmo estado.
    v030_initialize_world_systems()

    # 1) As relações laborais das personagens não são convertidas automaticamente
    # em efetivos de entidades. O quadro de pessoal fica por configurar.
    # 2) Não são gerados consumíveis, instalações, orçamentos ou saldos por defeito.

    # 3) Ocorrências só podem reservar viaturas que tenham sido registadas explicitamente.
    if not v030_incidents.is_empty():
        var active_incident: Dictionary = v030_incidents[0]
        if not active_incident.has("veiculo"):
            for vehicle_id in v030_vehicles.keys():
                var vehicle: Dictionary = v030_vehicles[vehicle_id]
                if str(vehicle.get("estado", "")) == "disponível":
                    if v030_assign_vehicle(str(vehicle_id), str(active_incident.get("local", "Nexora"))):
                        active_incident["veiculo"] = str(vehicle_id)
                        break
        if str(active_incident.get("estado", "")) == "resolvido" and active_incident.has("veiculo"):
            v030_release_vehicle(str(active_incident["veiculo"]), str(active_incident.get("local", "Nexora")))

    # 4) Economia: atividade da cidade e operações alteram consumo/receita de forma limitada.
    var operations_total: int = 0
    var staff_total: int = 0
    for entity_name in v030_entity_management.keys():
        var entity_state: Dictionary = v030_entity_management[entity_name]
        operations_total += int(entity_state.get("operacoes", 0))
        staff_total += v030_entity_staff.get(str(entity_name), []).size()
    var activity: float = clampf(45.0 + float(operations_total % 40) + float(staff_total % 15), 0.0, 100.0)
    v030_economy["atividade"] = activity
    v030_economy["consumo"] = clampf(activity * 0.8, 0.0, 100.0)
    v030_city_state["atividade"] = activity
    v030_city_state["pressao_servicos"] = clampf(float(v030_incidents.size()) * 12.0, 0.0, 100.0)
    v030_city_state["transito"] = "intenso" if activity >= 75.0 else ("moderado" if activity >= 55.0 else "normal")

    # 5) Guardar alterações importantes sem esperar pelo botão manual.
    if hour % 3 == 0:
        _save_game_silent()

func v030_initialize() -> void:
    if v030_initialized:
        return
    v030_initialized = true
    v030_character_progress = {
        "nivel": 1,
        "experiencia": 0,
        "competencias": {},
        "formacao": [],
        "objetivos": ["construir uma vida em Valepólis"],
        "historico": [],
        "humor": 70,
        "energia": int(energy),
        "saude": int(health)
    }
    v030_npc_life = {}
    for npc in npcs:
        var n := str(npc.get("name", ""))
        if n == "":
            continue
        v030_npc_life[n] = {
            "humor": 50 + (abs(n.hash()) % 31),
            "energia": 80,
            "objetivo": "rotina",
            "atividade": "casa",
            "lazer": "passeio",
            "memorias": [],
            "competencias": {},
            "experiencia": 0,
            "formacao": []
        }
    v030_job_progression = {}
    for n in v030_npc_profiles.keys():
        v030_job_progression[str(n)] = {"nivel": 1, "experiencia": 0, "promocoes": 0, "formacao": []}
    # O registo de gestão começa vazio. O catálogo funcional não implica
    # instalações físicas nem define quantidades de recursos.
    v030_entity_management = {}
    v030_economy = {
        "configured": false,
        "status": "por_definir",
        "historico": []
    }
    v030_city_state = {
        "atividade": 50.0,
        "transito": "normal",
        "clima": "estavel",
        "pressao_servicos": 0.0,
        "seguranca": 90.0,
        "comercio": 50.0,
        "vida_social": 20.0,
        "evento_atual": ""
    }
    for b in V030_NEIGHBORHOODS:
        v030_neighborhood_state[b] = {
            "atividade": 40 + (abs(b.hash()) % 41),
            "comercio": 40 + (abs((b + "c").hash()) % 51),
            "seguranca": 70 + (abs((b + "s").hash()) % 31),
            "vida_social": 20 + (abs((b + "l").hash()) % 61),
            "populacao_referencia": v030_get_population(b)
        }
    v030_load_state()
    v030_initialize_character_system()

func v030_update_world() -> void:
    v030_initialize()
    if v030_day_marker != day:
        v030_day_marker = day
        v030_daily_update()
    if v030_hour_marker != hour:
        v030_hour_marker = hour
        v030_hourly_update()
    v030_update_character()
    v030_update_npcs()
    v030_update_character_system()
    v030_core_update_entities()
    v030_core_update_economy()
    v030_update_city()
    v030_update_completion_systems()
    v030_integrated_system_tick()

func v030_daily_update() -> void:
    var weekend := weekday >= 6
    for n in v030_job_progression.keys():
        var jp: Dictionary = v030_job_progression[n]
        if not weekend:
            jp["experiencia"] = int(jp.get("experiencia", 0)) + 1
            if int(jp["experiencia"]) >= 20:
                jp["nivel"] = min(10, int(jp.get("nivel", 1)) + 1)
                jp["experiencia"] = 0
                jp["promocoes"] = int(jp.get("promocoes", 0)) + 1
        v030_job_progression[n] = jp
    for n in v030_npc_life.keys():
        var life: Dictionary = v030_npc_life[n]
        life["energia"] = 85
        life["humor"] = clampi(int(life.get("humor", 50)) + (3 if weekend else 0), 0, 100)
        if weekend:
            life["atividade"] = "lazer"
        v030_npc_life[n] = life
    v030_record_event("novo dia", "rotina")

func v030_hourly_update() -> void:
    var h := int(hour)
    var weekend := weekday >= 6
    for n in v030_npc_life.keys():
        var life: Dictionary = v030_npc_life[n]
        if h < 7 or h >= 22:
            life["atividade"] = "casa"
        elif weekend:
            life["atividade"] = "lazer"
        elif h >= 8 and h < 18:
            life["atividade"] = "trabalho"
        elif h >= 18 and h < 21:
            life["atividade"] = "comercio_ou_lazer"
        else:
            life["atividade"] = "casa"
        life["energia"] = clampi(int(life.get("energia", 80)) - (2 if h >= 8 and h < 18 else -1), 0, 100)
        v030_npc_life[n] = life

func v030_update_character() -> void:
    var p := v030_character_progress
    p["energia"] = int(energy)
    p["saude"] = int(health)
    p["humor"] = clampi(int(p.get("humor", 70)) + (1 if hour >= 18 and hour < 22 else 0), 0, 100)
    if v030_control_mode == "personagem":
        p["experiencia"] = int(p.get("experiencia", 0)) + 1
        if int(p["experiencia"]) >= 50:
            p["nivel"] = min(20, int(p.get("nivel", 1)) + 1)
            p["experiencia"] = 0
            v030_record_event("evolução de personagem: nível %d" % int(p["nivel"]), "personagem")
        var prof := str(v030_selected_profession)
        if prof != "":
            var skills: Dictionary = p.get("competencias", {})
            skills[prof] = int(skills.get(prof, 0)) + 1
            p["competencias"] = skills
    v030_character_progress = p

func v030_update_npcs() -> void:
    for n in v030_npc_life.keys():
        var life: Dictionary = v030_npc_life[n]
        var profile: Dictionary = v030_npc_profiles.get(n, {})
        var prof := str(profile.get("profissao", ""))
        var jp: Dictionary = v030_job_progression.get(n, {"nivel":1,"experiencia":0})
        life["experiencia"] = int(jp.get("experiencia", 0))
        life["competencias"] = {prof: int(jp.get("nivel", 1))} if prof != "" else {}
        if life["atividade"] == "lazer":
            life["humor"] = clampi(int(life.get("humor", 50)) + 1, 0, 100)
        elif life["atividade"] == "trabalho":
            life["humor"] = clampi(int(life.get("humor", 50)) - 1, 0, 100)
        if abs(n.hash() + day + hour) % 17 == 0:
            life["objetivo"] = "socializar"
            v030_record_event("%s encontrou alguém durante a rotina" % n, "social")
        v030_npc_life[n] = life

func v030_core_update_entities() -> void:
    for entity_name in v030_entity_management.keys():
        var m: Dictionary = v030_entity_management[entity_name]
        var entity: Dictionary = v030_entities_catalog.get(entity_name, {})
        var tipo := str(entity.get("tipo", ""))
        var open := int(hour) >= 8 and int(hour) < 20
        if tipo == "segurança":
            open = true
        if tipo == "restauração":
            open = int(hour) >= 10 and int(hour) < 23
        if open:
            m["operacoes"] = int(m.get("operacoes", 0)) + 1
            m["reputacao"] = clampi(int(m.get("reputacao", 50)) + (1 if hour in [12, 18] else 0), 0, 100)
        var report: Array = m.get("relatorios", [])
        report.append({"dia":day,"hora":hour,"operacoes":m["operacoes"],"aberta":open})
        if report.size() > 20:
            report.pop_front()
        m["relatorios"] = report
        v030_entity_management[entity_name] = m

func v030_core_update_economy() -> void:
    # A economia só será calculada quando existir uma configuração aprovada.
    v030_economy = {"configured": false, "status": "por_definir", "historico": []}
    return

func v030_update_city() -> void:
    var traffic := str(v030_city_traffic.get("nivel", "normal"))
    v030_city_state["transito"] = traffic
    v030_city_state["comercio"] = float(v030_economy.get("consumo", 50.0))
    v030_city_state["atividade"] = float(v030_economy.get("atividade", 50.0))
    v030_city_state["vida_social"] = clampf(20.0 + (35.0 if hour >= 17 and hour < 22 else 5.0), 0.0, 100.0)
    v030_city_state["pressao_servicos"] = clampf(float(hour >= 8 and hour < 20) * 35.0 + float(traffic == "elevado") * 25.0, 0.0, 100.0)
    v030_city_state["seguranca"] = 90.0
    if abs(day * 31 + hour) % 47 == 0:
        var events: Array[String] = ["festival de bairro", "avaria num serviço", "aumento do movimento comercial", "atividade comunitária", "obra municipal"]
        var ev: String = events[(day + hour) % events.size()]
        v030_city_state["evento_atual"] = ev
        v030_record_event(ev, "cidade")
    elif hour not in [8, 12, 18]:
        v030_city_state["evento_atual"] = ""
    for b in v030_neighborhood_state.keys():
        var ns: Dictionary = v030_neighborhood_state[b]
        var activity := float(ns.get("atividade", 50.0))
        activity += 0.5 if b == v030_current_neighborhood else -0.1
        ns["atividade"] = clampf(activity, 0.0, 100.0)
        ns["vida_social"] = clampf(float(ns.get("vida_social", 50.0)) + (1.0 if hour >= 18 and hour < 22 else -0.2), 0.0, 100.0)
        v030_neighborhood_state[b] = ns

func v030_record_event(description: String, category: String) -> void:
    v030_event_history.append({"dia":day,"hora":hour,"categoria":category,"descricao":description})
    if v030_event_history.size() > 200:
        v030_event_history.pop_front()

func v030_core_save_state() -> void:
    var f := FileAccess.open(V030_CORE_STATE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify({
            "version":"0.3.0",
            "character":v030_character_progress,
            "npc_life":v030_npc_life,
            "job_progression":v030_job_progression,
            "entity_management":v030_entity_management,
            "economy":v030_economy,
            "city_state":v030_city_state,
            "neighborhood_state":v030_neighborhood_state,
            "event_history":v030_event_history,
            "activity_history":v030_activity_history,
            "v030_character_profiles":v030_character_profiles,
            "v030_relationships":v030_relationships,
            "v030_routine_state":v030_routine_state,
            "v030_incidents":v030_incidents,
            "v030_incident_history":v030_incident_history,
            "v030_vehicles":v030_vehicles,
            "v030_entity_staff":v030_entity_staff,
            "v030_city_state":v030_city_state,
            "v030_character_ai":v030_character_ai,
            "v030_relationship_events":v030_relationship_events,
            "v030_traffic_routes":v030_traffic_routes,
            "v030_entity_metrics":v030_entity_metrics,
            "v030_economy":v030_economy,
            "v030_news":v030_news
        }))
        f.close()

func v030_load_state() -> void:
    if not FileAccess.file_exists(V030_CORE_STATE_PATH):
        return
    var f := FileAccess.open(V030_CORE_STATE_PATH, FileAccess.READ)
    if f == null:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    v030_character_progress = parsed.get("character", v030_character_progress)
    v030_npc_life = parsed.get("npc_life", v030_npc_life)
    v030_job_progression = parsed.get("job_progression", v030_job_progression)
    # Ignora antigos valores de demonstração de recursos de entidades; serão
    # reconstruídos apenas depois de acordados efetivos, frota e economia.
    v030_entity_management = {}
    v030_vehicles = {}
    v030_vehicle_state = {}
    v030_entity_staff = {}
    v030_teams = {}
    v030_inventories = {}
    v030_services_state = {}
    v030_entity_schedules = {}
    v030_entity_metrics = {}
    v030_finance = {"configured": false, "balance": null, "income": null, "expenses": null, "contracts": [], "loans": [], "history": []}
    v030_economy = parsed.get("economy", v030_economy)
    v030_city_state = parsed.get("city_state", v030_city_state)
    v030_neighborhood_state = parsed.get("neighborhood_state", v030_neighborhood_state)
    v030_event_history = parsed.get("event_history", v030_event_history)
    v030_activity_history = parsed.get("activity_history", v030_activity_history)


# =========================
# V0.3.0 — SISTEMAS INTEGRADOS
# =========================
func v030_initialize_advanced_world() -> void:
    if v030_initialized:
        return
    v030_initialized = true
    for npc in npcs:
        var n: String = str(npc.get("name", "NPC"))
        v030_character_ai[n] = {
            "priority": "rotina",
            "mood": 60.0,
            "stress": 10.0,
            "needs": {"social": 50.0, "rest": 50.0, "work": 50.0},
            "last_decision": "inicialização",
            "decision_count": 0
        }
    v030_entity_metrics = {} # Sem capacidades, efetivos ou cargas presumidos.
    v030_traffic_routes = {
        "Nexora-Rivéria": {"load": 20.0, "incidents": 0},
        "Nexora-Altavira": {"load": 18.0, "incidents": 0},
        "Nexora-Lúmora": {"load": 24.0, "incidents": 0},
        "Nexora-Ventúria": {"load": 22.0, "incidents": 0}
    }
    v030_add_news("A cidade entrou num novo ciclo de atividade.", "cidade")
    v030_initialize_all_systems()
    # Recupera estado persistente de simulação sem inventar recursos físicos.
    v030_load_integrated_state()

func v030_integrated_tick() -> void:
    v030_simulation_ticks += 1
    if is_instance_valid(v030_runtime):
        v030_runtime.tick(60)
    _v030_sync_canonical_runtime()
    v030_update_advanced_world()
    v030_update_personal_ai()
    if v030_simulation_ticks % 3 == 0:
        v030_update_character_ai()
        v030_update_relationship_dynamics()
        v030_update_traffic()
        v030_update_entities()
        v030_update_economy()
        v030_update_incidents()
        v030_generate_news()
        v030_update_all_systems()
    if v030_simulation_ticks % 6 == 0:
        v030_save_state()

func v030_update_advanced_world() -> void:
    if not v030_initialized:
        v030_initialize_advanced_world()
    var peak: float = 20.0 if hour < 7 or hour >= 22 else 65.0
    if hour >= 8 and hour < 10 or hour >= 17 and hour < 19:
        peak += 20.0
    v030_city_state["traffic"] = clampf(peak + float(v030_city_state.get("traffic", 20.0)) * 0.15, 0.0, 100.0)
    v030_city_state["commerce"] = clampf(45.0 + (30.0 if hour >= 9 and hour < 21 else 8.0), 0.0, 100.0)
    v030_city_state["public_services"] = clampf(78.0 - float(v030_incidents.size()) * 2.0, 20.0, 100.0)
    v030_city_state["satisfaction"] = clampf(
        55.0 + float(v030_city_state["public_services"]) * 0.25 - float(v030_city_state["traffic"]) * 0.12,
        0.0, 100.0
    )

func v030_update_personal_ai() -> void:
    # A IA assume tarefas repetitivas, mas nunca substitui decisões relevantes
    # do jogador. Uma ação manual recente cria uma janela de não-interferência.
    if not bool(v030_personal_ai.get("enabled", true)):
        return
    if v030_simulation_ticks < int(v030_personal_ai.get("manual_override_tick", 0)):
        return

    var action := "nenhuma"
    var reason := ""

    # Necessidades básicas têm prioridade sobre rotinas secundárias.
    if hunger >= 85:
        hunger = max(0, hunger - 45)
        action = "comer"
        reason = "necessidade básica; custo ainda por definir"
    elif energy <= 15:
        energy = min(100, energy + 35)
        action = "descansar"
        reason = "energia baixa"
    elif health < 35:
        health = min(100, health + 5)
        action = "recuperar-se"
        reason = "recuperação abstrata; cuidados e custos por definir"
    elif hour >= 22 or hour < 6:
        energy = min(100, energy + 18)
        hunger = min(100, hunger + 4)
        action = "dormir"
        reason = "rotina noturna"
    elif current_place == "Casa" and hour >= 7 and hour < 9 and v030_selected_profession != "":
        current_place = "Trabalho"
        selected_place = "Trabalho"
        action = "deslocar-se para o trabalho"
        reason = "rotina profissional"
    elif current_place == "Trabalho" and hour >= 18:
        current_place = "Casa"
        selected_place = "Casa"
        action = "regressar a casa"
        reason = "fim da rotina profissional"

    if action != "nenhuma":
        v030_personal_ai["last_action"] = action
        v030_personal_ai["last_reason"] = reason
        v030_personal_ai["action_count"] = int(v030_personal_ai.get("action_count", 0)) + 1
    else:
        v030_personal_ai["last_action"] = "gestão autónoma"
        v030_personal_ai["last_reason"] = "rotina monitorizada pela IA"

func v030_update_character_ai() -> void:
    for npc in npcs:
        var n: String = str(npc.get("name", "NPC"))
        var ai: Dictionary = v030_character_ai.get(n, {})
        var destination: String = str(npc.get("next_destination", "Casa"))
        var place: String = str(npc.get("place", "Casa"))
        var mood: float = float(ai.get("mood", 60.0))
        var stress: float = float(ai.get("stress", 10.0))
        if place == destination:
            stress = maxf(0.0, stress - 2.0)
            mood = minf(100.0, mood + 1.0)
        else:
            stress = minf(100.0, stress + 0.5)
        var priority := "rotina"
        if stress > 70.0:
            priority = "descanso"
        elif float(ai.get("needs", {}).get("social", 50.0)) < 25.0:
            priority = "social"
        ai["priority"] = priority
        ai["mood"] = mood
        ai["stress"] = stress
        ai["last_decision"] = priority
        ai["decision_count"] = int(ai.get("decision_count", 0)) + 1
        v030_character_ai[n] = ai

func v030_update_relationship_dynamics() -> void:
    for i in range(npcs.size()):
        for j in range(i + 1, npcs.size()):
            var a: Dictionary = npcs[i]
            var b: Dictionary = npcs[j]
            if str(a.get("place", "")) != str(b.get("place", "")):
                continue
            var an: String = str(a.get("name", ""))
            var bn: String = str(b.get("name", ""))
            var key: String = "%s|%s" % [an, bn]
            var rel: float = float(npc_relations.get(key, 0.0))
            rel = clampf(rel + 1.0, -100.0, 100.0)
            npc_relations[key] = rel
            v030_relationship_events.append({"day": day, "hour": hour, "a": an, "b": bn, "value": rel})
    if v030_relationship_events.size() > 300:
        v030_relationship_events.pop_front()

func v030_update_traffic() -> void:
    var total: float = 0.0
    for route in v030_traffic_routes.values():
        total += float(route.get("load", 0.0))
    var average: float = total / maxf(1.0, float(v030_traffic_routes.size()))
    v030_city_state["traffic"] = clampf((float(v030_city_state["traffic"]) + average) * 0.5, 0.0, 100.0)
    for key in v030_traffic_routes.keys():
        var r: Dictionary = v030_traffic_routes[key]
        var peak := (hour >= 7 and hour <= 9) or (hour >= 17 and hour <= 19)
        var night := hour >= 23 or hour <= 5
        var delta_load := 4.0 if peak else (-4.0 if night else -1.0)
        r["load"] = clampf(float(r.get("load", 20.0)) + delta_load, 0.0, 100.0)
        v030_traffic_routes[key] = r
    # O relógio da simulação também controla o trânsito visível no mapa 3D.
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    if city != null and city.has_method("set_traffic_hour"):
        city.call("set_traffic_hour", hour, _is_weekend())

func v030_update_entities() -> void:
    for entity_name in v030_entity_metrics.keys():
        var metric: Dictionary = v030_entity_metrics[entity_name]
        var staff: int = 0
        for n in v030_entity_staff.keys():
            if str(v030_entity_staff[n].get("entity", "")) == str(entity_name):
                staff += 1
        metric["staff"] = staff
        metric["open"] = not _is_weekend() or str(entity_name) in ["Hospital Municipal", "Município de Valepólis"]
        metric["load"] = clampf(float(metric.get("load", 20.0)) + float(staff) * 0.5, 0.0, 100.0)
        metric["productivity"] = clampf(55.0 + float(staff) * 5.0 - float(metric["load"]) * 0.15, 0.0, 100.0)
        v030_entity_metrics[entity_name] = metric

func v030_update_economy() -> void:
    # Não calcular preços, salários, oferta ou procura antes da aprovação
    # das regras económicas. A simulação urbana usa indicadores não financeiros.
    v030_economy = {"configured": false, "status": "por_definir", "history": []}
    return

func v030_update_incidents() -> void:
    # Incidentes são raros, determinísticos e limitados para manter a cidade jogável.
    if abs(day * 31 + hour + v030_simulation_ticks) % 41 != 0:
        return
    var kinds: Array[String] = ["avaria urbana", "pequeno acidente", "ocorrência comercial", "assistência a cidadão"]
    var kind: String = kinds[(day + hour + v030_simulation_ticks) % kinds.size()]
    v030_incidents.append({
        "id": "INC-%04d" % v030_simulation_ticks,
        "type": kind,
        "neighborhood": v030_current_neighborhood,
        "priority": 1 if kind == "assistência a cidadão" else 2,
        "status": "aberta",
        "day": day,
        "hour": hour
    })
    if v030_incidents.size() > 20:
        v030_incidents.pop_front()

func v030_generate_news() -> void:
    if v030_incidents.is_empty():
        return
    var incident: Dictionary = v030_incidents.back()
    v030_add_news(
        "%s em %s." % [str(incident.get("type", "Ocorrência")), str(incident.get("neighborhood", "Valepólis"))],
        "ocorrência"
    )

func v030_add_news(text: String, category: String) -> void:
    var item := {"day": day, "hour": hour, "category": category, "text": text}
    v030_news.append(item)
    v030_city_state["news"] = v030_news
    if v030_news.size() > 100:
        v030_news.pop_front()


# =========================
# V0.3.0 — SISTEMAS COMPLETOS DA CIDADE VIVA
# A IA cria missões; o jogador gere a resposta. Estes sistemas são estado real
# da simulação e não são substitutos visuais da cidade.
# =========================
var v030_missions: Array = []

func v030_get_active_missions() -> Array:
    var active: Array = []
    for mission in v030_missions:
        if str(mission.get("status", "")) in ["aberta", "em resposta", "em curso"]:
            active.append(mission)
    return active

var v030_teams: Dictionary = {}
var v030_dispatches: Array = []
var v030_communications: Array = []
var v030_inventories: Dictionary = {}
var v030_properties: Dictionary = {}
var v030_finance: Dictionary = {
    "configured": false,
    "balance": null,
    "income": null,
    "expenses": null,
    "contracts": [],
    "loans": [],
    "history": []
}
var v030_buildings: Dictionary = {}
var v030_population_state: Dictionary = {
    "births": 0, "deaths": 0, "moves": 0, "employment": null,
    "health": 82.0, "education": 76.0, "crime": 8.0
}
var v030_environment: Dictionary = {
    "weather": "limpo", "temperature": 18.0, "wind": 8.0,
    "rain": 0.0, "visibility": 100.0, "season": "inverno"
}
var v030_services_state: Dictionary = {}
var v030_system_events: Array = []
var v030_mission_counter: int = 0
var v030_team_counter: int = 0
var v030_property_counter: int = 0
var v030_building_counter: int = 0
var v030_population_agents: Dictionary = {}
var v030_city_causes: Array = []
var v030_vehicle_state: Dictionary = {}
var v030_entity_schedules: Dictionary = {}
var v030_mission_history: Array = []
var v030_incident_counter: int = 0
var v030_day_events: Dictionary = {}

func v030_initialize_all_systems() -> void:
    # Não criar edifícios, capacidades, ocupação ou serviços físicos de exemplo.
    # O mapa e as quantidades de edifícios só serão instanciados após aprovação.
    v030_buildings = {}
    # Efetivos, equipas, inventário e capacidades de serviço não recebem
    # quantidades de demonstração; são configurados numa fase posterior.
    if v030_teams.is_empty():
        v030_teams = {}
    if v030_inventories.is_empty():
        v030_inventories = {}
    if v030_services_state.is_empty():
        v030_services_state = {}
    v030_initialize_population_agents()
    v030_initialize_vehicle_state()
    v030_initialize_entity_schedules()
    v030_system_events.append({"type": "systems_initialized", "day": day, "hour": hour})

func v030_update_all_systems() -> void:
    v030_update_environment()
    v030_update_population_system()
    v030_update_buildings()
    v030_update_service_state()
    v030_update_mission_ai()
    v030_update_dispatches()
    v030_update_teams()
    v030_update_communications()
    v030_update_inventories()
    v030_update_properties()
    v030_update_finance()
    v030_update_city_consequences()
    v030_update_population_lifecycle()
    v030_update_building_services()
    v030_update_vehicle_operations()
    v030_update_entity_operations()
    v030_update_mission_consequences()
    v030_run_causal_city_ai()

func v030_update_environment() -> void:
    var season: String = "inverno"
    if month >= 2 and month <= 4:
        season = "primavera"
    elif month >= 5 and month <= 8:
        season = "verão"
    elif month >= 9 and month <= 11:
        season = "outono"
    var wave: float = sin(float(day * 17 + hour) * 0.08)
    var temperature: float = 18.0 + wave * 5.0
    if season == "verão":
        temperature += 7.0
    elif season == "inverno":
        temperature -= 5.0
    var rain: float = clampf(38.0 - temperature + abs(wave) * 12.0, 0.0, 85.0)
    if season == "verão":
        rain *= 0.35
    var weather: String = "limpo"
    if rain > 60.0:
        weather = "chuva forte"
    elif rain > 30.0:
        weather = "chuva"
    elif temperature > 31.0:
        weather = "calor"
    v030_environment = {
        "weather": weather,
        "temperature": snappedf(temperature, 0.1),
        "wind": snappedf(8.0 + abs(wave) * 12.0, 0.1),
        "rain": snappedf(rain, 0.1),
        "visibility": clampf(100.0 - rain * 0.45, 25.0, 100.0),
        "season": season
    }
    v030_weather = weather
    v030_season = season

func v030_update_population_system() -> void:
    # A taxa de emprego fica nula até o modelo laboral ser definido.
    var employment: Variant = null
    var health_value: float = clampf(82.0 - float(v030_incidents.size()) * 0.4 + float(v030_city_state.get("public_services", 70.0)) * 0.08, 0.0, 100.0)
    var crime_value: float = clampf(float(v030_city_state.get("crime", 8.0)) + float(v030_incidents.size()) * 0.08, 0.0, 100.0)
    v030_population_state["employment"] = employment
    v030_population_state["health"] = health_value
    v030_population_state["crime"] = crime_value
    v030_population_state["moves"] = v030_residence_moves.size()
    v030_city_state["employment"] = employment
    v030_city_state["crime"] = crime_value

func v030_update_buildings() -> void:
    for building_id in v030_buildings.keys():
        var building: Dictionary = v030_buildings[building_id]
        var occupancy: float = float(building.get("occupancy", 0))
        var capacity: float = maxf(1.0, float(building.get("capacity", 1)))
        var condition: float = float(building.get("condition", 90.0))
        var pressure: float = occupancy / capacity
        condition = clampf(condition - (0.01 if pressure > 0.9 else 0.002), 0.0, 100.0)
        building["condition"] = condition
        v030_buildings[building_id] = building

func v030_update_service_state() -> void:
    if v030_services_state.is_empty():
        return
    var incidents_load: int = v030_incidents.size()
    var hospital: Dictionary = v030_services_state.get("hospital", {})
    hospital["waiting"] = min(100, int(hospital.get("waiting", 0)) + incidents_load / 8)
    hospital["load"] = clampi(int(hospital.get("load", 35)) + incidents_load / 5 - 1, 0, 100)
    v030_services_state["hospital"] = hospital
    var schools: Dictionary = v030_services_state.get("schools", {})
    schools["load"] = 75 if v030_school_day else 25
    v030_services_state["schools"] = schools

func v030_update_mission_ai() -> void:
    # Missões nascem da IA/cidade. Nunca são criadas por um botão do jogador.
    var open_count: int = 0
    for mission in v030_missions:
        if str(mission.get("status", "")) in ["aberta", "em resposta", "em curso"]:
            open_count += 1
    if open_count >= 8:
        return
    var source_incident: Dictionary = {}
    for incident in v030_incidents:
        if str(incident.get("status", "")) == "aberta":
            source_incident = incident
            break
    var should_create: bool = not source_incident.is_empty()
    if not should_create:
        should_create = (day * 37 + hour * 11 + v030_simulation_ticks) % 53 == 0
    if not should_create:
        return
    v030_mission_counter += 1
    var mission_id: String = "MIS-%05d" % v030_mission_counter
    var kind: String = str(source_incident.get("type", "necessidade urbana"))
    var neighborhood: String = str(source_incident.get("neighborhood", v030_current_neighborhood))
    var priority: int = int(source_incident.get("priority", 2))
    var required_entity: String = "BRIGADA"
    if kind.find("assistência") >= 0:
        required_entity = "S.U.E."
    elif kind.find("criminal") >= 0:
        required_entity = "Polícia"
    elif kind.find("transporte") >= 0:
        required_entity = "TNUR"
    var mission: Dictionary = {
        "id": mission_id,
        "type": kind,
        "origin": "IA_CIDADE",
        "information": "informação inicial incompleta",
        "neighborhood": neighborhood,
        "priority": priority,
        "required_entity": required_entity,
        "status": "aberta",
        "created_day": day,
        "created_hour": hour,
        "assigned_team": "",
        "assigned_vehicle": "",
        "outcome": ""
    }
    v030_missions.append(mission)
    if not source_incident.is_empty():
        source_incident["status"] = "missão criada"
        for i in range(v030_incidents.size()):
            if str(v030_incidents[i].get("id", "")) == str(source_incident.get("id", "")):
                v030_incidents[i] = source_incident
                break
    v030_add_news("A IA gerou a missão %s em %s." % [mission_id, neighborhood], "missão")
    v030_communications.append({"type": "despacho", "mission_id": mission_id, "day": day, "hour": hour})

func v030_update_dispatches() -> void:
    # O tempo decorrido não determina o resultado de uma ocorrência. A missão
    # termina apenas por transição explícita e com equipa/viatura registadas.
    return

func v030_complete_mission(mission_id: String, outcome: String) -> Dictionary:
    for index in range(v030_missions.size()):
        var mission: Dictionary = v030_missions[index]
        if str(mission.get("id", "")) != mission_id:
            continue
        if str(mission.get("status", "")) not in ["em resposta", "em curso", "no local", "estabilizada"]:
            return {"ok": false, "error": "A missão não está num estado que permita conclusão."}
        var team_id := str(mission.get("assigned_team", ""))
        var vehicle_id := str(mission.get("assigned_vehicle", ""))
        if team_id.is_empty() or not v030_teams.has(team_id):
            return {"ok": false, "error": "Não existe equipa registada atribuída à missão."}
        if vehicle_id.is_empty() or not v030_vehicles.has(vehicle_id):
            return {"ok": false, "error": "Não existe viatura registada atribuída à missão."}
        mission["status"] = "concluída"
        mission["outcome"] = outcome.strip_edges() if not outcome.strip_edges().is_empty() else "resultado não especificado"
        mission["completed_day"] = day
        mission["completed_hour"] = hour
        v030_missions[index] = mission
        var team: Dictionary = v030_teams[team_id]
        team["status"] = "disponível"
        team["mission_id"] = ""
        team["vehicle"] = ""
        v030_teams[team_id] = team
        var vehicle: Dictionary = v030_vehicles[vehicle_id]
        vehicle["status"] = "disponível"
        vehicle["mission_id"] = ""
        v030_vehicles[vehicle_id] = vehicle
        if v030_vehicle_state.has(vehicle_id):
            var vehicle_state: Dictionary = v030_vehicle_state[vehicle_id]
            vehicle_state["available"] = true
            vehicle_state["mission"] = ""
            vehicle_state["location"] = str(mission.get("neighborhood", vehicle_state.get("location", "")))
            v030_vehicle_state[vehicle_id] = vehicle_state
        v030_add_news("Missão %s concluída: %s." % [mission_id, str(mission["outcome"])], "missão")
        return {"ok": true, "mission": mission.duplicate(true)}
    return {"ok": false, "error": "Missão não encontrada."}

func v030_update_teams() -> void:
    # Não atribuir missões automaticamente enquanto composição de equipas,
    # disponibilidade e regras de despacho não estiverem aprovadas.
    return

func v030_update_communications() -> void:
    if v030_communications.size() > 300:
        v030_communications = v030_communications.slice(v030_communications.size() - 300)

func v030_update_inventories() -> void:
    # O inventário só muda através de movimentos explícitos registados.
    # Não criar unidades nem repor stock automaticamente com valores inventados.
    return

func v030_update_properties() -> void:
    # Avaliações monetárias de imóveis aguardam regras económicas oficiais.
    # Não inventar preços de compra, venda ou valorização.
    return

func v030_update_finance() -> void:
    # Nenhuma receita/despesa é inferida a partir de comércio, ocorrências ou
    # missões. A contabilidade aguarda regras aprovadas e transações explícitas.
    return

func v030_record_financial_transaction(kind: String, amount_cents: int, actor_id: String = "") -> Dictionary:
    if not is_instance_valid(v030_runtime):
        return {"ok": false, "error": "Runtime financeiro indisponível."}
    var result: Dictionary = v030_runtime.add_transaction(kind, amount_cents, actor_id)
    if not bool(result.get("ok", false)):
        return result
    var runtime_status: Dictionary = v030_runtime.get_status()
    v030_finance["configured"] = true
    v030_finance["balance"] = float(runtime_status.get("economy_balance_cents", 0)) / 100.0
    v030_finance["history"] = v030_runtime.economy.get("transactions", []).duplicate(true)
    return result

func v030_update_city_consequences() -> void:
    var active_missions: int = 0
    for mission in v030_missions:
        if str(mission.get("status", "")) in ["aberta", "em resposta", "em curso"]:
            active_missions += 1
    v030_city_state["public_services"] = clampf(80.0 - active_missions * 2.0 + float(v030_population_state.get("health", 80.0)) * 0.08, 0.0, 100.0)
    v030_city_state["satisfaction"] = clampf(float(v030_city_state.get("satisfaction", 70.0)) + (0.2 if active_missions < 3 else -0.2), 0.0, 100.0)


# =========================
# V0.3.0 — IA CENTRAL / SIMULAÇÃO PROFUNDA
# Estes módulos ligam os sistemas entre si. A cidade produz causas,
# as causas produzem ocorrências e as ocorrências produzem consequências.
# =========================
func v030_initialize_population_agents() -> void:
    var legacy_names := {"Marta": "Arel Valara", "Rui": "Néria Nerova", "Inês": "Varel Loreno"}
    var normalized_agents: Dictionary = {}
    for old_key in v030_population_agents.keys():
        var old_name := str(old_key)
        var new_name := str(legacy_names.get(old_name, old_name))
        var existing_agent: Dictionary = v030_population_agents[old_key]
        existing_agent["income"] = null
        existing_agent["employment"] = "por_definir"
        existing_agent["household"] = null if existing_agent.get("household", null) == old_name else existing_agent.get("household", null)
        if not normalized_agents.has(new_name):
            normalized_agents[new_name] = existing_agent
    v030_population_agents = normalized_agents

    var used_names: Dictionary = {}
    for existing_name in v030_population_agents.keys():
        used_names[str(existing_name)] = true
    var neighborhood_names: Array = v030_get_neighborhoods()
    for index in range(npcs.size()):
        var npc: Dictionary = npcs[index]
        var name: String = str(npc.get("name", "Habitante"))
        used_names[name] = true
        if not v030_population_agents.has(name):
            v030_population_agents[name] = {
                "id": "VAL-%08d" % (100000 + index),
                "age": int(npc.get("age", 30)),
                "gender": "por_definir",
                "profession": str(npc.get("profession", "por_definir")),
                "employment": "por_definir",
                "income": null,
                "health": 85.0,
                "education": null,
                "happiness": 65.0,
                "household": null,
                "neighborhood": neighborhood_names[index % neighborhood_names.size()],
                "home_neighborhood": neighborhood_names[index % neighborhood_names.size()],
                "current_neighborhood": neighborhood_names[index % neighborhood_names.size()],
                "routine_profile": "",
                "destination_id": "",
                "destination_type": "residencia",
                "destination_neighborhood": neighborhood_names[index % neighborhood_names.size()],
                "trip_state": "em_casa",
                "destination_resolved": false,
                "mobility": null,
                "last_change": ""
            }
    # A população de referência é um milhão; 200 agentes individuais são a
    # amostra detalhada aprovada. O resto da população mantém-se agregada.
    while v030_population_agents.size() < 200:
        var index := v030_population_agents.size()
        var seed_value := 100000 + index
        var generated_name := str(V030_CHARACTER_GENERATOR.generate_name(seed_value, used_names))
        var attempt := 0
        while used_names.has(generated_name) and attempt < 100:
            attempt += 1
            generated_name = str(V030_CHARACTER_GENERATOR.generate_name(seed_value + attempt, used_names))
        if used_names.has(generated_name):
            generated_name = "Habitante-%06d" % seed_value
        used_names[generated_name] = true
        v030_population_agents[generated_name] = {
            "id": "VAL-%08d" % seed_value,
            "age": 18 + (seed_value % 65),
            "gender": "por_definir",
            "profession": "por_definir",
            "employment": "por_definir",
            "income": null,
            "health": 70.0 + float(seed_value % 31),
            "education": null,
            "happiness": 40.0 + float(seed_value % 51),
            "household": null,
            "neighborhood": neighborhood_names[index % neighborhood_names.size()],
            "mobility": null,
            "last_change": ""
        }
    v030_world_metrics["npc_materializados"] = v030_population_agents.size()
    v030_world_metrics["npc_visiveis_no_mapa"] = npcs.size()

func v030_initialize_vehicle_state() -> void:
    for vehicle_id in v030_vehicles.keys():
        if v030_vehicle_state.has(vehicle_id):
            continue
        var vehicle: Dictionary = v030_vehicles[vehicle_id]
        v030_vehicle_state[vehicle_id] = {
            "fuel": null,
            "condition": null,
            "available": null,
            "location": vehicle.get("location", null),
            "mission": "",
            "km": null
        }

func v030_initialize_entity_schedules() -> void:
    # Não presumir turnos, disponibilidade ou composição de equipas.
    if v030_entity_schedules.is_empty():
        v030_entity_schedules = {}

func v030_update_population_agent_routines() -> void:
    # Rotinas persistentes para a amostra individual detalhada. Não atribui
    # moradas, empregadores ou instalações inexistentes nos dados aprovados.
    # Destinos são tipificados e ficam pendentes quando falta um destino real.
    var counts: Dictionary = {}
    var destination_counts: Dictionary = {}
    for agent_name in v030_population_agents.keys():
        var agent: Dictionary = v030_population_agents[agent_name]
        var stable_id := str(agent.get("id", agent_name))
        var seed_value: int = int(abs(stable_id.hash()))
        var home_neighborhood := str(agent.get("home_neighborhood", agent.get("neighborhood", "Nexora")))
        var current_neighborhood := str(agent.get("current_neighborhood", home_neighborhood))
        var profile := str(agent.get("routine_profile", ""))
        if profile.is_empty():
            var profile_index := posmod(seed_value, 4)
            match profile_index:
                0: profile = "pendular"
                1: profile = "local"
                2: profile = "servicos"
                _: profile = "lazer"
        var activity := "vida_domestica"
        var location_type := "residencial"
        var destination_type := "residencia"
        var trip_state := "em_casa"
        var weekend_day := weekday >= 6
        if hour >= 22 or hour < 6:
            activity = "descanso"
            location_type = "residencial"
            destination_type = "residencia"
            trip_state = "em_casa"
        elif hour >= 7 and hour < 10 and not weekend_day and profile == "pendular":
            activity = "deslocacao_pendular"
            location_type = "via_publica"
            destination_type = "trabalho_ou_estudo_por_atribuir"
            trip_state = "destino_real_pendente"
        elif hour >= 8 and hour < 17 and not weekend_day:
            if profile == "servicos":
                activity = "atividade_de_servicos"
                location_type = "bairro"
                destination_type = "servico_por_atribuir"
            elif profile == "local":
                activity = "atividade_local"
                location_type = "bairro"
                destination_type = "destino_local_por_atribuir"
            else:
                activity = "rotina_diurna"
                location_type = "bairro"
                destination_type = "destino_diurno_por_atribuir"
            trip_state = "destino_real_pendente"
        elif hour >= 17 and hour < 20 and profile == "pendular":
            activity = "regresso_pendular"
            location_type = "via_publica"
            destination_type = "residencia"
            trip_state = "regresso_a_residencia"
        elif weekend_day and hour >= 10 and hour < 21 and profile == "lazer":
            activity = "lazer"
            location_type = "lazer_publico_ou_privado"
            destination_type = "local_de_lazer_por_atribuir"
            trip_state = "destino_real_pendente"
        elif hour >= 17 and hour < 22:
            activity = "lazer_ou_vida_domestica" if seed_value % 2 == 0 else "vida_domestica"
            location_type = "lazer_ou_residencial" if seed_value % 2 == 0 else "residencial"
            destination_type = "local_de_lazer_por_atribuir" if seed_value % 2 == 0 else "residencia"
            trip_state = "destino_real_pendente" if seed_value % 2 == 0 else "em_casa"
        # Mantém localização e identidade estáveis; não inventa morada, emprego,
        # família ou caminho físico enquanto esses registos não existirem.
        agent["routine_profile"] = profile
        agent["home_neighborhood"] = home_neighborhood
        agent["current_neighborhood"] = current_neighborhood
        agent["activity"] = activity
        agent["routine_location_type"] = location_type
        agent["destination_type"] = destination_type
        agent["destination_neighborhood"] = current_neighborhood
        agent["trip_state"] = trip_state
        agent["destination_id"] = str(agent.get("destination_id", ""))
        agent["destination_resolved"] = false if str(agent.get("destination_id", "")).is_empty() else true
        agent["routine_updated_day"] = day
        agent["routine_updated_hour"] = hour
        agent["routine_revision"] = 2
        v030_population_agents[agent_name] = agent
        counts[activity] = int(counts.get(activity, 0)) + 1
        destination_counts[destination_type] = int(destination_counts.get(destination_type, 0)) + 1
    v030_population_state["routine_counts"] = counts
    v030_population_state["destination_counts"] = destination_counts
    v030_population_state["reference_population"] = 1000000
    v030_population_state["detailed_individual_agents"] = v030_population_agents.size()
    v030_population_state["aggregate_population"] = maxi(0, 1000000 - v030_population_agents.size())
    v030_world_metrics["population_routine_counts"] = counts
    v030_world_metrics["population_destination_counts"] = destination_counts
    v030_world_metrics["population_reference"] = 1000000
    v030_world_metrics["population_aggregate"] = maxi(0, 1000000 - v030_population_agents.size())
    _v030_sync_city_population_agents()

func _v030_sync_city_population_agents() -> void:
    var city := get_node_or_null("UI/Map/MapBody/Map3D/SubViewport/ValepolisCity3D")
    if city != null and city.has_method("sync_population_agents"):
        var result: Variant = city.call("sync_population_agents", v030_population_agents)
        if result is Dictionary:
            v030_world_metrics["population_visual_sync"] = result

func v030_update_population_lifecycle() -> void:
    # Taxas de natalidade/mortalidade e emprego aguardam parâmetros demográficos aprovados.
    v030_update_population_agent_routines()
    var births: int = int(v030_population_state.get("births", 0))
    var deaths: int = int(v030_population_state.get("deaths", 0))
    var average_health: float = 0.0
    var average_happiness: float = 0.0
    for name in v030_population_agents.keys():
        var agent: Dictionary = v030_population_agents[name]
        var health: float = float(agent.get("health", 85.0))
        var happiness: float = float(agent.get("happiness", 65.0))
        if float(v030_environment.get("rain", 0.0)) > 60.0:
            happiness -= 0.2
        if float(v030_city_state.get("traffic", 20.0)) > 75.0:
            happiness -= 0.3
        if float(v030_city_state.get("public_services", 70.0)) > 75.0:
            health += 0.1
        health = clampf(health, 0.0, 100.0)
        happiness = clampf(happiness, 0.0, 100.0)
        agent["health"] = health
        agent["happiness"] = happiness
        agent["income"] = null
        agent["employment"] = "por_definir"
        average_health += health
        average_happiness += happiness
        v030_population_agents[name] = agent
    if not v030_population_agents.is_empty():
        average_health /= float(v030_population_agents.size())
        average_happiness /= float(v030_population_agents.size())
    v030_population_state["births"] = births
    v030_population_state["deaths"] = deaths
    v030_population_state["health"] = average_health
    v030_population_state["happiness"] = average_happiness
    v030_population_state["employment"] = null
    v030_city_state["employment"] = null
    v030_city_state["population_happiness"] = average_happiness

func v030_update_building_services() -> void:
    var failures: int = 0
    for building_id in v030_buildings.keys():
        var building: Dictionary = v030_buildings[building_id]
        var condition: float = float(building.get("condition", 90.0))
        var services: Array = building.get("services", [])
        if condition < 45.0:
            if not services.is_empty():
                services.pop_back()
            building["service_degraded"] = true
            failures += 1
        else:
            building["service_degraded"] = false
        building["services"] = services
        v030_buildings[building_id] = building
    if failures > 0:
        v030_city_causes.append({"type": "infraestrutura", "count": failures, "day": day, "hour": hour})
        if v030_city_causes.size() > 200:
            v030_city_causes.pop_front()

func v030_update_vehicle_operations() -> void:
    for vehicle_id in v030_vehicle_state.keys():
        var state: Dictionary = v030_vehicle_state[vehicle_id]
        var available: bool = bool(state.get("available", true))
        var mission: String = str(state.get("mission", ""))
        if mission != "":
            state["fuel"] = maxf(0.0, float(state.get("fuel", 100.0)) - 0.8)
            state["condition"] = maxf(0.0, float(state.get("condition", 100.0)) - 0.15)
            state["km"] = float(state.get("km", 0.0)) + 1.5
            if float(state["fuel"]) < 10.0 or float(state["condition"]) < 25.0:
                state["available"] = false
                available = false
        if not available and mission == "" and float(state.get("condition", 100.0)) > 40.0 and float(state.get("fuel", 100.0)) > 30.0:
            state["available"] = true
        v030_vehicle_state[vehicle_id] = state

func v030_update_entity_operations() -> void:
    for entity_name in v030_entity_schedules.keys():
        var schedule: Dictionary = v030_entity_schedules[entity_name]
        var shift: int = 1 + (hour / 8)
        schedule["shift"] = clampi(shift, 1, 3)
        schedule["staff_available"] = 0.65 if hour >= 0 and hour < 6 else 1.0
        schedule["training"] = clampf(float(schedule.get("training", 0.0)) + 0.05, 0.0, 100.0)
        v030_entity_schedules[entity_name] = schedule

func v030_update_mission_consequences() -> void:
    for i in range(v030_missions.size()):
        var mission: Dictionary = v030_missions[i]
        var status: String = str(mission.get("status", ""))
        if status == "concluída" and not bool(mission.get("consequence_applied", false)):
            mission["consequence_applied"] = true
            v030_city_state["satisfaction"] = clampf(float(v030_city_state.get("satisfaction", 60.0)) + 0.8, 0.0, 100.0)
            v030_population_state["health"] = clampf(float(v030_population_state.get("health", 80.0)) + 0.1, 0.0, 100.0)
            if bool(v030_finance.get("configured", false)):
                v030_finance["expenses"] = float(v030_finance.get("expenses", 0.0)) + 10.0
            v030_mission_history.append({"id": mission.get("id", ""), "outcome": mission.get("outcome", ""), "day": day, "hour": hour})
        elif status in ["aberta", "em resposta", "em curso"]:
            var age: int = (day - int(mission.get("created_day", day))) * 24 + hour - int(mission.get("created_hour", hour))
            if age >= 3 and int(mission.get("priority", 2)) <= 2:
                mission["status"] = "agravada"
                mission["priority"] = 1
                mission["information"] = "situação agravada; requer resposta prioritária"
                v030_add_news("A missão %s agravou-se." % str(mission.get("id", "")), "emergência")
        v030_missions[i] = mission
    if v030_mission_history.size() > 300:
        v030_mission_history.pop_front()

func v030_run_causal_city_ai() -> void:
    var traffic: float = float(v030_city_state.get("traffic", 20.0))
    var rain: float = float(v030_environment.get("rain", 0.0))
    var crime: float = float(v030_population_state.get("crime", 8.0))
    var pressure: float = float(v030_city_state.get("commerce", 50.0))
    if rain > 65.0:
        v030_city_causes.append({"type": "chuva_forte", "effect": "trânsito e ocorrências", "day": day, "hour": hour})
        v030_city_state["traffic"] = clampf(traffic + 4.0, 0.0, 100.0)
    if traffic > 80.0:
        v030_city_causes.append({"type": "congestionamento", "effect": "atrasos", "day": day, "hour": hour})
        v030_city_state["satisfaction"] = clampf(float(v030_city_state.get("satisfaction", 60.0)) - 0.6, 0.0, 100.0)
    if crime > 12.0 and (day * 7 + hour + v030_simulation_ticks) % 17 == 0:
        v030_incident_counter += 1
        v030_incidents.append({
            "id": "INC-AI-%05d" % v030_incident_counter,
            "type": "ocorrência de segurança",
            "neighborhood": v030_current_neighborhood,
            "priority": 2,
            "status": "aberta",
            "day": day,
            "hour": hour,
            "source": "IA_CENTRAL"
        })
    if pressure > 85.0 and (day * 5 + hour) % 23 == 0:
        v030_add_news("A atividade económica aumentou a procura por serviços.", "economia")
    if v030_city_causes.size() > 500:
        v030_city_causes = v030_city_causes.slice(v030_city_causes.size() - 500)

func v030_get_missions() -> Array:
    return v030_missions.duplicate(true)

func v030_get_finance() -> Dictionary:
    return v030_finance.duplicate(true)

func v030_get_inventories() -> Dictionary:
    return v030_inventories.duplicate(true)

func v030_load_integrated_state() -> void:
    if not FileAccess.file_exists(V030_STATE_PATH):
        return
    var f := FileAccess.open(V030_STATE_PATH, FileAccess.READ)
    if f == null:
        return
    var parsed: Variant = JSON.parse_string(f.get_as_text())
    f.close()
    if not (parsed is Dictionary) or str(parsed.get("version", "")) != V030_VERSION:
        return

    # Restaurar apenas estados de simulação. Efetivos, viaturas, instalações,
    # inventário e saldos continuam por configurar e não são carregados daqui.
    if parsed.get("city_state", null) is Dictionary:
        v030_city_state = parsed["city_state"].duplicate(true)
    if parsed.get("character_ai", null) is Dictionary:
        v030_character_ai = parsed["character_ai"].duplicate(true)
    if parsed.get("personal_ai", null) is Dictionary:
        v030_personal_ai = parsed["personal_ai"].duplicate(true)
    if parsed.get("relationship_events", null) is Array:
        v030_relationship_events = parsed["relationship_events"].duplicate(true)
    if parsed.get("incidents", null) is Array:
        v030_incidents = parsed["incidents"].duplicate(true)
    if parsed.get("traffic_routes", null) is Dictionary:
        v030_traffic_routes = parsed["traffic_routes"].duplicate(true)
    if parsed.get("news", null) is Array:
        v030_news = parsed["news"].duplicate(true)
    if parsed.get("communications", null) is Array:
        v030_communications = parsed["communications"].duplicate(true)
    if parsed.get("missions", null) is Array:
        v030_missions = parsed["missions"].duplicate(true)
    if parsed.get("population_state", null) is Dictionary:
        v030_population_state = parsed["population_state"].duplicate(true)
    if parsed.get("environment", null) is Dictionary:
        v030_environment = parsed["environment"].duplicate(true)
    if parsed.get("population_agents", null) is Dictionary:
        v030_population_agents = parsed["population_agents"].duplicate(true)
    if parsed.get("city_causes", null) is Array:
        v030_city_causes = parsed["city_causes"].duplicate(true)
    if parsed.get("mission_history", null) is Array:
        v030_mission_history = parsed["mission_history"].duplicate(true)

    v030_simulation_ticks = max(0, int(parsed.get("simulation_ticks", v030_simulation_ticks)))
    v030_mission_counter = max(0, int(parsed.get("mission_counter", v030_mission_counter)))
    v030_incident_counter = max(0, int(parsed.get("incident_counter", v030_incident_counter)))

    # Não manter missões atribuídas a equipas/viaturas inexistentes nesta sessão.
    for index in range(v030_missions.size()):
        var mission: Dictionary = v030_missions[index]
        if str(mission.get("status", "")) in ["em resposta", "em curso", "no local", "estabilizada"]:
            var team_id := str(mission.get("assigned_team", ""))
            var vehicle_id := str(mission.get("assigned_vehicle", ""))
            if team_id.is_empty() or vehicle_id.is_empty() or not v030_teams.has(team_id) or not v030_vehicles.has(vehicle_id):
                mission["status"] = "aberta"
                mission["assigned_team"] = ""
                mission["assigned_vehicle"] = ""
                mission["outcome"] = "aguarda recursos oficialmente configurados"
                v030_missions[index] = mission

func v030_save_state() -> void:
    var f := FileAccess.open(V030_STATE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify({
            "version": V030_VERSION,
            "city_state": v030_city_state,
            "character_ai": v030_character_ai,
            "personal_ai": v030_personal_ai,
            "relationship_events": v030_relationship_events,
            "incidents": v030_incidents,
            "traffic_routes": v030_traffic_routes,
            "entity_metrics": v030_entity_metrics,
            "economy": v030_economy,
            "news": v030_news,
            "simulation_ticks": v030_simulation_ticks,
            "missions": v030_missions,
            "teams": v030_teams,
            "dispatches": v030_dispatches,
            "communications": v030_communications,
            "inventories": v030_inventories,
            "properties": v030_properties,
            "finance": v030_finance,
            "buildings": v030_buildings,
            "population_state": v030_population_state,
            "environment": v030_environment,
            "services_state": v030_services_state,
            "mission_counter": v030_mission_counter,
            "team_counter": v030_team_counter,
            "property_counter": v030_property_counter,
            "building_counter": v030_building_counter,
            "population_agents": v030_population_agents,
            "city_causes": v030_city_causes,
            "vehicle_state": v030_vehicle_state,
            "entity_schedules": v030_entity_schedules,
            "mission_history": v030_mission_history,
            "incident_counter": v030_incident_counter
        }))
        f.close()

func v030_get_news() -> Array:
    return v030_news.duplicate(true)


# V0.3.0 — VALÉPOLIS 3D CITY DETAIL LAYER
# Camada procedural/data-driven para completar a cidade sem criar milhões de nós.
# Usa instancing lógico e níveis de detalhe. A população continua agregada na simulação.
const V030_CITY_MAX_FLOORS := 30
const V030_CITY_DETAIL_VERSION := "0.3.0-3D-CITY"

const V030_CITY_ZONES := {
    "residencial": {"density": 0.72, "height_min": 1, "height_max": 12},
    "comercial": {"density": 0.58, "height_min": 2, "height_max": 18},
    "empresarial": {"density": 0.42, "height_min": 4, "height_max": 30},
    "industrial": {"density": 0.35, "height_min": 1, "height_max": 8},
    "logistica": {"density": 0.25, "height_min": 1, "height_max": 5},
    "rural": {"density": 0.12, "height_min": 1, "height_max": 3},
    "verde": {"density": 0.08, "height_min": 0, "height_max": 1},
}

const V030_CITY_SERVICES := [
    "Município de Valepólis",
    "Hospital Municipal",
    "Escola de Valepólis",
    "Comércio Local",
    "BRIGADA",
    "S.U.E.",
    "TNUR",
    "Polícia",
    "Serviços Públicos",
]

const V030_CITY_FEATURES := [
    "Praias",
    "Marina",
    "Porto",
    "Rio/Estuário",
    "Montanhas",
    "Florestas",
    "Lagos",
    "Parques e Jardins",
    "Zona Urbana",
    "Zona Rural",
    "Zona Industrial",
    "Zona Logística",
    "Ponte da União",
    "Ponte do Horizonte",
]

func v030_city_3d_profile() -> Dictionary:
    return {
        "version": V030_CITY_DETAIL_VERSION,
        "population_reference": V030_CITY_POPULATION,
        "neighborhoods": V030_NEIGHBORHOODS.size() if "V030_NEIGHBORHOODS" in self else 25,
        "max_floors": V030_CITY_MAX_FLOORS,
        "zones": V030_CITY_ZONES.keys(),
        "services": V030_CITY_SERVICES,
        "features": V030_CITY_FEATURES,
        "simulation": "agregada + detalhada",
        "rendering": "LOD + instancing lógico",
    }

func v030_city_3d_building_profile(neighborhood: String, zone: String, seed: int = 0) -> Dictionary:
    var z: Dictionary = V030_CITY_ZONES.get(zone, V030_CITY_ZONES["residencial"])
    var local_seed: int = int(abs(hash(neighborhood + ":" + zone + ":" + str(seed))))
    var span := int(z["height_max"]) - int(z["height_min"]) + 1
    var floors: int = int(z["height_min"]) + (local_seed % maxi(1, span))
    floors = clampi(floors, 1, V030_CITY_MAX_FLOORS)
    return {
        "neighborhood": neighborhood,
        "zone": zone,
        "floors": floors,
        "lod": "high" if floors >= 12 else ("medium" if floors >= 5 else "low"),
        "instanced": true,
    }

func v030_city_3d_detail_targets() -> Array:
    return [
        "residencias", "apartamentos", "comercio", "escritorios",
        "industria", "logistica", "escolas", "saude", "municipio",
        "BRIGADA", "SUE", "TNUR", "policia", "parques", "praias",
        "porto", "marina", "florestas", "lagos", "estradas", "pontes",
        "transito", "peoes", "veiculos", "sinalizacao"
    ]


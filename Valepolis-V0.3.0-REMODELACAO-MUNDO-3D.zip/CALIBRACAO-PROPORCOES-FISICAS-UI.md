# Calibração de proporções físicas e interface móvel — V0.3.0

## Proporções
- Veículo visual base atualizado para 1,80 m de largura × 1,45 m de altura × 4,20 m de comprimento, escala métrica do mundo Godot.
- Peões existentes mantêm altura aproximada de 1,70 m (cabeça centrada a 1,48 m e corpo/pernas na geometria atual).
- Larguras de estradas e perfis de edifícios/pisos mantidos a partir da matriz existente; não foi aplicada uma escala global que altere os bairros ou a altura máxima aprovada.
- A proporção visual ainda necessita de validação no runtime Godot com a câmara normal do jogo.

## Interface
- Navegação de personagem e entidade passou de barra horizontal deslocável para grelha de 3 colunas × 3 linhas.
- Todos os nove separadores de cada modo ficam visíveis sem scroll horizontal; `TEMPORADAS` fica na grelha de personagem.
- Botões dimensionados para ecrã móvel, com texto compacto e altura de 34 px; a área de navegação recebe 104–120 px consoante o ecrã.

## Limites da validação
- ZIP e estrutura dos ficheiros são verificáveis, mas esta alteração ainda não foi compilada/executada no Godot 4.5 nesta sessão.

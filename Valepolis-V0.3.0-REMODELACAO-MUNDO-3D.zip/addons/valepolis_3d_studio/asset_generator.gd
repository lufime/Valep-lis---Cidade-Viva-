extends SceneTree

## Gera cenas 3D nativas Godot para smoke-test e biblioteca inicial do jogo.
const OUT_DIR := "res://assets/generated_3d"

func _initialize() -> void:
    call_deferred("_run")

func _run() -> void:
    var err := DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(OUT_DIR))
    if err != OK and err != ERR_ALREADY_EXISTS:
        push_error("Não foi possível criar a pasta de recursos 3D: %s" % err)
        quit(1)
        return
    var generated := 0
    var roles := ["Civil", "BRIGADA", "SUE", "TNUR", "Policia"]
    for i in range(roles.size()):
        var character_script: Script = load("res://addons/valepolis_3d_studio/procedural_character.gd")
        var character: Node3D = character_script.new() as Node3D
        character.name = "Personagem_%s" % roles[i]
        character.seed_value = 1000 + i
        character.role = roles[i]
        character.regenerate_on_ready = false
        character.regenerate()
        if _save_scene(character, OUT_DIR + "/personagem_%s.tscn" % roles[i].to_lower()):
            generated += 1
        character.free()
    for i in range(5):
        var root := Node3D.new()
        root.name = "Edificio_Modular_%02d" % (i + 1)
        var building := MeshInstance3D.new()
        building.name = "BuildingMesh"
        var mesh := BoxMesh.new()
        mesh.size = Vector3(5.0 + float(i % 3), 5.0 + float(i) * 1.7, 5.0 + float((i + 1) % 3))
        building.mesh = mesh
        building.position.y = mesh.size.y * 0.5
        var mat := StandardMaterial3D.new()
        mat.albedo_color = [Color("#c8b69c"), Color("#d6d4cb"), Color("#b6c5c9"), Color("#b9a58b"), Color("#c7c0b2")][i]
        mat.roughness = 0.9
        building.material_override = mat
        root.add_child(building)
        if _save_scene(root, OUT_DIR + "/edificio_modular_%02d.tscn" % (i + 1)):
            generated += 1
        root.free()
    if generated < 10:
        push_error("Biblioteca procedural incompleta: %d/10 cenas" % generated)
        quit(1)
        return
    print("VALEPOLIS_NATIVE_3D_PASS=generated:%d" % generated)
    quit(0)

func _save_scene(root: Node, path: String) -> bool:
    # PackedScene só inclui nós que pertencem à cena. Sem owner, o ficheiro
    # parecia existir mas perdia todos os meshes gerados (raiz vazia).
    _assign_scene_owner(root, root)
    var packed := PackedScene.new()
    var pack_err := packed.pack(root)
    if pack_err != OK:
        push_error("Falha ao empacotar cena %s: %s" % [path, pack_err])
        return false
    var save_err := ResourceSaver.save(packed, path)
    if save_err != OK:
        push_error("Falha ao guardar cena %s: %s" % [path, save_err])
        return false

    # Verificação real do recurso guardado, não apenas da existência do ficheiro.
    var saved_scene := load(path) as PackedScene
    if saved_scene == null:
        push_error("A cena guardada não pode ser carregada: %s" % path)
        return false
    var instance := saved_scene.instantiate()
    var mesh_count := _count_meshes(instance)
    instance.free()
    if mesh_count < 1:
        push_error("A cena gerada não contém geometria MeshInstance3D: %s" % path)
        return false
    return true

func _assign_scene_owner(node: Node, scene_root: Node) -> void:
    for child in node.get_children():
        child.owner = scene_root
        _assign_scene_owner(child, scene_root)

func _count_meshes(node: Node) -> int:
    var total := 1 if node is MeshInstance3D else 0
    for child in node.get_children():
        total += _count_meshes(child)
    return total

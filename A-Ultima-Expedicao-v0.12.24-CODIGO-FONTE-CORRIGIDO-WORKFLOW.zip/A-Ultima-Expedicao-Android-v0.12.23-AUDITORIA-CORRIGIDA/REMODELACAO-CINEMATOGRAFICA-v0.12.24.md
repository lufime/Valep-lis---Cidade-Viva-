# A Última Expedição v0.12.24 — Remodelação cinematográfica

## Âmbito implementado
- Nova camada visual de suspense realista: vinheta, contraste, vidro escuro, contornos e iluminação atmosférica.
- Hierarquia tipográfica mais legível e cartões de estado com maior contraste.
- Botões com áreas táteis maiores, estados de foco acessíveis e feedback visual.
- Ajustes responsivos para telemóveis pequenos, tablets e ecrãs largos.
- Melhorias de legibilidade nos cenários, pontos interativos, registos, votações e modais.
- Respeito por `prefers-reduced-motion` e pelas margens seguras do Android.

## Preservação
- Não foram alterados os manipuladores JavaScript, regras de missão, progressão, pistas, votação ou protocolo multijogador.
- As imagens e os recursos existentes foram preservados.
- Esta alteração é uma remodelação da camada de interface; não transforma os cenários 2D existentes em geometria 3D real.

## Validação
- A integridade do ZIP e a estrutura dos ficheiros foram verificadas após a criação.
- Os testes automatizados do protocolo devem ser executados no ambiente Node do projeto.
- A compilação Android e a experiência visual num dispositivo físico não foram executadas nesta sessão; não são declaradas como aprovadas.

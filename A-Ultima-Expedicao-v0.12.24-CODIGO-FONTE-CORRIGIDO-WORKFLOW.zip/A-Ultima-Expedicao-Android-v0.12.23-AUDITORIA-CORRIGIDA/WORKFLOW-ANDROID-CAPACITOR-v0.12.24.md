# Workflow Android — A Última Expedição v0.12.24

## Instalação no GitHub
1. Carrega `A-Ultima-Expedicao-v0.12.24-REMODELACAO-CINEMATOGRAFICA.zip` para o repositório.
2. Cria/substitui `.github/workflows/android-apk.yml` usando o ficheiro `android-apk-capacitor-v0.12.24.yml`.
3. Mantém no repositório apenas o ZIP esperado com esse nome, para evitar executar uma versão diferente.
4. Abre **Actions**, escolhe **A Última Expedição v0.12.24 — Capacitor Android Build** e executa **Run workflow**.

O workflow verifica a versão do `package.json`, executa `npm run build` e `npm test`, sincroniza Capacitor e tenta compilar a APK com Gradle. A APK só é considerada produzida quando o job passa e publica o artefacto.

## Limites
O workflow foi revisto estaticamente, mas não foi executado no GitHub Actions nesta sessão. A criação/instalação da APK continua por confirmar até uma execução real bem-sucedida.

#!/usr/bin/env python3
"""Apply the project launcher icon to a freshly generated Capacitor Android project."""
from pathlib import Path
from PIL import Image
import sys

project = Path(__file__).resolve().parents[1]
source = project / "assets" / "icon-app-512.png"
android_res = project / "android" / "app" / "src" / "main" / "res"
if not source.is_file():
    raise SystemExit(f"Ícone de origem em falta: {source}")
if not android_res.is_dir():
    raise SystemExit(f"Recursos Android não encontrados: {android_res}")

icon = Image.open(source).convert("RGBA")
sizes = {"mipmap-mdpi": 48, "mipmap-hdpi": 72, "mipmap-xhdpi": 96,
         "mipmap-xxhdpi": 144, "mipmap-xxxhdpi": 192}
for folder, size in sizes.items():
    target_dir = android_res / folder
    target_dir.mkdir(parents=True, exist_ok=True)
    resized = icon.resize((size, size), Image.Resampling.LANCZOS)
    resized.save(target_dir / "ic_launcher.png", optimize=True)
    # Keep foreground aligned with the same artwork for Capacitor templates that reference it.
    foreground = target_dir / "ic_launcher_foreground.png"
    if foreground.exists():
        resized.save(foreground, optimize=True)

# Make sure an adaptive icon points to the foreground and a dark background.
adaptive = android_res / "mipmap-anydpi-v26"
adaptive.mkdir(parents=True, exist_ok=True)
(adaptive / "ic_launcher.xml").write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n'
    '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
    '    <background android:drawable="@color/ic_launcher_background" />\n'
    '    <foreground android:drawable="@mipmap/ic_launcher_foreground" />\n'
    '</adaptive-icon>\n', encoding="utf-8")
colors = android_res / "values"
colors.mkdir(parents=True, exist_ok=True)
colors_xml = colors / "ic_launcher_background.xml"
colors_xml.write_text(
    '<?xml version="1.0" encoding="utf-8"?>\n'
    '<resources><color name="ic_launcher_background">#05090D</color></resources>\n',
    encoding="utf-8")
print("Ícone HOME/A Última Expedição aplicado às densidades Android e ao ícone adaptativo.")

# Auditoria técnica — A Última Expedição v0.12.23

## Corrigido nesta entrega
- Metadados `package.json` atualizados para v0.12.23 (antes indicavam v0.12.18).
- Progressão final passa a exigir a conclusão das zonas necessárias dos capítulos IV e VI, incluindo Cisterna, Arquivo frigorífico e Arquivo pessoal.
- Interface e bloqueio da Câmara alinhados com o requisito de 10 provas (antes havia indicadores e controlos ainda a usar 5).
- Tempo de campanha aumentado para 54 ações (normal), 46 (difícil) e 40 (pesadelo).
- Limite de turnos por jogador aumentado para 24 (normal), 21 (difícil) e 18 (pesadelo), reduzindo risco de terminar antes da investigação.

## Validações executadas
- ZIP de origem íntegro.
- Sintaxe JavaScript validada com `node --check` para protocolo, bridge e testes.
- `node tests/protocol.test.cjs`: PASS.
- Verificação das referências de imagens: será incluída no relatório de validação automatizado.

## Ainda não validado
- APK Android não compilada nesta execução.
- Multijogador Nearby não testado em dois dispositivos físicos.
- Não foi executado um playthrough manual completo no Android.

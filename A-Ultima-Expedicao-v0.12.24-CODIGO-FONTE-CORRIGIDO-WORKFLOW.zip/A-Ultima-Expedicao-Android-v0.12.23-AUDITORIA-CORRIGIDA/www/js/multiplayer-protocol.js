(function (root) {
  'use strict';
  const ACTIONS = new Set(['investigate','collect','compare','rest','advance','open','back']);
  const TYPES = new Set(['HELLO','WELCOME','STATE','ACTION','CHAT','VOTE','VOTE_UPDATE','VOTE_RESULT','SECRET']);
  function parseMessage(raw) {
    if (typeof raw !== 'string' || raw.length > 32000) return null;
    try {
      const msg = JSON.parse(raw);
      if (!msg || typeof msg !== 'object' || Array.isArray(msg) || !TYPES.has(msg.type)) return null;
      return msg;
    } catch (_) { return null; }
  }
  function isValidAction(action) { return typeof action === 'string' && ACTIONS.has(action); }
  function isValidState(st) {
    return !!st && [1,2].includes(st.version) && Array.isArray(st.players) &&
      st.players.length >= 2 && st.players.length <= 10 &&
      Number.isInteger(st.turn) && st.turn >= 0 &&
      Number.isFinite(st.time) && st.time >= 0 && st.time <= 1000 &&
      Array.isArray(st.clues) && st.clues.length <= 100 &&
      Array.isArray(st.visited) && st.visited.length <= 100 &&
      st.players.every(p => p && typeof p.name === 'string' && p.name.length <= 80 &&
        Number.isFinite(p.score) && Number.isFinite(p.stress));
  }
  function isFreshSequence(sequence, previous) {
    return Number.isSafeInteger(sequence) && sequence > (Number.isSafeInteger(previous) ? previous : 0);
  }
  function sanitizeChat(msg) {
    if (!msg || msg.type !== 'CHAT') return null;
    const id = String(msg.id || '').slice(0, 100);
    const sender = String(msg.sender || 'Investigador').slice(0, 22);
    const text = String(msg.text || '').trim().slice(0, 240);
    return id && text ? {type:'CHAT', id, sender, text, relayed:!!msg.relayed} : null;
  }
  const api = {parseMessage,isValidAction,isValidState,isFreshSequence,sanitizeChat};
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.UEProtocol = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);

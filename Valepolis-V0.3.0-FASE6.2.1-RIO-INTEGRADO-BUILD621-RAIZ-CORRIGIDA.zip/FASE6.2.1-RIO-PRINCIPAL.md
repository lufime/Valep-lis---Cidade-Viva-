# FASE 6.2.1 — Rio principal e leito integrado

## Alterações implementadas no código
- Cabeçalho atualizado para Fase 6.2.1 / BUILD 621 para não apresentar a identificação antiga BUILD 616.
- Criado eixo curvo para o rio entre o setor oriental e o estuário ocidental.
- Rebaixamento suave do terreno junto ao eixo do rio, calculado na mesma função de altitude usada pela malha do terreno.
- Superfície de água contínua, com largura variável e colocada depois dos polígonos dos bairros para evitar que estes ocultem o rio.

## Limites e validação
A geometria continua a ser procedural. Não representa um levantamento topográfico nem comprova a hidrologia real de Valepólis. A compilação Android e a inspeção visual no dispositivo são passos obrigatórios antes de considerar a alteração validada. A rede viária e os limites dos 25 bairros não foram alterados.

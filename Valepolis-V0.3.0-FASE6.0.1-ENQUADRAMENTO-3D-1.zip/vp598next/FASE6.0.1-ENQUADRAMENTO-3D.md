# Valepólis V0.3.0 — Fase 6.0.1 (BUILD 601)

## Âmbito
Ajuste conservador da apresentação da cena 3D, usando a Fase 6.0.0 enviada como base.

## Alterações
- Identificação da interface/renderizador atualizada para Fase 6.0.1 / BUILD 601.
- Distância inicial da câmara reduzida de 29 para 26 unidades.
- Área de renderização 3D aumentada de 360 dp para 400 dp.
- Mantidos os dados territoriais e as geometrias existentes; não foram inventados bairros, estradas ou atribuições culturais.

## Limitações e validação
- ZIP verificado quanto à integridade.
- Não foi executada compilação Android nem teste no dispositivo nesta sessão.
- Esta alteração não certifica melhoria de desempenho nem valida as camadas territoriais.
- A APK RELEASE permanece bloqueada até inspeção visual e técnica dos 25 bairros, água, relevo, edifícios e controlos.

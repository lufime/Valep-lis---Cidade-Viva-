# Valepólis V0.3.0 — Fase 6.1.9: remodelação urbana visual

## Alterações nesta revisão
- Reduzida a frequência da grelha viária local para diminuir o efeito de linhas excessivas na vista aérea.
- Aumentada a meta visual de edifícios por bairro, com limites para manter desempenho em Android.
- Reduzido o espaçamento mínimo de colocação de edifícios para formar quarteirões mais preenchidos.
- Aumentada a dimensão horizontal dos edifícios para melhorar a leitura visual à escala da cidade.
- Atualizados os indicadores visíveis para BUILD 619.

## Limites e honestidade da implementação
- A rede e os edifícios continuam a ser gerados proceduralmente a partir dos polígonos e dados existentes; não representam um cadastro cartográfico real rua a rua.
- Não foram inventados nomes oficiais para os bairros sem nomenclatura confirmada.
- A altura visual usa a densidade do bairro e permanece limitada a 30 pisos. A regra de 15 pisos só pode ser aplicada após existir polígono oficial da zona central.
- Esta revisão ainda precisa de compilação Android e teste visual no dispositivo. Não declarar PRE-FLIGHT aprovado sem execução dos testes.

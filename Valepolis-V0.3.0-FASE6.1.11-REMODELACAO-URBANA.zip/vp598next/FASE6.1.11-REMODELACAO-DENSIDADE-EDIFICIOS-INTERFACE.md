# Valepólis V0.3.0 — Fase 6.1.11 / BUILD 621

## Alterações nesta revisão
- Aumentada a meta procedural de edifícios por bairro, usando a população existente como fator, com limites para manter a carga gráfica controlada.
- Reduzido o espaçamento mínimo dos edifícios e aumentadas as dimensões dos volumes para preencher melhor os quarteirões à escala visual atual.
- Aumentada a separação média da malha viária local para reduzir a sensação de grelha excessivamente densa; as vias principais ficam visualmente mais largas.
- Encurtada a legenda dos controlos 3D para reduzir o risco de texto cortado em ecrãs móveis.
- Mantidos os registos territoriais e os limites de altura já presentes na fonte.

## Limitações e validação
A distribuição de edifícios e a rede de ruas continuam a ser geradas proceduralmente dentro dos polígonos disponíveis. Esta revisão não acrescenta cadastro cartográfico real nem oficializa nomes de ruas que não constem dos dados aprovados. O ZIP é um pacote de fontes; não foi possível compilar ou executar o APK neste ambiente. A validação visual e de desempenho continua pendente num dispositivo Android.

# Valepólis V0.3.0 — Fase 6.2.5: integração de DEM local

## O que esta fase altera
- O renderizador tenta ler `app/src/main/assets/data/terrain_reference_dem.asc` (formato ESRI ASCII Grid).
- Se o ficheiro existir e passar a validação, as altitudes de referência alimentam a malha do terreno, com normalização para a escala fictícia de Valepólis.
- A costa, o estuário e a cadeia de Pedravora continuam a ser adaptações fictícias; o DEM não altera os 25 polígonos territoriais.
- Se o asset não existir ou estiver inválido, o jogo usa o relevo procedural e mostra explicitamente `procedural (DEM em falta)` no estado do renderizador.

## Limitação importante
O ZIP de origem não continha um DEM real e este ambiente não conseguiu descarregar os dados de origem. Portanto, **não foi incluído nenhum DEM fictício** e a versão atual ainda usa fallback procedural até o ficheiro de elevação real ser colocado no caminho acima.

## Formato esperado
ESRI ASCII Grid, com as seis linhas de cabeçalho usuais (`ncols`, `nrows`, `xllcorner` ou `xllcenter`, `yllcorner` ou `yllcenter`, `cellsize`, `NODATA_value`) seguidas pelos valores de altitude em metros. O carregador usa dimensões e valores; a adaptação espacial ao mapa fictício é feita no renderizador.

## Fonte sugerida para obter dados de referência
Copernicus DEM GLO-90 público: https://copernicus-dem-90m.s3.amazonaws.com/readme.html
Descrição oficial: https://dataspace.copernicus.eu/explore-data/data-collections/copernicus-contributing-missions/collections-description/COP-DEM

O DEM representa a superfície (incluindo edifícios e vegetação), não apenas terreno nu. Deve ser tratado como referência de formas de relevo e adaptado ao mundo fictício.

## Estado de testes
- ZIP e JSON: validar no artefacto produzido.
- Compilação Gradle/Android: não executada neste ambiente.
- Teste visual no dispositivo: não executado.
- DEM real integrado: **não**, depende da obtenção do ficheiro de dados.

# Valepólis V0.3.0 — Fase 6.2.4: estuário integrado no relevo

## Alterações aplicadas
- A função de altura do terreno agora inclui uma depressão de leito sob a superfície do estuário e uma transição de margem.
- A superfície de água reutiliza a mesma função de centro/largura do canal, reduzindo o desalinhamento entre água e terreno.
- A malha de terreno foi aumentada de 80×80 para 128×128 células.
- A superfície do estuário foi aumentada de 32 para 96 secções.
- Cabeçalho e mensagens do renderizador atualizados para BUILD 624; removidas referências a BUILD 614/616/620 no ficheiro Kotlin principal.
- Não foram alterados os dados territoriais nem os limites dos 25 bairros.

## Limitações e validação
- O terreno continua procedural. Não foi integrado um DEM real nesta alteração e não deve ser apresentado como topografia medida.
- O aumento da malha aumenta o custo de geração e renderização; o desempenho num dispositivo Android real ainda precisa de ser medido.
- Não foi possível executar uma compilação Gradle/Android nesta sessão: o projeto não contém `gradlew` e não há comando `gradle` disponível.
- Foram efetuadas verificações estáticas do ficheiro-fonte e da estrutura do ZIP; estas não substituem compilação nem teste visual no telemóvel.

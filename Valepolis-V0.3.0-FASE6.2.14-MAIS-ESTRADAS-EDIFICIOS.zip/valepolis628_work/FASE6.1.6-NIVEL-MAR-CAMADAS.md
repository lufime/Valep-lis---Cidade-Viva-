# Fase 6.1.6 — Nível do mar e integração das camadas

- BUILD 616.
- Mar e estuário usam a cota vertical Y=0.
- A faixa do mar prolonga-se até z=-8.42, sob a margem nominal do terreno em z=-8.8, para reduzir fendas causadas pela rotação e perspetiva da câmara.
- Mantém-se o teste de profundidade OpenGL: o terreno que sobe acima de Y=0 tapa a água, evitando desenhar o mar por cima da terra.
- Mantidos os 25 bairros, os limites territoriais, o relevo oriental, a remoção das ligações viárias inferidas e os controlos de zoom/câmara.

Validação desta entrega: integridade do ZIP e inspeção estática do código. Não foi possível confirmar compilação Android nem comportamento no dispositivo; a versão não está aprovada para release até nova captura de ecrã.

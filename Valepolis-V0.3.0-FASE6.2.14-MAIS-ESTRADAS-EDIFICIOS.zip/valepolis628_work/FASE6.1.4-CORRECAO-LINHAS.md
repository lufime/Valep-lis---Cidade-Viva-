# Valepólis V0.3.0 — Fase 6.1.4 / BUILD 614

## Correção
As linhas escuras visíveis no mapa 3D eram uma rede viária **inferida automaticamente** ligando centros dos bairros mais próximos. O próprio código identificava a rede como proposta visual, não como traçado oficial.

Nesta fase, essa geração automática foi removida. Não são inventadas estradas nem alterados os 25 bairros. A rede viária só deverá ser introduzida quando existir uma matriz/ficheiro territorial validado. O zoom ampliado da Fase 6.1.3 é mantido.

## Validação feita
- ZIP de origem aberto sem erros.
- Alteração aplicada em `MainActivity.kt`.
- Confirmada a remoção do bloco que gerava `roadVertices` e `roadEdgeVertices`.
- Confirmados os rótulos BUILD 614.
- Compilação Android e teste no telemóvel **não executados** neste ambiente.

O gate de aprovação do 3D permanece bloqueado.

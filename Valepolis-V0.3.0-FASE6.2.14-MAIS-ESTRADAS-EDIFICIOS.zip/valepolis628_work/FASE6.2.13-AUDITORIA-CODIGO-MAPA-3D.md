# Valepólis V0.3.0 — FASE 6.2.13 / BUILD 632

## Alterações concretas
- O renderizador lê `architectural_identity_v030.json` e associa os perfis pelo ID de cada bairro.
- A geração urbana usa os polígonos `boundary_xz` dos 25 bairros e testa cada posição candidata com point-in-polygon; deixa de colocar edifícios por offsets fixos que podiam cair fora do bairro.
- A distribuição usa `buildings_per_cluster`, `min_floors`, `max_floors`, `low_rise_1_2_floor_ratio`, `footprint_base` e `base_color_rgb` do perfil de cada bairro.
- Os edifícios são excluídos do canal do estuário e de posições costeiras abaixo do nível de terreno.
- As malhas de edifícios e janelas são agrupadas por bairro para reduzir chamadas de desenho e carga no Android.
- Corrigido o tipo de retorno em `pointerDistance`: `sqrt` recebe `Double` explicitamente e regressa a `Float`.
- Incrementado `versionCode` Android para 301, sem alterar a versão funcional oficial V0.3.0.
- O `quality_gate_3d.json` permanece bloqueado; não se inventa evidência de aprovação.

## Auditoria estática realizada
- 25 bairros territoriais e 25 perfis arquitetónicos presentes, com IDs correspondentes.
- JSON e XML do projeto: sem erros de parsing.
- Teste geométrico independente: todos os bairros têm pontos candidatos interiores suficientes para a densidade-base definida nos perfis.
- A verificação de sintaxe Kotlin não encontrou erros de parsing. A compilação isolada com `kotlinc` não substitui Gradle/Android, porque o ambiente não inclui Android SDK nem dependências Android; os diagnósticos de referências Android não resolvidas são esperados nesse teste.

## Limites conhecidos — não declarar mapa real validado
- `limites_bairros_v030.json` identifica a geometria como Voronoi virtual e pendente de validação; não é levantamento geográfico real.
- A rede viária continua derivada dos centros de bairros, porque os dados disponíveis não fornecem uma rede oficial georreferenciada aprovada.
- O relevo real depende de `app/src/main/assets/data/terrain_reference_dem.asc`. Se não existir ou falhar a validação, o renderer usa relevo procedural, claramente reportado como tal.
- O renderizador OpenGL ainda não tem materiais PBR, texturas realistas, colisão de veículos/pessoas, nem teste de desempenho num dispositivo.
- Não foi possível executar build Android local nesta sessão: Gradle e Android SDK não estão instalados no ambiente. A APK e a validação visual permanecem pendentes no GitHub Actions/dispositivo.

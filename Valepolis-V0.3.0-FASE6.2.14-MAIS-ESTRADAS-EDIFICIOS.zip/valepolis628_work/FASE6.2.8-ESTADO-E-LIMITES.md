# Valepólis V0.3.0 — Fase 6.2.8

## O que esta entrega faz
- Atualiza os rótulos de diagnóstico do renderizador para Build 628.
- Mantém a correção de âmbito do estado `elevationDataLoaded`.
- Acrescenta workflow de integração do DEM que exige selecionar explicitamente o ZIP do projeto e o tile Copernicus.
- Corrige o diagnóstico GDAL para não usar `head` num pipeline com `pipefail`, evitando falha por SIGPIPE.
- Valida dimensões, linhas, colunas, NoData e variação de elevação antes de compilar.
- Publica APK Debug, grelha DEM, metadados e SHA256 apenas se a compilação terminar com sucesso.

## Limites importantes
- A grelha DEM não está incorporada nesta entrega porque o ambiente de preparação não tem acesso à Internet para a descarregar. O workflow tenta obtê-la no runner GitHub.
- O projeto ainda não define coordenadas geográficas oficiais para Valepólis. O tile deve corresponder à área de referência escolhida; não se deve usar um tile arbitrário como se fosse a geografia oficial da cidade.
- A integração DEM usa uma grelha de referência normalizada no terreno ficcional; não cria por si só uma rede viária real, edifícios fotogramétricos ou dados geográficos para os 25 bairros.
- A compilação e a validação visual no Android não foram executadas neste ambiente. Não declarar a APK aprovada antes de obter um workflow verde e verificar o APK no dispositivo.

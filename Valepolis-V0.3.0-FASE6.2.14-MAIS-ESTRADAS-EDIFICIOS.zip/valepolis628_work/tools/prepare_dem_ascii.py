#!/usr/bin/env python3
"""Convert a georeferenced DEM GeoTIFF to ESRI ASCII Grid for Valepólis.

Requires rasterio and numpy: python -m pip install rasterio numpy
Example:
  python tools/prepare_dem_ascii.py input_dem.tif app/src/main/assets/data/terrain_reference_dem.asc --size 256

The source DEM should cover a Portuguese reference landscape. The resulting raster is
resampled to a square grid for the fictional city's hybrid terrain and is not a claim
that Valepólis exists at the source coordinates.
"""
import argparse
from pathlib import Path
import numpy as np
import rasterio
from rasterio.enums import Resampling


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_tif")
    parser.add_argument("output_asc")
    parser.add_argument("--size", type=int, default=256)
    args = parser.parse_args()
    if args.size < 2 or args.size > 2048:
        raise SystemExit("--size tem de estar entre 2 e 2048")
    output = Path(args.output_asc)
    output.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(args.input_tif) as src:
        if src.crs is None:
            raise SystemExit("O GeoTIFF não tem CRS; não é seguro interpretar a grelha.")
        data = src.read(1, out_shape=(args.size, args.size), resampling=Resampling.bilinear).astype(np.float32)
        nodata = src.nodata if src.nodata is not None else -9999.0
        data[~np.isfinite(data)] = nodata
        valid = data > nodata + 0.001
        if not valid.any() or float(data[valid].max()) <= float(data[valid].min()):
            raise SystemExit("A área do DEM não contém cotas válidas suficientes.")
        # ASCII Grid expects first data row at the northern edge. Rasterio preserves
        # this row order after out_shape resampling.
        with output.open("w", encoding="ascii", newline="\n") as f:
            f.write(f"ncols {args.size}\n")
            f.write(f"nrows {args.size}\n")
            f.write("xllcorner 0\n")
            f.write("yllcorner 0\n")
            f.write("cellsize 1\n")
            f.write(f"NODATA_value {nodata:g}\n")
            for row in data:
                f.write(" ".join(f"{v:.3f}" for v in row) + "\n")
    print(f"Criado: {output} ({args.size}x{args.size}); confirme que a área cobre o relevo de referência pretendido.")

if __name__ == "__main__":
    main()

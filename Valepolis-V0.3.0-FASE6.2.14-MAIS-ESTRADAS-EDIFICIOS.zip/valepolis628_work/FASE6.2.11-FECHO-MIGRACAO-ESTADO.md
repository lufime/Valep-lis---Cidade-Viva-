# FASE 6.2.11 — Fecho da migração Android/DEM (estado verificável)

## O que foi consolidado nesta entrega

- Projeto Android Kotlin/Gradle mantido como destino da migração; não foram introduzidos ficheiros Godot nem referências a openDBC.
- Workflow principal `build.yml` usa o Android SDK pré-instalado no runner e solicita apenas `platform-tools`, `platforms;android-35` e `build-tools;35.0.0`; não solicita o pacote obsoleto `tools`.
- Validação do tile DEM por coordenadas numéricas com tolerância de 0,001° para acomodar o centro do primeiro píxel.
- O workflow `INTEGRAR-DEM-COPERNICUS.yml` usa a mesma regra de origem DEM em vez de uma expressão regular rígida.
- O gate 3D permanece `NOT_APPROVED`. Não se simulam evidências de dispositivo nem se declara o mapa aprovado sem testes reais.

## Validações efetuadas nesta preparação

- Sintaxe YAML dos workflows: validar com parser antes de commit.
- Estrutura Gradle Android presente: `settings.gradle.kts`, `build.gradle.kts`, `app/build.gradle.kts` e manifesto.
- Dados territoriais: os recursos JSON devem ser verificados pelo workflow no runner.
- Código Kotlin referencia `terrain_reference_dem.asc`; esta verificação estática não comprova a leitura/renderização.

## Bloqueios que dependem do runner/dispositivo

1. Executar o workflow no GitHub após substituir os workflows no repositório.
2. Confirmar que o runner instala os componentes Android SDK sem pedir `tools`.
3. Obter resultado real de `:app:assembleDebug` e artefacto APK não vazio.
4. Instalar o APK num Android físico/emulador e recolher capturas para validar relevo, costa/estuário/montanhas, bairros, estradas, zoom, câmara e desempenho.
5. Só depois preencher evidências e alterar o gate 3D; até lá, release continua bloqueado.

**Estado honesto:** migração do projeto para a estrutura Android Kotlin preparada; fecho integral ainda depende de build remoto bem-sucedido e validação visual Android. Este documento não afirma que o APK foi compilado.

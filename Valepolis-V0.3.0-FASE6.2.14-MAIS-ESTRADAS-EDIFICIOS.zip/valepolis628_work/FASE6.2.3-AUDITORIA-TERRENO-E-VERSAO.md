# Valepólis V0.3.0 — Fase 6.2.3

## Alterações efetivas nesta revisão
- Uniformizada a identificação da compilação para `BUILD 623` no cabeçalho e nas mensagens do renderizador.
- Corrigida a mensagem de erro OpenGL que ainda identificava a `BUILD 614`.
- Atualizada a descrição da fase para declarar explicitamente que o relevo continua procedural e que não existe DEM real integrado/validado.
- Atualizado o registo do renderizador para indicar `terreno=procedural-sem-DEM`.

## Limitações confirmadas
- `terrainHeight()` continua a gerar cotas por funções matemáticas; não lê um raster de elevação.
- A malha principal continua a ser gerada proceduralmente.
- A faixa do estuário continua a ser uma malha própria.
- O projeto não inclui ainda um DEM recortado, transformado e validado para a geografia fictícia de Valepólis.
- Não foi possível confirmar compilação Android nesta revisão: o projeto não inclui `gradlew`/Gradle Wrapper e não foi executada uma compilação Android SDK nesta sessão.
- Não foi executado teste visual no dispositivo. Portanto, nenhum teste de APK está marcado como aprovado.

## Próximo bloqueio técnico real
Valepólis é uma cidade fictícia. Um DEM de Portugal pode servir como referência de formas de relevo, mas não deve ser colocado diretamente como se fosse a geografia real da cidade. É necessário selecionar/recortar uma área de referência, adaptar a elevação à matriz territorial aprovada, exportar uma grelha local compacta (por exemplo, JSON binário ou grelha Float32) e ligar essa grelha à função de amostragem do terreno. O recurso final tem de ficar dentro de `app/src/main/assets/` para funcionamento offline.

Fonte pública consultada para o DEM: Copernicus DEM GLO-90 (90 m, acesso público) e documentação de acesso do Copernicus Data Space Ecosystem. O GLO-30 tem requisitos de acesso adicionais e não foi descarregado nem integrado nesta revisão.

# Valepólis V0.3.0 — Fase 6.2.0: costa, nível do mar e zoom

Alterações efetivas em `MainActivity.kt`:
- A altitude do terreno, incluindo a crista oriental, passa a nascer progressivamente para o interior a partir da cota costeira norte zero.
- O plano do mar foi alargado para ficar sob a margem e fora do limite visível do terreno, reduzindo cortes/fendas ao rodar a câmara.
- Foi adicionada uma faixa costeira estreita que acompanha a função de altitude do terreno, com ligeiro afastamento para evitar conflito de profundidade.
- Zoom mais próximo (distância mínima 4,8), passos de zoom maiores e campo de visão de 36 graus para tornar a cidade mais legível.
- A cadeia montanhosa já não pode elevar-se abruptamente na linha de costa norte.

Limites honestos: esta alteração corrige geometria costeira e enquadramento; não transforma ainda os volumes procedurais em modelos arquitetónicos finais nem cria uma rede viária sem dados aprovados. Não foi possível confirmar compilação Android nem executar no dispositivo neste ambiente. O APK Release deve continuar bloqueado até teste no telemóvel.

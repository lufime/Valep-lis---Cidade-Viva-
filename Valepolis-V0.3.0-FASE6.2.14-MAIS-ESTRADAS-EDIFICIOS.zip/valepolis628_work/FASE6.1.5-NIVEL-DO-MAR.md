# Valepólis V0.3.0 — Fase 6.1.5: nível do mar

## Alterações
- O mar norte prolonga-se ligeiramente sob a margem costeira para evitar uma fenda visual.
- Mar e estuário usam a mesma cota de água (`seaLevel = 0.012f`), em vez de alturas independentes.
- A rede viária inferida continua removida.
- Não foram alterados os polígonos dos 25 bairros nem os dados territoriais JSON.

## Limites de validação
O ZIP foi validado estruturalmente e os dados territoriais foram comparados com a entrada. Não foi possível executar uma compilação Android nem testar o renderizador num dispositivo nesta sessão. A cota é uma correção geométrica visual inicial; deve ser confirmada no telemóvel, sobretudo na margem norte e na ligação do estuário ao mar. O relevo continua ilustrativo, não baseado em levantamento topográfico real.

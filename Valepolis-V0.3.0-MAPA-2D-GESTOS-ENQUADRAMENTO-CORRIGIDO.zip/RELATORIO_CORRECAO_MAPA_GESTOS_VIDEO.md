# Correção do mapa 2D após análise do vídeo

## Problemas observados
- O mapa saltava de posição e escala durante gestos.
- O território podia sair quase totalmente da área visível.
- A alternância entre um e dois dedos podia provocar deslocamentos abruptos.

## Correções
- Conversão das coordenadas de toque para o espaço local do controlo.
- Limitação do arrasto com base na dimensão do território e no zoom atual.
- Reposição do estado de arrasto ao passar de dois dedos para um dedo.
- Limitação do deslocamento para que o mapa não desapareça por completo.
- Recalcular limites após cada alteração de zoom.

## Validação
- Integridade do ZIP confirmada.
- Godot e APK não foram executados nesta sessão; executar o PRE-FLIGHT antes de instalar.

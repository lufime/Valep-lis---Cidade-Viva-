# Aperfeiçoamento do mapa 2D — Valepólis V0.3.0

## Alterações
- Etiquetas dos bairros passam a ser centradas e limitadas à área visível para reduzir cortes nas margens.
- Fonte responsiva limitada a 10–15 px para equilibrar leitura e densidade.
- Interação do renderizador ativada: zoom com roda do rato, arrasto com rato, deslocação por toque e zoom por pinça com dois dedos.
- O mapa continua a usar os limites territoriais de `data/limites_bairros_v030.json`; não foi recuperada a imagem antiga.
- O painel continua responsivo e mantém a proporção geográfica do território.

## Limitação importante
A posição inicial do jogador no renderizador continua definida pelo centro territorial existente (-3, -3). O código do projeto não expõe neste ponto uma coordenada dinâmica X/Z inequívoca da personagem; por isso, não inventei uma ligação à simulação. A ligação ao movimento real deve ser feita quando a variável oficial de posição do jogador estiver identificada.

## Validação
- Integridade do ZIP confirmada.
- Godot e APK não foram executados nesta sessão. É obrigatório executar o PRE-FLIGHT e testar gestos/etiquetas no Android.

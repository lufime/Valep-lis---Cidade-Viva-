# Valepólis V0.3.0 — implementação da progressão persistente

## Alterações reais neste pacote
- O runtime passa a recuperar o estado da campanha de `user://valepolis_campaign_v030.json`.
- O estado inclui temporada, episódio, episódios concluídos, decisões registadas e conclusão da campanha.
- `complete_current_episode()` regista o episódio concluído, guarda o progresso e avança a sequência de 20 temporadas × 10 episódios.
- `get_campaign_status()` expõe o estado para a interface e para os testes.
- `is_episode_unlocked()` permite consultar a disponibilidade de episódios.
- `advance_episode()` usa agora a transição de conclusão persistente, em vez de alterar apenas os números em memória.
- Mantida a correção do `SubViewportContainer` com `stretch=true`, sem alterar manualmente o tamanho do `SubViewport`.

## Limites de validação
- O ZIP foi verificado estruturalmente e os contratos JSON foram auditados por script.
- Não foi possível executar o editor/runtime Godot nem testar a APK Android neste ambiente; por isso este pacote não deve ser rotulado como lançamento certificado.
- A conclusão do episódio é uma transição de campanha disponível ao runtime; os objetivos narrativos e condições específicas de todos os 200 episódios ainda necessitam de ligação às ações concretas do jogo e de testes funcionais.

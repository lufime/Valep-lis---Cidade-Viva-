# Fase 6.1.7 — Rede viária conforme regras territoriais (BUILD 617)

## Implementação
- Rede local mais contida: até dois vizinhos próximos por bairro, para reduzir ligações arbitrárias.
- Eixos estruturantes adicionais orientados ao núcleo central Nexora quando a distância é funcional.
- Representação visual explícita das duas travessias ocidentais: Ponte da União (principal) e Ponte do Horizonte (secundária).
- Mantidos os 25 bairros e os dados territoriais de origem.
- Costa e praias a norte, rio/estuário a oeste e montanhas/Pedravora a este permanecem como referências geográficas do cenário.

## Limite de validação
O repositório não contém neste ZIP uma geometria viária georreferenciada aprovada rua a rua. Por isso, a rede é uma implantação visual hierárquica coerente com as regras territoriais, não um cadastro definitivo. A posição das pontes é funcional/ilustrativa e deverá ser afinada quando existir traçado cartográfico aprovado. Não foram inventados nomes de ruas.

## Testes
ZIP e JSON territorial: verificação estrutural. Compilação Android e teste no dispositivo: pendentes; esta fase não autoriza RELEASE.

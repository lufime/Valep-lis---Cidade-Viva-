# Correção PRE-FLIGHT — mapa 2D

## Alterações
- Removida a exigência de `systems/city_3d.gd` nas auditorias PRE-FLIGHT.
- Substituídas verificações de addon de terreno e geração procedural 3D por verificação estática do painel de mapa 2D e do catálogo de 25 bairros.
- Atualizado o workflow para não executar nem exigir gates de terreno/recursos 3D.
- Adaptadas as auditorias de projeto, estradas e mapa para não falharem apenas pela ausência dos ficheiros 3D.
- Mantidas as verificações de importação Godot, testes funcionais e exportação/assinatura da APK.

## Limites
Esta alteração corrige dependências obsoletas do PRE-FLIGHT; não prova que o mapa 2D representa visualmente todos os bairros nem que os botões funcionam. A compilação Godot e exportação Android continuam a ter de ser executadas no GitHub Actions. Nenhum resultado de compilação é declarado como aprovado neste pacote.

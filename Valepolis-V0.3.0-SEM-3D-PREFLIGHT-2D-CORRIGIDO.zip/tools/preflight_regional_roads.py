#!/usr/bin/env python3
"""Auditoria estática do mapa 2D; não afirma validar circulação física."""
from pathlib import Path
import json, sys
root=Path(__file__).resolve().parents[1]
scene=(root/"Main.tscn").read_text(encoding="utf-8")
data=json.loads((root/"bairros_valepolis.json").read_text(encoding="utf-8"))
names=[x.get("name") for x in data.get("neighborhoods",[])]
checks={
 "painel do mapa 2D presente": 'name="MapBody"' in scene and 'name="Map"' in scene,
 "catálogo contém 25 bairros distintos": len(names)==25 and len(set(names))==25,
 "cena principal sem nós 3D": "Camera3D" not in scene and "Node3D" not in scene and "SubViewport3D" not in scene,
}
failed=[]
for label,ok in checks.items():
 print(("PASS|" if ok else "FAIL|")+label)
 if not ok: failed.append(label)
if failed:
 print("RESULT=FAIL"); sys.exit(1)
print("NOTE|Verificação estática apenas. Não valida visualmente estradas, pontes nem movimento em execução.")
print("RESULT=PASS_STATIC_ONLY")

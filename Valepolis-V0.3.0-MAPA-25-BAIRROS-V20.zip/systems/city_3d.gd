extends Node3D
class_name ValepolisCity3D

const NEIGHBORHOODS := [
    "Marévia", "Brisamar", "Avelora", "Rivéria", "Nexora", "Altavira", "Lúmora", "Florávia",
    "Pedrália", "Montélia", "Valeora", "Fontélia", "Silvéria", "Portávia", "Lacéria", "Ventúria",
    "Olivéria", "Ribeora", "Solária", "Terrávia", "Altória", "Marivora", "Verdelis", "Estúria", "Pedravora"
]
const POSITIONS := [
    Vector2(-25,-36), Vector2(-5,-39), Vector2(23,25), Vector2(-39,-10), Vector2(-3,-3),
    Vector2(16,-8), Vector2(7,8), Vector2(-20,15), Vector2(28,20), Vector2(31,-31),
    Vector2(13,12), Vector2(-12,5), Vector2(34,14), Vector2(-35,-24), Vector2(14,29),
    Vector2(39,-6), Vector2(2,15), Vector2(-38,8), Vector2(-18,29), Vector2(22,34),
    Vector2(40,8), Vector2(-31,-29), Vector2(31,30), Vector2(-40,26), Vector2(40,30)
]

var camera: Camera3D
var camera_target := Vector3.ZERO
var yaw := 14.0
var pitch := -48.0
var distance := 135.0
var _external_zoom := 1.0
var dragging := false
var last_mouse := Vector2.ZERO
var touch_points: Dictionary = {}
var last_touch_distance := 0.0
var _last_touch_centroid := Vector2.ZERO
var _architectural_profiles: Dictionary = {}
var _addresses_by_neighborhood: Dictionary = {}
var _streets_by_neighborhood: Dictionary = {}
var road_network: ValepolisRoadNetwork = ValepolisRoadNetwork.new()
var _road_waypoints_by_edge: Dictionary = {}
const REGIONAL_ROUTE_GRAPH := {
    "Valepólis": ["Ponte da União", "Ponte do Horizonte", "Vilas e arredores"],
    "Ponte da União": ["Valepólis", "Santo André do Vale", "Vilas e arredores"],
    "Ponte do Horizonte": ["Valepólis", "Portela do Sul", "Santo André do Vale", "Vilas e arredores"],
    "Santo André do Vale": ["Ponte da União", "Ponte do Horizonte", "Portela do Sul", "Vilas e arredores"],
    "Portela do Sul": ["Ponte do Horizonte", "Santo André do Vale", "Vilas e arredores"],
    "Vilas e arredores": ["Valepólis", "Ponte da União", "Ponte do Horizonte", "Santo André do Vale", "Portela do Sul"]
}
var _road_material: Material
var _valepolis_terrain: Node3D
var player_character: Node3D
var player_world_position := Vector3(-3.75, 0.0, -3.75)
var player_move_speed := 7.0
var player_display_name := "VOCÊ"
var player_profession := ""
var _player_label: Label3D
var _player_marker: MeshInstance3D
var _ambient_agents: Array[Dictionary] = []
var _ambient_clock: float = 0.0
var _traffic_hour: int = 8
var _traffic_weekend: bool = false
var _traffic_profile: String = "normal"
const WORLD_EXPANSION_FACTOR := 1.45

func _ready() -> void:
    _create_valepolis_terrain()
    _load_architectural_profiles()
    _load_address_registry()
    _build_world()
    _bind_companies_to_existing_buildings()
    _build_registered_installations()
    _create_player_character()
    _create_camera()
    _create_light()
    _create_atmosphere()
    set_traffic_hour(_traffic_hour, false)
    # Entrada inicial: mostrar a cidade completa e permitir reconhecer os 25 bairros.
    show_city_overview()

func _create_valepolis_terrain() -> void:
    # Addon próprio Valepólis Terrain: sem extensões nativas externas.
    var terrain_script: Script = preload("res://addons/valepolis_terrain/terrain_generator.gd")
    _valepolis_terrain = terrain_script.new() as Node3D
    _valepolis_terrain.name = "Relevo_Valepolis"
    add_child(_valepolis_terrain)

func _ground_height(x: float, z: float) -> float:
    # As coordenadas externas usam a escala final do mundo. Consultar o gerador
    # na coordenada-base e escalar a altura evita que veículos/peões que se
    # movem depois da construção afundem ou flutuem sobre o terreno ampliado.
    if is_instance_valid(_valepolis_terrain) and _valepolis_terrain.has_method("height_at"):
        var base_x := x / WORLD_EXPANSION_FACTOR
        var base_z := z / WORLD_EXPANSION_FACTOR
        return float(_valepolis_terrain.call("height_at", base_x, base_z)) * WORLD_EXPANSION_FACTOR
    return 0.0

func _load_address_registry() -> void:
    var path := "res://data/enderecamento_valepolis.json"
    if not FileAccess.file_exists(path):
        push_warning("Cadastro de endereços de Valepólis não encontrado: " + path)
        return
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        push_warning("Não foi possível abrir o cadastro de endereços de Valepólis.")
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary):
        push_warning("Cadastro de endereços inválido.")
        return
    for street in parsed.get("streets", []):
        var neighborhood := str(street.get("bairro", ""))
        if not _streets_by_neighborhood.has(neighborhood):
            _streets_by_neighborhood[neighborhood] = []
        _streets_by_neighborhood[neighborhood].append(street)
    for address in parsed.get("addresses", []):
        var neighborhood := str(address.get("bairro", ""))
        if not _addresses_by_neighborhood.has(neighborhood):
            _addresses_by_neighborhood[neighborhood] = []
        _addresses_by_neighborhood[neighborhood].append(address)


func _load_architectural_profiles() -> void:
    var path := "res://data/architectural_identity_v030.json"
    if not FileAccess.file_exists(path):
        push_warning("Perfis arquitetónicos V0.3.0 não encontrados; a cidade usa valores predefinidos.")
        return
    var file := FileAccess.open(path, FileAccess.READ)
    if file == null:
        push_warning("Não foi possível abrir os perfis arquitetónicos V0.3.0.")
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    if not (parsed is Dictionary):
        push_warning("Perfis arquitetónicos V0.3.0 inválidos.")
        return
    for item in parsed.get("neighborhoods", []):
        if item is Dictionary and item.has("name"):
            _architectural_profiles[str(item["name"])] = item

func _mat(color: Color, roughness := 0.8) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, name := "Block") -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := BoxMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.position = pos
    n.material_override = material
    parent.add_child(n)
    return n

func _plane(parent: Node3D, pos: Vector3, size: Vector2, material: Material, name := "Surface") -> MeshInstance3D:
    var n := MeshInstance3D.new()
    n.name = name
    var mesh := PlaneMesh.new()
    mesh.size = size
    n.mesh = mesh
    n.position = pos
    n.material_override = material
    parent.add_child(n)
    return n

func _label(text_value: String, pos: Vector3) -> void:
    var l := Label3D.new()
    l.text = text_value
    l.position = pos
    # Aumenta a legibilidade dos nomes à distância na vista geral do mapa.
    # O texto mantém billboard para continuar virado para a câmara.
    l.font_size = 40
    l.modulate = Color(0.97, 0.99, 1.0)
    l.outline_size = 12
    l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    l.no_depth_test = true
    l.pixel_size = 0.006
    l.add_to_group("valepolis_map_labels")
    add_child(l)



func _is_reserved_road_corridor(point: Vector2, clearance: float = 2.0) -> bool:
    # Reserva os eixos viários antes da colocação de objetos. A rede lógica não
    # basta: os geradores também têm de respeitar a geometria das ruas.
    # Avenidas de 3/4 faixas e corredores de autoestrada: reservar a largura
    # total da plataforma, bermas e faixa de segurança antes de gerar obstáculos.
    if absf(point.x + 1.0) < (5.0 + clearance): # Avenida Central, 4 faixas
        return true
    if absf(point.y - 4.0) < (4.7 + clearance): # Avenida Transversal, 4 faixas
        return true
    if absf(point.y + 20.0) < (3.5 + clearance) and point.x >= -51.0 and point.x <= -2.0:
        return true
    if absf(point.y - 24.0) < (3.5 + clearance) and point.x >= 1.0 and point.x <= 49.0:
        return true
    # Autoestrada periférica oriental e variante sul.
    if absf(point.x - 51.0) < (6.2 + clearance) and point.y >= -48.0 and point.y <= 49.0:
        return true
    if absf(point.y - 48.0) < (6.2 + clearance) and point.x >= -48.0 and point.x <= 53.0:
        return true
    # Cruzamentos locais reservados em cada bairro, incluindo passeios.
    for center_value in POSITIONS:
        var center: Vector2 = center_value
        if absf(point.y - (center.y + 5.0)) < (1.25 + clearance) and absf(point.x - center.x) < 11.5:
            return true
        if absf(point.x - (center.x + 5.0)) < (1.25 + clearance) and absf(point.y - center.y) < 11.5:
            return true
        if absf(point.y - (center.y + 8.0)) < (1.4 + clearance) and absf(point.x - center.x) < 11.5:
            return true
    return false

func _road_safe_position(point: Vector2, clearance: float = 2.0) -> bool:
    return not _is_reserved_road_corridor(point, clearance)

func _building_cluster(center: Vector2, index: int) -> void:
    var base := Node3D.new()
    base.name = "Bairro_%02d" % (index + 1)
    add_child(base)
    var neighborhood_name: String = NEIGHBORHOODS[index]
    var profile: Dictionary = _architectural_profiles.get(neighborhood_name, {})
    # Pequena praça/pavimento-base de cada núcleo, com contorno discreto.
    var plaza_color := Color(0.25, 0.29, 0.28) if index % 4 == 0 else Color(0.30, 0.32, 0.31)
    var plaza_x := center.x + 1.0
    var plaza_z := center.y + 1.0
    var plaza_y := _ground_height(plaza_x, plaza_z) + 0.025
    _plane(base, Vector3(plaza_x, plaza_y, plaza_z), Vector2(22.0, 22.0), _mat(plaza_color), "Pavimento_Bairro_%02d" % (index + 1))
    var rgb: Array = profile.get("base_color_rgb", [0.20 + float(index % 5) * 0.018, 0.25 + float(index % 4) * 0.018, 0.31 + float(index % 3) * 0.02])
    var district_mat := _mat(Color(float(rgb[0]), float(rgb[1]), float(rgb[2])))
    var min_floors: int = int(profile.get("min_floors", 2))
    var max_floors: int = int(profile.get("max_floors", 30))
    var footprint_base: float = float(profile.get("footprint_base", 2.5))
    var building_count: int = clampi(int(profile.get("buildings_per_cluster", 12)), 8, 12)
    # Gerador procedural existente preservado; o perfil do bairro ajusta cor, escala e alturas.
    for i in range(building_count):
        var a := float(i) * 0.49 + float(index) * 0.21
        var r := 7.2 + float((index + i) % 6) * 1.45
        var px := center.x + cos(a) * r
        var pz := center.y + sin(a) * r
        # Não criar edifícios dentro dos corredores de circulação reservados.
        if not _road_safe_position(Vector2(px, pz), 3.2):
            continue
        var p := Vector3(px, _ground_height(px, pz), pz)
        var floor_span: int = max(1, max_floors - min_floors + 1)
        var floor_count: int = min_floors + ((index * 7 + i * 3) % floor_span)
        # Variação de volumetria por bairro: torres no núcleo, blocos médios
        # nas zonas mistas e volumes baixos nas zonas verdes/costeiras.
        var h := 2.6 + float(floor_count) * 0.92
        if neighborhood_name in ["Nexora", "Altavira", "Lúmora"]:
            h *= 1.12 if i % 3 == 0 else 1.0
        elif neighborhood_name in ["Marévia", "Brisamar", "Florávia", "Silvéria", "Verdelis", "Pedravora"]:
            h *= 0.68 if i % 3 != 0 else 0.82
        var width_factor: float = [0.82, 1.0, 1.18, 0.92][(index + i * 3) % 4]
        var depth_factor: float = [1.12, 0.86, 1.0][(index * 2 + i) % 3]
        var footprint_x := maxf(2.0, (footprint_base + float((index + i) % 3) * 0.55) * width_factor)
        var footprint_z := maxf(2.0, (footprint_base + float((index + i) % 3) * 0.55) * depth_factor)
        var building := _box(base, p + Vector3(0,h/2.0,0), Vector3(footprint_x, h, footprint_z), district_mat, "Edificio_%02d_%02d" % [index, i])
        var roof_color := Color(0.16, 0.20, 0.27) if index % 3 == 0 else (Color(0.66, 0.63, 0.57) if index % 3 == 1 else Color(0.78, 0.80, 0.79))
        var roof_mat := _mat(roof_color)
        var roof_h := 0.22 if floor_count >= 5 else 0.14
        _box(base, p + Vector3(0, h + roof_h * 0.5, 0), Vector3(footprint_x + 0.18, roof_h, footprint_z + 0.18), roof_mat, "Cobertura_%02d_%02d" % [index, i])
        var window_mat := _mat(Color(0.42, 0.70, 0.84), 0.24)
        var trim_mat := _mat(Color(0.82, 0.84, 0.82), 0.68)
        if h >= 4.0:
            var rows := mini(7, maxi(2, int(floor_count / 2)))
            var cols := 2 if footprint_x < 4.0 else 3
            for wr in range(rows):
                var wy := p.y + 1.35 + float(wr) * maxf(1.25, (h - 2.0) / float(rows))
                if wy < p.y + h - 0.55:
                    for wc in range(cols):
                        var wx := px - footprint_x * 0.30 + float(wc) * footprint_x * 0.30
                        _box(base, Vector3(wx, wy, pz + footprint_z * 0.5 + 0.018), Vector3(0.28, 0.42, 0.035), window_mat, "JanelaF_%02d_%02d_%02d_%02d" % [index, i, wr, wc])
                    _box(base, Vector3(px - footprint_x * 0.5 - 0.018, wy, pz), Vector3(0.035, 0.38, footprint_z * 0.28), window_mat, "JanelaL_%02d_%02d_%02d" % [index, i, wr])
            # Varandas discretas em edifícios residenciais de altura média.
            if floor_count >= 3 and floor_count <= 10 and i % 2 == 0:
                for balcony in range(mini(3, rows)):
                    var by := p.y + 2.0 + float(balcony) * 2.4
                    if by < p.y + h - 0.5:
                        _box(base, Vector3(px, by, pz + footprint_z * 0.5 + 0.14), Vector3(footprint_x * 0.72, 0.07, 0.28), trim_mat, "Varanda_%02d_%02d_%02d" % [index, i, balcony])
        # Entrada e pala de acesso para que os blocos não pareçam cubos vazios.
        if i % 2 == 0:
            _box(base, Vector3(px, p.y + 0.72, pz + footprint_z * 0.5 + 0.025), Vector3(0.65, 1.35, 0.06), trim_mat, "Entrada_%02d_%02d" % [index, i])
        var district_addresses: Array = _addresses_by_neighborhood.get(NEIGHBORHOODS[index], [])
        if not district_addresses.is_empty():
            var address: Dictionary = district_addresses[i % district_addresses.size()]
            building.set_meta("address_id", address.get("id", ""))
            building.set_meta("bairro", address.get("bairro", NEIGHBORHOODS[index]))
            building.set_meta("arruamento", address.get("arruamento", ""))
            building.set_meta("numero_porta", address.get("numero_porta", 0))
            building.set_meta("codigo_postal", address.get("codigo_postal", ""))
            building.set_meta("morada_completa", address.get("morada_completa", ""))

    # Nome elevado para ser legível acima dos quarteirões e identificar o bairro
    # na vista geral. Não altera coordenadas, moradas nem distribuição territorial.
    var label_height := maxf(14.0, _ground_height(center.x, center.y) + 10.0)
    _label(NEIGHBORHOODS[index].to_upper(), Vector3(center.x, label_height, center.y))
    # Separar etiquetas de bairros das etiquetas de ruas, empresas e instalações.
    var neighborhood_labels := get_tree().get_nodes_in_group("valepolis_map_labels")
    if not neighborhood_labels.is_empty():
        var neighborhood_label: Node = neighborhood_labels[neighborhood_labels.size() - 1]
        neighborhood_label.add_to_group("valepolis_neighborhood_labels")

func _neighborhood_landmark(center: Vector2, neighborhood_name: String, index: int) -> void:
    # Marco visual 3D simples e distinto por bairro; não substitui a arquitetura
    # procedural nem atribui identidades culturais ainda pendentes.
    var stone := _mat(Color(0.48, 0.47, 0.43))
    var civic := _mat(Color(0.68, 0.70, 0.72))
    var green := _mat(Color(0.13, 0.34, 0.18))
    var water := _mat(Color(0.04, 0.31, 0.46), 0.32)
    var warm := _mat(Color(0.72, 0.52, 0.27))
    var px := center.x + 8.5
    var pz := center.y - 7.5
    var gy := _ground_height(px, pz)
    match neighborhood_name:
        "Nexora":
            _box(self, Vector3(px, gy + 10.0, pz), Vector3(3.5, 20.0, 3.5), civic, "Marco_Centro_Nexora")
        "Altavira":
            _box(self, Vector3(px, gy + 3.0, pz), Vector3(8.0, 6.0, 6.0), civic, "Edificio_Administrativo_Altavira")
        "Rivéria", "Ribeora":
            _box(self, Vector3(px, gy + 0.25, pz), Vector3(9.0, 0.5, 3.0), water, "Cais_" + neighborhood_name)
        "Marévia", "Brisamar", "Marivora":
            _box(self, Vector3(px, gy + 0.7, pz), Vector3(7.0, 1.4, 2.0), warm, "Passeio_Costeiro_" + neighborhood_name)
        "Montélia", "Pedravora", "Altória":
            _box(self, Vector3(px, gy + 2.2, pz), Vector3(5.0, 4.4, 5.0), stone, "Marco_Rochoso_" + neighborhood_name)
        "Lúmora":
            _box(self, Vector3(px, gy + 2.5, pz), Vector3(7.0, 5.0, 6.0), civic, "Polo_Conhecimento_Lumora")
        "Florávia", "Silvéria", "Verdelis":
            _plane(self, Vector3(px, gy + 0.06, pz), Vector2(8.0, 7.0), green, "Jardim_" + neighborhood_name)
            for t in range(3):
                _tree(Vector3(px - 2.0 + float(t) * 2.0, _ground_height(px - 2.0 + float(t) * 2.0, pz + 1.5), pz + 1.5), 0.7)
        "Pedrália", "Terrávia":
            _box(self, Vector3(px, gy + 2.0, pz), Vector3(5.5, 4.0, 5.5), stone, "Marco_Pedra_" + neighborhood_name)
        "Valeora", "Fontélia":
            _box(self, Vector3(px, gy + 0.8, pz), Vector3(3.0, 1.6, 3.0), water, "Fonte_Publica_" + neighborhood_name)
        "Portávia", "Estúria":
            _box(self, Vector3(px, gy + 1.0, pz), Vector3(8.0, 2.0, 5.0), stone, "Infraestrutura_Logistica_" + neighborhood_name)
        "Lacéria":
            _plane(self, Vector3(px, gy + 0.08, pz), Vector2(8.0, 5.0), water, "Lago_Laceria")
        "Ventúria":
            _box(self, Vector3(px, gy + 4.0, pz), Vector3(0.7, 8.0, 0.7), civic, "Torre_Energetica_Venturia")
            _box(self, Vector3(px, gy + 7.5, pz), Vector3(5.0, 0.35, 0.35), civic, "Pala_Venturia")
        "Olivéria":
            _box(self, Vector3(px, gy + 0.8, pz), Vector3(7.0, 1.6, 5.0), warm, "Mercado_Oliveria")
        "Solária":
            _box(self, Vector3(px, gy + 0.5, pz), Vector3(9.0, 1.0, 7.0), green, "Campo_Desportivo_Solaria")
        "Avelora":
            _box(self, Vector3(px, gy + 1.5, pz), Vector3(7.0, 3.0, 6.0), civic, "Nova_Construcao_Avelora")
        _:
            _box(self, Vector3(px, gy + 1.2, pz), Vector3(4.0, 2.4, 4.0), civic, "Marco_" + str(index + 1))

func _tree(pos: Vector3, scale_factor: float = 1.0) -> void:
    var trunk := _mat(Color(0.25,0.16,0.09))
    var leaves := _mat(Color(0.08,0.30,0.16))
    _box(self, pos + Vector3(0,1.0*scale_factor,0), Vector3(0.35,2.0*scale_factor,0.35), trunk, "Tronco")
    var crown := _box(self, pos + Vector3(0,2.5*scale_factor,0), Vector3(2.0*scale_factor,2.0*scale_factor,2.0*scale_factor), leaves, "Copa")
    crown.rotation_degrees = Vector3(0,45,0)

func _park(center: Vector2, index: int) -> void:
    var grass := _mat(Color(0.12,0.36,0.18))
    var park_y := _ground_height(center.x, center.y)
    _plane(self, Vector3(center.x, park_y + 0.04, center.y), Vector2(11,8), grass, "Parque_%02d" % index)
    for i in range(5):
        var tx := center.x - 4.0 + i * 2.0
        var tz := center.y - 2.2 + float((i+index)%3)
        if _road_safe_position(Vector2(tx, tz), 2.0):
            _tree(Vector3(tx, _ground_height(tx, tz), tz), 0.75)

func _build_neighborhood_details(center: Vector2, index: int, neighborhood_name: String) -> void:
    # Elementos próprios gerados por código: árvores, passeios, mobiliário, carros e peões.
    var sidewalk := _mat(Color(0.48, 0.49, 0.46), 0.92)
    var asphalt := _mat(Color(0.07, 0.08, 0.09), 0.98)
    var car_colors := [Color(0.72,0.12,0.10), Color(0.10,0.28,0.58), Color(0.78,0.79,0.76), Color(0.12,0.14,0.15), Color(0.76,0.57,0.12)]
    # Passeios baixos ao longo das ruas locais.
    for side: float in [-1.0, 1.0]:
        var sx: float = center.x + float(side) * 5.8
        var sz: float = center.y + 8.0
        _box(self, Vector3(sx, _ground_height(sx, sz) + 0.12, sz), Vector3(0.65,0.22,15.0), sidewalk, "Passeio_%02d_%s" % [index, str(side)])
    # Árvores distribuídas em pequenas bolsas verdes fora do centro dos edifícios.
    for t in range(9):
        var angle := float(t) * 2.399 + float(index) * 0.31
        var radius := 8.8 + float(t % 3) * 1.25
        var tx := center.x + cos(angle) * radius
        var tz := center.y + sin(angle) * radius
        if absf(tx) < 47.0 and absf(tz) < 46.0 and not (absf(tx - center.x) < 3.2 and absf(tz - center.y) < 3.2) and _road_safe_position(Vector2(tx, tz), 2.2):
            _tree(Vector3(tx, _ground_height(tx, tz), tz), 0.65 + float(t % 3) * 0.12)
    # Veículos com carroçaria, tejadilho, janelas e rodas geométricas próprias.
    # Quatro veículos por bairro, distribuídos por ambos os lados da malha local.
    # O percurso mantém-se no corredor viário; a seleção horária não os elimina todos.
    for c in range(4):
        var cx := center.x + (-6.2 if c % 2 == 0 else 6.2)
        var cz := center.y + 5.0 + float(c) * 1.0
        # Os veículos são obstáculos móveis destinados aos corredores viários;
        # não aplicar _road_safe_position(), que por definição rejeita as ruas.
        # Confirmar antes que o ponto está dentro da área jogável.
        if absf(cx) > 90.0 or absf(cz) > 90.0:
            continue
        var vehicle := Node3D.new()
        vehicle.name = "Veiculo_%02d_%02d" % [index, c]
        add_child(vehicle)
        # O ponto de partida e a altura são derivados do mesmo waypoint.
        # Isto evita calcular a altura num ponto e colocar o veículo noutro.
        var lane_z := center.y + 5.0 + float(c % 2) * 3.0
        var lane_x_offset := 5.0 + float(c / 2) * 1.2
        var vehicle_path: Array[Vector3] = [
            Vector3(center.x - lane_x_offset, 0.0, lane_z),
            Vector3(center.x + lane_x_offset, 0.0, lane_z),
            Vector3(center.x + lane_x_offset, 0.0, lane_z - 1.6),
            Vector3(center.x - lane_x_offset, 0.0, lane_z - 1.6)
        ]
        var start_point: Vector3 = vehicle_path[0]
        vehicle.position = Vector3(start_point.x, _ground_height(start_point.x, start_point.z) + 0.18, start_point.z)
        _ambient_agents.append({
            "node": vehicle,
            "kind": "vehicle",
            "path": vehicle_path,
            "target": 1,
            "speed": 3.0 + float((index + c) % 3) * 0.45,
            "base_speed": 3.0 + float((index + c) % 3) * 0.45,
            "phase": float(index * 3 + c) * 0.37,
            "traffic_index": index * 4 + c
        })
        var body_mat := _mat(car_colors[(index + c) % car_colors.size()], 0.38)
        var glass := _mat(Color(0.18,0.36,0.46), 0.22)
        _box(vehicle, Vector3.ZERO, Vector3(1.55,0.55,2.7), body_mat, "Carrocaria")
        _box(vehicle, Vector3(0,0.37,-0.12), Vector3(1.18,0.38,1.22), glass, "Vidros")
        var rubber := _mat(Color(0.025,0.028,0.03))
        for wx in [-0.78,0.78]:
            for wz in [-0.82,0.82]:
                var wheel := MeshInstance3D.new()
                var wm := CylinderMesh.new(); wm.top_radius=0.22; wm.bottom_radius=0.22; wm.height=0.14
                wheel.mesh=wm; wheel.material_override=rubber
                wheel.position=Vector3(wx,-0.18,wz); wheel.rotation_degrees.z=90
                vehicle.add_child(wheel)
    # Peões estilizados de baixa geometria, colocados junto dos passeios.
    # Pool visual de habitantes por bairro. São representantes da população simulada,
    # não o total demográfico da cidade; o número visível varia com hora e rotina.
    for person_i in range(6):
        var lane_offset := float(person_i % 3) * 1.8
        var side_offset := float(person_i / 3) * 1.1
        var px := center.x - 5.2 + lane_offset
        var pz := center.y + 5.3 + side_offset
        var py := _ground_height(px, pz)
        var npc := Node3D.new(); npc.name = "Peao_%02d_%02d" % [index, person_i]
        npc.position = Vector3(px, py, pz); add_child(npc)
        var pedestrian_path: Array[Vector3] = [
            Vector3(center.x - 5.2, 0.0, center.y + 5.3),
            Vector3(center.x, 0.0, center.y + 5.3),
            Vector3(center.x + 5.2, 0.0, center.y + 6.4),
            Vector3(center.x, 0.0, center.y + 6.4)
        ]
        _ambient_agents.append({
            "node": npc,
            "kind": "pedestrian",
            "path": pedestrian_path,
            "target": (person_i + 1) % pedestrian_path.size(),
            "speed": 0.75 + float(person_i % 2) * 0.18,
            "base_speed": 0.75 + float(person_i % 2) * 0.18,
            "phase": float(index * 5 + person_i) * 0.61,
            # Índice estável: a densidade horária muda sem sortear nem recriar habitantes.
            "population_index": index * 6 + person_i,
            "sim_id": "NPC-%s-%02d" % [str(index + 1).pad_zeros(2), person_i + 1],
            "neighborhood": neighborhood_name,
            "routine_profile": _population_routine_profile(index, person_i),
            "activity_state": "rua"
        })
        var skin := _mat([Color(0.72,0.52,0.38),Color(0.48,0.31,0.22),Color(0.88,0.70,0.55)][(index+person_i)%3])
        var clothes := _mat(car_colors[(index+person_i+2)%car_colors.size()])
        var head := MeshInstance3D.new(); var hm := SphereMesh.new(); hm.radius=0.17; hm.height=0.34
        head.mesh=hm; head.material_override=skin; head.position=Vector3(0,1.48,0); npc.add_child(head)
        _box(npc, Vector3(0,1.02,0), Vector3(0.38,0.65,0.24), clothes, "Corpo")
        for leg_x in [-0.11,0.11]:
            _box(npc, Vector3(leg_x,0.48,0), Vector3(0.12,0.42,0.14), _mat(Color(0.12,0.15,0.20)), "Perna")
    # Nome de bairro sempre visível como etiqueta no espaço do mapa.
    _label(neighborhood_name, Vector3(center.x, _ground_height(center.x, center.y) + 7.0, center.y))

func _local_roads(center: Vector2, index: int) -> void:
    var road := _mat(Color(0.055,0.065,0.075), 0.95)
    _box(self, Vector3(center.x, _ground_height(center.x, center.y + 8.0) + 0.08, center.y+8), Vector3(18,0.18,2.8), road, "Rua_%02d_A" % index)
    _box(self, Vector3(center.x+8, _ground_height(center.x + 8.0, center.y) + 0.08, center.y), Vector3(2.8,0.18,18), road, "Rua_%02d_B" % index)


func _named_street_network(center: Vector2, index: int) -> void:
    # Malha visual modular inicial: eixos locais e nomes fictícios por bairro.
    # Não equivale ainda a navegação rodoviária/pathfinding de veículos.
    var asphalt := _mat(Color(0.065, 0.075, 0.085), 0.96)
    var pavement := _mat(Color(0.34, 0.36, 0.37), 0.9)
    var names := [
        "Avenida", "Rua", "Praça", "Travessa", "Alameda"
    ]
    var samples := [
        ["Avenida da Inovação","Rua dos Navegantes","Praça da União","Travessa da Tecnologia","Alameda do Futuro"],
        ["Avenida das Colinas","Rua do Miradouro","Praça da Encosta","Travessa das Oliveiras","Alameda da Serra"],
        ["Avenida do Rio","Rua das Pontes","Praça Ribeira","Travessa da Água","Alameda do Vale"],
        ["Avenida do Atlântico","Rua das Marés","Praça da Praia","Travessa do Farol","Alameda da Costa"],
        ["Avenida das Montanhas","Rua da Encosta","Praça da Montanha","Travessa do Pinhal","Alameda dos Picos"],
        ["Avenida da Luz","Rua das Acácias","Praça Lúmora","Travessa do Jardim","Alameda das Fontes"],
        ["Avenida das Flores","Rua do Jardim","Praça Florávia","Travessa das Rosas","Alameda Verde"],
        ["Avenida da Pedra","Rua do Castelo","Praça Pedrália","Travessa da Fonte","Alameda das Pedras"],
        ["Avenida do Vale","Rua dos Plátanos","Praça Central","Travessa do Moinho","Alameda do Sol"],
        ["Avenida da Praia","Rua dos Pescadores","Praça Brisamar","Travessa da Marina","Alameda do Mar"],
        ["Avenida das Fontes","Rua da Nascente","Praça Fontélia","Travessa da Água","Alameda dos Lagos"],
        ["Avenida da Prata","Rua da Serra","Praça Silvéria","Travessa dos Cedros","Alameda Branca"],
        ["Avenida do Porto","Rua dos Armazéns","Praça Portávia","Travessa do Cais","Alameda Logística"],
        ["Avenida do Lago","Rua das Margens","Praça Lacéria","Travessa dos Juncos","Alameda da Lagoa"],
        ["Avenida dos Ventos","Rua da Brisa","Praça Ventúria","Travessa do Horizonte","Alameda do Vento"],
        ["Avenida das Oliveiras","Rua do Olival","Praça Olivéria","Travessa do Pomar","Alameda dos Montes"],
        ["Avenida Ribeirinha","Rua da Ribeira","Praça Ribeora","Travessa do Açude","Alameda do Rio"],
        ["Avenida do Sol","Rua do Poente","Praça Solária","Travessa da Aurora","Alameda Dourada"],
        ["Avenida da Avelã","Rua dos Jardins","Praça Avelora","Travessa das Árvores","Alameda da Fonte"],
        ["Avenida da Terra","Rua dos Campos","Praça Terrávia","Travessa Rural","Alameda do Campo"],
        ["Avenida da Altitude","Rua do Alto","Praça Altória","Travessa da Vista","Alameda das Colinas"],
        ["Avenida da Maré","Rua do Estuário","Praça Marivora","Travessa do Molhe","Alameda do Estuário"],
        ["Avenida Verde","Rua das Florestas","Praça Verdelis","Travessa do Bosque","Alameda das Árvores"],
        ["Avenida do Estuário","Rua dos Canais","Praça Estúria","Travessa da Doca","Alameda Ribeirinha"],
        ["Avenida das Pedras","Rua da Pedreira","Praça Pedravora","Travessa do Vale","Alameda Rochosa"]
    ]
    var street_names: Array = samples[index % samples.size()]
    # Ruas transversais e longitudinais ligam os quarteirões de cada bairro.
    var road_h := _box(self, Vector3(center.x, _ground_height(center.x, center.y + 5.0) + 0.095, center.y + 5.0), Vector3(26, 0.16, 3.2), asphalt, "Arruamento_H_%02d" % (index + 1))
    var road_v := _box(self, Vector3(center.x + 5.0, _ground_height(center.x + 5.0, center.y) + 0.096, center.y), Vector3(3.2, 0.16, 26), asphalt, "Arruamento_V_%02d" % (index + 1))
    var district_streets: Array = _streets_by_neighborhood.get(NEIGHBORHOODS[index], [])
    if not district_streets.is_empty():
        var main_street: Dictionary = district_streets[0]
        road_h.set_meta("arruamento_id", main_street.get("id", ""))
        road_h.set_meta("arruamento", main_street.get("nome", ""))
        road_h.set_meta("codigo_postal", main_street.get("codigo_postal", ""))
        if district_streets.size() > 1:
            var secondary_street: Dictionary = district_streets[1]
            road_v.set_meta("arruamento_id", secondary_street.get("id", ""))
            road_v.set_meta("arruamento", secondary_street.get("nome", ""))
            road_v.set_meta("codigo_postal", secondary_street.get("codigo_postal", ""))
    # Passeios laterais reutilizados como meshes simples.
    _box(self, Vector3(center.x, _ground_height(center.x, center.y + 3.35) + 0.105, center.y + 3.35), Vector3(26, 0.12, 0.65), pavement, "Passeio_HA_%02d" % (index + 1))
    _box(self, Vector3(center.x, _ground_height(center.x, center.y + 6.65) + 0.105, center.y + 6.65), Vector3(26, 0.12, 0.65), pavement, "Passeio_HB_%02d" % (index + 1))
    # Placa de orientação com o nome do eixo principal; os restantes nomes constam no cadastro.
    _label(street_names[0], Vector3(center.x, _ground_height(center.x, center.y + 5.0) + 1.1, center.y + 5.0))

func _terrain_following_road(start: Vector2, finish: Vector2, width: float, thickness: float, material: Material, road_name: String, segment_count: int = 12) -> Array[MeshInstance3D]:
    var result: Array[MeshInstance3D] = []
    var delta := finish - start
    var total_length := delta.length()
    if total_length < 0.1:
        return result
    var segments := maxi(1, segment_count)
    var segment_length := total_length / float(segments)
    for i in range(segments):
        var t0 := float(i) / float(segments)
        var t1 := float(i + 1) / float(segments)
        var midpoint := start.lerp(finish, (t0 + t1) * 0.5)
        var y := _ground_height(midpoint.x, midpoint.y) + thickness * 0.5 + 0.015
        var road := _box(self, Vector3(midpoint.x, y, midpoint.y), Vector3(segment_length + 0.18, thickness, width), material, "%s_%02d" % [road_name, i + 1])
        road.rotation.y = -atan2(delta.y, delta.x)
        result.append(road)
    return result

func _multilane_road(start: Vector2, finish: Vector2, width: float, lane_count: int, road_name: String, segments: int = 32) -> void:
    # Plataforma viária seguindo o terreno, com marcações longitudinais.
    var asphalt := _mat(Color(0.055, 0.062, 0.070), 0.96)
    var white_mark := _mat(Color(0.88, 0.89, 0.84), 0.72)
    var center_mark := _mat(Color(0.96, 0.72, 0.22), 0.68)
    var parts := _terrain_following_road(start, finish, width, 0.18, asphalt, road_name, segments)
    for part in parts:
        part.set_meta("road_class", "motorway" if lane_count >= 4 and road_name.begins_with("Autoestrada") else "avenue")
        part.set_meta("lane_count", lane_count)
        part.set_meta("obstacle_clearance_required", true)
    # Passeios e drenagem lateral seguem o eixo da estrada e o relevo.
    # Autoestradas não recebem passeios pedonais; mantêm-se bermas drenantes.
    var delta := finish - start
    var total_length := delta.length()
    if total_length >= 8.0:
        var direction := delta / total_length
        var perpendicular := Vector2(-direction.y, direction.x)
        var sidewalk_mat := _mat(Color(0.48, 0.49, 0.47), 0.94)
        var gutter_mat := _mat(Color(0.20, 0.22, 0.23), 0.92)
        var is_motorway := road_name.begins_with("Autoestrada")
        var side_width := 1.45 if not is_motorway else 0.65
        for side: float in [-1.0, 1.0]:
            var side_start: Vector2 = start + perpendicular * side * (width * 0.5 + side_width * 0.5 + 0.12)
            var side_finish: Vector2 = finish + perpendicular * side * (width * 0.5 + side_width * 0.5 + 0.12)
            _terrain_following_road(side_start, side_finish, side_width, 0.12, sidewalk_mat if not is_motorway else gutter_mat, "%s_%s_%s" % [road_name, "Passeio" if not is_motorway else "BermaDrenagem", str(int(side))], segments)
            var gutter_start: Vector2 = start + perpendicular * side * (width * 0.5 + 0.06)
            var gutter_finish: Vector2 = finish + perpendicular * side * (width * 0.5 + 0.06)
            _terrain_following_road(gutter_start, gutter_finish, 0.12, 0.06, gutter_mat, "%s_Drenagem_%s" % [road_name, str(int(side))], segments)
    if total_length < 1.0:
        return
    var direction := delta / total_length
    var perpendicular := Vector2(-direction.y, direction.x)
    var dash_count := maxi(2, int(total_length / 3.4))
    var lane_width := width / float(lane_count)
    for lane_boundary in range(1, lane_count):
        var offset := -width * 0.5 + lane_width * float(lane_boundary)
        var mark_material := center_mark if lane_boundary == lane_count / 2 and lane_count % 2 == 0 else white_mark
        for dash in range(dash_count):
            var t := (float(dash) + 0.5) / float(dash_count)
            var p := start.lerp(finish, t) + perpendicular * offset
            var y := _ground_height(p.x, p.y) + 0.125
            var mark := _box(self, Vector3(p.x, y, p.y), Vector3(minf(1.65, total_length / float(dash_count) * 0.65), 0.025, 0.075), mark_material, "%s_Faixa_%02d_%02d" % [road_name, lane_boundary, dash])
            mark.rotation.y = -atan2(delta.y, delta.x)

    # Linhas de bordo contínuas em segmentos curtos, para definir claramente
    # a largura útil da estrada sem invadir a faixa de rodagem.
    var edge_material := _mat(Color(0.92, 0.93, 0.88), 0.72)
    var edge_count := maxi(2, int(total_length / 2.0))
    for side: float in [-1.0, 1.0]:
        for edge_i in range(edge_count):
            var et := (float(edge_i) + 0.5) / float(edge_count)
            var ep: Vector2 = start.lerp(finish, et) + perpendicular * side * (width * 0.5 - 0.18)
            var ey := _ground_height(ep.x, ep.y) + 0.145
            var edge_mark := _box(self, Vector3(ep.x, ey, ep.y), Vector3(total_length / float(edge_count) * 0.86, 0.022, 0.09), edge_material, "%s_Bordo_%s_%02d" % [road_name, str(int(side)), edge_i])
            edge_mark.rotation.y = -atan2(delta.y, delta.x)

    # Guardas metálicas visuais em autoestradas: postes e segmentos de rail.
    # São elementos de cenário, não barreiras físicas com colisão garantida.
    if road_name.begins_with("Autoestrada") and total_length >= 18.0:
        var rail_mat := _mat(Color(0.55, 0.58, 0.59), 0.38)
        var rail_post_mat := _mat(Color(0.36, 0.39, 0.40), 0.48)
        var rail_count := maxi(3, int(total_length / 3.0))
        for side: float in [-1.0, 1.0]:
            var rail_offset := width * 0.5 + 0.52
            for ri in range(rail_count):
                var rt0 := float(ri) / float(rail_count)
                var rt1 := float(ri + 1) / float(rail_count)
                var rp0: Vector2 = start.lerp(finish, rt0) + perpendicular * side * rail_offset
                var rp1: Vector2 = start.lerp(finish, rt1) + perpendicular * side * rail_offset
                var mid: Vector2 = (rp0 + rp1) * 0.5
                var rail_len: float = rp0.distance_to(rp1)
                var rail_y := _ground_height(mid.x, mid.y) + 0.72
                var rail := _box(self, Vector3(mid.x, rail_y, mid.y), Vector3(rail_len + 0.04, 0.12, 0.10), rail_mat, "%s_Guardarrail_%s_%02d" % [road_name, str(int(side)), ri])
                rail.rotation.y = -atan2((rp1 - rp0).y, (rp1 - rp0).x)
                if ri % 2 == 0:
                    var post_pos: Vector2 = rp0
                    var post_y := _ground_height(post_pos.x, post_pos.y) + 0.38
                    _box(self, Vector3(post_pos.x, post_y, post_pos.y), Vector3(0.10, 0.76, 0.10), rail_post_mat, "%s_GuardarrailPoste_%s_%02d" % [road_name, str(int(side)), ri])

    # Balizadores refletivos nas bermas das autoestradas para leitura visual noturna.
    # São elementos decorativos; não constituem barreira física nem sistema de colisão.
    if road_name.begins_with("Autoestrada") and total_length >= 12.0:
        var post_mat := _mat(Color(0.84, 0.85, 0.80), 0.42)
        var reflector_mat := _mat(Color(0.95, 0.72, 0.12), 0.30)
        var post_count := maxi(3, int(total_length / 8.0))
        for side: float in [-1.0, 1.0]:
            for post_i in range(post_count):
                var pt := (float(post_i) + 0.5) / float(post_count)
                var pp: Vector2 = start.lerp(finish, pt) + perpendicular * side * (width * 0.5 + 0.82)
                var py := _ground_height(pp.x, pp.y)
                _box(self, Vector3(pp.x, py + 0.34, pp.y), Vector3(0.10, 0.68, 0.10), post_mat, "%s_Balizador_%s_%02d" % [road_name, str(int(side)), post_i])
                _box(self, Vector3(pp.x, py + 0.48, pp.y), Vector3(0.115, 0.10, 0.115), reflector_mat, "%s_Refletor_%s_%02d" % [road_name, str(int(side)), post_i])

    # Iluminação pública fora do asfalto; colocada apenas em eixos longos.
    # Não cria postes em cada segmento para limitar o custo de geometria.
    if total_length >= 20.0:
        var lamp_mat := _mat(Color(0.94, 0.84, 0.57), 0.42)
        var pole_mat := _mat(Color(0.22, 0.25, 0.28), 0.68)
        var lamp_count := maxi(2, int(total_length / 18.0))
        for lamp_i in range(1, lamp_count):
            var lt := float(lamp_i) / float(lamp_count)
            for side: float in [-1.0, 1.0]:
                var lp: Vector2 = start.lerp(finish, lt) + perpendicular * side * (width * 0.5 + 1.25)
                var ly := _ground_height(lp.x, lp.y)
                var pole := _box(self, Vector3(lp.x, ly + 2.15, lp.y), Vector3(0.12, 4.3, 0.12), pole_mat, "%s_Poste_%02d_%s" % [road_name, lamp_i, str(int(side))])
                var arm := _box(self, Vector3(lp.x - perpendicular.x * side * 0.45, ly + 4.15, lp.y - perpendicular.y * side * 0.45), Vector3(0.9, 0.10, 0.10), pole_mat, "%s_Braco_%02d_%s" % [road_name, lamp_i, str(int(side))])
                arm.rotation.y = -atan2(delta.y, delta.x)
                var lamp := _box(self, Vector3(lp.x - perpendicular.x * side * 0.72, ly + 4.08, lp.y - perpendicular.y * side * 0.72), Vector3(0.36, 0.09, 0.24), lamp_mat, "%s_Luminaria_%02d_%s" % [road_name, lamp_i, str(int(side))])

func _road_sample_hits_building(point: Vector2, clearance: float = 1.6) -> bool:
    # Verificação AABB dos edifícios procedurais existentes; não equivale a uma
    # consulta completa de colisão e não cobre água, árvores ou instalações futuras.
    var stack: Array[Node] = [self]
    while not stack.is_empty():
        var current: Node = stack.pop_back()
        for child in current.get_children():
            stack.append(child)
            if not (child is MeshInstance3D):
                continue
            var mesh_node := child as MeshInstance3D
            var object_name := str(mesh_node.name)
            if not (object_name.begins_with("Edificio_") or object_name.begins_with("Cobertura_")):
                continue
            var bounds: AABB = mesh_node.global_transform * mesh_node.get_aabb()
            if point.x >= bounds.position.x - clearance and point.x <= bounds.position.x + bounds.size.x + clearance and point.y >= bounds.position.z - clearance and point.y <= bounds.position.z + bounds.size.z + clearance:
                return true
    return false

func _validate_road_waypoints(points: Array[Vector3]) -> Dictionary:
    var checked := 0
    for point in points:
        checked += 1
        if _road_sample_hits_building(Vector2(point.x, point.z), 1.6):
            return {"ok": false, "checked": checked, "error": "Amostra demasiado próxima de edifício."}
    return {"ok": true, "checked": checked, "error": ""}

func _build_inter_neighborhood_roads() -> void:
    # A malha visual representa exatamente as arestas do grafo de navegação.
    var summary := road_network.build_graph(NEIGHBORHOODS, POSITIONS)
    _road_waypoints_by_edge.clear()
    var asphalt := _mat(Color(0.045, 0.055, 0.065), 0.97)
    for edge in road_network.edges:
        var from_name: String = str(edge["from"])
        var to_name: String = str(edge["to"])
        var from_pos: Vector2 = road_network.nodes[from_name]["position"]
        var to_pos: Vector2 = road_network.nodes[to_name]["position"]
        var delta := to_pos - from_pos
        var length := delta.length()
        if length < 0.1:
            continue
        # As ligações visuais começam fora do miolo de edifícios de cada bairro.
        var direction := delta.normalized()
        var visual_start := from_pos + direction * 12.0
        var visual_end := to_pos - direction * 12.0
        var visual_delta := visual_end - visual_start
        var visual_length := visual_delta.length()
        if visual_length < 0.1:
            continue
        var midpoint := (visual_start + visual_end) * 0.5
        # Registar pontos ao longo do mesmo eixo usado para desenhar a estrada.
        # Estes waypoints correspondem ao traçado linear construído aqui, não a
        # uma verificação de colisões ou a um desvio automático em torno de obstáculos.
        var edge_waypoints: Array[Vector3] = []
        var sample_count := maxi(2, int(visual_length / 5.0) + 1)
        var sample_clear := true
        var sample_issue := ""
        for sample_i in range(sample_count + 1):
            var sample_t := float(sample_i) / float(sample_count)
            var sample_pos := visual_start.lerp(visual_end, sample_t)
            var ground_y := _ground_height(sample_pos.x, sample_pos.y)
            # Heurística de relevo: rejeita amostras com saltos de altura excessivos
            # entre pontos adjacentes. Não deteta água nem edifícios.
            if not edge_waypoints.is_empty():
                var previous_point: Vector3 = edge_waypoints[edge_waypoints.size() - 1]
                var horizontal_step := Vector2(sample_pos.x - previous_point.x, sample_pos.y - previous_point.z).length()
                var vertical_step := absf(ground_y - previous_point.y + 0.18)
                if horizontal_step > 0.01 and vertical_step / horizontal_step > 0.45:
                    sample_clear = false
                    sample_issue = "declive abrupto"
            edge_waypoints.append(Vector3(sample_pos.x, ground_y + 0.18, sample_pos.y))
        var obstruction_check := _validate_road_waypoints(edge_waypoints)
        if not bool(obstruction_check.get("ok", false)):
            sample_clear = false
            sample_issue = "edifício próximo"
        _road_waypoints_by_edge[str(edge["key"])] = {
            "points": edge_waypoints,
            "geometry_heuristic_ok": sample_clear,
            "geometry_issue": sample_issue,
            "obstruction_samples_checked": int(obstruction_check.get("checked", 0))
        }
        var road_width := 4.2 if edge["type"] == "principal" else 3.2
        var road_parts := _terrain_following_road(visual_start, visual_end, road_width, 0.14, asphalt, "Ligacao_%s" % str(edge["key"]).replace("|", "_"), 12)
        if not road_parts.is_empty():
            # Os metadados ficam no primeiro segmento para preservar a consulta de rede.
            road_parts[0].set_meta("bairro_origem", from_name)
            road_parts[0].set_meta("bairro_destino", to_name)
            road_parts[0].set_meta("distancia_mapa", float(edge["distance"]))
            road_parts[0].set_meta("tipo_via", str(edge["type"]))
    print("Rede rodoviária Valepólis: ", summary)

func get_route_between_neighborhoods(origin: String, destination: String) -> Dictionary:
    return road_network.get_route(origin, destination)

func get_vehicle_waypoints_between_neighborhoods(origin: String, destination: String) -> Dictionary:
    # Calcula uma rota que evita ligações já rejeitadas pelas verificações geométricas.
    var blocked_edges: Array[String] = []
    for edge_key_value in _road_waypoints_by_edge.keys():
        var edge_key := str(edge_key_value)
        var edge_record: Dictionary = _road_waypoints_by_edge[edge_key]
        if not bool(edge_record.get("geometry_heuristic_ok", false)):
            blocked_edges.append(edge_key)

    var route: Dictionary = road_network.get_route_avoiding_edges(origin, destination, blocked_edges)
    if not bool(route.get("ok", false)):
        return {"ok": false, "error": str(route.get("error", "Percurso indisponível.")), "waypoints": []}

    var edge_keys: Array = route.get("segments", [])
    var waypoints: Array[Vector3] = []
    if origin == destination:
        var same_pos: Vector2 = road_network.nodes[origin]["position"]
        waypoints.append(Vector3(same_pos.x, _ground_height(same_pos.x, same_pos.y) + 0.18, same_pos.y))
    else:
        for edge_key_value in edge_keys:
            var edge_key := str(edge_key_value)
            if not _road_waypoints_by_edge.has(edge_key):
                return {"ok": false, "error": "Geometria não registada para o segmento: " + edge_key, "waypoints": []}
            var edge_record: Dictionary = _road_waypoints_by_edge[edge_key]
            if not bool(edge_record.get("geometry_heuristic_ok", false)):
                return {"ok": false, "error": "O algoritmo devolveu um segmento rejeitado: " + edge_key, "waypoints": []}
            var edge_points: Array = edge_record.get("points", [])
            var edge_data: Dictionary = {}
            for edge in road_network.edges:
                if str(edge.get("key", "")) == edge_key:
                    edge_data = edge
                    break
            # Os pontos são registados de from -> to; inverter se o percurso os usa ao contrário.
            if not edge_data.is_empty():
                var path_index: int = edge_keys.find(edge_key)
                var from_name := str(route["path"][path_index])
                var to_name := str(route["path"][path_index + 1])
                if str(edge_data.get("from", "")) == to_name and str(edge_data.get("to", "")) == from_name:
                    edge_points = edge_points.duplicate()
                    edge_points.reverse()
            for point_value in edge_points:
                var point: Vector3 = point_value
                if waypoints.is_empty() or waypoints[waypoints.size() - 1].distance_to(point) > 0.5:
                    waypoints.append(point)

    return {
        "ok": waypoints.size() > 1 or origin == destination,
        "origin": origin,
        "destination": destination,
        "neighborhood_path": route.get("path", []),
        "distance": float(route.get("distance", 0.0)),
        "waypoints": waypoints,
        "blocked_edges_avoided": blocked_edges.size(),
        "note": "Tenta evitar segmentos rejeitados pela heurística de declive/edifícios; não valida água, instalações, colisões ou pontes."
    }

func get_vehicle_route_network_diagnostics(origin: String = "", destination: String = "") -> Dictionary:
    # Diagnóstico explícito da rede calculada. Não executa veículos nem declara
    # segurança física: as verificações continuam a ser heurísticas limitadas.
    var blocked_edges: Array[String] = []
    var accepted_edges: Array[String] = []
    var edge_details: Array[Dictionary] = []
    for edge_key_value in _road_waypoints_by_edge.keys():
        var edge_key := str(edge_key_value)
        var edge_record: Dictionary = _road_waypoints_by_edge[edge_key]
        var geometry_ok := bool(edge_record.get("geometry_heuristic_ok", false))
        if geometry_ok:
            accepted_edges.append(edge_key)
        else:
            blocked_edges.append(edge_key)
        edge_details.append({
            "edge_key": edge_key,
            "heuristic_ok": geometry_ok,
            "issue": str(edge_record.get("geometry_issue", "motivo não registado")),
            "samples_checked": int(edge_record.get("obstruction_samples_checked", 0)),
            "waypoint_count": (edge_record.get("points", []) as Array).size()
        })
    edge_details.sort_custom(func(a: Dictionary, b: Dictionary) -> bool:
        return str(a.get("edge_key", "")) < str(b.get("edge_key", ""))
    )
    var result: Dictionary = {
        "ok": true,
        "network": road_network.get_network_summary(),
        "geometry_edges_registered": _road_waypoints_by_edge.size(),
        "heuristic_accepted_edges": accepted_edges.size(),
        "heuristic_rejected_edges": blocked_edges.size(),
        "accepted_edges": accepted_edges,
        "rejected_edges": blocked_edges,
        "edge_details": edge_details,
        "limitations": [
            "Não verifica água, árvores, instalações, tráfego, colisões reais ou continuidade física das pontes.",
            "Uma aresta aceite pela heurística não é garantia de estrada transitável.",
            "Não altera nem redireciona automaticamente veículos em circulação."
        ]
    }
    if not origin.is_empty() or not destination.is_empty():
        if origin.is_empty() or destination.is_empty():
            result["route"] = {"ok": false, "error": "Indique origem e destino para avaliar a rota."}
        else:
            result["route"] = get_vehicle_waypoints_between_neighborhoods(origin, destination)
    return result

func get_ambient_vehicle_indices() -> Array[int]:
    # Devolve índices estáveis da lista atual de agentes para ferramentas de teste/UI.
    var result: Array[int] = []
    for i in range(_ambient_agents.size()):
        if str(_ambient_agents[i].get("kind", "")) == "vehicle":
            var node: Node3D = _ambient_agents[i].get("node") as Node3D
            if is_instance_valid(node):
                result.append(i)
    return result

func assign_vehicle_route(agent_index: int, origin: String, destination: String, reverse_route: bool = false) -> Dictionary:
    # Atribuição explícita: não altera automaticamente todos os veículos existentes.
    if agent_index < 0 or agent_index >= _ambient_agents.size():
        return {"ok": false, "error": "Índice de agente inválido."}
    var agent: Dictionary = _ambient_agents[agent_index]
    if str(agent.get("kind", "")) != "vehicle":
        return {"ok": false, "error": "O agente indicado não é um veículo."}
    var node: Node3D = agent.get("node") as Node3D
    if not is_instance_valid(node):
        return {"ok": false, "error": "O veículo já não está disponível."}

    var route_result := get_vehicle_waypoints_between_neighborhoods(origin, destination)
    if not bool(route_result.get("ok", false)):
        return route_result
    var points: Array = route_result.get("waypoints", [])
    if reverse_route:
        points.reverse()
    if points.size() < 2:
        return {"ok": false, "error": "O percurso precisa de pelo menos dois pontos para mover o veículo."}

    var vehicle_path: Array[Vector3] = []
    for point_value in points:
        var point: Vector3 = point_value
        vehicle_path.append(point)
    # Atribuir um percurso não teletransporta o veículo: exige que esteja
    # próximo do primeiro waypoint para evitar atravessar a cidade em linha reta.
    var first_point: Vector3 = vehicle_path[0]
    var vehicle_flat := Vector2(node.position.x, node.position.z)
    var start_flat := Vector2(first_point.x, first_point.z)
    if vehicle_flat.distance_to(start_flat) > 8.0:
        return {
            "ok": false,
            "error": "O veículo está demasiado longe do início da rota.",
            "distance_to_start": vehicle_flat.distance_to(start_flat),
            "required_max_distance": 8.0
        }
    agent["path"] = vehicle_path
    agent["target"] = 0
    agent["route_origin"] = origin if not reverse_route else destination
    agent["route_destination"] = destination if not reverse_route else origin
    agent["route_assigned"] = true
    agent["route_completed"] = false
    agent["route_progress_index"] = 0
    _ambient_agents[agent_index] = agent
    return {
        "ok": true,
        "agent_index": agent_index,
        "origin": str(agent["route_origin"]),
        "destination": str(agent["route_destination"]),
        "waypoint_count": vehicle_path.size(),
        "note": "Percurso atribuído; validar a geometria no jogo antes de utilizar."
    }

func get_vehicle_route_status(agent_index: int) -> Dictionary:
    if agent_index < 0 or agent_index >= _ambient_agents.size():
        return {"ok": false, "error": "Índice de agente inválido."}
    var agent: Dictionary = _ambient_agents[agent_index]
    if str(agent.get("kind", "")) != "vehicle":
        return {"ok": false, "error": "O agente indicado não é um veículo."}
    return {
        "ok": true,
        "assigned": bool(agent.get("route_assigned", false)),
        "completed": bool(agent.get("route_completed", false)),
        "origin": str(agent.get("route_origin", "")),
        "destination": str(agent.get("route_destination", "")),
        "waypoint_index": int(agent.get("route_progress_index", 0)),
        "waypoint_count": (agent.get("path", []) as Array).size(),
        "note": "Estado lógico do percurso; não certifica colisões nem cumprimento do Código da Estrada."
    }

func _bind_companies_to_existing_buildings() -> void:
    # Liga empresas apenas a edifícios já existentes cujo address_id corresponda
    # exatamente à morada candidata. Não cria edifícios nem inventa coordenadas.
    var registry: Node = get_tree().root.get_node_or_null("ValepolisCompanies")
    if registry == null or not registry.has_method("get_all_companies"):
        push_warning("Catálogo de empresas indisponível; nenhuma ligação física foi criada.")
        return
    var buildings_by_address: Dictionary = {}
    var stack: Array[Node] = [self]
    while not stack.is_empty():
        var current: Node = stack.pop_back()
        if current.has_meta("address_id"):
            var address_id := str(current.get_meta("address_id", ""))
            if not address_id.is_empty():
                if not buildings_by_address.has(address_id):
                    buildings_by_address[address_id] = []
                buildings_by_address[address_id].append(current)
        for child in current.get_children():
            stack.append(child)

    var matched := 0
    var unmatched := 0
    var companies: Array = registry.call("get_all_companies")
    for company in companies:
        if not (company is Dictionary):
            continue
        var company_id := str(company.get("company_id", ""))
        var address_id := str(company.get("proposed_address_candidate_id", ""))
        var neighborhood := str(company.get("neighborhood_name", ""))
        if address_id.is_empty() or not buildings_by_address.has(address_id):
            unmatched += 1
            continue
        var candidates: Array = buildings_by_address[address_id]
        var chosen: Node3D = null
        for candidate in candidates:
            if candidate is Node3D and str(candidate.get_meta("bairro", "")) == neighborhood:
                chosen = candidate as Node3D
                break
        if chosen == null:
            unmatched += 1
            continue
        # Metadados informativos apenas; a empresa não é declarada operacional.
        chosen.set_meta("company_candidate_id", company_id)
        chosen.set_meta("company_candidate_name", str(company.get("name", "")))
        chosen.set_meta("company_candidate_status", "morada_candidata_ligada_edificio_existente_pendente_aprovacao_fisica")
        # Sinalização 3D discreta e explicitamente provisória: mostra apenas
        # candidatos com correspondência exata, sem declarar loja operacional.
        var marker_name := "EmpresaCandidata_%s" % company_id
        if not has_node(marker_name):
            var sign_position := chosen.global_position + Vector3(0.0, 3.0, 0.0)
            _label("CANDIDATA · %s" % str(company.get("name", "")), sign_position)
            get_child(get_child_count() - 1).name = marker_name
        matched += 1
    print("Ligação empresas-mapa: correspondências exatas=", matched, "; pendentes=", unmatched,
        ". Nenhum edifício criado automaticamente.")


func _build_registered_installations() -> void:
    var registry: Node = get_tree().root.get_node_or_null("ValepolisInstallations")
    if registry == null or not registry.has_method("get_map_spawnable_installations"):
        return
    var rows: Array = registry.call("get_map_spawnable_installations")
    var seen_buildings: Dictionary = {}
    for row in rows:
        if not (row is Dictionary):
            continue
        var building_id := str(row.get("building_id", "")).strip_edges()
        if building_id.is_empty() or seen_buildings.has(building_id):
            push_warning("Instalação ignorada: ID físico vazio ou duplicado.")
            continue
        var raw_position: Variant = row.get("map_position", null)
        if not (raw_position is Array) or raw_position.size() < 3:
            continue
        var position := Vector3(float(raw_position[0]), float(raw_position[1]), float(raw_position[2]))
        position.y = maxf(position.y, _ground_height(position.x, position.z))
        var entity_id := str(row.get("entity_id", ""))
        var size := Vector3(4.0, 3.0, 4.0)
        var tint := Color(0.24, 0.43, 0.55)
        if entity_id == "BRIGADA":
            tint = Color(0.75, 0.18, 0.14)
        elif entity_id == "SUE":
            tint = Color(0.88, 0.91, 0.95)
        elif entity_id == "POLICIA":
            tint = Color(0.08, 0.18, 0.36)
        elif entity_id == "MUNICIPIO":
            tint = Color(0.72, 0.62, 0.30)
        var mesh := _box(self, position + Vector3(0.0, size.y / 2.0, 0.0), size, _mat(tint), building_id)
        mesh.set_meta("installation_id", str(row.get("installation_id", "")))
        mesh.set_meta("entity_id", entity_id)
        mesh.set_meta("neighborhood", str(row.get("neighborhood_name", "")))
        mesh.set_meta("address", str(row.get("full_address", "")))
        mesh.set_meta("map_object_class", str(row.get("planned_map_object_class", "building")))
        seen_buildings[building_id] = true
        _label(str(row.get("display_name", building_id)), position + Vector3(0.0, size.y + 1.0, 0.0))


func _regional_road(start: Vector2, finish: Vector2, width: float, road_name: String, segments: int = 12) -> void:
    # Via regional assentada no relevo, dividida em segmentos curtos.
    var asphalt := _mat(Color(0.045, 0.055, 0.065), 0.97)
    var parts := _terrain_following_road(start, finish, width, 0.18, asphalt, road_name, segments)
    for part in parts:
        part.set_meta("road_class", "regional")
        part.set_meta("obstacle_clearance_required", true)

func _bridge_deck(z_value: float, bridge_name: String) -> void:
    var bridge_material := _mat(Color(0.34, 0.38, 0.41), 0.82)
    var rail_material := _mat(Color(0.20, 0.23, 0.26), 0.78)
    # Tabuleiro atravessa o canal no eixo X; a superfície fica acima da água.
    var deck := _box(self, Vector3(-44.0, 0.72, z_value), Vector3(27.0, 0.44, 5.2), bridge_material, bridge_name)
    deck.set_meta("bridge", true)
    deck.set_meta("crosses_water", "Rio_Estuario_Oeste")
    deck.set_meta("connects_both_banks", true)
    deck.set_meta("regional_network", true)
    _box(self, Vector3(-44.0, 1.12, z_value - 2.48), Vector3(27.0, 0.36, 0.16), rail_material, bridge_name + "_GuardaCorpo_N")
    _box(self, Vector3(-44.0, 1.12, z_value + 2.48), Vector3(27.0, 0.36, 0.16), rail_material, bridge_name + "_GuardaCorpo_S")
    # Rampas curtas unem o tabuleiro às duas margens sem uma mudança abrupta de cota.
    _sloped_road(Vector2(-66.0, z_value), Vector2(-57.5, z_value), _ground_height(-66.0, z_value) + 0.12, 0.94, 5.0, bridge_name + "_Rampa_Oeste")
    _sloped_road(Vector2(-30.5, z_value), Vector2(-20.5, z_value), 0.94, _ground_height(-20.5, z_value) + 0.12, 5.0, bridge_name + "_Rampa_Leste")
    _label("Ponte da União" if bridge_name == "Ponte_da_Uniao" else "Ponte do Horizonte", Vector3(-44.0, 2.2, z_value))

func _sloped_road(start: Vector2, finish: Vector2, start_surface_y: float, finish_surface_y: float, width: float, road_name: String) -> void:
    var delta := finish - start
    var total_length := delta.length()
    if total_length < 0.1:
        return
    var segments := maxi(4, int(ceil(total_length / 1.8)))
    var asphalt := _mat(Color(0.045, 0.055, 0.065), 0.97)
    for i in range(segments):
        var t0 := float(i) / float(segments)
        var t1 := float(i + 1) / float(segments)
        var midpoint := start.lerp(finish, (t0 + t1) * 0.5)
        var surface_y := lerpf(start_surface_y, finish_surface_y, (t0 + t1) * 0.5)
        var segment := _box(self, Vector3(midpoint.x, surface_y - 0.09, midpoint.y), Vector3(total_length / float(segments) + 0.08, 0.18, width), asphalt, "%s_%02d" % [road_name, i + 1])
        segment.rotation.y = -atan2(delta.y, delta.x)
        segment.set_meta("road_class", "bridge_approach")
        segment.set_meta("bridge_access", true)

func _regional_locality(name: String, center: Vector2, label_text: String) -> void:
    # Representação discreta da localidade; nomes oficiais não confirmados não são inventados.
    var ground := _ground_height(center.x, center.y)
    var land := _mat(Color(0.43, 0.47, 0.34), 1.0)
    var wall := _mat(Color(0.72, 0.65, 0.51), 0.92)
    var roof := _mat(Color(0.39, 0.22, 0.16), 0.9)
    _plane(self, Vector3(center.x, ground + 0.025, center.y), Vector2(13.0, 10.0), land, name + "_Lote")
    for i in range(3):
        var offset := Vector2(float(i % 2) * 4.0 - 2.0, float(i / 2) * 3.0 - 1.5)
        var pos := center + offset
        var h := 2.8 + float(i % 2) * 0.5
        _box(self, Vector3(pos.x, _ground_height(pos.x, pos.y) + h * 0.5, pos.y), Vector3(2.8, h, 2.6), wall, name + "_Edificio_%02d" % (i + 1))
        _box(self, Vector3(pos.x, _ground_height(pos.x, pos.y) + h + 0.12, pos.y), Vector3(3.0, 0.24, 2.8), roof, name + "_Telhado_%02d" % (i + 1))
    _label(label_text, Vector3(center.x, ground + 5.0, center.y))

func _build_bridges_and_regional_roads() -> void:
    # Coordenadas do rio: X=-56. As pontes atravessam o canal no eixo X.
    _bridge_deck(-17.0, "Ponte_da_Uniao")
    _bridge_deck(23.0, "Ponte_do_Horizonte")

    # Corredor da margem ocidental: une as duas pontes e continua para as
    # localidades do sul, evitando terminar as estradas na margem do rio.
    _regional_road(Vector2(-68.0, -17.0), Vector2(-70.0, 23.0), 4.2, "Corredor_Regional_Oeste_Norte", 24)
    _regional_road(Vector2(-70.0, 23.0), Vector2(-72.0, 43.0), 4.2, "Corredor_Regional_Oeste_Sul", 14)
    _regional_road(Vector2(-72.0, 43.0), Vector2(-79.0, 50.0), 3.4, "Acesso_Santo_Andre_do_Vale", 8)
    _regional_road(Vector2(-72.0, 43.0), Vector2(-79.0, 62.0), 3.4, "Acesso_Portela_do_Sul", 12)

    # Acessos orientais das pontes contornam os núcleos densos e chegam às
    # avenidas da cidade; evitam atravessar os centros dos bairros próximos.
    _regional_road(Vector2(-30.5, -17.0), Vector2(-24.0, -23.0), 4.0, "Ligacao_Uniao_Avenida_Norte", 8)
    _regional_road(Vector2(-24.0, -23.0), Vector2(-13.0, -20.0), 4.0, "Ligacao_Uniao_Centro", 8)
    _regional_road(Vector2(-30.5, 23.0), Vector2(-23.0, 28.0), 4.0, "Ligacao_Horizonte_Avenida_Sul", 8)
    _regional_road(Vector2(-23.0, 28.0), Vector2(-10.0, 29.0), 4.0, "Ligacao_Horizonte_Centro", 8)

    # Localidades oficiais do sul e acessos genéricos a vilas/arredores.
    _regional_locality("Santo_Andre_do_Vale", Vector2(-81.0, 50.0), "Santo André do Vale")
    _regional_locality("Portela_do_Sul", Vector2(-82.0, 62.0), "Portela do Sul")
    _regional_road(Vector2(-70.0, 34.0), Vector2(-52.0, 39.0), 3.0, "Acesso_Vilas_Sul_Leste", 12)
    _regional_road(Vector2(-70.0, 6.0), Vector2(-82.0, 12.0), 3.0, "Acesso_Vilas_Oeste", 10)
    _regional_locality("Aglomerado_Rural_Oeste", Vector2(-85.0, 13.0), "Vilas e arredores")
    _regional_locality("Aglomerado_Rural_Sul", Vector2(-51.0, 40.0), "Vilas e arredores")

    # Auditoria em runtime: os objetos criados têm metadados verificáveis.
    print("Rede regional: Ponte da União + Ponte do Horizonte; cidades vizinhas, vilas e arredores ligados.")

func get_regional_destinations() -> Array[String]:
    return ["Valepólis", "Santo André do Vale", "Portela do Sul", "Vilas e arredores"]

func get_regional_route(origin: String, destination: String) -> Dictionary:
    # Grafo regional lógico: permite testar conectividade entre cidade, pontes e localidades.
    if not REGIONAL_ROUTE_GRAPH.has(origin) or not REGIONAL_ROUTE_GRAPH.has(destination):
        return {"ok": false, "error": "Origem ou destino regional desconhecido.", "path": []}
    if origin == destination:
        return {"ok": true, "path": [origin]}
    var queue: Array[String] = [origin]
    var previous: Dictionary = {}
    var visited: Dictionary = {origin: true}
    while not queue.is_empty():
        var current: String = queue.pop_front()
        for next_value in REGIONAL_ROUTE_GRAPH[current]:
            var next_name := str(next_value)
            if visited.has(next_name):
                continue
            visited[next_name] = true
            previous[next_name] = current
            if next_name == destination:
                var path: Array[String] = [destination]
                var cursor := destination
                while cursor != origin:
                    cursor = str(previous[cursor])
                    path.push_front(cursor)
                return {"ok": true, "path": path}
            queue.append(next_name)
    return {"ok": false, "error": "Não existe rota regional.", "path": []}

func _add_crosswalk(center: Vector2, road_axis: Vector2, width: float, stripe_count: int, label: String) -> void:
    # Passadeira visual em faixas curtas, alinhada com o eixo perpendicular à estrada.
    var stripe_mat := _mat(Color(0.94, 0.94, 0.88), 0.86)
    var axis := road_axis.normalized()
    var across := Vector2(-axis.y, axis.x)
    for i in range(stripe_count):
        var offset := (float(i) - float(stripe_count - 1) * 0.5) * 0.62
        var p := center + across * offset
        var y := _ground_height(p.x, p.y) + 0.20
        var stripe := _box(self, Vector3(p.x, y, p.y), Vector3(1.0, 0.025, 0.34), stripe_mat, "%s_Faixa_%02d" % [label, i + 1])
        stripe.rotation.y = -atan2(axis.y, axis.x)

    # Sinais de aproximação à passadeira nos dois lados do eixo rodoviário.
    # São elementos visuais; não ativam prioridade, semáforos ou travagem.
    var pole_mat := _mat(Color(0.22, 0.24, 0.25), 0.68)
    var blue_mat := _mat(Color(0.04, 0.25, 0.62), 0.48)
    var white_mat := _mat(Color(0.96, 0.96, 0.92), 0.76)
    for side: float in [-1.0, 1.0]:
        var sign_pos: Vector2 = center + axis * side * (width * 0.5 + 1.35)
        var ground_y := _ground_height(sign_pos.x, sign_pos.y)
        _box(self, Vector3(sign_pos.x, ground_y + 0.85, sign_pos.y), Vector3(0.075, 1.7, 0.075), pole_mat, "%s_Sinal_Poste_%s" % [label, str(int(side))])
        var board := _box(self, Vector3(sign_pos.x, ground_y + 1.55, sign_pos.y), Vector3(0.62, 0.62, 0.10), blue_mat, "%s_Sinal_Passadeira_%s" % [label, str(int(side))])
        board.set_meta("sign_type", "passadeira_pedonal")
        # Figura simplificada branca no painel azul.
        _box(self, Vector3(sign_pos.x, ground_y + 1.57, sign_pos.y - 0.06), Vector3(0.10, 0.28, 0.025), white_mat, "%s_Sinal_Figura_%s" % [label, str(int(side))])
        _box(self, Vector3(sign_pos.x, ground_y + 1.47, sign_pos.y - 0.06), Vector3(0.30, 0.07, 0.025), white_mat, "%s_Sinal_Bracos_%s" % [label, str(int(side))])

func _add_stop_line(center: Vector2, road_axis: Vector2, width: float, label: String) -> void:
    # Linha de paragem antes da zona de conflito; marcação visual sem lógica de prioridade.
    var axis := road_axis.normalized()
    var across := Vector2(-axis.y, axis.x)
    var mat := _mat(Color(0.95, 0.95, 0.90), 0.82)
    for i in range(12):
        var offset := (float(i) - 5.5) * (width / 12.0)
        var p := center + across * offset
        var mark := _box(self, Vector3(p.x, _ground_height(p.x, p.y) + 0.19, p.y), Vector3(0.32, 0.025, 0.20), mat, "%s_Marca_%02d" % [label, i + 1])
        mark.rotation.y = -atan2(axis.y, axis.x)

func _add_traffic_signal(position_2d: Vector2, suffix: String) -> void:
    # Cabeça de semáforo ilustrativa. As lentes não mudam de estado e não controlam veículos.
    var pole_mat := _mat(Color(0.20, 0.22, 0.23), 0.62)
    var housing_mat := _mat(Color(0.07, 0.08, 0.08), 0.50)
    var red_mat := _mat(Color(0.95, 0.035, 0.025), 0.28)
    var amber_mat := _mat(Color(0.28, 0.16, 0.025), 0.38)
    var green_mat := _mat(Color(0.025, 0.22, 0.07), 0.38)
    var y := _ground_height(position_2d.x, position_2d.y)
    _box(self, Vector3(position_2d.x, y + 2.0, position_2d.y), Vector3(0.11, 4.0, 0.11), pole_mat, "Semaforo_Poste_" + suffix)
    _box(self, Vector3(position_2d.x, y + 3.75, position_2d.y), Vector3(0.48, 1.15, 0.34), housing_mat, "Semaforo_Caixa_" + suffix)
    for row in range(3):
        var lens_mat: Material = red_mat if row == 0 else (amber_mat if row == 1 else green_mat)
        var lens := _box(self, Vector3(position_2d.x, y + 4.10 - float(row) * 0.35, position_2d.y - 0.19), Vector3(0.25, 0.25, 0.06), lens_mat, "Semaforo_Lente_%s_%d" % [suffix, row])
        lens.set_meta("signal_state", ["red", "amber", "green"][row])
    add_to_group("valepolis_visual_traffic_signals")

func _add_road_sign(position_2d: Vector2, text_value: String, suffix: String) -> void:
    var pole_mat := _mat(Color(0.22, 0.24, 0.25), 0.68)
    var sign_mat := _mat(Color(0.05, 0.28, 0.16), 0.55)
    var y := _ground_height(position_2d.x, position_2d.y)
    _box(self, Vector3(position_2d.x, y + 1.35, position_2d.y), Vector3(0.10, 2.7, 0.10), pole_mat, "Sinal_Poste_" + suffix)
    var board := _box(self, Vector3(position_2d.x, y + 2.55, position_2d.y), Vector3(1.7, 0.62, 0.12), sign_mat, "Sinal_Painel_" + suffix)
    board.set_meta("destination", text_value)
    _label(text_value, Vector3(position_2d.x, y + 2.45, position_2d.y + 0.10))

func _build_world() -> void:
    # O solo e as montanhas são gerados pelo addon próprio Valepólis Terrain.

    # Geografia continental: mar apenas a norte; o estuário entra pelo oeste
    # e termina na costa norte. Não existe água a envolver a margem sul/leste.
    var sea := _mat(Color(0.035,0.22,0.39), 0.32)
    _plane(self, Vector3(0,-0.42,-65.0), Vector2(150,18), sea, "Mar_Norte")

    # Canal longitudinal a oeste, com margem terrestre contínua a sul.
    # A extremidade norte encontra a costa; a extremidade sul termina antes
    # das localidades interiores, evitando o efeito de ilha.
    _box(self, Vector3(-56,-0.24,-1.0), Vector3(7.0,0.30,88.0), sea, "Rio_Estuario_Oeste")


    # Eixos viários principais seguem o relevo; nenhum tabuleiro longo fica a uma cota fixa.
    var road := _mat(Color(0.075,0.082,0.09), 0.96)
    # Avenidas urbanas de quatro faixas (duas por sentido) e avenidas de três faixas.
    _multilane_road(Vector2(-1,-43), Vector2(-1,43), 8.8, 4, "Avenida_Central", 48)
    _multilane_road(Vector2(-47,4), Vector2(47,4), 8.4, 4, "Avenida_Transversal", 48)
    _multilane_road(Vector2(-49,-20), Vector2(-4,-20), 6.6, 3, "Avenida_Norte", 24)
    _multilane_road(Vector2(3,24), Vector2(47,24), 6.6, 3, "Avenida_Sul", 24)
    # Autoestrada periférica de quatro faixas, evitando o núcleo denso; liga à variante sul.
    _multilane_road(Vector2(51,-48), Vector2(51,48), 10.8, 4, "Autoestrada_Leste", 56)
    _multilane_road(Vector2(-48,48), Vector2(51,48), 10.8, 4, "Autoestrada_Variante_Sul", 56)
    # Ligações entre autoestrada, avenidas e rede regional.
    _multilane_road(Vector2(47,4), Vector2(51,4), 8.4, 4, "Ligacao_Autoestrada_Transversal", 8)
    _multilane_road(Vector2(51,24), Vector2(47,24), 6.6, 3, "Ligacao_Autoestrada_Sul", 8)
    var lane_mark := _mat(Color(0.92, 0.78, 0.38), 0.7)
    for mark_i in range(23):
        var mx := -43.0 + float(mark_i) * 3.8
        var my := _ground_height(mx, 4.0) + 0.27
        _box(self, Vector3(mx, my, 4.0), Vector3(1.35, 0.025, 0.10), lane_mark, "Marca_Transversal_%02d" % mark_i)

    # As duas pontes são infraestruturas funcionais da rede regional.
    # A geometria e os acessos são criados após os bairros para não ficarem
    # escondidos por edifícios ou vegetação gerados anteriormente.

    # Passadeiras nas duas avenidas centrais e nos principais cruzamentos.
    _add_crosswalk(Vector2(-1.0, 4.0), Vector2(0, 1), 8.8, 9, "Passadeira_Central_Transversal")
    _add_crosswalk(Vector2(-1.0, -20.0), Vector2(0, 1), 8.8, 9, "Passadeira_Avenida_Norte")
    _add_crosswalk(Vector2(3.0, 24.0), Vector2(0, 1), 6.6, 7, "Passadeira_Avenida_Sul")
    _add_crosswalk(Vector2(47.0, 4.0), Vector2(0, 1), 8.4, 9, "Passadeira_Ligacao_Leste")
    _add_road_sign(Vector2(2.8, 5.8), "Centro", "Centro")
    _add_road_sign(Vector2(48.4, 6.4), "Saída", "Saida_Leste")

    # Linhas de paragem e semáforos visuais nos cruzamentos principais.
    _add_stop_line(Vector2(-1.0, 1.0), Vector2(0, 1), 8.8, "Paragem_Central")
    _add_stop_line(Vector2(-1.0, 7.0), Vector2(0, 1), 8.8, "Paragem_Central_2")
    _add_stop_line(Vector2(-5.0, 4.0), Vector2(1, 0), 8.4, "Paragem_Transversal")
    _add_stop_line(Vector2(3.0, 21.0), Vector2(0, 1), 6.6, "Paragem_Sul")
    _add_traffic_signal(Vector2(5.6, 5.7), "Central_NE")
    _add_traffic_signal(Vector2(-7.5, 5.7), "Central_NO")
    _add_traffic_signal(Vector2(5.6, 1.6), "Central_SE")
    _add_traffic_signal(Vector2(-7.5, 1.6), "Central_SO")
    _add_traffic_signal(Vector2(7.7, 25.6), "Sul_NE")
    _add_traffic_signal(Vector2(-0.7, 25.6), "Sul_NO")

    for i in range(NEIGHBORHOODS.size()):
        _building_cluster(POSITIONS[i], i)
        _neighborhood_landmark(POSITIONS[i], NEIGHBORHOODS[i], i)
        _local_roads(POSITIONS[i], i)
        _named_street_network(POSITIONS[i], i)
        if i % 3 == 0:
            _park(POSITIONS[i] + Vector2(5,-5), i)
        _build_neighborhood_details(POSITIONS[i], i, NEIGHBORHOODS[i])

    _build_inter_neighborhood_roads()
    _build_bridges_and_regional_roads()

    # Lago interior e zona portuária.
    var lake := _mat(Color(0.04,0.30,0.45), 0.3)
    _plane(self, Vector3(3,0.01,35), Vector2(20,9), lake, "Lago_Valepolis")
    _box(self, Vector3(-25,0.4,-39), Vector3(22,0.8,8), _mat(Color(0.30,0.30,0.32)), "Porto")
    _label("PORTO / MARINA", Vector3(-25,2.5,-39))

    # Centro de Valepólis.
    var civic := _mat(Color(0.30,0.36,0.43))
    _box(self, Vector3(0,7,4), Vector3(10,14,10), civic, "Centro_Valepolis")
    _label("VALEPÓLIS", Vector3(0,17,4))

    # Instalações funcionais só aparecem via registo aprovado em _build_registered_installations().

    # Expansão física uniforme do cenário: aumenta o espaço absoluto entre os
    # bairros, a largura útil dos corredores e a área visual do terreno sem
    # alterar os nomes/identificadores nem recalcular individualmente as rotas.
    # Cada filho direto é escalado uma única vez; subcomponentes acompanham o pai.
    for world_node in get_children():
        if world_node is Node3D and world_node != camera:
            var node_3d := world_node as Node3D
            node_3d.position *= WORLD_EXPANSION_FACTOR
            node_3d.scale *= WORLD_EXPANSION_FACTOR

    # Os agentes guardam percursos em coordenadas próprias, fora da hierarquia
    # Node3D. Escalar apenas os modelos deixava os carros e peões a regressar
    # às coordenadas antigas no primeiro movimento.
    for agent in _ambient_agents:
        var path: Array = agent.get("path", [])
        for path_index in range(path.size()):
            var path_point: Vector3 = path[path_index]
            path[path_index] = path_point * WORLD_EXPANSION_FACTOR
        agent["path"] = path
    player_world_position *= WORLD_EXPANSION_FACTOR


func _create_player_character() -> void:
    # A personagem selecionada passa a existir no mundo 3D, não apenas como
    # marcador 2D sobre o SubViewport. A posição inicial fica em Nexora.
    var character_script: Script = load("res://addons/valepolis_3d_studio/procedural_character.gd")
    if character_script == null:
        push_warning("Gerador de personagem 3D indisponível; mantém-se o marcador da interface.")
        return
    player_character = character_script.new() as Node3D
    if player_character == null:
        push_warning("Não foi possível instanciar a personagem 3D.")
        return
    player_character.name = "PersonagemSelecionada3D"
    player_character.set("seed_value", 20261010)
    player_character.set("role", "Civil")
    player_character.set("regenerate_on_ready", true)
    player_world_position.y = _ground_height(player_world_position.x, player_world_position.z)
    player_character.position = player_world_position
    add_child(player_character)
    _player_label = Label3D.new()
    _player_label.name = "EtiquetaPersonagemSelecionada"
    _player_label.text = player_display_name
    _player_label.position = player_world_position + Vector3(0.0, 2.7, 0.0)
    _player_label.font_size = 24
    _player_label.modulate = Color(1.0, 0.88, 0.30)
    _player_label.outline_size = 8
    _player_label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
    add_child(_player_label)
    _player_marker = MeshInstance3D.new()
    _player_marker.name = "MarcadorPosicaoJogador"
    var ring := CylinderMesh.new()
    ring.top_radius = 1.05
    ring.bottom_radius = 1.05
    ring.height = 0.08
    _player_marker.mesh = ring
    _player_marker.position = player_world_position + Vector3(0, 0.12, 0)
    var marker_mat := StandardMaterial3D.new()
    marker_mat.albedo_color = Color(1.0, 0.72, 0.12, 0.82)
    marker_mat.emission_enabled = true
    marker_mat.emission = Color(1.0, 0.42, 0.04)
    marker_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    _player_marker.material_override = marker_mat
    add_child(_player_marker)
    camera_target = player_world_position + Vector3(0.0, 4.0, 0.0)


func set_player_identity(character_name: String, profession: String = "") -> void:
    var clean_name := character_name.strip_edges()
    player_display_name = clean_name if clean_name != "" and clean_name != "PERSONAGEM" else "ESCOLHA PERSONAGEM"
    player_profession = profession.strip_edges()
    if is_instance_valid(_player_label):
        _player_label.text = player_display_name
    if is_instance_valid(player_character):
        var seed_value := int(abs(player_display_name.hash()))
        if player_character.get("seed_value") != null:
            player_character.set("seed_value", seed_value)
        if player_character.get("role") != null:
            var role_text := player_profession.to_lower()
            var visual_role := "Civil"
            if "brigada" in role_text:
                visual_role = "BRIGADA"
            elif "sue" in role_text or "médic" in role_text or "enfermeir" in role_text:
                visual_role = "SUE"
            elif "tnur" in role_text or "transporte não urgente" in role_text:
                visual_role = "TNUR"
            elif "polícia" in role_text or "policia" in role_text or "agente de polícia" in role_text:
                visual_role = "Policia"
            player_character.set("role", visual_role)
        if player_character.has_method("regenerate"):
            player_character.call("regenerate")

func _population_routine_profile(neighborhood_index: int, person_index: int) -> String:
    # Perfis técnicos determinísticos; não definem a distribuição demográfica oficial.
    var profile_index := posmod(neighborhood_index * 7 + person_index, 4)
    match profile_index:
        0: return "pendular"
        1: return "local"
        2: return "servicos"
        _: return "lazer"


func sync_population_agents(population_agents: Dictionary) -> Dictionary:
    # Liga os peões visuais à amostra persistente existente; não cria pessoas nem destinos.
    var by_neighborhood: Dictionary = {}
    for agent_key in population_agents.keys():
        var record: Dictionary = population_agents[agent_key]
        var district := str(record.get("current_neighborhood", record.get("home_neighborhood", record.get("neighborhood", ""))))
        if district.is_empty():
            continue
        if not by_neighborhood.has(district):
            by_neighborhood[district] = []
        by_neighborhood[district].append({"key": str(agent_key), "record": record})
    var linked := 0
    var unresolved := 0
    var counters: Dictionary = {}
    for visual in _ambient_agents:
        if str(visual.get("kind", "")) != "pedestrian":
            continue
        var district := str(visual.get("neighborhood", ""))
        var records: Array = by_neighborhood.get(district, [])
        if records.is_empty():
            visual["persistent_agent_id"] = ""
            visual["destination_id"] = ""
            visual["destination_resolved"] = false
            unresolved += 1
            continue
        var offset := int(counters.get(district, 0))
        var selected: Dictionary = records[posmod(offset, records.size())]
        counters[district] = offset + 1
        var record: Dictionary = selected.get("record", {})
        visual["persistent_agent_id"] = str(record.get("id", selected.get("key", "")))
        visual["sim_id"] = visual["persistent_agent_id"]
        visual["routine_profile"] = str(record.get("routine_profile", visual.get("routine_profile", "local")))
        visual["activity_state"] = str(record.get("activity", record.get("trip_state", "rua")))
        visual["destination_id"] = str(record.get("destination_id", ""))
        visual["destination_type"] = str(record.get("destination_type", ""))
        visual["destination_neighborhood"] = str(record.get("destination_neighborhood", district))
        visual["destination_resolved"] = bool(record.get("destination_resolved", false))
        linked += 1
    return {"linked_visual_pedestrians": linked, "unresolved_visual_pedestrians": unresolved, "persistent_agents": population_agents.size()}

func set_traffic_hour(game_hour: int, weekend: bool = false) -> void:
    # O volume visível acompanha o relógio do jogo, sem teletransportar veículos.
    _traffic_hour = posmod(game_hour, 24)
    _traffic_weekend = weekend
    if _traffic_hour >= 7 and _traffic_hour <= 9:
        _traffic_profile = "ponta_manha"
    elif _traffic_hour >= 17 and _traffic_hour <= 19:
        _traffic_profile = "ponta_tarde"
    elif _traffic_hour >= 23 or _traffic_hour <= 5:
        _traffic_profile = "noturno"
    elif _traffic_hour >= 10 and _traffic_hour <= 16:
        _traffic_profile = "diurno"
    else:
        _traffic_profile = "transicao"
    _apply_traffic_profile()

func _apply_traffic_profile() -> void:
    # Densidade visual determinística: o mesmo relógio produz sempre o mesmo
    # conjunto de veículos e habitantes, sem clones nem teletransportes.
    var vehicle_ratio := 0.52
    var pedestrian_ratio := 0.68
    var vehicle_speed_factor := 1.0
    var pedestrian_speed_factor := 1.0
    match _traffic_profile:
        "ponta_manha":
            vehicle_ratio = 1.0
            pedestrian_ratio = 0.88
            vehicle_speed_factor = 0.72
            pedestrian_speed_factor = 1.0
        "ponta_tarde":
            vehicle_ratio = 1.0
            pedestrian_ratio = 0.92
            vehicle_speed_factor = 0.72
            pedestrian_speed_factor = 1.05
        "noturno":
            # Mesmo de madrugada há circulação residual na cidade viva.
            # Não esconder praticamente toda a frota por causa do relógio.
            vehicle_ratio = 0.40
            pedestrian_ratio = 0.12
            vehicle_speed_factor = 1.18
            pedestrian_speed_factor = 0.82
        "diurno":
            vehicle_ratio = 0.72
            pedestrian_ratio = 0.82
            vehicle_speed_factor = 0.94
            pedestrian_speed_factor = 1.0
        _:
            vehicle_ratio = 0.42
            pedestrian_ratio = 0.48
            vehicle_speed_factor = 0.88
            pedestrian_speed_factor = 0.9

    if _traffic_weekend:
        # Menos deslocações pendulares de carro; mais pessoas a pé durante o dia.
        vehicle_ratio = maxf(0.35, vehicle_ratio * 0.72)
        if _traffic_profile == "noturno":
            pedestrian_ratio *= 0.9
        else:
            pedestrian_ratio = minf(1.0, pedestrian_ratio * 1.12)

    for agent in _ambient_agents:
        var node := agent.get("node") as Node3D
        if not is_instance_valid(node):
            continue
        var kind := str(agent.get("kind", ""))
        if kind == "vehicle":
            # Distribui a seleção por toda a cidade. O módulo 100 anterior
            # concentrava os veículos nos primeiros bairros quando a densidade
            # era baixa, deixando zonas inteiras sem carros visíveis.
            var traffic_index := int(agent.get("traffic_index", 0))
            var stable_slot := posmod(traffic_index * 7 + 3, 10)
            var visible_slots := clampi(roundi(vehicle_ratio * 10.0), 5, 10)
            node.visible = stable_slot < visible_slots
            agent["speed"] = float(agent.get("base_speed", 3.0)) * vehicle_speed_factor
        elif kind == "pedestrian":
            var population_index := int(agent.get("population_index", 0))
            var routine := str(agent.get("routine_profile", "local"))
            var routine_ratio := pedestrian_ratio
            # Perfis diferentes impedem que toda a população siga a mesma curva horária.
            if routine == "pendular":
                if _traffic_profile == "ponta_manha" or _traffic_profile == "ponta_tarde":
                    routine_ratio = minf(1.0, pedestrian_ratio + 0.08)
                elif _traffic_profile == "noturno":
                    routine_ratio *= 0.45
            elif routine == "servicos":
                if _traffic_profile == "diurno":
                    routine_ratio = minf(1.0, pedestrian_ratio + 0.10)
                elif _traffic_profile == "noturno":
                    routine_ratio *= 0.55
            elif routine == "lazer" and _traffic_profile == "noturno":
                routine_ratio = minf(0.35, pedestrian_ratio + 0.12)
            var visible_by_schedule := float(posmod(population_index * 37, 100)) < routine_ratio * 100.0
            node.visible = visible_by_schedule
            agent["activity_state"] = "rua" if visible_by_schedule else "interior_ou_fora_de_zona"
            agent["speed"] = float(agent.get("base_speed", 0.8)) * pedestrian_speed_factor

func _process(delta: float) -> void:
    _ambient_clock += delta
    _update_ambient_agents(delta)
    # Movimento básico de teste com teclado (WASD/setas), relativo ao mapa.
    # Em ecrãs táteis, os gestos continuam reservados à câmara.
    if not is_instance_valid(player_character):
        return
    var move := Vector2.ZERO
    if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
        move.x -= 1.0
    if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
        move.x += 1.0
    if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
        move.y -= 1.0
    if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
        move.y += 1.0
    if player_character.has_method("set_moving"):
        player_character.call("set_moving", move.length_squared() > 0.0)
    if move.length_squared() > 0.0:
        move = move.normalized()
        player_world_position.x += move.x * player_move_speed * delta
        player_world_position.z += move.y * player_move_speed * delta
        player_world_position.x = clampf(player_world_position.x, -48.0, 48.0)
        player_world_position.z = clampf(player_world_position.z, -48.0, 48.0)
        player_world_position.y = _ground_height(player_world_position.x, player_world_position.z)
        player_character.position = player_world_position
        if is_instance_valid(_player_label):
            _player_label.position = player_world_position + Vector3(0.0, 2.7, 0.0)
        if is_instance_valid(_player_marker):
            _player_marker.position = player_world_position + Vector3(0.0, 0.12, 0.0)
        camera_target = player_world_position + Vector3(0.0, 4.0, 0.0)
        _update_camera()

func _update_ambient_agents(delta: float) -> void:
    # Percursos locais sobre os eixos viários/passeios já gerados. É uma
    # primeira camada de movimento autónomo; não substitui pathfinding global.
    for agent in _ambient_agents:
        var node: Node3D = agent.get("node") as Node3D
        if not is_instance_valid(node):
            continue
        var path: Array = agent.get("path", [])
        if path.size() < 2:
            continue
        var target_index: int = int(agent.get("target", 0))
        var is_assigned_route: bool = bool(agent.get("route_assigned", false))
        if is_assigned_route and bool(agent.get("route_completed", false)):
            continue
        if not is_assigned_route:
            target_index = posmod(target_index, path.size())
        else:
            target_index = clampi(target_index, 0, path.size() - 1)
        var target: Vector3 = path[target_index]
        var current_flat := Vector2(node.position.x, node.position.z)
        var target_flat := Vector2(target.x, target.z)
        var offset := target_flat - current_flat
        var speed := float(agent.get("speed", 1.0))
        # Avanço limitado para evitar saltos quando um frame demora mais do que o habitual.
        var step_distance := minf(speed * delta, maxf(0.0, offset.length()))
        if offset.length() <= maxf(0.12, speed * delta):
            if is_assigned_route and target_index >= path.size() - 1:
                # Percursos atribuídos terminam no destino; não fazem loop nem
                # regressam silenciosamente ao primeiro waypoint.
                agent["route_completed"] = true
                agent["route_progress_index"] = path.size() - 1
                continue
            var next_target_index: int = target_index + 1
            if not is_assigned_route:
                next_target_index = posmod(next_target_index, path.size())
            agent["target"] = next_target_index
            agent["route_progress_index"] = next_target_index
            target_index = next_target_index
            target = path[target_index]
            offset = Vector2(target.x - node.position.x, target.z - node.position.z)
        if offset.length_squared() > 0.0001:
            var direction := offset.normalized()
            # Seguimento básico: veículos reduzem a velocidade perante outro
            # veículo próximo que esteja à frente e aproximadamente na mesma faixa.
            var kind := str(agent.get("kind", ""))
            var safe_speed := speed
            if kind == "vehicle":
                for other_agent in _ambient_agents:
                    if other_agent == agent or str(other_agent.get("kind", "")) != "vehicle":
                        continue
                    var other_node: Node3D = other_agent.get("node") as Node3D
                    if not is_instance_valid(other_node):
                        continue
                    var relative := Vector2(other_node.position.x - node.position.x, other_node.position.z - node.position.z)
                    var ahead := relative.dot(direction)
                    var lateral := absf(relative.x * direction.y - relative.y * direction.x)
                    if ahead > 0.0 and ahead < 5.5 and lateral < 1.25:
                        safe_speed = minf(safe_speed, speed * clampf((ahead - 1.5) / 4.0, 0.0, 1.0))
            # Curva de direção progressiva e deslocamento limitado pelo espaço livre.
            var desired_yaw := atan2(direction.x, direction.y)
            node.rotation.y = lerp_angle(node.rotation.y, desired_yaw, clampf(delta * 5.0, 0.0, 1.0))
            var allowed_step := minf(safe_speed * delta, offset.length())
            node.position.x += direction.x * allowed_step
            node.position.z += direction.y * allowed_step
        # Manter a carroçaria acima da superfície do terreno/estrada em todos os frames.
        # Antes, o primeiro movimento colocava todos os agentes ao nível do solo,
        # anulando o desnível inicial dos veículos e fazendo as rodas/carroçaria
        # parecerem afundadas na estrada.
        var ground_y := _ground_height(node.position.x, node.position.z)
        if str(agent.get("kind", "")) == "vehicle":
            node.position.y = ground_y + 0.18
        elif str(agent.get("kind", "")) == "pedestrian":
            node.position.y = ground_y + absf(sin(_ambient_clock * 7.0 + float(agent.get("phase", 0.0)))) * 0.035
        else:
            node.position.y = ground_y
    # Guardar estado actualizado para o próximo frame.
    # Os dicionários são referências, por isso os alvos já ficam persistidos.

func _create_camera() -> void:
    camera = Camera3D.new()
    add_child(camera)
    camera.current = true
    camera.fov = 68.0
    camera.near = 0.1
    camera.far = 1200.0
    _update_camera()

func _update_camera() -> void:
    if camera == null:
        return
    # Limites globais: impedir zoom extremo que coloque a câmara dentro da geometria.
    distance = clampf(distance, 38.0, 230.0)
    var basis := Basis.from_euler(Vector3(deg_to_rad(pitch), deg_to_rad(yaw), 0))
    var desired_position: Vector3 = camera_target + basis * Vector3(0, 0, distance)
    # Colisão por raycast: se houver geometria física entre o alvo e a câmara,
    # aproximar a câmara até antes do obstáculo em vez de a deixar atravessar.
    var space := get_world_3d().direct_space_state
    if space != null:
        var query := PhysicsRayQueryParameters3D.create(camera_target, desired_position)
        query.exclude = []
        query.collide_with_areas = true
        query.collide_with_bodies = true
        var hit: Dictionary = space.intersect_ray(query)
        if not hit.is_empty():
            var hit_position: Vector3 = hit.get("position", desired_position)
            var direction: Vector3 = (desired_position - camera_target).normalized()
            desired_position = hit_position - direction * 0.8
    camera.global_position = desired_position
    camera.look_at(camera_target, Vector3.UP)

func set_external_zoom(zoom_value: float) -> void:
    # Distância de câmara, não escala do painel/viewport.
    # O mapa tem aproximadamente 170 x 150 unidades; a distância inicial
    # tem de permitir perceber a distribuição dos bairros. O zoom aproxima
    # progressivamente sem forçar a câmara para dentro dos edifícios.
    _external_zoom = clampf(zoom_value, 0.75, 3.2)
    distance = clampf(165.0 / _external_zoom, 38.0, 230.0)
    _update_camera()

func rotate_camera_by(delta: Vector2) -> void:
    yaw -= delta.x * 0.22
    pitch = clampf(pitch - delta.y * 0.16, -78.0, -25.0)
    _update_camera()

func center_camera_on_player() -> void:
    camera_target = player_world_position + Vector3(0.0, 4.0, 0.0)
    _update_camera()

func show_city_overview() -> void:
    # Enquadra a extensão completa dos 25 bairros, em vez de focar apenas o jogador.
    camera_target = Vector3(0.0, 0.0, 0.0)
    pitch = -55.0
    distance = 185.0
    _update_camera()

func get_neighborhood_names() -> Array[String]:
    # Lista oficial exposta à interface para construir o seletor de bairros.
    return NEIGHBORHOODS.duplicate()

func focus_neighborhood(neighborhood_name: String) -> bool:
    # Foca o bairro pedido usando as coordenadas já existentes; não cria nem move bairros.
    var index: int = NEIGHBORHOODS.find(neighborhood_name)
    if index < 0 or index >= POSITIONS.size():
        push_warning("Bairro de Valepólis desconhecido: " + neighborhood_name)
        return false
    var center: Vector2 = POSITIONS[index]
    camera_target = Vector3(center.x, _ground_height(center.x, center.y) + 3.0, center.y)
    distance = 48.0
    _update_camera()
    return true

func set_neighborhood_labels_visible(visible_value: bool) -> void:
    # Permite à interface alternar as etiquetas territoriais sem afetar as restantes etiquetas.
    for node in get_tree().get_nodes_in_group("valepolis_neighborhood_labels"):
        if is_instance_valid(node):
            node.visible = visible_value

func _create_light() -> void:
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-52,-28,0)
    sun.light_energy = 1.35
    sun.shadow_enabled = true
    add_child(sun)

func _create_atmosphere() -> void:
    var env := WorldEnvironment.new()
    var e := Environment.new()
    e.background_mode = Environment.BG_SKY
    var sky := Sky.new()
    var sky_material := ProceduralSkyMaterial.new()
    sky_material.sky_top_color = Color(0.12, 0.30, 0.52)
    sky_material.sky_horizon_color = Color(0.72, 0.80, 0.86)
    sky_material.ground_bottom_color = Color(0.18, 0.25, 0.20)
    sky_material.ground_horizon_color = Color(0.48, 0.56, 0.48)
    sky.sky_material = sky_material
    e.sky = sky
    e.background_color = Color(0.24,0.38,0.52)
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.45,0.52,0.65)
    e.ambient_light_energy = 1.0
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        if event.button_index == MOUSE_BUTTON_LEFT:
            dragging = event.pressed
            last_mouse = event.position
        elif event.button_index == MOUSE_BUTTON_WHEEL_UP and event.pressed:
            distance = max(38.0, distance - 5.0)
            _update_camera()
        elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN and event.pressed:
            distance = min(230.0, distance + 5.0)
            _update_camera()
    elif event is InputEventMouseMotion and dragging:
        var delta: Vector2 = event.position - last_mouse
        last_mouse = event.position
        yaw -= delta.x * 0.25
        pitch = clampf(pitch - delta.y * 0.18, -78.0, -25.0)
        _update_camera()
    elif event is InputEventScreenTouch:
        if event.pressed:
            touch_points[event.index] = event.position
        else:
            touch_points.erase(event.index)
            if touch_points.size() < 2:
                last_touch_distance = 0.0
            if touch_points.size() == 1:
                _last_touch_centroid = touch_points.values()[0]
    elif event is InputEventScreenDrag:
        touch_points[event.index] = event.position
        if touch_points.size() >= 2:
            var touch_ids: Array = touch_points.keys()
            var p1: Vector2 = touch_points[touch_ids[0]]
            var p2: Vector2 = touch_points[touch_ids[1]]
            var pinch_distance := p1.distance_to(p2)
            if last_touch_distance > 0.0:
                var pinch_delta := pinch_distance - last_touch_distance
                distance = clampf(distance - pinch_delta * 0.12, 38.0, 230.0)
            last_touch_distance = pinch_distance
            _last_touch_centroid = (p1 + p2) * 0.5
            _update_camera()
        elif touch_points.size() == 1:
            var current_position: Vector2 = touch_points[event.index]
            var drag_delta := current_position - _last_touch_centroid
            _last_touch_centroid = current_position
            yaw -= drag_delta.x * 0.22
            pitch = clampf(pitch - drag_delta.y * 0.16, -78.0, -25.0)
            _update_camera()


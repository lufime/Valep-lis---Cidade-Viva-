# Valepólis — Cidade Viva V0.3.0 (Kotlin Android)

## Direção técnica
Esta base inicia a migração de Godot/GDScript para Android nativo com Kotlin. A aplicação usa uma Activity Android nativa e registos JSON em `app/src/main/assets/data/`. Google Filament está declarado como dependência para a futura camada de renderização 3D.

## Estado honesto da migração
- Estrutura Android/Kotlin e navegação inicial: base implementada.
- Registos JSON e imagens selecionadas: incluídos como assets.
- Sistemas de simulação completos, despacho integral, mundo 3D interativo, animações e equivalência funcional total: ainda por migrar.
- A APK só pode ser considerada compilada após sucesso real do workflow GitHub Actions.

## Regras preservadas nesta base
- Valepólis: 1.000.000 habitantes e 25 bairros.
- 200 episódios em 20 temporadas.
- TNUR integrada nas bases BRIGADA, sem bases independentes.
- Propostas de instalações não aprovadas não são criadas automaticamente.
- A economia não deve fabricar saldos, receitas ou despesas.
- A interface deve priorizar legibilidade móvel e alvos de toque grandes.

## Compilação
Executar o workflow **Valepólis V0.3.0 — Kotlin Android Build** em GitHub Actions. Usa Java 17, Gradle 8.9 e Android API 35. O artefacto esperado é `app-debug.apk` com o respetivo SHA-256.


## Fase 1 — território e legibilidade móvel

Esta entrega melhora a legibilidade da navegação nativa e passa a apresentar os 25 registos territoriais a partir de `bairros_valepolis.json`, incluindo nome, população de referência, função territorial e estado tal como fornecidos no JSON. O painel também verifica a quantidade de registos narrativos encontrada em `episodes_200.json`.

**Limitações explícitas:** isto ainda não é a migração completa. Não existe nesta fase um mapa 3D interativo funcional, nem os sistemas completos de trânsito, NPCs, despacho, viaturas ou persistência. Os ecrãs de operações/equipas/veículos/instalações continuam informativos e não devem ser tratados como módulos concluídos.

## Verificação da fase

- Verificar visualmente no Android a legibilidade e navegação.
- Confirmar que a secção Bairros apresenta 25 registos com dados lidos do JSON.
- Confirmar que o painel identifica 200 episódios no registo.
- Compilar novamente no GitHub Actions; esta entrega não declara compilação aprovada até existir uma execução bem-sucedida.


## Fase 2 — mapa territorial 2D

Foi acrescentada uma visualização territorial 2D na secção Bairros. Os pontos e nomes dos bairros são lidos de `bairros_valepolis.json` e posicionados pelas coordenadas `world_position_xz`. É possível tocar num ponto para destacar o bairro e mostrar o seu papel territorial.

A costa norte, o rio/estuário ocidental e as montanhas orientais são representados nesta fase como zonas esquemáticas de orientação. As linhas de estrada também são esquemáticas, não são a rede viária real. Esta visualização **não é um mapa 3D nem substitui o renderizador de terreno**.

Ainda pendente: mapa 3D, geometria e edifícios detalhados, rede viária real, navegação/câmara, tráfego, NPCs e sistemas de despacho.

package pt.valepolis.quandotocaasirene

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

/**
 * Fase 1 da migração nativa: interface móvel legível e leitura real dos registos territoriais.
 * Não representa ainda o motor 3D nem os sistemas operacionais completos.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(5, 20, 30)
    private val panel = Color.rgb(10, 34, 49)
    private val panelAlt = Color.rgb(16, 46, 62)
    private val accent = Color.rgb(239, 202, 94)
    private val muted = Color.rgb(190, 205, 214)
    private lateinit var content: LinearLayout
    private var section = "PAINEL"
    private val localePt = Locale("pt", "PT")
    private val numberFormat: NumberFormat = NumberFormat.getIntegerInstance(localePt)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showShell()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(
        text: String,
        size: Float,
        color: Int = Color.WHITE,
        bold: Boolean = false
    ): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        gravity = Gravity.CENTER_VERTICAL
        setLineSpacing(dp(2).toFloat(), 1.05f)
        contentDescription = text
    }

    private fun showShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(label("VALEPÓLIS — CIDADE VIVA", 24f, accent, true))
        root.addView(label("V0.3.0 · Migração Kotlin nativo · Fase 1", 15f, muted))

        val scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(12))
        }
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        listOf(
            listOf("PAINEL", "BAIRROS"),
            listOf("OPERAÇÕES", "EQUIPAS"),
            listOf("VEÍCULOS", "INSTALAÇÕES")
        ).forEach { names ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            names.forEach { name ->
                row.addView(navButton(name), LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                    marginEnd = dp(4)
                    bottomMargin = dp(4)
                })
            }
            nav.addView(row)
        }
        root.addView(nav)
        setContentView(root)
        renderSection()
    }

    private fun navButton(name: String) = Button(this).apply {
        text = name
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(if (section == name) Color.rgb(100, 78, 29) else panel)
        setPadding(dp(6), dp(6), dp(6), dp(6))
        minHeight = dp(54)
        minWidth = dp(0)
        setOnClickListener {
            section = name
            renderSection()
        }
    }

    private fun card(title: String): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        layout.addView(label(title, 22f, accent, true))
        return layout
    }

    private fun addCard(view: View) {
        content.addView(view, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(12)
        })
    }

    private fun renderSection() {
        content.removeAllViews()
        when (section) {
            "BAIRROS" -> renderNeighborhoods()
            "OPERAÇÕES" -> {
                val c = card("CENTRO DE OPERAÇÕES")
                c.addView(label(
                    "Módulo em migração. Esta versão ainda não despacha ocorrências reais.",
                    17f
                ))
                c.addView(label(
                    "Regra de integridade: uma missão só poderá ser despachada quando existir uma equipa e uma viatura registadas, disponíveis e compatíveis.",
                    16f, muted
                ))
                addCard(c)
            }
            "EQUIPAS" -> {
                val c = card("EQUIPAS E SERVIÇOS")
                c.addView(label(
                    "BRIGADA e TNUR\nTNUR permanece integrada nas bases BRIGADA; não são criadas bases TNUR independentes.",
                    17f
                ))
                c.addView(label(
                    "Os efetivos e a disponibilidade só serão apresentados quando os registos operacionais forem ligados e validados.",
                    16f, muted
                ))
                addCard(c)
            }
            "VEÍCULOS" -> {
                val c = card("GESTÃO DE VIATURAS")
                c.addView(label(
                    "O catálogo de veículos ainda não está ligado ao despacho. Não são atribuídos veículos fictícios nem disponibilidades presumidas.",
                    17f
                ))
                addCard(c)
            }
            "INSTALAÇÕES" -> {
                val c = card("INSTALAÇÕES")
                c.addView(label(
                    "Os registos de instalações estão incluídos nos dados do projeto, mas a visualização e a validação operacional ainda precisam de integração.",
                    17f
                ))
                c.addView(label(
                    "Propostas não aprovadas não são tratadas como instalações oficiais.",
                    16f, muted
                ))
                addCard(c)
            }
            else -> renderDashboard()
        }
    }

    private fun renderDashboard() {
        val c = card("CENTRO DE COMANDO")
        c.addView(label("A IA aconselha. O jogador comanda. A cidade reage.", 18f, Color.WHITE, true))
        c.addView(label("População oficial: 1 000 000", 19f, Color.WHITE, true))
        c.addView(label("Bairros: ${readNeighborhoods().length()} / 25", 18f))
        val episodeCount = readEpisodes()?.optJSONArray("episodes")?.length()
        c.addView(label("Narrativa: ${episodeCount ?: "—"} episódios · 20 temporadas", 18f))
        c.addView(label(
            "Estado da migração: interface e leitura territorial em implementação. O mapa 3D e os sistemas operacionais ainda não estão concluídos.",
            16f, muted
        ))
        addCard(c)

        val dataCard = card("DADOS CARREGADOS")
        val neighborhoods = readNeighborhoods()
        val episodes = readEpisodes()
        dataCard.addView(label(
            if (neighborhoods.length() == 25) "✓ Registo territorial: 25 bairros encontrados"
            else "⚠ Registo territorial: ${neighborhoods.length()} bairros encontrados",
            16f,
            if (neighborhoods.length() == 25) Color.rgb(145, 220, 170) else accent
        ))
        dataCard.addView(label(
            if (episodes?.optJSONArray("episodes")?.length() == 200) "✓ Registo narrativo: 200 episódios encontrados"
            else "⚠ Registo narrativo incompleto ou indisponível",
            16f,
            if (episodes?.optJSONArray("episodes")?.length() == 200) Color.rgb(145, 220, 170) else accent
        ))
        addCard(dataCard)
    }

    private fun renderNeighborhoods() {
        val root = card("TERRITÓRIO DE VALEPÓLIS")
        root.addView(label(
            "Mapa territorial 2D baseado nas coordenadas oficiais dos registos. Ainda não é o renderizador 3D.",
            16f, muted
        ))
        val arr = readNeighborhoods()
        root.addView(NeighborhoodMapView(arr), LinearLayout.LayoutParams(-1, dp(340)).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })
        if (arr.length() == 0) {
            root.addView(label("Não foi possível ler o registo de bairros.", 17f))
        } else {
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("name", "Bairro sem nome")
                val population = item.optLong("population", -1L)
                val role = item.optString("territorial_role", "")
                val active = item.optBoolean("active", true)
                val entry = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(if (i % 2 == 0) panelAlt else panel)
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                entry.addView(label("${item.optInt("id", i + 1)}. $name", 19f, Color.WHITE, true))
                if (population >= 0) {
                    entry.addView(label("População de referência: ${numberFormat.format(population)}", 16f, muted))
                }
                if (role.isNotBlank()) entry.addView(label(role, 16f))
                entry.addView(label(if (active) "Estado do registo: ativo" else "Estado do registo: inativo", 14f, muted))
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply {
                    topMargin = dp(4)
                })
            }
        }
        addCard(root)
    }


    /**
     * Mapa territorial 2D interativo: posições e rótulos são lidos do JSON oficial.
     * A geografia (mar a norte, estuário a oeste e montanhas a este) é uma camada
     * esquemática orientativa; não substitui o terreno/renderizador 3D.
     */
    private inner class NeighborhoodMapView(private val neighborhoods: JSONArray) : View(this@MainActivity) {
        private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(12, 29, 39) }
        private val seaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(23, 74, 101) }
        private val riverPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(32, 100, 128) }
        private val landPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(42, 77, 59) }
        private val mountainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(82, 87, 82) }
        private val roadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(185, 174, 135); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
        }
        private val districtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; style = Paint.Style.FILL }
        private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat()
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = sp(10f); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(dp(2).toFloat(), 0f, 1f, Color.BLACK)
        }
        private val regionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(218, 229, 232); textSize = sp(11f); typeface = Typeface.DEFAULT_BOLD
        }
        private var selectedIndex = -1
        private val points = mutableListOf<Pair<Float, Float>>()

        private fun sp(v: Float) = v * resources.displayMetrics.scaledDensity

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), dp(10).toFloat(), dp(10).toFloat(), backgroundPaint)
            val w = width.toFloat()
            val h = height.toFloat()
            // Norte no topo: costa superior e estuário a oeste.
            canvas.drawRect(0f, 0f, w, h * .18f, seaPaint)
            canvas.drawText("MAR · NORTE", dp(12).toFloat(), dp(22).toFloat(), regionPaint)

            val river = Path().apply {
                moveTo(0f, h * .18f)
                cubicTo(w * .12f, h * .30f, w * .02f, h * .42f, w * .13f, h * .55f)
                cubicTo(w * .18f, h * .66f, w * .06f, h * .78f, w * .11f, h)
                lineTo(0f, h)
                close()
            }
            canvas.drawPath(river, riverPaint)
            canvas.drawText("RIO / ESTUÁRIO", dp(7).toFloat(), h * .48f, regionPaint)

            val mountain = Path().apply {
                moveTo(w * .82f, h * .18f)
                lineTo(w, h * .18f)
                lineTo(w, h)
                lineTo(w * .70f, h)
                lineTo(w * .78f, h * .72f)
                lineTo(w * .74f, h * .52f)
                close()
            }
            canvas.drawPath(mountain, mountainPaint)
            canvas.drawText("MONTANHAS", w * .75f, h - dp(12).toFloat(), regionPaint)

            val mapLeft = w * .17f
            val mapRight = w * .77f
            val mapTop = h * .22f
            val mapBottom = h * .91f
            // Eixos viários esquemáticos; não representam ainda a rede viária navegável.
            canvas.drawLine(mapLeft, mapTop + (mapBottom-mapTop)*.48f, mapRight, mapTop + (mapBottom-mapTop)*.48f, roadPaint)
            canvas.drawLine(mapLeft + (mapRight-mapLeft)*.52f, mapTop, mapLeft + (mapRight-mapLeft)*.52f, mapBottom, roadPaint)
            canvas.drawLine(mapLeft, mapBottom*.80f, mapRight, mapTop + (mapBottom-mapTop)*.22f, roadPaint)

            points.clear()
            var minX = -45.0
            var maxX = 45.0
            var minZ = -45.0
            var maxZ = 45.0
            for (i in 0 until neighborhoods.length()) {
                val obj = neighborhoods.optJSONObject(i) ?: continue
                val pos = obj.optJSONObject("world_position_xz") ?: continue
                minX = minOf(minX, pos.optDouble("x", 0.0))
                maxX = maxOf(maxX, pos.optDouble("x", 0.0))
                minZ = minOf(minZ, pos.optDouble("z", 0.0))
                maxZ = maxOf(maxZ, pos.optDouble("z", 0.0))
            }
            val usableLeft = mapLeft + dp(8)
            val usableRight = mapRight - dp(8)
            val usableTop = mapTop + dp(8)
            val usableBottom = mapBottom - dp(8)
            for (i in 0 until neighborhoods.length()) {
                val obj = neighborhoods.optJSONObject(i) ?: continue
                val pos = obj.optJSONObject("world_position_xz") ?: continue
                val x = pos.optDouble("x", 0.0)
                val z = pos.optDouble("z", 0.0)
                val px = usableLeft + ((x - minX) / (maxX - minX)).toFloat() * (usableRight - usableLeft)
                val py = usableTop + ((z - minZ) / (maxZ - minZ)).toFloat() * (usableBottom - usableTop)
                points.add(px to py)
                if (i == selectedIndex) canvas.drawCircle(px, py, dp(9).toFloat(), selectedPaint)
                canvas.drawCircle(px, py, dp(4.5f.toInt()).toFloat(), districtPaint)
                val name = obj.optString("name", "Bairro")
                canvas.drawText(name, px + dp(5), py - dp(3), textPaint)
            }
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            if (event.action == android.view.MotionEvent.ACTION_UP) {
                var nearest = -1
                var distance = Float.MAX_VALUE
                points.forEachIndexed { index, point ->
                    val dx = event.x - point.first
                    val dy = event.y - point.second
                    val d = dx * dx + dy * dy
                    if (d < distance) { distance = d; nearest = index }
                }
                if (nearest >= 0 && distance < dp(36).toFloat() * dp(36).toFloat()) {
                    selectedIndex = nearest
                    invalidate()
                    val obj = neighborhoods.optJSONObject(nearest)
                    if (obj != null) {
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "${obj.optString("name")} · ${obj.optString("territorial_role")}",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
                return true
            }
            return true
        }
    }

    private fun readJsonObject(file: String): JSONObject? = try {
        assets.open("data/$file").bufferedReader(Charsets.UTF_8).use {
            JSONObject(it.readText())
        }
    } catch (_: Exception) {
        null
    }

    private fun readNeighborhoods(): JSONArray =
        readJsonObject("bairros_valepolis.json")?.optJSONArray("neighborhoods") ?: JSONArray()

    private fun readEpisodes(): JSONObject? = readJsonObject("episodes_200.json")
}

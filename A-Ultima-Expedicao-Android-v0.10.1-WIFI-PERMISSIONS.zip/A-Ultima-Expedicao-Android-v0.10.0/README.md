# A Última Expedição v0.10.0

Esta versão corrige a deteção e inclusão da bridge JavaScript do plugin Capacitor Nearby. Abrir `www/index.html` num navegador normal **não** dá acesso ao Bluetooth nativo; a bridge só é ativada dentro da APK Capacitor Android.

## Compilação

1. Coloque o conteúdo deste projeto no repositório GitHub, preservando `.github/workflows/android-apk.yml`.
2. Execute **Actions → A Última Expedição v0.10.0 — Testes de protocolo e APK Android**.
3. Descarregue o artefacto `A-Ultima-Expedicao-Android-v0.10.0-debug` quando o workflow terminar com sucesso.
4. Instale a APK nos dispositivos Android e aceite as permissões de dispositivos próximos.

## Limitações e validação

- A bridge é compilada pelo esbuild e incluída em `www/js/nearby-bridge.bundle.js`.
- O plugin Android usa Google Play services Nearby Connections, que negocia Bluetooth/Wi-Fi conforme a disponibilidade.
- Este ZIP não contém uma APK pré-compilada. A compilação deve ser executada no GitHub Actions.
- A comunicação real entre dois Android, permissões e reconexão ainda requerem testes físicos. Não considerar validado até esses testes passarem.


## Permissões Android corrigidas (v0.10.0)

O plugin separa as permissões por versão do Android: Android 12+ solicita o grupo Bluetooth/Dispositivos próximos; Android 13+ solicita também a permissão Wi-Fi próxima; Android 10/11 solicita localização para descoberta. A permissão Wi-Fi de Android 13 deixou de fazer parte do mesmo alias Bluetooth, evitando que o Capacitor marque o grupo como recusado em Android 12.


## v0.10.0 — Cenários visuais exploráveis
- Adicionadas cinco imagens de ambiente locais, sem dependência de Internet durante o jogo.
- As nove zonas mapeiam para cenários visuais e incluem marcadores de investigação táteis.
- Os marcadores chamam o sistema de investigação existente, pelo que mantêm consumo de ações, risco e regras de provas.
- O mapa continua disponível a partir do cenário.

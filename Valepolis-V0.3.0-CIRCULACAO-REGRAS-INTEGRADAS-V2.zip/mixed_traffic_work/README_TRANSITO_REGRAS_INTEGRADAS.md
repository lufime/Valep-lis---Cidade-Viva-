# Valepólis V0.3.0 — Regras de circulação integradas

Esta alteração adiciona uma camada simples de espaçamento e redução de velocidade entre os agentes visuais de trânsito.

- Veículos ligeiros e pesados continuam no sistema de agentes partilhado.
- Peões continuam a usar percursos locais de passeio.
- Agentes próximos reduzem a velocidade ou param temporariamente para diminuir sobreposições visuais.
- O código assinala explicitamente que isto não substitui um simulador rodoviário completo.

## Limitações não ocultadas

Os percursos ainda são locais e artificiais. Não estão implementados/validados de forma completa semáforos, prioridades de cruzamento, passadeiras funcionais, deteção de sinalização, regras de ultrapassagem, travagem física, limites reais em km/h ou pathfinding global. A execução no Godot e a compilação Android não foram possíveis neste ambiente; não declarar conformidade legal integral nem testes de runtime aprovados.

# Valepólis V0.3.0 — Trânsito misto

Esta revisão adiciona veículos pesados visuais ao sistema de veículos já existente. Ligeiros e pesados são agentes do mesmo sistema e utilizam o corredor local gerado para cada bairro; os pesados têm carroçaria/cabina/caixa maiores e velocidade base inferior. Os metadados registam classe, lado de circulação à direita e dimensões aproximadas.

## Limitações importantes

- Não foi possível executar o projeto com o Godot neste ambiente.
- Os percursos continuam a ser circuitos locais artificiais; esta alteração não implementa ainda regras completas de cedência de passagem, semáforos, distâncias de segurança, ultrapassagens, limites por classe ou pathfinding global.
- Não declarar a rede como plenamente conforme com o Código da Estrada português até esses sistemas serem implementados e testados.

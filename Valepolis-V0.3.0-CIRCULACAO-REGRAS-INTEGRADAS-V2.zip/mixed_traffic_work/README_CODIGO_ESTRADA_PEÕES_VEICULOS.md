# Valepólis V0.3.0 — Regras de circulação para veículos e peões

## Alterações nesta revisão
- Os peões visuais passam a seguir percursos laterais de passeio, afastados das faixas usadas pelos veículos.
- Os registos dos veículos identificam circulação pela direita e limites/velocidades urbanos de referência distintos para ligeiros e pesados.
- Os registos dos peões explicitam o uso de passeios e a obrigação de atravessar em passadeiras e ceder prioridade quando aplicável.

## Limitações que não devem ser confundidas com implementação completa
Este ajuste não implementa ainda um sistema completo de Código da Estrada. Os percursos dos agentes continuam a ser locais e artificiais. Ainda faltam passadeiras físicas ligadas aos passeios, semáforos, prioridades em cruzamentos, cedência de passagem, sinais STOP/cedência, distâncias de segurança, colisões e travagem, ultrapassagens, limites por tipo de via e validação de rotas contínuas entre bairros e pontes. As velocidades anotadas nos registos são metadados; não se deve assumir conversão e simulação real em km/h sem implementar essa conversão no movimento.

## Validação
A revisão foi verificada por inspeção estática do código e integridade do ZIP. Não foi executada no Godot nem compilada para Android neste ambiente.

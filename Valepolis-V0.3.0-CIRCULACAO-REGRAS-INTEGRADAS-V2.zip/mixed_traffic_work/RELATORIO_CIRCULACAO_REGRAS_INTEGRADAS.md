# Relatório — Circulação e regras integradas

A lógica de seguimento existente foi ampliada para que um veículo considere tanto veículos à frente na mesma faixa como peões dentro da zona frontal de conflito. A regra é deliberadamente conservadora: é preferível travar do que continuar através de um peão detetado.

Não se declara o Código da Estrada integralmente implementado. As rotas ainda são locais e artificiais e os percursos pedonais atuais não atravessam necessariamente passadeiras geradas. Faltam sinalização física e lógica, prioridades por cruzamento, dinâmica de travagem, deteção de colisões e validação em execução.

Estado: revisão estática do ficheiro alterado; execução Godot/APK não realizada neste ambiente.

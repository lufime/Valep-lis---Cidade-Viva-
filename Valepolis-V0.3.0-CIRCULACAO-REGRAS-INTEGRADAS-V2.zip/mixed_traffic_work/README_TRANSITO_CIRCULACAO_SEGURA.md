# Valepólis V0.3.0 — Circulação segura (revisão consolidada)

## Alterações
- Ajustada a verificação de distância para veículos: considera apenas veículos à frente e aproximadamente na mesma faixa, usando o comprimento do veículo para estimar a distância mínima.
- Redução progressiva de velocidade antes de atingir a distância mínima; paragem quando o espaço disponível é insuficiente.
- Peões mantêm a separação entre si e os metadados declaram utilização de passeios e atravessamento apenas em passadeiras.
- Mantidos os veículos ligeiros e pesados no mesmo conjunto de agentes.

## Limitações conhecidas — não declarar conformidade integral
- Os percursos existentes continuam a ser locais e artificiais; não existe ainda encaminhamento global sobre uma malha viária física validada.
- Os metadados de passadeiras/cedência não criam, por si só, passadeiras ou semáforos físicos.
- Não foram testados sinais, prioridades em cruzamentos, rotundas, ultrapassagens, limites legais por tipo de via, nem comportamento de emergência.
- O Godot não estava disponível neste ambiente; a execução do jogo e a compilação APK ficam pendentes.

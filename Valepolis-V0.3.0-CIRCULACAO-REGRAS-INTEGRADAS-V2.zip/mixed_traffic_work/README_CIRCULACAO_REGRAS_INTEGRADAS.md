# Valepólis V0.3.0 — Circulação integrada

## Alteração desta consolidação
- Veículos ligeiros e pesados continuam no mesmo conjunto de agentes.
- A verificação longitudinal distingue veículos na mesma faixa de peões que estejam diretamente na zona frontal de conflito.
- O veículo reduz/paralisa a progressão quando deteta um peão nessa zona, como salvaguarda básica.
- Foi evitada uma declaração local duplicada para a direção de movimento.

## Limitações explícitas
Isto não constitui uma implementação integral ou certificada do Código da Estrada. O mapa ainda necessita de passadeiras físicas ligadas aos passeios, semáforos com fases, prioridades nos cruzamentos, sinais de STOP/cedência, limites de velocidade por tipo de via, travagem física, colisões e pathfinding contínuo sobre a rede rodoviária. A deteção de peões é uma salvaguarda geométrica básica e depende das posições dos agentes.

## Validação
- Alteração confirmada por comparação textual do script.
- Integridade do ZIP deve ser verificada no momento da criação.
- Godot não está disponível neste ambiente; não foi possível executar a cena, validar sintaxe com o motor ou compilar a APK.

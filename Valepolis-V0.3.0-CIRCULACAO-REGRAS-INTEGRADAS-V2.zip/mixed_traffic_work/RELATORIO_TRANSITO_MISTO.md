# Relatório — Trânsito misto

## Alterações
- Os veículos existentes continuam a usar o sistema de agentes de trânsito.
- Uma parte dos veículos foi convertida em veículos pesados, com chassis, cabina, caixa e rodas maiores.
- Os pesados têm velocidade base inferior à dos ligeiros.
- Cada agente regista `vehicle_class`, `road_side`, `length` e `width`.
- Os veículos ligeiros e pesados permanecem integrados na mesma lista `_ambient_agents`.

## Verificações executadas
- Verificação textual da presença dos novos campos e da construção visual do pesado.
- Integridade do ZIP a testar após criação.

## Não validado
- Sintaxe/execução no Godot; não há executável Godot disponível neste ambiente.
- Conformidade integral com o Código da Estrada, circulação entre bairros e pontes, colisões, cedências, semáforos, distâncias de segurança e desempenho Android.

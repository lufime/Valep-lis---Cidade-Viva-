# Valepólis V0.3.0 — FASE 6.2.2 / BUILD 622

## Alterações no código
- Corrigida a direção do eixo procedural do rio: setor montanhoso oriental para o estuário ocidental.
- O vale fluvial usa a mesma função do eixo do rio, para alinhar depressão do terreno e superfície de água.
- A faixa de água usa mais secções e alarga gradualmente em direção à foz.
- A malha base do terreno passou de 80×80 para 128×128 células e recebeu uma componente determinística adicional de relevo multiescala.
- Identificadores de diagnóstico da cena atualizados para BUILD 622.
- Os dados territoriais e os limites dos 25 bairros não foram editados.

## Limitações e validação pendente
O relevo e o rio continuam a ser gerados proceduralmente; não são dados topográficos ou hidrográficos medidos. Não declarar o mapa aprovado com base apenas nestas alterações. É necessária compilação Android, execução no dispositivo e revisão visual de continuidade do rio, ligação à foz, interseções com bairros/edifícios, desempenho e zoom.

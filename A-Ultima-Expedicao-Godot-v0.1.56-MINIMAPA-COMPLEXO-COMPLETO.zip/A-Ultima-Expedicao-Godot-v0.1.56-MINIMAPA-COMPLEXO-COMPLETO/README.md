# A Última Expedição 3D — v0.1.43 Correção de parsing e áudio

Protótipo experimental Godot 4.5: exploração em primeira pessoa, controlos táteis, painel LAN, relés cooperativos, pistas privadas, votação narrativa, furtividade e entidade reativa.

## Correções nesta versão
- Corrigida uma string inválida no texto de ajuda dos controlos táteis.
- Adicionado painel recolhível “REDE LAN” para criar sessão ou entrar pelo IP do anfitrião (porta UDP 24567), ancorado à direita para se adaptar melhor a ecrãs estreitos.
- O agachamento altera a câmara, velocidade e cápsula de colisão.
- O aviso de interação distingue os relés da porta.
- Relatório de validação em `docs/RELATORIO_VALIDACAO.md`.

## Abrir
Extrai o ZIP e abre a pasta que contém `project.godot` no Godot 4.5. A cena inicial é `res://scenes/Boot.tscn`.

## Estado dos testes
O ZIP foi verificado. O motor Godot 4.5 não está disponível neste ambiente, pelo que não foi possível compilar/importar ou executar o projeto. A rede entre dispositivos, os RPCs, os controlos táteis em Android e a exportação APK **continuam por validar**. Esta versão não está aprovada para lançamento.

## Build Android
O projeto contém `export_presets.cfg` para Android. O workflow presente nesta versão é `.github/workflows/quality.yml`: executa auditoria estática, importação e arranque headless com Godot 4.5, mas **não exporta uma APK**. A exportação Android continua a exigir um workflow próprio com SDK, templates e uma execução concluída com sucesso.


## Controlos táteis Android
- Joystick virtual no canto inferior esquerdo: andar em qualquer direção.
- Arrastar no lado direito do ecrã: rodar a câmara.
- Botões do lado direito: interagir, lanterna e agachar/levantar.
\n\n## Vozes e vocalizações contextuais (v0.1.8)\n\nForam adicionados efeitos vocais sintéticos locais, sem dependência de Internet: sussurro distante quando a entidade inicia a perseguição, grito curto em perigo imediato, gemido quando desaparece ao ser observada e gasp quando a equipa ativa os dois relés. São vocalizações não verbais; diálogo falado com palavras ainda precisa de gravações/locução próprias. Os eventos têm cooldown para evitar repetição excessiva.\n

## Modo cooperativo WLAN (sem Internet)
- Ambos os telemóveis têm de estar ligados à mesma rede Wi-Fi local. A rede pode não ter acesso à Internet.
- No telemóvel anfitrião, toque em **Criar sessão**.
- Descubra o endereço IPv4 local do anfitrião nas definições Wi-Fi do Android.
- No segundo telemóvel, abra **REDE LAN**, introduza esse endereço IPv4 (não use `127.0.0.1`) e toque em **Ligar**.
- A porta de jogo é UDP 24567. Se a rede tiver isolamento de clientes, os dispositivos podem não conseguir comunicar.
- Esta versão usa ENet sobre WLAN. **Não implementa Bluetooth nem Wi-Fi Direct**.
- O estado do código e os RPCs ainda precisam de ser testados no Godot 4.5 e em dois dispositivos reais; este ZIP não é uma compilação validada.


## Alterações v0.1.9
- Introdução cinematográfica de 4 segundos antes do menu, com barra de progresso visível de 000% a 100%.
- Modelos humanos 3D procedurais para o jogador cooperativo remoto e para a entidade; o jogador local recebe corpo, braços, pernas, botas, colete refletor e mochila sem cabeça para evitar obstrução da câmara em primeira pessoa.
- Interface renovada com paleta azul-petróleo, acentos dourados, botões maiores e estados de foco/pressão mais claros para ecrãs táteis.
- Corrigida a indentação inconsistente em `scripts/mini_map.gd`.

## Validação desta revisão
Os ficheiros foram verificados estaticamente e o ZIP foi validado. O Godot 4.5 não está instalado neste ambiente, portanto a importação, a execução da introdução, a renderização dos modelos 3D e a exportação da APK ainda precisam de ser testadas no motor/GitHub Actions. Os humanos são modelos procedurais de baixa complexidade, não personagens fotorealistas com rigging/animações.


## v0.1.14 — VANTHIS, missão inicial e traidor
- A página inicial apresenta a introdução pública da Estação Véspera e os objetivos oficiais, sem mencionar o traidor nem revelar a natureza da ameaça.
- Em sessão multijogador, o anfitrião atribui aleatoriamente um papel secreto depois de entrar o primeiro cliente. A pessoa escolhida recebe em privado “ÉS O TRAIDOR” e os objetivos da VANTHIS Corporation; os restantes recebem o papel de explorador.
- A criatura é criada no início de cada execução e a lógica de comportamento existente continua a ser controlada pela IA; não existe seleção de jogador para controlar a criatura.
- O papel do traidor não é divulgado no painel público.

### Limitações conhecidas desta revisão
- A atribuição do traidor ocorre quando o primeiro cliente se liga, porque o protótipo ainda não tem um lobby separado com botão de iniciar partida. A entrada tardia de outros jogadores depois da atribuição não provoca nova distribuição de papéis.
- O protótipo ainda não sincroniza de forma autoritativa a posição/estado da criatura entre todos os clientes; a IA existente executa localmente em cada instância. Portanto, a presença da criatura e o papel secreto foram integrados no código, mas a experiência multijogador completa não deve ser considerada validada.
- A validação com Godot 4.5, rede entre dispositivos e APK continua pendente.


## v0.1.26 — Equipamento polar visível
- Atualizado o modelo humano procedural para o cenário do Polo Norte: parka isolante, capuz, proteção facial, óculos de neve, luvas térmicas, botas polares e mochila de sobrevivência com rádio.
- Atualizado o separador de inventário para identificar o equipamento visual e declarar claramente que a simulação de hipotermia/temperatura ainda não está implementada.
- Alteração estática do código e validação estrutural do ZIP; Godot 4.5 não está disponível neste ambiente, pelo que não foi possível executar a cena nem confirmar a renderização no motor.


## V0.1.27 — Diretor de suspense polar
A versão acrescenta sinais ambientais variáveis antes do primeiro contacto visual. Ver `docs/RELATORIO-V0.1.27-DIRETOR-SUSPENSE-POLAR.md` para o âmbito e as limitações de validação.


## V0.1.28 — Suspense dinâmico
Removido o cronómetro fixo da primeira aparição. A criatura passa a depender dos acontecimentos narrativos existentes; os sinais ambientais continuam variáveis. Ver `docs/RELATORIO-V0.1.28-SUSPENSE-DINAMICO.md`.


## V0.1.29 — 10 zonas com várias salas
Cada uma das 10 zonas recebe duas salas laterais adicionais à sala principal, totalizando 30 salas físicas geradas proceduralmente. Ver `docs/RELATORIO-V0.1.29-10-ZONAS-MULTISALAS.md`. Runtime Godot ainda não validado.


## V0.1.30 — Salas auxiliares variadas
As duas salas adicionais de cada zona têm agora nomes, funções e mobiliário procedural distintos. Ver `docs/RELATORIO-V0.1.30-SALAS-VARIADAS.md`. A execução no Godot não foi validada.


## V0.1.31 — Sala secreta da experiência original
- Acrescentada uma câmara secreta VANTHIS junto da Zona 10, com acesso selado.
- Dez provas interativas foram distribuídas pelas dez zonas.
- A recolha das provas é sincronizada pelo servidor durante uma sessão multijogador.
- A porta só abre após a recolha dos dez fragmentos; abrir antes apresenta quantas provas faltam.
- A câmara contém cenário e registos narrativos da experiência original.
- O projeto foi validado estruturalmente no ZIP; não foi possível executar o projeto no motor Godot nesta sessão.


## V0.1.32 — Sistema de pistas e síntese de provas
- As dez provas são recolhidas individualmente nas dez zonas e o progresso é sincronizado pelo servidor.
- A recolha, por si só, já não desbloqueia a porta secreta.
- Foi acrescentada uma consola de síntese no exterior da porta: os jogadores têm de interagir com ela depois de reunirem todas as provas.
- A consola valida os dez fragmentos, constrói a cadeia narrativa da experiência VANTHIS e só então autoriza a abertura da porta.
- A porta indica se faltam provas ou se a síntese ainda não foi executada.
- Validação estrutural do ZIP efetuada; execução no motor Godot e teste multijogador real não efetuados nesta sessão.


## V0.1.33 — combinação da sala secreta

A sala secreta exige agora as dez provas e a descoberta de uma combinação de quatro algarismos. Quatro documentos contêm pistas que, pela ordem dos registos, formam o código. Introduz o código na consola VANTHIS; uma tentativa errada não abre a porta. Consulta `docs/RELATORIO-V0.1.33-COMBINATION.md` para o relatório técnico.


## V0.1.34 — pistas de localização

A porta secreta e a consola ficam ocultas no início. As provas revelam gradualmente a parede falsa a oeste da Zona 10 e a consola junto da passagem selada. Ao reunir as dez provas, os objetos são revelados; depois é necessário deduzir o código e abrir a porta. Relatório: `docs/RELATORIO-V0.1.34-PISTAS-LOCALIZACAO.md`.


## V0.1.35 — combinação lógica

A combinação exige cruzar registos de turnos, ciclos, alarmes confirmados e sequência dos procedimentos; o código não aparece escrito diretamente nas provas. Consulte `docs/RELATORIO-V0.1.35-COMBINACAO-LOGICA.md`.


## V0.1.37 — validação do segredo e sincronização

- A consola só é revelada pelo anfitrião após as dez provas; os clientes recebem o estado por RPC fiável.
- A porta permanece invisível e sem colisão até o anfitrião validar a combinação.
- A combinação tem uma regra de dedução verificável: alertas confirmados, ciclos rejeitados, circuito isolado primeiro e primeiro ciclo estável. A sequência é 7, 3, 1, 4; nenhum documento contém o código completo.
- O estado das provas e do acesso é enviado a jogadores que entram numa sessão já em curso.
- O anfitrião valida a combinação e a abertura; clientes não devem desbloquear o segredo localmente.
- O ZIP foi verificado estruturalmente. A compilação GDScript, o teste de rede real e a execução no Godot 4.5 continuam pendentes.


## v0.1.37 — validação do segredo e sincronização multijogador
- As dez provas revelam a consola, mas mantêm a porta invisível e sem colisão até o anfitrião validar a combinação.
- A combinação é dedutível pelas quatro pistas em ordem: sete alertas confirmados, três ciclos rejeitados, circuito 1 isolado primeiro e primeiro ciclo estável no ciclo 4 (7314).
- O progresso das provas, a síntese e o estado da porta são enviados a clientes existentes e a quem entra numa sessão em curso.
- Relatório: `docs/RELATORIO-V0.1.37-VALIDACAO-SEGREDO-MULTIJOGADOR.md`.

**Limitação de validação:** o ZIP foi verificado estruturalmente. O Godot 4.5 não está disponível neste ambiente; compilação GDScript, execução real, teste de rede em dois dispositivos e exportação APK não foram confirmados.


## V0.1.38 — auditoria e integração contínua
- Adicionado um auditor estático de recursos e contratos de jogo em `tests/quality_audit.py`.
- Adicionados testes automáticos para a existência de cenas/scripts, dez provas, código dedutível, autoridade do anfitrião, criatura controlada pela IA e atribuição privada do traidor.
- Adicionado workflow GitHub Actions para executar os testes estáticos e a importação/arranque headless com Godot 4.5.
- Atualizado o caminho de exportação Android para V0.1.38.

O workflow de qualidade não substitui testes reais entre dispositivos nem garante a exportação APK. A APK só deve ser considerada criada se uma execução específica de exportação Android terminar com sucesso.


## V0.1.39 — traidor IA oculto no Single Player
- O modo individual passa a incluir uma IA de traidor separada da criatura.
- O traidor permanece sem identificação pública, provoca perturbações temporárias nos sistemas e deixa mensagens ambíguas para investigação.
- Pode surgir uma silhueta humana distante por um breve instante, sem nome, identificação de papel ou revelação direta.
- O comportamento só é ativado em modo individual depois de a criatura entrar em jogo; não altera a atribuição do traidor humano em multijogador.
- As perturbações não provocam mortes automáticas: funcionam como sinais narrativos e pistas ambientais.

**Validação:** a alteração foi revista estaticamente e o ZIP será verificado. A compilação Godot 4.5, a execução da IA em jogo e a APK continuam por testar num ambiente com Godot.


## V0.1.40 — Personagens e criatura 3D melhorados
- Reforçado o modelo humano procedural com proteções de ombros e joelhos, sola de botas, cinto utilitário, fivelas, depósitos de oxigénio e identificação de expedição.
- Substituída a silhueta humanoide da entidade por um modelo procedural distinto: anatomia alongada, costelas expostas, crânio angular, olhos emissivos, braços compridos, garras, espigões dorsais e apêndice posterior.
- Os modelos usam primitivas 3D nativas, sem downloads externos, para preservar a portabilidade e reduzir dependências.
- Validação estática e integridade do ZIP realizadas. A renderização, as proporções finais, as animações e o desempenho precisam de confirmação no Godot 4.5 e num dispositivo Android; não são modelos importados de alta fidelidade nem possuem rigging/ animações completas.


## v0.1.50 — Single Player jogável sem segundo participante
- Corrigido o bloqueio dos relés: em modo individual, o jogador pode ativar o Relé A e depois deslocar-se até ao Relé B para o ativar sozinho.
- A porta da câmara passa a desbloquear quando ambos os relés estão ativos em Single Player; no multijogador online mantém-se a regra de participantes diferentes.
- As decisões ACUSAR/DEFENDER deixam de exigir uma sessão LAN ou um segundo voto no modo individual. A escolha do jogador resolve imediatamente a decisão e aplica a respetiva consequência.
- O painel de objetivos apresenta tarefas individuais no modo Single Player e mantém os requisitos cooperativos quando existe uma sessão online.
- As chamadas de sincronização remota das provas, combinação e porta são omitidas em modo local, evitando depender de uma ligação de rede para completar a investigação.

**Validação:** revisão estática das alterações e teste de integridade do ZIP. Godot 4.5 não está instalado neste ambiente; compilação, execução integral, colisões e APK ainda precisam de ser testadas no motor.


## v0.1.50 — personagens e criatura com animação procedural

- Adicionado `scripts/procedural_model_animator.gd` para animação leve de membros, tronco, cabeça e apêndices, sem dependências externas.
- Personagem do jogador: balanço de braços/pernas conforme o movimento e respiração subtil em repouso.
- Traidor: silhueta com movimento discreto, mantendo a identidade oculta.
- Criatura: animação diferente para patrulha e caça, com movimento assimétrico de braços, pernas, tronco, cabeça e tendril.
- Rosto humano com mais leitura visual: sobrancelhas, ponte nasal e respirador polar.
- Os modelos continuam a ser geometria procedural low-poly; não são modelos escaneados nem rigs profissionais.
- Validação de compilação/runtime Godot 4.5 ainda necessária.


## v0.1.50 — correção do erro de parsing e áudio espacial
- Corrigida a indentação do bloco `if _is_solo_session()` em `scripts/expedition.gd`, que impedia o Godot 4.5 de carregar o script (erro reportado na linha 2571).
- Os emissores de áudio 3D são agora libertados quando o som termina, evitando acumulação de nós durante sessões longas.
- Mantidos os efeitos locais existentes: passos, roupa, respiração, cliques, motores, sussurros e sinais de suspense.
- O workflow `.github/workflows/quality.yml` executa auditoria estática, importação e arranque headless com Godot 4.5. A validação final deve ser confirmada no resultado do GitHub Actions.


## v0.1.50 — Correção de tipo GDScript

Corrigida a inferência do tipo `claw` na criação das garras da criatura, declarando explicitamente `ConeMesh` para evitar o erro de parsing reportado pelo Godot 4.5. Esta alteração resolve o erro específico; a compilação completa deve ser confirmada no workflow Godot.


## V0.1.50 — correções de parsing Godot 4.5
- Tipagem explícita de `both_active` para evitar inferência ambígua de valores de Dictionary.
- Declaração de `MODEL_ANIMATOR_SCRIPT` através de preload do script procedural existente.
- Substituição de `ConeMesh` (tipo inexistente em Godot 4.5) por `CylinderMesh` com `top_radius = 0.0`, formando garras cónicas.


## V0.1.50 — Pistas físicas diferenciadas
As dez provas físicas usam formas de objetos distintos (frasco, gravador, documento, módulo de dados e fragmento de equipamento), em vez de uma única forma retangular genérica. Alteração visual estática; não representa validação de execução no Godot.


## V0.1.50 — Consolas industriais 3D
Os dois pontos de cooperação usam agora painéis industriais com placa metálica, indicadores luminosos, botões físicos e grelha de ventilação. O rótulo foi reposicionado para reduzir a sobreposição visual. A validação de parsing e a execução no Godot 4.5 ainda têm de ser confirmadas no workflow.


## V0.1.50 — Objetivos sem spoilers
O painel de objetivos do modo individual já não revela antecipadamente a existência de uma passagem secreta nem menciona uma combinação. A progressão secreta continua dependente da recolha e análise das provas.

## V0.1.50 — Revelação gradual e som dinâmico da criatura
- Removido o temporizador arbitrário de revelação: a criatura não aparece apenas porque passou determinado tempo; a revelação fica ligada a acontecimentos narrativos e ações da investigação.
- A tensão é construída primeiro por sinais ambientais.
- Vocalizações usam vários clips locais, variação de pitch e intervalos aleatórios, com sons mais intensos em situações de perigo.
- Testes Godot/runtime ainda necessários; não declarar build aprovado até executar o workflow.


## V0.1.54 — Revelação narrativa sem temporizador arbitrário
- Removida a regra de aparição baseada em 78–112 segundos.
- A direção de suspense continua a poder apresentar sinais ambientais, mas não força a revelação da criatura por tempo decorrido.
- A validação em runtime Godot 4.5 continua pendente.


## V0.1.54 — Modelos 3D com detalhe adicional

Aprimorados os modelos procedurais da equipa e da criatura com acessórios de expedição, costuras, correias, bolsos, fivelas, lanterna frontal, detalhes de rádio e relevos adicionais na silhueta da criatura. Mantém-se a geração nativa por malhas do Godot, sem dependências externas. A compilação Godot e a inspeção visual em dispositivo devem ser executadas no workflow antes de considerar a qualidade validada.


## V0.1.54 — Estado real dos relés

Os indicadores físicos dos relés A/B passam a refletir o estado lógico: âmbar/«À ESPERA» quando inativos e verde/«SISTEMA ATIVO» após ativação. O estado é atualizado pela mesma função que recebe a sincronização dos relés.


## V0.1.54 — Exterior e meteorologia
- Criada uma zona exterior 3D explorável ligada ao corredor de saída existente.
- Campo de neve, caminho compactado, bancos de neve, abrigo de gerador, antenas e luzes de orientação.
- Queda de neve por partículas e rajadas de vento variáveis que alteram a intensidade da neve e do sinalizador.
- A integração com o gerador é ambiental/visual nesta versão; não foi afirmada ligação à lógica de energia sem testes.


## V0.1.56 — Exterior integrado e meteorologia funcional
- Verificada a continuidade geométrica entre o corredor de saída e o terreno exterior.
- Adicionado áudio de vento polar apenas quando o jogador está no exterior.
- A visibilidade da câmara diminui durante as rajadas e recupera ao regressar ao interior.
- Indicador meteorológico mostra neve moderada, vento polar ou tempestade e intensidade variável.
- Mantida a meteorologia procedural e o caminho físico para o abrigo do gerador.
- Validação Godot pendente: esta alteração foi revista estaticamente; não foi possível executar o motor nesta sessão.


## V0.1.56 — minimapa do complexo completo
O minimapa foi ampliado para representar esquematicamente a estação, as alas interiores, a saída, o caminho exterior, o abrigo do gerador e os instrumentos meteorológicos. A posição do jogador, dos colegas e da presença usa uma transformação global única.

#!/usr/bin/env python3
"""Standalone PRE-FLIGHT runner for Valepólis V0.3.0. Uses only Python stdlib."""
from __future__ import annotations
import argparse, datetime, hashlib, json, os, re, shutil, subprocess, sys
from pathlib import Path

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main() -> int:
    ap = argparse.ArgumentParser(description="Auditoria independente do projeto Godot Valepólis.")
    ap.add_argument("project", help="Pasta raiz do projeto Godot (contém project.godot)")
    ap.add_argument("--godot", default="", help="Executável Godot 4.x; por omissão procura godot/godot4")
    ap.add_argument("--export-apk", action="store_true", help="Tenta exportar APK Android (requer preset Android e SDK)")
    ap.add_argument("--report-dir", default="", help="Pasta para relatórios; por omissão usa reports/ ao lado deste script")
    args = ap.parse_args()

    root = Path(args.project).expanduser().resolve()
    tool_dir = Path(__file__).resolve().parent
    report_dir = Path(args.report_dir).expanduser().resolve() if args.report_dir else tool_dir / "reports"
    report_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.datetime.now().astimezone().strftime("%Y%m%d-%H%M%S")
    report = report_dir / f"PRE-FLIGHT-V030-{stamp}.txt"
    log_dir = report_dir / f"logs-{stamp}"
    log_dir.mkdir(parents=True, exist_ok=True)

    results = []
    def check(label, ok, detail=""):
        results.append(("PASS" if ok else "FAIL", label, detail))
    def note(label, detail=""):
        results.append(("INFO", label, detail))
    def skip(label, detail=""):
        results.append(("SKIP", label, detail))
    def run_cmd(label, cmd, cwd, log_name, timeout=600):
        try:
            p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                               text=True, errors="replace", timeout=timeout)
            (log_dir / log_name).write_text(p.stdout, encoding="utf-8")
            ok = p.returncode == 0
            check(label, ok, f"exit={p.returncode}; log={log_name}")
            return ok, p.stdout, p.returncode
        except FileNotFoundError:
            skip(label, f"Executável não encontrado: {cmd[0]}")
            return None, "", None
        except subprocess.TimeoutExpired as e:
            out = e.stdout or ""
            if isinstance(out, bytes): out = out.decode("utf-8", "replace")
            (log_dir / log_name).write_text(out + "\nTIMEOUT\n", encoding="utf-8")
            check(label, False, f"timeout; log={log_name}")
            return False, out, -1

    note("Projeto", str(root))
    check("Pasta do projeto existe", root.is_dir(), str(root))
    required = ["project.godot", "Main.tscn", "main.gd", "export_presets.cfg"]
    for rel in required:
        check(f"Ficheiro essencial: {rel}", (root / rel).is_file(), rel)

    if not (root / "project.godot").is_file():
        check("Auditoria estática interrompida", False, "project.godot em falta")
    else:
        project_text = (root / "project.godot").read_text(encoding="utf-8", errors="replace")
        scene_text = (root / "Main.tscn").read_text(encoding="utf-8", errors="replace") if (root / "Main.tscn").exists() else ""
        main_text = (root / "main.gd").read_text(encoding="utf-8", errors="replace") if (root / "main.gd").exists() else ""
        export_text = (root / "export_presets.cfg").read_text(encoding="utf-8", errors="replace") if (root / "export_presets.cfg").exists() else ""
        check("Versão ativa V0.3.0", 'config/version="0.3.0"' in project_text, 'project.godot')
        check("Cena principal declarada", 'run/main_scene="res://Main.tscn"' in project_text, 'res://Main.tscn')
        check("Script principal ligado à cena", 'res://main.gd' in scene_text, 'Main.tscn')
        # Regra crítica contra o ecrã preto: o SubViewport preexistente tem de
        # receber City3D, não apenas ser tornado visível.
        map_setup = re.search(r"func _v030_setup_2d_map\(\) -> void:(.*?)(?=\nfunc )", main_text, re.S)
        map_setup_text = map_setup.group(1) if map_setup else ""
        check("Mapa 3D anexado ao SubViewport existente",
              'viewport.get_node_or_null("ValepolisCity3D")' in map_setup_text
              and 'viewport.add_child(city_instance)' in map_setup_text
              and 'viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS' in map_setup_text,
              "MAP_RENDER_FAIL será acionado se o viewport ficar vazio")
        check("Preset Android existe", 'name="Android"' in export_text, 'export_presets.cfg')
        check("Preset Android V0.3.0", 'version/name="0.3.0"' in export_text, 'export_presets.cfg')
        check("versionCode Android = 30000", 'version/code=30000' in export_text, 'export_presets.cfg')

        # Validate all JSON files, but skip generated Godot caches.
        json_files = [p for p in root.rglob("*.json") if ".godot" not in p.parts and "build" not in p.parts]
        json_errors = []
        for p in json_files:
            try: json.loads(p.read_text(encoding="utf-8"))
            except Exception as e: json_errors.append(f"{p.relative_to(root)}: {e}")
        check(f"JSON válido ({len(json_files)} ficheiros)", not json_errors, "; ".join(json_errors[:5]))

        # Static literal resource reference scan.
        resource_exts = {".gd",".tscn",".tres",".res",".scn",".json",".svg",".png",".jpg",".jpeg",".webp",".ogg",".wav",".ttf",".otf",".mp3"}
        refs = {}
        for p in list(root.rglob("*.gd")) + list(root.rglob("*.tscn")) + list(root.rglob("*.tres")) + [root/"project.godot", root/"export_presets.cfg"]:
            if not p.is_file() or ".godot" in p.parts or "build" in p.parts: continue
            txt = p.read_text(encoding="utf-8", errors="replace")
            for ref in re.findall(r'res://[^"\s,)]+', txt):
                if Path(ref).suffix.lower() in resource_exts:
                    refs.setdefault(ref, []).append(p.relative_to(root).as_posix())
        missing = [(ref, owners) for ref, owners in refs.items() if not (root / ref.removeprefix("res://")).is_file()]
        check(f"Referências res:// ({len(refs)} verificadas)", not missing,
              "; ".join(f"{r} em {','.join(o[:2])}" for r,o in missing[:8]))

        # Duplicate functions and constants within each script.
        dupes = []
        for p in root.rglob("*.gd"):
            if ".godot" in p.parts or "build" in p.parts: continue
            txt = p.read_text(encoding="utf-8", errors="replace")
            funcs = re.findall(r"^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(", txt, re.M)
            consts = re.findall(r"^const\s+([A-Za-z_][A-Za-z0-9_]*)", txt, re.M)
            for kind, vals in (("func", funcs), ("const", consts)):
                repeated = sorted({v for v in vals if vals.count(v) > 1})
                if repeated: dupes.append(f"{p.relative_to(root)} {kind}: {','.join(repeated)}")
        check("Sem funções/constantes duplicadas por script", not dupes, "; ".join(dupes[:8]))

        # Core project-specific integrity checks, only when corresponding files exist.
        city = root / "city_3d.gd"
        city_system = root / "systems" / "city_3d.gd"
        city_path = city if city.exists() else city_system
        check("Script da cidade 3D localizado", city_path.exists(),
              str(city_path.relative_to(root)) if city_path.exists() else "city_3d.gd não encontrado na raiz nem em systems/")
        if city_path.exists():
            city_text = city_path.read_text(encoding="utf-8", errors="replace")
            check("Script da cidade contém rotina de integração de instalações",
                  "_build_registered_installations()" in city_text and "get_map_spawnable_installations" in city_text,
                  str(city_path.relative_to(root)))
            # Compare neighbourhoods only when catalogue shape is recognizable.
            hood_file = root / "bairros_valepolis.json"
            if hood_file.exists():
                try:
                    hd = json.loads(hood_file.read_text(encoding="utf-8"))
                    names = {x.get("name") for x in hd.get("neighborhoods", [])}
                    m = re.search(r"const NEIGHBORHOODS\s*:?[^=]*=\s*\[(.*?)\]", city_text, re.S)
                    map_names = set(re.findall(r'"([^"\n]+)"', m.group(1))) if m else set()
                    check("25 bairros oficiais coincidem com o mapa 3D",
                          len(names) == 25 and len(map_names) == 25 and names == map_names,
                          f"catálogo={len(names)}; mapa={len(map_names)}")
                except Exception as e:
                    check("Catálogo de bairros legível", False, str(e))

        # Ensure no accidental unapproved financial baseline is being invented.
        econ = root / "data" / "economy_config.json"
        if econ.exists():
            try:
                ed = json.loads(econ.read_text(encoding="utf-8"))
                salary_file = root / "data" / "salary_by_profession_proposal_v030.json"
                salary_data = json.loads(salary_file.read_text(encoding="utf-8")) if salary_file.exists() else {}
                salary_records = salary_data.get("professions", [])
                salary_ids = [str(item.get("ID", "")) for item in salary_records]
                tax_model = ed.get("tax_model") or {}
                valid_economy_reference = (
                    salary_data.get("status") == "approved_gameplay_reference_rules"
                    and len(salary_records) == 800
                    and all(salary_ids)
                    and len(set(salary_ids)) == len(salary_ids)
                    and all(item.get("Salario_bruto_mensal_proposto_EUR") is not None for item in salary_records)
                    and ed.get("status") == "approved_rules_values_pending"
                    and tax_model.get("social_security_rate") == 0.11
                    and isinstance(tax_model.get("irs_marginal_brackets"), list)
                    and isinstance(tax_model.get("consumption_tax_rates"), dict)
                )
                check("Catálogo salarial de referência e modelo fiscal presentes",
                      valid_economy_reference,
                      "catálogo salarial ou configuração fiscal de referência inválidos")
            except Exception as e:
                check("Configuração económica legível", False, str(e))

    # Structural regional-road audit. This is static only and never substitutes Godot runtime tests.
    regional_checker = root / "tools" / "preflight_regional_roads.py"
    if regional_checker.is_file():
        regional_ok, regional_output, regional_code = run_cmd(
            "Auditoria estrutural da rede rodoviária regional",
            [sys.executable, str(regional_checker)], root, "regional-roads-audit.log", timeout=120)
        if regional_ok is None:
            skip("Auditoria estrutural da rede rodoviária regional", "Python não disponível")
    else:
        skip("Auditoria estrutural da rede rodoviária regional", "tools/preflight_regional_roads.py não existe")

    # Optional runtime stage; report SKIP rather than pretending it passed.
    godot = args.godot or shutil.which("godot") or shutil.which("godot4")
    if godot and root.is_dir() and (root / "project.godot").exists():
        imp_ok, _, _ = run_cmd("Importação Godot headless", [godot, "--headless", "--editor", "--path", str(root), "--quit"],
                               root, "godot-import.log", timeout=900)
        functional = root / "tools" / "preflight_functional.gd"
        if functional.exists():
            run_cmd("Teste funcional Godot", [godot, "--headless", "--path", str(root), "--script", "tools/preflight_functional.gd"],
                    root, "godot-functional.log", timeout=900)
        else:
            skip("Teste funcional Godot", "tools/preflight_functional.gd não existe")
        if args.export_apk:
            apk = log_dir / "Valepolis-V0.3.0-preflight.apk"
            run_cmd("Exportação APK Android", [godot, "--headless", "--path", str(root), "--export-release", "Android", str(apk)],
                    root, "godot-export.log", timeout=1800)
            check("APK exportado e não vazio", apk.is_file() and apk.stat().st_size > 0, str(apk))
        else:
            skip("Exportação APK Android", "Não solicitada; usar --export-apk")
    else:
        skip("Importação Godot headless", "Godot 4.x não encontrado; validação de runtime não executada")
        skip("Teste funcional Godot", "Godot 4.x não encontrado; teste funcional não executado")
        skip("Exportação APK Android", "Godot não encontrado ou exportação não solicitada")

    fails = sum(s == "FAIL" for s,_,_ in results)
    skips = sum(s == "SKIP" for s,_,_ in results)
    overall = "FAIL" if fails else ("INCOMPLETE" if skips else "PASS")
    lines = [
        "VALEPÓLIS V0.3.0 — RELATÓRIO PRE-FLIGHT INDEPENDENTE",
        f"Data: {datetime.datetime.now().astimezone().isoformat(timespec='seconds')}",
        f"Projeto: {root}",
        f"Ferramenta: {Path(__file__).name}",
        "",
        "RESULTADOS:"
    ]
    for status, label, detail in results:
        lines.append(f"{status}|{label}" + (f"|{detail}" if detail else ""))
    lines += ["", f"TOTAL_PASS={sum(s=='PASS' for s,_,_ in results)}",
              f"TOTAL_FAIL={fails}", f"TOTAL_SKIP={skips}", f"RESULTADO={overall}",
              "", "Interpretação: PASS = verificações concluídas sem falhas; INCOMPLETE = não houve falhas estáticas, mas existem etapas não executadas; FAIL = pelo menos uma verificação falhou.",
              f"Logs: {log_dir}"]
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    print(f"\nRelatório guardado em: {report}")
    print(f"Logs guardados em: {log_dir}")
    return 1 if overall == "FAIL" else (2 if overall == "INCOMPLETE" else 0)

if __name__ == "__main__":
    raise SystemExit(main())

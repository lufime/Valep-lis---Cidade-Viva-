# Valepólis V0.3.0 — Correção orientada pelos logs

## Evidência do workflow recebido
- O PRE-FLIGHT estático passou (26 verificações).
- A auditoria de regras passou (32 verificações).
- A auditoria estrutural passou (44 verificações).
- O teste funcional falhou: `MAP_RENDER_FAIL: cidade 3D incompleta (cidade=true, câmara=false, relevo=true)`.
- O teste também encontrou o `Map3D` invisível, porque a rotina escondia o container quando não encontrava a câmara.
- A exportação APK não foi concluída porque o workflow parou no gate funcional.

## Correção aplicada neste pacote
`main.gd` tenta recuperar a câmara através do inicializador da própria cidade e, se ainda faltar, cria uma câmara de visão geral de recurso antes de decidir que o mapa 3D está incompleto. Isto evita esconder a cidade apenas por falta da câmara. A câmara de recurso garante visualização inicial; a integração dos controlos de zoom deve ser confirmada no próximo teste Godot.

## Limites
O ZIP foi verificado estruturalmente e o patch de texto foi confirmado. Não foi possível executar Godot nesta sessão; portanto, não declarar a falha resolvida até o workflow voltar a passar o teste funcional e gerar a APK. O log também contém uma mensagem `sdkmanager não encontrado`, que deve ser observada na fase de exportação Android caso o workflow chegue a esse passo.

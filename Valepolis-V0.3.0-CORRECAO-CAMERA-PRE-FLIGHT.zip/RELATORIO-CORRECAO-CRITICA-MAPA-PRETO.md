# Valepólis V0.3.0 — correção crítica do mapa preto

## Causa encontrada

`Main.tscn` já contém `UI/Map/MapBody/Map3D/SubViewport`, mas o `SubViewport` não contém inicialmente a cena `ValepolisCity3D`. A rotina anterior só carregava `City3D.tscn` no ramo em que criava um `SubViewportContainer` novo. Quando o container preexistente era encontrado, tornava-se visível sem anexar a cidade, produzindo o fundo preto visto na captura do Android.

## Alterações aplicadas

- `main.gd`: `_v030_setup_2d_map()` passa a garantir que o container, o SubViewport e a instância `ValepolisCity3D` existem, mesmo quando o container já vem de `Main.tscn`.
- O viewport é configurado para atualização contínua (`SubViewport.UPDATE_ALWAYS`), mantendo `stretch = true` sem redimensionamento manual incompatível.
- O runtime operacional recebe a referência da cidade por `register_city()`.
- A camada geográfica 2D só é ocultada depois de verificar que a cidade tem câmara e gerador de relevo. Se a montagem 3D falhar, o jogo regista `MAP_RENDER_FAIL`, desliga o viewport vazio e mantém a cartografia 2D como recurso em vez de deixar um painel vazio.
- `tools/preflight_functional.gd`: acrescentadas verificações para o SubViewport, instância da cidade, relevo, câmara e ligação ao runtime. O teste aguarda seis frames para permitir a montagem diferida.
- `tools/preflight_v030_static.py` e `tools/preflight.py`: acrescentada uma guarda contra regressão do SubViewport vazio.

## Validação executada neste ambiente

- PRE-FLIGHT estático: **27 PASS, 0 FAIL**.
- Auditoria de regras: **32 PASS, 0 FAIL**.
- Auditoria de projeto: **44 PASS, 0 FAIL**.
- Auditoria de instalações: **26 PASS, 0 FAIL**.
- Auditoria da rede regional: **PASS_STATIC_ONLY**; geometria/circulação em runtime não testadas.
- PRE-FLIGHT independente: **20 PASS, 0 FAIL, 3 SKIP — INCOMPLETE**.
- Códigos de saída das auditorias específicas: PRE-FLIGHT estático 0; regras 0; projeto 0; instalações 0; rede regional 0; PRE-FLIGHT independente 2 (`INCOMPLETE`, porque o runtime não foi executado).
- 83 ficheiros JSON válidos, referências internas verificadas e 25 bairros únicos no mapa 3D.
- Auditoria de regras conserva o catálogo aprovado de 200 episódios em 20 temporadas, 10 episódios por temporada, sem criar dados de instalações ou efetivos não aprovados.

## Limites que não foram ocultados

Não existe executável Godot 4.x neste ambiente e o acesso à rede para instalar um está indisponível. Portanto, não foi possível executar a importação/runtime Godot, validar visualmente o mapa num dispositivo Android nem exportar/testar uma APK nesta sessão. O pacote é um projeto corrigido e auditado estaticamente, **não uma APK certificada**.

O catálogo atual `data/episodes_200.json` contém a estrutura, os títulos e a duração variável dos episódios; não contém objetivos ou condições específicas de conclusão para cada episódio. A progressão persistente existe, mas não se declara que os 200 episódios tenham todos os respetivos objetivos narrativos implementados sem essa ligação e validação.

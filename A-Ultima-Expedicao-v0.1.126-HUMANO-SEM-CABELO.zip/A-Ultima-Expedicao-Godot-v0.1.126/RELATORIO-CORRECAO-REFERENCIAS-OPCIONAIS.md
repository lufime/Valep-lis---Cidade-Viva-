# Correção de referências opcionais — V0.1.126

- `audio/polar_wind_loop.wav`: verifica a existência antes de carregar; ausência deixa o áudio exterior desativado sem tentar carregar um ficheiro inexistente.
- `assets/station_corridor_kit.glb`: verifica a existência antes de carregar; o kit decorativo é opcional e o restante método continua a construir os detalhes procedurais.
- `assets/entity_creature.glb`: verifica a existência antes de carregar; se faltar, mantém o fallback visual já existente no código.
- Não foram alteradas as regras de jogo, a rede, o movimento, a IA ou a hierarquia dos jogadores.

## Verificações executadas
- ZIP de entrada abriu e todos os membros foram lidos.
- O código contém agora guardas `ResourceLoader.exists` para os três caminhos opcionais.
- Integridade do ZIP de saída verificada após escrita.

## Limitação
Não foi possível executar o projeto no motor Godot nesta sessão; portanto, isto não certifica execução/runtime nem alinhamento visual do cabelo.

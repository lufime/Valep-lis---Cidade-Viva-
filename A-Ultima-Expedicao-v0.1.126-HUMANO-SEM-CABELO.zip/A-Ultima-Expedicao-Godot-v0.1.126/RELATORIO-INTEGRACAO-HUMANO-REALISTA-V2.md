# A Última Expedição V0.1.126 — Integração do humano realista V2

## Alterações efetuadas
- Adicionado `assets/humano_realista_v2.glb`, extraído do pacote fornecido `A_Ultima_Expedicao_Humano_Realista_V2.zip`.
- Substituído o conteúdo vazio de `scenes/PlayerExpeditionSurvivor.tscn` por uma instância direta desse GLB.
- Mantida a constante `PLAYER_EXPEDITION_MODEL_SCENE` e o fluxo de criação dos avatares remotos em `scripts/expedition.gd`, para preservar a integração de rede existente.
- Mantidos os scripts de controlo, colisão, câmara e sincronização; não foram alterados.

## Limites e validação
- Verificado estruturalmente: GLB válido (glTF 2.0), 166 nós, 2 malhas, 1 skin e 0 animações incorporadas.
- O ZIP final foi verificado quanto à integridade.
- **Não foi possível executar o jogo no Godot nesta sessão**; por isso, escala, orientação, materiais, aparência em jogo e deformação do esqueleto ainda precisam de confirmação no runtime.
- O GLB fornecido tem rig/skin, mas não contém animações incorporadas. Esta integração não cria animações novas nem transforma automaticamente a malha-base numa personagem com roupa realista. O equipamento procedural antigo não foi sobreposto ao modelo, para evitar manter as formas geométricas antigas por cima do humano novo.
- O jogador local continua em primeira pessoa e não renderiza o próprio corpo; esta cena é utilizada pelo fluxo de avatares remotos.

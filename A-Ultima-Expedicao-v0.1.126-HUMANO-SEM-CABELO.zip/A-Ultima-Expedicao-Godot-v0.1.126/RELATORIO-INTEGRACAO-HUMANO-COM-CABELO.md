# A Última Expedição V0.1.126 — humano sem cabelo adicional

- Removida a instância do cabelo da cena `PlayerExpeditionSurvivor.tscn`.
- Removido o carregamento dinâmico do cabelo em `scripts/expedition.gd`.
- Removido `assets/humano_cabelo_castanho.glb` do pacote.
- Mantido o modelo humano `assets/humano_realista_v2.glb` e a hierarquia existente.
- A execução dentro do Godot não foi realizada nesta sessão; a validação visual continua pendente.

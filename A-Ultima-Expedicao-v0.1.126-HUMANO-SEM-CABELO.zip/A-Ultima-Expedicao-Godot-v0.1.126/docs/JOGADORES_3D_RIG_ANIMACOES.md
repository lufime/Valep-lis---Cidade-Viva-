# Jogadores 3D rigados — Blender 4.x

## O que esta etapa acrescenta
- Fonte Blender editável (`player_expedition_rigged.blend`).
- Exportação GLB com armature e ações `Idle`, `Walk` e `Run`.
- Malhas segmentadas com grupos de vértices e modificador Armature para acompanhar os ossos.
- Compatível com a ideia das 8 variantes de cor já escolhidas pelo código Godot.

## Gerar os ficheiros
1. Extrair o ZIP no telemóvel/PC onde esteja disponível Blender 4.x.
2. Abrir Blender > Scripting > Open e selecionar `blender/build_rigged_animated_players.py`.
3. Executar Run Script. O script grava `player_expedition_rigged.blend` e `player_expedition_rigged.glb` na pasta do projeto (ou na pasta do ficheiro Blender, se já estiver guardado).
4. Copiar o GLB gerado para `assets/player_expedition_rigged.glb` e importar no Godot 4.5. Atualizar a cena do jogador para apontar para esse GLB e escolher a animação no `AnimationPlayer`/`AnimationTree`.

## Limitações honestas
Este script gera um rig humano estilizado com peças rígidas ponderadas a 100% por osso, adequado para um protótipo de personagem articulado. Não é captura de movimento nem deformação orgânica de alta qualidade. A exportação Blender não foi executada neste ambiente porque Blender não está instalado; por isso os ficheiros `.blend` e GLB rigado são produzidos quando o script for executado no Blender. O GLB estático existente continua no projeto como fallback.


## Estado atual — V0.1.126
Os modelos humanos antigos `player_expedition_survivor` e `player_expedition_rigged` foram retirados dos assets ativos. A cena reutilizável aponta para `res://assets/humano_realista_v2.glb`. Este documento é histórico; não recriar nem reintroduzir os modelos antigos no build atual.

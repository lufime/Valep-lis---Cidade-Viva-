extends Node3D

const PLAYER_SCRIPT := preload("res://scripts/player_controller.gd")
const INTERACTABLE_SCRIPT := preload("res://scripts/interactable_door.gd")
const COOP_SWITCH_SCRIPT := preload("res://scripts/coop_switch.gd")
const PORT := 24567

var network_peer: ENetMultiplayerPeer
var remote_players: Dictionary = {}
var switch_owners: Dictionary = {"A": 0, "B": 0}
var coop_solved := false
var network_status: Label
var ip_input: LineEdit
var coop_status: Label
var private_clue: Label
var local_player_id := 1
var _sync_accumulator := 0.0
var decision_votes: Dictionary = {}
var decision_resolved := false
var decision_status: Label
var accusation_button: Button
var defense_button: Button
var entity_presence: Node3D
var entity_reaction_label: Label
var entity_active := false
var entity_motion_time := 0.0
var entity_ai_state := "DORMANT"
var entity_waypoint_index := 0
var entity_hidden_time := 0.0
var entity_state_time := 0.0
var entity_notice_label: Label
var stealth_status: Label
var entity_last_notice := 0.0
var entity_waypoints: Array[Vector3] = [Vector3(-3.8, 0.0, -13.4), Vector3(3.6, 0.0, -11.7), Vector3(2.8, 0.0, -6.8), Vector3(-3.5, 0.0, -8.1)]

func _ready() -> void:
	_build_environment()
	_build_room()
	_build_door()
	_build_coop_switches()
	_build_player()
	_build_hud()
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()

func _material(color: Color, roughness := 0.86, metallic := 0.0) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	return mat

func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, mat: Material, collision := true) -> MeshInstance3D:
	var body: Node3D = parent
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.position = pos
	mesh_node.material_override = mat
	body.add_child(mesh_node)
	if collision:
		var static_body := StaticBody3D.new()
		static_body.name = node_name + "Collision"
		static_body.position = pos
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		static_body.add_child(shape_node)
		body.add_child(static_body)
	return mesh_node

func host_game() -> void:
	if network_peer != null:
		network_status.text = "Rede: já existe uma sessão"
		return
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_server(PORT, 4)
	if result != OK:
		network_status.text = "Erro ao criar sessão: %s" % error_string(result)
		return
	multiplayer.multiplayer_peer = network_peer
	local_player_id = multiplayer.get_unique_id()
	network_status.text = "Anfitrião ativo · porta %d · jogadores: 1" % PORT
	_broadcast_local_state()

func join_game() -> void:
	if network_peer != null:
		network_status.text = "Rede: já existe uma sessão"
		return
	var address := ip_input.text.strip_edges()
	if address.is_empty():
		address = "127.0.0.1"
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_client(address, PORT)
	if result != OK:
		network_status.text = "Erro ao ligar: %s" % error_string(result)
		return
	multiplayer.multiplayer_peer = network_peer
	network_status.text = "A ligar a %s:%d…" % [address, PORT]

func _on_connected_to_server() -> void:
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	if network_status:
		network_status.text = "Ligado ao anfitrião · ID %d" % local_player_id

func _on_peer_connected(peer_id: int) -> void:
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	if network_status:
		network_status.text = "Ligado · novo jogador %d" % peer_id

func _on_peer_disconnected(peer_id: int) -> void:
	if remote_players.has(peer_id):
		remote_players[peer_id].queue_free()
		remote_players.erase(peer_id)
	if multiplayer.is_server():
		for key in switch_owners.keys():
			if int(switch_owners[key]) == peer_id:
				switch_owners[key] = 0
		decision_votes.erase(peer_id)
		_broadcast_switch_state()
	if network_status:
		network_status.text = "Jogador %d saiu" % peer_id

func _process(delta: float) -> void:
	_sync_accumulator += delta
	if entity_active:
		entity_motion_time += delta
		entity_state_time += delta
		var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
		if lamp:
			# The light reacts to the entity's current state.
			var flicker := 0.35 + absf(sin(entity_motion_time * (10.0 if entity_ai_state == "HUNT" else 6.0))) * (1.15 if entity_ai_state == "HUNT" else 0.65)
			lamp.light_energy = flicker
		_update_entity_ai(delta)
		_update_stealth_status()
	if _sync_accumulator >= 0.08:
		_sync_accumulator = 0.0
		_broadcast_local_state()

func _broadcast_local_state() -> void:
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	var player := get_node_or_null("Player") as CharacterBody3D
	if player == null:
		return
	var pitch := 0.0
	var pivot := player.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pitch = pivot.rotation.x
	rpc("receive_player_state", multiplayer.get_unique_id(), player.global_position, player.rotation.y, pitch)

@rpc("any_peer", "call_remote", "unreliable")
func receive_player_state(peer_id: int, pos: Vector3, yaw: float, pitch: float) -> void:
	# Never trust a client-supplied identity: derive it from the RPC sender.
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id > 0:
		peer_id = sender_id
	if peer_id == multiplayer.get_unique_id():
		return
	var avatar: Node3D = remote_players.get(peer_id)
	if avatar == null:
		avatar = _make_remote_avatar(peer_id)
		remote_players[peer_id] = avatar
	avatar.global_position = pos
	avatar.rotation.y = yaw
	var pivot := avatar.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pivot.rotation.x = pitch

func _make_remote_avatar(peer_id: int) -> Node3D:
	var avatar := Node3D.new()
	avatar.name = "RemotePlayer_%d" % peer_id
	var body := MeshInstance3D.new()
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.32
	capsule.height = 1.75
	body.mesh = capsule
	var mat := _material(Color(0.42, 0.52, 0.59), 0.72, 0.05)
	body.material_override = mat
	body.position.y = 0.88
	avatar.add_child(body)
	var pivot := Node3D.new()
	pivot.name = "CameraPivot"
	pivot.position.y = 1.45
	avatar.add_child(pivot)
	add_child(avatar)
	return avatar

func request_switch(switch_id: String) -> void:
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		_set_coop_status("Liga a sessão e junta um segundo jogador para ativar os dois relés.")
		return
	if multiplayer.is_server():
		_server_toggle_switch(switch_id, multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_toggle_switch", switch_id)

@rpc("any_peer", "call_remote", "reliable")
func server_toggle_switch(switch_id: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	_server_toggle_switch(switch_id, sender)

func _server_toggle_switch(switch_id: String, peer_id: int) -> void:
	if not switch_owners.has(switch_id) or coop_solved:
		return
	# One player cannot satisfy both stations. They must be operated by distinct peers.
	if switch_owners[switch_id] == peer_id:
		switch_owners[switch_id] = 0
	else:
		switch_owners[switch_id] = peer_id
	coop_solved = switch_owners["A"] != 0 and switch_owners["B"] != 0 and switch_owners["A"] != switch_owners["B"]
	_broadcast_switch_state()

func _broadcast_switch_state() -> void:
	_apply_switch_state(switch_owners["A"], switch_owners["B"], coop_solved)
	if multiplayer.multiplayer_peer != null and multiplayer.is_server():
		rpc("apply_switch_state", switch_owners["A"], switch_owners["B"], coop_solved)

@rpc("authority", "call_remote", "reliable")
func apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	_apply_switch_state(owner_a, owner_b, solved)

func _apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	switch_owners["A"] = owner_a
	switch_owners["B"] = owner_b
	coop_solved = solved
	var a := get_node_or_null("CoopSwitchA/SwitchMesh") as MeshInstance3D
	var b := get_node_or_null("CoopSwitchB/SwitchMesh") as MeshInstance3D
	if a:
		a.material_override = _material(Color(0.12, 0.72, 0.42) if owner_a != 0 else Color(0.24, 0.28, 0.30), 0.38, 0.55)
	if b:
		b.material_override = _material(Color(0.12, 0.72, 0.42) if owner_b != 0 else Color(0.24, 0.28, 0.30), 0.38, 0.55)
	if solved:
		_set_coop_status("RELÉS ATIVOS POR JOGADORES DIFERENTES — CÂMARA DESBLOQUEADA")
		var door := get_node_or_null("InteractiveBulkhead")
		if door and door.has_method("open_for_coop"):
			door.open_for_coop()
	else:
		_set_coop_status("RELÉ A: %s   ·   RELÉ B: %s" % ["ATIVO" if owner_a != 0 else "PENDENTE", "ATIVO" if owner_b != 0 else "PENDENTE"])

func _toggle_network_panel(panel: PanelContainer) -> void:
	if panel:
		panel.visible = not panel.visible

func _set_coop_status(message: String) -> void:
	if coop_status:
		coop_status.text = message

func _update_private_clue() -> void:
	if private_clue == null:
		return
	local_player_id = multiplayer.get_unique_id()
	var clue := ""
	match local_player_id:
		1:
			clue = "DOSSIÊ PRIVADO 01 — REGISTO DE CÂMARA: uma silhueta atravessou a porta às 02:13. O rosto não é identificável."
		2:
			clue = "DOSSIÊ PRIVADO 02 — REGISTO MAGNÉTICO: a porta permaneceu selada entre as 02:00 e as 02:20. Não há abertura registada."
		3:
			clue = "DOSSIÊ PRIVADO 03 — ÁUDIO RECUPERADO: às 02:13 ouvem-se duas vozes; uma diz «não o deixes entrar»."
		_:
			clue = "DOSSIÊ PRIVADO 04 — SENSOR TÉRMICO: às 02:13 foi detetado movimento, mas sem assinatura térmica humana compatível."
	private_clue.text = clue

func submit_decision(choice: String) -> void:
	if decision_resolved:
		_set_decision_status("A decisão desta missão já foi tomada.")
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		_set_decision_status("Liga-te a uma sessão para confrontar a equipa com outro jogador.")
		return
	if multiplayer.is_server():
		_server_record_decision(multiplayer.get_unique_id(), choice)
	else:
		rpc_id(1, "server_record_decision", choice)
	_set_decision_status("Voto registado em privado. Compara as provas antes de decidirem.")

@rpc("any_peer", "call_remote", "reliable")
func server_record_decision(choice: String) -> void:
	if not multiplayer.is_server() or decision_resolved:
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 0:
		return
	_server_record_decision(sender, choice)

func _server_record_decision(peer_id: int, choice: String) -> void:
	if decision_resolved or peer_id <= 0:
		return
	decision_votes[peer_id] = choice
	var eligible := 1
	if network_peer != null:
		eligible = max(1, network_peer.get_peers().size() + 1)
	if decision_votes.size() < min(2, eligible):
		_broadcast_decision_status("Votos recebidos: %d/%d. Falta ouvir outro jogador." % [decision_votes.size(), min(2, eligible)])
		return
	var accuse_count := 0
	var defend_count := 0
	for vote in decision_votes.values():
		if vote == "ACUSAR":
			accuse_count += 1
		else:
			defend_count += 1
	decision_resolved = true
	var outcome := ""
	if accuse_count > defend_count:
		outcome = "CONSEQUÊNCIA: ACUSAÇÃO — o alarme dispara e a estação entra em contenção. A equipa perde a confiança do operador."
		_set_alarm_state(true)
	elif defend_count > accuse_count:
		outcome = "CONSEQUÊNCIA: DEFESA — o operador mantém acesso, mas uma porta secundária desbloqueia-se sem explicação."
		_set_alarm_state(false)
	else:
		outcome = "CONSEQUÊNCIA: DIVISÃO — sem consenso, o sistema entra em bloqueio e a luz de emergência falha."
		_set_alarm_state(true)
	_broadcast_decision_result(outcome)

func _broadcast_decision_status(message: String) -> void:
	_set_decision_status(message)
	if multiplayer.is_server():
		rpc("apply_decision_status", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_status(message: String) -> void:
	_set_decision_status(message)

func _broadcast_decision_result(message: String) -> void:
	_apply_decision_result(message)
	if multiplayer.is_server():
		rpc("apply_decision_result", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_result(message: String) -> void:
	_apply_decision_result(message)

func _apply_decision_result(message: String) -> void:
	decision_resolved = true
	_activate_entity_reaction(message)
	_set_decision_status(message)
	_set_alarm_state(message.begins_with("CONSEQUÊNCIA: ACUSAÇÃO") or message.begins_with("CONSEQUÊNCIA: DIVISÃO"))
	if accusation_button:
		accusation_button.disabled = true
	if defense_button:
		defense_button.disabled = true

func _activate_entity_reaction(outcome: String) -> void:
	if entity_active:
		return
	entity_active = true
	var room := get_node_or_null("ResearchStationRoom") as Node3D
	if room == null:
		return
	# A distant, deliberately ambiguous silhouette appears only after the team's decision.
	entity_presence = Node3D.new()
	entity_presence.name = "UnidentifiedPresence"
	entity_presence.position = entity_waypoints[entity_waypoint_index]
	room.add_child(entity_presence)
	var body := MeshInstance3D.new()
	body.name = "Silhouette"
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.38
	capsule.height = 2.05
	body.mesh = capsule
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color(0.008, 0.009, 0.012)
	dark.roughness = 1.0
	dark.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	body.material_override = dark
	body.position = Vector3(0.0, 1.05, 0.0)
	entity_presence.add_child(body)
	var collision := StaticBody3D.new()
	collision.name = "EntityCollision"
	var collision_shape := CollisionShape3D.new()
	var collision_capsule := CapsuleShape3D.new()
	collision_capsule.radius = 0.34
	collision_capsule.height = 1.9
	collision_shape.shape = collision_capsule
	collision_shape.position.y = 1.0
	collision.add_child(collision_shape)
	entity_presence.add_child(collision)
	for eye_x in [-0.12, 0.12]:
		var eye := MeshInstance3D.new()
		var eye_mesh := SphereMesh.new()
		eye_mesh.radius = 0.035
		eye_mesh.height = 0.07
		eye.mesh = eye_mesh
		var eye_mat := StandardMaterial3D.new()
		eye_mat.albedo_color = Color(0.55, 0.015, 0.01)
		eye_mat.emission_enabled = true
		eye_mat.emission = Color(0.8, 0.01, 0.005)
		eye.material_override = eye_mat
		eye.position = Vector3(eye_x, 1.42, -0.34)
		entity_presence.add_child(eye)
	entity_ai_state = "PATROL"
	entity_state_time = 0.0
	if entity_reaction_label:
		if outcome.begins_with("CONSEQUÊNCIA: ACUSAÇÃO"):
			entity_reaction_label.text = "SINAL HOSTIL: a contenção chamou algo até à estação."
		elif outcome.begins_with("CONSEQUÊNCIA: DEFESA"):
			entity_reaction_label.text = "SINAL ANÓMALO: a presença apareceu depois de manterem o acesso."
		else:
			entity_reaction_label.text = "SINAL CRÍTICO: a divisão da equipa coincidiu com uma presença."

func _update_entity_ai(delta: float) -> void:
	if entity_presence == null:
		return
	var player := get_node_or_null("Player") as CharacterBody3D
	if player == null:
		return
	var distance_to_player := entity_presence.global_position.distance_to(player.global_position)
	var observed := _is_entity_observed(player)
	var player_speed := Vector2(player.velocity.x, player.velocity.z).length()
	var player_script = player.get_script()
	var crouching := bool(player.get("is_crouching"))
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	var illuminated := _is_entity_lit_by_player(player, flashlight)
	# Fast movement creates noise; crouching reduces the detection radius. A beam on the entity can provoke it.
	if observed and distance_to_player < 19.0:
		entity_ai_state = "OBSERVED"
		entity_hidden_time = 2.6
		entity_presence.visible = false
		entity_state_time = 0.0
		if entity_reaction_label:
			entity_reaction_label.text = "A PRESENÇA DESAPARECEU QUANDO A OBSERVASTE. O ruído continua no corredor…"
		return
	if entity_ai_state == "OBSERVED":
		entity_hidden_time -= delta
		if entity_hidden_time <= 0.0:
			entity_ai_state = "PATROL"
			entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
			entity_presence.position = entity_waypoints[entity_waypoint_index]
			entity_presence.visible = true
			entity_state_time = 0.0
			if entity_reaction_label:
				entity_reaction_label.text = "MOVIMENTO DETETADO NOUTRA ZONA. A entidade mudou de posição."
		return
	var noise_radius := 5.0 if crouching else 13.0
	if (player_speed > 2.25 and not crouching and distance_to_player < noise_radius) or (illuminated and distance_to_player < 15.0):
		entity_ai_state = "HUNT"
	else:
		entity_ai_state = "PATROL"
	var target := entity_waypoints[entity_waypoint_index]
	if entity_ai_state == "HUNT" and distance_to_player > 3.4:
		# A lit target is more compelling than sound alone, but crouching still lowers noise.
		target = player.global_position
	elif entity_presence.global_position.distance_to(target) < 0.7:
		entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
		target = entity_waypoints[entity_waypoint_index]
	var flat_target := Vector3(target.x, entity_presence.position.y, target.z)
	var step := 1.35 if entity_ai_state == "PATROL" else 2.15
	entity_presence.global_position = entity_presence.global_position.move_toward(flat_target, step * delta)
	if entity_presence.global_position.distance_to(player.global_position) < 1.35:
		entity_ai_state = "ATTACK_WARNING"
		if entity_reaction_label:
			entity_reaction_label.text = "PERIGO IMEDIATO: a presença chegou demasiado perto. Recuem e não façam ruído."
	elif entity_ai_state == "HUNT" and entity_reaction_label and entity_state_time > 1.8 and Time.get_ticks_msec() / 1000.0 - entity_last_notice > 2.5:
		entity_reaction_label.text = "A ENTIDADE DETETOU %s. %s" % ["a luz da lanterna" if illuminated else "o ruído", "Desliga a lanterna e agacha-te." if illuminated else "Agacha-te para reduzir o ruído."]
		entity_last_notice = Time.get_ticks_msec() / 1000.0

func _is_entity_lit_by_player(player: CharacterBody3D, flashlight: SpotLight3D) -> bool:
	if flashlight == null or not flashlight.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - flashlight.global_position
	if to_entity.length() > flashlight.spot_range:
		return false
	var forward := -flashlight.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < cos(deg_to_rad(flashlight.spot_angle * 0.5)):
		return false
	var query := PhysicsRayQueryParameters3D.create(flashlight.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _update_stealth_status() -> void:
	if stealth_status == null:
		return
	var player := get_node_or_null("Player")
	if player == null:
		return
	var crouching := bool(player.get("is_crouching"))
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	stealth_status.text = "FURTIVIDADE: AGACHADO · RUÍDO BAIXO" if crouching else "FURTIVIDADE: DE PÉ · RUÍDO ELEVADO"
	if flashlight and flashlight.visible:
		stealth_status.text += " · LANTERNA LIGADA"

func _is_entity_observed(player: CharacterBody3D) -> bool:
	var camera := player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
	if camera == null or not entity_presence.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - camera.global_position
	if to_entity.length() > 17.0:
		return false
	var forward := -camera.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < 0.965:
		return false
	var query := PhysicsRayQueryParameters3D.create(camera.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _set_decision_status(message: String) -> void:
	if decision_status:
		decision_status.text = message

func _set_alarm_state(active: bool) -> void:
	var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
	if lamp:
		lamp.light_color = Color(1.0, 0.025, 0.01) if active else Color(0.1, 0.55, 0.3)
		lamp.light_energy = 1.1 if active else 0.35

func _build_environment() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.015, 0.025, 0.04)
	sky_mat.sky_horizon_color = Color(0.06, 0.065, 0.07)
	sky_mat.ground_bottom_color = Color(0.008, 0.01, 0.012)
	sky_mat.ground_horizon_color = Color(0.035, 0.04, 0.045)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.19, 0.22, 0.27)
	env.ambient_light_energy = 0.62
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world.environment = env
	add_child(world)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-42, -25, 0)
	moon.light_color = Color(0.52, 0.61, 0.78)
	moon.light_energy = 0.38
	moon.shadow_enabled = true
	add_child(moon)
	var fill_light := OmniLight3D.new()
	fill_light.name = "RoomFillLight"
	fill_light.position = Vector3(0, 2.7, -2.5)
	fill_light.light_color = Color(0.48, 0.57, 0.66)
	fill_light.light_energy = 0.7
	fill_light.omni_range = 13.0
	fill_light.shadow_enabled = false
	add_child(fill_light)

func _build_room() -> void:
	var room := Node3D.new()
	room.name = "ResearchStationRoom"
	add_child(room)
	var concrete := _material(Color(0.19, 0.205, 0.21))
	var floor_mat := _material(Color(0.075, 0.085, 0.09), 0.28, 0.18)
	var metal := _material(Color(0.11, 0.135, 0.15), 0.42, 0.62)
	var hazard := _material(Color(0.43, 0.19, 0.07), 0.65, 0.25)
	_box(room, "Floor", Vector3(12, 0.3, 16), Vector3(0, -0.15, -2), floor_mat)
	_box(room, "Ceiling", Vector3(12, 0.25, 16), Vector3(0, 3.6, -2), concrete)
	_box(room, "LeftWall", Vector3(0.3, 3.6, 16), Vector3(-6, 1.65, -2), concrete)
	_box(room, "RightWall", Vector3(0.3, 3.6, 16), Vector3(6, 1.65, -2), concrete)
	# Split the rear wall around a real doorway; the previous solid wall made
	# the door appear interactive while physically blocking the exit.
	_box(room, "BackWallLeft", Vector3(4.7, 3.6, 0.3), Vector3(-3.65, 1.65, -10), concrete)
	_box(room, "BackWallRight", Vector3(4.7, 3.6, 0.3), Vector3(3.65, 1.65, -10), concrete)
	_box(room, "DoorLintel", Vector3(2.6, 0.65, 0.3), Vector3(0, 3.275, -10), concrete)
	# A short corridor makes the doorway lead somewhere instead of ending at a wall.
	_box(room, "ExitCorridorFloor", Vector3(3.0, 0.18, 7.0), Vector3(0, -0.16, -13.3), floor_mat)
	_box(room, "ExitCorridorLeft", Vector3(0.18, 3.3, 7.0), Vector3(-1.5, 1.5, -13.3), concrete)
	_box(room, "ExitCorridorRight", Vector3(0.18, 3.3, 7.0), Vector3(1.5, 1.5, -13.3), concrete)
	# Modular wall ribs and pipe runs establish scale and navigation cues.
	for i in range(5):
		var z := 4.0 - float(i) * 3.0
		_box(room, "WallRib_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(-5.72, 1.55, z), metal)
		_box(room, "WallRibR_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(5.72, 1.55, z), metal)
	_box(room, "PipeHorizontal", Vector3(0.18, 0.18, 12), Vector3(-5.55, 2.95, -2), hazard)
	_box(room, "ControlDesk", Vector3(2.3, 0.95, 0.8), Vector3(-3.7, 0.48, -3.8), metal)
	_box(room, "StorageCrate", Vector3(1.1, 1.2, 1.0), Vector3(3.8, 0.6, 1.2), concrete)
	var lamp := OmniLight3D.new()
	lamp.name = "FailingEmergencyLamp"
	lamp.position = Vector3(0, 3.15, -4)
	lamp.light_color = Color(0.65, 0.11, 0.055)
	lamp.light_energy = 0.9
	lamp.omni_range = 10
	lamp.shadow_enabled = true
	room.add_child(lamp)
	var green := _material(Color(0.12, 0.48, 0.31), 0.25, 0.15)
	_box(room, "ExitIndicator", Vector3(0.75, 0.12, 0.06), Vector3(0, 2.85, -9.72), green, false)

func _build_door() -> void:
	var door := StaticBody3D.new()
	door.name = "InteractiveBulkhead"
	door.set_script(INTERACTABLE_SCRIPT)
	door.position = Vector3(0, 1.4, -9.35)
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "DoorMesh"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(2.2, 2.8, 0.22)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(Color(0.13, 0.16, 0.18), 0.42, 0.7)
	door.add_child(mesh_node)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.2, 2.8, 0.22)
	shape_node.shape = shape
	door.add_child(shape_node)
	var label := Label3D.new()
	label.text = "CÂMARA DE CONTENÇÃO  /  01"
	label.position = Vector3(0, 1.72, -0.13)
	label.font_size = 32
	label.modulate = Color(0.82, 0.72, 0.52)
	door.add_child(label)
	add_child(door)

func _build_coop_switches() -> void:
	# Two separated stations: each must be activated by a different network peer.
	_create_switch("A", Vector3(-4.1, 0.0, -2.1), "RELÉ A  /  LEITURA")
	_create_switch("B", Vector3(4.1, 0.0, -6.0), "RELÉ B  /  CONFIRMAÇÃO")

func _create_switch(switch_id: String, pos: Vector3, caption: String) -> void:
	var station := StaticBody3D.new()
	station.name = "CoopSwitch" + switch_id
	station.set_script(COOP_SWITCH_SCRIPT)
	station.switch_id = switch_id
	station.position = pos
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "SwitchMesh"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.85, 1.0, 0.38)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(Color(0.24, 0.28, 0.30), 0.38, 0.55)
	station.add_child(mesh_node)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.95, 1.1, 0.5)
	shape_node.shape = shape
	station.add_child(shape_node)
	var label := Label3D.new()
	label.text = caption
	label.position = Vector3(0, 0.72, 0)
	label.font_size = 30
	label.modulate = Color(0.78, 0.84, 0.88)
	station.add_child(label)
	add_child(station)

func _build_player() -> void:
	var player := CharacterBody3D.new()
	player.name = "Player"
	player.set_script(PLAYER_SCRIPT)
	player.position = Vector3(0, 0.95, 4.2)
	var collider := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.75
	collider.shape = capsule
	player.add_child(collider)
	var camera_pivot := Node3D.new()
	camera_pivot.name = "CameraPivot"
	camera_pivot.position = Vector3(0, 0.55, 0)
	player.add_child(camera_pivot)
	var camera := Camera3D.new()
	camera.name = "Camera3D"
	camera.current = true
	camera.fov = 82
	camera_pivot.add_child(camera)
	var ray := RayCast3D.new()
	ray.name = "InteractionRay"
	ray.target_position = Vector3(0, 0, -2.8)
	ray.collide_with_areas = true
	ray.collide_with_bodies = true
	camera.add_child(ray)
	var flashlight := SpotLight3D.new()
	flashlight.name = "Flashlight"
	flashlight.position = Vector3(0.12, -0.08, -0.15)
	flashlight.rotation_degrees = Vector3(-3, 0, 0)
	flashlight.light_energy = 3.1
	flashlight.spot_range = 17
	flashlight.spot_angle = 34
	flashlight.shadow_enabled = true
	camera.add_child(flashlight)
	add_child(player)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUD"
	add_child(layer)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(center)
	var reticle := Label.new()
	reticle.text = "+"
	reticle.add_theme_font_size_override("font_size", 24)
	reticle.add_theme_color_override("font_color", Color(0.82, 0.88, 0.9, 0.85))
	center.add_child(reticle)
	var prompt := Label.new()
	prompt.name = "Prompt"
	prompt.text = "Mover: WASD / joystick · Olhar: rato / arrastar · Interagir: E / botão · Lanterna: F / botão"
	prompt.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	prompt.anchor_left = 0.06
	prompt.anchor_right = 0.94
	prompt.offset_top = -54
	prompt.offset_bottom = -14
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	prompt.add_theme_font_size_override("font_size", 14)
	prompt.add_theme_color_override("font_color", Color(0.78, 0.82, 0.84))
	layer.add_child(prompt)
	var title := Label.new()
	title.text = "EXPEDIÇÃO 01  /  ESTAÇÃO VÉSPERA"
	title.position = Vector2(18, 14)
	title.add_theme_font_size_override("font_size", 15)
	title.add_theme_color_override("font_color", Color(0.73, 0.78, 0.81))
	layer.add_child(title)
	stealth_status = Label.new()
	stealth_status.name = "StealthStatus"
	stealth_status.position = Vector2(18, 32)
	stealth_status.add_theme_font_size_override("font_size", 14)
	stealth_status.add_theme_color_override("font_color", Color(0.65, 0.82, 0.76))
	layer.add_child(stealth_status)
	private_clue = Label.new()
	private_clue.name = "PrivateClue"
	private_clue.position = Vector2(18, 52)
	private_clue.size = Vector2( minf(500.0, get_viewport().get_visible_rect().size.x * 0.48), 82)
	private_clue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	private_clue.add_theme_font_size_override("font_size", 17)
	private_clue.add_theme_color_override("font_color", Color(0.94, 0.78, 0.48))
	layer.add_child(private_clue)
	_update_private_clue()
	# Native Godot touch buttons for mobile. Buttons are deliberately large.
	var player := get_node_or_null("Player")
	if player:
		var action_box := VBoxContainer.new()
		action_box.name = "TouchActions"
		action_box.anchor_left = 1.0
		action_box.anchor_top = 1.0
		action_box.anchor_right = 1.0
		action_box.anchor_bottom = 1.0
		action_box.offset_left = -174
		action_box.offset_top = -202
		action_box.offset_right = -12
		action_box.offset_bottom = -12
		action_box.add_theme_constant_override("separation", 12)
		layer.add_child(action_box)
		var interact_button := Button.new()
		interact_button.name = "InteractButton"
		interact_button.text = "INTERAGIR"
		interact_button.custom_minimum_size = Vector2(150, 52)
		interact_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		interact_button.add_theme_font_size_override("font_size", 16)
		interact_button.pressed.connect(Callable(player, "interact_now"))
		action_box.add_child(interact_button)
		var flashlight_button := Button.new()
		flashlight_button.name = "FlashlightButton"
		flashlight_button.text = "LANTERNA"
		flashlight_button.custom_minimum_size = Vector2(150, 48)
		flashlight_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		flashlight_button.add_theme_font_size_override("font_size", 15)
		flashlight_button.pressed.connect(Callable(player, "toggle_flashlight"))
		action_box.add_child(flashlight_button)
		var crouch_button := Button.new()
		crouch_button.name = "CrouchButton"
		crouch_button.text = "AGACHAR / LEVANTAR"
		crouch_button.custom_minimum_size = Vector2(150, 48)
		crouch_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		crouch_button.add_theme_font_size_override("font_size", 12)
		crouch_button.pressed.connect(Callable(player, "toggle_crouch"))
		action_box.add_child(crouch_button)
	var decision_panel := PanelContainer.new()
	decision_panel.name = "ConfrontationPanel"
	decision_panel.position = Vector2(18, 138)
	decision_panel.custom_minimum_size = Vector2( minf(330.0, get_viewport().get_visible_rect().size.x * 0.46), 0)
	var decision_box := VBoxContainer.new()
	decision_box.add_theme_constant_override("separation", 8)
	decision_panel.add_child(decision_box)
	var decision_title := Label.new()
	decision_title.text = "CONFRONTO  /  OPERADOR 07"
	decision_title.add_theme_font_size_override("font_size", 16)
	decision_title.add_theme_color_override("font_color", Color(0.85, 0.78, 0.62))
	decision_box.add_child(decision_title)
	var decision_hint := Label.new()
	decision_hint.text = "Após partilharem as pistas, escolhe uma posição. A decisão conjunta altera a missão."
	decision_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_hint.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 44)
	decision_hint.add_theme_font_size_override("font_size", 14)
	decision_box.add_child(decision_hint)
	accusation_button = Button.new()
	accusation_button.text = "ACUSAR — ativar contenção"
	accusation_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	accusation_button.pressed.connect(submit_decision.bind("ACUSAR"))
	decision_box.add_child(accusation_button)
	defense_button = Button.new()
	defense_button.text = "DEFENDER — manter acesso"
	defense_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	defense_button.pressed.connect(submit_decision.bind("DEFENDER"))
	decision_box.add_child(defense_button)
	decision_status = Label.new()
	decision_status.text = "Decisão pendente: compara as pistas em voz alta."
	decision_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_status.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 30)
	decision_status.add_theme_font_size_override("font_size", 13)
	decision_status.add_theme_color_override("font_color", Color(0.72, 0.82, 0.86))
	decision_box.add_child(decision_status)
	entity_reaction_label = Label.new()
	entity_reaction_label.name = "EntityReaction"
	entity_reaction_label.text = "Sem presença confirmada."
	entity_reaction_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	entity_reaction_label.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 28)
	entity_reaction_label.add_theme_font_size_override("font_size", 13)
	entity_reaction_label.add_theme_color_override("font_color", Color(0.95, 0.3, 0.22))
	decision_box.add_child(entity_reaction_label)
	layer.add_child(decision_panel)
	var joystick_hint := Label.new()
	joystick_hint.name = "TouchMoveHint"
	joystick_hint.text = "TOCAR E ARRASTAR\nPARA MOVER"
	joystick_hint.position = Vector2(18, get_viewport().get_visible_rect().size.y - 112)
	joystick_hint.add_theme_font_size_override("font_size", 14)
	joystick_hint.add_theme_color_override("font_color", Color(0.72, 0.78, 0.82, 0.72))
	layer.add_child(joystick_hint)
	# LAN controls: host/join must be accessible in the actual HUD, not only in code.
	var network_panel := PanelContainer.new()
	network_panel.name = "NetworkPanel"
	network_panel.anchor_left = 1.0
	network_panel.anchor_right = 1.0
	network_panel.offset_left = -360
	network_panel.offset_top = 58
	network_panel.offset_right = -16
	network_panel.offset_bottom = 210
	network_panel.custom_minimum_size = Vector2(344, 142)
	network_panel.visible = false
	var network_box := VBoxContainer.new()
	network_box.add_theme_constant_override("separation", 5)
	network_panel.add_child(network_box)
	var network_title := Label.new()
	network_title.text = "COOPERAÇÃO LAN · UDP %d" % PORT
	network_title.add_theme_font_size_override("font_size", 14)
	network_box.add_child(network_title)
	ip_input = LineEdit.new()
	ip_input.name = "HostAddress"
	ip_input.placeholder_text = "IP do anfitrião (ex.: 192.168.1.20)"
	ip_input.text = "127.0.0.1"
	network_box.add_child(ip_input)
	var network_buttons := HBoxContainer.new()
	var host_button := Button.new()
	host_button.text = "CRIAR SESSÃO"
	host_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	host_button.pressed.connect(host_game)
	network_buttons.add_child(host_button)
	var join_button := Button.new()
	join_button.text = "ENTRAR"
	join_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	join_button.pressed.connect(join_game)
	network_buttons.add_child(join_button)
	network_box.add_child(network_buttons)
	network_status = Label.new()
	network_status.name = "NetworkStatus"
	network_status.text = "Sem sessão. Anfitrião e cliente devem usar a mesma rede LAN."
	network_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	network_status.add_theme_font_size_override("font_size", 12)
	network_box.add_child(network_status)
	layer.add_child(network_panel)
	var network_toggle := Button.new()
	network_toggle.name = "NetworkToggle"
	network_toggle.text = "REDE LAN"
	network_toggle.anchor_left = 1.0
	network_toggle.anchor_right = 1.0
	network_toggle.offset_left = -124
	network_toggle.offset_top = 20
	network_toggle.offset_right = -16
	network_toggle.offset_bottom = 54
	network_toggle.pressed.connect(_toggle_network_panel.bind(network_panel))
	layer.add_child(network_toggle)

# Release checklist — A Última Expedição V0.1.89

## Verificações executadas neste pacote
- [x] ZIP íntegro.
- [x] Auditoria estática incluída no projeto: 41 verificações passaram.
- [x] Referências essenciais de cenas, scripts e recursos verificadas pela auditoria.
- [x] Controlador bloqueia o movimento quando a saúde chega a zero.
- [x] Proteção contra bloqueio persistente do movimento incluída.
- [x] Marcadores principais de versão atualizados para V0.1.89.

## Bloqueios para release final (ainda por executar)
- [ ] Importar/compilar o projeto no Godot 4.5 sem erros ou avisos críticos.
- [ ] Executar as 10 zonas, ida e regresso por todos os corredores.
- [ ] Testar colisões e funcionamento real das portas (abrir, fechar, atravessar).
- [ ] Testar todos os objetos, pistas, relés, consola, porta experimental e extração.
- [ ] Testar criatura, abrigo, captura e recuperação de movimento.
- [ ] Testar saúde/pulsação, exposição exterior, incapacitação e eventual recuperação/continuação de missão.
- [ ] Testar modo individual do início à extração.
- [ ] Testar multijogador com pelo menos dois clientes reais.
- [ ] Exportar APK Android e testar em dispositivo físico, incluindo desempenho e controlos táteis.

## Limitação
O ambiente de preparação não contém o executável Godot. Não foram declarados testes de runtime, rede ou APK como aprovados. Este pacote é uma versão de estabilização candidata, não uma release final certificada.

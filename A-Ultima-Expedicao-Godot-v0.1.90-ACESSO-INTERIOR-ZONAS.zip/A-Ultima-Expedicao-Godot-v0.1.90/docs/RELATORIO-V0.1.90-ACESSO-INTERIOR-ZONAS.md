# V0.1.90 — Acesso interior entre zonas

## Alteração
As folhas visuais das portas deslizantes nos conectores interiores das zonas 03–10 deixam de criar colisões físicas. A passagem central mantém-se livre para o jogador; as molduras continuam visíveis.

## Limites da validação
- Confirmada a alteração estática no código.
- O executável Godot 4.5 não está disponível neste ambiente; não foi possível executar o jogo nem confirmar em runtime a travessia de todas as zonas.
- Antes de release, executar no Godot: entrada/saída das zonas 02–10, colisões das paredes, deslocação com teclado/toque e passagem de dois jogadores.

# V0.1.89 — Estabilização para release

- Mantida a deteção de bloqueio do movimento introduzida na versão anterior.
- Corrigido o controlador para impedir movimento e limpar o input tátil quando a saúde chega a zero, atualizando o HUD para mostrar o estado crítico.
- Incluído checklist explícito de gates de release; gates não executados permanecem pendentes.

O projeto não foi compilado/executado no Godot 4.5 neste ambiente.

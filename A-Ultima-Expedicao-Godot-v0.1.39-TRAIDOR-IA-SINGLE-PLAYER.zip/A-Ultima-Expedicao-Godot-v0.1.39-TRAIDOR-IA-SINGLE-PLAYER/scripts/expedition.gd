extends Node3D

const PLAYER_SCRIPT := preload("res://scripts/player_controller.gd")
const INTERACTABLE_SCRIPT := preload("res://scripts/interactable_door.gd")
const COOP_SWITCH_SCRIPT := preload("res://scripts/coop_switch.gd")
const PORT := 24567
const ENTITY_SYNC_INTERVAL := 0.08

var network_peer: ENetMultiplayerPeer
var remote_players: Dictionary = {}
var _last_authoritative_player_positions: Dictionary = {}
var switch_owners: Dictionary = {"A": 0, "B": 0}
var coop_solved := false
var network_status: Label
var ip_input: LineEdit
var coop_status: Label
var private_clue: Label
var mission_hub: PanelContainer
var mission_hub_body: Label
var mission_hub_title: Label
var mission_hub_tab := "OBJETIVOS"
var quick_comms_status: Label
var game_paused_by_menu := false
var local_player_id := 1
# Estado dos papéis secretos, mantido no servidor durante a sessão.
var traitor_peer_id: int = 0
var traitor_role_assigned: bool = false
# Single-player: o traidor é uma IA separada da criatura e permanece oculto.
var solo_traitor_timer := 0.0
var solo_traitor_next_action := 38.0
var solo_traitor_presence: Node3D
var solo_traitor_rng := RandomNumberGenerator.new()
var solo_traitor_sabotages := 0
var solo_traitor_glimpse_timer := 0.0
var role_notice_layer: CanvasLayer
var _sync_accumulator := 0.0
var _entity_sync_accumulator := 0.0
var _client_connect_elapsed := 0.0
const CLIENT_CONNECT_TIMEOUT := 12.0
var decision_votes: Dictionary = {}
var decision_resolved := false
var decision_status: Label
var accusation_button: Button
var defense_button: Button
var entity_presence: Node3D
var entity_reaction_label: Label
var entity_active := false
var entity_motion_time := 0.0
var entity_ai_state := "DORMANT"
var entity_waypoint_index := 0
var entity_hidden_time := 0.0
var entity_state_time := 0.0
var entity_notice_label: Label
var stealth_status: Label
var entity_last_notice := 0.0
var ambient_music: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var voice_player: AudioStreamPlayer
var _world_sound_cooldowns: Dictionary = {}
var _voice_cooldown := 0.0
var _last_voice_state := ""
var _previous_audio_state := "DORMANT"
var _danger_audio_cooldown := 0.0
var _lighting_time := 0.0
var _alarm_active := false
var intro_layer: CanvasLayer
var intro_progress: ProgressBar
var intro_percent: Label
var intro_elapsed := 0.0
const INTRO_DURATION := 4.0
var entity_waypoints: Array[Vector3] = [Vector3(-3.8, 0.0, -13.4), Vector3(3.6, 0.0, -11.7), Vector3(2.8, 0.0, -6.8), Vector3(-3.5, 0.0, -8.1)]

# Diretor de suspense: sinais ambientais antes do primeiro contacto visual.
var suspense_elapsed := 0.0
var suspense_next_event := 24.0
var suspense_event_index := 0
var suspense_rng := RandomNumberGenerator.new()
# Investigação cooperativa da experiência original: dez fragmentos, um por zona.
var experiment_clues_found: Dictionary = {}
var secret_experiment_door: StaticBody3D
var secret_experiment_open := false
var evidence_synthesis_complete := false
var secret_combination_panel: PanelContainer
var secret_combination_input: LineEdit
var secret_synthesis_console: StaticBody3D
var secret_clue_status: Label
const SECRET_COMBINATION := "7314"
var evidence_journal: Array[String] = []
var suspense_messages: Array[String] = [
    "RÁDIO: interferência breve. A origem do sinal não foi identificada.",
    "ESTAÇÃO: um impacto metálico ecoa num corredor distante.",
    "SENSORES: movimento térmico inconclusivo junto à estrutura exterior.",
    "AVISO: rajada polar intensa. A visibilidade exterior está a diminuir.",
    "ÁUDIO: três passos no piso superior. Não há movimento registado nos sensores.",
    "ENERGIA: oscilação momentânea. Verifica a lanterna e o rádio."
]

func _ready() -> void:
	_setup_audio()
	_build_environment()
	_build_room()
	_build_next_chamber()
	_build_remaining_zones()
	_build_initial_zone_wings()
	_build_secret_experiment_area()
	_build_door()
	_build_coop_switches()
	_build_player()
	_build_hud()
	# A criatura existe em todas as partidas, mas a primeira aparição é precedida por sinais ambientais.
	suspense_rng.randomize()
	solo_traitor_rng.randomize()
	suspense_next_event = suspense_rng.randf_range(18.0, 32.0)
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	_build_main_menu()
	# Only dismiss the boot diagnostics after the full scene and UI were created.
	var boot := get_parent()
	if boot and boot.has_method("on_expedition_ready"):
		boot.call_deferred("on_expedition_ready")

func _setup_audio() -> void:
	# Original procedural ambience and cues are bundled locally; no network access required.
	ambient_music = AudioStreamPlayer.new()
	ambient_music.name = "AmbientMusic"
	ambient_music.stream = load("res://audio/ambient_tension.wav")
	ambient_music.volume_db = -19.0
	ambient_music.autoplay = false
	add_child(ambient_music)
	if ambient_music.stream:
		ambient_music.play()
		ambient_music.finished.connect(func():
			if ambient_music and ambient_music.stream:
				ambient_music.play()
		)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.name = "SituationSFX"
	sfx_player.volume_db = -7.0
	add_child(sfx_player)
	voice_player = AudioStreamPlayer.new()
	voice_player.name = "CharacterVoices"
	voice_player.volume_db = -10.0
	add_child(voice_player)

func _play_voice(file_name: String) -> void:
	if voice_player == null:
		return
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream:
		voice_player.stream = stream
		voice_player.play()

func _play_sfx(file_name: String) -> void:
	if sfx_player == null:
		return
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream:
		sfx_player.stream = stream
		sfx_player.play()

func _play_player_sound(file_name: String, world_position: Vector3, surface: String = "snow", pitch: float = 1.0) -> void:
	# Reproduz localmente e replica apenas eventos autorizados aos restantes jogadores.
	_play_spatial_sound(file_name, world_position, surface, pitch)
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	if multiplayer.is_server():
		rpc("receive_world_sound", multiplayer.get_unique_id(), file_name, world_position, surface, pitch)
	else:
		rpc_id(1, "request_world_sound", file_name, world_position, surface, pitch)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func request_world_sound(file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var allowed := ["footstep.wav", "cloth_rustle.wav", "flashlight_click.wav", "door_motor.wav", "voice_breathing.wav"]
	if not allowed.has(file_name):
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 1 or not remote_players.has(sender):
		return
	# Usa a posição que o servidor já conhece para evitar posições arbitrárias do cliente.
	var authoritative_position: Vector3 = (remote_players[sender] as Node3D).global_position
	if authoritative_position.distance_to(world_position) > 3.0:
		world_position = authoritative_position
	rpc("receive_world_sound", sender, file_name, world_position, surface, clampf(pitch, 0.75, 1.3))

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_world_sound(peer_id: int, file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	if peer_id == multiplayer.get_unique_id():
		return
	var allowed := ["footstep.wav", "cloth_rustle.wav", "flashlight_click.wav", "door_motor.wav", "voice_breathing.wav"]
	if not allowed.has(file_name):
		return
	_play_spatial_sound(file_name, world_position, surface, pitch)

func _play_spatial_sound(file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream == null:
		return
	var emitter := AudioStreamPlayer3D.new()
	emitter.name = "WorldSound"
	emitter.stream = stream
	emitter.global_position = world_position
	emitter.max_distance = 24.0
	emitter.unit_size = 4.0
	emitter.volume_db = -4.0 if file_name == "footstep.wav" else -8.0
	emitter.pitch_scale = clampf(pitch, 0.75, 1.3)
	match surface:
		"ice":
			emitter.pitch_scale *= 1.08
			emitter.volume_db -= 1.5
		"stone":
			emitter.pitch_scale *= 0.94
			emitter.volume_db += 1.0
		"metal":
			emitter.pitch_scale *= 1.12
			emitter.volume_db += 2.0
		"interior":
			emitter.volume_db -= 2.0
	add_child(emitter)
	emitter.finished.connect(emitter.queue_free)
	emitter.play()

func _play_context_voice(state: String) -> void:
	# Non-verbal vocal cues are intentionally sparse so they remain unsettling rather than repetitive.
	if _voice_cooldown > 0.0 or state == _last_voice_state:
		return
	_last_voice_state = state
	match state:
		"HUNT":
			_play_voice("voice_distant_whisper.wav")
			_voice_cooldown = 7.0
		"ATTACK_WARNING":
			_play_voice("voice_scream.wav")
			_voice_cooldown = 10.0
		"OBSERVED":
			_play_voice("voice_groan.wav")
			_voice_cooldown = 6.0
		"COOP_SOLVED":
			_play_voice("voice_choked_gasp.wav")
			_voice_cooldown = 5.0

func _material(color: Color, roughness := 0.86, metallic := 0.0) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	return mat

func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, mat: Material, collision := true) -> MeshInstance3D:
	var body: Node3D = parent
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.position = pos
	mesh_node.material_override = mat
	body.add_child(mesh_node)
	if collision:
		var static_body := StaticBody3D.new()
		static_body.name = node_name + "Collision"
		static_body.position = pos
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		static_body.add_child(shape_node)
		body.add_child(static_body)
	return mesh_node

func _get_local_ipv4_addresses() -> PackedStringArray:
	var addresses := PackedStringArray()
	for address in IP.get_local_addresses():
		# ENet on Android needs a reachable IPv4 address, not loopback or IPv6.
		if address.count(".") == 3 and not address.begins_with("127.") and not address == "0.0.0.0":
			addresses.append(address)
	return addresses

func _get_preferred_local_ipv4() -> String:
	var addresses := _get_local_ipv4_addresses()
	# Prefer common private LAN addresses when multiple adapters are available.
	for address in addresses:
		if address.begins_with("192.168.") or address.begins_with("10."):
			return address
		if address.begins_with("172."):
			var parts := address.split(".")
			if parts.size() == 4 and int(parts[1]) >= 16 and int(parts[1]) <= 31:
				return address
	if not addresses.is_empty():
		return addresses[0]
	return ""

func _sync_network_status_to_menu() -> void:
	# The menu and HUD have separate labels. Keep both updated after asynchronous
	# ENet callbacks, otherwise the menu can remain stuck on "A ligar...".
	if menu_status_label != null and network_status != null:
		menu_status_label.text = network_status.text

func host_game() -> void:
	if network_peer != null:
		var current_ip := _get_preferred_local_ipv4()
		if network_status:
			network_status.text = "Sessão já ativa · IP deste telemóvel: %s:%d" % [current_ip if not current_ip.is_empty() else "IP indisponível", PORT]
			_sync_network_status_to_menu()
		return
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_server(PORT, 7) # 1 anfitrião + até 7 clientes = 8 jogadores
	if result != OK:
		network_peer = null
		if network_status:
			network_status.text = "Erro ao criar sessão: %s" % error_string(result)
			_sync_network_status_to_menu()
		return
	multiplayer.multiplayer_peer = network_peer
	local_player_id = multiplayer.get_unique_id()
	var local_ip := _get_preferred_local_ipv4()
	if network_status:
		if local_ip.is_empty():
			network_status.text = "Sessão ativa na porta %d, mas não encontrei IP IPv4. Liga os telemóveis à mesma WLAN e tenta novamente." % PORT
			_sync_network_status_to_menu()
		else:
			var all_ips := ", ".join(_get_local_ipv4_addresses())
			network_status.text = "ANFITRIÃO ATIVO · IP sugerido: %s · IPs detetados: %s · PORTA UDP: %d. Partilha o IP WLAN correto." % [local_ip, all_ips, PORT]
			_sync_network_status_to_menu()
	if ip_input and not local_ip.is_empty():
		ip_input.text = local_ip
	_broadcast_local_state()

func join_game() -> void:
	if network_peer != null:
		if network_status:
			network_status.text = "Já existe uma sessão de rede neste telemóvel."
			_sync_network_status_to_menu()
		return
	var address := ip_input.text.strip_edges()
	if address.is_empty() or address == "127.0.0.1" or address == "localhost":
		if network_status:
			network_status.text = "Introduz o IP WLAN mostrado no telemóvel anfitrião; 127.0.0.1 não liga a outro telemóvel."
			_sync_network_status_to_menu()
		return
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_client(address, PORT)
	if result != OK:
		network_peer = null
		if network_status:
			network_status.text = "Erro ao iniciar ligação: %s" % error_string(result)
			_sync_network_status_to_menu()
		return
	multiplayer.multiplayer_peer = network_peer
	_client_connect_elapsed = 0.0
	if network_status:
		network_status.text = "A ligar a %s:%d…" % [address, PORT]
		_sync_network_status_to_menu()

func _on_connected_to_server() -> void:
	_client_connect_elapsed = 0.0
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	rpc_id(1, "request_initial_session_state")
	if network_status:
		network_status.text = "Ligado ao anfitrião · ID %d" % local_player_id
		_sync_network_status_to_menu()

func _on_connection_failed() -> void:
	_client_connect_elapsed = 0.0
	if network_status:
		network_status.text = "Ligação falhou. Verifica o IP do anfitrião, a mesma WLAN e se a rede permite comunicação entre dispositivos."
		_sync_network_status_to_menu()
	if network_peer != null:
		network_peer.close()
		network_peer = null
	multiplayer.multiplayer_peer = null

func _on_server_disconnected() -> void:
	if network_status:
		network_status.text = "Ligação ao anfitrião perdida. Volta a ligar à sessão WLAN."
		_sync_network_status_to_menu()
	if network_peer != null:
		network_peer.close()
		network_peer = null
	multiplayer.multiplayer_peer = null

func _on_peer_connected(peer_id: int) -> void:
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	if multiplayer.is_server() and not remote_players.has(peer_id):
		var host_player := get_node_or_null("Player") as Node3D
		var spawn_position := host_player.global_position + Vector3(1.5, 0.0, 1.5) if host_player else Vector3.ZERO
		var avatar := _make_remote_avatar(peer_id)
		avatar.global_position = spawn_position
		remote_players[peer_id] = avatar
		_last_authoritative_player_positions[peer_id] = spawn_position
	if multiplayer.is_server() and not traitor_role_assigned:
		_assign_hidden_roles()
	if multiplayer.is_server():
		if traitor_role_assigned:
			var is_traitor := peer_id == traitor_peer_id
			var role_message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
			rpc_id(peer_id, "receive_secret_role", is_traitor, role_message)
		_send_entity_state_to(peer_id)
	if network_status:
		network_status.text = "Ligado · novo jogador %d" % peer_id
		_sync_network_status_to_menu()

@rpc("any_peer", "call_remote", "reliable")
func request_initial_session_state() -> void:
	if not multiplayer.is_server():
		return
	var requester := multiplayer.get_remote_sender_id()
	if requester <= 1:
		return
	if traitor_role_assigned:
		var is_traitor := requester == traitor_peer_id
		var message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
		rpc_id(requester, "receive_secret_role", is_traitor, message)
	_send_entity_state_to(requester)
	rpc_id(requester, "client_sync_secret_progress", experiment_clues_found.keys(), evidence_synthesis_complete, secret_experiment_open)

@rpc("authority", "call_remote", "reliable")
func client_sync_secret_progress(found_ids: Array, synthesis_done: bool, door_open: bool) -> void:
	experiment_clues_found.clear()
	for raw_id in found_ids:
		experiment_clues_found[int(raw_id)] = true
	evidence_synthesis_complete = synthesis_done
	secret_experiment_open = door_open
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: %02d / 10" % experiment_clues_found.size()
	if experiment_clues_found.size() >= 10:
		client_reveal_secret_console()
	if evidence_synthesis_complete:
		_unlock_secret_door()
	if door_open and secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)

func _assign_hidden_roles() -> void:
	if not multiplayer.is_server() or traitor_role_assigned:
		return
	var participants: Array[int] = [1]
	for peer_id in multiplayer.get_peers():
		participants.append(int(peer_id))
	if participants.size() < 2:
		return # The traitor is a human player; solo play has no human traitor.
	participants.shuffle()
	traitor_peer_id = participants[0]
	traitor_role_assigned = true
	for participant_id in participants:
		var is_traitor := participant_id == traitor_peer_id
		var message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
		if participant_id == 1:
			_show_role_notice(is_traitor, message)
		else:
			rpc_id(participant_id, "receive_secret_role", is_traitor, message)

@rpc("authority", "call_remote", "reliable")
func receive_secret_role(is_traitor: bool, message: String) -> void:
	_show_role_notice(is_traitor, message)

func _show_role_notice(is_traitor: bool, message: String) -> void:
	if role_notice_layer != null:
		role_notice_layer.queue_free()
	role_notice_layer = CanvasLayer.new()
	role_notice_layer.name = "PrivateRoleNotice"
	role_notice_layer.layer = 150
	add_child(role_notice_layer)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.008, 0.012, 0.018, 0.94)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	role_notice_layer.add_child(backdrop)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 24
	center.offset_right = -24
	center.offset_top = 24
	center.offset_bottom = -24
	role_notice_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(minf(560.0, get_viewport().get_visible_rect().size.x - 48.0), 0)
	center.add_child(panel)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 14)
	panel.add_child(stack)
	var heading := Label.new()
	heading.text = "INSTRUÇÃO CONFIDENCIAL" if is_traitor else "MISSÃO ATRIBUÍDA"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.add_theme_font_size_override("font_size", 23)
	heading.add_theme_color_override("font_color", Color(0.88, 0.19, 0.15) if is_traitor else Color(0.35, 0.82, 0.88))
	stack.add_child(heading)
	var body := Label.new()
	body.text = message
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.custom_minimum_size = Vector2(0, 100)
	body.add_theme_font_size_override("font_size", 17)
	stack.add_child(body)
	var confirm := Button.new()
	confirm.text = "COMPREENDI"
	confirm.custom_minimum_size = Vector2(0, 48)
	confirm.pressed.connect(func(): role_notice_layer.queue_free(); role_notice_layer = null)
	stack.add_child(confirm)

func _on_peer_disconnected(peer_id: int) -> void:
	if remote_players.has(peer_id):
		remote_players[peer_id].queue_free()
		remote_players.erase(peer_id)	
	_last_authoritative_player_positions.erase(peer_id)
	if multiplayer.is_server():
		for key in switch_owners.keys():
			if int(switch_owners[key]) == peer_id:
				switch_owners[key] = 0
		decision_votes.erase(peer_id)
		# Recalculate the objective after a participant leaves; a disconnected peer
		# must not keep a relay or the bulkhead permanently unlocked.
		coop_solved = switch_owners["A"] != 0 and switch_owners["B"] != 0 and switch_owners["A"] != switch_owners["B"]
		_broadcast_switch_state()
	if network_status:
		network_status.text = "Jogador %d saiu" % peer_id
		_sync_network_status_to_menu()

func _process(delta: float) -> void:
	# ENet can remain in CONNECTING on some Android/network combinations.
	# Never leave the UI stuck indefinitely: stop the attempt and expose a useful status.
	if network_peer != null and network_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTING:
		_client_connect_elapsed += delta
		if _client_connect_elapsed >= CLIENT_CONNECT_TIMEOUT:
			if network_peer != null:
				network_peer.close()
				network_peer = null
			multiplayer.multiplayer_peer = null
			_client_connect_elapsed = 0.0
			if network_status:
				network_status.text = "Tempo esgotado: sem resposta de %s:%d. Verifica o IP do anfitrião, desativa VPN/hotspot alternativo e confirma que o router permite comunicação entre dispositivos na UDP %d." % [ip_input.text.strip_edges() if ip_input else "anfitrião", PORT, PORT]
				_sync_network_status_to_menu()
	if multiplayer.is_server() and not entity_active:
		_update_suspense_director(delta)	
	# Single-player traitor AI is independent from the creature AI and only runs offline.
	if multiplayer.multiplayer_peer == null and entity_active:
		_update_solo_traitor_ai(delta)
	_sync_accumulator += delta
	_lighting_time += delta
	_update_lighting_effects()
	_voice_cooldown = maxf(0.0, _voice_cooldown - delta)
	if intro_layer != null and intro_layer.visible:
		intro_elapsed = minf(INTRO_DURATION, intro_elapsed + delta)
		var intro_value := clampf(intro_elapsed / INTRO_DURATION, 0.0, 1.0)
		if intro_progress != null:
			intro_progress.value = intro_value * 100.0
		if intro_percent != null:
			intro_percent.text = "%03d%%" % int(round(intro_value * 100.0))
		if intro_elapsed >= INTRO_DURATION:
			intro_layer.visible = false
			if main_menu_layer != null:
				main_menu_layer.visible = true
	if entity_active:
		entity_motion_time += delta
		if multiplayer.is_server():
			entity_state_time += delta
			_update_entity_ai(delta)
			_entity_sync_accumulator += delta
			if _entity_sync_accumulator >= ENTITY_SYNC_INTERVAL:
				_entity_sync_accumulator = 0.0
				_broadcast_entity_state()
		var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
		if lamp:
			var flicker := 0.35 + absf(sin(entity_motion_time * (10.0 if entity_ai_state == "HUNT" else 6.0))) * (1.15 if entity_ai_state == "HUNT" else 0.65)
			lamp.light_energy = flicker
		_update_stealth_status()
	if _sync_accumulator >= 0.08:
		_sync_accumulator = 0.0
		_broadcast_local_state()
	if mission_hub != null and mission_hub.visible:
		_refresh_mission_hub()

func _broadcast_local_state() -> void:
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	var player := get_node_or_null("Player") as CharacterBody3D
	if player == null:
		return
	var pitch := 0.0
	var pivot := player.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pitch = pivot.rotation.x
	var peer_id := multiplayer.get_unique_id()
	if multiplayer.is_server():
		# The host is authoritative for its own state and relays it to clients.
		rpc("receive_player_state", peer_id, player.global_position, player.rotation.y, pitch)
	else:
		# Clients submit state only to the server; they cannot directly dictate other clients' avatars.
		rpc_id(1, "submit_player_state", player.global_position, player.rotation.y, pitch)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func submit_player_state(pos: Vector3, yaw: float, pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id <= 1 or not remote_players.has(sender_id):
		return
	var avatar := remote_players[sender_id] as Node3D
	if avatar == null or not is_instance_valid(avatar):
		return
	# Reject implausible position jumps. The tolerance accommodates packet jitter and frame stalls.
	var previous: Vector3 = _last_authoritative_player_positions.get(sender_id, avatar.global_position)
	if previous.distance_to(pos) > 2.5:
		return
	_last_authoritative_player_positions[sender_id] = pos
	# Keep the server-side avatar current; proximity checks for relays and sounds use this node.
	avatar.global_position = pos
	avatar.rotation.y = yaw
	var server_pivot := avatar.get_node_or_null("CameraPivot") as Node3D
	if server_pivot:
		server_pivot.rotation.x = clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0))
	rpc("receive_player_state", sender_id, pos, yaw, clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0)))

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_player_state(peer_id: int, pos: Vector3, yaw: float, pitch: float) -> void:
	# Only the server relays accepted states. The RPC sender is server ID 1; retain the peer ID in the payload.
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id > 0 and sender_id != 1:
		return
	if peer_id == multiplayer.get_unique_id():
		return
	var avatar: Node3D = remote_players.get(peer_id)
	if avatar == null:
		avatar = _make_remote_avatar(peer_id)
		remote_players[peer_id] = avatar
	avatar.global_position = pos
	avatar.rotation.y = yaw
	var pivot := avatar.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pivot.rotation.x = clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0))

func _make_remote_avatar(peer_id: int) -> Node3D:
	var avatar := Node3D.new()
	avatar.name = "RemotePlayer_%d" % peer_id
	_add_human_model(avatar, Color(0.20, 0.46, 0.58), true, true)
	var pivot := Node3D.new()
	pivot.name = "CameraPivot"
	pivot.position.y = 1.45
	avatar.add_child(pivot)
	add_child(avatar)
	return avatar

func request_switch(switch_id: String) -> void:
	_play_sfx("object_latch.wav")
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		_set_coop_status("Liga a sessão e junta um segundo jogador para ativar os dois relés.")
		return
	if multiplayer.is_server():
		_server_toggle_switch(switch_id, multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_toggle_switch", switch_id)

@rpc("any_peer", "call_remote", "reliable")
func server_toggle_switch(switch_id: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	_server_toggle_switch(switch_id, sender)

func _server_toggle_switch(switch_id: String, peer_id: int) -> void:
	if not multiplayer.is_server() or not switch_owners.has(switch_id) or coop_solved:
		return
	if peer_id <= 0:
		return
	# Validate proximity on the authority. A client cannot activate a relay remotely
	# by sending the RPC without actually being near that station.
	var actor: Node3D = null
	if peer_id == 1:
		actor = get_node_or_null("Player") as Node3D
	else:
		actor = remote_players.get(peer_id) as Node3D
	var station := get_node_or_null("CoopSwitch" + switch_id) as Node3D
	if actor == null or station == null or not is_instance_valid(actor) or not is_instance_valid(station):
		return
	if actor.global_position.distance_to(station.global_position) > 3.0:
		return
	# One player cannot satisfy both stations. They must be operated by distinct peers.
	if switch_owners[switch_id] == peer_id:
		switch_owners[switch_id] = 0
	else:
		switch_owners[switch_id] = peer_id
	coop_solved = switch_owners["A"] != 0 and switch_owners["B"] != 0 and switch_owners["A"] != switch_owners["B"]
	_broadcast_switch_state()

func _broadcast_switch_state() -> void:
	_apply_switch_state(switch_owners["A"], switch_owners["B"], coop_solved)
	if multiplayer.multiplayer_peer != null and multiplayer.is_server():
		rpc("apply_switch_state", switch_owners["A"], switch_owners["B"], coop_solved)

@rpc("authority", "call_remote", "reliable")
func apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	_apply_switch_state(owner_a, owner_b, solved)

func _apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	switch_owners["A"] = owner_a
	switch_owners["B"] = owner_b
	var was_solved := coop_solved
	coop_solved = solved
	if solved and not was_solved:
		_play_context_voice("COOP_SOLVED")
	var a := get_node_or_null("CoopSwitchA/SwitchMesh") as MeshInstance3D
	var b := get_node_or_null("CoopSwitchB/SwitchMesh") as MeshInstance3D
	if a:
		a.material_override = _material(Color(0.12, 0.72, 0.42) if owner_a != 0 else Color(0.24, 0.28, 0.30), 0.38, 0.55)
	if b:
		b.material_override = _material(Color(0.12, 0.72, 0.42) if owner_b != 0 else Color(0.24, 0.28, 0.30), 0.38, 0.55)
	if solved:
		_set_coop_status("RELÉS ATIVOS POR JOGADORES DIFERENTES — CÂMARA DESBLOQUEADA")
		var door := get_node_or_null("InteractiveBulkhead")
		if door and door.has_method("open_for_coop"):
			door.open_for_coop()
	else:
		_set_coop_status("RELÉ A: %s   ·   RELÉ B: %s" % ["ATIVO" if owner_a != 0 else "PENDENTE", "ATIVO" if owner_b != 0 else "PENDENTE"])

func _toggle_network_panel(panel: PanelContainer) -> void:
	if panel:
		panel.visible = not panel.visible

func _set_coop_status(message: String) -> void:
	if coop_status:
		coop_status.text = message

func _update_private_clue() -> void:
	if private_clue == null:
		return
	local_player_id = multiplayer.get_unique_id()
	var clue := ""
	match local_player_id:
		1:
			clue = "DOSSIÊ PRIVADO 01 — REGISTO DE CÂMARA: uma silhueta atravessou a porta às 02:13. O rosto não é identificável."
		2:
			clue = "DOSSIÊ PRIVADO 02 — REGISTO MAGNÉTICO: a porta permaneceu selada entre as 02:00 e as 02:20. Não há abertura registada."
		3:
			clue = "DOSSIÊ PRIVADO 03 — ÁUDIO RECUPERADO: às 02:13 ouvem-se duas vozes; uma diz «não o deixes entrar»."
		_:
			clue = "DOSSIÊ PRIVADO 04 — SENSOR TÉRMICO: às 02:13 foi detetado movimento, mas sem assinatura térmica humana compatível."
	private_clue.text = clue

func submit_decision(choice: String) -> void:
	if decision_resolved:
		_set_decision_status("A decisão desta missão já foi tomada.")
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		_set_decision_status("Liga-te a uma sessão para confrontar a equipa com outro jogador.")
		return
	if multiplayer.is_server():
		_server_record_decision(multiplayer.get_unique_id(), choice)
	else:
		rpc_id(1, "server_record_decision", choice)
	_set_decision_status("Voto registado em privado. Compara as provas antes de decidirem.")

@rpc("any_peer", "call_remote", "reliable")
func server_record_decision(choice: String) -> void:
	if not multiplayer.is_server() or decision_resolved:
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 0:
		return
	_server_record_decision(sender, choice)

func _server_record_decision(peer_id: int, choice: String) -> void:
	if decision_resolved or peer_id <= 0:
		return
	decision_votes[peer_id] = choice
	var eligible := 1
	if network_peer != null:
		eligible = max(1, network_peer.get_peers().size() + 1)
	if decision_votes.size() < min(2, eligible):
		_broadcast_decision_status("Votos recebidos: %d/%d. Falta ouvir outro jogador." % [decision_votes.size(), min(2, eligible)])
		return
	var accuse_count := 0
	var defend_count := 0
	for vote in decision_votes.values():
		if vote == "ACUSAR":
			accuse_count += 1
		else:
			defend_count += 1
	decision_resolved = true
	var outcome := ""
	if accuse_count > defend_count:
		outcome = "CONSEQUÊNCIA: ACUSAÇÃO — o alarme dispara e a estação entra em contenção. A equipa perde a confiança do operador."
		_set_alarm_state(true)
	elif defend_count > accuse_count:
		outcome = "CONSEQUÊNCIA: DEFESA — o operador mantém acesso, mas uma porta secundária desbloqueia-se sem explicação."
		_set_alarm_state(false)
	else:
		outcome = "CONSEQUÊNCIA: DIVISÃO — sem consenso, o sistema entra em bloqueio e a luz de emergência falha."
		_set_alarm_state(true)
	_broadcast_decision_result(outcome)

func _broadcast_decision_status(message: String) -> void:
	_set_decision_status(message)
	if multiplayer.is_server():
		rpc("apply_decision_status", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_status(message: String) -> void:
	_set_decision_status(message)

func _broadcast_decision_result(message: String) -> void:
	_apply_decision_result(message)
	if multiplayer.is_server():
		rpc("apply_decision_result", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_result(message: String) -> void:
	_apply_decision_result(message)

func _apply_decision_result(message: String) -> void:
	decision_resolved = true
	_activate_entity_reaction(message)
	_set_decision_status(message)
	_set_alarm_state(message.begins_with("CONSEQUÊNCIA: ACUSAÇÃO") or message.begins_with("CONSEQUÊNCIA: DIVISÃO"))
	if accusation_button:
		accusation_button.disabled = true
	if defense_button:
		defense_button.disabled = true

func _update_suspense_director(delta: float) -> void:
	# Os sinais ambientais podem surgir com intervalos variáveis, mas nunca
	# forçam a aparição da criatura por decurso de tempo.
	suspense_elapsed += delta
	if suspense_elapsed >= suspense_next_event:
		if entity_reaction_label:
			entity_reaction_label.text = suspense_messages[suspense_event_index % suspense_messages.size()]
		suspense_event_index += 1
		suspense_next_event = suspense_elapsed + suspense_rng.randf_range(28.0, 48.0)
		if suspense_event_index % 2 == 0:
			_play_sfx("relay_click.wav")

func _activate_entity_reaction(outcome: String) -> void:
	if outcome != "INITIAL_PATROL":
		_play_sfx("entity_sting.wav")
	if entity_active:
		return
	entity_active = true
	var room := get_node_or_null("ResearchStationRoom") as Node3D
	if room == null:
		return
	# A distant, deliberately ambiguous silhouette appears only after the team's decision.
	entity_presence = Node3D.new()
	entity_presence.name = "UnidentifiedPresence"
	entity_presence.position = entity_waypoints[entity_waypoint_index]
	room.add_child(entity_presence)
	var entity_model := Node3D.new()
	entity_model.name = "EntityHumanoidModel"
	entity_model.position.y = 0.82
	entity_presence.add_child(entity_model)
	_add_human_model(entity_model, Color(0.012, 0.018, 0.022), true)
	var collision := StaticBody3D.new()
	collision.name = "EntityCollision"
	var collision_shape := CollisionShape3D.new()
	var collision_capsule := CapsuleShape3D.new()
	collision_capsule.radius = 0.34
	collision_capsule.height = 1.9
	collision_shape.shape = collision_capsule
	collision_shape.position.y = 1.0
	collision.add_child(collision_shape)
	entity_presence.add_child(collision)
	for eye_x in [-0.12, 0.12]:
		var eye := MeshInstance3D.new()
		var eye_mesh := SphereMesh.new()
		eye_mesh.radius = 0.035
		eye_mesh.height = 0.07
		eye.mesh = eye_mesh
		var eye_mat := StandardMaterial3D.new()
		eye_mat.albedo_color = Color(0.55, 0.015, 0.01)
		eye_mat.emission_enabled = true
		eye_mat.emission = Color(0.8, 0.01, 0.005)
		eye.material_override = eye_mat
		eye.position = Vector3(eye_x, 1.42, -0.145)
		entity_presence.add_child(eye)
	entity_ai_state = "PATROL"
	entity_state_time = 0.0
	if entity_reaction_label:
		if outcome.begins_with("CONSEQUÊNCIA: ACUSAÇÃO"):
			entity_reaction_label.text = "SINAL HOSTIL: a contenção chamou algo até à estação."
		elif outcome.begins_with("CONSEQUÊNCIA: DEFESA"):
			entity_reaction_label.text = "SINAL ANÓMALO: a presença apareceu depois de manterem o acesso."
		elif outcome == "INITIAL_PATROL":
			entity_reaction_label.text = "A estação permanece em silêncio. Há movimento não confirmado nos corredores."
		else:
			entity_reaction_label.text = "SINAL CRÍTICO: foi detetada uma anomalia na estação."

func _update_solo_traitor_ai(delta: float) -> void:
	# This character is never assigned to the player and is never the creature.
	# It manipulates station systems and leaves ambiguous evidence; it does not
	# reveal its identity in the public mission UI.
	solo_traitor_timer += delta
	if solo_traitor_glimpse_timer > 0.0:
		solo_traitor_glimpse_timer = maxf(0.0, solo_traitor_glimpse_timer - delta)
		if solo_traitor_glimpse_timer == 0.0 and solo_traitor_presence:
			solo_traitor_presence.visible = false
	if solo_traitor_timer < solo_traitor_next_action:
		return
	solo_traitor_timer = 0.0
	solo_traitor_next_action = solo_traitor_rng.randf_range(34.0, 52.0)
	solo_traitor_sabotages += 1
	# Sabotage is a temporary systems disturbance, not an arbitrary death or attack.
	_set_alarm_state(true)
	if entity_reaction_label:
		var messages := [
			"REGISTO ANÓMALO: uma ordem de manutenção foi executada sem credenciais válidas.",
			"COMUNICAÇÕES: pacote de diagnóstico alterado. A origem não foi identificada.",
			"ENERGIA: um circuito foi isolado manualmente. Não existe operador registado.",
			"SEGURANÇA: acesso autorizado com uma credencial que deveria estar desativada."
		]
		entity_reaction_label.text = messages[(solo_traitor_sabotages - 1) % messages.size()]
	# A brief human silhouette may be seen at a distant waypoint; no label identifies it.
	if solo_traitor_presence == null:
		solo_traitor_presence = Node3D.new()
		solo_traitor_presence.name = "UnidentifiedStaffSilhouette"
		var room := get_node_or_null("ResearchStationRoom") as Node3D
		if room:
			room.add_child(solo_traitor_presence)
			var model := Node3D.new()
			model.name = "StaffSilhouetteModel"
			model.position.y = 0.82
			solo_traitor_presence.add_child(model)
			_add_human_model(model, Color(0.10, 0.16, 0.19), true)
			var coat := StandardMaterial3D.new()
			coat.albedo_color = Color(0.035, 0.055, 0.065)
			coat.roughness = 0.95
			for child in model.get_children():
				if child is MeshInstance3D:
					child.material_override = coat
	var waypoint := solo_traitor_rng.randi_range(0, entity_waypoints.size() - 1)
	solo_traitor_presence.position = entity_waypoints[waypoint] + Vector3(0.0, 0.0, -1.2)
	solo_traitor_presence.visible = true
	solo_traitor_glimpse_timer = 2.2
	# The sabotage signal is transient. The player must investigate the evidence.
	get_tree().create_timer(5.0).timeout.connect(func():
		if is_instance_valid(self):
			_set_alarm_state(false)
	)

func _update_entity_ai(delta: float) -> void:
	# The host is the only authority allowed to decide AI movement/state.
	if not multiplayer.is_server() or entity_presence == null:
		return
	var player := _find_entity_target()
	if player == null:
		return
	var distance_to_player := entity_presence.global_position.distance_to(player.global_position)
	var observed := _is_entity_observed(player)
	var player_speed := 0.0
	if player is CharacterBody3D:
		player_speed = Vector2((player as CharacterBody3D).velocity.x, (player as CharacterBody3D).velocity.z).length()
	var crouching := bool(player.get("is_crouching")) if player.get("is_crouching") != null else false
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	var illuminated := _is_entity_lit_by_player(player, flashlight)
	# Fast movement creates noise; crouching reduces the detection radius. A beam on the entity can provoke it.
	if observed and distance_to_player < 19.0:
		entity_ai_state = "OBSERVED"
		_play_context_voice("OBSERVED")
		entity_hidden_time = 2.6
		entity_presence.visible = false
		entity_state_time = 0.0
		if entity_reaction_label:
			entity_reaction_label.text = "A PRESENÇA DESAPARECEU QUANDO A OBSERVASTE. O ruído continua no corredor…"
		return
	if entity_ai_state == "OBSERVED":
		entity_hidden_time -= delta
		if entity_hidden_time <= 0.0:
			entity_ai_state = "PATROL"
			entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
			entity_presence.position = entity_waypoints[entity_waypoint_index]
			entity_presence.visible = true
			entity_state_time = 0.0
			if entity_reaction_label:
				entity_reaction_label.text = "MOVIMENTO DETETADO NOUTRA ZONA. A entidade mudou de posição."
		return
	var noise_radius := 5.0 if crouching else 13.0
	var old_state := entity_ai_state
	if (player_speed > 2.25 and not crouching and distance_to_player < noise_radius) or (illuminated and distance_to_player < 15.0):
		entity_ai_state = "HUNT"
	else:
		entity_ai_state = "PATROL"
	if entity_ai_state == "HUNT" and old_state != "HUNT":
		_play_sfx("danger_pulse.wav")
		_play_context_voice("HUNT")
	var target := entity_waypoints[entity_waypoint_index]
	if entity_ai_state == "HUNT" and distance_to_player > 3.4:
		# A lit target is more compelling than sound alone, but crouching still lowers noise.
		target = player.global_position
	elif entity_presence.global_position.distance_to(target) < 0.7:
		entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
		target = entity_waypoints[entity_waypoint_index]
	var flat_target := Vector3(target.x, entity_presence.position.y, target.z)
	var step := 1.35 if entity_ai_state == "PATROL" else 2.15
	entity_presence.global_position = entity_presence.global_position.move_toward(flat_target, step * delta)
	if entity_presence.global_position.distance_to(player.global_position) < 1.35:
		if entity_ai_state != "ATTACK_WARNING":
			_play_sfx("danger_pulse.wav")
			_play_context_voice("ATTACK_WARNING")
		entity_ai_state = "ATTACK_WARNING"
		if entity_reaction_label:
			entity_reaction_label.text = "PERIGO IMEDIATO: a presença chegou demasiado perto. Recuem e não façam ruído."
	elif entity_ai_state == "HUNT" and entity_reaction_label and entity_state_time > 1.8 and Time.get_ticks_msec() / 1000.0 - entity_last_notice > 2.5:
		entity_reaction_label.text = "A ENTIDADE DETETOU %s. %s" % ["a luz da lanterna" if illuminated else "o ruído", "Desliga a lanterna e agacha-te." if illuminated else "Agacha-te para reduzir o ruído."]
		entity_last_notice = Time.get_ticks_msec() / 1000.0

func _find_entity_target() -> Node3D:
	var best: Node3D = get_node_or_null("Player") as Node3D
	var best_distance := INF
	if best != null and is_instance_valid(best):
		best_distance = entity_presence.global_position.distance_to(best.global_position)
	for peer_id in remote_players.keys():
		var candidate := remote_players[peer_id] as Node3D
		if candidate == null or not is_instance_valid(candidate):
			continue
		var distance := entity_presence.global_position.distance_to(candidate.global_position)
		if distance < best_distance:
			best = candidate
			best_distance = distance
	return best

func _broadcast_entity_state() -> void:
	if not multiplayer.is_server() or entity_presence == null:
		return
	rpc("receive_entity_state", entity_presence.global_position, entity_presence.visible, entity_ai_state, entity_waypoint_index, entity_hidden_time, entity_state_time, entity_reaction_label.text if entity_reaction_label else "")

func _send_entity_state_to(peer_id: int) -> void:
	if not multiplayer.is_server() or entity_presence == null:
		return
	rpc_id(peer_id, "receive_entity_state", entity_presence.global_position, entity_presence.visible, entity_ai_state, entity_waypoint_index, entity_hidden_time, entity_state_time, entity_reaction_label.text if entity_reaction_label else "")

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_entity_state(position: Vector3, visible: bool, ai_state: String, waypoint_index: int, hidden_time: float, state_time: float, reaction_text: String) -> void:
	# Clients render the host's snapshot; they never simulate or decide the creature AI.
	if multiplayer.is_server():
		return
	if entity_presence == null:
		_activate_entity_reaction("INITIAL_PATROL")
	if entity_presence == null:
		return
	entity_active = true
	entity_presence.global_position = position
	entity_presence.visible = visible
	entity_ai_state = ai_state
	entity_waypoint_index = waypoint_index
	entity_hidden_time = hidden_time
	entity_state_time = state_time
	if entity_reaction_label and not reaction_text.is_empty():
		entity_reaction_label.text = reaction_text

func _is_entity_lit_by_player(player: Node3D, flashlight: SpotLight3D) -> bool:
	if flashlight == null or not flashlight.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - flashlight.global_position
	if to_entity.length() > flashlight.spot_range:
		return false
	var forward := -flashlight.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < cos(deg_to_rad(flashlight.spot_angle * 0.5)):
		return false
	var query := PhysicsRayQueryParameters3D.create(flashlight.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _update_stealth_status() -> void:
	if stealth_status == null:
		return
	var player := get_node_or_null("Player")
	if player == null:
		return
	var crouching := bool(player.get("is_crouching"))
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	stealth_status.text = "FURTIVIDADE: AGACHADO · RUÍDO BAIXO" if crouching else "FURTIVIDADE: DE PÉ · RUÍDO ELEVADO"
	if flashlight and flashlight.visible:
		stealth_status.text += " · LANTERNA LIGADA"

func _is_entity_observed(player: Node3D) -> bool:
	var camera := player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
	if camera == null or not entity_presence.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - camera.global_position
	if to_entity.length() > 17.0:
		return false
	var forward := -camera.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < 0.965:
		return false
	var query := PhysicsRayQueryParameters3D.create(camera.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _set_decision_status(message: String) -> void:
	if decision_status:
		decision_status.text = message

func _set_alarm_state(active: bool) -> void:
	_alarm_active = active
	var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
	if lamp:
		lamp.light_color = Color(1.0, 0.025, 0.01) if active else (Color(0.1, 0.9, 0.35) if coop_solved else Color(0.18, 0.48, 0.72))
		lamp.light_energy = 1.35 if active else (0.9 if coop_solved else 0.45)
	var beacon := get_node_or_null("ResearchStationRoom/AlarmBeacon") as OmniLight3D
	if beacon:
		beacon.visible = active
	var beacon_mesh := get_node_or_null("ResearchStationRoom/AlarmBeacon/BeaconMesh") as MeshInstance3D
	if beacon_mesh:
		beacon_mesh.visible = active

func _update_lighting_effects() -> void:
	# LEDs and luminaires respond to danger, relays and the emergency state.
	var room := get_node_or_null("ResearchStationRoom")
	if room == null:
		return
	var lamp := room.get_node_or_null("FailingEmergencyLamp") as OmniLight3D
	if lamp and entity_active:
		var speed := 15.0 if entity_ai_state == "HUNT" else 7.0
		var depth := 1.0 if entity_ai_state == "HUNT" else 0.45
		lamp.light_energy = (0.42 + absf(sin(_lighting_time * speed)) * depth) if not _alarm_active else (0.3 + absf(sin(_lighting_time * 13.0)) * 1.45)
	var strip_a := room.get_node_or_null("LEDStripA") as MeshInstance3D
	var strip_b := room.get_node_or_null("LEDStripB") as MeshInstance3D
	var led_color := Color(1.0, 0.025, 0.01) if _alarm_active else (Color(0.05, 1.0, 0.35) if coop_solved else Color(0.05, 0.65, 1.0))
	for strip in [strip_a, strip_b]:
		if strip and strip.material_override is StandardMaterial3D:
			var mat := strip.material_override as StandardMaterial3D
			mat.albedo_color = led_color
			mat.emission = led_color
			mat.emission_energy_multiplier = 1.8 if not _alarm_active else (0.6 + absf(sin(_lighting_time * 12.0)) * 3.5)
	var exit_light := room.get_node_or_null("ExitIndicatorLight") as OmniLight3D
	if exit_light:
		exit_light.light_color = Color(0.05, 1.0, 0.25) if coop_solved else Color(0.1, 0.65, 0.35)
		exit_light.light_energy = 1.3 if coop_solved else 0.45

func _build_environment() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.015, 0.025, 0.04)
	sky_mat.sky_horizon_color = Color(0.06, 0.065, 0.07)
	sky_mat.ground_bottom_color = Color(0.008, 0.01, 0.012)
	sky_mat.ground_horizon_color = Color(0.035, 0.04, 0.045)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.19, 0.22, 0.27)
	env.ambient_light_energy = 0.62
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world.environment = env
	add_child(world)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-42, -25, 0)
	moon.light_color = Color(0.52, 0.61, 0.78)
	moon.light_energy = 0.38
	moon.shadow_enabled = true
	add_child(moon)
	var fill_light := OmniLight3D.new()
	fill_light.name = "RoomFillLight"
	fill_light.position = Vector3(0, 2.7, -2.5)
	fill_light.light_color = Color(0.48, 0.57, 0.66)
	fill_light.light_energy = 0.7
	fill_light.omni_range = 13.0
	fill_light.shadow_enabled = false
	add_child(fill_light)

func _build_room() -> void:
	var room := Node3D.new()
	room.name = "ResearchStationRoom"
	add_child(room)
	var concrete := _material(Color(0.19, 0.205, 0.21))
	var floor_mat := _material(Color(0.075, 0.085, 0.09), 0.28, 0.18)
	var metal := _material(Color(0.11, 0.135, 0.15), 0.42, 0.62)
	var hazard := _material(Color(0.43, 0.19, 0.07), 0.65, 0.25)
	_box(room, "Floor", Vector3(12, 0.3, 16), Vector3(0, -0.15, -2), floor_mat)
	_box(room, "Ceiling", Vector3(12, 0.25, 16), Vector3(0, 3.6, -2), concrete)
	_box(room, "LeftWall", Vector3(0.3, 3.6, 16), Vector3(-6, 1.65, -2), concrete)
	_box(room, "RightWall", Vector3(0.3, 3.6, 16), Vector3(6, 1.65, -2), concrete)
	# Split the rear wall around a real doorway; the previous solid wall made
	# the door appear interactive while physically blocking the exit.
	_box(room, "BackWallLeft", Vector3(4.7, 3.6, 0.3), Vector3(-3.65, 1.65, -10), concrete)
	_box(room, "BackWallRight", Vector3(4.7, 3.6, 0.3), Vector3(3.65, 1.65, -10), concrete)
	_box(room, "DoorLintel", Vector3(2.6, 0.65, 0.3), Vector3(0, 3.275, -10), concrete)
	# A short corridor makes the doorway lead somewhere instead of ending at a wall.
	_box(room, "ExitCorridorFloor", Vector3(3.0, 0.18, 7.0), Vector3(0, -0.16, -13.3), floor_mat)
	_box(room, "ExitCorridorLeft", Vector3(0.18, 3.3, 7.0), Vector3(-1.5, 1.5, -13.3), concrete)
	_box(room, "ExitCorridorRight", Vector3(0.18, 3.3, 7.0), Vector3(1.5, 1.5, -13.3), concrete)
	# Modular wall ribs and pipe runs establish scale and navigation cues.
	for i in range(5):
		var z := 4.0 - float(i) * 3.0
		_box(room, "WallRib_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(-5.72, 1.55, z), metal)
		_box(room, "WallRibR_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(5.72, 1.55, z), metal)
	_box(room, "PipeHorizontal", Vector3(0.18, 0.18, 12), Vector3(-5.55, 2.95, -2), hazard)
	_box(room, "ControlDesk", Vector3(2.3, 0.95, 0.8), Vector3(-3.7, 0.48, -3.8), metal)
	_box(room, "StorageCrate", Vector3(1.1, 1.2, 1.0), Vector3(3.8, 0.6, 1.2), concrete)
	var lamp := OmniLight3D.new()
	lamp.name = "FailingEmergencyLamp"
	lamp.position = Vector3(0, 3.15, -4)
	lamp.light_color = Color(0.65, 0.11, 0.055)
	lamp.light_energy = 0.9
	lamp.omni_range = 10
	lamp.shadow_enabled = true
	room.add_child(lamp)
	# Ceiling luminaires with emissive LED panels create visible pools of light.
	for i in range(3):
		var z := 2.0 - float(i) * 4.0
		var panel_mat := StandardMaterial3D.new()
		panel_mat.albedo_color = Color(0.55, 0.82, 1.0)
		panel_mat.emission_enabled = true
		panel_mat.emission = Color(0.24, 0.62, 1.0)
		panel_mat.emission_energy_multiplier = 1.1
		_box(room, "CeilingLEDPanel_%02d" % i, Vector3(1.45, 0.055, 0.42), Vector3(0, 3.43, z), panel_mat, false)
		var ceiling_light := OmniLight3D.new()
		ceiling_light.name = "CeilingLamp_%02d" % i
		ceiling_light.position = Vector3(0, 3.15, z)
		ceiling_light.light_color = Color(0.48, 0.72, 1.0)
		ceiling_light.light_energy = 0.7
		ceiling_light.omni_range = 5.5
		ceiling_light.shadow_enabled = false
		room.add_child(ceiling_light)
	# Wall LED strips change from blue (normal) to red (alarm) and green (solved).
	var led_mat := StandardMaterial3D.new()
	led_mat.albedo_color = Color(0.05, 0.65, 1.0)
	led_mat.emission_enabled = true
	led_mat.emission = Color(0.05, 0.65, 1.0)
	led_mat.emission_energy_multiplier = 1.8
	_box(room, "LEDStripA", Vector3(0.055, 0.08, 10.5), Vector3(-5.78, 2.72, -2.0), led_mat, false)
	_box(room, "LEDStripB", Vector3(0.055, 0.08, 10.5), Vector3(5.78, 2.72, -2.0), led_mat, false)
	# Emergency beacon only flashes when an alarm/event is active.
	var beacon := OmniLight3D.new()
	beacon.name = "AlarmBeacon"
	beacon.position = Vector3(4.8, 3.0, -7.5)
	beacon.light_color = Color(1.0, 0.015, 0.005)
	beacon.light_energy = 2.2
	beacon.omni_range = 7.0
	beacon.visible = false
	beacon.shadow_enabled = false
	room.add_child(beacon)
	var beacon_mesh := MeshInstance3D.new()
	beacon_mesh.name = "BeaconMesh"
	var beacon_shape := SphereMesh.new()
	beacon_shape.radius = 0.16
	beacon_shape.height = 0.32
	beacon_mesh.mesh = beacon_shape
	var beacon_mat := StandardMaterial3D.new()
	beacon_mat.albedo_color = Color(1.0, 0.01, 0.005)
	beacon_mat.emission_enabled = true
	beacon_mat.emission = Color(1.0, 0.01, 0.005)
	beacon_mat.emission_energy_multiplier = 3.0
	beacon_mesh.material_override = beacon_mat
	beacon_mesh.position = Vector3.ZERO
	beacon.add_child(beacon_mesh)
	beacon_mesh.visible = false
	var green := StandardMaterial3D.new()
	green.albedo_color = Color(0.12, 0.8, 0.31)
	green.emission_enabled = true
	green.emission = Color(0.05, 1.0, 0.22)
	green.emission_energy_multiplier = 2.2
	_box(room, "ExitIndicator", Vector3(0.75, 0.12, 0.06), Vector3(0, 2.85, -9.72), green, false)
	var exit_light := OmniLight3D.new()
	exit_light.name = "ExitIndicatorLight"
	exit_light.position = Vector3(0, 2.75, -9.25)
	exit_light.light_color = Color(0.1, 0.65, 0.35)
	exit_light.light_energy = 0.45
	exit_light.omni_range = 3.0
	exit_light.shadow_enabled = false
	room.add_child(exit_light)

func _build_next_chamber() -> void:
	# Zona 02: câmara de investigação ligada ao corredor de saída.
	# A entrada fica aberta; não existe uma parede sólida a bloquear a passagem.
	var zone := Node3D.new()
	zone.name = "InvestigationChamber02"
	add_child(zone)
	var concrete := _material(Color(0.16, 0.18, 0.20))
	var floor_mat := _material(Color(0.055, 0.065, 0.075), 0.3, 0.2)
	var metal := _material(Color(0.10, 0.13, 0.16), 0.4, 0.55)
	# Câmara centrada em z=-23.5; o piso sobrepõe ligeiramente o corredor.
	_box(zone, "Zone02Floor", Vector3(12.0, 0.3, 12.5), Vector3(0, -0.16, -23.45), floor_mat)
	_box(zone, "Zone02Ceiling", Vector3(12.0, 0.25, 12.5), Vector3(0, 3.6, -23.45), concrete)
	_box(zone, "Zone02LeftWall", Vector3(0.3, 3.6, 12.5), Vector3(-6.0, 1.65, -23.45), concrete)
	_box(zone, "Zone02RightWall", Vector3(0.3, 3.6, 12.5), Vector3(6.0, 1.65, -23.45), concrete)
	# Parede frontal com abertura central de 3 m para a continuação do corredor.
	_box(zone, "Zone02EntryWallLeft", Vector3(4.5, 3.6, 0.3), Vector3(-3.75, 1.65, -17.2), concrete)
	_box(zone, "Zone02EntryWallRight", Vector3(4.5, 3.6, 0.3), Vector3(3.75, 1.65, -17.2), concrete)
	_box(zone, "Zone02EntryLintel", Vector3(3.0, 0.55, 0.3), Vector3(0, 3.30, -17.2), concrete)
	# Equipamento de investigação como referência visual, sem bloquear a circulação.
	_box(zone, "EvidenceConsole", Vector3(2.0, 1.0, 0.65), Vector3(0, 0.5, -27.2), metal)
	var console_label := Label3D.new()
	console_label.name = "Zone02ObjectiveLabel"
	console_label.text = "ZONA 02  /  TERMINAL DE INVESTIGAÇÃO"
	console_label.position = Vector3(0, 1.35, -27.2)
	console_label.font_size = 28
	console_label.modulate = Color(0.55, 0.88, 0.95)
	zone.add_child(console_label)
	var glow_mat := StandardMaterial3D.new()
	glow_mat.albedo_color = Color(0.05, 0.55, 0.75)
	glow_mat.emission_enabled = true
	glow_mat.emission = Color(0.05, 0.65, 1.0)
	glow_mat.emission_energy_multiplier = 1.4
	_box(zone, "Zone02GuideLight", Vector3(1.2, 0.06, 0.08), Vector3(0, 2.8, -17.0), glow_mat, false)
	var lamp := OmniLight3D.new()
	lamp.name = "Zone02ColdLamp"
	lamp.position = Vector3(0, 3.0, -23.5)
	lamp.light_color = Color(0.25, 0.58, 0.72)
	lamp.light_energy = 0.85
	lamp.omni_range = 9.0
	lamp.shadow_enabled = false
	zone.add_child(lamp)


func _build_remaining_zones() -> void:
	# Zonas 03-10: módulos físicos consecutivos. As passagens ficam abertas
	# para que os jogadores possam avançar sem uma barreira invisível.
	var zone_names: Array[String] = [
		"03 / MANUTENÇÃO", "04 / LABORATÓRIO", "05 / CENTRAL ELÉTRICA",
		"06 / CONTENÇÃO", "07 / ARQUIVO SUBTERRÂNEO", "08 / SEGURANÇA",
		"09 / NÚCLEO DA ENTIDADE", "10 / EXTRAÇÃO FINAL"
	]
	var palettes: Array[Color] = [
		Color(0.28, 0.34, 0.36), Color(0.18, 0.32, 0.36),
		Color(0.38, 0.22, 0.12), Color(0.34, 0.10, 0.09),
		Color(0.26, 0.25, 0.22), Color(0.12, 0.20, 0.30),
		Color(0.25, 0.06, 0.08), Color(0.16, 0.28, 0.18)
	]
	var previous_end_z := -29.7 # saída da Zona 02
	for i in range(zone_names.size()):
		var zone_number := i + 3
		var center_z := -42.2 - float(i) * 20.0
		var front_z := center_z + 6.25
		var back_z := center_z - 6.25
		# Corredor de ligação entre módulos, sem colisões no eixo de passagem.
		var corridor_center := (previous_end_z + front_z) * 0.5
		var corridor_length := absf(previous_end_z - front_z) + 0.35
		var corridor := Node3D.new()
		corridor.name = "Connector_%02d" % zone_number
		add_child(corridor)
		var floor_mat := _material(Color(0.055, 0.065, 0.072), 0.32, 0.16)
		var wall_mat := _material(Color(0.14, 0.16, 0.18), 0.78, 0.18)
		_box(corridor, "Floor", Vector3(3.0, 0.18, corridor_length), Vector3(0, -0.16, corridor_center), floor_mat)
		_box(corridor, "LeftWall", Vector3(0.18, 3.2, corridor_length), Vector3(-1.5, 1.45, corridor_center), wall_mat)
		_box(corridor, "RightWall", Vector3(0.18, 3.2, corridor_length), Vector3(1.5, 1.45, corridor_center), wall_mat)
		var zone := Node3D.new()
		zone.name = "Zone%02d" % zone_number
		add_child(zone)
		var tint: Color = palettes[i]
		var concrete := _material(Color(0.13, 0.15, 0.17))
		var floor_material := _material(Color(0.045, 0.052, 0.06), 0.3, 0.25)
		var trim := _material(tint, 0.48, 0.3)
		_box(zone, "Floor", Vector3(12.0, 0.3, 12.5), Vector3(0, -0.16, center_z), floor_material)
		_box(zone, "Ceiling", Vector3(12.0, 0.25, 12.5), Vector3(0, 3.6, center_z), concrete)
		if zone_number == 10:
			# A parede esquerda da Zona 10 tem uma abertura real para o corredor secreto.
			_box(zone, "LeftWallFront", Vector3(0.3, 3.6, 4.3), Vector3(-6.0, 1.65, center_z + 4.1), concrete)
			_box(zone, "LeftWallBack", Vector3(0.3, 3.6, 4.3), Vector3(-6.0, 1.65, center_z - 4.1), concrete)
			_box(zone, "LeftWallLintel", Vector3(0.3, 0.55, 3.9), Vector3(-6.0, 3.30, center_z), concrete)
		else:
			_box(zone, "LeftWall", Vector3(0.3, 3.6, 12.5), Vector3(-6.0, 1.65, center_z), concrete)
		# Abertura lateral para duas salas auxiliares; mantém passagem física real.
		_box(zone, "RightWallFront", Vector3(0.3, 3.6, 4.65), Vector3(6.0, 1.65, center_z + 3.925), concrete)
		_box(zone, "RightWallBack", Vector3(0.3, 3.6, 4.65), Vector3(6.0, 1.65, center_z - 3.925), concrete)
		_box(zone, "RightWallLintel", Vector3(0.3, 0.55, 3.2), Vector3(6.0, 3.30, center_z), concrete)
		# Parede de entrada e de saída segmentadas: abertura central de 3 m.
		for wall_z in [front_z, back_z]:
			_box(zone, "WallLeft_%0.2f" % wall_z, Vector3(4.5, 3.6, 0.3), Vector3(-3.75, 1.65, wall_z), concrete)
			_box(zone, "WallRight_%0.2f" % wall_z, Vector3(4.5, 3.6, 0.3), Vector3(3.75, 1.65, wall_z), concrete)
			_box(zone, "Lintel_%0.2f" % wall_z, Vector3(3.0, 0.55, 0.3), Vector3(0, 3.30, wall_z), concrete)
		# Console lateral deixa o eixo central livre para circulação cooperativa.
		_box(zone, "ObjectiveConsole", Vector3(1.8, 1.0, 0.65), Vector3(-3.9, 0.5, center_z), trim)
		var sign := Label3D.new()
		sign.name = "ZoneTitle"
		sign.text = "ZONA %02d  /  %s" % [zone_number, zone_names[i].split(" / ", true, 1)[1]]
		sign.position = Vector3(0, 2.65, front_z + 0.22)
		sign.font_size = 24
		sign.modulate = tint.lightened(0.45)
		zone.add_child(sign)
		var lamp := OmniLight3D.new()
		lamp.name = "ZoneLamp"
		lamp.position = Vector3(0, 3.0, center_z)
		lamp.light_color = tint.lightened(0.2)
		lamp.light_energy = 0.8
		lamp.omni_range = 9.0
		lamp.shadow_enabled = false
		zone.add_child(lamp)
		# Duas faixas luminosas dão uma referência visual sem marcadores no mini-mapa.
		_box(zone, "TrimLightLeft", Vector3(0.06, 0.08, 9.5), Vector3(-5.78, 2.7, center_z), trim, false)
		_box(zone, "TrimLightRight", Vector3(0.06, 0.08, 9.5), Vector3(5.78, 2.7, center_z), trim, false)
		_build_zone_side_rooms(zone, zone_number, center_z, tint)
		# Cada zona contém uma prova física examinável; a posição fica fora do eixo central.
		_add_experiment_clue(zone, zone_number, Vector3(4.15, 0.65, center_z + 1.25))
		previous_end_z = back_z

func _add_experiment_clue(parent: Node3D, clue_id: int, clue_position: Vector3) -> void:
	var clue := StaticBody3D.new()
	clue.name = "ExperimentClue_%02d" % clue_id
	clue.set_script(load("res://scripts/experiment_clue.gd"))
	clue.clue_id = clue_id
	clue.position = clue_position
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "EvidenceMesh"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.34, 0.42, 0.12)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(Color(0.12, 0.62, 0.68), 0.3, 0.25)
	clue.add_child(mesh_node)
	var glow := OmniLight3D.new()
	glow.name = "EvidenceGlow"
	glow.position = Vector3(0, 0.35, 0)
	glow.light_color = Color(0.12, 0.72, 0.82)
	glow.light_energy = 0.45
	glow.omni_range = 2.2
	clue.add_child(glow)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.3, 1.5, 1.3)
	shape_node.shape = shape
	clue.add_child(shape_node)
	parent.add_child(clue)

func request_experiment_clue(clue_id: int, player: Node = null) -> void:
	if multiplayer.is_server():
		_server_collect_experiment_clue(clue_id)
	else:
		rpc_id(1, "server_collect_experiment_clue", clue_id)

@rpc("any_peer", "call_remote", "reliable")
func server_collect_experiment_clue(clue_id: int) -> void:
	if not multiplayer.is_server():
		return
	_server_collect_experiment_clue(clue_id)

func _server_collect_experiment_clue(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 10 or experiment_clues_found.has(clue_id):
		return
	experiment_clues_found[clue_id] = true
	collect_experiment_clue_local(clue_id)
	rpc("client_sync_experiment_clue", clue_id)
	rpc("client_sync_secret_progress", experiment_clues_found.keys(), evidence_synthesis_complete, secret_experiment_open)

@rpc("authority", "call_remote", "reliable")
func client_sync_experiment_clue(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 10:
		return
	experiment_clues_found[clue_id] = true
	collect_experiment_clue_local(clue_id)

func collect_experiment_clue_local(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 10:
		return
	var clue_names := {
		1: "Registo de admissão",
		2: "Consentimento falsificado",
		3: "Relatório de manutenção",
		4: "Protocolo de incubação",
		5: "Falha de energia planeada",
		6: "Relatório de contenção",
		7: "Diário de laboratório",
		8: "Ordem de segurança",
		9: "Sequência de ativação",
		10: "Gravação da experiência"
	}
	var combination_fragments := {
		2: "CHAVE DE LEITURA: extrai quatro valores por esta ordem — alertas confirmados, ciclos rejeitados, circuito isolado primeiro, primeiro ciclo estável. Ignora datas e números administrativos.",
		4: "INCUBAÇÃO: três ciclos foram rejeitados antes da primeira leitura estável. Conta apenas os ciclos rejeitados.",
		7: "DIÁRIO DE ALARMES: sete alertas foram confirmados. Exclui todos os registos marcados TESTE.",
		9: "MANUTENÇÃO/ATIVAÇÃO: o circuito 1 foi isolado primeiro; a primeira leitura estável ocorreu no ciclo 4."
	}
	var found := experiment_clues_found.size()
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		var clue_message := "PROVA %02d/10: %s — fragmento registado." % [found, clue_names[clue_id]]
		if combination_fragments.has(clue_id):
			clue_message += " " + combination_fragments[clue_id]
		prompt.text = clue_message
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: %02d / 10" % found
	if found == 3 and prompt:
		prompt.text = "PISTA DE LOCALIZAÇÃO: o relatório de manutenção menciona uma parede falsa a oeste da Zona 10."
	elif found == 6 and prompt:
		prompt.text = "PISTA DE LOCALIZAÇÃO: o relatório de contenção refere uma consola escondida junto à passagem selada, atrás da parede oeste da Zona 10."
	elif found == 10:
		_reveal_secret_access()
		if prompt:
			prompt.text = "LOCALIZAÇÃO DESCOBERTA: a parede falsa a oeste da Zona 10 revelou a porta e a consola VANTHIS. Usa as pistas para obter o código."

func _reveal_secret_access() -> void:
	# Só o anfitrião/servidor altera o estado partilhado.
	if not multiplayer.is_server():
		return
	if secret_synthesis_console:
		secret_synthesis_console.visible = true
		for child in secret_synthesis_console.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	rpc("client_reveal_secret_console")

@rpc("authority", "call_remote", "reliable")
func client_reveal_secret_console() -> void:
	if secret_synthesis_console:
		secret_synthesis_console.visible = true
		for child in secret_synthesis_console.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: 10 / 10 · CONSOLA REVELADA"

func _unlock_secret_door() -> void:
	# Só a combinação correta revela e ativa a porta oculta.
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = true
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)

func interact_evidence_synthesis_console(_player: Node = null) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 10:
		if prompt:
			prompt.text = "CONSOLA BLOQUEADA — reúne as 10 provas e procura os quatro algarismos escondidos nos documentos."
		_play_sfx("radio_static.wav")
		return
	if secret_combination_panel:
		secret_combination_panel.visible = true
		if secret_combination_input:
			secret_combination_input.clear()
			secret_combination_input.grab_focus()
	if prompt:
		prompt.text = "FECHADURA VANTHIS — introduz a combinação deduzida a partir das provas."
	if not multiplayer.is_server():
		return

func _submit_secret_combination() -> void:
	if not secret_combination_input:
		return
	var entered_code := secret_combination_input.text.strip_edges()
	if not entered_code.is_valid_int() or entered_code.length() != 4:
		var prompt := get_node_or_null("HUD/Prompt") as Label
		if prompt:
			prompt.text = "CÓDIGO INVÁLIDO — são necessários quatro algarismos."
		return
	if multiplayer.is_server():
		_server_validate_secret_combination(entered_code)
	else:
		rpc_id(1, "server_validate_secret_combination", entered_code)

@rpc("any_peer", "call_remote", "reliable")
func server_validate_secret_combination(entered_code: String) -> void:
	if multiplayer.is_server():
		_server_validate_secret_combination(entered_code)

func _server_validate_secret_combination(entered_code: String) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 10:
		if prompt:
			prompt.text = "ACESSO NEGADO — faltam provas para descobrir a combinação."
		return
	if entered_code != SECRET_COMBINATION:
		if prompt:
			prompt.text = "COMBINAÇÃO INCORRETA — cruza a cronologia dos registos e exclui alarmes de teste e números administrativos."
		_play_sfx("radio_static.wav")
		rpc("client_secret_combination_result", false)
		return
	evidence_synthesis_complete = true
	_unlock_secret_door()
	evidence_journal = [
		"CHAVE DE LEITURA: extrai quatro valores, nesta ordem: alertas confirmados; ciclos rejeitados; circuito isolado primeiro; primeiro ciclo estável.",
		"ALARMES: sete alertas são confirmados. Exclui todos os registos identificados como TESTE.",
		"INCUBAÇÃO: três ciclos foram rejeitados antes da primeira leitura estável.",
		"MANUTENÇÃO: o circuito 1 foi isolado primeiro.",
		"VALIDAÇÃO: a primeira leitura estável ocorreu no ciclo 4.",
		"Conclusão: usa os quatro valores na ordem da chave de leitura. Não uses datas, números de turno ou identificadores administrativos."
	]
	if prompt:
		prompt.text = "COMBINAÇÃO CORRETA. A fechadura VANTHIS foi desbloqueada. Interage com a porta secreta."
	if secret_clue_status:
		secret_clue_status.text = "PROVAS: 10/10 · COMBINAÇÃO VALIDADA"
	if secret_combination_panel:
		secret_combination_panel.visible = false
	_play_sfx("door_open.wav")
	rpc("client_sync_evidence_synthesis")
	rpc("client_secret_combination_result", true)
	rpc("client_unlock_secret_door")

@rpc("authority", "call_remote", "reliable")
func client_secret_combination_result(correct: bool) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if correct:
		if prompt:
			prompt.text = "COMBINAÇÃO CORRETA — fechadura desbloqueada. Interage com a porta secreta."
		if secret_combination_panel:
			secret_combination_panel.visible = false
		_unlock_secret_door()
	else:
		if prompt:
			prompt.text = "COMBINAÇÃO INCORRETA — verifica a ordem dos eventos e distingue registos válidos de testes."

@rpc("authority", "call_remote", "reliable")
func client_unlock_secret_door() -> void:
	_unlock_secret_door()

@rpc("authority", "call_remote", "reliable")
func client_sync_evidence_synthesis() -> void:
	evidence_synthesis_complete = true
	evidence_journal = [
		"CHAVE DE LEITURA: extrai quatro valores, nesta ordem: alertas confirmados; ciclos rejeitados; circuito isolado primeiro; primeiro ciclo estável.",
		"ALARMES: sete alertas são confirmados. Exclui todos os registos identificados como TESTE.",
		"INCUBAÇÃO: três ciclos foram rejeitados antes da primeira leitura estável.",
		"MANUTENÇÃO: o circuito 1 foi isolado primeiro.",
		"VALIDAÇÃO: a primeira leitura estável ocorreu no ciclo 4.",
		"Conclusão: usa os quatro valores na ordem da chave de leitura. Não uses datas, números de turno ou identificadores administrativos."
	]
	if secret_clue_status:
		secret_clue_status.text = "PROVAS: 10/10 · SÍNTESE VANTHIS CONCLUÍDA"

func interact_secret_experiment_door(_player: Node = null) -> void:
	if not multiplayer.is_server():
		rpc_id(1, "server_try_open_secret_door")
		return
	_server_try_open_secret_door()

@rpc("any_peer", "call_remote", "reliable")
func server_try_open_secret_door() -> void:
	if multiplayer.is_server():
		_server_try_open_secret_door()

func _server_try_open_secret_door() -> void:
	if secret_experiment_open:
		return
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 10:
		var missing := 10 - experiment_clues_found.size()
		if prompt:
			prompt.text = "ACESSO NEGADO — faltam %d provas da experiência (%d/10)." % [missing, experiment_clues_found.size()]
		_play_sfx("radio_static.wav")
		return
	if not evidence_synthesis_complete:
		if prompt:
			prompt.text = "ACESSO NEGADO — tens de descobrir e introduzir a combinação correta na consola VANTHIS."
		_play_sfx("radio_static.wav")
		return
	# A sequência completa das dez provas é validada antes de libertar a porta.
	for clue_id in range(1, 11):
		if not experiment_clues_found.has(clue_id):
			if prompt:
				prompt.text = "SEQUÊNCIA INCOMPLETA — falta o fragmento %02d." % clue_id
			return
	secret_experiment_open = true
	rpc("client_open_secret_door")
	if secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if prompt:
		prompt.text = "ACESSO CONCEDIDO — ARQUIVO VANTHIS: EXPERIÊNCIA ORIGINAL. A porta foi desbloqueada."
	_play_sfx("door_open.wav")

@rpc("authority", "call_remote", "reliable")
func client_open_secret_door() -> void:
	secret_experiment_open = true
	if secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)

func _build_secret_experiment_area() -> void:
	# A câmara fica para lá da parede esquerda da Zona 10, fora da rota normal.
	var chamber := Node3D.new()
	chamber.name = "SecretOriginalExperimentChamber"
	add_child(chamber)
	var concrete := _material(Color(0.10, 0.12, 0.14), 0.45, 0.5)
	var floor_mat := _material(Color(0.035, 0.045, 0.052), 0.3, 0.25)
	var glass := _material(Color(0.10, 0.32, 0.38, 0.42), 0.15, 0.2)
	# Zona 10 está centrada em z=-182.2. A entrada abre na parede x=-6.
	var center_z := -182.2
	_box(chamber, "SecretFloor", Vector3(14.0, 0.25, 10.0), Vector3(-13.0, -0.16, center_z), floor_mat)
	_box(chamber, "SecretCeiling", Vector3(14.0, 0.25, 10.0), Vector3(-13.0, 3.6, center_z), concrete)
	_box(chamber, "SecretOuterWall", Vector3(0.25, 3.6, 10.0), Vector3(-20.0, 1.65, center_z), concrete)
	_box(chamber, "SecretFrontWall", Vector3(14.0, 3.6, 0.25), Vector3(-13.0, 1.65, center_z + 5.0), concrete)
	_box(chamber, "SecretBackWall", Vector3(14.0, 3.6, 0.25), Vector3(-13.0, 1.65, center_z - 5.0), concrete)
	# Corredor entre a porta e a câmara, com paredes e chão próprios.
	_box(chamber, "SecretAccessFloor", Vector3(3.0, 0.18, 4.0), Vector3(-7.5, -0.16, center_z), floor_mat)
	_box(chamber, "SecretAccessWallFront", Vector3(4.0, 3.2, 0.18), Vector3(-8.0, 1.45, center_z + 1.5), concrete)
	_box(chamber, "SecretAccessWallBack", Vector3(4.0, 3.2, 0.18), Vector3(-8.0, 1.45, center_z - 1.5), concrete)
	# Consola de síntese fica no corredor exterior: os jogadores têm de montar as provas antes de abrir a porta.
	secret_synthesis_console = StaticBody3D.new()
	secret_synthesis_console.name = "EvidenceSynthesisConsole"
	secret_synthesis_console.set_script(load("res://scripts/evidence_synthesis_console.gd"))
	secret_synthesis_console.position = Vector3(-4.7, 0.65, center_z)
	var console_mesh := MeshInstance3D.new()
	var console_box := BoxMesh.new()
	console_box.size = Vector3(0.75, 1.2, 0.65)
	console_mesh.mesh = console_box
	console_mesh.material_override = _material(Color(0.08, 0.34, 0.37), 0.35, 0.4)
	secret_synthesis_console.add_child(console_mesh)
	var console_shape_node := CollisionShape3D.new()
	var console_shape := BoxShape3D.new()
	console_shape.size = Vector3(1.2, 1.8, 1.2)
	console_shape_node.shape = console_shape
	secret_synthesis_console.add_child(console_shape_node)
	var console_label := Label3D.new()
	console_label.text = "SÍNTESE DE PROVAS"
	console_label.position = Vector3(0, 1.0, -0.36)
	console_label.font_size = 18
	console_label.modulate = Color(0.3, 0.9, 0.88)
	secret_synthesis_console.add_child(console_label)
	chamber.add_child(secret_synthesis_console)

	secret_synthesis_console.visible = false
	for child in secret_synthesis_console.get_children():
		if child is CollisionShape3D:
			child.disabled = true

	secret_experiment_door = StaticBody3D.new()
	secret_experiment_door.name = "SecretExperimentDoor"
	secret_experiment_door.set_script(load("res://scripts/secret_experiment_door.gd"))
	secret_experiment_door.position = Vector3(-6.0, 1.4, center_z)
	var door_mesh := MeshInstance3D.new()
	var door_box := BoxMesh.new()
	door_box.size = Vector3(0.22, 2.8, 3.0)
	door_mesh.mesh = door_box
	door_mesh.material_override = _material(Color(0.16, 0.08, 0.07), 0.4, 0.8)
	secret_experiment_door.add_child(door_mesh)
	var door_shape_node := CollisionShape3D.new()
	var door_shape := BoxShape3D.new()
	door_shape.size = Vector3(0.25, 2.8, 3.0)
	door_shape_node.shape = door_shape
	secret_experiment_door.add_child(door_shape_node)
	var door_label := Label3D.new()
	door_label.text = "VANTHIS // ACESSO SELADO"
	door_label.position = Vector3(0.18, 0.35, 0)
	door_label.rotation.y = deg_to_rad(90)
	door_label.font_size = 22
	door_label.modulate = Color(0.9, 0.24, 0.15)
	secret_experiment_door.add_child(door_label)
	chamber.add_child(secret_experiment_door)
	# Porta bloqueada por defeito; só é revelada após validação da combinação.
	secret_experiment_door.visible = false
	for child in secret_experiment_door.get_children():
		if child is CollisionShape3D:
			child.disabled = true
	# A cápsula de contenção central sugere a experiência sem revelar a criatura no exterior.
	_box(chamber, "ExperimentPlatform", Vector3(3.2, 0.3, 2.2), Vector3(-13.0, 0.15, center_z), concrete)
	_box(chamber, "OriginalContainmentGlass", Vector3(2.5, 2.4, 0.12), Vector3(-13.0, 1.45, center_z), glass, false)
	_box(chamber, "ExperimentConsole", Vector3(1.5, 1.1, 0.6), Vector3(-16.0, 0.55, center_z + 2.7), _material(Color(0.12, 0.30, 0.34)))
	var title := Label3D.new()
	title.text = "VANTHIS — ARQUIVO DA EXPERIÊNCIA ORIGINAL"
	title.position = Vector3(-13.0, 3.0, center_z + 4.3)
	title.font_size = 24
	title.modulate = Color(0.4, 0.86, 0.88)
	chamber.add_child(title)
	var evidence := Label3D.new()
	evidence.text = "SUJEITO: CLASSIFICAÇÃO OMITIDA\nPROTOCOLO: AUTORIZAÇÃO FRAUDULENTA\nESTADO: CONTENÇÃO COMPROMETIDA\nREGISTO FINAL: NÃO ABRIR NOVAMENTE"
	evidence.position = Vector3(-16.0, 1.65, center_z + 2.35)
	evidence.font_size = 18
	evidence.modulate = Color(0.86, 0.82, 0.72)
	evidence.rotation.y = deg_to_rad(18)
	chamber.add_child(evidence)
	secret_clue_status = Label.new()
	secret_clue_status.name = "SecretClueStatus"
	secret_clue_status.text = "PROVAS REUNIDAS: 00 / 10"
	secret_clue_status.position = Vector2(18, 68)
	secret_clue_status.add_theme_font_size_override("font_size", 14)
	secret_clue_status.add_theme_color_override("font_color", Color(0.2, 0.78, 0.84))
	# HUD é criado depois; a etiqueta é adicionada quando o HUD existir.
	call_deferred("_attach_secret_clue_status")

func _attach_secret_clue_status() -> void:
	var hud := get_node_or_null("HUD")
	if hud and secret_clue_status and not secret_clue_status.is_inside_tree():
		hud.add_child(secret_clue_status)

func _build_initial_zone_wings() -> void:
	# Zonas 01 e 02 também recebem duas salas anexas, para manter a mesma escala.
	_build_zone_side_rooms(self, 1, -8.0, Color(0.18, 0.28, 0.34))
	_build_zone_side_rooms(self, 2, -23.45, Color(0.20, 0.32, 0.38))
	_add_experiment_clue(self, 1, Vector3(4.15, 0.65, -6.75))
	_add_experiment_clue(self, 2, Vector3(4.15, 0.65, -22.2))

func _build_zone_side_rooms(parent: Node3D, zone_number: int, center_z: float, tint: Color) -> void:
	# Salas laterais distintas por zona: cada zona tem dois espaços auxiliares
	# com finalidade, mobiliário, sinalética e iluminação próprios.
	var concrete := _material(Color(0.12, 0.14, 0.16))
	var floor_material := _material(Color(0.038, 0.046, 0.052), 0.28, 0.22)
	var trim := _material(tint, 0.5, 0.3)
	var room_catalog := [
		[["VESTIÁRIO POLAR", "ARMÁRIO TÉRMICO"], ["POSTO DE TRIAGEM", "MACA DE EMERGÊNCIA"]],
		[["CÂMARA DE AMOSTRAS", "ARMÁRIO CRIOGÉNICO"], ["SALA DE ANÁLISE", "MESA DE MICROSCÓPIO"]],
		[["OFICINA DE FERRAMENTAS", "BANCADA DE REPARAÇÃO"], ["ARMAZÉM DE PEÇAS", "PRATELEIRAS METÁLICAS"]],
		[["PREPARAÇÃO DE AMOSTRAS", "MESA DE LABORATÓRIO"], ["ANÁLISE QUÍMICA", "ARMÁRIO DE REAGENTES"]],
		[["CONTROLO DE GERADORES", "PAINEL ELÉTRICO"], ["BANCO DE BATERIAS", "RACK DE ACUMULADORES"]],
		[["SALA DE OBSERVAÇÃO", "VIDRO DE CONTENÇÃO"], ["ANTECÂMARA", "PORTA DE PRESSURIZAÇÃO"]],
		[["ARQUIVO FÍSICO", "ESTANTES DE DOSSIÊS"], ["SALA DE REGISTOS", "TERMINAL DE DADOS"]],
		[["MONITORIZAÇÃO", "CONSOLES DE VIGILÂNCIA"], ["EQUIPAMENTO DE EMERGÊNCIA", "ARMÁRIO DE PROTEÇÃO"]],
		[["OBSERVAÇÃO DA ENTIDADE", "JANELA REFORÇADA"], ["CONTROLO DO NÚCLEO", "CONSOLA DE CONTROLO"]],
		[["PREPARAÇÃO DE EVACUAÇÃO", "MAPA DE EXTRAÇÃO"], ["ARMAZENAMENTO DE EMERGÊNCIA", "CONTENTORES DE SOBREVIVÊNCIA"]]
	]
	var wing := Node3D.new()
	wing.name = "Zone%02dSideRooms" % zone_number
	parent.add_child(wing)
	var zone_rooms: Array = room_catalog[clampi(zone_number - 1, 0, room_catalog.size() - 1)]
	for room_index in range(2):
		var room_center_z := center_z + (3.125 if room_index == 0 else -3.125)
		var room_title: String = zone_rooms[room_index][0]
		var prop_title: String = zone_rooms[room_index][1]
		var room := Node3D.new()
		room.name = "Zone%02d_%s" % [zone_number, "AuxA" if room_index == 0 else "AuxB"]
		wing.add_child(room)
		_box(room, "Floor", Vector3(6.0, 0.3, 6.25), Vector3(9.0, -0.16, room_center_z), floor_material)
		_box(room, "Ceiling", Vector3(6.0, 0.25, 6.25), Vector3(9.0, 3.6, room_center_z), concrete)
		_box(room, "OuterWall", Vector3(0.3, 3.6, 6.25), Vector3(12.0, 1.65, room_center_z), concrete)
		_box(room, "NorthWall", Vector3(6.0, 3.6, 0.3), Vector3(9.0, 1.65, center_z + 6.25), concrete)
		_box(room, "SouthWall", Vector3(6.0, 3.6, 0.3), Vector3(9.0, 1.65, center_z - 6.25), concrete)
		_box(room, "InnerWallFront", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, room_center_z + 2.35), concrete)
		_box(room, "InnerWallBack", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, room_center_z - 2.35), concrete)
		_box(room, "InnerWallLintel", Vector3(0.3, 0.55, 1.6), Vector3(6.0, 3.30, room_center_z), concrete)
		# Elemento visual funcional por tipo: a geometria distingue as salas sem
		# alterar os corredores nem substituir os sistemas do jogo.
		if zone_number == 1 and room_index == 0:
			_box(room, "ThermalLocker", Vector3(1.0, 1.7, 0.65), Vector3(10.7, 0.85, room_center_z - 1.0), trim)
			_box(room, "Bench", Vector3(1.6, 0.5, 0.55), Vector3(10.6, 0.25, room_center_z + 1.0), concrete)
		elif zone_number == 1 and room_index == 1:
			_box(room, "EmergencyCot", Vector3(2.0, 0.28, 0.8), Vector3(10.2, 0.75, room_center_z), trim)
		elif zone_number in [2, 4, 6, 9] and room_index == 0:
			_box(room, "SampleCabinet", Vector3(1.1, 1.8, 0.6), Vector3(10.7, 0.9, room_center_z - 1.1), trim)
			_box(room, "ObservationPanel", Vector3(0.12, 1.1, 1.5), Vector3(11.1, 1.8, room_center_z + 1.0), concrete)
		elif zone_number in [2, 4] and room_index == 1:
			_box(room, "LabBench", Vector3(1.8, 0.85, 0.7), Vector3(10.5, 0.425, room_center_z), trim)
			_box(room, "Instrument", Vector3(0.5, 0.45, 0.45), Vector3(10.4, 1.08, room_center_z), concrete)
		elif zone_number == 3:
			_box(room, "WorkshopBench", Vector3(2.0, 0.8, 0.75), Vector3(10.4, 0.4, room_center_z), trim)
			if room_index == 1:
				for shelf_index in range(3):
					_box(room, "PartsShelf%d" % shelf_index, Vector3(0.4, 1.5, 0.45), Vector3(11.2, 0.75, room_center_z - 1.4 + shelf_index * 1.2), concrete)
		elif zone_number == 5:
			_box(room, "ElectricalCabinet", Vector3(0.75, 2.0, 1.5), Vector3(11.0, 1.0, room_center_z), trim)
			if room_index == 1:
				for battery_index in range(3):
					_box(room, "BatteryUnit%d" % battery_index, Vector3(0.45, 0.9, 0.55), Vector3(9.0 + battery_index * 0.9, 0.45, room_center_z + 1.5), concrete)
		elif zone_number == 7:
			for shelf_index in range(3):
				_box(room, "ArchiveShelf%d" % shelf_index, Vector3(0.5, 2.0, 1.6), Vector3(10.9, 1.0, room_center_z - 1.6 + shelf_index * 1.6), trim)
		elif zone_number == 8:
			_box(room, "SecurityConsole", Vector3(1.7, 0.8, 0.7), Vector3(10.3, 0.4, room_center_z), trim)
			if room_index == 0:
				_box(room, "Monitor", Vector3(0.12, 0.7, 1.2), Vector3(11.0, 1.2, room_center_z), concrete)
		elif zone_number == 10:
			_box(room, "EvacuationCrate", Vector3(0.9, 0.9, 0.9), Vector3(10.5, 0.45, room_center_z - 1.1), trim)
			_box(room, "SupplyCrate", Vector3(0.9, 0.9, 0.9), Vector3(10.5, 0.45, room_center_z + 1.1), concrete)
		var label := Label3D.new()
		label.name = "RoomSign"
		label.text = "ZONA %02d · %s\n%s" % [zone_number, room_title, prop_title]
		label.position = Vector3(9.0, 2.55, room_center_z + 2.6)
		label.font_size = 11
		label.modulate = tint.lightened(0.55)
		room.add_child(label)
		var lamp := OmniLight3D.new()
		lamp.name = "RoomLamp"
		lamp.position = Vector3(9.0, 2.9, room_center_z)
		lamp.light_color = tint.lightened(0.18)
		lamp.light_energy = 0.45 if zone_number in [6, 9] else 0.65
		lamp.omni_range = 6.5
		lamp.shadow_enabled = false
		room.add_child(lamp)

func _build_door() -> void:
	var door := StaticBody3D.new()
	door.name = "InteractiveBulkhead"
	door.set_script(INTERACTABLE_SCRIPT)
	door.position = Vector3(0, 1.4, -9.35)
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "DoorMesh"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(2.2, 2.8, 0.22)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(Color(0.13, 0.16, 0.18), 0.42, 0.7)
	door.add_child(mesh_node)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.2, 2.8, 0.22)
	shape_node.shape = shape
	door.add_child(shape_node)
	var label := Label3D.new()
	label.text = "CÂMARA DE CONTENÇÃO  /  01"
	label.position = Vector3(0, 1.72, -0.13)
	label.font_size = 32
	label.modulate = Color(0.82, 0.72, 0.52)
	door.add_child(label)
	add_child(door)

func _build_coop_switches() -> void:
	# Two separated stations: each must be activated by a different network peer.
	_create_switch("A", Vector3(-4.1, 0.0, -2.1), "RELÉ A  /  LEITURA")
	_create_switch("B", Vector3(4.1, 0.0, -6.0), "RELÉ B  /  CONFIRMAÇÃO")

func _create_switch(switch_id: String, pos: Vector3, caption: String) -> void:
	var station := StaticBody3D.new()
	station.name = "CoopSwitch" + switch_id
	station.set_script(COOP_SWITCH_SCRIPT)
	station.switch_id = switch_id
	station.position = pos
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "SwitchMesh"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(0.85, 1.0, 0.38)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(Color(0.24, 0.28, 0.30), 0.38, 0.55)
	station.add_child(mesh_node)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.95, 1.1, 0.5)
	shape_node.shape = shape
	station.add_child(shape_node)
	var label := Label3D.new()
	label.text = caption
	label.position = Vector3(0, 0.72, 0)
	label.font_size = 30
	label.modulate = Color(0.78, 0.84, 0.88)
	station.add_child(label)
	add_child(station)

func _human_part(parent: Node3D, part_name: String, mesh: PrimitiveMesh, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var part := MeshInstance3D.new()
	part.name = part_name
	part.mesh = mesh
	part.position = pos
	part.rotation = rot
	part.material_override = mat
	parent.add_child(part)
	return part

func _add_human_model(parent: Node3D, uniform_color: Color, include_head := true, include_camera_pivot := false) -> void:
	# Lightweight, fully procedural human silhouette: no external model downloads.
	# Equipamento polar visível: parka acolchoada, capuz, óculos, luvas e botas isolantes.
	var uniform := _material(uniform_color, 0.82, 0.02)
	var dark_fabric := _material(Color(0.055, 0.075, 0.085), 0.92)
	var insulation := _material(Color(0.16, 0.22, 0.27), 0.96)
	var trim := _material(Color(0.78, 0.84, 0.87), 0.62, 0.05)
	var lens := _material(Color(0.06, 0.25, 0.34), 0.28, 0.42)
	var skin := _material(Color(0.56, 0.37, 0.27), 0.9)
	var hair := _material(Color(0.035, 0.027, 0.025), 0.96)
	var boot_mesh := BoxMesh.new()
	boot_mesh.size = Vector3(0.24, 0.18, 0.36)
	for side in [-1.0, 1.0]:
		var leg := CapsuleMesh.new()
		leg.radius = 0.115
		leg.height = 0.62
		_human_part(parent, "Leg_%s" % str(side), leg, Vector3(side * 0.14, -0.42, 0.0), dark_fabric)
		_human_part(parent, "PolarBoot_%s" % str(side), boot_mesh, Vector3(side * 0.14, -0.76, -0.055), insulation)
		var gaiter := CylinderMesh.new()
		gaiter.top_radius = 0.105
		gaiter.bottom_radius = 0.12
		gaiter.height = 0.20
		_human_part(parent, "BootGaiter_%s" % str(side), gaiter, Vector3(side * 0.14, -0.60, 0.0), trim)
	var torso := CapsuleMesh.new()
	torso.radius = 0.255
	torso.height = 0.70
	_human_part(parent, "InsulatedPolarParka", torso, Vector3(0, 0.02, 0), uniform)
	var hood := SphereMesh.new()
	hood.radius = 0.205
	hood.height = 0.30
	_human_part(parent, "ParkaHood", hood, Vector3(0, 0.39, 0.035), insulation)
	var zipper := BoxMesh.new()
	zipper.size = Vector3(0.018, 0.40, 0.018)
	_human_part(parent, "ParkaFrontZipper", zipper, Vector3(0, 0.03, -0.253), trim)
	var chest_panel := BoxMesh.new()
	chest_panel.size = Vector3(0.12, 0.09, 0.025)
	_human_part(parent, "ExpeditionIDPanel", chest_panel, Vector3(0.105, 0.16, -0.251), insulation)
	var vest := BoxMesh.new()
	vest.size = Vector3(0.34, 0.31, 0.045)
	_human_part(parent, "ExpeditionVest", vest, Vector3(0, 0.05, -0.245), _material(Color(0.72, 0.24, 0.10), 0.7))
	var stripe := BoxMesh.new()
	stripe.size = Vector3(0.29, 0.035, 0.012)
	_human_part(parent, "ReflectiveVestStripe", stripe, Vector3(0, 0.075, -0.274), _material(Color(0.88, 0.78, 0.42), 0.48, 0.08))
	for side in [-1.0, 1.0]:
		var arm := CapsuleMesh.new()
		arm.radius = 0.085
		arm.height = 0.62
		_human_part(parent, "Arm_%s" % str(side), arm, Vector3(side * 0.31, 0.0, -0.01), uniform, Vector3(0, 0, side * -0.12))
		var hand := SphereMesh.new()
		hand.radius = 0.082
		hand.height = 0.16
		_human_part(parent, "InsulatedGlove_%s" % str(side), hand, Vector3(side * 0.34, -0.30, -0.025), insulation)
	var pack := BoxMesh.new()
	pack.size = Vector3(0.32, 0.43, 0.17)
	_human_part(parent, "PolarSurvivalPack", pack, Vector3(0, 0.10, 0.22), dark_fabric)
	var pack_flap := BoxMesh.new()
	pack_flap.size = Vector3(0.25, 0.10, 0.035)
	_human_part(parent, "PackFlap", pack_flap, Vector3(0, 0.28, 0.315), insulation)
	var radio := BoxMesh.new()
	radio.size = Vector3(0.07, 0.13, 0.045)
	_human_part(parent, "EmergencyRadio", radio, Vector3(0.205, 0.10, 0.015), dark_fabric)
	if include_head:
		var neck := CylinderMesh.new()
		neck.top_radius = 0.075
		neck.bottom_radius = 0.085
		neck.height = 0.13
		_human_part(parent, "Neck", neck, Vector3(0, 0.40, 0), skin)
		var head := SphereMesh.new()
		head.radius = 0.145
		head.height = 0.34
		_human_part(parent, "HumanHead", head, Vector3(0, 0.59, -0.005), skin)
		# Balaclava/cap silhouette and polar goggles are always part of the outfit.
		var balaclava := SphereMesh.new()
		balaclava.radius = 0.151
		balaclava.height = 0.24
		_human_part(parent, "PolarBalaclava", balaclava, Vector3(0, 0.61, 0.0), insulation)
		var goggles := BoxMesh.new()
		goggles.size = Vector3(0.23, 0.065, 0.035)
		_human_part(parent, "SnowGoggles", goggles, Vector3(0, 0.625, -0.132), lens)
		var hair_cap := SphereMesh.new()
		hair_cap.radius = 0.15
		hair_cap.height = 0.16
		_human_part(parent, "Hair", hair_cap, Vector3(0, 0.69, 0.0), hair)
		for side in [-1.0, 1.0]:
			var eye := SphereMesh.new()
			eye.radius = 0.014
			eye.height = 0.025
			_human_part(parent, "Eye_%s" % str(side), eye, Vector3(side * 0.05, 0.60, -0.139), dark_fabric)

func _build_player() -> void:
	var player := CharacterBody3D.new()
	player.name = "Player"
	# Use exactly one capsule collider. Duplicate overlapping colliders can cause
	# unstable CharacterBody3D movement, especially through a narrow doorway.
	var collider := CollisionShape3D.new()
	collider.name = "CollisionShape3D"
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.75
	collider.shape = capsule
	player.add_child(collider)
	player.set_script(PLAYER_SCRIPT)
	player.position = Vector3(0, 0.95, 4.2)
	var camera_pivot := Node3D.new()
	camera_pivot.name = "CameraPivot"
	camera_pivot.position = Vector3(0, 0.55, 0)
	player.add_child(camera_pivot)
	var camera := Camera3D.new()
	camera.name = "Camera3D"
	camera.current = true
	camera.fov = 82
	camera_pivot.add_child(camera)
	var ray := RayCast3D.new()
	ray.name = "InteractionRay"
	ray.target_position = Vector3(0, 0, -2.8)
	ray.collide_with_areas = true
	ray.collide_with_bodies = true
	camera.add_child(ray)
	var flashlight := SpotLight3D.new()
	flashlight.name = "Flashlight"
	flashlight.position = Vector3(0.12, -0.08, -0.15)
	flashlight.rotation_degrees = Vector3(-3, 0, 0)
	flashlight.light_energy = 3.1
	flashlight.spot_range = 17
	flashlight.spot_angle = 34
	flashlight.shadow_enabled = true
	camera.add_child(flashlight)
	_add_human_model(player, Color(0.24, 0.42, 0.48), false, false)
	add_child(player)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUD"
	add_child(layer)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(center)
	var reticle := Label.new()
	reticle.text = "+"
	reticle.add_theme_font_size_override("font_size", 24)
	reticle.add_theme_color_override("font_color", Color(0.82, 0.88, 0.9, 0.85))
	center.add_child(reticle)
	var prompt := Label.new()
	prompt.name = "Prompt"
	prompt.text = "MOVER: joystick · OLHAR: arrasta à direita · INTERAGIR / LANTERNA / AGACHAR: botões"
	prompt.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	prompt.anchor_left = 0.06
	prompt.anchor_right = 0.94
	prompt.offset_top = -54
	prompt.offset_bottom = -14
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	prompt.add_theme_font_size_override("font_size", 14)
	prompt.add_theme_color_override("font_color", Color(0.78, 0.82, 0.84))
	layer.add_child(prompt)
	# Painel de combinação da porta secreta — aberto apenas ao interagir com a consola.
	secret_combination_panel = PanelContainer.new()
	secret_combination_panel.name = "SecretCombinationPanel"
	secret_combination_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	secret_combination_panel.offset_left = -190
	secret_combination_panel.offset_top = -120
	secret_combination_panel.offset_right = 190
	secret_combination_panel.offset_bottom = 120
	secret_combination_panel.visible = false
	var combo_box := VBoxContainer.new()
	combo_box.add_theme_constant_override("separation", 10)
	secret_combination_panel.add_child(combo_box)
	var combo_title := Label.new()
	combo_title.text = "FECHADURA VANTHIS"
	combo_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_title.add_theme_font_size_override("font_size", 20)
	combo_box.add_child(combo_title)
	var combo_hint := Label.new()
	combo_hint.text = "Cruza os registos de turno, os ciclos válidos, os avisos confirmados e a ordem real dos procedimentos. Nenhum documento contém o código completo."
	combo_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	combo_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_box.add_child(combo_hint)
	secret_combination_input = LineEdit.new()
	secret_combination_input.name = "SecretCombinationInput"
	secret_combination_input.placeholder_text = "Código de 4 algarismos"
	secret_combination_input.max_length = 4
	secret_combination_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	secret_combination_input.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	combo_box.add_child(secret_combination_input)
	var combo_buttons := HBoxContainer.new()
	combo_buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	combo_box.add_child(combo_buttons)
	var combo_submit := Button.new()
	combo_submit.text = "VALIDAR CÓDIGO"
	combo_submit.custom_minimum_size = Vector2(150, 44)
	combo_submit.pressed.connect(_submit_secret_combination)
	combo_buttons.add_child(combo_submit)
	var combo_cancel := Button.new()
	combo_cancel.text = "FECHAR"
	combo_cancel.custom_minimum_size = Vector2(90, 44)
	combo_cancel.pressed.connect(func(): secret_combination_panel.visible = false)
	combo_buttons.add_child(combo_cancel)
	layer.add_child(secret_combination_panel)
	var title := Label.new()
	title.text = "EXPEDIÇÃO 01  /  ESTAÇÃO VÉSPERA"
	title.position = Vector2(18, 14)
	title.add_theme_font_size_override("font_size", 15)
	title.add_theme_color_override("font_color", Color(0.73, 0.78, 0.81))
	layer.add_child(title)
	stealth_status = Label.new()
	stealth_status.name = "StealthStatus"
	stealth_status.position = Vector2(18, 32)
	stealth_status.add_theme_font_size_override("font_size", 14)
	stealth_status.add_theme_color_override("font_color", Color(0.65, 0.82, 0.76))
	layer.add_child(stealth_status)
	private_clue = Label.new()
	private_clue.name = "PrivateClue"
	private_clue.position = Vector2(18, 52)
	private_clue.size = Vector2( minf(500.0, get_viewport().get_visible_rect().size.x * 0.48), 82)
	private_clue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	private_clue.add_theme_font_size_override("font_size", 17)
	private_clue.add_theme_color_override("font_color", Color(0.94, 0.78, 0.48))
	layer.add_child(private_clue)
	_update_private_clue()
	# Native Godot touch buttons for mobile. Buttons are deliberately large.
	var player := get_node_or_null("Player")
	if player:
		var action_box := VBoxContainer.new()
		action_box.name = "TouchActions"
		action_box.anchor_left = 1.0
		action_box.anchor_top = 1.0
		action_box.anchor_right = 1.0
		action_box.anchor_bottom = 1.0
		# Margens de segurança para ecrãs Android com proporções diferentes.
		action_box.offset_left = -174
		action_box.offset_top = -210
		action_box.offset_right = -18
		action_box.offset_bottom = -18
		action_box.add_theme_constant_override("separation", 12)
		layer.add_child(action_box)
		var interact_button := Button.new()
		interact_button.name = "InteractButton"
		interact_button.text = "INTERAGIR"
		interact_button.custom_minimum_size = Vector2(150, 52)
		interact_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		interact_button.add_theme_font_size_override("font_size", 16)
		interact_button.pressed.connect(Callable(player, "interact_now"))
		action_box.add_child(interact_button)
		var flashlight_button := Button.new()
		flashlight_button.name = "FlashlightButton"
		flashlight_button.text = "LANTERNA"
		flashlight_button.custom_minimum_size = Vector2(150, 48)
		flashlight_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		flashlight_button.add_theme_font_size_override("font_size", 15)
		flashlight_button.pressed.connect(Callable(player, "toggle_flashlight"))
		action_box.add_child(flashlight_button)
		var crouch_button := Button.new()
		crouch_button.name = "CrouchButton"
		# Texto curto para não ser cortado em ecrãs estreitos.
		crouch_button.text = "AGACHAR"
		crouch_button.tooltip_text = "Alternar entre agachado e de pé"
		crouch_button.custom_minimum_size = Vector2(150, 48)
		crouch_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		crouch_button.add_theme_font_size_override("font_size", 12)
		crouch_button.pressed.connect(Callable(player, "toggle_crouch"))
		action_box.add_child(crouch_button)
		# Guardar a referência real do botão já integrado na árvore.
		# O controlador consulta "crouch_button_ref" para atualizar AGACHAR/LEVANTAR.
		player.set_meta("crouch_button_ref", crouch_button)
	var decision_panel := PanelContainer.new()
	decision_panel.name = "ConfrontationPanel"
	decision_panel.position = Vector2(18, 138)
	decision_panel.custom_minimum_size = Vector2( minf(330.0, get_viewport().get_visible_rect().size.x * 0.46), 0)
	var decision_box := VBoxContainer.new()
	decision_box.add_theme_constant_override("separation", 8)
	decision_panel.add_child(decision_box)
	var decision_title := Label.new()
	decision_title.text = "CONFRONTO  /  OPERADOR 07"
	decision_title.add_theme_font_size_override("font_size", 16)
	decision_title.add_theme_color_override("font_color", Color(0.85, 0.78, 0.62))
	decision_box.add_child(decision_title)
	var decision_hint := Label.new()
	decision_hint.text = "Após partilharem as pistas, escolhe uma posição. A decisão conjunta altera a missão."
	decision_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_hint.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 44)
	decision_hint.add_theme_font_size_override("font_size", 14)
	decision_box.add_child(decision_hint)
	accusation_button = Button.new()
	accusation_button.text = "ACUSAR — ativar contenção"
	accusation_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	accusation_button.pressed.connect(submit_decision.bind("ACUSAR"))
	decision_box.add_child(accusation_button)
	defense_button = Button.new()
	defense_button.text = "DEFENDER — manter acesso"
	defense_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	defense_button.pressed.connect(submit_decision.bind("DEFENDER"))
	decision_box.add_child(defense_button)
	decision_status = Label.new()
	decision_status.text = "Decisão pendente: compara as pistas em voz alta."
	decision_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_status.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 30)
	decision_status.add_theme_font_size_override("font_size", 13)
	decision_status.add_theme_color_override("font_color", Color(0.72, 0.82, 0.86))
	decision_box.add_child(decision_status)
	entity_reaction_label = Label.new()
	entity_reaction_label.name = "EntityReaction"
	entity_reaction_label.text = "Sem presença confirmada."
	entity_reaction_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	entity_reaction_label.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 28)
	entity_reaction_label.add_theme_font_size_override("font_size", 13)
	entity_reaction_label.add_theme_color_override("font_color", Color(0.95, 0.3, 0.22))
	decision_box.add_child(entity_reaction_label)
	layer.add_child(decision_panel)
	# Joystick virtual visível, ao estilo dos jogos mobile (canto inferior esquerdo).
	var joystick := Control.new()
	joystick.name = "VirtualJoystick"
	joystick.set_script(load("res://scripts/virtual_joystick.gd"))
	joystick.anchor_left = 0.0
	joystick.anchor_top = 1.0
	joystick.anchor_right = 0.0
	joystick.anchor_bottom = 1.0
	joystick.offset_left = 22.0
	joystick.offset_top = -184.0
	joystick.offset_right = 178.0
	joystick.offset_bottom = -28.0
	joystick.z_index = 10
	layer.add_child(joystick)
	var player_for_joystick := get_node_or_null("Player")
	if player_for_joystick:
		joystick.value_changed.connect(Callable(player_for_joystick, "set_touch_move"))
	# LAN controls: host/join must be accessible in the actual HUD, not only in code.
	var network_panel := PanelContainer.new()
	network_panel.name = "NetworkPanel"
	network_panel.anchor_left = 1.0
	network_panel.anchor_right = 1.0
	network_panel.offset_left = -360
	network_panel.offset_top = 58
	network_panel.offset_right = -16
	network_panel.offset_bottom = 218
	network_panel.custom_minimum_size = Vector2(344, 160)
	network_panel.visible = false
	var network_box := VBoxContainer.new()
	network_box.add_theme_constant_override("separation", 5)
	network_panel.add_child(network_box)
	var network_title := Label.new()
	network_title.text = "COOPERAÇÃO LAN · UDP %d" % PORT
	network_title.add_theme_font_size_override("font_size", 14)
	network_box.add_child(network_title)
	ip_input = LineEdit.new()
	ip_input.name = "HostAddress"
	ip_input.placeholder_text = "IP do anfitrião (ex.: 192.168.1.35)"
	ip_input.text = ""
	ip_input.custom_minimum_size = Vector2(0, 36)
	network_box.add_child(ip_input)
	var network_buttons := HBoxContainer.new()
	var host_button := Button.new()
	host_button.text = "CRIAR SESSÃO"
	host_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	host_button.pressed.connect(host_game)
	network_buttons.add_child(host_button)
	var join_button := Button.new()
	join_button.text = "LIGAR À SESSÃO"
	join_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	join_button.pressed.connect(join_game)
	network_buttons.add_child(join_button)
	network_box.add_child(network_buttons)
	network_status = Label.new()
	network_status.name = "NetworkStatus"
	network_status.text = "Jogador 1: CRIAR SESSÃO. Jogador 2: introduz o IP do anfitrião e toca em LIGAR À SESSÃO. Mesma WLAN; internet não necessária."
	network_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	network_status.add_theme_font_size_override("font_size", 12)
	network_box.add_child(network_status)
	layer.add_child(network_panel)
	var network_toggle := Button.new()
	network_toggle.name = "NetworkToggle"
	network_toggle.text = "REDE LAN"
	network_toggle.anchor_left = 1.0
	network_toggle.anchor_right = 1.0
	network_toggle.offset_left = -124
	network_toggle.offset_top = 20
	network_toggle.offset_right = -16
	network_toggle.offset_bottom = 54
	network_toggle.pressed.connect(_toggle_network_panel.bind(network_panel))
	layer.add_child(network_toggle)
	# Mini-mapa gamer: apenas o perímetro da sala atual e a posição do jogador.
	var mini_map := Control.new()
	mini_map.name = "MiniMapaSala"
	mini_map.set_script(load("res://scripts/mini_map.gd"))
	mini_map.anchor_left = 1.0
	mini_map.anchor_right = 1.0
	mini_map.anchor_top = 0.0
	mini_map.anchor_bottom = 0.0
	mini_map.offset_left = -184.0
	mini_map.offset_top = 226.0
	mini_map.offset_right = -16.0
	mini_map.offset_bottom = 386.0
	mini_map.z_index = 5
	layer.add_child(mini_map)
	# HUB DE JOGO: objetivos, inventário, equipa, dossier, comunicação rápida e pausa.
	var hub_toggle := Button.new()
	hub_toggle.name = "MissionHubToggle"
	hub_toggle.text = "MISSÃO  /  EQUIPA"
	hub_toggle.anchor_left = 0.0
	hub_toggle.anchor_right = 0.0
	hub_toggle.anchor_top = 0.0
	hub_toggle.anchor_bottom = 0.0
	hub_toggle.offset_left = 18
	hub_toggle.offset_top = 82
	hub_toggle.offset_right = 190
	hub_toggle.offset_bottom = 122
	hub_toggle.pressed.connect(_toggle_mission_hub)
	layer.add_child(hub_toggle)
	var pause_button := Button.new()
	pause_button.name = "PauseButton"
	pause_button.text = "Ⅱ  PAUSA"
	pause_button.anchor_left = 1.0
	pause_button.anchor_right = 1.0
	pause_button.offset_left = -124
	pause_button.offset_top = 60
	pause_button.offset_right = -16
	pause_button.offset_bottom = 98
	pause_button.pressed.connect(_toggle_pause_menu)
	layer.add_child(pause_button)
	mission_hub = PanelContainer.new()
	mission_hub.name = "MissionHub"
	mission_hub.anchor_left = 0.5
	mission_hub.anchor_top = 0.5
	mission_hub.anchor_right = 0.5
	mission_hub.anchor_bottom = 0.5
	mission_hub.offset_left = -minf(330.0, get_viewport().get_visible_rect().size.x * 0.44)
	mission_hub.offset_top = -minf(260.0, get_viewport().get_visible_rect().size.y * 0.40)
	mission_hub.offset_right = minf(330.0, get_viewport().get_visible_rect().size.x * 0.44)
	mission_hub.offset_bottom = minf(260.0, get_viewport().get_visible_rect().size.y * 0.40)
	mission_hub.visible = false
	mission_hub.z_index = 40
	var hub_stack := VBoxContainer.new()
	hub_stack.add_theme_constant_override("separation", 8)
	mission_hub.add_child(hub_stack)
	mission_hub_title = Label.new()
	mission_hub_title.text = "CENTRO DE MISSÃO"
	mission_hub_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mission_hub_title.add_theme_font_size_override("font_size", 20)
	hub_stack.add_child(mission_hub_title)
	var tab_row := GridContainer.new()
	tab_row.columns = 2
	tab_row.add_theme_constant_override("h_separation", 6)
	tab_row.add_theme_constant_override("v_separation", 6)
	for tab_name in ["OBJETIVOS", "INVENTÁRIO", "EQUIPA", "DOSSIÊ"]:
		var tab_button := Button.new()
		tab_button.text = tab_name
		tab_button.custom_minimum_size = Vector2(130, 40)
		tab_button.pressed.connect(_set_mission_hub_tab.bind(tab_name))
		tab_row.add_child(tab_button)
	hub_stack.add_child(tab_row)
	mission_hub_body = Label.new()
	mission_hub_body.name = "MissionHubBody"
	mission_hub_body.custom_minimum_size = Vector2(0, 185)
	mission_hub_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mission_hub_body.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	mission_hub_body.add_theme_font_size_override("font_size", 15)
	hub_stack.add_child(mission_hub_body)
	quick_comms_status = Label.new()
	quick_comms_status.text = "Comunicação rápida disponível em sessão LAN."
	quick_comms_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	quick_comms_status.add_theme_font_size_override("font_size", 12)
	hub_stack.add_child(quick_comms_status)
	var comms_row := HBoxContainer.new()
	for comm in ["ESTOU AQUI", "PRECISO DE AJUDA", "VEM AO RELÉ"]:
		var comm_button := Button.new()
		comm_button.text = comm
		comm_button.custom_minimum_size = Vector2(0, 40)
		comm_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		comm_button.pressed.connect(_send_quick_comms.bind(comm))
		comms_row.add_child(comm_button)
	hub_stack.add_child(comms_row)
	var hub_close := Button.new()
	hub_close.text = "VOLTAR AO JOGO"
	hub_close.custom_minimum_size = Vector2(0, 44)
	hub_close.pressed.connect(_toggle_mission_hub)
	hub_stack.add_child(hub_close)
	layer.add_child(mission_hub)
	_refresh_mission_hub()
	_apply_gamer_ui_style(layer)


func _toggle_mission_hub() -> void:
	if mission_hub == null:
		return
	mission_hub.visible = not mission_hub.visible
	if mission_hub.visible:
		_refresh_mission_hub()


func _set_mission_hub_tab(tab_name: String) -> void:
	mission_hub_tab = tab_name
	_refresh_mission_hub()


func _refresh_mission_hub() -> void:
	if mission_hub_body == null:
		return
	local_player_id = multiplayer.get_unique_id()
	var connected_count := multiplayer.get_peers().size() + 1 if multiplayer.multiplayer_peer != null else 1
	var objective_a := "CONCLUÍDO" if int(switch_owners.get("A", 0)) > 0 else "PENDENTE"
	var objective_b := "CONCLUÍDO" if int(switch_owners.get("B", 0)) > 0 else "PENDENTE"
	match mission_hub_tab:
		"OBJETIVOS":
			mission_hub_title.text = "OBJETIVOS DA EXPEDIÇÃO"
			mission_hub_body.text = "MISSÃO: Estação Véspera\n\n%s  Ativar o Relé A\n%s  Ativar o Relé B\n%s  Usar dois participantes diferentes nos relés\n%s  Resolver o acesso à câmara de contenção\n\nTrabalha com outro jogador: os dois relés estão separados." % ["✓" if objective_a == "CONCLUÍDO" else "○", "✓" if objective_b == "CONCLUÍDO" else "○", "✓" if coop_solved else "○", "✓" if coop_solved else "○"]
		"INVENTÁRIO":
			mission_hub_title.text = "EQUIPAMENTO E INVENTÁRIO"
			mission_hub_body.text = "EQUIPAMENTO POLAR VISÍVEL\n• Parka térmica com capuz e proteção facial\n• Óculos de neve, luvas isolantes e botas polares\n• Mochila de sobrevivência e rádio de emergência\n• Lanterna — alternar no botão LANTERNA\n• Modo furtivo — botão AGACHAR\n\nA roupa é visual nesta revisão. Temperatura corporal, hipotermia e desgaste do equipamento ainda não são sistemas de sobrevivência funcionais."
		"EQUIPA":
			mission_hub_title.text = "ESTADO DA EQUIPA"
			var team_text := "Participantes na sessão: %d\n" % connected_count
			team_text += "Anfitrião: %s\n" % ("ligado" if multiplayer.multiplayer_peer != null else "sessão local")
			team_text += "Relé A: %s\nRelé B: %s\n" % ["ativo" if int(switch_owners.get("A", 0)) > 0 else "por ativar", "ativo" if int(switch_owners.get("B", 0)) > 0 else "por ativar"]
			team_text += "Cooperação: %s\n\nUsa a comunicação rápida abaixo para coordenar a equipa." % ("objetivo cooperativo concluído" if coop_solved else "a aguardar ações de participantes diferentes")
			mission_hub_body.text = team_text
		"DOSSIÊ":
			mission_hub_title.text = "DOSSIÊ PESSOAL"
			mission_hub_body.text = "REGISTO PRIVADO DO PARTICIPANTE\n\n%s\n\nAs pistas deste painel são pessoais. Partilha verbalmente a informação com a equipa; o painel não revela papéis secretos de outros jogadores." % (private_clue.text if private_clue != null else "Ainda não há registo disponível.")
	if quick_comms_status != null and multiplayer.multiplayer_peer == null:
		quick_comms_status.text = "Comunicação rápida: cria ou entra numa sessão LAN para enviar mensagens à equipa."


func _send_quick_comms(message: String) -> void:
	if multiplayer.multiplayer_peer == null:
		if quick_comms_status:
			quick_comms_status.text = "Sem sessão LAN. Abre REDE LAN e cria/entra numa sessão para comunicar."
		return
	if multiplayer.is_server():
		_apply_quick_comms(multiplayer.get_unique_id(), message)
		for peer_id in multiplayer.get_peers():
			rpc_id(int(peer_id), "receive_quick_comms", multiplayer.get_unique_id(), message)
	else:
		rpc_id(1, "server_quick_comms", message)


@rpc("any_peer", "call_remote", "reliable")
func server_quick_comms(message: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	_apply_quick_comms(sender, message)
	for peer_id in multiplayer.get_peers():
		if int(peer_id) != sender:
			rpc_id(int(peer_id), "receive_quick_comms", sender, message)


@rpc("authority", "call_remote", "reliable")
func receive_quick_comms(sender_id: int, message: String) -> void:
	_apply_quick_comms(sender_id, message)


func _apply_quick_comms(sender_id: int, message: String) -> void:
	if quick_comms_status:
		quick_comms_status.text = "EQUIPA · Jogador %d: %s" % [sender_id, message]
	if network_status:
		network_status.text = "Comunicação rápida · Jogador %d: %s" % [sender_id, message]


func _toggle_pause_menu() -> void:
	if game_paused_by_menu:
		game_paused_by_menu = false
		get_tree().paused = false
		return
	var pause_layer := get_node_or_null("PauseOverlay") as CanvasLayer
	if pause_layer:
		pause_layer.queue_free()
		pause_layer = null
	pause_layer = CanvasLayer.new()
	pause_layer.name = "PauseOverlay"
	pause_layer.layer = 120
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(pause_layer)
	var dim := ColorRect.new()
	dim.color = Color(0.005, 0.012, 0.018, 0.88)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(minf(420.0, get_viewport().get_visible_rect().size.x - 36.0), 0)
	center.add_child(panel)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 12)
	panel.add_child(stack)
	var heading := Label.new()
	heading.text = "EXPEDIÇÃO EM PAUSA"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 22)
	stack.add_child(heading)
	var resume := Button.new()
	resume.text = "RETOMAR EXPEDIÇÃO"
	resume.custom_minimum_size = Vector2(0, 48)
	resume.pressed.connect(func(): game_paused_by_menu = false; get_tree().paused = false; pause_layer.queue_free())
	stack.add_child(resume)
	var sound_info := Label.new()
	sound_info.text = "Áudio, ecrã e rede LAN estão disponíveis no menu de opções/rede. A sessão cooperativa não é terminada ao pausar."
	sound_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stack.add_child(sound_info)
	get_tree().paused = true
	game_paused_by_menu = true


func _gamer_style(bg: Color, border_color: Color, border_size: int = 1, radius: int = 8) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border_color
	style.set_border_width_all(border_size)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 12.0
	style.content_margin_right = 12.0
	style.content_margin_top = 7.0
	style.content_margin_bottom = 7.0
	return style


func _apply_gamer_ui_style(node: Node) -> void:
	# Tactical premium interface: deep blue-green surfaces, warm gold accents, large touch targets.
	if node is Button:
		var button := node as Button
		button.add_theme_stylebox_override("normal", _gamer_style(Color(0.035, 0.085, 0.105, 0.98), Color(0.14, 0.44, 0.49, 0.95), 1, 8))
		button.add_theme_stylebox_override("hover", _gamer_style(Color(0.07, 0.17, 0.19, 1.0), Color(0.82, 0.58, 0.28, 1.0), 2, 8))
		button.add_theme_stylebox_override("pressed", _gamer_style(Color(0.10, 0.20, 0.20, 1.0), Color(0.95, 0.72, 0.38, 1.0), 2, 8))
		button.add_theme_stylebox_override("focus", _gamer_style(Color(0.06, 0.15, 0.17, 1.0), Color(0.35, 0.82, 0.86, 1.0), 2, 8))
		button.add_theme_font_size_override("font_size", 15)
		button.add_theme_color_override("font_color", Color(0.91, 0.95, 0.96))
		button.add_theme_color_override("font_hover_color", Color(1.0, 0.84, 0.52))
		button.add_theme_color_override("font_pressed_color", Color(1.0, 0.88, 0.65))
		button.add_theme_color_override("font_focus_color", Color(1.0, 1.0, 1.0))
		button.add_theme_color_override("font_disabled_color", Color(0.40, 0.48, 0.52))
	elif node is PanelContainer:
		(node as PanelContainer).add_theme_stylebox_override("panel", _gamer_style(Color(0.012, 0.028, 0.038, 0.98), Color(0.14, 0.38, 0.43, 0.98), 1, 12))
	elif node is LineEdit:
		var edit := node as LineEdit
		edit.add_theme_stylebox_override("normal", _gamer_style(Color(0.02, 0.045, 0.06, 0.98), Color(0.12, 0.38, 0.46, 1.0), 1, 6))
		edit.add_theme_stylebox_override("focus", _gamer_style(Color(0.025, 0.065, 0.08, 1.0), Color(0.20, 0.88, 1.0, 1.0), 2, 6))
		edit.add_theme_color_override("font_color", Color(0.88, 0.96, 1.0))
		edit.add_theme_color_override("font_placeholder_color", Color(0.42, 0.58, 0.63))
	elif node is Label:
		var label := node as Label
		label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.85))
		label.add_theme_constant_override("shadow_offset_x", 1)
		label.add_theme_constant_override("shadow_offset_y", 1)
	for child in node.get_children():
		_apply_gamer_ui_style(child)


# Menu inicial gamer: configurações, ligação e regras detalhadas.
var main_menu_layer: CanvasLayer
var main_menu_content: VBoxContainer
var main_menu_ip: LineEdit
var menu_status_label: Label

func _build_main_menu() -> void:
	main_menu_layer = CanvasLayer.new()
	main_menu_layer.name = "MainMenu"
	main_menu_layer.layer = 100
	add_child(main_menu_layer)
	var menu_background := TextureRect.new()
	menu_background.name = "MenuCinematicBackground"
	menu_background.texture = load("res://art/menu_estacao_vespera.png") as Texture2D
	menu_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	menu_background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	menu_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	main_menu_layer.add_child(menu_background)
	var dim := ColorRect.new()
	# Escurece a arte para manter o texto e os controlos legíveis em telemóveis.
	dim.color = Color(0.008, 0.018, 0.028, 0.70)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main_menu_layer.add_child(dim)
	var outer := CenterContainer.new()
	outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	outer.offset_left = 18
	outer.offset_top = 12
	outer.offset_right = -18
	outer.offset_bottom = -12
	main_menu_layer.add_child(outer)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2( minf(620.0, get_viewport().get_visible_rect().size.x - 36.0), 0.0)
	outer.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	panel.add_child(root)
	var title := Label.new()
	title.text = "A ÚLTIMA EXPEDIÇÃO"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 26 if get_viewport().get_visible_rect().size.x < 520.0 else 30)
	title.add_theme_color_override("font_color", Color(0.96, 0.76, 0.43))
	root.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "UMA EXPEDIÇÃO. DUAS PERSPETIVAS. NENHUMA SAÍDA GARANTIDA."
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 13)
	subtitle.add_theme_color_override("font_color", Color(0.43, 0.82, 0.88))
	root.add_child(subtitle)
	var nav := GridContainer.new()
	# One column on narrow phones prevents clipped labels and tiny touch targets.
	nav.columns = 1 if get_viewport().get_visible_rect().size.x < 560.0 else 2
	nav.add_theme_constant_override("h_separation", 8)
	nav.add_theme_constant_override("v_separation", 8)
	root.add_child(nav)
	for item in [{"label":"JOGAR", "page":"play"}, {"label":"LIGAÇÃO WLAN", "page":"network"}, {"label":"SOM", "page":"sound"}, {"label":"VÍDEO", "page":"video"}, {"label":"REGRAS COMPLETAS", "page":"rules"}, {"label":"SAIR", "page":"exit"}]:
		var b := Button.new()
		b.text = item.label
		b.custom_minimum_size = Vector2(0, 46)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_show_main_menu_page.bind(item.page))
		nav.add_child(b)
	var sep := HSeparator.new()
	root.add_child(sep)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, minf(300.0, get_viewport().get_visible_rect().size.y * 0.40))
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(scroll)
	main_menu_content = VBoxContainer.new()
	main_menu_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_menu_content.add_theme_constant_override("separation", 8)
	scroll.add_child(main_menu_content)
	menu_status_label = Label.new()
	menu_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_status_label.add_theme_color_override("font_color", Color(0.58, 0.91, 0.78))
	root.add_child(menu_status_label)
	_apply_gamer_ui_style(main_menu_layer)
	_show_main_menu_page("home")
	_build_intro_screen()

func _build_intro_screen() -> void:
	intro_layer = CanvasLayer.new()
	intro_layer.name = "CinematicIntro"
	intro_layer.layer = 200
	add_child(intro_layer)
	var intro_background := TextureRect.new()
	intro_background.name = "IntroCinematicBackground"
	intro_background.texture = load("res://art/intro_estacao_vespera.png") as Texture2D
	intro_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	intro_background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	intro_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	intro_layer.add_child(intro_background)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.008, 0.018, 0.028, 0.48)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_layer.add_child(backdrop)
	var glow := ColorRect.new()
	glow.color = Color(0.04, 0.15, 0.18, 0.26)
	glow.anchor_left = 0.0
	glow.anchor_top = 0.35
	glow.anchor_right = 1.0
	glow.anchor_bottom = 0.72
	glow.offset_left = 0
	glow.offset_right = 0
	glow.offset_top = 0
	glow.offset_bottom = 0
	intro_layer.add_child(glow)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 24
	center.offset_right = -24
	intro_layer.add_child(center)
	var stack := VBoxContainer.new()
	stack.custom_minimum_size = Vector2(minf(560.0, get_viewport().get_visible_rect().size.x - 48.0), 0)
	stack.add_theme_constant_override("separation", 16)
	stack.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(stack)
	var overline := Label.new()
	overline.text = "REGISTO DE MISSÃO  /  ESTAÇÃO VÉSPERA"
	overline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overline.add_theme_font_size_override("font_size", 12)
	overline.add_theme_color_override("font_color", Color(0.38, 0.77, 0.81))
	stack.add_child(overline)
	var logo := Label.new()
	logo.text = "A ÚLTIMA\nEXPEDIÇÃO"
	logo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	logo.add_theme_font_size_override("font_size", 38 if get_viewport().get_visible_rect().size.x > 500 else 29)
	logo.add_theme_color_override("font_color", Color(0.95, 0.81, 0.57))
	stack.add_child(logo)
	var tagline := Label.new()
	tagline.text = "O QUE DESCOBRIRES LÁ DENTRO, LEVAS CONTIGO."
	tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tagline.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tagline.add_theme_font_size_override("font_size", 13)
	tagline.add_theme_color_override("font_color", Color(0.70, 0.80, 0.83))
	stack.add_child(tagline)
	var spacer := Control.new()
	spacer.custom_minimum_size.y = 28
	stack.add_child(spacer)
	intro_progress = ProgressBar.new()
	intro_progress.min_value = 0
	intro_progress.max_value = 100
	intro_progress.value = 0
	intro_progress.show_percentage = false
	intro_progress.custom_minimum_size = Vector2(0, 9)
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.08, 0.13, 0.15, 1)
	track.set_corner_radius_all(5)
	intro_progress.add_theme_stylebox_override("background", track)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.92, 0.55, 0.24, 1)
	fill.set_corner_radius_all(5)
	intro_progress.add_theme_stylebox_override("fill", fill)
	stack.add_child(intro_progress)
	intro_percent = Label.new()
	intro_percent.text = "000%"
	intro_percent.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	intro_percent.add_theme_font_size_override("font_size", 15)
	intro_percent.add_theme_color_override("font_color", Color(0.92, 0.94, 0.91))
	stack.add_child(intro_percent)
	var foot := Label.new()
	foot.text = "A PREPARAR A EXPEDIÇÃO · 4 SEGUNDOS"
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	foot.add_theme_font_size_override("font_size", 10)
	foot.add_theme_color_override("font_color", Color(0.43, 0.58, 0.62))
	stack.add_child(foot)
	main_menu_layer.visible = false
	intro_layer.visible = true
	intro_elapsed = 0.0

func _clear_menu_content() -> void:
	for child in main_menu_content.get_children():
		child.queue_free()

func _menu_heading(text_value: String) -> void:
	var heading := Label.new()
	heading.text = text_value
	heading.add_theme_font_size_override("font_size", 19)
	heading.add_theme_color_override("font_color", Color(0.35, 0.92, 1.0))
	main_menu_content.add_child(heading)

func _menu_text(text_value: String) -> void:
	var body := Label.new()
	body.text = text_value
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_font_size_override("font_size", 14)
	body.add_theme_color_override("font_color", Color(0.82, 0.88, 0.91))
	main_menu_content.add_child(body)

func _show_main_menu_page(page: String) -> void:
	_clear_menu_content()
	menu_status_label.text = ""
	match page:
		"home":
			_menu_heading("MENU PRINCIPAL")
			_menu_text("REGISTO DE MISSÃO 01\nHá vários dias que a Estação Véspera deixou de responder às comunicações externas. A última transmissão foi interrompida a meio de uma frase. A VANTHIS Corporation classificou o incidente como uma falha operacional e autorizou uma equipa a avaliar a situação. As condições meteorológicas estão a piorar e a janela de operação é limitada.\n\nMISSÃO: chegar à estação, restabelecer as comunicações, investigar o que aconteceu, recolher os dados necessários e encontrar uma forma de regressar em segurança. Não existe informação confirmada sobre o estado da equipa anterior.\n\nPara cooperar, os jogadores devem estar na mesma rede WLAN e um deles tem de criar a sessão.")
			var start := Button.new()
			start.text = "ENTRAR NA EXPEDIÇÃO"
			start.custom_minimum_size = Vector2(0, 48)
			start.pressed.connect(_close_main_menu)
			main_menu_content.add_child(start)
		"play":
			_menu_heading("PRONTO PARA JOGAR?")
			_menu_text("A exploração começa quando fechares este menu. Usa o joystick para te moveres, arrasta no lado direito para olhar e aproxima-te dos mecanismos para interagir. A cooperação completa requer um segundo jogador ligado.")
			var start := Button.new()
			start.text = "COMEÇAR / VOLTAR AO JOGO"
			start.custom_minimum_size = Vector2(0, 48)
			start.pressed.connect(_close_main_menu)
			main_menu_content.add_child(start)
		"network":
			_menu_heading("LIGAÇÃO AO JOGO · WLAN")
			_menu_text("Sem internet: liga os dois telemóveis à mesma rede Wi-Fi ou ao ponto de acesso de um deles. O anfitrião cria a sessão e partilha o IP mostrado. O segundo jogador introduz esse IP abaixo e carrega em LIGAR.")
			var host := Button.new()
			host.text = "CRIAR SESSÃO (ANFITRIÃO)"
			host.custom_minimum_size = Vector2(0, 44)
			host.pressed.connect(_menu_host_session)
			main_menu_content.add_child(host)
			var ip_label := Label.new()
			ip_label.text = "IP DO ANFITRIÃO"
			main_menu_content.add_child(ip_label)
			main_menu_ip = LineEdit.new()
			main_menu_ip.placeholder_text = "Ex.: 192.168.1.77"
			main_menu_ip.text = ""
			main_menu_ip.custom_minimum_size = Vector2(0, 42)
			main_menu_content.add_child(main_menu_ip)
			var join := Button.new()
			join.text = "LIGAR À SESSÃO"
			join.custom_minimum_size = Vector2(0, 44)
			join.pressed.connect(_menu_join_session)
			main_menu_content.add_child(join)
			_menu_text("Se a ligação falhar, confirma o IP, que ambos estão na mesma WLAN e que a rede não bloqueia a comunicação entre dispositivos. A porta de jogo é UDP %d." % PORT)
		"sound":
			_menu_heading("DEFINIÇÕES DE SOM")
			_menu_text("Ajusta o volume geral e da música. As alterações aplicam-se imediatamente.")
			_add_volume_slider("Volume geral", "Master", 1.0)
			_add_volume_slider("Música ambiente", "Music", 0.55)
			_add_volume_slider("Efeitos e vozes", "SFX", 0.8)
			_menu_text("Se os buses Music ou SFX não existirem no projeto, os controlos correspondentes ficam indisponíveis; o volume geral continua disponível.")
		"video":
			_menu_heading("DEFINIÇÕES DE VÍDEO")
			_menu_text("As opções de vídeo são locais neste dispositivo. Em telemóveis, o modo de ecrã inteiro é normalmente o comportamento recomendado.")
			var fullscreen := Button.new()
			fullscreen.text = "ALTERNAR ECRÃ INTEIRO"
			fullscreen.custom_minimum_size = Vector2(0, 44)
			fullscreen.pressed.connect(_toggle_fullscreen)
			main_menu_content.add_child(fullscreen)
			var brightness_label := Label.new()
			brightness_label.text = "Brilho da interface (pré-visualização)"
			main_menu_content.add_child(brightness_label)
			var brightness := HSlider.new()
			brightness.min_value = 0.65
			brightness.max_value = 1.35
			brightness.step = 0.05
			brightness.value = 1.0
			brightness.value_changed.connect(_set_ui_brightness)
			main_menu_content.add_child(brightness)
			_menu_text("A qualidade gráfica depende também das capacidades do dispositivo e das definições de renderização do projeto.")
		"exit":
			_menu_heading("SAIR DA EXPEDIÇÃO?")
			_menu_text("Fecha a aplicação. Se estiveres numa sessão cooperativa, avisa o outro jogador antes de sair.")
			var quit_button := Button.new()
			quit_button.text = "CONFIRMAR SAÍDA"
			quit_button.custom_minimum_size = Vector2(0, 46)
			quit_button.pressed.connect(get_tree().quit)
			main_menu_content.add_child(quit_button)
		"rules":
			_menu_heading("REGRAS DA EXPEDIÇÃO — GUIA DETALHADO")
			_menu_text("1. OBJETIVO\nInvestiga a Estação Véspera, recolhe pistas e decide como responder à presença desconhecida. Sobrevive e conclui os objetivos da missão.")
			_menu_text("2. MOVIMENTO E EXPLORAÇÃO\nUsa o joystick para caminhar e arrasta na zona direita para orientar a câmara. A lanterna ajuda a observar áreas escuras. Agacha-te quando precisares de avançar com cautela.")
			_menu_text("3. INTERAÇÃO\nAproxima-te de um mecanismo e carrega em INTERAGIR. Se estiveres demasiado longe, a ação não será executada. Observa as mensagens do jogo para perceber o resultado.")
			_menu_text("4. COOPERAÇÃO\nNo modo cooperativo, cada jogador deve comunicar as pistas e cumprir a sua parte. Os relés A e B exigem colaboração. A porta só deve abrir quando o objetivo cooperativo for concluído pelo sistema.")
			_menu_text("5. WLAN\nUm jogador cria a sessão e partilha o IP local apresentado. O outro introduz esse IP e liga-se. Ambos devem estar na mesma rede local. 127.0.0.1 nunca é o IP a partilhar com outro dispositivo.")
			_menu_text("6. ENTIDADE E CALOR\nOs indicadores térmicos representam deteções simuladas do jogo, não sensores físicos. Um sinal pode indicar proximidade; não garante que a entidade esteja visível. Usa o ambiente sonoro e visual para avaliar o risco.")
			_menu_text("7. DECISÕES\nQuando surgir uma escolha, lê as pistas e discute-as com o outro jogador antes de selecionar ACUSAR ou DEFENDER. As decisões podem alterar o rumo da missão.")
			_menu_text("8. DERROTA, FALHAS E RECONEXÃO\nSe perderes a ligação, verifica a WLAN e o IP do anfitrião e tenta ligar novamente. Não assumas que uma sessão está ligada até o painel confirmar o estado. Esta versão é um protótipo: algumas regras e funcionalidades ainda podem estar em desenvolvimento.")
			_menu_text("9. JOGO RESPONSÁVEL\nJoga com som num nível confortável. Faz pausas se os efeitos de suspense te causarem desconforto.")
	_apply_gamer_ui_style(main_menu_content)

func _close_main_menu() -> void:
	if main_menu_layer:
		main_menu_layer.visible = false

func _menu_host_session() -> void:
	host_game()
	if menu_status_label and network_status:
		menu_status_label.text = network_status.text

func _menu_join_session() -> void:
	if main_menu_ip and ip_input:
		ip_input.text = main_menu_ip.text.strip_edges()
	join_game()
	if menu_status_label and network_status:
		menu_status_label.text = network_status.text

func _add_volume_slider(label_text: String, bus_name: String, default_value: float) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	var label := Label.new()
	label.text = label_text + (" (indisponível)" if bus_index < 0 else "")
	main_menu_content.add_child(label)
	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = default_value
	slider.editable = bus_index >= 0
	slider.value_changed.connect(_set_bus_volume.bind(bus_name))
	main_menu_content.add_child(slider)

func _set_bus_volume(value: float, bus_name: String) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	if bus_index >= 0:
		AudioServer.set_bus_volume_db(bus_index, linear_to_db(maxf(value, 0.001)))
		AudioServer.set_bus_mute(bus_index, value <= 0.001)

func _toggle_fullscreen() -> void:
	if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

func _set_ui_brightness(value: float) -> void:
	if main_menu_layer:
		main_menu_layer.modulate = Color(value, value, value, 1.0)

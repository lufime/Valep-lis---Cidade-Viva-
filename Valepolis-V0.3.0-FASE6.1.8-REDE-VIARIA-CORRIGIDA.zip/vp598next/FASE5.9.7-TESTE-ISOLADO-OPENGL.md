# Valepólis V0.3.0 — Fase 5.9.7

## Objetivo
Isolar a apresentação OpenGL sem câmara, terreno ou malhas urbanas.

## Resultado visual esperado
- Fundo verde vivo na área do mapa.
- Triângulo magenta centrado.
- Estado `BUILD 597 · FRAME=... · TESTE ISOLADO VERDE/MAGENTA`.

## Interpretação
- Se o fundo verde e o triângulo aparecerem, a superfície OpenGL e o desenho básico funcionam; o problema está na cena/malhas/câmara e deve ser reintroduzido por etapas.
- Se a área continuar azul e o estado ficar em `SUPERFÍCIE OK ... teste isolado preparado`, investigar o ciclo do GLSurfaceView, a thread GL e a apresentação da superfície.
- Se aparecer erro OpenGL, guardar a mensagem exata.

Esta é uma build de diagnóstico. Não é uma versão de lançamento. O APK não foi compilado nem validado num dispositivo durante a preparação deste ZIP.

# Valepólis V0.3.0 — Fase 6.1.5 / BUILD 615

## Alterações
- Aumentada a aproximação máxima da câmara: distância mínima 6,5 (antes 8,0).
- Botões de zoom com passos mais controlados de 2,0 unidades.
- Pinça de dois dedos suavizada para reduzir saltos durante o zoom.
- Ligações visuais entre centros de bairros ligeiramente mais largas e elevadas para reduzir artefactos de sobreposição com o terreno.
- Superfície e contornos das ligações clareados para melhorar a leitura.
- Identificação do renderizador atualizada para BUILD 615.

## Limitações e validação
As ligações continuam a ser uma proposta geométrica derivada dos centros dos bairros, não uma rede viária oficial. Não foram alterados os 25 registos territoriais.

Verificação local: integridade do ZIP e JSON territorial. A compilação Android e o teste no dispositivo não foram executados nesta sessão; esta versão não está aprovada para lançamento.

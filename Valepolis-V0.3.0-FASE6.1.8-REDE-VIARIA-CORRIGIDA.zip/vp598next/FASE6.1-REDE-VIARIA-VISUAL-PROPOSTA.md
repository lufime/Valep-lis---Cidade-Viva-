# Valepólis V0.3.0 — Fase 6.1: rede viária visual proposta

## Âmbito
- Preserva os dados territoriais V0.3.0 e os 25 polígonos de bairro existentes.
- Adiciona segmentos de estrada em geometria 3D, inferidos dos centros de bairro já existentes.
- A rede é explicitamente **proposta/visual**: não substitui um traçado viário aprovado nem constitui dados cartográficos reais.
- Mantém mar a norte, estuário a oeste e cadeia montanhosa a este.
- Atualiza a identificação visual para Fase 6.1 / BUILD 610.

## Limitações conhecidas
- Não foram fornecidos dados viários oficiais; por isso, o traçado serve apenas para avaliação visual e não deve ser usado como rota operacional.
- A altimetria continua procedural/ilustrativa, não baseada num modelo digital de terreno real.
- Os edifícios continuam a ser volumes simples; fachadas, telhados, variedade arquitetónica e densidade final ainda precisam de trabalho.
- Não foi executada compilação Android nem teste num dispositivo nesta sessão. A validação do ZIP e dos dados não equivale a aprovação do APK.
- O APK de lançamento deve continuar bloqueado até à validação visual e técnica integral.

## Verificações executadas
- Integridade do ZIP de entrada.
- JSON territorial com 25 bairros.
- Alteração localizada em `MainActivity.kt`; ficheiros e regras não relacionados foram preservados.

# Fase 6.0.4 — Relevo oriental reforçado (BUILD 604)

## Alteração
- Reforçada a amplitude das cristas e vales da cadeia montanhosa oriental no gerador procedural.
- A crista foi alargada ligeiramente para oeste, mantendo-se no setor oriental.
- Não foram alterados os polígonos dos 25 bairros, os seus centros, a costa norte nem o estuário oeste.

## Limitações
- O relevo continua ilustrativo/procedural e não corresponde a um levantamento topográfico real.
- A rede viária detalhada e os níveis de detalhe por zoom continuam pendentes.
- A distribuição cultural dos 16 bairros não foi alterada.
- BUILD 604 é diagnóstico/DEBUG; não é RELEASE.

## Validação
- ZIP: validar integridade após empacotamento.
- Dados territoriais: JSON deve manter os 25 bairros.
- Não foi executada compilação Android nem teste físico nesta sessão.

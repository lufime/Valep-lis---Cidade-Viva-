# Fase 6.0.4 — Relevo oriental reforçado (BUILD 604)

## Objetivo
Melhorar a leitura das referências geográficas sem substituir os dados territoriais existentes nem inventar estradas ou atribuições culturais.

## Alterações
- Identificação atualizada para BUILD 604.
- Adicionada legenda textual compacta: mar a norte, estuário a oeste e cadeia montanhosa/Pedravora a este.
- Ajustado o contraste da paleta dos polígonos territoriais e das superfícies de água.
- Reforçada a altura e a irregularidade das cristas da cadeia montanhosa oriental; mantidos o lado oriental e a extensão norte-sul.
- Mantidos os dados dos 25 bairros e os controlos de câmara da BUILD 602.

## Limitações conhecidas
- Relevo ainda procedural/ilustrativo, não baseado em levantamento topográfico real.
- Rede viária detalhada não validada.
- A atribuição definitiva das culturas aos 16 bairros não foi alterada.
- APK não considerada RELEASE: requer compilação e validação visual no dispositivo.

## Validação efetuada
Verificação estrutural do ZIP, sintaxe JSON do registo territorial e presença das referências BUILD 604. Não foi executada compilação Android nem teste físico do dispositivo.

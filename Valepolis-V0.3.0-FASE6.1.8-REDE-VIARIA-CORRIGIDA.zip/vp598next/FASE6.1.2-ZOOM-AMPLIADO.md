# Valepólis V0.3.0 — Fase 6.1.2: Zoom ampliado

Alteração aplicada sobre o ZIP fornecido Fase 6.1.1 — Rede Viária Legível.

- Zoom por gesto de pinça no mapa 3D: distância da câmara agora limitada a 10–78 (antes 22–58).
- Botões + e − do mapa 3D passam a alterar a distância em passos de 4 (antes 3).
- Recentrar continua a repor a câmara para a distância 31 e a orientação inicial.
- Mantidos os dados territoriais e restantes ficheiros do projeto.

Importante: o ZIP foi verificado estruturalmente, mas não foi compilado nem testado num dispositivo Android nesta sessão. A ampliação permite aproximar mais; não transforma o protótipo de polígonos numa cidade final detalhada.

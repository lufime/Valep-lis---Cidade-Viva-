# Valepólis V0.3.0 — Fase 5.9.6

Correção do teste visual: o triângulo magenta é desenhado DEPOIS de todas as malhas do mapa, com teste de profundidade temporariamente desativado. Na Fase 5.9.5, o triângulo era desenhado antes das malhas e podia ficar coberto por elas; por isso, a ausência de triângulo na captura não demonstrava falha de framebuffer.

Validar no dispositivo: se o triângulo aparecer, a superfície e o shader conseguem apresentar geometria simples; se não aparecer, investigar superfície EGL/shader/framebuffer. A fase é de diagnóstico, não release. ZIP validado; não foi compilado nem testado num dispositivo nesta sessão.

# Valepólis V0.3.0 — Fase 6.1.6: rede viária visual

## Alterações
- Ligações visuais entre os centros territoriais existentes dos 25 bairros.
- Tramos com curvatura suave e subdivisões para acompanhar o relevo.
- Duas larguras visuais para distinguir ligações principais e secundárias.
- Pavimento em tom de asfalto e bordos discretos, substituindo a aparência de linhas escuras isoladas.
- Identificação de diagnóstico atualizada para BUILD 616.

## Limites
Esta rede é uma proposta geométrica para validação visual, inferida dos centros dos bairros. Não é um traçado viário oficial nem substitui uma matriz de estradas aprovada. Não foram inventados nomes de ruas, sentidos, hierarquias oficiais ou ligações geográficas definitivas.

## Validação
O ZIP foi verificado estruturalmente. A compilação Android e o teste no dispositivo ainda precisam de ser executados no workflow.

# Valepólis V0.3.0 — Fase 5.9.8

## Objetivo
Repor o desenho da cena real depois do teste isolado 5.9.7 e investigar a composição visual da `GLSurfaceView`.

## Alterações
- Repõe a passagem de desenho das malhas da cena real.
- Mantém contagem de frames, chamadas de desenho, vértices e erros OpenGL.
- Ativa `setZOrderMediaOverlay(true)` sem colocar a superfície no topo absoluto da janela.
- Remove a cor opaca de fundo da `GLSurfaceView`, para reduzir o risco de a própria View esconder a superfície renderizada.
- Mantém os dados territoriais do ZIP de origem sem alterar os limites dos bairros.

## Camadas
O código chama as malhas geradas em `buildMeshes()`; isto não prova por si só que cada camada esteja visualmente correta. A validação das camadas de terreno, água, bairros, limites e edifícios depende de a cena voltar a aparecer no dispositivo.

## Validação
ZIP montado a partir da Fase 5.9.7 e alterações verificadas no código. Não foi compilado nem testado em dispositivo neste ambiente. APK RELEASE bloqueada.

# Valepólis V0.3.0 — Fase 6.1.3 · BUILD 613

## Alterações
- Aumentado o limite de aproximação da câmara: distância mínima 6,5 (antes 10).
- Aumentado o limite de afastamento para 90 (antes 78).
- Botões de zoom passam a alterar a distância em passos de 2,5 (antes 4), para ajuste mais fino.
- Pinça de dois dedos limitada por evento para reduzir saltos bruscos de zoom.
- Clareada a cor da superfície da rede viária visual proposta e reduzido o contraste das suas linhas laterais, que apareciam quase pretas nas capturas.
- Preservados os dados territoriais existentes; não foram atribuídos nomes ou culturas novas aos bairros.

## Limitações e validação
A rede viária continua explicitamente identificada no código como proposta visual derivada dos centros dos bairros, não como traçado oficial. O relevo continua ilustrativo. Esta entrega não declara o APK compilado nem testado num dispositivo; deve passar pelo workflow Android e ser verificada no telemóvel antes de aprovação.

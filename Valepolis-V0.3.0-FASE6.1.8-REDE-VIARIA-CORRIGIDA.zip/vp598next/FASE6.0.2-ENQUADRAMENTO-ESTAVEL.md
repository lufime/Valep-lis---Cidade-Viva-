# Valepólis V0.3.0 — Fase 6.0.2 / BUILD 602

## Objetivo
Estabilizar o enquadramento inicial depois das capturas da BUILD 601, onde o zoom próximo cortou partes do mapa.

## Alterações
- Distância inicial da câmara ajustada para 31 unidades, mais conservadora para enquadrar a cidade completa.
- Botão Recentrar repõe rotação, distância e deslocamentos para os valores iniciais.
- Limite mínimo do zoom aproximado ajustado de 10 para 22 unidades, para reduzir cortes extremos.
- Identificação do diagnóstico atualizada para BUILD 602.
- Mantidos os dados territoriais e as malhas da versão de origem.

## Limitações e validação
O ZIP foi verificado estruturalmente. Não foi compilado nem testado num dispositivo nesta execução. Os controlos visuais devem ser confirmados na APK DEBUG; as capturas anteriores mostraram que os botões podem ficar visualmente reduzidos em certas condições. Não considerar a versão RELEASE aprovada.

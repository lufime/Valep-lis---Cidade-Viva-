# Valepólis V0.3.0 — Fase 6.1.4 / BUILD 614

## Correções nesta revisão
- Aumentada a distância mínima da câmara de 6,5 para 8,0 para reduzir cortes extremos ao aproximar.
- Mantido o limite de afastamento em 90 e os controlos de zoom existentes.
- Reduzida a largura das ligações geométricas entre centros de bairros.
- Clareada a superfície e as linhas laterais para deixarem de parecer traços quase pretos.
- Atualizados os textos de diagnóstico para BUILD 614.

## Limitações e validação
As ligações continuam a ser uma proposta visual derivada dos centros dos bairros, não uma rede viária oficial. Não foram inventadas coordenadas oficiais nem alterados deliberadamente os 25 registos territoriais.

O ZIP foi verificado quanto à integridade do arquivo e às alterações textuais. A compilação Android e o teste no dispositivo ainda são necessários; esta revisão não está aprovada para lançamento.

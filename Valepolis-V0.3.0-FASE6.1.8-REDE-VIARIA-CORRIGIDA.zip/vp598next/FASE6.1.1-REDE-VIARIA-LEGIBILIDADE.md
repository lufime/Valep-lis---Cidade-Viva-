# Valepólis V0.3.0 — Fase 6.1.1 / BUILD 611

## Alterações
- Aumentada a largura visual dos segmentos viários propostos para melhorar a leitura no telemóvel.
- Aumentado o contraste entre a superfície da estrada e as linhas de bordo.
- Mantida a rede como proposta visual derivada dos centros existentes dos bairros; não representa cartografia oficial nem deve ser usada para despacho ou navegação operacional.
- Mantidos os 25 polígonos e os dados territoriais existentes.

## Limitações
- A rede continua inferida a partir dos centros dos bairros e não segue um levantamento rodoviário aprovado.
- Não foram adicionados nomes de ruas nem ligações reais inventadas.
- A compilação Android e o teste no dispositivo não foram executados nesta sessão.
- O APK de lançamento continua bloqueado até à validação técnica e visual integral.

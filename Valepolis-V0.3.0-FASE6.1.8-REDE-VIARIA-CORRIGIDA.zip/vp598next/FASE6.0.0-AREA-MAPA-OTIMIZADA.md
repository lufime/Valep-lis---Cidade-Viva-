# Valepólis V0.3.0 — Fase 6.0.0 — Área do mapa otimizada

## Objetivo
Reduzir o espaço vertical vazio na área do mapa 3D sem voltar a alterar a geometria territorial ou o renderizador que já apresenta a cena real.

## Alteração
- Área do `GLSurfaceView` reduzida de 520 dp para 360 dp.
- Mantida a câmara inicial da BUILD 599 e os controlos existentes.
- Atualizada a identificação para BUILD 600.
- Mantidos os dados territoriais, malhas, costa, estuário, relevo ilustrativo e volumes urbanos do ZIP de origem.

## Limites de validação
Esta alteração foi feita no código-fonte do ZIP da Fase 5.9.9. O arquivo pode ser verificado, mas a APK não foi compilada nem testada neste ambiente. A aparência final deve ser confirmada no dispositivo.

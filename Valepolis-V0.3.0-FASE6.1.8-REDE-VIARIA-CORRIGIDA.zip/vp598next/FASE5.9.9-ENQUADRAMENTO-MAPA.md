# Valepólis V0.3.0 — Fase 5.9.9

## Objetivo
Melhorar o enquadramento inicial da cena real no ecrã Android sem alterar os dados territoriais aprovados.

## Alterações
- Distância inicial da câmara reduzida de 46 para 29 unidades, para o mapa ocupar mais área visível.
- Limites do zoom ajustados para permitir maior aproximação (10) e manter afastamento máximo controlado (58).
- Botão **Recentrar** repõe a distância inicial de 29 unidades.
- Identificação da interface e mensagens de diagnóstico atualizadas para Fase 5.9.9 / BUILD 599.
- Não foram alterados os polígonos dos 25 bairros, os dados de população ou as regras territoriais.

## Validação
- ZIP e estrutura de ficheiros: verificar no empacotamento.
- Dados JSON: serão validados antes da entrega.
- Compilação Android e teste físico: não executados neste ambiente.
- Esta fase não aprova o mapa 3D nem desbloqueia a APK RELEASE.

# A Última Expedição — V0.1.73

- Encerramento da missão apresentado como **EXTRAÇÃO CONFIRMADA**.
- A extração exige relés A e B ativos, energia restabelecida, 10 provas recolhidas, combinação VANTHIS validada e arquivo confidencial aberto.
- O terminal apresenta as tarefas em falta quando a missão ainda não está pronta para terminar.
- O modo individual permite concluir os objetivos sem depender de outro jogador; no multijogador, a validação é feita pelo servidor.
- A cena final mantém em aberto o destino da experiência VANTHIS.

## Validação honesta

O pacote ZIP pode ser verificado estruturalmente, mas o Godot 4.5 não está disponível neste ambiente. Não declarar compilação, execução nem teste multijogador como aprovados sem os executar.

extends Node3D

const PLAYER_SCRIPT := preload("res://scripts/player_controller.gd")
const INTERACTABLE_SCRIPT := preload("res://scripts/interactable_door.gd")
const COOP_SWITCH_SCRIPT := preload("res://scripts/coop_switch.gd")
const MODEL_ANIMATOR_SCRIPT := preload("res://scripts/procedural_model_animator.gd")
const PORT := 24567
const ENTITY_SYNC_INTERVAL := 0.08

var network_peer: ENetMultiplayerPeer
var remote_players: Dictionary = {}
var _last_authoritative_player_positions: Dictionary = {}
var switch_owners: Dictionary = {"A": 0, "B": 0}
var coop_solved := false
var network_status: Label
var ip_input: LineEdit
var coop_status: Label
var private_clue: Label
var mission_hub: PanelContainer
var mission_hub_body: Label
var mission_hub_title: Label
var mission_hub_tab := "OBJETIVOS"
var quick_comms_status: Label
var game_paused_by_menu := false
var local_player_id := 1
# Estado dos papéis secretos, mantido no servidor durante a sessão.
var traitor_peer_id: int = 0
var traitor_role_assigned: bool = false
# Single-player: o traidor é uma IA separada da criatura e permanece oculto.
var solo_traitor_timer := 0.0
var solo_traitor_next_action := 38.0
var solo_traitor_presence: Node3D
var solo_traitor_rng := RandomNumberGenerator.new()
var solo_traitor_sabotages := 0
var solo_traitor_glimpse_timer := 0.0
var role_notice_layer: CanvasLayer
var _sync_accumulator := 0.0
var _entity_sync_accumulator := 0.0
var _client_connect_elapsed := 0.0
const CLIENT_CONNECT_TIMEOUT := 12.0
var decision_votes: Dictionary = {}
var decision_resolved := false
var decision_status: Label
var accusation_button: Button
var defense_button: Button
var entity_presence: Node3D
var entity_reaction_label: Label
var entity_active := false
var entity_motion_time := 0.0
var entity_ai_state := "DORMANT"
var entity_waypoint_index := 0
var entity_hidden_time := 0.0
var entity_state_time := 0.0
# Captura/sobrevivência: decisão autoritativa no anfitrião.
var capture_target_peer_id := 0
var capture_elapsed := 0.0
var capture_escape_presses := 0
var capture_target_node: Node3D
const CAPTURE_ESCAPE_SECONDS := 5.0
const CAPTURE_ESCAPE_PRESSES := 8
var capture_overlay: PanelContainer
var capture_message: Label
var capture_button: Button
var eliminated_peers: Dictionary = {}
var entity_notice_label: Label
var stealth_status: Label
var entity_last_notice := 0.0
var ambient_music: AudioStreamPlayer
var sfx_player: AudioStreamPlayer
var voice_player: AudioStreamPlayer
var _world_sound_cooldowns: Dictionary = {}
var _voice_cooldown := 0.0
var _last_voice_state := ""
var _previous_audio_state := "DORMANT"
var _danger_audio_cooldown := 0.0
var _lighting_time := 0.0
var _alarm_active := false
var exterior_weather_particles: GPUParticles3D
var exterior_beacon: OmniLight3D
var exterior_weather_phase := 0.0
var exterior_wind_player: AudioStreamPlayer
var exterior_weather_label: Label
var exterior_gust_strength := 0.0
# Abrigo seguro: independente do MRE, com bloqueio blindado e um ponto fraco reparável.
var safe_shelter: Node3D
var shelter_door: StaticBody3D
var shelter_door_open := false
var shelter_lock_damaged := false
var shelter_lock_damage_progress := 0.0
var shelter_creature_pressure := 0.0
var shelter_feedback_label: Label3D
var shelter_repair_parts_available := true
var exterior_is_player_outside := false
var intro_layer: CanvasLayer
var intro_progress: ProgressBar
var intro_percent: Label
var intro_elapsed := 0.0
const INTRO_DURATION := 4.0
var entity_waypoints: Array[Vector3] = [Vector3(-3.8, 0.0, -13.4), Vector3(3.6, 0.0, -11.7), Vector3(2.8, 0.0, -6.8), Vector3(-3.5, 0.0, -8.1)]

# Diretor de suspense: sinais ambientais antes do primeiro contacto visual.
var suspense_elapsed := 0.0
var suspense_next_event := 24.0
var suspense_event_index := 0
var creature_vocal_cooldown := 0.0
var creature_vocal_index := -1
var suspense_rng := RandomNumberGenerator.new()
# Investigação cooperativa da experiência original: dez fragmentos, um por zona.
var experiment_clues_found: Dictionary = {}
var secret_experiment_door: StaticBody3D
var secret_experiment_open := false
var evidence_synthesis_complete := false
var mission_completed := false
# Extração em fases: pedido, janela de sobrevivência e chegada ao ponto exterior.
var extraction_phase := "INACTIVE" # INACTIVE, COUNTDOWN, LANDING, COMPLETE
var extraction_countdown := 0.0
var extraction_last_broadcast_second := -1
var extraction_landing_marker: Node3D
var extraction_status_label: Label
const EXTRACTION_SURVIVAL_SECONDS := 35.0
const EXTRACTION_LANDING_RADIUS := 4.0
var extraction_terminal: StaticBody3D
var mission_ending_layer: CanvasLayer
var secret_combination_panel: PanelContainer
var secret_combination_input: LineEdit
var secret_synthesis_console: StaticBody3D
var secret_clue_status: Label
const SECRET_COMBINATION := "7314"
var evidence_journal: Array[String] = []
var suspense_messages: Array[String] = [
    "RÁDIO: interferência breve. A origem do sinal não foi identificada.",
    "ESTAÇÃO: um impacto metálico ecoa num corredor distante.",
    "SENSORES: movimento térmico inconclusivo junto à estrutura exterior.",
    "AVISO: rajada polar intensa. A visibilidade exterior está a diminuir.",
    "ÁUDIO: três passos no piso superior. Não há movimento registado nos sensores.",
    "ENERGIA: oscilação momentânea. Verifica a lanterna e o rádio."
]

func _ready() -> void:
	_setup_audio()
	_build_environment()
	_build_room()
	_build_exterior_world()
	_build_safe_shelter()
	_build_next_chamber()
	_build_remaining_zones()
	_build_initial_zone_wings()
	_build_secret_experiment_area()
	_build_door()
	_build_coop_switches()
	_build_player()
	_build_hud()
	# A criatura existe em todas as partidas, mas a primeira aparição é precedida por sinais ambientais.
	suspense_rng.randomize()
	solo_traitor_rng.randomize()
	suspense_next_event = suspense_rng.randf_range(18.0, 32.0)
	multiplayer.peer_connected.connect(_on_peer_connected)
	multiplayer.peer_disconnected.connect(_on_peer_disconnected)
	multiplayer.connected_to_server.connect(_on_connected_to_server)
	multiplayer.connection_failed.connect(_on_connection_failed)
	multiplayer.server_disconnected.connect(_on_server_disconnected)
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	_build_main_menu()
	# Only dismiss the boot diagnostics after the full scene and UI were created.
	var boot := get_parent()
	if boot and boot.has_method("on_expedition_ready"):
		boot.call_deferred("on_expedition_ready")

func _setup_audio() -> void:
	# Original procedural ambience and cues are bundled locally; no network access required.
	ambient_music = AudioStreamPlayer.new()
	ambient_music.name = "AmbientMusic"
	ambient_music.stream = load("res://audio/ambient_tension.wav")
	ambient_music.volume_db = -19.0
	ambient_music.autoplay = false
	add_child(ambient_music)
	if ambient_music.stream:
		ambient_music.play()
		ambient_music.finished.connect(func():
			if ambient_music and ambient_music.stream:
				ambient_music.play()
		)
	sfx_player = AudioStreamPlayer.new()
	sfx_player.name = "SituationSFX"
	sfx_player.volume_db = -7.0
	add_child(sfx_player)
	voice_player = AudioStreamPlayer.new()
	voice_player.name = "CharacterVoices"
	voice_player.volume_db = -10.0
	add_child(voice_player)
	exterior_wind_player = AudioStreamPlayer.new()
	exterior_wind_player.name = "ExteriorPolarWind"
	exterior_wind_player.stream = load("res://audio/polar_wind_loop.wav")
	exterior_wind_player.volume_db = -28.0
	add_child(exterior_wind_player)
	if exterior_wind_player.stream:
		exterior_wind_player.finished.connect(func():
			if exterior_wind_player and exterior_is_player_outside and exterior_wind_player.stream:
				exterior_wind_player.play()
		)

func _play_voice(file_name: String) -> void:
	if voice_player == null:
		return
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream:
		voice_player.stream = stream
		voice_player.pitch_scale = 1.0
		voice_player.volume_db = -10.0
		voice_player.play()

func _play_sfx(file_name: String) -> void:
	if sfx_player == null:
		return
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream:
		sfx_player.stream = stream
		sfx_player.play()

func _play_player_sound(file_name: String, world_position: Vector3, surface: String = "snow", pitch: float = 1.0) -> void:
	# Reproduz localmente e replica apenas eventos autorizados aos restantes jogadores.
	_play_spatial_sound(file_name, world_position, surface, pitch)
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	if multiplayer.is_server():
		rpc("receive_world_sound", multiplayer.get_unique_id(), file_name, world_position, surface, pitch)
	else:
		rpc_id(1, "request_world_sound", file_name, world_position, surface, pitch)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func request_world_sound(file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var allowed := ["footstep.wav", "cloth_rustle.wav", "flashlight_click.wav", "door_motor.wav", "voice_breathing.wav"]
	if not allowed.has(file_name):
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 1 or not remote_players.has(sender):
		return
	# Usa a posição que o servidor já conhece para evitar posições arbitrárias do cliente.
	var authoritative_position: Vector3 = (remote_players[sender] as Node3D).global_position
	if authoritative_position.distance_to(world_position) > 3.0:
		world_position = authoritative_position
	rpc("receive_world_sound", sender, file_name, world_position, surface, clampf(pitch, 0.75, 1.3))

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_world_sound(peer_id: int, file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	if peer_id == multiplayer.get_unique_id():
		return
	var allowed := ["footstep.wav", "cloth_rustle.wav", "flashlight_click.wav", "door_motor.wav", "voice_breathing.wav"]
	if not allowed.has(file_name):
		return
	_play_spatial_sound(file_name, world_position, surface, pitch)

func _play_spatial_sound(file_name: String, world_position: Vector3, surface: String, pitch: float) -> void:
	var stream := load("res://audio/" + file_name) as AudioStream
	if stream == null:
		return
	var emitter := AudioStreamPlayer3D.new()
	emitter.name = "WorldSound"
	emitter.stream = stream
	emitter.global_position = world_position
	emitter.max_distance = 24.0
	emitter.unit_size = 4.0
	emitter.volume_db = -4.0 if file_name == "footstep.wav" else -8.0
	emitter.pitch_scale = clampf(pitch, 0.75, 1.3)
	match surface:
		"ice":
			emitter.pitch_scale *= 1.08
			emitter.volume_db -= 1.5
		"stone":
			emitter.pitch_scale *= 0.94
			emitter.volume_db += 1.0
		"metal":
			emitter.pitch_scale *= 1.12
			emitter.volume_db += 2.0
		"interior":
			emitter.volume_db -= 2.0
	add_child(emitter)
	emitter.finished.connect(emitter.queue_free)
	emitter.finished.connect(emitter.queue_free)
	emitter.play()

func _play_context_voice(state: String) -> void:
	# Non-verbal vocal cues are intentionally sparse so they remain unsettling rather than repetitive.
	if _voice_cooldown > 0.0 or state == _last_voice_state:
		return
	_last_voice_state = state
	match state:
		"HUNT":
			_play_voice("voice_distant_whisper.wav")
			_voice_cooldown = 7.0
		"ATTACK_WARNING":
			_play_voice("voice_scream.wav")
			_voice_cooldown = 10.0
		"OBSERVED":
			_play_voice("voice_groan.wav")
			_voice_cooldown = 6.0
		"COOP_SOLVED":
			_play_voice("voice_choked_gasp.wav")
			_voice_cooldown = 5.0

func _material(color: Color, roughness := 0.86, metallic := 0.0) -> StandardMaterial3D:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	mat.roughness = roughness
	mat.metallic = metallic
	return mat

func _box(parent: Node3D, node_name: String, size: Vector3, pos: Vector3, mat: Material, collision := true) -> MeshInstance3D:
	var body: Node3D = parent
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = node_name
	var mesh := BoxMesh.new()
	mesh.size = size
	mesh_node.mesh = mesh
	mesh_node.position = pos
	mesh_node.material_override = mat
	body.add_child(mesh_node)
	if collision:
		var static_body := StaticBody3D.new()
		static_body.name = node_name + "Collision"
		static_body.position = pos
		var shape_node := CollisionShape3D.new()
		var shape := BoxShape3D.new()
		shape.size = size
		shape_node.shape = shape
		static_body.add_child(shape_node)
		body.add_child(static_body)
	return mesh_node

func _get_local_ipv4_addresses() -> PackedStringArray:
	var addresses := PackedStringArray()
	for address in IP.get_local_addresses():
		# ENet on Android needs a reachable IPv4 address, not loopback or IPv6.
		if address.count(".") == 3 and not address.begins_with("127.") and not address == "0.0.0.0":
			addresses.append(address)
	return addresses

func _get_preferred_local_ipv4() -> String:
	var addresses := _get_local_ipv4_addresses()
	# Prefer common private LAN addresses when multiple adapters are available.
	for address in addresses:
		if address.begins_with("192.168.") or address.begins_with("10."):
			return address
		if address.begins_with("172."):
			var parts := address.split(".")
			if parts.size() == 4 and int(parts[1]) >= 16 and int(parts[1]) <= 31:
				return address
	if not addresses.is_empty():
		return addresses[0]
	return ""

func _sync_network_status_to_menu() -> void:
	# The menu and HUD have separate labels. Keep both updated after asynchronous
	# ENet callbacks, otherwise the menu can remain stuck on "A ligar...".
	if menu_status_label != null and network_status != null:
		menu_status_label.text = network_status.text

func host_game() -> void:
	if network_peer != null:
		var current_ip := _get_preferred_local_ipv4()
		if network_status:
			network_status.text = "Sessão já ativa · IP deste telemóvel: %s:%d" % [current_ip if not current_ip.is_empty() else "IP indisponível", PORT]
			_sync_network_status_to_menu()
		return
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_server(PORT, 7) # 1 anfitrião + até 7 clientes = 8 jogadores
	if result != OK:
		network_peer = null
		if network_status:
			network_status.text = "Erro ao criar sessão: %s" % error_string(result)
			_sync_network_status_to_menu()
		return
	multiplayer.multiplayer_peer = network_peer
	local_player_id = multiplayer.get_unique_id()
	var local_ip := _get_preferred_local_ipv4()
	if network_status:
		if local_ip.is_empty():
			network_status.text = "Sessão ativa na porta %d, mas não encontrei IP IPv4. Liga os telemóveis à mesma WLAN e tenta novamente." % PORT
			_sync_network_status_to_menu()
		else:
			var all_ips := ", ".join(_get_local_ipv4_addresses())
			network_status.text = "ANFITRIÃO ATIVO · IP sugerido: %s · IPs detetados: %s · PORTA UDP: %d. Partilha o IP WLAN correto." % [local_ip, all_ips, PORT]
			_sync_network_status_to_menu()
	if ip_input and not local_ip.is_empty():
		ip_input.text = local_ip
	_broadcast_local_state()

func join_game() -> void:
	if network_peer != null:
		if network_status:
			network_status.text = "Já existe uma sessão de rede neste telemóvel."
			_sync_network_status_to_menu()
		return
	var address := ip_input.text.strip_edges()
	if address.is_empty() or address == "127.0.0.1" or address == "localhost":
		if network_status:
			network_status.text = "Introduz o IP WLAN mostrado no telemóvel anfitrião; 127.0.0.1 não liga a outro telemóvel."
			_sync_network_status_to_menu()
		return
	network_peer = ENetMultiplayerPeer.new()
	var result := network_peer.create_client(address, PORT)
	if result != OK:
		network_peer = null
		if network_status:
			network_status.text = "Erro ao iniciar ligação: %s" % error_string(result)
			_sync_network_status_to_menu()
		return
	multiplayer.multiplayer_peer = network_peer
	_client_connect_elapsed = 0.0
	if network_status:
		network_status.text = "A ligar a %s:%d…" % [address, PORT]
		_sync_network_status_to_menu()

func _on_connected_to_server() -> void:
	_client_connect_elapsed = 0.0
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	rpc_id(1, "request_initial_session_state")
	if network_status:
		network_status.text = "Ligado ao anfitrião · ID %d" % local_player_id
		_sync_network_status_to_menu()

func _on_connection_failed() -> void:
	_client_connect_elapsed = 0.0
	if network_status:
		network_status.text = "Ligação falhou. Verifica o IP do anfitrião, a mesma WLAN e se a rede permite comunicação entre dispositivos."
		_sync_network_status_to_menu()
	if network_peer != null:
		network_peer.close()
		network_peer = null
	multiplayer.multiplayer_peer = null

func _on_server_disconnected() -> void:
	if network_status:
		network_status.text = "Ligação ao anfitrião perdida. Volta a ligar à sessão WLAN."
		_sync_network_status_to_menu()
	if network_peer != null:
		network_peer.close()
		network_peer = null
	multiplayer.multiplayer_peer = null

func _on_peer_connected(peer_id: int) -> void:
	local_player_id = multiplayer.get_unique_id()
	_update_private_clue()
	if multiplayer.is_server() and not remote_players.has(peer_id):
		var host_player := get_node_or_null("Player") as Node3D
		var spawn_position := host_player.global_position + Vector3(1.5, 0.0, 1.5) if host_player else Vector3.ZERO
		var avatar := _make_remote_avatar(peer_id)
		avatar.global_position = spawn_position
		remote_players[peer_id] = avatar
		_last_authoritative_player_positions[peer_id] = spawn_position
	if multiplayer.is_server() and not traitor_role_assigned:
		_assign_hidden_roles()
	if multiplayer.is_server():
		if traitor_role_assigned:
			var is_traitor := peer_id == traitor_peer_id
			var role_message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
			rpc_id(peer_id, "receive_secret_role", is_traitor, role_message)
		_send_entity_state_to(peer_id)
	if network_status:
		network_status.text = "Ligado · novo jogador %d" % peer_id
		_sync_network_status_to_menu()

@rpc("any_peer", "call_remote", "reliable")
func request_initial_session_state() -> void:
	if not multiplayer.is_server():
		return
	var requester := multiplayer.get_remote_sender_id()
	if requester <= 1:
		return
	if traitor_role_assigned:
		var is_traitor := requester == traitor_peer_id
		var message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
		rpc_id(requester, "receive_secret_role", is_traitor, message)
	_send_entity_state_to(requester)
	rpc_id(requester, "client_sync_secret_progress", experiment_clues_found.keys(), evidence_synthesis_complete, secret_experiment_open)
	if mission_completed:
		rpc_id(requester, "client_mission_completed")
	elif extraction_phase != "INACTIVE":
		rpc_id(requester, "client_extraction_state", extraction_phase, extraction_countdown)

@rpc("authority", "call_remote", "reliable")
func client_sync_secret_progress(found_ids: Array, synthesis_done: bool, door_open: bool) -> void:
	experiment_clues_found.clear()
	for raw_id in found_ids:
		experiment_clues_found[int(raw_id)] = true
	evidence_synthesis_complete = synthesis_done
	secret_experiment_open = door_open
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: %02d / 10" % experiment_clues_found.size()
	if experiment_clues_found.size() >= 10:
		client_reveal_secret_console()
	if evidence_synthesis_complete:
		_unlock_secret_door()
	if door_open and secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)

func _assign_hidden_roles() -> void:
	if not multiplayer.is_server() or traitor_role_assigned:
		return
	var participants: Array[int] = [1]
	for peer_id in multiplayer.get_peers():
		participants.append(int(peer_id))
	if participants.size() < 2:
		return # The traitor is a human player; solo play has no human traitor.
	participants.shuffle()
	traitor_peer_id = participants[0]
	traitor_role_assigned = true
	for participant_id in participants:
		var is_traitor := participant_id == traitor_peer_id
		var message := "ÉS O TRAIDOR. A VANTHIS Corporation contratou-te para impedir que provas essenciais sejam transmitidas. Apaga ou compromete registos, sabota comunicações sem seres descoberto e mantém a tua identidade em segredo." if is_traitor else "PAPEL: EXPLORADOR. Investiga a Estação Véspera, coopera com a equipa, preserva as provas e procura uma saída segura."
		if participant_id == 1:
			_show_role_notice(is_traitor, message)
		else:
			rpc_id(participant_id, "receive_secret_role", is_traitor, message)

@rpc("authority", "call_remote", "reliable")
func receive_secret_role(is_traitor: bool, message: String) -> void:
	_show_role_notice(is_traitor, message)

func _show_role_notice(is_traitor: bool, message: String) -> void:
	if role_notice_layer != null:
		role_notice_layer.queue_free()
	role_notice_layer = CanvasLayer.new()
	role_notice_layer.name = "PrivateRoleNotice"
	role_notice_layer.layer = 150
	add_child(role_notice_layer)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.008, 0.012, 0.018, 0.94)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	role_notice_layer.add_child(backdrop)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 24
	center.offset_right = -24
	center.offset_top = 24
	center.offset_bottom = -24
	role_notice_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(minf(560.0, get_viewport().get_visible_rect().size.x - 48.0), 0)
	center.add_child(panel)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 14)
	panel.add_child(stack)
	var heading := Label.new()
	heading.text = "INSTRUÇÃO CONFIDENCIAL" if is_traitor else "MISSÃO ATRIBUÍDA"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	heading.add_theme_font_size_override("font_size", 23)
	heading.add_theme_color_override("font_color", Color(0.88, 0.19, 0.15) if is_traitor else Color(0.35, 0.82, 0.88))
	stack.add_child(heading)
	var body := Label.new()
	body.text = message
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.custom_minimum_size = Vector2(0, 100)
	body.add_theme_font_size_override("font_size", 17)
	stack.add_child(body)
	var confirm := Button.new()
	confirm.text = "COMPREENDI"
	confirm.custom_minimum_size = Vector2(0, 48)
	confirm.pressed.connect(func(): role_notice_layer.queue_free(); role_notice_layer = null)
	stack.add_child(confirm)

func _on_peer_disconnected(peer_id: int) -> void:
	if remote_players.has(peer_id):
		remote_players[peer_id].queue_free()
		remote_players.erase(peer_id)	
	_last_authoritative_player_positions.erase(peer_id)
	if multiplayer.is_server():
		for key in switch_owners.keys():
			if int(switch_owners[key]) == peer_id:
				switch_owners[key] = 0
		decision_votes.erase(peer_id)
		# Recalculate the objective after a participant leaves; a disconnected peer
		# must not keep a relay or the bulkhead permanently unlocked.
		coop_solved = switch_owners["A"] != 0 and switch_owners["B"] != 0 and switch_owners["A"] != switch_owners["B"]
		_broadcast_switch_state()
	if network_status:
		network_status.text = "Jogador %d saiu" % peer_id
		_sync_network_status_to_menu()

func _process(delta: float) -> void:
	# ENet can remain in CONNECTING on some Android/network combinations.
	# Never leave the UI stuck indefinitely: stop the attempt and expose a useful status.
	if network_peer != null and network_peer.get_connection_status() == MultiplayerPeer.CONNECTION_CONNECTING:
		_client_connect_elapsed += delta
		if _client_connect_elapsed >= CLIENT_CONNECT_TIMEOUT:
			if network_peer != null:
				network_peer.close()
				network_peer = null
			multiplayer.multiplayer_peer = null
			_client_connect_elapsed = 0.0
			if network_status:
				network_status.text = "Tempo esgotado: sem resposta de %s:%d. Verifica o IP do anfitrião, desativa VPN/hotspot alternativo e confirma que o router permite comunicação entre dispositivos na UDP %d." % [ip_input.text.strip_edges() if ip_input else "anfitrião", PORT, PORT]
				_sync_network_status_to_menu()
	if multiplayer.is_server() and not entity_active:
		_update_suspense_director(delta)
	if multiplayer.multiplayer_peer == null or multiplayer.is_server():
		_update_extraction_sequence(delta)
	# Single-player traitor AI is independent from the creature AI and only runs offline.
	if multiplayer.multiplayer_peer == null and entity_active:
		_update_solo_traitor_ai(delta)
	_sync_accumulator += delta
	_lighting_time += delta
	_update_lighting_effects()
	_update_exterior_weather(delta)
	_voice_cooldown = maxf(0.0, _voice_cooldown - delta)
	creature_vocal_cooldown = maxf(0.0, creature_vocal_cooldown - delta)
	if intro_layer != null and intro_layer.visible:
		intro_elapsed = minf(INTRO_DURATION, intro_elapsed + delta)
		var intro_value := clampf(intro_elapsed / INTRO_DURATION, 0.0, 1.0)
		if intro_progress != null:
			intro_progress.value = intro_value * 100.0
		if intro_percent != null:
			intro_percent.text = "%03d%%" % int(round(intro_value * 100.0))
		if intro_elapsed >= INTRO_DURATION:
			intro_layer.visible = false
			if main_menu_layer != null:
				main_menu_layer.visible = true
	if entity_active:
		entity_motion_time += delta
		if multiplayer.is_server():
			entity_state_time += delta
			_update_shelter_weakpoint_ai(delta)
			_update_entity_ai(delta)
			_update_capture_state(delta)
			_entity_sync_accumulator += delta
			if _entity_sync_accumulator >= ENTITY_SYNC_INTERVAL:
				_entity_sync_accumulator = 0.0
				_broadcast_entity_state()
		var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
		if lamp:
			var flicker := 0.35 + absf(sin(entity_motion_time * (10.0 if entity_ai_state == "HUNT" else 6.0))) * (1.15 if entity_ai_state == "HUNT" else 0.65)
			lamp.light_energy = flicker
		_update_stealth_status()
	if _sync_accumulator >= 0.08:
		_sync_accumulator = 0.0
		_broadcast_local_state()
	if mission_hub != null and mission_hub.visible:
		_refresh_mission_hub()

func _broadcast_local_state() -> void:
	if network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED:
		return
	var player := get_node_or_null("Player") as CharacterBody3D
	if player == null:
		return
	var pitch := 0.0
	var pivot := player.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pitch = pivot.rotation.x
	var peer_id := multiplayer.get_unique_id()
	if multiplayer.is_server():
		# The host is authoritative for its own state and relays it to clients.
		rpc("receive_player_state", peer_id, player.global_position, player.rotation.y, pitch)
	else:
		# Clients submit state only to the server; they cannot directly dictate other clients' avatars.
		rpc_id(1, "submit_player_state", player.global_position, player.rotation.y, pitch)

@rpc("any_peer", "call_remote", "unreliable_ordered")
func submit_player_state(pos: Vector3, yaw: float, pitch: float) -> void:
	if not multiplayer.is_server():
		return
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id <= 1 or not remote_players.has(sender_id):
		return
	var avatar := remote_players[sender_id] as Node3D
	if avatar == null or not is_instance_valid(avatar):
		return
	# Reject implausible position jumps. The tolerance accommodates packet jitter and frame stalls.
	var previous: Vector3 = _last_authoritative_player_positions.get(sender_id, avatar.global_position)
	if previous.distance_to(pos) > 2.5:
		return
	_last_authoritative_player_positions[sender_id] = pos
	# Keep the server-side avatar current; proximity checks for relays and sounds use this node.
	avatar.global_position = pos
	avatar.rotation.y = yaw
	var server_pivot := avatar.get_node_or_null("CameraPivot") as Node3D
	if server_pivot:
		server_pivot.rotation.x = clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0))
	rpc("receive_player_state", sender_id, pos, yaw, clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0)))

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_player_state(peer_id: int, pos: Vector3, yaw: float, pitch: float) -> void:
	# Only the server relays accepted states. The RPC sender is server ID 1; retain the peer ID in the payload.
	var sender_id := multiplayer.get_remote_sender_id()
	if sender_id > 0 and sender_id != 1:
		return
	if peer_id == multiplayer.get_unique_id():
		return
	var avatar: Node3D = remote_players.get(peer_id)
	if avatar == null:
		avatar = _make_remote_avatar(peer_id)
		remote_players[peer_id] = avatar
	avatar.global_position = pos
	avatar.rotation.y = yaw
	var pivot := avatar.get_node_or_null("CameraPivot") as Node3D
	if pivot:
		pivot.rotation.x = clampf(pitch, deg_to_rad(-82.0), deg_to_rad(82.0))

func _make_remote_avatar(peer_id: int) -> Node3D:
	var avatar := Node3D.new()
	avatar.name = "RemotePlayer_%d" % peer_id
	_add_human_model(avatar, Color(0.20, 0.46, 0.58), true, true)
	var pivot := Node3D.new()
	pivot.name = "CameraPivot"
	pivot.position.y = 1.45
	avatar.add_child(pivot)
	add_child(avatar)
	return avatar

func _is_solo_session() -> bool:
	# Sem um peer ENet ligado, a partida é local: todas as ações pertencem ao jogador 1.
	return network_peer == null or network_peer.get_connection_status() != MultiplayerPeer.CONNECTION_CONNECTED

func request_switch(switch_id: String) -> void:
	_play_sfx("object_latch.wav")
	if _is_solo_session():
		_server_toggle_switch(switch_id, 1)
		return
	if multiplayer.is_server():
		_server_toggle_switch(switch_id, multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_toggle_switch", switch_id)

@rpc("any_peer", "call_remote", "reliable")
func server_toggle_switch(switch_id: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	_server_toggle_switch(switch_id, sender)

func _server_toggle_switch(switch_id: String, peer_id: int) -> void:
	if (not _is_solo_session() and not multiplayer.is_server()) or not switch_owners.has(switch_id) or coop_solved:
		return
	if peer_id <= 0:
		return
	# Validate proximity on the authority. A client cannot activate a relay remotely
	# by sending the RPC without actually being near that station.
	var actor: Node3D = null
	if peer_id == 1:
		actor = get_node_or_null("Player") as Node3D
	else:
		actor = remote_players.get(peer_id) as Node3D
	var station := get_node_or_null("CoopSwitch" + switch_id) as Node3D
	if actor == null or station == null or not is_instance_valid(actor) or not is_instance_valid(station):
		return
	if actor.global_position.distance_to(station.global_position) > 5.0:
		if peer_id == 1 or _is_solo_session():
			_set_coop_status("APROXIMA-TE DO RELÉ PARA O ATIVAR")
		return
	if switch_owners[switch_id] == peer_id:
		switch_owners[switch_id] = 0
	else:
		switch_owners[switch_id] = peer_id
	# Single-player: the same person may walk between A and B and activate both.
	# Online co-op: preserve the original requirement for two different participants.
	var both_active: bool = int(switch_owners.get("A", 0)) != 0 and int(switch_owners.get("B", 0)) != 0
	coop_solved = both_active and (_is_solo_session() or switch_owners["A"] != switch_owners["B"])
	_broadcast_switch_state()

func _broadcast_switch_state() -> void:
	_apply_switch_state(switch_owners["A"], switch_owners["B"], coop_solved)
	if not _is_solo_session() and multiplayer.is_server():
		rpc("apply_switch_state", switch_owners["A"], switch_owners["B"], coop_solved)

@rpc("authority", "call_remote", "reliable")
func apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	_apply_switch_state(owner_a, owner_b, solved)

func _apply_switch_state(owner_a: int, owner_b: int, solved: bool) -> void:
	switch_owners["A"] = owner_a
	switch_owners["B"] = owner_b
	var was_solved := coop_solved
	coop_solved = solved
	if solved and not was_solved:
		_play_context_voice("COOP_SOLVED")
	# O indicador físico e o texto do painel refletem o estado lógico replicado do relé.
	_update_relay_feedback("A", owner_a != 0)
	_update_relay_feedback("B", owner_b != 0)
	if solved:
		_set_coop_status("RELÉS A E B ATIVOS — ACESSO DESBLOQUEADO" if _is_solo_session() else "RELÉS ATIVOS POR JOGADORES DIFERENTES — CÂMARA DESBLOQUEADA")
		var door := get_node_or_null("InteractiveBulkhead")
		if door and door.has_method("open_for_coop"):
			door.open_for_coop()
	else:
		_set_coop_status("RELÉ A: %s   ·   RELÉ B: %s" % ["ATIVO" if owner_a != 0 else "PENDENTE", "ATIVO" if owner_b != 0 else "PENDENTE"])

func _update_relay_feedback(switch_id: String, active: bool) -> void:
	var station := get_node_or_null("CoopSwitch" + switch_id)
	if station == null:
		return
	var led := station.get_node_or_null("RelayStatusLED") as MeshInstance3D
	if led:
		var led_color := Color(0.12, 1.0, 0.38) if active else Color(1.0, 0.62, 0.08)
		var led_mat := _material(led_color, 0.22, 0.12)
		led_mat.emission_enabled = true
		led_mat.emission = led_color
		led_mat.emission_energy_multiplier = 2.2 if active else 0.8
		led.material_override = led_mat
	var status_label := station.get_node_or_null("RelayStateLabel") as Label3D
	if status_label:
		status_label.text = "SISTEMA ATIVO" if active else "À ESPERA"
		status_label.modulate = Color(0.35, 1.0, 0.52) if active else Color(1.0, 0.72, 0.24)
	var display := station.get_node_or_null("RelayStateDisplay") as MeshInstance3D
	if display:
		var display_color := Color(0.025, 0.20, 0.075) if active else Color(0.20, 0.12, 0.025)
		var display_mat := _material(display_color, 0.2, 0.1)
		display_mat.emission_enabled = true
		display_mat.emission = display_color
		display_mat.emission_energy_multiplier = 0.7
		display.material_override = display_mat

func _toggle_network_panel(panel: PanelContainer) -> void:
	if panel:
		panel.visible = not panel.visible

func _set_coop_status(message: String) -> void:
	if coop_status:
		coop_status.text = message

func _update_private_clue() -> void:
	if private_clue == null:
		return
	local_player_id = multiplayer.get_unique_id()
	var clue := ""
	match local_player_id:
		1:
			clue = "DOSSIÊ PRIVADO 01 — REGISTO DE CÂMARA: uma silhueta atravessou a porta às 02:13. O rosto não é identificável."
		2:
			clue = "DOSSIÊ PRIVADO 02 — REGISTO MAGNÉTICO: a porta permaneceu selada entre as 02:00 e as 02:20. Não há abertura registada."
		3:
			clue = "DOSSIÊ PRIVADO 03 — ÁUDIO RECUPERADO: às 02:13 ouvem-se duas vozes; uma diz «não o deixes entrar»."
		_:
			clue = "DOSSIÊ PRIVADO 04 — SENSOR TÉRMICO: às 02:13 foi detetado movimento, mas sem assinatura térmica humana compatível."
	private_clue.text = clue

func submit_decision(choice: String) -> void:
	if decision_resolved:
		_set_decision_status("A decisão desta missão já foi tomada.")
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	if _is_solo_session():
		# In solo, the player makes the decision; no second vote is required.
		_server_record_decision(1, choice)
		return
	if multiplayer.is_server():
		_server_record_decision(multiplayer.get_unique_id(), choice)
	else:
		rpc_id(1, "server_record_decision", choice)
	_set_decision_status("Voto registado em privado. Compara as provas antes de decidirem.")

@rpc("any_peer", "call_remote", "reliable")
func server_record_decision(choice: String) -> void:
	if not multiplayer.is_server() or decision_resolved:
		return
	if choice != "ACUSAR" and choice != "DEFENDER":
		return
	var sender := multiplayer.get_remote_sender_id()
	if sender <= 0:
		return
	_server_record_decision(sender, choice)

func _server_record_decision(peer_id: int, choice: String) -> void:
	if decision_resolved or peer_id <= 0:
		return
	decision_votes[peer_id] = choice
	var eligible := 1
	if not _is_solo_session() and network_peer != null:
		eligible = max(1, network_peer.get_peers().size() + 1)
	if decision_votes.size() < min(2, eligible):
		_broadcast_decision_status("Votos recebidos: %d/%d. Falta ouvir outro jogador." % [decision_votes.size(), min(2, eligible)])
		return
	var accuse_count := 0
	var defend_count := 0
	for vote in decision_votes.values():
		if vote == "ACUSAR":
			accuse_count += 1
		else:
			defend_count += 1
	decision_resolved = true
	var outcome := ""
	if accuse_count > defend_count:
		outcome = "CONSEQUÊNCIA: ACUSAÇÃO — o alarme dispara e a estação entra em contenção. A equipa perde a confiança do operador."
		_set_alarm_state(true)
	elif defend_count > accuse_count:
		outcome = "CONSEQUÊNCIA: DEFESA — o operador mantém acesso, mas uma porta secundária desbloqueia-se sem explicação."
		_set_alarm_state(false)
	else:
		outcome = "CONSEQUÊNCIA: DIVISÃO — sem consenso, o sistema entra em bloqueio e a luz de emergência falha."
		_set_alarm_state(true)
	_broadcast_decision_result(outcome)

func _broadcast_decision_status(message: String) -> void:
	_set_decision_status(message)
	if not _is_solo_session() and multiplayer.is_server():
		rpc("apply_decision_status", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_status(message: String) -> void:
	_set_decision_status(message)

func _broadcast_decision_result(message: String) -> void:
	_apply_decision_result(message)
	if not _is_solo_session() and multiplayer.is_server():
		rpc("apply_decision_result", message)

@rpc("authority", "call_remote", "reliable")
func apply_decision_result(message: String) -> void:
	_apply_decision_result(message)

func _apply_decision_result(message: String) -> void:
	decision_resolved = true
	_activate_entity_reaction(message)
	_set_decision_status(message)
	_set_alarm_state(message.begins_with("CONSEQUÊNCIA: ACUSAÇÃO") or message.begins_with("CONSEQUÊNCIA: DIVISÃO"))
	if accusation_button:
		accusation_button.disabled = true
	if defense_button:
		defense_button.disabled = true

func _update_suspense_director(delta: float) -> void:
	# Os sinais ambientais podem surgir com intervalos variáveis, mas nunca
	# forçam a aparição da criatura por decurso de tempo.
	suspense_elapsed += delta
	if suspense_elapsed >= suspense_next_event:
		if entity_reaction_label:
			entity_reaction_label.text = suspense_messages[suspense_event_index % suspense_messages.size()]
		suspense_event_index += 1
		suspense_next_event = suspense_elapsed + suspense_rng.randf_range(28.0, 48.0)
		if suspense_event_index % 2 == 0:
			_play_sfx("relay_click.wav")

func _activate_entity_reaction(outcome: String) -> void:
	# A criatura não é revelada por um temporizador. A sua aparição depende
	# de acontecimentos narrativos e de ações da investigação, nunca apenas do tempo.
	if outcome.begins_with("DELAYED:"):
		outcome = outcome.trim_prefix("DELAYED:")
	if outcome != "INITIAL_PATROL":
		_play_sfx("entity_sting.wav")
	if entity_active:
		return
	entity_active = true
	var room := get_node_or_null("ResearchStationRoom") as Node3D
	if room == null:
		return
	# A distant, deliberately ambiguous silhouette appears only after the team's decision.
	entity_presence = Node3D.new()
	entity_presence.name = "UnidentifiedPresence"
	entity_presence.position = entity_waypoints[entity_waypoint_index]
	room.add_child(entity_presence)
	var entity_model := Node3D.new()
	entity_model.name = "EntityCreatureModel"
	entity_model.position.y = 0.82
	entity_presence.add_child(entity_model)
	_add_creature_model(entity_model)
	entity_model.set_script(MODEL_ANIMATOR_SCRIPT)
	entity_model.set("creature_mode", true)
	var collision := StaticBody3D.new()
	collision.name = "EntityCollision"
	var collision_shape := CollisionShape3D.new()
	var collision_capsule := CapsuleShape3D.new()
	collision_capsule.radius = 0.34
	collision_capsule.height = 1.9
	collision_shape.shape = collision_capsule
	collision_shape.position.y = 1.0
	collision.add_child(collision_shape)
	entity_presence.add_child(collision)
	entity_ai_state = "PATROL"
	entity_state_time = 0.0
	if entity_reaction_label:
		if outcome.begins_with("CONSEQUÊNCIA: ACUSAÇÃO"):
			entity_reaction_label.text = "SINAL HOSTIL: a contenção chamou algo até à estação."
		elif outcome.begins_with("CONSEQUÊNCIA: DEFESA"):
			entity_reaction_label.text = "SINAL ANÓMALO: a presença apareceu depois de manterem o acesso."
		elif outcome == "INITIAL_PATROL":
			entity_reaction_label.text = "A estação permanece em silêncio. Há movimento não confirmado nos corredores."
		else:
			entity_reaction_label.text = "SINAL CRÍTICO: foi detetada uma anomalia na estação."

func _update_solo_traitor_ai(delta: float) -> void:
	# This character is never assigned to the player and is never the creature.
	# It manipulates station systems and leaves ambiguous evidence; it does not
	# reveal its identity in the public mission UI.
	solo_traitor_timer += delta
	if solo_traitor_glimpse_timer > 0.0:
		solo_traitor_glimpse_timer = maxf(0.0, solo_traitor_glimpse_timer - delta)
		if solo_traitor_glimpse_timer == 0.0 and solo_traitor_presence:
			solo_traitor_presence.visible = false
	if solo_traitor_timer < solo_traitor_next_action:
		return
	solo_traitor_timer = 0.0
	solo_traitor_next_action = solo_traitor_rng.randf_range(34.0, 52.0)
	solo_traitor_sabotages += 1
	# Sabotage is a temporary systems disturbance, not an arbitrary death or attack.
	_set_alarm_state(true)
	if entity_reaction_label:
		var messages := [
			"REGISTO ANÓMALO: uma ordem de manutenção foi executada sem credenciais válidas.",
			"COMUNICAÇÕES: pacote de diagnóstico alterado. A origem não foi identificada.",
			"ENERGIA: um circuito foi isolado manualmente. Não existe operador registado.",
			"SEGURANÇA: acesso autorizado com uma credencial que deveria estar desativada."
		]
		entity_reaction_label.text = messages[(solo_traitor_sabotages - 1) % messages.size()]
	# A brief human silhouette may be seen at a distant waypoint; no label identifies it.
	if solo_traitor_presence == null:
		solo_traitor_presence = Node3D.new()
		solo_traitor_presence.name = "UnidentifiedStaffSilhouette"
		var room := get_node_or_null("ResearchStationRoom") as Node3D
		if room:
			room.add_child(solo_traitor_presence)
			var model := Node3D.new()
			model.name = "StaffSilhouetteModel"
			model.position.y = 0.82
			solo_traitor_presence.add_child(model)
			_add_human_model(model, Color(0.10, 0.16, 0.19), true)
			model.set_script(MODEL_ANIMATOR_SCRIPT)
			var coat := StandardMaterial3D.new()
			coat.albedo_color = Color(0.035, 0.055, 0.065)
			coat.roughness = 0.95
			for child in model.get_children():
				if child is MeshInstance3D:
					child.material_override = coat
	var waypoint := solo_traitor_rng.randi_range(0, entity_waypoints.size() - 1)
	solo_traitor_presence.position = entity_waypoints[waypoint] + Vector3(0.0, 0.0, -1.2)
	solo_traitor_presence.visible = true
	solo_traitor_glimpse_timer = 2.2
	# The sabotage signal is transient. The player must investigate the evidence.
	get_tree().create_timer(5.0).timeout.connect(func():
		if is_instance_valid(self):
			_set_alarm_state(false)
	)

func _play_creature_vocal(context: String) -> void:
	# Use varied existing non-verbal clips, with pitch and timing variation to avoid a looped cue.
	if creature_vocal_cooldown > 0.0 or voice_player == null:
		return
	var clips := ["voice_groan.wav", "voice_choked_gasp.wav", "voice_distant_whisper.wav", "voice_breathing.wav"]
	if context == "DANGER":
		clips = ["voice_groan.wav", "voice_scream.wav", "voice_choked_gasp.wav"]
	var pick := suspense_rng.randi_range(0, clips.size() - 1)
	if clips.size() > 1 and pick == creature_vocal_index:
		pick = (pick + suspense_rng.randi_range(1, clips.size() - 1)) % clips.size()
	creature_vocal_index = pick
	var stream := load("res://audio/" + clips[pick]) as AudioStream
	if stream == null:
		return
	voice_player.stream = stream
	voice_player.pitch_scale = suspense_rng.randf_range(0.78, 1.16)
	voice_player.volume_db = -13.0 if context == "DISTANT" else -8.0
	voice_player.play()
	creature_vocal_cooldown = suspense_rng.randf_range(9.0, 18.0) if context == "DISTANT" else suspense_rng.randf_range(6.0, 12.0)

func _update_entity_ai(delta: float) -> void:
	# The host is the only authority allowed to decide AI movement/state.
	if not multiplayer.is_server() or entity_presence == null:
		return
	var player := _find_entity_target()
	if player == null:
		return
	var distance_to_player := entity_presence.global_position.distance_to(player.global_position)
	# Se o jogador estiver no abrigo, a criatura não o pode atacar nem atravessar as paredes.
	# Em vez de acampar na porta, abandona a zona e retoma a patrulha.
	if _is_player_inside_safe_shelter(player):
		var shelter_exit := safe_shelter.to_global(Vector3(0.0, 0.0, 3.35)) if safe_shelter else Vector3(0.0, 0.0, -25.65)
		var at_shelter := entity_presence.global_position.distance_to(shelter_exit) < 4.5
		# A criatura pode pressionar o ponto fraco por tempo limitado, mas não pode acampar.
		if at_shelter and not shelter_lock_damaged and shelter_creature_pressure < 9.0:
			return
		if at_shelter:
			entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
			entity_ai_state = "PATROL"
			entity_state_time = 0.0
			entity_presence.global_position = entity_waypoints[entity_waypoint_index]
			entity_presence.visible = true
			if entity_reaction_label:
				entity_reaction_label.text = "MOVIMENTO AFASTADO. A presença abandonou a entrada do abrigo."
		return
	var observed := _is_entity_observed(player)
	var player_speed := 0.0
	if player is CharacterBody3D:
		player_speed = Vector2((player as CharacterBody3D).velocity.x, (player as CharacterBody3D).velocity.z).length()
	var crouching := bool(player.get("is_crouching")) if player.get("is_crouching") != null else false
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	var illuminated := _is_entity_lit_by_player(player, flashlight)
	# Fast movement creates noise; crouching reduces the detection radius. A beam on the entity can provoke it.
	if observed and distance_to_player < 19.0:
		entity_ai_state = "OBSERVED"
		_play_context_voice("OBSERVED")
		entity_hidden_time = 2.6
		entity_presence.visible = false
		entity_state_time = 0.0
		if entity_reaction_label:
			entity_reaction_label.text = "A PRESENÇA DESAPARECEU QUANDO A OBSERVASTE. O ruído continua no corredor…"
		return
	if entity_ai_state == "OBSERVED":
		entity_hidden_time -= delta
		if entity_hidden_time <= 0.0:
			entity_ai_state = "PATROL"
			entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
			entity_presence.position = entity_waypoints[entity_waypoint_index]
			entity_presence.visible = true
			entity_state_time = 0.0
			if entity_reaction_label:
				entity_reaction_label.text = "MOVIMENTO DETETADO NOUTRA ZONA. A entidade mudou de posição."
		return
	var noise_radius := 5.0 if crouching else 13.0
	var old_state := entity_ai_state
	if (player_speed > 2.25 and not crouching and distance_to_player < noise_radius) or (illuminated and distance_to_player < 15.0):
		entity_ai_state = "HUNT"
	else:
		entity_ai_state = "PATROL"
	if entity_ai_state == "HUNT" and old_state != "HUNT":
		_play_sfx("danger_pulse.wav")
		_play_context_voice("HUNT")
		_play_creature_vocal("DANGER")
	elif entity_ai_state == "PATROL" and old_state != "PATROL":
		_play_creature_vocal("DISTANT")
	elif entity_ai_state == "PATROL" and suspense_rng.randf() < delta * 0.025:
		_play_creature_vocal("DISTANT")
	var target := entity_waypoints[entity_waypoint_index]
	if entity_ai_state == "HUNT" and distance_to_player > 3.4:
		# A lit target is more compelling than sound alone, but crouching still lowers noise.
		target = player.global_position
	elif entity_presence.global_position.distance_to(target) < 0.7:
		entity_waypoint_index = (entity_waypoint_index + 1) % entity_waypoints.size()
		target = entity_waypoints[entity_waypoint_index]
	var flat_target := Vector3(target.x, entity_presence.position.y, target.z)
	var step := 1.35 if entity_ai_state == "PATROL" else 2.15
	entity_presence.global_position = entity_presence.global_position.move_toward(flat_target, step * delta)
	if entity_presence.global_position.distance_to(player.global_position) < 1.15 and capture_target_peer_id == 0:
		_begin_player_capture(player)
		return
	if entity_presence.global_position.distance_to(player.global_position) < 1.35:
		if entity_ai_state != "ATTACK_WARNING":
			_play_sfx("danger_pulse.wav")
			_play_context_voice("ATTACK_WARNING")
			_play_creature_vocal("DANGER")
		entity_ai_state = "ATTACK_WARNING"
		if entity_reaction_label:
			entity_reaction_label.text = "PERIGO IMEDIATO: a presença chegou demasiado perto. Recuem e não façam ruído."
	elif entity_ai_state == "HUNT" and entity_reaction_label and entity_state_time > 1.8 and Time.get_ticks_msec() / 1000.0 - entity_last_notice > 2.5:
		entity_reaction_label.text = "A ENTIDADE DETETOU %s. %s" % ["a luz da lanterna" if illuminated else "o ruído", "Desliga a lanterna e agacha-te." if illuminated else "Agacha-te para reduzir o ruído."]
		entity_last_notice = Time.get_ticks_msec() / 1000.0

func _peer_id_for_player(player: Node3D) -> int:
	if player == get_node_or_null("Player"):
		return 1
	for key in remote_players.keys():
		if remote_players[key] == player:
			return int(key)
	return 0

func _begin_player_capture(player: Node3D) -> void:
	if not multiplayer.is_server() or capture_target_peer_id != 0 or player == null:
		return
	var peer_id := _peer_id_for_player(player)
	if peer_id == 0 or eliminated_peers.has(peer_id):
		return
	capture_target_peer_id = peer_id
	capture_target_node = player
	capture_elapsed = 0.0
	capture_escape_presses = 0
	entity_ai_state = "CAPTURE"
	if entity_reaction_label:
		entity_reaction_label.text = "A CRIATURA AGARROU UM EXPLORADOR. LIBERTA-TE!"
	_apply_capture_state_to_peer(peer_id, true, false, "A CRIATURA AGARROU-TE! TOCA RAPIDAMENTE PARA TE LIBERTARES.")
	if peer_id != 1 and network_peer != null:
		rpc_id(peer_id, "client_capture_state", true, false, "A CRIATURA AGARROU-TE! TOCA RAPIDAMENTE PARA TE LIBERTARES.")
	elif peer_id == 1:
		_apply_capture_state_to_peer(1, true, false, "A CRIATURA AGARROU-TE! TOCA RAPIDAMENTE PARA TE LIBERTARES.")

func _apply_capture_state_to_peer(peer_id: int, captured: bool, eliminated: bool, message: String) -> void:
	if peer_id == 1:
		var local_player := get_node_or_null("Player")
		if local_player and local_player.has_method("set_capture_state"):
			local_player.call("set_capture_state", captured, eliminated)
		if capture_overlay:
			capture_overlay.visible = captured or eliminated
		if capture_message:
			capture_message.text = message
		if capture_button:
			capture_button.visible = captured and not eliminated

func _update_capture_state(delta: float) -> void:
	if not multiplayer.is_server() or capture_target_peer_id == 0:
		return
	capture_elapsed += delta
	if capture_target_node == null or not is_instance_valid(capture_target_node):
		_finish_capture(false)
		return
	if capture_escape_presses >= CAPTURE_ESCAPE_PRESSES and capture_elapsed <= CAPTURE_ESCAPE_SECONDS:
		_finish_capture(true)
	elif capture_elapsed >= CAPTURE_ESCAPE_SECONDS:
		_finish_capture(false)

func request_capture_escape() -> void:
	# Clients do not hold the authoritative target ID; the server validates the sender.
	if _is_solo_session() or multiplayer.is_server():
		_server_capture_escape(1)
	else:
		rpc_id(1, "server_capture_escape")

@rpc("any_peer", "call_remote", "reliable")
func server_capture_escape() -> void:
	if not multiplayer.is_server():
		return
	_server_capture_escape(multiplayer.get_remote_sender_id())

func _server_capture_escape(peer_id: int) -> void:
	if capture_target_peer_id != peer_id or capture_elapsed > CAPTURE_ESCAPE_SECONDS:
		return
	capture_escape_presses += 1
	var progress_text := "LIBERTAÇÃO: %d/%d" % [capture_escape_presses, CAPTURE_ESCAPE_PRESSES]
	if peer_id == 1:
		if capture_message:
			capture_message.text = progress_text + " — CONTINUA!"
	else:
		rpc_id(peer_id, "client_capture_progress", progress_text)

func _finish_capture(escaped: bool) -> void:
	var peer_id := capture_target_peer_id
	if peer_id == 0:
		return
	capture_target_peer_id = 0
	capture_elapsed = 0.0
	capture_escape_presses = 0
	if escaped:
		_apply_capture_state_to_peer(peer_id, false, false, "LIBERTASTE-TE! FOGE AGORA.")
		if peer_id != 1 and network_peer != null:
			rpc_id(peer_id, "client_capture_state", false, false, "LIBERTASTE-TE! FOGE AGORA.")
		entity_ai_state = "HUNT"
		entity_state_time = 0.0
		# Pequena janela de fuga: a entidade recua para retomar a perseguição.
		if entity_presence:
			entity_presence.global_position += (entity_presence.global_position - capture_target_node.global_position).normalized() * 2.5
	else:
		eliminated_peers[peer_id] = true
		_apply_capture_state_to_peer(peer_id, false, true, "FOSTE ELIMINADO. A EQUIPA PODE CONTINUAR A MISSÃO.")
		if peer_id != 1 and network_peer != null:
			rpc_id(peer_id, "client_capture_state", false, true, "FOSTE ELIMINADO. A EQUIPA PODE CONTINUAR A MISSÃO.")
		entity_ai_state = "HUNT"
		entity_state_time = 0.0
	capture_target_node = null

@rpc("authority", "call_remote", "reliable")
func client_capture_state(captured: bool, eliminated: bool, message: String) -> void:
	if multiplayer.is_server():
		return
	var local_player := get_node_or_null("Player")
	if local_player and local_player.has_method("set_capture_state"):
		local_player.call("set_capture_state", captured, eliminated)
	if capture_overlay:
		capture_overlay.visible = captured or eliminated
	if capture_message:
		capture_message.text = message
	if capture_button:
		capture_button.visible = captured and not eliminated

@rpc("authority", "call_remote", "reliable")
func client_capture_progress(message: String) -> void:
	if multiplayer.is_server():
		return
	if capture_message:
		capture_message.text = message

func _find_entity_target() -> Node3D:
	var best: Node3D = get_node_or_null("Player") as Node3D
	var best_distance := INF
	if best != null and is_instance_valid(best):
		best_distance = entity_presence.global_position.distance_to(best.global_position)
	for peer_id in remote_players.keys():
		var candidate := remote_players[peer_id] as Node3D
		if candidate == null or not is_instance_valid(candidate):
			continue
		var distance := entity_presence.global_position.distance_to(candidate.global_position)
		if distance < best_distance:
			best = candidate
			best_distance = distance
	return best

func _broadcast_entity_state() -> void:
	if not multiplayer.is_server() or entity_presence == null:
		return
	rpc("receive_entity_state", entity_presence.global_position, entity_presence.visible, entity_ai_state, entity_waypoint_index, entity_hidden_time, entity_state_time, entity_reaction_label.text if entity_reaction_label else "")

func _send_entity_state_to(peer_id: int) -> void:
	if not multiplayer.is_server() or entity_presence == null:
		return
	rpc_id(peer_id, "receive_entity_state", entity_presence.global_position, entity_presence.visible, entity_ai_state, entity_waypoint_index, entity_hidden_time, entity_state_time, entity_reaction_label.text if entity_reaction_label else "")

@rpc("authority", "call_remote", "unreliable_ordered")
func receive_entity_state(position: Vector3, visible: bool, ai_state: String, waypoint_index: int, hidden_time: float, state_time: float, reaction_text: String) -> void:
	# Clients render the host's snapshot; they never simulate or decide the creature AI.
	if multiplayer.is_server():
		return
	if entity_presence == null:
		_activate_entity_reaction("INITIAL_PATROL")
	if entity_presence == null:
		return
	entity_active = true
	entity_presence.global_position = position
	entity_presence.visible = visible
	entity_ai_state = ai_state
	entity_waypoint_index = waypoint_index
	entity_hidden_time = hidden_time
	entity_state_time = state_time
	if entity_reaction_label and not reaction_text.is_empty():
		entity_reaction_label.text = reaction_text

func _is_entity_lit_by_player(player: Node3D, flashlight: SpotLight3D) -> bool:
	if flashlight == null or not flashlight.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - flashlight.global_position
	if to_entity.length() > flashlight.spot_range:
		return false
	var forward := -flashlight.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < cos(deg_to_rad(flashlight.spot_angle * 0.5)):
		return false
	var query := PhysicsRayQueryParameters3D.create(flashlight.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _update_stealth_status() -> void:
	if stealth_status == null:
		return
	var player := get_node_or_null("Player")
	if player == null:
		return
	var crouching := bool(player.get("is_crouching"))
	var flashlight := player.get_node_or_null("CameraPivot/Camera3D/Flashlight") as SpotLight3D
	stealth_status.text = "FURTIVIDADE: AGACHADO · RUÍDO BAIXO" if crouching else "FURTIVIDADE: DE PÉ · RUÍDO ELEVADO"
	if flashlight and flashlight.visible:
		stealth_status.text += " · LANTERNA LIGADA"

func _is_entity_observed(player: Node3D) -> bool:
	var camera := player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
	if camera == null or not entity_presence.visible:
		return false
	var to_entity := entity_presence.global_position + Vector3(0.0, 1.0, 0.0) - camera.global_position
	if to_entity.length() > 17.0:
		return false
	var forward := -camera.global_transform.basis.z.normalized()
	if forward.dot(to_entity.normalized()) < 0.965:
		return false
	var query := PhysicsRayQueryParameters3D.create(camera.global_position, entity_presence.global_position + Vector3(0.0, 1.0, 0.0))
	query.exclude = [player]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or (hit.collider is Node and entity_presence.is_ancestor_of(hit.collider))

func _set_decision_status(message: String) -> void:
	if decision_status:
		decision_status.text = message

func _set_alarm_state(active: bool) -> void:
	_alarm_active = active
	var lamp := get_node_or_null("ResearchStationRoom/FailingEmergencyLamp") as OmniLight3D
	if lamp:
		lamp.light_color = Color(1.0, 0.025, 0.01) if active else (Color(0.1, 0.9, 0.35) if coop_solved else Color(0.18, 0.48, 0.72))
		lamp.light_energy = 1.35 if active else (0.9 if coop_solved else 0.45)
	var beacon := get_node_or_null("ResearchStationRoom/AlarmBeacon") as OmniLight3D
	if beacon:
		beacon.visible = active
	var beacon_mesh := get_node_or_null("ResearchStationRoom/AlarmBeacon/BeaconMesh") as MeshInstance3D
	if beacon_mesh:
		beacon_mesh.visible = active

func _update_lighting_effects() -> void:
	# LEDs and luminaires respond to danger, relays and the emergency state.
	var room := get_node_or_null("ResearchStationRoom")
	if room == null:
		return
	var lamp := room.get_node_or_null("FailingEmergencyLamp") as OmniLight3D
	if lamp and entity_active:
		var speed := 15.0 if entity_ai_state == "HUNT" else 7.0
		var depth := 1.0 if entity_ai_state == "HUNT" else 0.45
		lamp.light_energy = (0.42 + absf(sin(_lighting_time * speed)) * depth) if not _alarm_active else (0.3 + absf(sin(_lighting_time * 13.0)) * 1.45)
	# A segunda luminária falha de forma irregular; o painel emissivo acompanha a luz.
	var intermittent := room.get_node_or_null("IntermittentCeilingLamp") as OmniLight3D
	if intermittent:
		var pulse := absf(sin(_lighting_time * 8.7) * cos(_lighting_time * 3.1))
		intermittent.light_energy = 0.0 if pulse < 0.28 else (0.25 + pulse * 0.9)
	var intermittent_panel := room.get_node_or_null("IntermittentLEDPanel") as MeshInstance3D
	if intermittent_panel and intermittent_panel.material_override is StandardMaterial3D:
		var panel_material := intermittent_panel.material_override as StandardMaterial3D
		var panel_on := absf(sin(_lighting_time * 8.7) * cos(_lighting_time * 3.1)) >= 0.28
		panel_material.emission_energy_multiplier = 1.0 if panel_on else 0.02
	var strip_a := room.get_node_or_null("LEDStripA") as MeshInstance3D
	var strip_b := room.get_node_or_null("LEDStripB") as MeshInstance3D
	var led_color := Color(1.0, 0.025, 0.01) if _alarm_active else (Color(0.05, 1.0, 0.35) if coop_solved else Color(0.05, 0.65, 1.0))
	for strip in [strip_a, strip_b]:
		if strip and strip.material_override is StandardMaterial3D:
			var mat := strip.material_override as StandardMaterial3D
			mat.albedo_color = led_color
			mat.emission = led_color
			mat.emission_energy_multiplier = 1.8 if not _alarm_active else (0.6 + absf(sin(_lighting_time * 12.0)) * 3.5)
	var exit_light := room.get_node_or_null("ExitIndicatorLight") as OmniLight3D
	if exit_light:
		exit_light.light_color = Color(0.05, 1.0, 0.25) if coop_solved else Color(0.1, 0.65, 0.35)
		exit_light.light_energy = 1.3 if coop_solved else 0.45

func _build_environment() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.015, 0.025, 0.04)
	sky_mat.sky_horizon_color = Color(0.06, 0.065, 0.07)
	sky_mat.ground_bottom_color = Color(0.008, 0.01, 0.012)
	sky_mat.ground_horizon_color = Color(0.035, 0.04, 0.045)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_color = Color(0.34, 0.40, 0.49)
	env.ambient_light_energy = 0.72
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	# Névoa polar atmosférica: melhora a profundidade sem efeitos volumétricos pesados.
	env.fog_enabled = true
	env.fog_light_color = Color(0.43, 0.52, 0.62)
	env.fog_light_energy = 0.72
	env.fog_density = 0.0065
	env.fog_sky_affect = 0.18
	# Bloom discreto para LEDs e alarmes; controlado para GPUs móveis.
	env.glow_enabled = true
	env.glow_intensity = 0.32
	env.glow_strength = 0.55
	env.glow_bloom = 0.06
	env.glow_hdr_threshold = 1.35
	world.environment = env
	add_child(world)
	var moon := DirectionalLight3D.new()
	moon.rotation_degrees = Vector3(-42, -25, 0)
	moon.light_color = Color(0.52, 0.61, 0.78)
	moon.light_energy = 0.46
	moon.shadow_enabled = true
	add_child(moon)
	var fill_light := OmniLight3D.new()
	fill_light.name = "RoomFillLight"
	fill_light.position = Vector3(0, 2.7, -2.5)
	fill_light.light_color = Color(0.48, 0.57, 0.66)
	fill_light.light_energy = 0.7
	fill_light.omni_range = 13.0
	fill_light.shadow_enabled = false
	add_child(fill_light)


func _build_exterior_world() -> void:
	# Zona exterior explorável ligada ao corredor de saída existente (aprox. z=-16.8).
	var outdoors := Node3D.new()
	outdoors.name = "PolarExterior"
	add_child(outdoors)
	var snow := _material(Color(0.48, 0.57, 0.63), 0.96, 0.0)
	var packed_snow := _material(Color(0.25, 0.32, 0.37), 0.94, 0.0)
	var dark_metal := _material(Color(0.075, 0.105, 0.125), 0.72, 0.62)
	var warning := StandardMaterial3D.new()
	warning.albedo_color = Color(0.12, 0.72, 0.82)
	warning.emission_enabled = true
	warning.emission = Color(0.02, 0.42, 0.58)
	warning.emission_energy_multiplier = 1.4
	# Snowfield begins at the corridor mouth and extends into an explorable yard.
	_box(outdoors, "ExteriorSnowfield", Vector3(64, 0.3, 78), Vector3(0, -0.15, -39), snow)
	_box(outdoors, "PackedPathToGenerator", Vector3(5.0, 0.035, 34), Vector3(0, -0.105, -37), packed_snow, false)
	# Snow banks frame the playable route without sealing it.
	for i in range(9):
		var side := -1.0 if i % 2 == 0 else 1.0
		var z := -23.0 - float(i) * 5.2
		var drift := _box(outdoors, "SnowDrift_%02d" % i, Vector3(3.2, 0.9 + float(i % 3) * 0.25, 2.8), Vector3(side * (5.4 + float(i % 2)), 0.1, z), snow, false)
		drift.rotation_degrees.z = side * float(4 + i % 5)
	# Montes de neve arredondados para quebrar a silhueta geométrica do cenário.
	for i in range(7):
		var mound := MeshInstance3D.new()
		mound.name = "RoundedSnowMound_%02d" % i
		var mound_mesh := SphereMesh.new()
		mound_mesh.radius = 1.0
		mound_mesh.height = 2.0
		mound.mesh = mound_mesh
		mound.scale = Vector3(2.4 + float(i % 3) * 0.55, 0.48 + float(i % 2) * 0.18, 1.8 + float(i % 2) * 0.4)
		mound.position = Vector3((-1.0 if i % 2 == 0 else 1.0) * (7.2 + float(i % 3) * 1.4), 0.04, -25.0 - float(i) * 4.2)
		mound.material_override = snow
		outdoors.add_child(mound)
	# Silhuetas de gelo facetado para quebrar a repetição de blocos no horizonte.
	var ice_mat := _material(Color(0.31, 0.43, 0.51), 0.3, 0.16)
	ice_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ice_mat.albedo_color.a = 0.82
	for i in range(11):
		var shard := MeshInstance3D.new()
		shard.name = "PolarIceSpire_%02d" % i
		var shard_mesh := CylinderMesh.new()
		shard_mesh.top_radius = 0.04 + float(i % 3) * 0.035
		shard_mesh.bottom_radius = 0.38 + float(i % 4) * 0.12
		shard_mesh.height = 1.6 + float(i % 5) * 0.48
		shard.mesh = shard_mesh
		shard.material_override = ice_mat
		var side := -1.0 if i % 2 == 0 else 1.0
		shard.position = Vector3(side * (10.5 + float(i % 3) * 2.0), shard_mesh.height * 0.5 - 0.03, -24.0 - float(i) * 3.15)
		shard.rotation_degrees.z = side * float(4 + i % 7)
		outdoors.add_child(shard)
	# Marcos de orientação industriais, legíveis sem depender de texto pequeno.
	var sign_back := _material(Color(0.035, 0.075, 0.09), 0.62, 0.48)
	var sign_glow := StandardMaterial3D.new()
	sign_glow.albedo_color = Color(0.08, 0.65, 0.78)
	sign_glow.emission_enabled = true
	sign_glow.emission = Color(0.025, 0.42, 0.58)
	sign_glow.emission_energy_multiplier = 1.25
	_box(outdoors, "GeneratorDirectionSign", Vector3(1.55, 0.62, 0.09), Vector3(-4.5, 2.05, -25.0), sign_back, false)
	_box(outdoors, "GeneratorDirectionArrow", Vector3(0.68, 0.075, 0.035), Vector3(-4.5, 2.05, -24.94), sign_glow, false)
	_box(outdoors, "GeneratorDirectionArrowHead", Vector3(0.16, 0.23, 0.035), Vector3(-4.18, 2.05, -24.94), sign_glow, false)
	# Industrial generator shed, physically reachable along the path.
	_box(outdoors, "GeneratorShedBody", Vector3(5.8, 3.2, 5.0), Vector3(-7.2, 1.35, -42), dark_metal)
	_box(outdoors, "GeneratorShedRoofSnow", Vector3(6.1, 0.22, 5.3), Vector3(-7.2, 3.05, -42), snow, false)
	_box(outdoors, "GeneratorDoor", Vector3(1.55, 2.35, 0.12), Vector3(-7.2, 1.15, -39.43), packed_snow, false)
	_box(outdoors, "GeneratorVentA", Vector3(0.85, 0.72, 0.12), Vector3(-8.9, 2.2, -39.36), dark_metal, false)
	_box(outdoors, "GeneratorVentB", Vector3(0.85, 0.72, 0.12), Vector3(-5.5, 2.2, -39.36), dark_metal, false)
	# Antenna mast and a distant instrument pole provide scale and navigation landmarks.
	_box(outdoors, "WeatherAntennaMast", Vector3(0.16, 7.5, 0.16), Vector3(8.8, 3.55, -49), dark_metal, false)
	_box(outdoors, "WeatherAntennaCrossbar", Vector3(2.3, 0.12, 0.12), Vector3(8.8, 6.1, -49), dark_metal, false)
	_box(outdoors, "WeatherInstrumentPole", Vector3(0.12, 3.8, 0.12), Vector3(12.5, 1.7, -31), dark_metal, false)
	_box(outdoors, "WeatherInstrumentHead", Vector3(0.8, 0.32, 0.8), Vector3(12.5, 3.65, -31), warning, false)
	# Low cyan guide lights remain visible through snow, but do not reveal the creature.
	for i in range(6):
		var guide := OmniLight3D.new()
		guide.name = "ExteriorGuideLight_%02d" % i
		guide.position = Vector3(0, 0.28, -22.0 - float(i) * 5.1)
		guide.light_color = Color(0.15, 0.72, 0.9)
		guide.light_energy = 0.48
		guide.omni_range = 3.4
		guide.shadow_enabled = false
		outdoors.add_child(guide)
		_box(outdoors, "ExteriorGuideMarker_%02d" % i, Vector3(0.22, 0.42, 0.22), Vector3(0, 0.12, -22.0 - float(i) * 5.1), warning, false)
	# Snow particles: wind-driven, volumetric box emitter around the yard.
	exterior_weather_particles = GPUParticles3D.new()
	exterior_weather_particles.name = "PolarSnowfall"
	exterior_weather_particles.amount = 520
	exterior_weather_particles.lifetime = 6.5
	exterior_weather_particles.preprocess = 2.0
	exterior_weather_particles.position = Vector3(0, 5.0, -39)
	var process_material := ParticleProcessMaterial.new()
	process_material.emission_shape = ParticleProcessMaterial.EMISSION_SHAPE_BOX
	process_material.emission_box_extents = Vector3(25, 7, 27)
	process_material.direction = Vector3(-1.0, -0.22, -0.18)
	process_material.spread = 18.0
	process_material.initial_velocity_min = 2.2
	process_material.initial_velocity_max = 5.8
	process_material.gravity = Vector3(-1.8, -1.2, -0.4)
	process_material.scale_min = 0.035
	process_material.scale_max = 0.085
	process_material.color = Color(0.82, 0.91, 1.0, 0.78)
	exterior_weather_particles.process_material = process_material
	var snow_mesh := SphereMesh.new()
	snow_mesh.radius = 0.035
	snow_mesh.height = 0.07
	var snow_visual := StandardMaterial3D.new()
	snow_visual.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	snow_visual.albedo_color = Color(0.82, 0.91, 1.0, 0.8)
	snow_visual.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	snow_mesh.material = snow_visual
	exterior_weather_particles.draw_pass_1 = snow_mesh
	outdoors.add_child(exterior_weather_particles)
	# A warm warning beacon marks the generator shed; intensity changes with gusts.
	exterior_beacon = OmniLight3D.new()
	exterior_beacon.name = "ExteriorStormBeacon"
	exterior_beacon.position = Vector3(-7.2, 3.35, -42)
	exterior_beacon.light_color = Color(1.0, 0.28, 0.08)
	exterior_beacon.light_energy = 0.75
	exterior_beacon.omni_range = 8.0
	exterior_beacon.shadow_enabled = false
	outdoors.add_child(exterior_beacon)
	# Ponto de extração visível no exterior, afastado do abrigo e do gerador.
	extraction_landing_marker = Node3D.new()
	extraction_landing_marker.name = "ExtractionLandingZone"
	extraction_landing_marker.position = Vector3(0.0, 0.0, -56.0)
	var landing_ring := MeshInstance3D.new()
	var ring_mesh := CylinderMesh.new()
	ring_mesh.top_radius = 2.8
	ring_mesh.bottom_radius = 2.8
	ring_mesh.height = 0.08
	landing_ring.mesh = ring_mesh
	landing_ring.material_override = _material(Color(0.05, 0.35, 0.25), 0.35, 0.2)
	landing_ring.visible = false
	landing_ring.name = "LandingZoneRing"
	extraction_landing_marker.add_child(landing_ring)
	var landing_light := OmniLight3D.new()
	landing_light.name = "LandingZoneLight"
	landing_light.position.y = 2.5
	landing_light.light_color = Color(0.18, 0.95, 0.65)
	landing_light.light_energy = 0.0
	landing_light.omni_range = 13.0
	landing_light.shadow_enabled = false
	extraction_landing_marker.add_child(landing_light)
	var landing_label := Label3D.new()
	landing_label.name = "LandingZoneLabel"
	landing_label.text = "PONTO DE EXTRAÇÃO"
	landing_label.position.y = 3.6
	landing_label.font_size = 22
	landing_label.modulate = Color(0.35, 1.0, 0.72)
	landing_label.visible = false
	extraction_landing_marker.add_child(landing_label)
	outdoors.add_child(extraction_landing_marker)

func _update_exterior_weather(delta: float) -> void:
	if exterior_weather_particles == null:
		return
	exterior_weather_phase += delta
	# Rajadas irregulares: neve, vento, visibilidade e luz respondem à meteorologia.
	var gust := 0.5 + 0.5 * sin(exterior_weather_phase * 0.31 + sin(exterior_weather_phase * 0.11) * 1.7)
	exterior_gust_strength = gust
	exterior_weather_particles.amount = int(280.0 + gust * 520.0)
	var pm := exterior_weather_particles.process_material as ParticleProcessMaterial
	if pm:
		pm.initial_velocity_min = 1.6 + gust * 1.7
		pm.initial_velocity_max = 3.8 + gust * 4.2
		pm.gravity = Vector3(-1.0 - gust * 2.8, -1.2, -0.4 - gust * 1.1)
	if exterior_beacon:
		exterior_beacon.light_energy = 0.45 + gust * 0.85
	var player := get_node_or_null("Player") as CharacterBody3D
	if player:
		# A saída do corredor situa-se em z=-16.8; a zona exterior começa depois dela.
		var outside_now := player.global_position.z < -17.2 or absf(player.global_position.x) > 13.2
		if outside_now != exterior_is_player_outside:
			exterior_is_player_outside = outside_now
			if exterior_wind_player:
				if outside_now and exterior_wind_player.stream:
					if not exterior_wind_player.playing:
						exterior_wind_player.play()
				else:
					exterior_wind_player.stop()
		if exterior_wind_player and outside_now:
			exterior_wind_player.volume_db = lerpf(-25.0, -9.0, gust)
		var camera := player.get_node_or_null("CameraPivot/Camera3D") as Camera3D
		if camera:
			# A tempestade reduz a distância de visão no exterior, sem alterar o interior.
			camera.far = lerpf(62.0, 23.0, gust) if outside_now else 120.0
		if exterior_weather_label:
			exterior_weather_label.visible = outside_now
			if outside_now:
				var weather_name := "NEVE MODERADA" if gust < 0.38 else ("VENTO POLAR" if gust < 0.72 else "TEMPESTADE · VISIBILIDADE REDUZIDA")
				exterior_weather_label.text = "%s  ·  VENTO %d%%" % [weather_name, int(round(gust * 100.0))]

func _build_exterior_side_corridor(parent: Node3D, side_name: String, direction: float, wall_mat: Material, floor_mat: Material, metal_mat: Material) -> void:
	# Two lateral corridors lead from the station to separate exterior airlocks.
	var x_inner := direction * 6.0
	var x_mid := direction * 9.0
	var x_outer := direction * 12.0
	_box(parent, side_name + "ExteriorCorridorFloor", Vector3(6.4, 0.18, 2.6), Vector3(direction * 9.0, -0.16, -2.0), floor_mat)
	_box(parent, side_name + "ExteriorCorridorInnerWall", Vector3(6.4, 3.2, 0.18), Vector3(direction * 9.0, 1.5, -3.3), wall_mat)
	_box(parent, side_name + "ExteriorCorridorOuterWall", Vector3(6.4, 3.2, 0.18), Vector3(direction * 9.0, 1.5, -0.7), wall_mat)
	_box(parent, side_name + "ExteriorCorridorCeiling", Vector3(6.4, 0.18, 2.6), Vector3(direction * 9.0, 3.25, -2.0), wall_mat)
	# Porta exterior funcional: folha com colisão, detetável pelo raio de INTERAGIR.
	var door_mat := _material(Color(0.09, 0.16, 0.19), 0.4, 0.55)
	var door := StaticBody3D.new()
	door.name = side_name + "ExteriorDoor"
	door.set_script(INTERACTABLE_SCRIPT)
	door.require_coop = false
	door.slide_distance = -direction * 1.95
	door.position = Vector3(direction * 12.1, 1.2, -2.0)
	var leaf := MeshInstance3D.new()
	leaf.name = "DoorMesh"
	var leaf_mesh := BoxMesh.new()
	leaf_mesh.size = Vector3(0.12, 2.45, 1.75)
	leaf.mesh = leaf_mesh
	leaf.material_override = door_mat
	door.add_child(leaf)
	var collision := CollisionShape3D.new()
	collision.name = "DoorCollision"
	var collision_shape := BoxShape3D.new()
	collision_shape.size = Vector3(0.12, 2.45, 1.75)
	collision.shape = collision_shape
	door.add_child(collision)
	parent.add_child(door)
	_box(parent, side_name + "ExteriorDoorFrameTop", Vector3(0.28, 0.18, 2.05), Vector3(direction * 12.1, 2.55, -2.0), metal_mat, false)
	_box(parent, side_name + "ExteriorDoorFrameNear", Vector3(0.28, 2.6, 0.18), Vector3(direction * 12.1, 1.25, -3.0), metal_mat, false)
	_box(parent, side_name + "ExteriorDoorFrameFar", Vector3(0.28, 2.6, 0.18), Vector3(direction * 12.1, 1.25, -1.0), metal_mat, false)
	var indicator_mat := StandardMaterial3D.new()
	indicator_mat.albedo_color = Color(1.0, 0.12, 0.06)
	indicator_mat.emission_enabled = true
	indicator_mat.emission = Color(1.0, 0.04, 0.015)
	indicator_mat.emission_energy_multiplier = 1.4
	var indicator := MeshInstance3D.new()
	indicator.name = "LockIndicator"
	var indicator_mesh := BoxMesh.new()
	indicator_mesh.size = Vector3(0.08, 0.12, 0.08)
	indicator.mesh = indicator_mesh
	indicator.material_override = indicator_mat
	indicator.position = Vector3(-direction * 0.24, 0.95, -1.0)
	door.add_child(indicator)

func _build_room() -> void:
	var room := Node3D.new()
	room.name = "ResearchStationRoom"
	add_child(room)
	var concrete := _material(Color(0.19, 0.205, 0.21))
	var floor_mat := _material(Color(0.075, 0.085, 0.09), 0.28, 0.18)
	var metal := _material(Color(0.11, 0.135, 0.15), 0.42, 0.62)
	var hazard := _material(Color(0.43, 0.19, 0.07), 0.65, 0.25)
	_box(room, "Floor", Vector3(12, 0.3, 16), Vector3(0, -0.15, -2), floor_mat)
	_box(room, "Ceiling", Vector3(12, 0.25, 16), Vector3(0, 3.6, -2), concrete)
	# Side walls are split to create two genuine corridor openings to the exterior.
	# The openings are kept clear of collision geometry so the player can pass through.
	_box(room, "LeftWallFront", Vector3(0.3, 3.6, 5.0), Vector3(-6, 1.65, 3.5), concrete)
	_box(room, "LeftWallRear", Vector3(0.3, 3.6, 8.5), Vector3(-6, 1.65, -6.25), concrete)
	_box(room, "RightWallFront", Vector3(0.3, 3.6, 5.0), Vector3(6, 1.65, 3.5), concrete)
	_box(room, "RightWallRear", Vector3(0.3, 3.6, 8.5), Vector3(6, 1.65, -6.25), concrete)
	_build_exterior_side_corridor(room, "West", -1.0, concrete, floor_mat, metal)
	_build_exterior_side_corridor(room, "East", 1.0, concrete, floor_mat, metal)
	# Split the rear wall around a real doorway; the previous solid wall made
	# the door appear interactive while physically blocking the exit.
	_box(room, "BackWallLeft", Vector3(4.7, 3.6, 0.3), Vector3(-3.65, 1.65, -10), concrete)
	_box(room, "BackWallRight", Vector3(4.7, 3.6, 0.3), Vector3(3.65, 1.65, -10), concrete)
	_box(room, "DoorLintel", Vector3(2.6, 0.65, 0.3), Vector3(0, 3.275, -10), concrete)
	# A short corridor makes the doorway lead somewhere instead of ending at a wall.
	_box(room, "ExitCorridorFloor", Vector3(3.0, 0.18, 7.0), Vector3(0, -0.16, -13.3), floor_mat)
	_box(room, "ExitCorridorLeft", Vector3(0.18, 3.3, 7.0), Vector3(-1.5, 1.5, -13.3), concrete)
	_box(room, "ExitCorridorRight", Vector3(0.18, 3.3, 7.0), Vector3(1.5, 1.5, -13.3), concrete)
	# Piso técnico com placas, juntas e desgaste: detalhe geométrico leve para Android.
	var floor_seam := _material(Color(0.025, 0.032, 0.038), 0.78, 0.28)
	var floor_edge := _material(Color(0.16, 0.20, 0.22), 0.52, 0.55)
	for row in range(5):
		var floor_z := 4.8 - float(row) * 2.65
		_box(room, "FloorPanelJoint_%02d" % row, Vector3(11.2, 0.012, 0.035), Vector3(0, 0.008, floor_z), floor_seam, false)
		_box(room, "FloorDrain_%02d" % row, Vector3(0.62, 0.016, 0.18), Vector3(4.55, 0.012, floor_z - 0.72), floor_edge, false)
		for slot in range(5):
			_box(room, "FloorDrainSlot_%02d_%02d" % [row, slot], Vector3(0.035, 0.018, 0.13), Vector3(4.32 + float(slot) * 0.11, 0.02, floor_z - 0.72), floor_seam, false)
	# Modular wall ribs and pipe runs establish scale and navigation cues.
	for i in range(5):
		var z := 4.0 - float(i) * 3.0
		_box(room, "WallRib_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(-5.72, 1.55, z), metal)
		_box(room, "WallRibR_%02d" % i, Vector3(0.18, 3.35, 0.22), Vector3(5.72, 1.55, z), metal)
	_box(room, "PipeHorizontal", Vector3(0.18, 0.18, 12), Vector3(-5.55, 2.95, -2), hazard)
	_box(room, "ControlDesk", Vector3(2.3, 0.95, 0.8), Vector3(-3.7, 0.48, -3.8), metal)
	_box(room, "StorageCrate", Vector3(1.1, 1.2, 1.0), Vector3(3.8, 0.6, 1.2), concrete)
	var lamp := OmniLight3D.new()
	lamp.name = "FailingEmergencyLamp"
	lamp.position = Vector3(0, 3.15, -4)
	lamp.light_color = Color(0.65, 0.11, 0.055)
	lamp.light_energy = 0.9
	lamp.omni_range = 10
	lamp.shadow_enabled = true
	room.add_child(lamp)
	# Ceiling luminaires with emissive LED panels create visible pools of light.
	for i in range(3):
		var z := 2.0 - float(i) * 4.0
		var panel_mat := StandardMaterial3D.new()
		panel_mat.albedo_color = Color(0.55, 0.82, 1.0)
		panel_mat.emission_enabled = true
		panel_mat.emission = Color(0.24, 0.62, 1.0)
		panel_mat.emission_energy_multiplier = 1.1
		_box(room, "CeilingLEDPanel_%02d" % i, Vector3(1.45, 0.055, 0.42), Vector3(0, 3.43, z), panel_mat, false)
		var ceiling_light := OmniLight3D.new()
		ceiling_light.name = "CeilingLamp_%02d" % i
		ceiling_light.position = Vector3(0, 3.15, z)
		ceiling_light.light_color = Color(0.48, 0.72, 1.0)
		ceiling_light.light_energy = 0.7
		ceiling_light.omni_range = 5.5
		ceiling_light.shadow_enabled = false
		room.add_child(ceiling_light)
	# Deterioração visível: zonas danificadas, cabos soltos e luminárias avariadas.
	var damage_dark := _material(Color(0.025, 0.03, 0.035), 0.98, 0.0)
	var rust_mat := _material(Color(0.24, 0.095, 0.045), 0.94, 0.12)
	var glass_mat := StandardMaterial3D.new()
	glass_mat.albedo_color = Color(0.16, 0.22, 0.24, 0.72)
	glass_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	# Marcas de impacto e fissuras junto a painéis e no piso; apenas visuais.
	_box(room, "WallImpact_01", Vector3(0.035, 0.62, 0.48), Vector3(-5.81, 1.42, -1.4), damage_dark, false)
	_box(room, "WallImpact_02", Vector3(0.04, 0.28, 0.23), Vector3(5.81, 2.05, 2.1), rust_mat, false)
	_box(room, "FloorScorch_01", Vector3(1.35, 0.012, 0.72), Vector3(2.3, 0.008, -4.2), damage_dark, false)
	_box(room, "FallenCeilingPanel", Vector3(1.05, 0.09, 0.56), Vector3(3.6, 0.06, -2.8), metal, false)
	_box(room, "BrokenGlassShard_01", Vector3(0.24, 0.018, 0.09), Vector3(2.9, 0.018, -2.35), glass_mat, false)
	_box(room, "BrokenGlassShard_02", Vector3(0.16, 0.014, 0.07), Vector3(3.18, 0.016, -2.52), glass_mat, false)
	_box(room, "LooseCable_01", Vector3(0.045, 0.045, 1.8), Vector3(-4.9, 2.6, -5.0), rust_mat, false)
	# Uma lâmpada fundida (sem emissão) e outra intermitente, claramente distinguíveis.
	var dead_panel_mat := StandardMaterial3D.new()
	dead_panel_mat.albedo_color = Color(0.045, 0.055, 0.06)
	_box(room, "BurntOutLEDPanel", Vector3(1.1, 0.045, 0.34), Vector3(-3.7, 3.43, -5.8), dead_panel_mat, false)
	var dead_lamp := OmniLight3D.new()
	dead_lamp.name = "BurntOutCeilingLamp"
	dead_lamp.position = Vector3(-3.7, 3.12, -5.8)
	dead_lamp.light_color = Color(0.45, 0.65, 0.8)
	dead_lamp.light_energy = 0.0
	dead_lamp.omni_range = 4.0
	dead_lamp.shadow_enabled = false
	room.add_child(dead_lamp)
	var flicker_panel_mat := StandardMaterial3D.new()
	flicker_panel_mat.albedo_color = Color(0.45, 0.62, 0.68)
	flicker_panel_mat.emission_enabled = true
	flicker_panel_mat.emission = Color(0.2, 0.55, 0.72)
	flicker_panel_mat.emission_energy_multiplier = 0.6
	_box(room, "IntermittentLEDPanel", Vector3(0.95, 0.045, 0.32), Vector3(3.7, 3.43, 1.5), flicker_panel_mat, false)
	var flicker_lamp := OmniLight3D.new()
	flicker_lamp.name = "IntermittentCeilingLamp"
	flicker_lamp.position = Vector3(3.7, 3.12, 1.5)
	flicker_lamp.light_color = Color(0.28, 0.62, 0.85)
	flicker_lamp.light_energy = 0.65
	flicker_lamp.omni_range = 4.8
	flicker_lamp.shadow_enabled = false
	room.add_child(flicker_lamp)
	# Wall LED strips change from blue (normal) to red (alarm) and green (solved).
	var led_mat := StandardMaterial3D.new()
	led_mat.albedo_color = Color(0.05, 0.65, 1.0)
	led_mat.emission_enabled = true
	led_mat.emission = Color(0.05, 0.65, 1.0)
	led_mat.emission_energy_multiplier = 1.8
	_box(room, "LEDStripA", Vector3(0.055, 0.08, 10.5), Vector3(-5.78, 2.72, -2.0), led_mat, false)
	_box(room, "LEDStripB", Vector3(0.055, 0.08, 10.5), Vector3(5.78, 2.72, -2.0), led_mat, false)
	# Emergency beacon only flashes when an alarm/event is active.
	var beacon := OmniLight3D.new()
	beacon.name = "AlarmBeacon"
	beacon.position = Vector3(4.8, 3.0, -7.5)
	beacon.light_color = Color(1.0, 0.015, 0.005)
	beacon.light_energy = 2.2
	beacon.omni_range = 7.0
	beacon.visible = false
	beacon.shadow_enabled = false
	room.add_child(beacon)
	var beacon_mesh := MeshInstance3D.new()
	beacon_mesh.name = "BeaconMesh"
	var beacon_shape := SphereMesh.new()
	beacon_shape.radius = 0.16
	beacon_shape.height = 0.32
	beacon_mesh.mesh = beacon_shape
	var beacon_mat := StandardMaterial3D.new()
	beacon_mat.albedo_color = Color(1.0, 0.01, 0.005)
	beacon_mat.emission_enabled = true
	beacon_mat.emission = Color(1.0, 0.01, 0.005)
	beacon_mat.emission_energy_multiplier = 3.0
	beacon_mesh.material_override = beacon_mat
	beacon_mesh.position = Vector3.ZERO
	beacon.add_child(beacon_mesh)
	beacon_mesh.visible = false
	var green := StandardMaterial3D.new()
	green.albedo_color = Color(0.12, 0.8, 0.31)
	green.emission_enabled = true
	green.emission = Color(0.05, 1.0, 0.22)
	green.emission_energy_multiplier = 2.2
	_box(room, "ExitIndicator", Vector3(0.75, 0.12, 0.06), Vector3(0, 2.85, -9.72), green, false)
	var exit_light := OmniLight3D.new()
	exit_light.name = "ExitIndicatorLight"
	exit_light.position = Vector3(0, 2.75, -9.25)
	exit_light.light_color = Color(0.1, 0.65, 0.35)
	exit_light.light_energy = 0.45
	exit_light.omni_range = 3.0
	exit_light.shadow_enabled = false
	room.add_child(exit_light)


	# Camada de detalhe visual: juntas, placas de manutenção e fixações metálicas.
	# Elementos sem colisão para enriquecer a leitura visual sem bloquear o jogador.
	var panel_mat := _material(Color(0.105, 0.135, 0.155), 0.48, 0.52)
	var seam_mat := _material(Color(0.035, 0.052, 0.064), 0.72, 0.35)
	var bolt_mat := _material(Color(0.34, 0.40, 0.43), 0.3, 0.82)
	var hazard_mat := StandardMaterial3D.new()
	hazard_mat.albedo_color = Color(0.82, 0.34, 0.055)
	hazard_mat.roughness = 0.58
	hazard_mat.metallic = 0.25
	for side in [-1.0, 1.0]:
		for i in range(4):
			var panel_z := 2.1 - float(i) * 2.65
			_box(room, "WallServicePanel_%s_%02d" % ["L" if side < 0.0 else "R", i], Vector3(0.035, 0.82, 1.35), Vector3(side * 5.79, 1.55, panel_z), panel_mat, false)
			_box(room, "WallPanelSeam_%s_%02d" % ["L" if side < 0.0 else "R", i], Vector3(0.045, 0.025, 1.18), Vector3(side * 5.765, 1.55, panel_z), seam_mat, false)
			for bolt_y in [1.22, 1.88]:
				var bolt := MeshInstance3D.new()
				bolt.name = "WallPanelBolt_%s_%02d_%s" % ["L" if side < 0.0 else "R", i, str(bolt_y)]
				var bolt_mesh := SphereMesh.new()
				bolt_mesh.radius = 0.035
				bolt_mesh.height = 0.07
				bolt.mesh = bolt_mesh
				bolt.material_override = bolt_mat
				bolt.position = Vector3(side * 5.755, bolt_y, panel_z - 0.53)
				room.add_child(bolt)
	# Faixas de segurança junto às áreas técnicas e grelhas de ventilação decorativas.
	for i in range(8):
		_box(room, "FloorHazardStripe_%02d" % i, Vector3(0.34, 0.014, 0.075), Vector3(-1.35 + float(i) * 0.38, 0.012, -8.85), hazard_mat, false)
	var vent_mat := _material(Color(0.055, 0.075, 0.085), 0.55, 0.58)
	_box(room, "CeilingVentHousing", Vector3(1.65, 0.08, 0.72), Vector3(4.15, 3.38, -5.0), metal, false)
	for i in range(7):
		_box(room, "CeilingVentSlat_%02d" % i, Vector3(1.42, 0.025, 0.045), Vector3(4.15, 3.325, -5.29 + float(i) * 0.095), vent_mat, false)

func _build_next_chamber() -> void:
	# Zona 02: câmara de investigação ligada ao corredor de saída.
	# A entrada fica aberta; não existe uma parede sólida a bloquear a passagem.
	var zone := Node3D.new()
	zone.name = "InvestigationChamber02"
	add_child(zone)
	var concrete := _material(Color(0.16, 0.18, 0.20))
	var floor_mat := _material(Color(0.055, 0.065, 0.075), 0.3, 0.2)
	var metal := _material(Color(0.10, 0.13, 0.16), 0.4, 0.55)
	# Câmara centrada em z=-23.5; o piso sobrepõe ligeiramente o corredor.
	_box(zone, "Zone02Floor", Vector3(12.0, 0.3, 12.5), Vector3(0, -0.16, -23.45), floor_mat)
	_box(zone, "Zone02Ceiling", Vector3(12.0, 0.25, 12.5), Vector3(0, 3.6, -23.45), concrete)
	_box(zone, "Zone02LeftWall", Vector3(0.3, 3.6, 12.5), Vector3(-6.0, 1.65, -23.45), concrete)
	_box(zone, "Zone02RightWall", Vector3(0.3, 3.6, 12.5), Vector3(6.0, 1.65, -23.45), concrete)
	# Parede frontal com abertura central de 3 m para a continuação do corredor.
	_box(zone, "Zone02EntryWallLeft", Vector3(4.5, 3.6, 0.3), Vector3(-3.75, 1.65, -17.2), concrete)
	_box(zone, "Zone02EntryWallRight", Vector3(4.5, 3.6, 0.3), Vector3(3.75, 1.65, -17.2), concrete)
	_box(zone, "Zone02EntryLintel", Vector3(3.0, 0.55, 0.3), Vector3(0, 3.30, -17.2), concrete)
	# Equipamento de investigação como referência visual, sem bloquear a circulação.
	_box(zone, "EvidenceConsole", Vector3(2.0, 1.0, 0.65), Vector3(0, 0.5, -27.2), metal)
	var console_label := Label3D.new()
	console_label.name = "Zone02ObjectiveLabel"
	console_label.text = "ZONA 02  /  TERMINAL DE INVESTIGAÇÃO"
	console_label.position = Vector3(0, 1.35, -27.2)
	console_label.font_size = 28
	console_label.modulate = Color(0.55, 0.88, 0.95)
	zone.add_child(console_label)
	var glow_mat := StandardMaterial3D.new()
	glow_mat.albedo_color = Color(0.05, 0.55, 0.75)
	glow_mat.emission_enabled = true
	glow_mat.emission = Color(0.05, 0.65, 1.0)
	glow_mat.emission_energy_multiplier = 1.4
	_box(zone, "Zone02GuideLight", Vector3(1.2, 0.06, 0.08), Vector3(0, 2.8, -17.0), glow_mat, false)
	var lamp := OmniLight3D.new()
	lamp.name = "Zone02ColdLamp"
	lamp.position = Vector3(0, 3.0, -23.5)
	lamp.light_color = Color(0.25, 0.58, 0.72)
	lamp.light_energy = 0.85
	lamp.omni_range = 9.0
	lamp.shadow_enabled = false
	zone.add_child(lamp)


func _build_remaining_zones() -> void:
	# Zonas 03-10: módulos físicos consecutivos. As passagens ficam abertas
	# para que os jogadores possam avançar sem uma barreira invisível.
	var zone_names: Array[String] = [
		"03 / LABORATÓRIOS CIENTÍFICOS", "04 / CENTRAL ENERGÉTICA", "05 / ENFERMARIA",
		"06 / ARMAZÉM E MANUTENÇÃO", "07 / CONTENÇÃO EXPERIMENTAL", "08 / SEGURANÇA E VIGILÂNCIA",
		"09 / NÚCLEO DA ENTIDADE", "10 / EXTRAÇÃO E ARQUIVO CONFIDENCIAL"
	]
	var palettes: Array[Color] = [
		Color(0.28, 0.34, 0.36), Color(0.18, 0.32, 0.36),
		Color(0.38, 0.22, 0.12), Color(0.34, 0.10, 0.09),
		Color(0.26, 0.25, 0.22), Color(0.12, 0.20, 0.30),
		Color(0.25, 0.06, 0.08), Color(0.16, 0.28, 0.18)
	]
	var previous_end_z := -29.7 # saída da Zona 02
	for i in range(zone_names.size()):
		var zone_number := i + 3
		var center_z := -42.2 - float(i) * 20.0
		var front_z := center_z + 6.25
		var back_z := center_z - 6.25
		# Corredor de ligação entre módulos, sem colisões no eixo de passagem.
		var corridor_center := (previous_end_z + front_z) * 0.5
		var corridor_length := absf(previous_end_z - front_z) + 0.35
		var corridor := Node3D.new()
		corridor.name = "Connector_%02d" % zone_number
		add_child(corridor)
		var floor_mat := _material(Color(0.055, 0.065, 0.072), 0.32, 0.16)
		var wall_mat := _material(Color(0.14, 0.16, 0.18), 0.78, 0.18)
		_box(corridor, "Floor", Vector3(3.0, 0.18, corridor_length), Vector3(0, -0.16, corridor_center), floor_mat)
		_box(corridor, "LeftWall", Vector3(0.18, 3.2, corridor_length), Vector3(-1.5, 1.45, corridor_center), wall_mat)
		_box(corridor, "RightWall", Vector3(0.18, 3.2, corridor_length), Vector3(1.5, 1.45, corridor_center), wall_mat)
		var zone := Node3D.new()
		zone.name = "Zone%02d" % zone_number
		add_child(zone)
		var tint: Color = palettes[i]
		var concrete := _material(Color(0.13, 0.15, 0.17))
		var floor_material := _material(Color(0.045, 0.052, 0.06), 0.3, 0.25)
		var trim := _material(tint, 0.48, 0.3)
		var metal := _material(Color(0.10, 0.13, 0.16), 0.4, 0.55)
		_box(zone, "Floor", Vector3(12.0, 0.3, 12.5), Vector3(0, -0.16, center_z), floor_material)
		_box(zone, "Ceiling", Vector3(12.0, 0.25, 12.5), Vector3(0, 3.6, center_z), concrete)
		if zone_number == 10:
			# A parede esquerda da Zona 10 tem uma abertura real para o corredor secreto.
			_box(zone, "LeftWallFront", Vector3(0.3, 3.6, 4.3), Vector3(-6.0, 1.65, center_z + 4.1), concrete)
			_box(zone, "LeftWallBack", Vector3(0.3, 3.6, 4.3), Vector3(-6.0, 1.65, center_z - 4.1), concrete)
			_box(zone, "LeftWallLintel", Vector3(0.3, 0.55, 3.9), Vector3(-6.0, 3.30, center_z), concrete)
		else:
			_box(zone, "LeftWall", Vector3(0.3, 3.6, 12.5), Vector3(-6.0, 1.65, center_z), concrete)
		# Abertura lateral para duas salas auxiliares; mantém passagem física real.
		_box(zone, "RightWallFront", Vector3(0.3, 3.6, 4.65), Vector3(6.0, 1.65, center_z + 3.925), concrete)
		_box(zone, "RightWallBack", Vector3(0.3, 3.6, 4.65), Vector3(6.0, 1.65, center_z - 3.925), concrete)
		_box(zone, "RightWallLintel", Vector3(0.3, 0.55, 3.2), Vector3(6.0, 3.30, center_z), concrete)
		# Parede de entrada e de saída segmentadas: abertura central de 3 m.
		for wall_z in [front_z, back_z]:
			_box(zone, "WallLeft_%0.2f" % wall_z, Vector3(4.5, 3.6, 0.3), Vector3(-3.75, 1.65, wall_z), concrete)
			_box(zone, "WallRight_%0.2f" % wall_z, Vector3(4.5, 3.6, 0.3), Vector3(3.75, 1.65, wall_z), concrete)
			_box(zone, "Lintel_%0.2f" % wall_z, Vector3(3.0, 0.55, 0.3), Vector3(0, 3.30, wall_z), concrete)
		# Console lateral deixa o eixo central livre para circulação cooperativa.
		_box(zone, "ObjectiveConsole", Vector3(1.8, 1.0, 0.65), Vector3(-3.9, 0.5, center_z), trim)
		# Equipamento de trabalho visível em todas as zonas: bancadas, cadeiras,
		# armários e racks variam por função e mantêm livre o corredor central.
		_box(zone, "WorkBench", Vector3(2.2, 0.14, 0.75), Vector3(3.65, 0.92, center_z - 3.2), trim)
		for leg_x in [-0.92, 0.92]:
			for leg_z in [-0.27, 0.27]:
				_box(zone, "BenchLeg_%s_%s" % [str(leg_x), str(leg_z)], Vector3(0.10, 0.78, 0.10), Vector3(3.65 + leg_x, 0.39, center_z - 3.2 + leg_z), metal)
		_box(zone, "EquipmentCabinet", Vector3(0.8, 1.75, 0.65), Vector3(5.0, 0.875, center_z + 3.0), concrete)
		_box(zone, "EquipmentCabinetDoor", Vector3(0.04, 1.35, 0.48), Vector3(4.57, 0.95, center_z + 3.0), trim, false)
		_box(zone, "ChairSeat", Vector3(0.65, 0.12, 0.62), Vector3(3.65, 0.52, center_z - 2.15), metal)
		_box(zone, "ChairBack", Vector3(0.62, 0.65, 0.12), Vector3(3.65, 0.83, center_z - 1.86), metal)
		# Fechadura elétrica identificável junto à passagem da zona. A luz vermelha
		# comunica estado bloqueado; o painel é equipamento visual, não uma prova.
		var lock_mat := StandardMaterial3D.new()
		lock_mat.albedo_color = Color(0.18, 0.045, 0.04)
		lock_mat.emission_enabled = true
		lock_mat.emission = Color(0.75, 0.025, 0.015)
		lock_mat.emission_energy_multiplier = 1.2
		_box(zone, "ElectricLockPanel", Vector3(0.16, 0.42, 0.24), Vector3(1.72, 1.65, front_z + 0.45), metal)
		_box(zone, "ElectricLockLED", Vector3(0.055, 0.09, 0.06), Vector3(1.62, 1.68, front_z + 0.45), lock_mat, false)
		var sign := Label3D.new()
		sign.name = "ZoneTitle"
		sign.text = "ZONA %02d  /  %s" % [zone_number, zone_names[i].split(" / ", true, 1)[1]]
		sign.position = Vector3(0, 2.65, front_z + 0.22)
		sign.font_size = 24
		sign.modulate = tint.lightened(0.45)
		zone.add_child(sign)
		var lamp := OmniLight3D.new()
		lamp.name = "ZoneLamp"
		lamp.position = Vector3(0, 3.0, center_z)
		lamp.light_color = tint.lightened(0.2)
		lamp.light_energy = 0.8
		lamp.omni_range = 9.0
		lamp.shadow_enabled = false
		zone.add_child(lamp)
		# Duas faixas luminosas dão uma referência visual sem marcadores no mini-mapa.
		_box(zone, "TrimLightLeft", Vector3(0.06, 0.08, 9.5), Vector3(-5.78, 2.7, center_z), trim, false)
		_box(zone, "TrimLightRight", Vector3(0.06, 0.08, 9.5), Vector3(5.78, 2.7, center_z), trim, false)
		_build_zone_side_rooms(zone, zone_number, center_z, tint)
		_build_detailed_zone_furnishings(zone, zone_number, center_z, tint)
		# Cada zona contém uma prova física, escondida à vista entre equipamento e mobiliário.
		# As posições variam; não usar etiquetas nem luzes que revelem a prova à distância.
		_add_experiment_clue(zone, zone_number, _evidence_position_for_zone(zone_number, center_z))
		previous_end_z = back_z

func _build_detailed_zone_furnishings(zone: Node3D, zone_number: int, center_z: float, tint: Color) -> void:
	# Mobiliário 3D adicional para as dez áreas principais. Os volumes grandes
	# têm colisão; pequenos detalhes são apenas visuais para não bloquear a passagem.
	var metal := _material(Color(0.075, 0.095, 0.11), 0.38, 0.62)
	var cabinet_mat := _material(Color(0.20, 0.23, 0.25), 0.72, 0.28)
	var surface_mat := _material(Color(0.24, 0.27, 0.28), 0.45, 0.35)
	var screen_mat := StandardMaterial3D.new()
	screen_mat.albedo_color = Color(0.025, 0.11, 0.13)
	screen_mat.emission_enabled = true
	screen_mat.emission = Color(0.02, 0.38, 0.48)
	screen_mat.emission_energy_multiplier = 1.3
	# Armários modulares com puxadores e pés visíveis junto à parede oeste.
	for i in range(3):
		var z := center_z - 3.4 + float(i) * 1.35
		_box(zone, "DetailLocker_%02d_%d" % [zone_number, i], Vector3(0.78, 1.72, 0.82), Vector3(-5.05, 0.86, z), cabinet_mat)
		_box(zone, "LockerDoor_%02d_%d" % [zone_number, i], Vector3(0.035, 1.43, 0.72), Vector3(-4.64, 0.92, z), surface_mat, false)
		_box(zone, "LockerHandle_%02d_%d" % [zone_number, i], Vector3(0.035, 0.22, 0.035), Vector3(-4.60, 0.95, z - 0.22), metal, false)
		_box(zone, "LockerVent_%02d_%d" % [zone_number, i], Vector3(0.018, 0.025, 0.32), Vector3(-4.595, 1.28, z), metal, false)
	# Estante de peças com prateleiras, caixas e recipientes identificáveis.
	_box(zone, "DetailedStorageFrame_%02d" % zone_number, Vector3(0.12, 1.95, 1.45), Vector3(4.85, 0.98, center_z + 1.25), metal)
	for shelf in range(4):
		var y := 0.30 + float(shelf) * 0.48
		_box(zone, "StorageShelf_%02d_%d" % [zone_number, shelf], Vector3(0.72, 0.07, 1.38), Vector3(4.82, y, center_z + 1.25), surface_mat, false)
		_box(zone, "StorageBin_%02d_%d" % [zone_number, shelf], Vector3(0.38, 0.28, 0.42), Vector3(4.78, y + 0.17, center_z + 1.05), _material(tint.darkened(0.35)), false)
	# Segunda bancada técnica, monitores inclinados simulados por ecrãs e teclado.
	_box(zone, "InstrumentBench_%02d" % zone_number, Vector3(2.15, 0.14, 0.78), Vector3(-3.55, 0.94, center_z + 3.15), surface_mat)
	for leg_x in [-0.88, 0.88]:
		_box(zone, "InstrumentBenchLeg_%02d_%s" % [zone_number, str(leg_x)], Vector3(0.10, 0.86, 0.10), Vector3(-3.55 + leg_x, 0.43, center_z + 3.15), metal)
	for monitor in range(2):
		var mx := -4.12 + float(monitor) * 1.08
		_box(zone, "MonitorHousing_%02d_%d" % [zone_number, monitor], Vector3(0.72, 0.48, 0.10), Vector3(mx, 1.28, center_z + 2.88), metal, false)
		_box(zone, "MonitorScreen_%02d_%d" % [zone_number, monitor], Vector3(0.62, 0.36, 0.025), Vector3(mx, 1.29, center_z + 2.82), screen_mat, false)
		_box(zone, "MonitorStand_%02d_%d" % [zone_number, monitor], Vector3(0.10, 0.20, 0.10), Vector3(mx, 1.07, center_z + 2.91), metal, false)
	_box(zone, "Keyboard_%02d" % zone_number, Vector3(0.48, 0.035, 0.17), Vector3(-3.55, 1.035, center_z + 3.38), metal, false)
	# Cadeira completa: assento, costas, quatro pernas e apoios laterais.
	var chair_pos := Vector3(-3.55, 0.0, center_z + 1.95)
	_box(zone, "DetailChairSeat_%02d" % zone_number, Vector3(0.58, 0.13, 0.56), chair_pos + Vector3(0, 0.52, 0), _material(tint.darkened(0.12)))
	_box(zone, "DetailChairBack_%02d" % zone_number, Vector3(0.56, 0.60, 0.12), chair_pos + Vector3(0, 0.86, -0.22), _material(tint.darkened(0.18)))
	for lx in [-0.22, 0.22]:
		for lz in [-0.20, 0.20]:
			_box(zone, "DetailChairLeg_%02d_%s_%s" % [zone_number, str(lx), str(lz)], Vector3(0.055, 0.48, 0.055), chair_pos + Vector3(lx, 0.24, lz), metal)
	# Função visual varia por zona: leitos, bateria, laboratório, arquivo ou contenção.
	match zone_number:
		1:
			_build_bed_prop(zone, "TriageBed", Vector3(1.8, 0.0, center_z - 2.4), surface_mat, metal)
			_box(zone, "PPEBench", Vector3(1.35, 0.82, 0.55), Vector3(1.2, 0.41, center_z + 3.3), cabinet_mat)
		2:
			_box(zone, "CommsRack", Vector3(0.65, 2.0, 1.0), Vector3(-4.9, 1.0, center_z + 2.4), metal)
			for i in range(4):
				_box(zone, "CommsRackSlot_%d" % i, Vector3(0.06, 0.06, 0.66), Vector3(-4.55, 0.48 + float(i) * 0.4, center_z + 2.4), screen_mat, false)
		3:
			for i in range(3):
				_box(zone, "LabSampleCanister_%d" % i, Vector3(0.22, 0.48, 0.22), Vector3(1.0 + float(i) * 0.45, 1.22, center_z - 3.25), screen_mat, false)
		4:
			for i in range(3):
				_box(zone, "PowerBattery_%d" % i, Vector3(0.62, 1.15, 0.72), Vector3(-4.85, 0.58, center_z + 2.5 - float(i) * 1.25), cabinet_mat)
				_box(zone, "BatteryStatus_%d" % i, Vector3(0.12, 0.08, 0.08), Vector3(-4.48, 1.0, center_z + 2.5 - float(i) * 1.25), screen_mat, false)
		5:
			_build_bed_prop(zone, "MedicalBed", Vector3(-1.8, 0.0, center_z + 2.6), surface_mat, metal)
		6:
			_box(zone, "ToolChest", Vector3(1.05, 0.62, 0.65), Vector3(-4.75, 0.31, center_z + 2.7), cabinet_mat)
			for i in range(5):
				_box(zone, "ToolSlot_%d" % i, Vector3(0.10, 0.20, 0.06), Vector3(-4.9 + float(i) * 0.18, 0.65, center_z + 2.34), tint, false)
		7:
			_box(zone, "ContainmentGlassFrame", Vector3(0.12, 2.1, 2.2), Vector3(-5.2, 1.05, center_z + 2.2), metal)
			_box(zone, "ContainmentGlass", Vector3(0.035, 1.8, 1.9), Vector3(-5.12, 1.12, center_z + 2.2), screen_mat, false)
		8:
			for i in range(3):
				_box(zone, "SecurityMonitor_%d" % i, Vector3(0.72, 0.48, 0.09), Vector3(-4.5 + float(i) * 0.95, 1.85, center_z + 3.0), metal, false)
				_box(zone, "SecurityScreen_%d" % i, Vector3(0.62, 0.36, 0.025), Vector3(-4.5 + float(i) * 0.95, 1.86, center_z + 2.94), screen_mat, false)
		9:
			_box(zone, "EntityContainmentPod", Vector3(1.35, 2.15, 1.35), Vector3(-4.75, 1.08, center_z + 2.2), metal)
			_box(zone, "PodWindow", Vector3(0.04, 1.25, 0.75), Vector3(-4.04, 1.35, center_z + 2.2), screen_mat, false)
		10:
			for i in range(4):
				_box(zone, "ArchiveDrawer_%d" % i, Vector3(0.82, 0.26, 0.62), Vector3(-4.9, 0.35 + float(i) * 0.32, center_z + 2.3), cabinet_mat)
	# Placa funcional de identificação, fixada na parede sem bloquear circulação.
	var wall_label := Label3D.new()
	wall_label.name = "FurnishingZoneLabel"
	wall_label.text = ["TRIAGEM / EQUIPAMENTO", "COMUNICAÇÕES / MAPAS", "LABORATÓRIO / AMOSTRAS", "ENERGIA / BATERIAS", "CUIDADOS MÉDICOS", "MANUTENÇÃO / PEÇAS", "CONTENÇÃO / OBSERVAÇÃO", "SEGURANÇA / MONITORIZAÇÃO", "NÚCLEO / CONTENÇÃO", "ARQUIVO / EXTRAÇÃO"][clampi(zone_number - 1, 0, 9)]
	wall_label.position = Vector3(-5.72, 2.35, center_z - 4.65)
	wall_label.font_size = 12
	wall_label.modulate = tint.lightened(0.55)
	zone.add_child(wall_label)

func _build_bed_prop(parent: Node3D, prefix: String, pos: Vector3, surface_mat: Material, metal: Material) -> void:
	# Cama/maca com colchão, armação, pernas e cabeceira claramente legíveis.
	_box(parent, prefix + "Frame", Vector3(1.9, 0.13, 0.82), pos + Vector3(0, 0.55, 0), metal)
	_box(parent, prefix + "Mattress", Vector3(1.78, 0.18, 0.72), pos + Vector3(0, 0.70, 0), surface_mat)
	_box(parent, prefix + "Headboard", Vector3(0.08, 0.50, 0.82), pos + Vector3(-0.92, 0.78, 0), metal)
	for x in [-0.78, 0.78]:
		for z in [-0.29, 0.29]:
			_box(parent, prefix + "Leg_%s_%s" % [str(x), str(z)], Vector3(0.07, 0.52, 0.07), pos + Vector3(x, 0.26, z), metal)

func _build_detailed_auxiliary_furnishings(room: Node3D, zone_number: int, room_index: int, room_center_z: float, tint: Color) -> void:
	# Cada uma das 20 salas anexas recebe objetos próprios além da mesa/cadeira/rack-base.
	var metal := _material(Color(0.065, 0.085, 0.10), 0.4, 0.55)
	var cabinet := _material(Color(0.19, 0.22, 0.24), 0.75, 0.25)
	var pale := _material(Color(0.58, 0.66, 0.68), 0.62, 0.12)
	var screen := StandardMaterial3D.new()
	screen.albedo_color = Color(0.02, 0.12, 0.15)
	screen.emission_enabled = true
	screen.emission = Color(0.02, 0.36, 0.46)
	screen.emission_energy_multiplier = 1.25
	var room_tag := "Z%02dR%d" % [zone_number, room_index]
	# Armário com portas, puxadores e ventilação; fica encostado à parede exterior.
	_box(room, room_tag + "TallLocker", Vector3(0.72, 1.78, 0.72), Vector3(11.25, 0.89, room_center_z - 1.65), cabinet)
	_box(room, room_tag + "LockerFront", Vector3(0.035, 1.48, 0.62), Vector3(10.875, 0.96, room_center_z - 1.65), pale, false)
	for i in range(4):
		_box(room, room_tag + "LockerVent%d" % i, Vector3(0.018, 0.025, 0.28), Vector3(10.85, 1.22 + float(i) * 0.09, room_center_z - 1.65), metal, false)
	_box(room, room_tag + "LockerHandle", Vector3(0.035, 0.20, 0.035), Vector3(10.84, 0.96, room_center_z - 1.45), metal, false)
	# Recipientes, papéis e ferramentas na mesa existente, sem cobrir toda a superfície.
	_box(room, room_tag + "DeskTray", Vector3(0.42, 0.035, 0.28), Vector3(8.0, 0.97, room_center_z + 0.78), metal, false)
	_box(room, room_tag + "DocumentStack", Vector3(0.30, 0.035, 0.22), Vector3(8.52, 0.98, room_center_z + 0.78), pale, false)
	_box(room, room_tag + "DeskLampBase", Vector3(0.16, 0.035, 0.16), Vector3(8.78, 0.98, room_center_z + 0.62), metal, false)
	_box(room, room_tag + "DeskLampArm", Vector3(0.035, 0.28, 0.035), Vector3(8.78, 1.13, room_center_z + 0.62), metal, false)
	# Ecrã, suporte e teclado nas salas de trabalho; nos restantes casos, quadro informativo.
	if zone_number in [2, 3, 4, 8, 9] or (zone_number == 10 and room_index == 0):
		_box(room, room_tag + "TerminalHousing", Vector3(0.62, 0.43, 0.10), Vector3(8.2, 1.28, room_center_z + 1.02), metal, false)
		_box(room, room_tag + "TerminalScreen", Vector3(0.53, 0.33, 0.025), Vector3(8.2, 1.29, room_center_z + 0.96), screen, false)
		_box(room, room_tag + "TerminalStand", Vector3(0.10, 0.18, 0.10), Vector3(8.2, 1.08, room_center_z + 1.03), metal, false)
		_box(room, room_tag + "TerminalKeyboard", Vector3(0.38, 0.035, 0.13), Vector3(8.2, 1.00, room_center_z + 1.22), metal, false)
	else:
		_box(room, room_tag + "WallNoticeBoard", Vector3(0.055, 0.85, 1.25), Vector3(11.78, 1.95, room_center_z + 0.15), cabinet, false)
		for i in range(3):
			_box(room, room_tag + "NoticePaper%d" % i, Vector3(0.02, 0.22, 0.28), Vector3(11.745, 2.12 - float(i) * 0.24, room_center_z - 0.20 + float(i) * 0.32), pale, false)
	# Cadeira de escritório completa com pés/rodízios; colocada junto à mesa.
	_box(room, room_tag + "OfficeChairSeat", Vector3(0.48, 0.13, 0.48), Vector3(8.25, 0.49, room_center_z - 0.05), _material(tint.darkened(0.15)))
	_box(room, room_tag + "OfficeChairBack", Vector3(0.46, 0.55, 0.10), Vector3(8.25, 0.80, room_center_z - 0.27), _material(tint.darkened(0.2)))
	_box(room, room_tag + "OfficeChairStem", Vector3(0.08, 0.30, 0.08), Vector3(8.25, 0.27, room_center_z - 0.05), metal, false)
	for x in [-0.19, 0.19]:
		for z in [-0.19, 0.19]:
			_box(room, room_tag + "OfficeChairFoot_%s_%s" % [str(x), str(z)], Vector3(0.24, 0.045, 0.06), Vector3(8.25 + x, 0.08, room_center_z - 0.05 + z), metal, false)
	# Conteúdo de prateleiras: caixas e recipientes colocados em alturas distintas.
	for shelf in range(3):
		var y := 0.42 + float(shelf) * 0.45
		_box(room, room_tag + "RackShelf%d" % shelf, Vector3(0.42, 0.06, 0.95), Vector3(11.35, y, room_center_z + 1.0), metal, false)
		_box(room, room_tag + "RackBox%d" % shelf, Vector3(0.28, 0.24, 0.32), Vector3(11.32, y + 0.15, room_center_z + 0.88), _material(tint.darkened(0.25)), false)
	# Prop funcional visual específico, por função da sala.
	if zone_number in [1, 5] and room_index == 1:
		_build_bed_prop(room, room_tag + "MedicalCot", Vector3(9.55, 0.0, room_center_z + 0.05), pale, metal)
	elif zone_number == 3:
		for i in range(3):
			_box(room, room_tag + "SampleVial%d" % i, Vector3(0.12, 0.28, 0.12), Vector3(8.8 + float(i) * 0.28, 1.08, room_center_z + 0.78), screen, false)
		_box(room, room_tag + "MicroscopeBase", Vector3(0.35, 0.07, 0.25), Vector3(9.0, 1.03, room_center_z + 0.25), metal, false)
		_box(room, room_tag + "MicroscopeColumn", Vector3(0.07, 0.32, 0.07), Vector3(9.0, 1.22, room_center_z + 0.25), metal, false)
	elif zone_number == 4:
		for i in range(3):
			_box(room, room_tag + "BatteryPack%d" % i, Vector3(0.34, 0.58, 0.42), Vector3(9.0 + float(i) * 0.48, 0.29, room_center_z + 0.12), cabinet)
	elif zone_number == 6:
		for i in range(4):
			_box(room, room_tag + "Tool%d" % i, Vector3(0.08, 0.30, 0.08), Vector3(8.8 + float(i) * 0.22, 1.10, room_center_z + 0.75), metal, false)
	elif zone_number == 7 or zone_number == 9:
		_box(room, room_tag + "ReinforcedWindowFrame", Vector3(0.10, 1.45, 1.65), Vector3(11.76, 1.65, room_center_z + 0.1), metal, false)
		_box(room, room_tag + "ReinforcedWindow", Vector3(0.035, 1.22, 1.42), Vector3(11.70, 1.68, room_center_z + 0.1), screen, false)
	elif zone_number == 10:
		for i in range(3):
			_box(room, room_tag + "ArchiveFileBox%d" % i, Vector3(0.28, 0.18, 0.36), Vector3(10.85, 0.35 + float(i) * 0.42, room_center_z + 0.8), _material(tint.lightened(0.15)), false)

func _evidence_position_for_zone(clue_id: int, center_z: float) -> Vector3:
	# Objetos colocados em superfícies ou parcialmente resguardados por equipamento.
	# Todos permanecem alcançáveis e dentro da zona correspondente.
	match clue_id:
		1: return Vector3(-5.05, 1.78, center_z - 2.05) # topo do armário, atrás do alinhamento frontal
		2: return Vector3(3.65, 1.02, center_z - 3.38) # canto da bancada
		3: return Vector3(4.72, 1.78, center_z + 3.0) # bordo do armário
		4: return Vector3(3.05, 0.98, center_z - 3.15) # bancada, parcialmente tapado pelo equipamento
		5: return Vector3(-5.28, 1.30, center_z - 0.85) # recuado junto aos cacifos
		6: return Vector3(4.35, 0.78, center_z + 2.65) # prateleira inferior
		7: return Vector3(-4.78, 1.78, center_z + 1.85) # topo de armário lateral
		8: return Vector3(3.35, 1.00, center_z - 2.85) # junto a instrumentos da bancada
		9: return Vector3(4.85, 0.76, center_z + 2.20) # perto de caixas de manutenção
		_: return Vector3(-4.95, 1.42, center_z + 2.65) # junto às estantes, fora do eixo central

func _add_experiment_clue(parent: Node3D, clue_id: int, clue_position: Vector3) -> void:
	# As provas são objetos físicos distintos, não cubos/ícones genéricos.
	var clue := StaticBody3D.new()
	clue.name = "ExperimentClue_%02d" % clue_id
	clue.add_to_group("collectible_evidence")
	clue.set_script(load("res://scripts/experiment_clue.gd"))
	clue.clue_id = clue_id
	clue.position = clue_position
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "EvidenceMesh"
	var mesh: Mesh
	var evidence_material: StandardMaterial3D
	match clue_id % 5:
		0:
			# Pequeno frasco de amostra criogénica.
			var vial := CylinderMesh.new()
			vial.top_radius = 0.075
			vial.bottom_radius = 0.09
			vial.height = 0.34
			mesh = vial
			evidence_material = _material(Color(0.28, 0.43, 0.44, 0.92), 0.32, 0.05)
		1:
			# Gravador de áudio portátil, alongado e com aspeto metálico.
			var recorder := BoxMesh.new()
			recorder.size = Vector3(0.29, 0.10, 0.16)
			mesh = recorder
			evidence_material = _material(Color(0.085, 0.10, 0.11), 0.42, 0.35)
		2:
			# Fotografia/documento recuperado, fino e retangular.
			var document := BoxMesh.new()
			document.size = Vector3(0.28, 0.015, 0.38)
			mesh = document
			evidence_material = _material(Color(0.47, 0.45, 0.39), 0.94, 0.0)
		3:
			# Módulo de dados com cantos arredondados simulados por corpo compacto.
			var data_module := CylinderMesh.new()
			data_module.top_radius = 0.105
			data_module.bottom_radius = 0.105
			data_module.height = 0.12
			data_module.radial_segments = 8
			mesh = data_module
			evidence_material = _material(Color(0.10, 0.23, 0.25), 0.38, 0.3)
		_:
			# Peça de equipamento danificada, com forma oval em vez de quadrada.
			var fragment := SphereMesh.new()
			fragment.radius = 0.14
			fragment.height = 0.22
			mesh = fragment
			evidence_material = _material(Color(0.28, 0.20, 0.14), 0.82, 0.08)
	mesh_node.mesh = mesh
	mesh_node.material_override = evidence_material
	if clue_id % 5 == 1:
		mesh_node.rotation.y = deg_to_rad(-18.0)
	elif clue_id % 5 == 2:
		mesh_node.rotation.x = deg_to_rad(-8.0)
	clue.add_child(mesh_node)
	# Pequenos detalhes visuais tornam os objetos reconhecíveis à distância.
	if clue_id % 5 == 1:
		var display := MeshInstance3D.new()
		display.name = "RecorderDisplay"
		var display_mesh := BoxMesh.new()
		display_mesh.size = Vector3(0.10, 0.012, 0.045)
		display.mesh = display_mesh
		display.position = Vector3(0.0, 0.057, -0.015)
		display.material_override = _material(Color(0.12, 0.95, 0.78), 0.25, 0.0)
		mesh_node.add_child(display)
	elif clue_id % 5 == 2:
		var marking := MeshInstance3D.new()
		marking.name = "DocumentMarking"
		var marking_mesh := BoxMesh.new()
		marking_mesh.size = Vector3(0.19, 0.004, 0.012)
		marking.mesh = marking_mesh
		marking.position = Vector3(0.0, 0.010, -0.08)
		marking.material_override = _material(Color(0.16, 0.24, 0.28), 0.9, 0.0)
		mesh_node.add_child(marking)
	# Sem brilho nem etiqueta flutuante: a prova mistura-se com o cenário.
	# Um pequeno detalhe mate ajuda a reconhecê-la apenas de perto.
	var evidence_mark := MeshInstance3D.new()
	evidence_mark.name = "EvidenceWearMark"
	var mark_mesh := BoxMesh.new()
	mark_mesh.size = Vector3(0.045, 0.008, 0.025)
	evidence_mark.mesh = mark_mesh
	evidence_mark.position = Vector3(0.015, 0.055, -0.018)
	evidence_mark.material_override = _material(Color(0.20, 0.25, 0.25), 0.9, 0.0)
	mesh_node.add_child(evidence_mark)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	# Área generosa de interação, mantendo o objeto visível e fácil de selecionar.
	shape.size = Vector3(1.7, 1.8, 1.7)
	shape_node.shape = shape
	clue.add_child(shape_node)
	parent.add_child(clue)

func request_experiment_clue(clue_id: int, player: Node = null) -> void:
	if multiplayer.is_server():
		_server_collect_experiment_clue(clue_id)
	else:
		rpc_id(1, "server_collect_experiment_clue", clue_id)

@rpc("any_peer", "call_remote", "reliable")
func server_collect_experiment_clue(clue_id: int) -> void:
	if not multiplayer.is_server():
		return
	_server_collect_experiment_clue(clue_id)

func _server_collect_experiment_clue(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 10 or experiment_clues_found.has(clue_id):
		return
	experiment_clues_found[clue_id] = true
	collect_experiment_clue_local(clue_id)
	if not _is_solo_session():
		rpc("client_sync_experiment_clue", clue_id)
		rpc("client_sync_secret_progress", experiment_clues_found.keys(), evidence_synthesis_complete, secret_experiment_open)

@rpc("authority", "call_remote", "reliable")
func client_sync_experiment_clue(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 10:
		return
	experiment_clues_found[clue_id] = true
	collect_experiment_clue_local(clue_id)

func collect_experiment_clue_local(clue_id: int) -> void:
	if clue_id < 1 or clue_id > 10:
		return
	# A prova desaparece após recolha para não induzir o jogador a repetir a ação.
	for item in get_tree().get_nodes_in_group("collectible_evidence"):
		if is_instance_valid(item) and int(item.get("clue_id")) == clue_id:
			item.queue_free()
			break
	var clue_names := {
		1: "Registo de admissão",
		2: "Consentimento falsificado",
		3: "Relatório de manutenção",
		4: "Protocolo de incubação",
		5: "Falha de energia planeada",
		6: "Relatório de contenção",
		7: "Diário de laboratório",
		8: "Ordem de segurança",
		9: "Sequência de ativação",
		10: "Gravação da experiência"
	}
	var combination_fragments := {
		2: "CHAVE DE LEITURA: extrai quatro valores por esta ordem — alertas confirmados, ciclos rejeitados, circuito isolado primeiro, primeiro ciclo estável. Ignora datas e números administrativos.",
		4: "INCUBAÇÃO: três ciclos foram rejeitados antes da primeira leitura estável. Conta apenas os ciclos rejeitados.",
		7: "DIÁRIO DE ALARMES: sete alertas foram confirmados. Exclui todos os registos marcados TESTE.",
		9: "MANUTENÇÃO/ATIVAÇÃO: o circuito 1 foi isolado primeiro; a primeira leitura estável ocorreu no ciclo 4."
	}
	var found := experiment_clues_found.size()
	var prompt := get_node_or_null("HUD/Prompt") as Label
	var trail_hints := {
		1: "INDÍCIO: o registo menciona mapas revistos depois de uma chamada interna. Procura sinais de comunicação fora do horário normal.",
		2: "INDÍCIO: a autorização foi validada com uma amostra que nunca entrou no inventário. Compara os registos científicos e os códigos de entrada.",
		3: "INDÍCIO: a falha não foi causada pelo frio. O relatório descreve uma interrupção seletiva e menciona circuitos isolados manualmente.",
		4: "INDÍCIO: alguém ocultou um efeito secundário nos registos clínicos. Procura diferenças entre observações médicas e relatórios oficiais.",
		5: "INDÍCIO: uma ferramenta foi requisitada, mas nunca devolvida. Segue o rasto da manutenção e observa o que parece ter sido mexido recentemente.",
		6: "INDÍCIO: o relatório de contenção descreve marcas no lado interior da barreira. Investiga a zona onde se registam as entradas e saídas.",
		7: "INDÍCIO: o diário contradiz a gravação de vigilância por alguns minutos. Compara horários e procura o ponto cego do sistema.",
		8: "INDÍCIO: a ordem de segurança foi assinada depois do encerramento da estação. Verifica quem tinha acesso e que equipamento foi ativado.",
		9: "INDÍCIO: a sequência de ativação foi dividida entre dois registos. Reúne os horários e procura a instalação que não aparece nas plantas públicas.",
		10: "SEQUÊNCIA COMPLETA: os registos apontam para uma área omitida das plantas. Compara as paredes, cablagens e documentação da estação; não há marcador de localização."
	}
	if prompt:
		var clue_message := "PROVA %02d/10: %s — fragmento registado. A próxima localização não foi marcada." % [found, clue_names[clue_id]]
		if combination_fragments.has(clue_id):
			clue_message += " " + combination_fragments[clue_id]
		if trail_hints.has(clue_id):
			clue_message += "\n\n" + trail_hints[clue_id]
		prompt.text = clue_message
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: %02d / 10" % found
	if found == 3 and prompt:
		prompt.text += "\n\nPISTA ADICIONAL: o relatório de manutenção menciona uma parede falsa a oeste da Zona 10."
	elif found == 6 and prompt:
		prompt.text += "\n\nPISTA ADICIONAL: o relatório de contenção refere uma consola escondida junto à passagem selada, atrás da parede oeste da Zona 10."
	elif found == 10:
		_reveal_secret_access()
		if prompt:
			prompt.text += "\n\nACESSO DESCOBERTO: procura a passagem oculta e usa as pistas recolhidas para obter o código."

func _reveal_secret_access() -> void:
	# Só o anfitrião/servidor altera o estado partilhado.
	if not multiplayer.is_server():
		return
	if secret_synthesis_console:
		secret_synthesis_console.visible = true
		for child in secret_synthesis_console.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if not _is_solo_session():
		rpc("client_reveal_secret_console")

@rpc("authority", "call_remote", "reliable")
func client_reveal_secret_console() -> void:
	if secret_synthesis_console:
		secret_synthesis_console.visible = true
		for child in secret_synthesis_console.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if secret_clue_status:
		secret_clue_status.text = "PROVAS REUNIDAS: 10 / 10 · CONSOLA REVELADA"

func _unlock_secret_door() -> void:
	# Só a combinação correta revela e ativa a porta oculta.
	if secret_experiment_door and not secret_experiment_open:
		secret_experiment_door.visible = true
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", false)

func interact_evidence_synthesis_console(_player: Node = null) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 10:
		if prompt:
			prompt.text = "CONSOLA BLOQUEADA — reúne as 10 provas e procura os quatro algarismos escondidos nos documentos."
		_play_sfx("radio_static.wav")
		return
	if secret_combination_panel:
		secret_combination_panel.visible = true
		if secret_combination_input:
			secret_combination_input.clear()
			secret_combination_input.grab_focus()
	if prompt:
		prompt.text = "FECHADURA VANTHIS — introduz a combinação deduzida a partir das provas."
	if not multiplayer.is_server():
		return

func _submit_secret_combination() -> void:
	if not secret_combination_input:
		return
	var entered_code := secret_combination_input.text.strip_edges()
	if not entered_code.is_valid_int() or entered_code.length() != 4:
		var prompt := get_node_or_null("HUD/Prompt") as Label
		if prompt:
			prompt.text = "CÓDIGO INVÁLIDO — são necessários quatro algarismos."
		return
	if multiplayer.is_server():
		_server_validate_secret_combination(entered_code)
	else:
		rpc_id(1, "server_validate_secret_combination", entered_code)

@rpc("any_peer", "call_remote", "reliable")
func server_validate_secret_combination(entered_code: String) -> void:
	if multiplayer.is_server():
		_server_validate_secret_combination(entered_code)

func _server_validate_secret_combination(entered_code: String) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 10:
		if prompt:
			prompt.text = "ACESSO NEGADO — faltam provas para descobrir a combinação."
		return
	if entered_code != SECRET_COMBINATION:
		if prompt:
			prompt.text = "COMBINAÇÃO INCORRETA — cruza a cronologia dos registos e exclui alarmes de teste e números administrativos."
		_play_sfx("radio_static.wav")
		if not _is_solo_session():
			rpc("client_secret_combination_result", false)
		return
	evidence_synthesis_complete = true
	_unlock_secret_door()
	evidence_journal = [
		"CHAVE DE LEITURA: extrai quatro valores, nesta ordem: alertas confirmados; ciclos rejeitados; circuito isolado primeiro; primeiro ciclo estável.",
		"ALARMES: sete alertas são confirmados. Exclui todos os registos identificados como TESTE.",
		"INCUBAÇÃO: três ciclos foram rejeitados antes da primeira leitura estável.",
		"MANUTENÇÃO: o circuito 1 foi isolado primeiro.",
		"VALIDAÇÃO: a primeira leitura estável ocorreu no ciclo 4.",
		"Conclusão: usa os quatro valores na ordem da chave de leitura. Não uses datas, números de turno ou identificadores administrativos."
	]
	if prompt:
		prompt.text = "COMBINAÇÃO CORRETA. A fechadura VANTHIS foi desbloqueada. Interage com a porta secreta."
	if secret_clue_status:
		secret_clue_status.text = "PROVAS: 10/10 · COMBINAÇÃO VALIDADA"
	if secret_combination_panel:
		secret_combination_panel.visible = false
	_play_sfx("door_open.wav")
	if not _is_solo_session():
		rpc("client_sync_evidence_synthesis")
		rpc("client_secret_combination_result", true)
		rpc("client_unlock_secret_door")

@rpc("authority", "call_remote", "reliable")
func client_secret_combination_result(correct: bool) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if correct:
		if prompt:
			prompt.text = "COMBINAÇÃO CORRETA — fechadura desbloqueada. Interage com a porta secreta."
		if secret_combination_panel:
			secret_combination_panel.visible = false
		_unlock_secret_door()
	else:
		if prompt:
			prompt.text = "COMBINAÇÃO INCORRETA — verifica a ordem dos eventos e distingue registos válidos de testes."

@rpc("authority", "call_remote", "reliable")
func client_unlock_secret_door() -> void:
	_unlock_secret_door()

@rpc("authority", "call_remote", "reliable")
func client_sync_evidence_synthesis() -> void:
	evidence_synthesis_complete = true
	evidence_journal = [
		"CHAVE DE LEITURA: extrai quatro valores, nesta ordem: alertas confirmados; ciclos rejeitados; circuito isolado primeiro; primeiro ciclo estável.",
		"ALARMES: sete alertas são confirmados. Exclui todos os registos identificados como TESTE.",
		"INCUBAÇÃO: três ciclos foram rejeitados antes da primeira leitura estável.",
		"MANUTENÇÃO: o circuito 1 foi isolado primeiro.",
		"VALIDAÇÃO: a primeira leitura estável ocorreu no ciclo 4.",
		"Conclusão: usa os quatro valores na ordem da chave de leitura. Não uses datas, números de turno ou identificadores administrativos."
	]
	if secret_clue_status:
		secret_clue_status.text = "PROVAS: 10/10 · SÍNTESE VANTHIS CONCLUÍDA"

func interact_secret_experiment_door(_player: Node = null) -> void:
	if not multiplayer.is_server():
		rpc_id(1, "server_try_open_secret_door")
		return
	_server_try_open_secret_door()

@rpc("any_peer", "call_remote", "reliable")
func server_try_open_secret_door() -> void:
	if multiplayer.is_server():
		_server_try_open_secret_door()

func _server_try_open_secret_door() -> void:
	if secret_experiment_open:
		return
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if experiment_clues_found.size() < 10:
		var missing := 10 - experiment_clues_found.size()
		if prompt:
			prompt.text = "ACESSO NEGADO — faltam %d provas da experiência (%d/10)." % [missing, experiment_clues_found.size()]
		_play_sfx("radio_static.wav")
		return
	if not evidence_synthesis_complete:
		if prompt:
			prompt.text = "ACESSO NEGADO — tens de descobrir e introduzir a combinação correta na consola VANTHIS."
		_play_sfx("radio_static.wav")
		return
	# A sequência completa das dez provas é validada antes de libertar a porta.
	for clue_id in range(1, 11):
		if not experiment_clues_found.has(clue_id):
			if prompt:
				prompt.text = "SEQUÊNCIA INCOMPLETA — falta o fragmento %02d." % clue_id
			return
	secret_experiment_open = true
	rpc("client_open_secret_door")
	if secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)
	if prompt:
		prompt.text = "ACESSO CONCEDIDO — ARQUIVO VANTHIS: EXPERIÊNCIA ORIGINAL. A porta foi desbloqueada."
	_play_sfx("door_open.wav")

@rpc("authority", "call_remote", "reliable")
func client_open_secret_door() -> void:
	secret_experiment_open = true
	if secret_experiment_door:
		secret_experiment_door.visible = false
		for child in secret_experiment_door.get_children():
			if child is CollisionShape3D:
				child.set_deferred("disabled", true)

func _build_secret_experiment_area() -> void:
	# A câmara fica para lá da parede esquerda da Zona 10, fora da rota normal.
	var chamber := Node3D.new()
	chamber.name = "SecretOriginalExperimentChamber"
	add_child(chamber)
	var concrete := _material(Color(0.10, 0.12, 0.14), 0.45, 0.5)
	var floor_mat := _material(Color(0.035, 0.045, 0.052), 0.3, 0.25)
	var glass := _material(Color(0.10, 0.32, 0.38, 0.42), 0.15, 0.2)
	# Zona 10 está centrada em z=-182.2. A entrada abre na parede x=-6.
	var center_z := -182.2
	_box(chamber, "SecretFloor", Vector3(14.0, 0.25, 10.0), Vector3(-13.0, -0.16, center_z), floor_mat)
	_box(chamber, "SecretCeiling", Vector3(14.0, 0.25, 10.0), Vector3(-13.0, 3.6, center_z), concrete)
	_box(chamber, "SecretOuterWall", Vector3(0.25, 3.6, 10.0), Vector3(-20.0, 1.65, center_z), concrete)
	_box(chamber, "SecretFrontWall", Vector3(14.0, 3.6, 0.25), Vector3(-13.0, 1.65, center_z + 5.0), concrete)
	_box(chamber, "SecretBackWall", Vector3(14.0, 3.6, 0.25), Vector3(-13.0, 1.65, center_z - 5.0), concrete)
	# Corredor entre a porta e a câmara, com paredes e chão próprios.
	_box(chamber, "SecretAccessFloor", Vector3(3.0, 0.18, 4.0), Vector3(-7.5, -0.16, center_z), floor_mat)
	_box(chamber, "SecretAccessWallFront", Vector3(4.0, 3.2, 0.18), Vector3(-8.0, 1.45, center_z + 1.5), concrete)
	_box(chamber, "SecretAccessWallBack", Vector3(4.0, 3.2, 0.18), Vector3(-8.0, 1.45, center_z - 1.5), concrete)
	# Consola de síntese fica no corredor exterior: os jogadores têm de montar as provas antes de abrir a porta.
	secret_synthesis_console = StaticBody3D.new()
	secret_synthesis_console.name = "EvidenceSynthesisConsole"
	secret_synthesis_console.set_script(load("res://scripts/evidence_synthesis_console.gd"))
	secret_synthesis_console.position = Vector3(-4.7, 0.65, center_z)
	var console_mesh := MeshInstance3D.new()
	var console_box := BoxMesh.new()
	console_box.size = Vector3(0.75, 1.2, 0.65)
	console_mesh.mesh = console_box
	console_mesh.material_override = _material(Color(0.08, 0.34, 0.37), 0.35, 0.4)
	secret_synthesis_console.add_child(console_mesh)
	var console_shape_node := CollisionShape3D.new()
	var console_shape := BoxShape3D.new()
	console_shape.size = Vector3(1.2, 1.8, 1.2)
	console_shape_node.shape = console_shape
	secret_synthesis_console.add_child(console_shape_node)
	var console_label := Label3D.new()
	console_label.text = "SÍNTESE DE PROVAS"
	console_label.position = Vector3(0, 1.0, -0.36)
	console_label.font_size = 18
	console_label.modulate = Color(0.3, 0.9, 0.88)
	secret_synthesis_console.add_child(console_label)
	chamber.add_child(secret_synthesis_console)

	secret_synthesis_console.visible = false
	for child in secret_synthesis_console.get_children():
		if child is CollisionShape3D:
			child.disabled = true

	secret_experiment_door = StaticBody3D.new()
	secret_experiment_door.name = "SecretExperimentDoor"
	secret_experiment_door.set_script(load("res://scripts/secret_experiment_door.gd"))
	secret_experiment_door.position = Vector3(-6.0, 1.4, center_z)
	var door_mesh := MeshInstance3D.new()
	var door_box := BoxMesh.new()
	door_box.size = Vector3(0.22, 2.8, 3.0)
	door_mesh.mesh = door_box
	door_mesh.material_override = _material(Color(0.16, 0.08, 0.07), 0.4, 0.8)
	secret_experiment_door.add_child(door_mesh)
	var door_shape_node := CollisionShape3D.new()
	var door_shape := BoxShape3D.new()
	door_shape.size = Vector3(0.25, 2.8, 3.0)
	door_shape_node.shape = door_shape
	secret_experiment_door.add_child(door_shape_node)
	var door_label := Label3D.new()
	door_label.text = "VANTHIS // ACESSO SELADO"
	door_label.position = Vector3(0.18, 0.35, 0)
	door_label.rotation.y = deg_to_rad(90)
	door_label.font_size = 22
	door_label.modulate = Color(0.9, 0.24, 0.15)
	secret_experiment_door.add_child(door_label)
	chamber.add_child(secret_experiment_door)
	# Porta bloqueada por defeito; só é revelada após validação da combinação.
	secret_experiment_door.visible = false
	for child in secret_experiment_door.get_children():
		if child is CollisionShape3D:
			child.disabled = true
	# A cápsula de contenção central sugere a experiência sem revelar a criatura no exterior.
	_box(chamber, "ExperimentPlatform", Vector3(3.2, 0.3, 2.2), Vector3(-13.0, 0.15, center_z), concrete)
	_box(chamber, "OriginalContainmentGlass", Vector3(2.5, 2.4, 0.12), Vector3(-13.0, 1.45, center_z), glass, false)
	_box(chamber, "ExperimentConsole", Vector3(1.5, 1.1, 0.6), Vector3(-16.0, 0.55, center_z + 2.7), _material(Color(0.12, 0.30, 0.34)))
	var title := Label3D.new()
	title.text = "VANTHIS — ARQUIVO DA EXPERIÊNCIA ORIGINAL"
	title.position = Vector3(-13.0, 3.0, center_z + 4.3)
	title.font_size = 24
	title.modulate = Color(0.4, 0.86, 0.88)
	chamber.add_child(title)
	var evidence := Label3D.new()
	evidence.text = "SUJEITO: CLASSIFICAÇÃO OMITIDA\nPROTOCOLO: AUTORIZAÇÃO FRAUDULENTA\nESTADO: CONTENÇÃO COMPROMETIDA\nREGISTO FINAL: NÃO ABRIR NOVAMENTE"
	evidence.position = Vector3(-16.0, 1.65, center_z + 2.35)
	evidence.font_size = 18
	evidence.modulate = Color(0.86, 0.82, 0.72)
	evidence.rotation.y = deg_to_rad(18)
	chamber.add_child(evidence)
	# Terminal final: só conclui a missão depois de todas as tarefas obrigatórias.
	extraction_terminal = StaticBody3D.new()
	extraction_terminal.name = "MissionExtractionTerminal"
	extraction_terminal.set_script(load("res://scripts/mission_extraction_terminal.gd"))
	extraction_terminal.position = Vector3(-17.0, 0.65, center_z - 2.7)
	var extraction_mesh := MeshInstance3D.new()
	var extraction_box := BoxMesh.new()
	extraction_box.size = Vector3(0.85, 1.25, 0.7)
	extraction_mesh.mesh = extraction_box
	extraction_mesh.material_override = _material(Color(0.08, 0.27, 0.20), 0.3, 0.45)
	extraction_terminal.add_child(extraction_mesh)
	var extraction_shape_node := CollisionShape3D.new()
	var extraction_shape := BoxShape3D.new()
	extraction_shape.size = Vector3(1.15, 1.8, 1.1)
	extraction_shape_node.shape = extraction_shape
	extraction_terminal.add_child(extraction_shape_node)
	var extraction_label := Label3D.new()
	extraction_label.text = "TRANSMISSÃO / EXTRAÇÃO"
	extraction_label.position = Vector3(0, 1.0, -0.38)
	extraction_label.font_size = 16
	extraction_label.modulate = Color(0.35, 0.95, 0.62)
	extraction_terminal.add_child(extraction_label)
	chamber.add_child(extraction_terminal)
	secret_clue_status = Label.new()
	secret_clue_status.name = "SecretClueStatus"
	secret_clue_status.text = "PROVAS REUNIDAS: 00 / 10"
	secret_clue_status.position = Vector2(18, 68)
	secret_clue_status.add_theme_font_size_override("font_size", 14)
	secret_clue_status.add_theme_color_override("font_color", Color(0.2, 0.78, 0.84))
	# HUD é criado depois; a etiqueta é adicionada quando o HUD existir.
	call_deferred("_attach_secret_clue_status")

func interact_mission_extraction(_player: Node = null) -> void:
	if mission_completed or extraction_phase != "INACTIVE":
		return
	if _is_solo_session():
		_server_start_extraction(1)
	elif multiplayer.is_server():
		_server_start_extraction(multiplayer.get_unique_id())
	else:
		rpc_id(1, "server_request_extraction")

@rpc("any_peer", "call_remote", "reliable")
func server_request_extraction() -> void:
	if not multiplayer.is_server():
		return
	_server_start_extraction(multiplayer.get_remote_sender_id())

func _server_start_extraction(peer_id: int) -> void:
	if mission_completed or extraction_phase != "INACTIVE":
		return
	var actor: Node3D = get_node_or_null("Player") as Node3D if peer_id == 1 else remote_players.get(peer_id) as Node3D
	if actor == null or extraction_terminal == null or not is_instance_valid(actor):
		return
	if actor.global_position.distance_to(extraction_terminal.global_position) > 4.5:
		if peer_id == 1:
			_set_extraction_feedback("APROXIMA-TE DO TERMINAL DE EXTRAÇÃO")
		return
	var missing: Array[String] = []
	if int(switch_owners.get("A", 0)) == 0: missing.append("ativar o Relé A")
	if int(switch_owners.get("B", 0)) == 0: missing.append("ativar o Relé B")
	if not coop_solved: missing.append("restabelecer a energia dos relés")
	if experiment_clues_found.size() < 10: missing.append("recolher as 10 provas")
	if not evidence_synthesis_complete: missing.append("validar a combinação VANTHIS")
	if not secret_experiment_open: missing.append("abrir o arquivo confidencial")
	if not missing.is_empty():
		_set_extraction_feedback("EXTRAÇÃO BLOQUEADA — falta: " + "; ".join(missing) + ".")
		return
	extraction_phase = "COUNTDOWN"
	extraction_countdown = EXTRACTION_SURVIVAL_SECONDS
	# A criatura continua ativa durante a espera; não termina nem desaparece automaticamente.
	entity_active = true
	entity_state_time = 0.0
	_set_extraction_feedback("PEDIDO DE EXTRAÇÃO ENVIADO — SOBREVIVE DURANTE 35 SEGUNDOS")
	_update_extraction_ui()
	if not _is_solo_session():
		rpc("client_extraction_state", extraction_phase, extraction_countdown)

func _update_extraction_sequence(delta: float) -> void:
	if extraction_phase == "INACTIVE" or extraction_phase == "COMPLETE" or mission_completed:
		return
	if extraction_phase == "COUNTDOWN":
		extraction_countdown = maxf(0.0, extraction_countdown - delta)
		_update_extraction_ui()
		var second_left := int(ceil(extraction_countdown))
		if second_left != extraction_last_broadcast_second and second_left % 5 == 0 and extraction_countdown > 0.0:
			extraction_last_broadcast_second = second_left
			if not _is_solo_session():
				rpc("client_extraction_state", extraction_phase, extraction_countdown)
		if extraction_countdown <= 0.0:
			extraction_phase = "LANDING"
			_update_landing_zone_visuals(true)
			_set_extraction_feedback("RESGATE À VISTA — ALCANÇA O PONTO DE EXTRAÇÃO NO EXTERIOR")
			_update_extraction_ui()
			if not _is_solo_session():
				rpc("client_extraction_state", extraction_phase, 0.0)
	elif extraction_phase == "LANDING":
		if _actor_reached_landing_zone(get_node_or_null("Player") as Node3D):
			_complete_extraction()
			return
		for peer_id in remote_players.keys():
			var actor := remote_players.get(peer_id) as Node3D
			if _actor_reached_landing_zone(actor):
				_complete_extraction()
				return

func _actor_reached_landing_zone(actor: Node3D) -> bool:
	if actor == null or not is_instance_valid(actor) or extraction_landing_marker == null:
		return false
	return actor.global_position.distance_to(extraction_landing_marker.global_position) <= EXTRACTION_LANDING_RADIUS

@rpc("authority", "call_remote", "reliable")
func client_extraction_state(phase: String, seconds_left: float) -> void:
	if mission_completed:
		return
	extraction_phase = phase
	extraction_countdown = seconds_left
	_update_landing_zone_visuals(phase == "LANDING")
	_update_extraction_ui()

func _update_landing_zone_visuals(active: bool) -> void:
	if extraction_landing_marker == null:
		return
	var ring := extraction_landing_marker.get_node_or_null("LandingZoneRing") as MeshInstance3D
	var light := extraction_landing_marker.get_node_or_null("LandingZoneLight") as OmniLight3D
	var label := extraction_landing_marker.get_node_or_null("LandingZoneLabel") as Label3D
	if ring: ring.visible = active
	if light: light.light_energy = 2.0 if active else 0.0
	if label: label.visible = active
	if active and exterior_beacon:
		exterior_beacon.light_color = Color(0.18, 0.95, 0.65)
		exterior_beacon.light_energy = 2.0

func _update_extraction_ui() -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	var message := ""
	match extraction_phase:
		"COUNTDOWN": message = "EXTRAÇÃO PEDIDA — SOBREVIVE: %02d s" % int(ceil(extraction_countdown))
		"LANDING": message = "RESGATE À VISTA — ALCANÇA O FAROL VERDE NO EXTERIOR"
		"COMPLETE": message = "EXTRAÇÃO CONFIRMADA"
	if prompt and not message.is_empty():
		prompt.text = message

func _complete_extraction() -> void:
	if mission_completed:
		return
	mission_completed = true
	extraction_phase = "COMPLETE"
	_update_extraction_ui()
	_show_mission_ending()
	if not _is_solo_session() and multiplayer.is_server():
		rpc("client_mission_completed")

@rpc("authority", "call_remote", "reliable")
func client_mission_completed() -> void:
	mission_completed = true
	extraction_phase = "COMPLETE"
	_update_landing_zone_visuals(false)
	_show_mission_ending()

func _server_try_complete_mission(peer_id: int) -> void:
	# Compatibilidade com versões antigas: interação no terminal inicia o procedimento,
	# não concede vitória instantânea.
	_server_start_extraction(peer_id)

func _set_extraction_feedback(message: String) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = message

func _show_mission_ending() -> void:
	if mission_ending_layer and is_instance_valid(mission_ending_layer):
		mission_ending_layer.visible = true
		return
	mission_ending_layer = CanvasLayer.new()
	mission_ending_layer.name = "MissionEndingLayer"
	mission_ending_layer.layer = 30
	add_child(mission_ending_layer)
	var shade := ColorRect.new()
	shade.color = Color(0.015, 0.025, 0.03, 0.94)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mission_ending_layer.add_child(shade)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mission_ending_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(320, 280)
	center.add_child(panel)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 14)
	panel.add_child(content)
	var title := Label.new()
	title.text = "EXTRAÇÃO CONFIRMADA"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 27)
	title.add_theme_color_override("font_color", Color(0.45, 0.95, 0.68))
	content.add_child(title)
	var summary := Label.new()
	summary.text = "ESTAÇÃO VÉSPERA — OPERAÇÃO FINAL\n\n✓ Relés A e B ativos\n✓ 10 provas recuperadas\n✓ Evidências VANTHIS validadas\n✓ Arquivo confidencial aberto\n✓ Terminal de extração ativado\n\nO sinal de socorro foi aceite. A equipa alcançou o ponto exterior e os registos foram transmitidos.\n\nO que a VANTHIS fez com a experiência continua por revelar…"
	summary.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	summary.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	content.add_child(summary)
	var close_button := Button.new()
	close_button.text = "CONTINUAR A EXPLORAR"
	close_button.pressed.connect(func(): mission_ending_layer.visible = false)
	content.add_child(close_button)
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = "EXTRAÇÃO CONFIRMADA — registos transmitidos."
	_play_sfx("door_open.wav")

func _attach_secret_clue_status() -> void:
	var hud := get_node_or_null("HUD")
	if hud and secret_clue_status and not secret_clue_status.is_inside_tree():
		hud.add_child(secret_clue_status)

func _build_initial_zone_wings() -> void:
	# Zonas 01 e 02 também recebem duas salas anexas, para manter a mesma escala.
	_build_zone_side_rooms(self, 1, -8.0, Color(0.18, 0.28, 0.34))
	_build_zone_side_rooms(self, 2, -23.45, Color(0.20, 0.32, 0.38))
	_build_detailed_zone_furnishings(self, 1, -2.0, Color(0.18, 0.28, 0.34))
	var investigation_zone := get_node_or_null("InvestigationChamber02") as Node3D
	if investigation_zone != null:
		_build_detailed_zone_furnishings(investigation_zone, 2, -23.45, Color(0.20, 0.32, 0.38))

func _build_zone_side_rooms(parent: Node3D, zone_number: int, center_z: float, tint: Color) -> void:
	# Salas laterais distintas por zona: cada zona tem dois espaços auxiliares
	# com finalidade, mobiliário, sinalética e iluminação próprios.
	var concrete := _material(Color(0.12, 0.14, 0.16))
	var floor_material := _material(Color(0.038, 0.046, 0.052), 0.28, 0.22)
	var trim := _material(tint, 0.5, 0.3)
	var metal := _material(Color(0.10, 0.13, 0.16), 0.4, 0.55)
	var room_catalog := [
		[["VESTIÁRIO E DESCONTAMINAÇÃO", "ARMÁRIO DE PROTEÇÃO"], ["POSTO DE TRIAGEM", "MACA DE EMERGÊNCIA"]],
		[["CENTRO DE COMUNICAÇÕES", "RÁDIO DE LONGO ALCANCE"], ["SALA DE MAPAS", "MAPA TÁTICO DA ESTAÇÃO"]],
		[["CÂMARA DE AMOSTRAS", "ARMÁRIO CRIOGÉNICO"], ["SALA DE ANÁLISE", "MESA DE MICROSCÓPIO"]],
		[["CONTROLO DE GERADORES", "PAINEL ELÉTRICO"], ["BANCO DE BATERIAS", "RACK DE ACUMULADORES"]],
		[["TRATAMENTO DE FERIMENTOS", "MACA CLÍNICA"], ["FARMÁCIA DE EMERGÊNCIA", "ARMÁRIO MÉDICO"]],
		[["OFICINA DE FERRAMENTAS", "BANCADA DE REPARAÇÃO"], ["ARMAZÉM DE PEÇAS", "PRATELEIRAS METÁLICAS"]],
		[["SALA DE OBSERVAÇÃO", "VIDRO DE CONTENÇÃO"], ["ANTECÂMARA", "PORTA DE PRESSURIZAÇÃO"]],
		[["MONITORIZAÇÃO", "CONSOLES DE VIGILÂNCIA"], ["EQUIPAMENTO DE EMERGÊNCIA", "ARMÁRIO DE PROTEÇÃO"]],
		[["OBSERVAÇÃO DA ENTIDADE", "JANELA REFORÇADA"], ["CONTROLO DO NÚCLEO", "CONSOLA DE CONTROLO"]],
		[["ARQUIVO CONFIDENCIAL", "ESTANTES DE DOSSIÊS VANTHIS"], ["PREPARAÇÃO DE EXTRAÇÃO", "CONTENTORES DE SOBREVIVÊNCIA"]]
	]
	var wing := Node3D.new()
	wing.name = "Zone%02dSideRooms" % zone_number
	parent.add_child(wing)
	var zone_rooms: Array = room_catalog[clampi(zone_number - 1, 0, room_catalog.size() - 1)]
	for room_index in range(2):
		var room_center_z := center_z + (3.125 if room_index == 0 else -3.125)
		var room_title: String = zone_rooms[room_index][0]
		var prop_title: String = zone_rooms[room_index][1]
		var room := Node3D.new()
		room.name = "Zone%02d_%s" % [zone_number, "AuxA" if room_index == 0 else "AuxB"]
		wing.add_child(room)
		_box(room, "Floor", Vector3(6.0, 0.3, 6.25), Vector3(9.0, -0.16, room_center_z), floor_material)
		_box(room, "Ceiling", Vector3(6.0, 0.25, 6.25), Vector3(9.0, 3.6, room_center_z), concrete)
		_box(room, "OuterWall", Vector3(0.3, 3.6, 6.25), Vector3(12.0, 1.65, room_center_z), concrete)
		_box(room, "NorthWall", Vector3(6.0, 3.6, 0.3), Vector3(9.0, 1.65, center_z + 6.25), concrete)
		_box(room, "SouthWall", Vector3(6.0, 3.6, 0.3), Vector3(9.0, 1.65, center_z - 6.25), concrete)
		_box(room, "InnerWallFront", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, room_center_z + 2.35), concrete)
		_box(room, "InnerWallBack", Vector3(0.3, 3.6, 1.55), Vector3(6.0, 1.65, room_center_z - 2.35), concrete)
		_box(room, "InnerWallLintel", Vector3(0.3, 0.55, 1.6), Vector3(6.0, 3.30, room_center_z), concrete)
		# Elemento visual funcional por tipo: a geometria distingue as salas sem
		# alterar os corredores nem substituir os sistemas do jogo.
		if zone_number == 1 and room_index == 0:
			_box(room, "ThermalLocker", Vector3(1.0, 1.7, 0.65), Vector3(10.7, 0.85, room_center_z - 1.0), trim)
			_box(room, "Bench", Vector3(1.6, 0.5, 0.55), Vector3(10.6, 0.25, room_center_z + 1.0), concrete)
		elif zone_number == 1 and room_index == 1:
			_box(room, "EmergencyCot", Vector3(2.0, 0.28, 0.8), Vector3(10.2, 0.75, room_center_z), trim)
		elif zone_number in [3, 7, 9] and room_index == 0:
			_box(room, "SampleCabinet", Vector3(1.1, 1.8, 0.6), Vector3(10.7, 0.9, room_center_z - 1.1), trim)
			_box(room, "ObservationPanel", Vector3(0.12, 1.1, 1.5), Vector3(11.1, 1.8, room_center_z + 1.0), concrete)
		elif zone_number in [3, 5] and room_index == 1:
			_box(room, "LabBench", Vector3(1.8, 0.85, 0.7), Vector3(10.5, 0.425, room_center_z), trim)
			_box(room, "Instrument", Vector3(0.5, 0.45, 0.45), Vector3(10.4, 1.08, room_center_z), concrete)
		elif zone_number == 6:
			_box(room, "WorkshopBench", Vector3(2.0, 0.8, 0.75), Vector3(10.4, 0.4, room_center_z), trim)
			if room_index == 1:
				for shelf_index in range(3):
					_box(room, "PartsShelf%d" % shelf_index, Vector3(0.4, 1.5, 0.45), Vector3(11.2, 0.75, room_center_z - 1.4 + shelf_index * 1.2), concrete)
		elif zone_number == 4:
			_box(room, "ElectricalCabinet", Vector3(0.75, 2.0, 1.5), Vector3(11.0, 1.0, room_center_z), trim)
			if room_index == 1:
				for battery_index in range(3):
					_box(room, "BatteryUnit%d" % battery_index, Vector3(0.45, 0.9, 0.55), Vector3(9.0 + battery_index * 0.9, 0.45, room_center_z + 1.5), concrete)
		elif zone_number == 10:
			for shelf_index in range(3):
				_box(room, "ArchiveShelf%d" % shelf_index, Vector3(0.5, 2.0, 1.6), Vector3(10.9, 1.0, room_center_z - 1.6 + shelf_index * 1.6), trim)
			_box(room, "EvacuationCrate", Vector3(0.9, 0.9, 0.9), Vector3(10.5, 0.45, room_center_z - 1.1), trim)
			_box(room, "SupplyCrate", Vector3(0.9, 0.9, 0.9), Vector3(10.5, 0.45, room_center_z + 1.1), concrete)
		elif zone_number == 8:
			_box(room, "SecurityConsole", Vector3(1.7, 0.8, 0.7), Vector3(10.3, 0.4, room_center_z), trim)
			if room_index == 0:
				_box(room, "Monitor", Vector3(0.12, 0.7, 1.2), Vector3(11.0, 1.2, room_center_z), concrete)
		# Mobiliário-base em todas as salas auxiliares, além do equipamento específico
		# acima: mesa de trabalho, assento e armário/rack com colisão real.
		_box(room, "RoomWorkTable", Vector3(1.45, 0.12, 0.72), Vector3(8.25, 0.88, room_center_z + 0.85), trim)
		_box(room, "RoomTableLegA", Vector3(0.10, 0.82, 0.10), Vector3(7.65, 0.41, room_center_z + 0.58), concrete)
		_box(room, "RoomTableLegB", Vector3(0.10, 0.82, 0.10), Vector3(8.85, 0.41, room_center_z + 0.58), concrete)
		_box(room, "RoomChairSeat", Vector3(0.48, 0.12, 0.48), Vector3(8.25, 0.48, room_center_z - 0.05), metal)
		_box(room, "RoomChairBack", Vector3(0.46, 0.55, 0.10), Vector3(8.25, 0.77, room_center_z - 0.25), metal)
		_box(room, "RoomStorageRack", Vector3(0.38, 1.55, 1.15), Vector3(11.35, 0.78, room_center_z + 1.0), concrete)
		# Painel de controlo de acesso elétrico junto à porta interior da sala.
		var access_panel_mat := StandardMaterial3D.new()
		access_panel_mat.albedo_color = Color(0.20, 0.055, 0.045)
		access_panel_mat.emission_enabled = true
		access_panel_mat.emission = Color(0.8, 0.025, 0.012)
		access_panel_mat.emission_energy_multiplier = 1.1
		_box(room, "ElectricAccessPanel", Vector3(0.10, 0.38, 0.20), Vector3(6.28, 1.55, room_center_z - 0.55), trim)
		_box(room, "ElectricAccessRedLED", Vector3(0.035, 0.07, 0.05), Vector3(6.215, 1.58, room_center_z - 0.55), access_panel_mat, false)
		_build_detailed_auxiliary_furnishings(room, zone_number, room_index, room_center_z, tint)
		var label := Label3D.new()
		label.name = "RoomSign"
		label.text = "ZONA %02d · %s\n%s" % [zone_number, room_title, prop_title]
		label.position = Vector3(9.0, 2.55, room_center_z + 2.6)
		label.font_size = 11
		label.modulate = tint.lightened(0.55)
		room.add_child(label)
		var lamp := OmniLight3D.new()
		lamp.name = "RoomLamp"
		lamp.position = Vector3(9.0, 2.9, room_center_z)
		lamp.light_color = tint.lightened(0.18)
		lamp.light_energy = 0.45 if zone_number in [6, 9] else 0.65
		lamp.omni_range = 6.5
		lamp.shadow_enabled = false
		room.add_child(lamp)

func _show_toast(message: String) -> void:
	var prompt := get_node_or_null("HUD/Prompt") as Label
	if prompt:
		prompt.text = message
	if entity_reaction_label and is_instance_valid(entity_reaction_label):
		entity_reaction_label.text = message

func _build_safe_shelter() -> void:
	# Abrigo físico na zona exterior, ligado à rota de neve. Porta e paredes têm colisão.
	safe_shelter = Node3D.new()
	safe_shelter.name = "PermanentSafeShelter"
	safe_shelter.position = Vector3(0.0, 0.0, -29.0)
	add_child(safe_shelter)
	var wall := _material(Color(0.13, 0.18, 0.21), 0.58, 0.72)
	var interior := _material(Color(0.24, 0.31, 0.34), 0.88, 0.12)
	var warning := _material(Color(0.82, 0.23, 0.08), 0.5, 0.15)
	_box(safe_shelter, "ShelterFloor", Vector3(7.0, 0.25, 7.0), Vector3(0, -0.13, 0), interior)
	_box(safe_shelter, "ShelterBackWall", Vector3(7.0, 3.2, 0.3), Vector3(0, 1.5, -3.35), wall)
	_box(safe_shelter, "ShelterLeftWall", Vector3(0.3, 3.2, 7.0), Vector3(-3.35, 1.5, 0), wall)
	_box(safe_shelter, "ShelterRightWall", Vector3(0.3, 3.2, 7.0), Vector3(3.35, 1.5, 0), wall)
	_box(safe_shelter, "ShelterRoof", Vector3(7.0, 0.3, 7.0), Vector3(0, 3.15, 0), wall)
	# A parede frontal tem dois pilares; o vão central é ocupado pela porta blindada.
	_box(safe_shelter, "ShelterFrontLeft", Vector3(2.0, 3.2, 0.3), Vector3(-2.5, 1.5, 3.35), wall)
	_box(safe_shelter, "ShelterFrontRight", Vector3(2.0, 3.2, 0.3), Vector3(2.5, 1.5, 3.35), wall)
	shelter_door = StaticBody3D.new()
	shelter_door.name = "SafeShelterDoor"
	shelter_door.position = Vector3(0, 1.45, 3.35)
	shelter_door.set_script(load("res://scripts/safe_shelter_interactable.gd"))
	shelter_door.set("interaction_mode", "door")
	var door_mesh := MeshInstance3D.new()
	var door_box := BoxMesh.new()
	door_box.size = Vector3(3.0, 2.8, 0.22)
	door_mesh.mesh = door_box
	door_mesh.name = "ShelterBlastDoorMesh"
	door_mesh.material_override = wall
	shelter_door.add_child(door_mesh)
	var door_collision := CollisionShape3D.new()
	var door_shape := BoxShape3D.new()
	door_shape.size = Vector3(3.0, 2.8, 0.24)
	door_collision.shape = door_shape
	shelter_door.add_child(door_collision)
	var door_label := Label3D.new()
	door_label.text = "ABRIGO SEGURO // PORTA BLINDADA"
	door_label.position = Vector3(0, 1.65, -0.14)
	door_label.font_size = 20
	door_label.modulate = Color(0.7, 0.95, 1.0)
	shelter_door.add_child(door_label)
	safe_shelter.add_child(shelter_door)
	# Painel exterior vulnerável: a criatura pode danificá-lo se permanecer junto à entrada.
	var panel := StaticBody3D.new()
	panel.name = "ShelterWeakpointPanel"
	panel.position = Vector3(2.05, 1.15, 3.62)
	panel.set_script(load("res://scripts/safe_shelter_interactable.gd"))
	panel.set("interaction_mode", "panel")
	var panel_mesh := MeshInstance3D.new()
	var panel_box := BoxMesh.new()
	panel_box.size = Vector3(0.48, 0.72, 0.16)
	panel_mesh.mesh = panel_box
	panel_mesh.material_override = warning
	panel.add_child(panel_mesh)
	var panel_collision := CollisionShape3D.new()
	var panel_shape := BoxShape3D.new()
	panel_shape.size = Vector3(0.55, 0.8, 0.2)
	panel_collision.shape = panel_shape
	panel.add_child(panel_collision)
	safe_shelter.add_child(panel)
	var inside_panel := StaticBody3D.new()
	inside_panel.name = "ShelterEmergencyOverride"
	inside_panel.position = Vector3(2.85, 1.1, 1.4)
	inside_panel.set_script(load("res://scripts/safe_shelter_interactable.gd"))
	inside_panel.set("interaction_mode", "repair")
	var override_mesh := MeshInstance3D.new()
	var override_box := BoxMesh.new()
	override_box.size = Vector3(0.16, 0.6, 0.45)
	override_mesh.mesh = override_box
	override_mesh.material_override = warning
	inside_panel.add_child(override_mesh)
	var override_collision := CollisionShape3D.new()
	var override_shape := BoxShape3D.new()
	override_shape.size = Vector3(0.2, 0.7, 0.5)
	override_collision.shape = override_shape
	inside_panel.add_child(override_collision)
	safe_shelter.add_child(inside_panel)
	var light := OmniLight3D.new()
	light.name = "ShelterEmergencyLight"
	light.position = Vector3(0, 2.55, 0)
	light.light_color = Color(0.48, 0.82, 1.0)
	light.light_energy = 1.0
	light.omni_range = 9.0
	safe_shelter.add_child(light)
	var sign := Label3D.new()
	sign.text = "ABRIGO DE EMERGÊNCIA\nENERGIA INDEPENDENTE"
	sign.position = Vector3(0, 2.05, -2.9)
	sign.font_size = 22
	sign.modulate = Color(0.65, 0.9, 1.0)
	safe_shelter.add_child(sign)
	var supplies := _box(safe_shelter, "EmergencySupplies", Vector3(1.2, 0.55, 0.65), Vector3(-2.1, 0.28, -1.9), interior, false)
	supplies.rotation.y = deg_to_rad(-8)
	var radio := _box(safe_shelter, "EmergencyRadio", Vector3(0.42, 0.24, 0.28), Vector3(-2.0, 1.05, -1.8), warning, false)
	var notice := Label3D.new()
	notice.name = "ShelterWeakpointNotice"
	notice.text = "SISTEMA DE FECHO: NORMAL"
	notice.position = Vector3(0, 0.55, -2.9)
	notice.font_size = 18
	notice.modulate = Color(0.45, 1.0, 0.55)
	safe_shelter.add_child(notice)
	shelter_feedback_label = notice

func _is_player_inside_safe_shelter(player: Node3D) -> bool:
	if player == null or safe_shelter == null:
		return false
	var local_pos: Vector3 = safe_shelter.to_local(player.global_position)
	return absf(local_pos.x) < 2.95 and local_pos.z > -2.95 and local_pos.z < 2.85 and local_pos.y > -0.5 and local_pos.y < 2.7

func interact_safe_shelter_door() -> void:
	if shelter_lock_damaged:
		_show_toast("FECHO AVARIADO — usa o painel de emergência no interior para reparar o sistema.")
		return
	if shelter_door_open:
		shelter_door.position = Vector3(0, 1.45, 3.35)
		shelter_door_open = false
		_play_sfx("door_motor.wav")
		if shelter_feedback_label:
			shelter_feedback_label.text = "SISTEMA DE FECHO: NORMAL"
			shelter_feedback_label.modulate = Color(0.45, 1.0, 0.55)
	else:
		shelter_door.position = Vector3(3.1, 1.45, 3.35)
		shelter_door_open = true
		_play_sfx("door_motor.wav")
		_show_toast("ABRIGO SEGURO — entra e fecha a porta. O MRE não alimenta este sistema.")

func interact_shelter_weakpoint() -> void:
	if shelter_lock_damaged:
		_show_toast("PAINEL DANIFICADO — a fechadura perdeu a proteção normal. Repara pelo painel interior.")
	else:
		_show_toast("PONTO FRACO IDENTIFICADO: painel exterior do fecho. A proteção está ativa por agora.")

func repair_shelter_lock() -> void:
	if not shelter_lock_damaged:
		_show_toast("SISTEMA NORMAL — não é necessária reparação.")
		return
	# Reparação simples para não bloquear o modo individual; custo é tempo de exposição/ação.
	shelter_lock_damaged = false
	shelter_lock_damage_progress = 0.0
	shelter_creature_pressure = 0.0
	if shelter_door:
		shelter_door.position = Vector3(0, 1.45, 3.35) if not shelter_door_open else Vector3(3.1, 1.45, 3.35)
	if shelter_feedback_label:
		shelter_feedback_label.text = "SISTEMA DE FECHO: NORMAL"
		shelter_feedback_label.modulate = Color(0.45, 1.0, 0.55)
	_show_toast("FECHO REPARADO — a porta blindada voltou a proteger o abrigo.")

func _update_shelter_weakpoint_ai(delta: float) -> void:
	if not multiplayer.is_server() or entity_presence == null or shelter_lock_damaged or safe_shelter == null:
		return
	var panel_position: Vector3 = safe_shelter.to_global(Vector3(2.05, 1.15, 3.62))
	if entity_presence.global_position.distance_to(panel_position) < 2.2:
		shelter_creature_pressure += delta
		if shelter_creature_pressure >= 9.0:
			shelter_lock_damaged = true
			shelter_door_open = true
			if shelter_door:
				shelter_door.position = Vector3(3.1, 1.45, 3.35)
			if shelter_feedback_label:
				shelter_feedback_label.text = "AVARIA NO FECHO — REPARAÇÃO NECESSÁRIA"
				shelter_feedback_label.modulate = Color(1.0, 0.18, 0.08)
			_show_toast("AVISO: a criatura danificou o ponto fraco exterior do abrigo. Usa o comando de emergência no interior.")
	else:
		shelter_creature_pressure = maxf(0.0, shelter_creature_pressure - delta * 1.5)

func _build_door() -> void:
	var door := StaticBody3D.new()
	door.name = "InteractiveBulkhead"
	door.set_script(INTERACTABLE_SCRIPT)
	door.position = Vector3(0, 1.4, -9.35)
	var mesh_node := MeshInstance3D.new()
	mesh_node.name = "DoorMesh"
	var mesh := BoxMesh.new()
	mesh.size = Vector3(2.2, 2.8, 0.22)
	mesh_node.mesh = mesh
	mesh_node.material_override = _material(Color(0.13, 0.16, 0.18), 0.42, 0.7)
	door.add_child(mesh_node)
	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.2, 2.8, 0.22)
	shape_node.shape = shape
	door.add_child(shape_node)
	var label := Label3D.new()
	label.text = "CÂMARA DE CONTENÇÃO  /  01"
	label.position = Vector3(0, 1.72, -0.13)
	label.font_size = 32
	label.modulate = Color(0.82, 0.72, 0.52)
	door.add_child(label)
	add_child(door)

func _build_coop_switches() -> void:
	# Two separated stations: each must be activated by a different network peer.
	_create_switch("A", Vector3(-4.1, 0.0, -2.1), "RELÉ A  /  LEITURA")
	_create_switch("B", Vector3(4.1, 0.0, -6.0), "RELÉ B  /  CONFIRMAÇÃO")

func _create_switch(switch_id: String, pos: Vector3, caption: String) -> void:
	# Consola industrial detalhada: deixa de ser um bloco colorido de protótipo.
	var station := StaticBody3D.new()
	station.name = "CoopSwitch" + switch_id
	station.set_script(COOP_SWITCH_SCRIPT)
	station.switch_id = switch_id
	station.position = pos

	var housing := MeshInstance3D.new()
	housing.name = "IndustrialRelayHousing"
	var housing_mesh := BoxMesh.new()
	housing_mesh.size = Vector3(0.78, 0.92, 0.42)
	housing.mesh = housing_mesh
	housing.position = Vector3(0, 0.48, 0)
	housing.material_override = _material(Color(0.105, 0.135, 0.15), 0.72, 0.68)
	station.add_child(housing)

	var face := MeshInstance3D.new()
	face.name = "MetalControlFace"
	var face_mesh := BoxMesh.new()
	face_mesh.size = Vector3(0.64, 0.70, 0.035)
	face.mesh = face_mesh
	face.position = Vector3(0, 0.49, -0.229)
	face.material_override = _material(Color(0.20, 0.24, 0.25), 0.48, 0.78)
	station.add_child(face)

	# Faixa de identificação gravada no painel frontal.
	var strip := MeshInstance3D.new()
	strip.name = "RelayLabelStrip"
	var strip_mesh := BoxMesh.new()
	strip_mesh.size = Vector3(0.48, 0.09, 0.018)
	strip.mesh = strip_mesh
	strip.position = Vector3(0, 0.73, -0.253)
	strip.material_override = _material(Color(0.055, 0.075, 0.08), 0.6, 0.25)
	station.add_child(strip)

	var status_led := MeshInstance3D.new()
	status_led.name = "RelayStatusLED"
	var led_mesh := SphereMesh.new()
	led_mesh.radius = 0.035
	led_mesh.height = 0.07
	status_led.mesh = led_mesh
	status_led.position = Vector3(-0.19, 0.73, -0.276)
	var led_mat := _material(Color(0.05, 0.95, 0.72) if switch_id == "A" else Color(1.0, 0.48, 0.08), 0.28, 0.15)
	led_mat.emission_enabled = true
	led_mat.emission = led_mat.albedo_color
	led_mat.emission_energy_multiplier = 1.4
	status_led.material_override = led_mat
	station.add_child(status_led)

	# Pequeno ecrã de estado visível no próprio equipamento.
	var state_display := MeshInstance3D.new()
	state_display.name = "RelayStateDisplay"
	var display_mesh := BoxMesh.new()
	display_mesh.size = Vector3(0.25, 0.085, 0.012)
	state_display.mesh = display_mesh
	state_display.position = Vector3(0.105, 0.73, -0.276)
	state_display.material_override = _material(Color(0.20, 0.12, 0.025), 0.2, 0.1)
	station.add_child(state_display)

	var state_label := Label3D.new()
	state_label.name = "RelayStateLabel"
	state_label.text = "À ESPERA"
	state_label.position = Vector3(0.105, 0.73, -0.286)
	state_label.font_size = 10
	state_label.pixel_size = 0.0018
	state_label.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	state_label.modulate = Color(1.0, 0.72, 0.24)
	state_label.outline_size = 2
	state_label.outline_modulate = Color(0.01, 0.015, 0.01, 1.0)
	station.add_child(state_label)

	for button_index in range(3):
		var button := MeshInstance3D.new()
		button.name = "ControlButton%d" % button_index
		var button_mesh := CylinderMesh.new()
		button_mesh.top_radius = 0.045
		button_mesh.bottom_radius = 0.045
		button_mesh.height = 0.035
		button.mesh = button_mesh
		button.rotation.x = PI / 2.0
		button.position = Vector3(-0.13 + float(button_index) * 0.13, 0.35, -0.264)
		button.material_override = _material([Color(0.75, 0.16, 0.10), Color(0.12, 0.65, 0.9), Color(0.72, 0.75, 0.72)][button_index], 0.38, 0.28)
		station.add_child(button)

	var lower_vent := MeshInstance3D.new()
	lower_vent.name = "LowerVent"
	var vent_mesh := BoxMesh.new()
	vent_mesh.size = Vector3(0.43, 0.12, 0.02)
	lower_vent.mesh = vent_mesh
	lower_vent.position = Vector3(0, 0.19, -0.253)
	lower_vent.material_override = _material(Color(0.035, 0.045, 0.05), 0.9, 0.2)
	station.add_child(lower_vent)

	var shape_node := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(0.90, 1.05, 0.52)
	shape_node.position = Vector3(0, 0.49, 0)
	shape_node.shape = shape
	station.add_child(shape_node)

	var label := Label3D.new()
	label.name = "RelayWorldLabel"
	label.text = caption
	label.position = Vector3(0, 1.12, -0.30)
	label.font_size = 24
	label.pixel_size = 0.004
	label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	label.modulate = Color(0.82, 0.90, 0.92)
	label.outline_size = 6
	label.outline_modulate = Color(0.015, 0.025, 0.03, 0.95)
	station.add_child(label)
	add_child(station)

func _human_part(parent: Node3D, part_name: String, mesh: PrimitiveMesh, pos: Vector3, mat: Material, rot := Vector3.ZERO) -> MeshInstance3D:
	var part := MeshInstance3D.new()
	part.name = part_name
	part.mesh = mesh
	part.position = pos
	part.rotation = rot
	part.material_override = mat
	parent.add_child(part)
	return part

func _add_human_model(parent: Node3D, uniform_color: Color, include_head := true, include_camera_pivot := false) -> void:
	# Lightweight, fully procedural human silhouette: no external model downloads.
	# Equipamento polar visível: parka acolchoada, capuz, óculos, luvas e botas isolantes.
	var uniform := _material(uniform_color, 0.82, 0.02)
	var dark_fabric := _material(Color(0.055, 0.075, 0.085), 0.92)
	var insulation := _material(Color(0.16, 0.22, 0.27), 0.96)
	var trim := _material(Color(0.78, 0.84, 0.87), 0.62, 0.05)
	var lens := _material(Color(0.06, 0.25, 0.34), 0.28, 0.42)
	var skin := _material(Color(0.56, 0.37, 0.27), 0.9)
	var hair := _material(Color(0.035, 0.027, 0.025), 0.96)
	var boot_mesh := BoxMesh.new()
	boot_mesh.size = Vector3(0.24, 0.18, 0.36)
	for side in [-1.0, 1.0]:
		var leg := CapsuleMesh.new()
		leg.radius = 0.115
		leg.height = 0.62
		_human_part(parent, "Leg_%s" % str(side), leg, Vector3(side * 0.14, -0.42, 0.0), dark_fabric)
		_human_part(parent, "PolarBoot_%s" % str(side), boot_mesh, Vector3(side * 0.14, -0.76, -0.055), insulation)
		var gaiter := CylinderMesh.new()
		gaiter.top_radius = 0.105
		gaiter.bottom_radius = 0.12
		gaiter.height = 0.20
		_human_part(parent, "BootGaiter_%s" % str(side), gaiter, Vector3(side * 0.14, -0.60, 0.0), trim)
	var torso := CapsuleMesh.new()
	torso.radius = 0.255
	torso.height = 0.70
	_human_part(parent, "InsulatedPolarParka", torso, Vector3(0, 0.02, 0), uniform)
	var hood := SphereMesh.new()
	hood.radius = 0.205
	hood.height = 0.30
	_human_part(parent, "ParkaHood", hood, Vector3(0, 0.39, 0.035), insulation)
	var zipper := BoxMesh.new()
	zipper.size = Vector3(0.018, 0.40, 0.018)
	_human_part(parent, "ParkaFrontZipper", zipper, Vector3(0, 0.03, -0.253), trim)
	var chest_panel := BoxMesh.new()
	chest_panel.size = Vector3(0.12, 0.09, 0.025)
	_human_part(parent, "ExpeditionIDPanel", chest_panel, Vector3(0.105, 0.16, -0.251), insulation)
	var vest := BoxMesh.new()
	vest.size = Vector3(0.34, 0.31, 0.045)
	_human_part(parent, "ExpeditionVest", vest, Vector3(0, 0.05, -0.245), _material(Color(0.72, 0.24, 0.10), 0.7))
	var stripe := BoxMesh.new()
	stripe.size = Vector3(0.29, 0.035, 0.012)
	_human_part(parent, "ReflectiveVestStripe", stripe, Vector3(0, 0.075, -0.274), _material(Color(0.88, 0.78, 0.42), 0.48, 0.08))
	for side in [-1.0, 1.0]:
		var arm := CapsuleMesh.new()
		arm.radius = 0.085
		arm.height = 0.62
		_human_part(parent, "Arm_%s" % str(side), arm, Vector3(side * 0.31, 0.0, -0.01), uniform, Vector3(0, 0, side * -0.12))
		var hand := SphereMesh.new()
		hand.radius = 0.082
		hand.height = 0.16
		_human_part(parent, "InsulatedGlove_%s" % str(side), hand, Vector3(side * 0.34, -0.30, -0.025), insulation)
	var pack := BoxMesh.new()
	pack.size = Vector3(0.32, 0.43, 0.17)
	_human_part(parent, "PolarSurvivalPack", pack, Vector3(0, 0.10, 0.22), dark_fabric)
	var pack_flap := BoxMesh.new()
	pack_flap.size = Vector3(0.25, 0.10, 0.035)
	_human_part(parent, "PackFlap", pack_flap, Vector3(0, 0.28, 0.315), insulation)
	var radio := BoxMesh.new()
	radio.size = Vector3(0.07, 0.13, 0.045)
	_human_part(parent, "EmergencyRadio", radio, Vector3(0.205, 0.10, 0.015), dark_fabric)
	# Additional layered expedition gear gives the silhouette a more finished 3D read.
	var shoulder_pad := SphereMesh.new()
	shoulder_pad.radius = 0.125
	shoulder_pad.height = 0.22
	for side in [-1.0, 1.0]:
		_human_part(parent, "InsulatedShoulder_%s" % str(side), shoulder_pad, Vector3(side * 0.255, 0.235, -0.005), insulation)
		var knee_pad := BoxMesh.new()
		knee_pad.size = Vector3(0.19, 0.15, 0.075)
		_human_part(parent, "KneeProtection_%s" % str(side), knee_pad, Vector3(side * 0.14, -0.43, -0.095), dark_fabric)
		var boot_sole := BoxMesh.new()
		boot_sole.size = Vector3(0.25, 0.035, 0.37)
		_human_part(parent, "BootSole_%s" % str(side), boot_sole, Vector3(side * 0.14, -0.845, -0.06), dark_fabric)
	var belt := BoxMesh.new()
	belt.size = Vector3(0.42, 0.075, 0.29)
	_human_part(parent, "UtilityBelt", belt, Vector3(0, -0.17, 0), dark_fabric)
	var buckle := BoxMesh.new()
	buckle.size = Vector3(0.075, 0.055, 0.025)
	_human_part(parent, "UtilityBuckle", buckle, Vector3(0, -0.17, -0.157), trim)
	var oxygen_tank := CylinderMesh.new()
	oxygen_tank.top_radius = 0.065
	oxygen_tank.bottom_radius = 0.065
	oxygen_tank.height = 0.34
	for side in [-1.0, 1.0]:
		_human_part(parent, "EmergencyOxygen_%s" % str(side), oxygen_tank, Vector3(side * 0.105, 0.13, 0.265), insulation)
	var chest_patch := BoxMesh.new()
	chest_patch.size = Vector3(0.105, 0.055, 0.018)
	_human_part(parent, "ExpeditionChestPatch", chest_patch, Vector3(-0.105, 0.19, -0.278), trim)
	# High-detail wearable kit: stitched seams, webbing, clips, headlamp and weathered gear.
	var seam_mat := _material(Color(0.025, 0.038, 0.045), 0.98, 0.0)
	var webbing_mat := _material(Color(0.11, 0.14, 0.15), 0.88, 0.02)
	var metal_mat := _material(Color(0.42, 0.49, 0.50), 0.34, 0.72)
	for side in [-1.0, 1.0]:
		var harness := BoxMesh.new()
		harness.size = Vector3(0.055, 0.42, 0.035)
		_human_part(parent, "HarnessStrap_%s" % str(side), harness, Vector3(side * 0.105, 0.075, -0.272), webbing_mat, Vector3(0, 0, side * -0.22))
		var thigh_pocket := BoxMesh.new()
		thigh_pocket.size = Vector3(0.105, 0.14, 0.055)
		_human_part(parent, "CargoPocket_%s" % str(side), thigh_pocket, Vector3(side * 0.19, -0.24, -0.12), insulation)
		var pocket_latch := BoxMesh.new()
		pocket_latch.size = Vector3(0.045, 0.018, 0.012)
		_human_part(parent, "CargoPocketLatch_%s" % str(side), pocket_latch, Vector3(side * 0.19, -0.20, -0.153), metal_mat)
		var cuff := CylinderMesh.new()
		cuff.top_radius = 0.088
		cuff.bottom_radius = 0.092
		cuff.height = 0.075
		_human_part(parent, "WristCuff_%s" % str(side), cuff, Vector3(side * 0.33, -0.255, -0.02), dark_fabric, Vector3(0, 0, deg_to_rad(90)))
	# Multiple small stitch lines break up the large flat surfaces at close range.
	for stitch_index in range(4):
		var stitch := BoxMesh.new()
		stitch.size = Vector3(0.12, 0.008, 0.009)
		_human_part(parent, "ParkaStitch_%02d" % stitch_index, stitch, Vector3(0.0, 0.19 - float(stitch_index) * 0.075, -0.257), seam_mat)
	var headlamp_mount := BoxMesh.new()
	headlamp_mount.size = Vector3(0.105, 0.045, 0.045)
	_human_part(parent, "HeadlampHousing", headlamp_mount, Vector3(0, 0.735, -0.135), dark_fabric)
	var headlamp_lens := SphereMesh.new()
	headlamp_lens.radius = 0.023
	headlamp_lens.height = 0.03
	var lamp_mat := _material(Color(0.72, 0.88, 1.0), 0.22, 0.1)
	lamp_mat.emission_enabled = true
	lamp_mat.emission = Color(0.48, 0.72, 1.0)
	lamp_mat.emission_energy_multiplier = 1.15
	_human_part(parent, "HeadlampLens", headlamp_lens, Vector3(0, 0.735, -0.164), lamp_mat)
	var radio_antenna := CylinderMesh.new()
	radio_antenna.top_radius = 0.006
	radio_antenna.bottom_radius = 0.012
	radio_antenna.height = 0.18
	_human_part(parent, "RadioAntenna", radio_antenna, Vector3(0.23, 0.22, 0.025), metal_mat, Vector3(0, 0, deg_to_rad(-8)))
	var radio_screen := BoxMesh.new()
	radio_screen.size = Vector3(0.043, 0.035, 0.009)
	_human_part(parent, "RadioScreen", radio_screen, Vector3(0.205, 0.12, -0.012), lens)
	if include_head:
		var neck := CylinderMesh.new()
		neck.top_radius = 0.075
		neck.bottom_radius = 0.085
		neck.height = 0.13
		_human_part(parent, "Neck", neck, Vector3(0, 0.40, 0), skin)
		var head := SphereMesh.new()
		head.radius = 0.145
		head.height = 0.34
		_human_part(parent, "HumanHead", head, Vector3(0, 0.59, -0.005), skin)
		# Balaclava/cap silhouette and polar goggles are always part of the outfit.
		var balaclava := SphereMesh.new()
		balaclava.radius = 0.151
		balaclava.height = 0.24
		_human_part(parent, "PolarBalaclava", balaclava, Vector3(0, 0.61, 0.0), insulation)
		var goggles := BoxMesh.new()
		goggles.size = Vector3(0.23, 0.065, 0.035)
		_human_part(parent, "SnowGoggles", goggles, Vector3(0, 0.625, -0.132), lens)
		var hair_cap := SphereMesh.new()
		hair_cap.radius = 0.15
		hair_cap.height = 0.16
		_human_part(parent, "Hair", hair_cap, Vector3(0, 0.69, 0.0), hair)
		for side in [-1.0, 1.0]:
			var eye := SphereMesh.new()
			eye.radius = 0.018
			eye.height = 0.03
			_human_part(parent, "Eye_%s" % str(side), eye, Vector3(side * 0.05, 0.60, -0.139), dark_fabric)
			var brow := BoxMesh.new()
			brow.size = Vector3(0.055, 0.014, 0.018)
			_human_part(parent, "Brow_%s" % str(side), brow, Vector3(side * 0.05, 0.635, -0.145), hair, Vector3(0, 0, side * -0.10))
		var nose := SphereMesh.new()
		nose.radius = 0.025
		nose.height = 0.045
		_human_part(parent, "NoseBridge", nose, Vector3(0, 0.565, -0.15), skin)
		var respirator := BoxMesh.new()
		respirator.size = Vector3(0.16, 0.075, 0.055)
		_human_part(parent, "PolarRespirator", respirator, Vector3(0, 0.535, -0.145), dark_fabric)

func _add_creature_model(parent: Node3D) -> void:
	# Distinct procedural creature silhouette: elongated anatomy, asymmetry, exposed ribs and hooked claws.
	# Kept lightweight for mobile rendering; all geometry is generated from Godot primitives.
	var hide_mat := _material(Color(0.012, 0.018, 0.022), 0.98, 0.0)
	var chitin := _material(Color(0.045, 0.065, 0.069), 0.62, 0.12)
	var bone := _material(Color(0.22, 0.27, 0.25), 0.82, 0.0)
	var wound := _material(Color(0.19, 0.018, 0.012), 0.7, 0.0)
	var glow := StandardMaterial3D.new()
	glow.albedo_color = Color(0.72, 0.018, 0.006)
	glow.emission_enabled = true
	glow.emission = Color(0.95, 0.012, 0.003)
	glow.emission_energy_multiplier = 2.4
	var torso := CapsuleMesh.new()
	torso.radius = 0.30
	torso.height = 0.96
	_human_part(parent, "NarrowTorso", torso, Vector3(0, 0.12, 0), hide_mat, Vector3(0, 0, deg_to_rad(-7.0)))
	var sternum := BoxMesh.new()
	sternum.size = Vector3(0.12, 0.66, 0.12)
	_human_part(parent, "ExposedSternum", sternum, Vector3(0, 0.10, -0.265), bone)
	for rib_index in range(5):
		var rib := TorusMesh.new()
		rib.inner_radius = 0.105
		rib.outer_radius = 0.135
		rib.rings = 5
		rib.ring_segments = 8
		var rib_node := _human_part(parent, "Rib_%02d" % rib_index, rib, Vector3(0, 0.28 - float(rib_index) * 0.13, -0.22), bone, Vector3(deg_to_rad(90), 0, 0))
		rib_node.scale = Vector3(1.55, 0.78, 1.0)
	var neck := CylinderMesh.new()
	neck.top_radius = 0.105
	neck.bottom_radius = 0.19
	neck.height = 0.42
	_human_part(parent, "ElongatedNeck", neck, Vector3(0, 0.68, 0.015), chitin, Vector3(0, 0, deg_to_rad(-8.0)))
	var skull := SphereMesh.new()
	skull.radius = 0.205
	skull.height = 0.53
	_human_part(parent, "WedgeSkull", skull, Vector3(0, 0.99, -0.035), hide_mat, Vector3(deg_to_rad(-12), 0, 0))
	# Secondary carapace ridges and wet-looking tendons give the creature a less blocky silhouette.
	var ridge_mat := _material(Color(0.075, 0.095, 0.095), 0.52, 0.18)
	for ridge_index in range(4):
		var ridge := CapsuleMesh.new()
		ridge.radius = 0.035
		ridge.height = 0.48 - float(ridge_index) * 0.045
		_human_part(parent, "DorsalRidge_%02d" % ridge_index, ridge, Vector3(-0.16 + float(ridge_index) * 0.105, 0.22, 0.18), ridge_mat, Vector3(deg_to_rad(16), 0, deg_to_rad(-12)))
	var face_plate := BoxMesh.new()
	face_plate.size = Vector3(0.22, 0.18, 0.09)
	_human_part(parent, "FacePlate", face_plate, Vector3(0, 0.91, -0.205), chitin, Vector3(deg_to_rad(-12), 0, 0))
	for side in [-1.0, 1.0]:
		var eye := SphereMesh.new()
		eye.radius = 0.038
		eye.height = 0.07
		_human_part(parent, "PredatorEye_%s" % str(side), eye, Vector3(side * 0.105, 1.035, -0.205), glow)
		var shoulder := SphereMesh.new()
		shoulder.radius = 0.19
		shoulder.height = 0.31
		_human_part(parent, "AsymmetricShoulder_%s" % str(side), shoulder, Vector3(side * 0.29, 0.40, 0.015), chitin, Vector3(0, 0, side * 0.2))
		var arm := CapsuleMesh.new()
		arm.radius = 0.105 if side < 0 else 0.13
		arm.height = 0.86 if side < 0 else 1.02
		_human_part(parent, "LongArm_%s" % str(side), arm, Vector3(side * 0.39, -0.08, -0.005), hide_mat, Vector3(0, 0, side * -0.18))
		var forearm := CapsuleMesh.new()
		forearm.radius = 0.075
		forearm.height = 0.55
		_human_part(parent, "ForearmPlate_%s" % str(side), forearm, Vector3(side * 0.46, -0.43, -0.02), chitin, Vector3(0, 0, side * -0.14))
		for claw_index in range(3):
			var claw: CylinderMesh = CylinderMesh.new()
			claw.top_radius = 0.0
			claw.bottom_radius = 0.025
			claw.height = 0.22
			_human_part(parent, "HookClaw_%s_%d" % [str(side), claw_index], claw, Vector3(side * (0.42 + float(claw_index) * 0.065), -0.76, -0.10), bone, Vector3(deg_to_rad(155), 0, side * -0.12))
		var thigh := CapsuleMesh.new()
		thigh.radius = 0.14
		thigh.height = 0.55
		_human_part(parent, "ReverseLeg_%s" % str(side), thigh, Vector3(side * 0.15, -0.48, 0.035), hide_mat, Vector3(deg_to_rad(7), 0, side * 0.08))
		var shin := CapsuleMesh.new()
		shin.radius = 0.075
		shin.height = 0.54
		_human_part(parent, "ShinSpur_%s" % str(side), shin, Vector3(side * 0.17, -0.76, -0.005), chitin, Vector3(deg_to_rad(-9), 0, side * -0.04))
	var tendril := CapsuleMesh.new()
	tendril.radius = 0.035
	tendril.height = 0.75
	_human_part(parent, "TrailingTendril", tendril, Vector3(0.08, 0.05, 0.28), wound, Vector3(deg_to_rad(35), 0, deg_to_rad(-24)))
	for plate_index in range(3):
		var plate := SphereMesh.new()
		plate.radius = 0.10
		plate.height = 0.16
		_human_part(parent, "BackSpine_%d" % plate_index, plate, Vector3(0, 0.35 - float(plate_index) * 0.19, 0.22), chitin, Vector3(deg_to_rad(22), 0, 0))

func _build_player() -> void:
	var player := CharacterBody3D.new()
	player.name = "Player"
	# Use exactly one capsule collider. Duplicate overlapping colliders can cause
	# unstable CharacterBody3D movement, especially through a narrow doorway.
	var collider := CollisionShape3D.new()
	collider.name = "CollisionShape3D"
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.32
	capsule.height = 1.75
	collider.shape = capsule
	player.add_child(collider)
	player.set_script(PLAYER_SCRIPT)
	player.position = Vector3(0, 0.95, 4.2)
	var camera_pivot := Node3D.new()
	camera_pivot.name = "CameraPivot"
	camera_pivot.position = Vector3(0, 0.55, 0)
	player.add_child(camera_pivot)
	var camera := Camera3D.new()
	camera.name = "Camera3D"
	camera.current = true
	camera.fov = 82
	camera_pivot.add_child(camera)
	var ray := RayCast3D.new()
	ray.name = "InteractionRay"
	ray.target_position = Vector3(0, 0, -2.8)
	ray.collide_with_areas = true
	ray.collide_with_bodies = true
	camera.add_child(ray)
	var flashlight := SpotLight3D.new()
	flashlight.name = "Flashlight"
	flashlight.position = Vector3(0.12, -0.08, -0.15)
	flashlight.rotation_degrees = Vector3(-3, 0, 0)
	flashlight.light_energy = 3.1
	flashlight.spot_range = 17
	flashlight.spot_angle = 34
	flashlight.shadow_enabled = true
	camera.add_child(flashlight)
	_add_human_model(player, Color(0.24, 0.42, 0.48), false, false)
	add_child(player)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "HUD"
	add_child(layer)
	capture_overlay = PanelContainer.new()
	capture_overlay.name = "CaptureOverlay"
	capture_overlay.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	capture_overlay.offset_left = -210
	capture_overlay.offset_top = -90
	capture_overlay.offset_right = 210
	capture_overlay.offset_bottom = 90
	capture_overlay.visible = false
	var capture_box := VBoxContainer.new()
	capture_box.add_theme_constant_override("separation", 12)
	capture_overlay.add_child(capture_box)
	capture_message = Label.new()
	capture_message.text = "A CRIATURA AGARROU-TE!"
	capture_message.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	capture_message.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	capture_message.add_theme_font_size_override("font_size", 18)
	capture_box.add_child(capture_message)
	capture_button = Button.new()
	capture_button.name = "EscapeCaptureButton"
	capture_button.text = "TOCA RAPIDAMENTE PARA TE LIBERTARES"
	capture_button.custom_minimum_size = Vector2(0, 58)
	capture_button.pressed.connect(request_capture_escape)
	capture_box.add_child(capture_button)
	layer.add_child(capture_overlay)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	layer.add_child(center)
	var reticle := Label.new()
	reticle.text = "+"
	reticle.add_theme_font_size_override("font_size", 24)
	reticle.add_theme_color_override("font_color", Color(0.82, 0.88, 0.9, 0.85))
	center.add_child(reticle)
	var prompt := Label.new()
	prompt.name = "Prompt"
	prompt.text = "MOVER: joystick · OLHAR: arrasta à direita · INTERAGIR / LANTERNA / AGACHAR: botões"
	prompt.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	prompt.anchor_left = 0.06
	prompt.anchor_right = 0.94
	prompt.offset_top = -54
	prompt.offset_bottom = -14
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	prompt.add_theme_font_size_override("font_size", 14)
	prompt.add_theme_color_override("font_color", Color(0.78, 0.82, 0.84))
	layer.add_child(prompt)
	# Painel de combinação da porta secreta — aberto apenas ao interagir com a consola.
	secret_combination_panel = PanelContainer.new()
	secret_combination_panel.name = "SecretCombinationPanel"
	secret_combination_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	secret_combination_panel.offset_left = -190
	secret_combination_panel.offset_top = -120
	secret_combination_panel.offset_right = 190
	secret_combination_panel.offset_bottom = 120
	secret_combination_panel.visible = false
	var combo_box := VBoxContainer.new()
	combo_box.add_theme_constant_override("separation", 10)
	secret_combination_panel.add_child(combo_box)
	var combo_title := Label.new()
	combo_title.text = "FECHADURA VANTHIS"
	combo_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_title.add_theme_font_size_override("font_size", 20)
	combo_box.add_child(combo_title)
	var combo_hint := Label.new()
	combo_hint.text = "Cruza os registos de turno, os ciclos válidos, os avisos confirmados e a ordem real dos procedimentos. Nenhum documento contém o código completo."
	combo_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	combo_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	combo_box.add_child(combo_hint)
	secret_combination_input = LineEdit.new()
	secret_combination_input.name = "SecretCombinationInput"
	secret_combination_input.placeholder_text = "Código de 4 algarismos"
	secret_combination_input.max_length = 4
	secret_combination_input.alignment = HORIZONTAL_ALIGNMENT_CENTER
	secret_combination_input.virtual_keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
	combo_box.add_child(secret_combination_input)
	var combo_buttons := HBoxContainer.new()
	combo_buttons.alignment = BoxContainer.ALIGNMENT_CENTER
	combo_box.add_child(combo_buttons)
	var combo_submit := Button.new()
	combo_submit.text = "VALIDAR CÓDIGO"
	combo_submit.custom_minimum_size = Vector2(150, 44)
	combo_submit.pressed.connect(_submit_secret_combination)
	combo_buttons.add_child(combo_submit)
	var combo_cancel := Button.new()
	combo_cancel.text = "FECHAR"
	combo_cancel.custom_minimum_size = Vector2(90, 44)
	combo_cancel.pressed.connect(func(): secret_combination_panel.visible = false)
	combo_buttons.add_child(combo_cancel)
	layer.add_child(secret_combination_panel)
	var title := Label.new()
	title.text = "EXPEDIÇÃO 01  /  ESTAÇÃO VÉSPERA"
	title.position = Vector2(18, 14)
	title.add_theme_font_size_override("font_size", 15)
	title.add_theme_color_override("font_color", Color(0.73, 0.78, 0.81))
	layer.add_child(title)
	exterior_weather_label = Label.new()
	exterior_weather_label.name = "ExteriorWeatherStatus"
	exterior_weather_label.position = Vector2(18, 96)
	exterior_weather_label.size = Vector2(520, 26)
	exterior_weather_label.visible = false
	exterior_weather_label.add_theme_font_size_override("font_size", 14)
	exterior_weather_label.add_theme_color_override("font_color", Color(0.64, 0.86, 0.96))
	layer.add_child(exterior_weather_label)
	stealth_status = Label.new()
	stealth_status.name = "StealthStatus"
	stealth_status.position = Vector2(18, 32)
	stealth_status.add_theme_font_size_override("font_size", 14)
	stealth_status.add_theme_color_override("font_color", Color(0.65, 0.82, 0.76))
	layer.add_child(stealth_status)
	private_clue = Label.new()
	private_clue.name = "PrivateClue"
	private_clue.position = Vector2(18, 52)
	private_clue.size = Vector2( minf(500.0, get_viewport().get_visible_rect().size.x * 0.48), 82)
	private_clue.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	private_clue.add_theme_font_size_override("font_size", 17)
	private_clue.add_theme_color_override("font_color", Color(0.94, 0.78, 0.48))
	layer.add_child(private_clue)
	_update_private_clue()
	# Native Godot touch buttons for mobile. Buttons are deliberately large.
	var player := get_node_or_null("Player")
	if player:
		var action_box := VBoxContainer.new()
		action_box.name = "TouchActions"
		action_box.anchor_left = 1.0
		action_box.anchor_top = 1.0
		action_box.anchor_right = 1.0
		action_box.anchor_bottom = 1.0
		# Margens de segurança para ecrãs Android com proporções diferentes.
		action_box.offset_left = -174
		action_box.offset_top = -210
		action_box.offset_right = -18
		action_box.offset_bottom = -18
		action_box.add_theme_constant_override("separation", 12)
		layer.add_child(action_box)
		var interact_button := Button.new()
		interact_button.name = "InteractButton"
		interact_button.text = "INTERAGIR"
		interact_button.custom_minimum_size = Vector2(150, 52)
		interact_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		interact_button.add_theme_font_size_override("font_size", 16)
		interact_button.pressed.connect(Callable(player, "interact_now"))
		action_box.add_child(interact_button)
		var flashlight_button := Button.new()
		flashlight_button.name = "FlashlightButton"
		flashlight_button.text = "LANTERNA"
		flashlight_button.custom_minimum_size = Vector2(150, 48)
		flashlight_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		flashlight_button.add_theme_font_size_override("font_size", 15)
		flashlight_button.pressed.connect(Callable(player, "toggle_flashlight"))
		action_box.add_child(flashlight_button)
		var crouch_button := Button.new()
		crouch_button.name = "CrouchButton"
		# Texto curto para não ser cortado em ecrãs estreitos.
		crouch_button.text = "AGACHAR"
		crouch_button.tooltip_text = "Alternar entre agachado e de pé"
		crouch_button.custom_minimum_size = Vector2(150, 48)
		crouch_button.size_flags_horizontal = Control.SIZE_SHRINK_END
		crouch_button.add_theme_font_size_override("font_size", 12)
		crouch_button.pressed.connect(Callable(player, "toggle_crouch"))
		action_box.add_child(crouch_button)
		# Guardar a referência real do botão já integrado na árvore.
		# O controlador consulta "crouch_button_ref" para atualizar AGACHAR/LEVANTAR.
		player.set_meta("crouch_button_ref", crouch_button)
	var decision_panel := PanelContainer.new()
	decision_panel.name = "ConfrontationPanel"
	decision_panel.position = Vector2(18, 138)
	decision_panel.custom_minimum_size = Vector2( minf(330.0, get_viewport().get_visible_rect().size.x * 0.46), 0)
	var decision_box := VBoxContainer.new()
	decision_box.add_theme_constant_override("separation", 8)
	decision_panel.add_child(decision_box)
	var decision_title := Label.new()
	decision_title.text = "CONFRONTO  /  OPERADOR 07"
	decision_title.add_theme_font_size_override("font_size", 16)
	decision_title.add_theme_color_override("font_color", Color(0.85, 0.78, 0.62))
	decision_box.add_child(decision_title)
	var decision_hint := Label.new()
	decision_hint.text = "Após partilharem as pistas, escolhe uma posição. A decisão conjunta altera a missão."
	decision_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_hint.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 44)
	decision_hint.add_theme_font_size_override("font_size", 14)
	decision_box.add_child(decision_hint)
	accusation_button = Button.new()
	accusation_button.text = "ACUSAR — ativar contenção"
	accusation_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	accusation_button.pressed.connect(submit_decision.bind("ACUSAR"))
	decision_box.add_child(accusation_button)
	defense_button = Button.new()
	defense_button.text = "DEFENDER — manter acesso"
	defense_button.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 38)
	defense_button.pressed.connect(submit_decision.bind("DEFENDER"))
	decision_box.add_child(defense_button)
	decision_status = Label.new()
	decision_status.text = "Decisão pendente: compara as pistas em voz alta."
	decision_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	decision_status.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 30)
	decision_status.add_theme_font_size_override("font_size", 13)
	decision_status.add_theme_color_override("font_color", Color(0.72, 0.82, 0.86))
	decision_box.add_child(decision_status)
	entity_reaction_label = Label.new()
	entity_reaction_label.name = "EntityReaction"
	entity_reaction_label.text = "Sem presença confirmada."
	entity_reaction_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	entity_reaction_label.custom_minimum_size = Vector2( minf(300.0, get_viewport().get_visible_rect().size.x * 0.42), 28)
	entity_reaction_label.add_theme_font_size_override("font_size", 13)
	entity_reaction_label.add_theme_color_override("font_color", Color(0.95, 0.3, 0.22))
	decision_box.add_child(entity_reaction_label)
	layer.add_child(decision_panel)
	# Joystick virtual visível, ao estilo dos jogos mobile (canto inferior esquerdo).
	var joystick := Control.new()
	joystick.name = "VirtualJoystick"
	joystick.set_script(load("res://scripts/virtual_joystick.gd"))
	joystick.anchor_left = 0.0
	joystick.anchor_top = 1.0
	joystick.anchor_right = 0.0
	joystick.anchor_bottom = 1.0
	joystick.offset_left = 22.0
	joystick.offset_top = -184.0
	joystick.offset_right = 178.0
	joystick.offset_bottom = -28.0
	joystick.z_index = 10
	layer.add_child(joystick)
	var player_for_joystick := get_node_or_null("Player")
	if player_for_joystick:
		joystick.value_changed.connect(Callable(player_for_joystick, "set_touch_move"))
	# LAN controls: host/join must be accessible in the actual HUD, not only in code.
	var network_panel := PanelContainer.new()
	network_panel.name = "NetworkPanel"
	network_panel.anchor_left = 1.0
	network_panel.anchor_right = 1.0
	network_panel.offset_left = -360
	network_panel.offset_top = 58
	network_panel.offset_right = -16
	network_panel.offset_bottom = 218
	network_panel.custom_minimum_size = Vector2(344, 160)
	network_panel.visible = false
	var network_box := VBoxContainer.new()
	network_box.add_theme_constant_override("separation", 5)
	network_panel.add_child(network_box)
	var network_title := Label.new()
	network_title.text = "COOPERAÇÃO LAN · UDP %d" % PORT
	network_title.add_theme_font_size_override("font_size", 14)
	network_box.add_child(network_title)
	ip_input = LineEdit.new()
	ip_input.name = "HostAddress"
	ip_input.placeholder_text = "IP do anfitrião (ex.: 192.168.1.35)"
	ip_input.text = ""
	ip_input.custom_minimum_size = Vector2(0, 36)
	network_box.add_child(ip_input)
	var network_buttons := HBoxContainer.new()
	var host_button := Button.new()
	host_button.text = "CRIAR SESSÃO"
	host_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	host_button.pressed.connect(host_game)
	network_buttons.add_child(host_button)
	var join_button := Button.new()
	join_button.text = "LIGAR À SESSÃO"
	join_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	join_button.pressed.connect(join_game)
	network_buttons.add_child(join_button)
	network_box.add_child(network_buttons)
	network_status = Label.new()
	network_status.name = "NetworkStatus"
	network_status.text = "Jogador 1: CRIAR SESSÃO. Jogador 2: introduz o IP do anfitrião e toca em LIGAR À SESSÃO. Mesma WLAN; internet não necessária."
	network_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	network_status.add_theme_font_size_override("font_size", 12)
	network_box.add_child(network_status)
	layer.add_child(network_panel)
	var network_toggle := Button.new()
	network_toggle.name = "NetworkToggle"
	network_toggle.text = "REDE LAN"
	network_toggle.anchor_left = 1.0
	network_toggle.anchor_right = 1.0
	network_toggle.offset_left = -124
	network_toggle.offset_top = 20
	network_toggle.offset_right = -16
	network_toggle.offset_bottom = 54
	network_toggle.pressed.connect(_toggle_network_panel.bind(network_panel))
	layer.add_child(network_toggle)
	# Mini-mapa global ampliado: complexo, salas e exterior, legível em ecrãs móveis.
	var mini_map := Control.new()
	mini_map.name = "MiniMapaSala"
	mini_map.set_script(load("res://scripts/mini_map.gd"))
	mini_map.anchor_left = 1.0
	mini_map.anchor_right = 1.0
	mini_map.anchor_top = 0.0
	mini_map.anchor_bottom = 0.0
	mini_map.anchor_top = 0.34
	mini_map.anchor_bottom = 0.34
	mini_map.offset_left = -316.0
	mini_map.offset_top = 0.0
	mini_map.offset_right = -16.0
	mini_map.offset_bottom = 270.0
	mini_map.z_index = 5
	layer.add_child(mini_map)
	# HUB DE JOGO: objetivos, inventário, equipa, dossier, comunicação rápida e pausa.
	var hub_toggle := Button.new()
	hub_toggle.name = "MissionHubToggle"
	hub_toggle.text = "MISSÃO  /  EQUIPA"
	hub_toggle.anchor_left = 0.0
	hub_toggle.anchor_right = 0.0
	hub_toggle.anchor_top = 0.0
	hub_toggle.anchor_bottom = 0.0
	hub_toggle.offset_left = 18
	hub_toggle.offset_top = 82
	hub_toggle.offset_right = 190
	hub_toggle.offset_bottom = 122
	hub_toggle.pressed.connect(_toggle_mission_hub)
	layer.add_child(hub_toggle)
	var pause_button := Button.new()
	pause_button.name = "PauseButton"
	pause_button.text = "Ⅱ  PAUSA"
	pause_button.anchor_left = 1.0
	pause_button.anchor_right = 1.0
	pause_button.offset_left = -124
	pause_button.offset_top = 60
	pause_button.offset_right = -16
	pause_button.offset_bottom = 98
	pause_button.pressed.connect(_toggle_pause_menu)
	layer.add_child(pause_button)
	mission_hub = PanelContainer.new()
	mission_hub.name = "MissionHub"
	mission_hub.anchor_left = 0.5
	mission_hub.anchor_top = 0.5
	mission_hub.anchor_right = 0.5
	mission_hub.anchor_bottom = 0.5
	mission_hub.offset_left = -minf(330.0, get_viewport().get_visible_rect().size.x * 0.44)
	mission_hub.offset_top = -minf(260.0, get_viewport().get_visible_rect().size.y * 0.40)
	mission_hub.offset_right = minf(330.0, get_viewport().get_visible_rect().size.x * 0.44)
	mission_hub.offset_bottom = minf(260.0, get_viewport().get_visible_rect().size.y * 0.40)
	mission_hub.visible = false
	mission_hub.z_index = 40
	var hub_stack := VBoxContainer.new()
	hub_stack.add_theme_constant_override("separation", 8)
	mission_hub.add_child(hub_stack)
	mission_hub_title = Label.new()
	mission_hub_title.text = "CENTRO DE MISSÃO"
	mission_hub_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mission_hub_title.add_theme_font_size_override("font_size", 20)
	hub_stack.add_child(mission_hub_title)
	var tab_row := GridContainer.new()
	tab_row.columns = 2
	tab_row.add_theme_constant_override("h_separation", 6)
	tab_row.add_theme_constant_override("v_separation", 6)
	for tab_name in ["OBJETIVOS", "INVENTÁRIO", "EQUIPA", "DOSSIÊ"]:
		var tab_button := Button.new()
		tab_button.text = tab_name
		tab_button.custom_minimum_size = Vector2(130, 40)
		tab_button.pressed.connect(_set_mission_hub_tab.bind(tab_name))
		tab_row.add_child(tab_button)
	hub_stack.add_child(tab_row)
	mission_hub_body = Label.new()
	mission_hub_body.name = "MissionHubBody"
	mission_hub_body.custom_minimum_size = Vector2(0, 185)
	mission_hub_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	mission_hub_body.vertical_alignment = VERTICAL_ALIGNMENT_TOP
	mission_hub_body.add_theme_font_size_override("font_size", 15)
	hub_stack.add_child(mission_hub_body)
	quick_comms_status = Label.new()
	quick_comms_status.text = "Comunicação rápida disponível em sessão LAN."
	quick_comms_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	quick_comms_status.add_theme_font_size_override("font_size", 12)
	hub_stack.add_child(quick_comms_status)
	var comms_row := HBoxContainer.new()
	for comm in ["ESTOU AQUI", "PRECISO DE AJUDA", "VEM AO RELÉ"]:
		var comm_button := Button.new()
		comm_button.text = comm
		comm_button.custom_minimum_size = Vector2(0, 40)
		comm_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		comm_button.pressed.connect(_send_quick_comms.bind(comm))
		comms_row.add_child(comm_button)
	hub_stack.add_child(comms_row)
	var hub_close := Button.new()
	hub_close.text = "VOLTAR AO JOGO"
	hub_close.custom_minimum_size = Vector2(0, 44)
	hub_close.pressed.connect(_toggle_mission_hub)
	hub_stack.add_child(hub_close)
	layer.add_child(mission_hub)
	_refresh_mission_hub()
	_apply_gamer_ui_style(layer)


func _toggle_mission_hub() -> void:
	if mission_hub == null:
		return
	mission_hub.visible = not mission_hub.visible
	if mission_hub.visible:
		_refresh_mission_hub()


func _set_mission_hub_tab(tab_name: String) -> void:
	mission_hub_tab = tab_name
	_refresh_mission_hub()


func _refresh_mission_hub() -> void:
	if mission_hub_body == null:
		return
	local_player_id = multiplayer.get_unique_id()
	var connected_count := multiplayer.get_peers().size() + 1 if multiplayer.multiplayer_peer != null else 1
	var objective_a := "CONCLUÍDO" if int(switch_owners.get("A", 0)) > 0 else "PENDENTE"
	var objective_b := "CONCLUÍDO" if int(switch_owners.get("B", 0)) > 0 else "PENDENTE"
	match mission_hub_tab:
		"OBJETIVOS":
			mission_hub_title.text = "OBJETIVOS DA EXPEDIÇÃO"
			if _is_solo_session():
				var evidence_objective := "Analisar os registos recolhidos" if experiment_clues_found.size() >= 10 else "Recolher provas e registos da estação"
				mission_hub_body.text = "MISSÃO: Estação Véspera — MODO INDIVIDUAL\n\n%s  Ativar o Relé A\n%s  Regressar e ativar o Relé B\n%s  Restabelecer a energia da câmara\n%s  Recolher as 10 provas\n%s  %s\n\nTodas as tarefas disponíveis podem ser concluídas por ti. Explora a estação, examina os objetos e cruza os registos. Algumas descobertas só se tornam claras depois de reunires provas suficientes." % ["✓" if objective_a == "CONCLUÍDO" else "○", "✓" if objective_b == "CONCLUÍDO" else "○", "✓" if coop_solved else "○", "✓" if experiment_clues_found.size() >= 10 else "○", "✓" if evidence_synthesis_complete else "○", evidence_objective]
			else:
				mission_hub_body.text = "MISSÃO: Estação Véspera\n\n%s  Ativar o Relé A\n%s  Ativar o Relé B\n%s  Usar dois participantes diferentes nos relés\n%s  Resolver o acesso à câmara de contenção\n\nTrabalha com outro jogador: os dois relés estão separados." % ["✓" if objective_a == "CONCLUÍDO" else "○", "✓" if objective_b == "CONCLUÍDO" else "○", "✓" if coop_solved else "○", "✓" if coop_solved else "○"]
		"INVENTÁRIO":
			mission_hub_title.text = "EQUIPAMENTO E INVENTÁRIO"
			mission_hub_body.text = "EQUIPAMENTO POLAR VISÍVEL\n• Parka térmica com capuz e proteção facial\n• Óculos de neve, luvas isolantes e botas polares\n• Mochila de sobrevivência e rádio de emergência\n• Lanterna — alternar no botão LANTERNA\n• Modo furtivo — botão AGACHAR\n\nA roupa é visual nesta revisão. Temperatura corporal, hipotermia e desgaste do equipamento ainda não são sistemas de sobrevivência funcionais."
		"EQUIPA":
			mission_hub_title.text = "ESTADO DA EQUIPA"
			var team_text := "Participantes na sessão: %d\n" % connected_count
			team_text += "Anfitrião: %s\n" % ("ligado" if multiplayer.multiplayer_peer != null else "sessão local")
			team_text += "Relé A: %s\nRelé B: %s\n" % ["ativo" if int(switch_owners.get("A", 0)) > 0 else "por ativar", "ativo" if int(switch_owners.get("B", 0)) > 0 else "por ativar"]
			team_text += "Cooperação: %s\n\nUsa a comunicação rápida abaixo para coordenar a equipa." % ("objetivo cooperativo concluído" if coop_solved else "a aguardar ações de participantes diferentes")
			mission_hub_body.text = team_text
		"DOSSIÊ":
			mission_hub_title.text = "DOSSIÊ PESSOAL"
			mission_hub_body.text = "REGISTO PRIVADO DO PARTICIPANTE\n\n%s\n\nAs pistas deste painel são pessoais. Partilha verbalmente a informação com a equipa; o painel não revela papéis secretos de outros jogadores." % (private_clue.text if private_clue != null else "Ainda não há registo disponível.")
	if quick_comms_status != null and multiplayer.multiplayer_peer == null:
		quick_comms_status.text = "Comunicação rápida: cria ou entra numa sessão LAN para enviar mensagens à equipa."


func _send_quick_comms(message: String) -> void:
	if multiplayer.multiplayer_peer == null:
		if quick_comms_status:
			quick_comms_status.text = "Sem sessão LAN. Abre REDE LAN e cria/entra numa sessão para comunicar."
		return
	if multiplayer.is_server():
		_apply_quick_comms(multiplayer.get_unique_id(), message)
		for peer_id in multiplayer.get_peers():
			rpc_id(int(peer_id), "receive_quick_comms", multiplayer.get_unique_id(), message)
	else:
		rpc_id(1, "server_quick_comms", message)


@rpc("any_peer", "call_remote", "reliable")
func server_quick_comms(message: String) -> void:
	if not multiplayer.is_server():
		return
	var sender := multiplayer.get_remote_sender_id()
	_apply_quick_comms(sender, message)
	for peer_id in multiplayer.get_peers():
		if int(peer_id) != sender:
			rpc_id(int(peer_id), "receive_quick_comms", sender, message)


@rpc("authority", "call_remote", "reliable")
func receive_quick_comms(sender_id: int, message: String) -> void:
	_apply_quick_comms(sender_id, message)


func _apply_quick_comms(sender_id: int, message: String) -> void:
	if quick_comms_status:
		quick_comms_status.text = "EQUIPA · Jogador %d: %s" % [sender_id, message]
	if network_status:
		network_status.text = "Comunicação rápida · Jogador %d: %s" % [sender_id, message]


func _toggle_pause_menu() -> void:
	if game_paused_by_menu:
		game_paused_by_menu = false
		get_tree().paused = false
		return
	var pause_layer := get_node_or_null("PauseOverlay") as CanvasLayer
	if pause_layer:
		pause_layer.queue_free()
		pause_layer = null
	pause_layer = CanvasLayer.new()
	pause_layer.name = "PauseOverlay"
	pause_layer.layer = 120
	pause_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(pause_layer)
	var dim := ColorRect.new()
	dim.color = Color(0.005, 0.012, 0.018, 0.88)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(minf(420.0, get_viewport().get_visible_rect().size.x - 36.0), 0)
	center.add_child(panel)
	var stack := VBoxContainer.new()
	stack.add_theme_constant_override("separation", 12)
	panel.add_child(stack)
	var heading := Label.new()
	heading.text = "EXPEDIÇÃO EM PAUSA"
	heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	heading.add_theme_font_size_override("font_size", 22)
	stack.add_child(heading)
	var resume := Button.new()
	resume.text = "RETOMAR EXPEDIÇÃO"
	resume.custom_minimum_size = Vector2(0, 48)
	resume.pressed.connect(func(): game_paused_by_menu = false; get_tree().paused = false; pause_layer.queue_free())
	stack.add_child(resume)
	var sound_info := Label.new()
	sound_info.text = "Áudio, ecrã e rede LAN estão disponíveis no menu de opções/rede. A sessão cooperativa não é terminada ao pausar."
	sound_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stack.add_child(sound_info)
	get_tree().paused = true
	game_paused_by_menu = true


func _gamer_style(bg: Color, border_color: Color, border_size: int = 1, radius: int = 8) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = bg
	style.border_color = border_color
	style.set_border_width_all(border_size)
	style.set_corner_radius_all(radius)
	style.content_margin_left = 12.0
	style.content_margin_right = 12.0
	style.content_margin_top = 7.0
	style.content_margin_bottom = 7.0
	return style


func _apply_gamer_ui_style(node: Node) -> void:
	# Tactical premium interface: deep blue-green surfaces, warm gold accents, large touch targets.
	if node is Button:
		var button := node as Button
		button.add_theme_stylebox_override("normal", _gamer_style(Color(0.035, 0.085, 0.105, 0.98), Color(0.14, 0.44, 0.49, 0.95), 1, 8))
		button.add_theme_stylebox_override("hover", _gamer_style(Color(0.07, 0.17, 0.19, 1.0), Color(0.82, 0.58, 0.28, 1.0), 2, 8))
		button.add_theme_stylebox_override("pressed", _gamer_style(Color(0.10, 0.20, 0.20, 1.0), Color(0.95, 0.72, 0.38, 1.0), 2, 8))
		button.add_theme_stylebox_override("focus", _gamer_style(Color(0.06, 0.15, 0.17, 1.0), Color(0.35, 0.82, 0.86, 1.0), 2, 8))
		button.add_theme_font_size_override("font_size", 15)
		button.add_theme_color_override("font_color", Color(0.91, 0.95, 0.96))
		button.add_theme_color_override("font_hover_color", Color(1.0, 0.84, 0.52))
		button.add_theme_color_override("font_pressed_color", Color(1.0, 0.88, 0.65))
		button.add_theme_color_override("font_focus_color", Color(1.0, 1.0, 1.0))
		button.add_theme_color_override("font_disabled_color", Color(0.40, 0.48, 0.52))
	elif node is PanelContainer:
		(node as PanelContainer).add_theme_stylebox_override("panel", _gamer_style(Color(0.012, 0.028, 0.038, 0.98), Color(0.14, 0.38, 0.43, 0.98), 1, 12))
	elif node is LineEdit:
		var edit := node as LineEdit
		edit.add_theme_stylebox_override("normal", _gamer_style(Color(0.02, 0.045, 0.06, 0.98), Color(0.12, 0.38, 0.46, 1.0), 1, 6))
		edit.add_theme_stylebox_override("focus", _gamer_style(Color(0.025, 0.065, 0.08, 1.0), Color(0.20, 0.88, 1.0, 1.0), 2, 6))
		edit.add_theme_color_override("font_color", Color(0.88, 0.96, 1.0))
		edit.add_theme_color_override("font_placeholder_color", Color(0.42, 0.58, 0.63))
	elif node is Label:
		var label := node as Label
		label.add_theme_color_override("font_shadow_color", Color(0.0, 0.0, 0.0, 0.85))
		label.add_theme_constant_override("shadow_offset_x", 1)
		label.add_theme_constant_override("shadow_offset_y", 1)
	for child in node.get_children():
		_apply_gamer_ui_style(child)


# Menu inicial gamer: configurações, ligação e regras detalhadas.
var main_menu_layer: CanvasLayer
var main_menu_content: VBoxContainer
var main_menu_ip: LineEdit
var menu_status_label: Label

func _build_main_menu() -> void:
	main_menu_layer = CanvasLayer.new()
	main_menu_layer.name = "MainMenu"
	main_menu_layer.layer = 100
	add_child(main_menu_layer)
	var menu_background := TextureRect.new()
	menu_background.name = "MenuCinematicBackground"
	menu_background.texture = load("res://art/menu_estacao_vespera.png") as Texture2D
	menu_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	menu_background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	menu_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	main_menu_layer.add_child(menu_background)
	var dim := ColorRect.new()
	# Escurece a arte para manter o texto e os controlos legíveis em telemóveis.
	dim.color = Color(0.008, 0.018, 0.028, 0.70)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main_menu_layer.add_child(dim)
	var outer := CenterContainer.new()
	outer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	outer.offset_left = 18
	outer.offset_top = 12
	outer.offset_right = -18
	outer.offset_bottom = -12
	main_menu_layer.add_child(outer)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2( minf(620.0, get_viewport().get_visible_rect().size.x - 36.0), 0.0)
	outer.add_child(panel)
	var root := VBoxContainer.new()
	root.add_theme_constant_override("separation", 12)
	panel.add_child(root)
	var title := Label.new()
	title.text = "A ÚLTIMA EXPEDIÇÃO"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 26 if get_viewport().get_visible_rect().size.x < 520.0 else 30)
	title.add_theme_color_override("font_color", Color(0.96, 0.76, 0.43))
	root.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "UMA EXPEDIÇÃO. DUAS PERSPETIVAS. NENHUMA SAÍDA GARANTIDA."
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_font_size_override("font_size", 13)
	subtitle.add_theme_color_override("font_color", Color(0.43, 0.82, 0.88))
	root.add_child(subtitle)
	var nav := GridContainer.new()
	# One column on narrow phones prevents clipped labels and tiny touch targets.
	nav.columns = 1 if get_viewport().get_visible_rect().size.x < 560.0 else 2
	nav.add_theme_constant_override("h_separation", 8)
	nav.add_theme_constant_override("v_separation", 8)
	root.add_child(nav)
	for item in [{"label":"JOGAR", "page":"play"}, {"label":"LIGAÇÃO WLAN", "page":"network"}, {"label":"SOM", "page":"sound"}, {"label":"VÍDEO", "page":"video"}, {"label":"REGRAS COMPLETAS", "page":"rules"}, {"label":"SAIR", "page":"exit"}]:
		var b := Button.new()
		b.text = item.label
		b.custom_minimum_size = Vector2(0, 46)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(_show_main_menu_page.bind(item.page))
		nav.add_child(b)
	var sep := HSeparator.new()
	root.add_child(sep)
	var scroll := ScrollContainer.new()
	scroll.custom_minimum_size = Vector2(0, minf(300.0, get_viewport().get_visible_rect().size.y * 0.40))
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(scroll)
	main_menu_content = VBoxContainer.new()
	main_menu_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	main_menu_content.add_theme_constant_override("separation", 8)
	scroll.add_child(main_menu_content)
	menu_status_label = Label.new()
	menu_status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	menu_status_label.add_theme_color_override("font_color", Color(0.58, 0.91, 0.78))
	root.add_child(menu_status_label)
	_apply_gamer_ui_style(main_menu_layer)
	_show_main_menu_page("home")
	_build_intro_screen()

func _build_intro_screen() -> void:
	intro_layer = CanvasLayer.new()
	intro_layer.name = "CinematicIntro"
	intro_layer.layer = 200
	add_child(intro_layer)
	var intro_background := TextureRect.new()
	intro_background.name = "IntroCinematicBackground"
	intro_background.texture = load("res://art/intro_estacao_vespera.png") as Texture2D
	intro_background.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	intro_background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	intro_background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_background.mouse_filter = Control.MOUSE_FILTER_IGNORE
	intro_layer.add_child(intro_background)
	var backdrop := ColorRect.new()
	backdrop.color = Color(0.008, 0.018, 0.028, 0.48)
	backdrop.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	intro_layer.add_child(backdrop)
	var glow := ColorRect.new()
	glow.color = Color(0.04, 0.15, 0.18, 0.26)
	glow.anchor_left = 0.0
	glow.anchor_top = 0.35
	glow.anchor_right = 1.0
	glow.anchor_bottom = 0.72
	glow.offset_left = 0
	glow.offset_right = 0
	glow.offset_top = 0
	glow.offset_bottom = 0
	intro_layer.add_child(glow)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.offset_left = 24
	center.offset_right = -24
	intro_layer.add_child(center)
	var stack := VBoxContainer.new()
	stack.custom_minimum_size = Vector2(minf(560.0, get_viewport().get_visible_rect().size.x - 48.0), 0)
	stack.add_theme_constant_override("separation", 16)
	stack.alignment = BoxContainer.ALIGNMENT_CENTER
	center.add_child(stack)
	var overline := Label.new()
	overline.text = "REGISTO DE MISSÃO  /  ESTAÇÃO VÉSPERA"
	overline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	overline.add_theme_font_size_override("font_size", 12)
	overline.add_theme_color_override("font_color", Color(0.38, 0.77, 0.81))
	stack.add_child(overline)
	var logo := Label.new()
	logo.text = "A ÚLTIMA\nEXPEDIÇÃO"
	logo.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	logo.add_theme_font_size_override("font_size", 38 if get_viewport().get_visible_rect().size.x > 500 else 29)
	logo.add_theme_color_override("font_color", Color(0.95, 0.81, 0.57))
	stack.add_child(logo)
	var tagline := Label.new()
	tagline.text = "O QUE DESCOBRIRES LÁ DENTRO, LEVAS CONTIGO."
	tagline.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	tagline.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tagline.add_theme_font_size_override("font_size", 13)
	tagline.add_theme_color_override("font_color", Color(0.70, 0.80, 0.83))
	stack.add_child(tagline)
	var spacer := Control.new()
	spacer.custom_minimum_size.y = 28
	stack.add_child(spacer)
	intro_progress = ProgressBar.new()
	intro_progress.min_value = 0
	intro_progress.max_value = 100
	intro_progress.value = 0
	intro_progress.show_percentage = false
	intro_progress.custom_minimum_size = Vector2(0, 9)
	var track := StyleBoxFlat.new()
	track.bg_color = Color(0.08, 0.13, 0.15, 1)
	track.set_corner_radius_all(5)
	intro_progress.add_theme_stylebox_override("background", track)
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.92, 0.55, 0.24, 1)
	fill.set_corner_radius_all(5)
	intro_progress.add_theme_stylebox_override("fill", fill)
	stack.add_child(intro_progress)
	intro_percent = Label.new()
	intro_percent.text = "000%"
	intro_percent.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	intro_percent.add_theme_font_size_override("font_size", 15)
	intro_percent.add_theme_color_override("font_color", Color(0.92, 0.94, 0.91))
	stack.add_child(intro_percent)
	var foot := Label.new()
	foot.text = "A PREPARAR A EXPEDIÇÃO · 4 SEGUNDOS"
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	foot.add_theme_font_size_override("font_size", 10)
	foot.add_theme_color_override("font_color", Color(0.43, 0.58, 0.62))
	stack.add_child(foot)
	main_menu_layer.visible = false
	intro_layer.visible = true
	intro_elapsed = 0.0

func _clear_menu_content() -> void:
	for child in main_menu_content.get_children():
		child.queue_free()

func _menu_heading(text_value: String) -> void:
	var heading := Label.new()
	heading.text = text_value
	heading.add_theme_font_size_override("font_size", 19)
	heading.add_theme_color_override("font_color", Color(0.35, 0.92, 1.0))
	main_menu_content.add_child(heading)

func _menu_text(text_value: String) -> void:
	var body := Label.new()
	body.text = text_value
	body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_font_size_override("font_size", 14)
	body.add_theme_color_override("font_color", Color(0.82, 0.88, 0.91))
	main_menu_content.add_child(body)

func _show_main_menu_page(page: String) -> void:
	_clear_menu_content()
	menu_status_label.text = ""
	match page:
		"home":
			_menu_heading("MENU PRINCIPAL")
			_menu_text("REGISTO DE MISSÃO 01\nHá vários dias que a Estação Véspera deixou de responder às comunicações externas. A última transmissão foi interrompida a meio de uma frase. A VANTHIS Corporation classificou o incidente como uma falha operacional e autorizou uma equipa a avaliar a situação. As condições meteorológicas estão a piorar e a janela de operação é limitada.\n\nMISSÃO: chegar à estação, restabelecer as comunicações, investigar o que aconteceu, recolher os dados necessários e encontrar uma forma de regressar em segurança. Não existe informação confirmada sobre o estado da equipa anterior.\n\nPara cooperar, os jogadores devem estar na mesma rede WLAN e um deles tem de criar a sessão.")
			var start := Button.new()
			start.text = "ENTRAR NA EXPEDIÇÃO"
			start.custom_minimum_size = Vector2(0, 48)
			start.pressed.connect(_close_main_menu)
			main_menu_content.add_child(start)
		"play":
			_menu_heading("PRONTO PARA JOGAR?")
			_menu_text("A exploração começa quando fechares este menu. Usa o joystick para te moveres, arrasta no lado direito para olhar e aproxima-te dos mecanismos para interagir. A cooperação completa requer um segundo jogador ligado.")
			var start := Button.new()
			start.text = "COMEÇAR / VOLTAR AO JOGO"
			start.custom_minimum_size = Vector2(0, 48)
			start.pressed.connect(_close_main_menu)
			main_menu_content.add_child(start)
		"network":
			_menu_heading("LIGAÇÃO AO JOGO · WLAN")
			_menu_text("Sem internet: liga os dois telemóveis à mesma rede Wi-Fi ou ao ponto de acesso de um deles. O anfitrião cria a sessão e partilha o IP mostrado. O segundo jogador introduz esse IP abaixo e carrega em LIGAR.")
			var host := Button.new()
			host.text = "CRIAR SESSÃO (ANFITRIÃO)"
			host.custom_minimum_size = Vector2(0, 44)
			host.pressed.connect(_menu_host_session)
			main_menu_content.add_child(host)
			var ip_label := Label.new()
			ip_label.text = "IP DO ANFITRIÃO"
			main_menu_content.add_child(ip_label)
			main_menu_ip = LineEdit.new()
			main_menu_ip.placeholder_text = "Ex.: 192.168.1.77"
			main_menu_ip.text = ""
			main_menu_ip.custom_minimum_size = Vector2(0, 42)
			main_menu_content.add_child(main_menu_ip)
			var join := Button.new()
			join.text = "LIGAR À SESSÃO"
			join.custom_minimum_size = Vector2(0, 44)
			join.pressed.connect(_menu_join_session)
			main_menu_content.add_child(join)
			_menu_text("Se a ligação falhar, confirma o IP, que ambos estão na mesma WLAN e que a rede não bloqueia a comunicação entre dispositivos. A porta de jogo é UDP %d." % PORT)
		"sound":
			_menu_heading("DEFINIÇÕES DE SOM")
			_menu_text("Ajusta o volume geral e da música. As alterações aplicam-se imediatamente.")
			_add_volume_slider("Volume geral", "Master", 1.0)
			_add_volume_slider("Música ambiente", "Music", 0.55)
			_add_volume_slider("Efeitos e vozes", "SFX", 0.8)
			_menu_text("Se os buses Music ou SFX não existirem no projeto, os controlos correspondentes ficam indisponíveis; o volume geral continua disponível.")
		"video":
			_menu_heading("DEFINIÇÕES DE VÍDEO")
			_menu_text("As opções de vídeo são locais neste dispositivo. Em telemóveis, o modo de ecrã inteiro é normalmente o comportamento recomendado.")
			var fullscreen := Button.new()
			fullscreen.text = "ALTERNAR ECRÃ INTEIRO"
			fullscreen.custom_minimum_size = Vector2(0, 44)
			fullscreen.pressed.connect(_toggle_fullscreen)
			main_menu_content.add_child(fullscreen)
			var brightness_label := Label.new()
			brightness_label.text = "Brilho da interface (pré-visualização)"
			main_menu_content.add_child(brightness_label)
			var brightness := HSlider.new()
			brightness.min_value = 0.65
			brightness.max_value = 1.35
			brightness.step = 0.05
			brightness.value = 1.0
			brightness.value_changed.connect(_set_ui_brightness)
			main_menu_content.add_child(brightness)
			_menu_text("A qualidade gráfica depende também das capacidades do dispositivo e das definições de renderização do projeto.")
		"exit":
			_menu_heading("SAIR DA EXPEDIÇÃO?")
			_menu_text("Fecha a aplicação. Se estiveres numa sessão cooperativa, avisa o outro jogador antes de sair.")
			var quit_button := Button.new()
			quit_button.text = "CONFIRMAR SAÍDA"
			quit_button.custom_minimum_size = Vector2(0, 46)
			quit_button.pressed.connect(get_tree().quit)
			main_menu_content.add_child(quit_button)
		"rules":
			_menu_heading("REGRAS DA EXPEDIÇÃO — GUIA DETALHADO")
			_menu_text("1. OBJETIVO\nInvestiga a Estação Véspera, recolhe pistas e decide como responder à presença desconhecida. Sobrevive e conclui os objetivos da missão.")
			_menu_text("2. MOVIMENTO E EXPLORAÇÃO\nUsa o joystick para caminhar e arrasta na zona direita para orientar a câmara. A lanterna ajuda a observar áreas escuras. Agacha-te quando precisares de avançar com cautela.")
			_menu_text("3. INTERAÇÃO\nAproxima-te de um mecanismo e carrega em INTERAGIR. Se estiveres demasiado longe, a ação não será executada. Observa as mensagens do jogo para perceber o resultado.")
			_menu_text("4. COOPERAÇÃO\nNo modo cooperativo, cada jogador deve comunicar as pistas e cumprir a sua parte. Os relés A e B exigem colaboração. A porta só deve abrir quando o objetivo cooperativo for concluído pelo sistema.")
			_menu_text("5. WLAN\nUm jogador cria a sessão e partilha o IP local apresentado. O outro introduz esse IP e liga-se. Ambos devem estar na mesma rede local. 127.0.0.1 nunca é o IP a partilhar com outro dispositivo.")
			_menu_text("6. ENTIDADE E CALOR\nOs indicadores térmicos representam deteções simuladas do jogo, não sensores físicos. Um sinal pode indicar proximidade; não garante que a entidade esteja visível. Usa o ambiente sonoro e visual para avaliar o risco.")
			_menu_text("7. DECISÕES\nQuando surgir uma escolha, lê as pistas e discute-as com o outro jogador antes de selecionar ACUSAR ou DEFENDER. As decisões podem alterar o rumo da missão.")
			_menu_text("8. DERROTA, FALHAS E RECONEXÃO\nSe perderes a ligação, verifica a WLAN e o IP do anfitrião e tenta ligar novamente. Não assumas que uma sessão está ligada até o painel confirmar o estado. Esta versão é um protótipo: algumas regras e funcionalidades ainda podem estar em desenvolvimento.")
			_menu_text("9. JOGO RESPONSÁVEL\nJoga com som num nível confortável. Faz pausas se os efeitos de suspense te causarem desconforto.")
	_apply_gamer_ui_style(main_menu_content)

func _close_main_menu() -> void:
	if main_menu_layer:
		main_menu_layer.visible = false

func _menu_host_session() -> void:
	host_game()
	if menu_status_label and network_status:
		menu_status_label.text = network_status.text

func _menu_join_session() -> void:
	if main_menu_ip and ip_input:
		ip_input.text = main_menu_ip.text.strip_edges()
	join_game()
	if menu_status_label and network_status:
		menu_status_label.text = network_status.text

func _add_volume_slider(label_text: String, bus_name: String, default_value: float) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	var label := Label.new()
	label.text = label_text + (" (indisponível)" if bus_index < 0 else "")
	main_menu_content.add_child(label)
	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.05
	slider.value = default_value
	slider.editable = bus_index >= 0
	slider.value_changed.connect(_set_bus_volume.bind(bus_name))
	main_menu_content.add_child(slider)

func _set_bus_volume(value: float, bus_name: String) -> void:
	var bus_index := AudioServer.get_bus_index(bus_name)
	if bus_index >= 0:
		AudioServer.set_bus_volume_db(bus_index, linear_to_db(maxf(value, 0.001)))
		AudioServer.set_bus_mute(bus_index, value <= 0.001)

func _toggle_fullscreen() -> void:
	if DisplayServer.window_get_mode() == DisplayServer.WINDOW_MODE_FULLSCREEN:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)

func _set_ui_brightness(value: float) -> void:
	if main_menu_layer:
		main_menu_layer.modulate = Color(value, value, value, 1.0)

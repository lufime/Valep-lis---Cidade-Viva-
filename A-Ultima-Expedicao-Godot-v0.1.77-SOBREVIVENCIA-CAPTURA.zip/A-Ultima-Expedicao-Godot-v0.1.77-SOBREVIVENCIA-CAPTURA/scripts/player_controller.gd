extends CharacterBody3D

@export var walk_speed: float = 3.2
@export var mouse_sensitivity: float = 0.0018
@export var gravity_strength: float = 13.0
var look_pitch := 0.0
var look_enabled := true
var touch_move := Vector2.ZERO
var look_touch_id := -1
var last_look_position := Vector2.ZERO
var is_crouching := false
var standing_camera_y := 0.55
var crouching_camera_y := 0.22
var footstep_timer := 0.0
var breathing_timer := 5.0
var animation_phase := 0.0
var is_captured := false
var is_eliminated := false

@onready var pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var ray: RayCast3D = $CameraPivot/Camera3D/InteractionRay
@onready var flashlight: SpotLight3D = $CameraPivot/Camera3D/Flashlight
@onready var body_collider: CollisionShape3D = $CollisionShape3D
@onready var prompt: Label = _find_prompt()

func _ready() -> void:
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	# HUD is created by the parent immediately after adding the player.
	call_deferred("_bind_hud")

func _bind_hud() -> void:
	prompt = _find_prompt()
	if prompt == null:
		push_warning("[PLAYER] HUD/Prompt não encontrado; o jogo continua sem mensagens contextuais.")

func _find_prompt() -> Label:
	# O jogador e o HUD são filhos da cena ExpeditionRuntime; current_scene é Boot.
	var world := get_parent()
	if world:
		var hud := world.get_node_or_null("HUD")
		if hud:
			return hud.get_node_or_null("Prompt") as Label
	return null

func set_touch_move(value: Vector2) -> void:
	touch_move = value.limit_length(1.0)

func toggle_flashlight() -> void:
	flashlight.visible = not flashlight.visible
	_play_player_sfx("flashlight_click.wav", _detect_surface(), 1.0)

func toggle_crouch() -> void:
	is_crouching = not is_crouching
	_play_player_sfx("cloth_rustle.wav", _detect_surface(), randf_range(0.95, 1.05))
	walk_speed = 1.35 if is_crouching else 3.2
	pivot.position.y = crouching_camera_y if is_crouching else standing_camera_y
	var capsule := body_collider.shape as CapsuleShape3D
	if capsule:
		capsule.height = 1.1 if is_crouching else 1.75
		body_collider.position.y = -0.325 if is_crouching else 0.0
	if prompt:
		prompt.text = "AGACHADO · ruído reduzido" if is_crouching else "De pé · movimento mais rápido, mas mais ruidoso"
	var crouch_button := get_meta("crouch_button_ref", null) as Button
	if is_instance_valid(crouch_button):
		crouch_button.text = "LEVANTAR" if is_crouching else "AGACHAR"

func interact_now() -> void:
	_interact()

func _input(event: InputEvent) -> void:
	# No telemóvel, o movimento é controlado pelo joystick virtual visível.
	# A metade direita do ecrã continua livre para rodar a câmara.
	var screen_size := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x >= screen_size.x * 0.46 and not _is_touch_button_area(event.position) and look_touch_id == -1:
				look_touch_id = event.index
				last_look_position = event.position
		else:
			if event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag and event.index == look_touch_id:
		var look_delta: Vector2 = event.position - last_look_position
		_apply_look(look_delta)
		last_look_position = event.position

func _is_touch_button_area(pos: Vector2) -> bool:
	var size := get_viewport().get_visible_rect().size
	# Exclui a coluna de ações inteira da captura de gesto da câmara.
	# A área é deliberadamente um pouco maior que os botões para evitar rotação acidental.
	return pos.x > size.x - 220.0 and pos.y > size.y - 250.0

func _apply_look(delta: Vector2) -> void:
	rotate_y(-delta.x * mouse_sensitivity * 1.6)
	look_pitch = clamp(look_pitch - delta.y * mouse_sensitivity * 1.6, deg_to_rad(-82), deg_to_rad(82))
	pivot.rotation.x = look_pitch

func set_capture_state(captured: bool, eliminated: bool) -> void:
	is_captured = captured
	is_eliminated = eliminated
	if is_captured or is_eliminated:
		touch_move = Vector2.ZERO
		velocity = Vector3.ZERO

func _unhandled_input(event: InputEvent) -> void:
	if is_captured or is_eliminated:
		return
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_apply_look(event.relative)
	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
	if event.is_action_pressed("flashlight"):
		toggle_flashlight()
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_C:
		toggle_crouch()
	if event.is_action_pressed("interact"):
		_interact()

func _physics_process(delta: float) -> void:
	if is_captured or is_eliminated:
		velocity = Vector3.ZERO
		return
	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	input_vec = (input_vec + touch_move).limit_length(1.0)
	var dir := (transform.basis * Vector3(input_vec.x, 0, input_vec.y)).normalized()
	velocity.x = dir.x * walk_speed
	velocity.z = dir.z * walk_speed
	if not is_on_floor():
		velocity.y -= gravity_strength * delta
	else:
		velocity.y = 0.0
	move_and_slide()
	var horizontal_speed := Vector2(velocity.x, velocity.z).length()
	_update_procedural_animation(delta, horizontal_speed)
	if is_on_floor() and horizontal_speed > 0.35:
		footstep_timer -= delta
		if footstep_timer <= 0.0:
			var surface := _detect_surface()
			var pitch := randf_range(0.94, 1.06) if not is_crouching else randf_range(0.82, 0.94)
			_play_player_sfx("footstep.wav", surface, pitch)
			footstep_timer = (0.62 if not is_crouching else 0.88) / maxf(horizontal_speed / 3.2, 0.65)
	else:
		footstep_timer = minf(footstep_timer, 0.12)
	breathing_timer -= delta
	if is_on_floor() and horizontal_speed > 2.2 and breathing_timer <= 0.0:
		_play_player_sfx("voice_breathing.wav", _detect_surface(), randf_range(0.92, 1.08))
		breathing_timer = randf_range(7.0, 11.0)
	_update_prompt()


func _update_procedural_animation(delta: float, horizontal_speed: float) -> void:
	animation_phase += delta * (5.8 if horizontal_speed > 0.25 else 2.0)
	var moving := is_on_floor() and horizontal_speed > 0.25
	for child in get_children():
		if not child is Node3D:
			continue
		var n := child.name
		if n.begins_with("Leg_"):
			var side := -1.0 if "-1" in n else 1.0
			child.rotation.x = sin(animation_phase + side * PI) * (0.38 if moving else 0.025)
			child.position.y = -0.42 + absf(sin(animation_phase + side * PI)) * (0.035 if moving else 0.0)
		elif n.begins_with("Arm_"):
			var side_arm := -1.0 if "-1" in n else 1.0
			child.rotation.x = sin(animation_phase + side_arm * PI) * (0.22 if moving else 0.035)
		elif n == "InsulatedPolarParka":
			child.rotation.x = sin(animation_phase * (1.35 if moving else 0.6)) * 0.018

func _update_prompt() -> void:
	if not prompt:
		return
	ray.force_raycast_update()
	if ray.is_colliding():
		var target := ray.get_collider()
		if target and target.has_method("interact"):
			if target.name.begins_with("CoopSwitch"):
				prompt.text = "RELÉ — toca em INTERAGIR"
			elif target.name.begins_with("ExperimentClue"):
				prompt.text = "PROVA DA EXPERIÊNCIA — toca em INTERAGIR para recolher"
			elif target.name == "SecretExperimentDoor":
				prompt.text = "ACESSO VANTHIS — INTERAGIR para verificar as provas combinadas"
			elif target.name == "EvidenceSynthesisConsole":
				prompt.text = "CONSOLA DE SÍNTESE — INTERAGIR para combinar as 10 provas"
			elif target.name == "MissionExtractionTerminal":
				prompt.text = "TERMINAL DE EXTRAÇÃO — INTERAGIR para solicitar o resgate"
			else:
				prompt.text = "INTERAGIR — usar equipamento/porta"
			return
	# As provas podem ser apanhadas por proximidade: o mobiliário ou a precisão
	# do toque no ecrã não deve bloquear a recolha.
	var nearby_clue := _find_nearby_clue(4.8)
	if nearby_clue:
		prompt.text = "PROVA AO ALCANCE — toca em INTERAGIR para recolher"
		return
	prompt.text = "Telemóvel: arrasta para mover/olhar · INTERAGIR · LANTERNA · AGACHAR"

func _find_nearby_clue(max_distance: float = 4.8) -> Node3D:
	var best: Node3D = null
	var best_distance := max_distance
	for item in get_tree().get_nodes_in_group("collectible_evidence"):
		if not is_instance_valid(item) or not item is Node3D:
			continue
		var clue := item as Node3D
		var distance := global_position.distance_to(clue.global_position)
		if distance <= best_distance and clue.has_method("interact"):
			best = clue
			best_distance = distance
	return best

func _interact() -> void:
	ray.force_raycast_update()
	if ray.is_colliding():
		var target := ray.get_collider()
		if target and target.has_method("interact"):
			target.interact(self)
			return
	# Fallback de proximidade para recolher provas em ecrãs táteis e quando
	# mesas/armários ficam entre o raio da câmara e o objeto pequeno.
	var nearby_clue := _find_nearby_clue(4.8)
	if nearby_clue:
		nearby_clue.interact(self)

func _detect_surface() -> String:
	# Deteta o material pelo nome do collider; o cenário mantém-se funcional sem nomes especiais.
	var from := global_position + Vector3.UP * 0.15
	var to := global_position + Vector3.DOWN * 1.8
	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = [get_rid()]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if hit.is_empty():
		return "snow"
	var collider: Object = hit.get("collider")
	var label := ""
	if collider is Node:
		label = (collider as Node).name.to_lower()
		if (collider as Node).get_parent():
			label += " " + (collider as Node).get_parent().name.to_lower()
	if "metal" in label or "grate" in label or "stairs" in label:
		return "metal"
	if "ice" in label or "gelo" in label:
		return "ice"
	if "stone" in label or "concrete" in label or "floor" in label or "stone" in label or "pavement" in label:
		return "stone"
	if "room" in label or "interior" in label or "corridor" in label:
		return "interior"
	return "snow"

func _play_player_sfx(file_name: String, surface: String = "snow", pitch: float = 1.0) -> void:
	var world := get_parent()
	if world and world.has_method("_play_player_sound"):
		world.call("_play_player_sound", file_name, global_position, surface, pitch)
	else:
		_play_world_sfx(file_name)

func _play_world_sfx(file_name: String) -> void:
	var world := get_parent()
	if world and world.has_method("_play_sfx"):
		world.call("_play_sfx", file_name)

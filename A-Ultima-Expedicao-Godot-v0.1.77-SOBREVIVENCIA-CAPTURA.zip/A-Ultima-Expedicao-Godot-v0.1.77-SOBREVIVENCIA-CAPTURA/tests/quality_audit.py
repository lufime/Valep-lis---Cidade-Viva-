#!/usr/bin/env python3
"""Static project audit for A Última Expedição. Does not replace Godot runtime tests."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
checks: list[str] = []

def check(condition: bool, message: str) -> None:
    if condition:
        checks.append(message)
    else:
        errors.append(message)

# Essential files
for rel in [
    "project.godot", "scenes/Boot.tscn", "scenes/Expedition.tscn",
    "scripts/boot.gd", "scripts/expedition.gd", "scripts/player_controller.gd",
    "scripts/experiment_clue.gd", "scripts/evidence_synthesis_console.gd",
    "scripts/secret_experiment_door.gd", "export_presets.cfg",
]:
    check((ROOT / rel).is_file(), f"ficheiro essencial: {rel}")

# Validate every literal res:// reference found in Godot source and scene files.
refs: set[str] = set()
for path in list(ROOT.rglob("*.gd")) + list(ROOT.rglob("*.tscn")) + list(ROOT.rglob("*.tres")) + [ROOT / "project.godot"]:
    if not path.is_file():
        continue
    try:
        source = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    refs.update(re.findall(r'res://[^"\s)]+', source))
for ref in sorted(refs):
    # Some audio paths are assembled dynamically as res://audio/ + filename.
    if ref.endswith("/"):
        continue
    target = ROOT / ref.removeprefix("res://")
    check(target.exists(), f"referência de recurso: {ref}")

expedition = (ROOT / "scripts/expedition.gd").read_text(encoding="utf-8")
check('const SECRET_COMBINATION := "7314"' in expedition, "combinação lógica 7314")
check("for clue_id in range(1, 11)" in expedition, "validação das dez provas")
check("func _server_validate_secret_combination" in expedition and 'entered_code != SECRET_COMBINATION' in expedition, "validação do código no servidor")
check('func _update_entity_ai' in expedition and 'if not multiplayer.is_server() or entity_presence == null:' in expedition, "IA da criatura autoritativa")
check('func _assign_hidden_roles()' in expedition and 'func receive_secret_role' in expedition, "atribuição e entrega privada dos papéis")
check('func client_sync_secret_progress' in expedition and 'request_initial_session_state' in expedition, "sincronização do progresso para entrada tardia")
check('func _reveal_secret_access()' in expedition and 'if not multiplayer.is_server():' in expedition, "consola revelada apenas pela autoridade")
check('func _server_try_open_secret_door()' in expedition and 'if not evidence_synthesis_complete:' in expedition, "porta protegida por síntese")

# V0.1.71: fog-of-war and end-to-end logical audit presence.
mini_map = (ROOT / "scripts/mini_map.gd").read_text(encoding="utf-8")
check("FOG_COLS" in mini_map and "FOG_ROWS" in mini_map, "grelha de exploração do minimapa")
check("_update_exploration()" in mini_map and "explored_cells" in mini_map, "descoberta progressiva do mapa")
check("_draw_fog_of_war(r)" in mini_map and "Color(0.002, 0.004, 0.006, 0.995)" in mini_map, "áreas não exploradas cobertas a preto")
check((ROOT / "scripts/RELATORIO-AUDITORIA-LOGICA-V0.1.71.md").is_file(), "relatório de auditoria lógica ponta a ponta")

if errors:
    print(f"FAIL: {len(errors)} falha(s), {len(checks)} verificações aprovadas")
    for item in errors:
        print("[FAIL] " + item)
    for item in checks:
        print("[PASS] " + item)
    sys.exit(1)
print(f"PASS: {len(checks)} verificações estáticas")
for item in checks:
    print("[PASS] " + item)
print("NOTA: não valida sintaxe GDScript em runtime, gameplay, rede real ou exportação APK.")

# Dynamic audio paths: all sounds referenced by string-based audio loaders must exist.
for sound in ["ambient_tension.wav", "polar_wind_loop.wav", "station_hum_loop.wav", "metal_creak.wav", "ice_stress_crack.wav", "heartbeat_low.wav", "door_open.wav", "radio_static.wav"]:
    check((ROOT / "audio" / sound).is_file(), f"ficheiro de áudio: {sound}")

extends SceneTree

var failures: Array[String] = []
var passes: Array[String] = []
var _frames_waited: int = 0
var _tests_started: bool = false
var _test_main: Node = null

func ok(text: String) -> void:
    passes.append(text)

func fail(text: String) -> void:
    failures.append(text)

func has_node_path(root_node: Node, path: String) -> bool:
    return root_node.get_node_or_null(path) != null

func text_of(root_node: Node, path: String) -> String:
    var n: Node = root_node.get_node_or_null(path)
    if n == null:
        return ""
    return str(n.get("text"))

func visible_of(root_node: Node, path: String) -> bool:
    var n: Node = root_node.get_node_or_null(path)
    if n == null:
        return false
    return bool(n.get("visible"))

func check_action_buttons(main: Node, expected: Array[String]) -> void:
    var paths: Array[String] = [
        "UI/Actions/Move",
        "UI/Actions/Work",
        "UI/Actions/Shop",
        "UI/Actions/Hospital"
    ]
    var actual: Array[String] = []

    for p in paths:
        var n: Node = main.get_node_or_null(p)
        if n == null:
            fail("Botão em falta: " + p)
            continue

        actual.append(str(n.get("text")))

        var control: Control = n as Control
        if control != null:
            var rect: Rect2 = control.get_global_rect()
            var viewport: Rect2 = main.get_viewport().get_visible_rect()
            if not viewport.encloses(rect):
                fail("Botão fora do ecrã: " + p)

    if actual == expected:
        ok("Ações corretas: " + str(actual))
    else:
        fail("Ações incorretas. Esperado " + str(expected) + " / obtido " + str(actual))

func check_no_overlap(main: Node) -> void:
    var paths: Array[String] = [
        "UI/Actions/Move",
        "UI/Actions/Work",
        "UI/Actions/Shop",
        "UI/Actions/Hospital"
    ]

    var overlap_found: bool = false

    for i in range(paths.size()):
        var a_node: Node = main.get_node_or_null(paths[i])
        if a_node == null:
            continue

        var a: Control = a_node as Control
        if a == null:
            continue

        var ra: Rect2 = a.get_global_rect()

        for j in range(i + 1, paths.size()):
            var b_node: Node = main.get_node_or_null(paths[j])
            if b_node == null:
                continue

            var b: Control = b_node as Control
            if b == null:
                continue

            var rb: Rect2 = b.get_global_rect()

            if ra.intersects(rb):
                overlap_found = true
                fail("Sobreposição entre " + paths[i] + " e " + paths[j])

    if not overlap_found:
        ok("Ações sem sobreposição entre si")

func run_entity_test(main: Node) -> void:
    main.set("v030_control_mode", "entidade")
    main.set("v030_selected_entity", "Entidade de Teste")
    main.call("_v030_set_mode", "entidade")
    check_action_buttons(main, ["GESTÃO", "PESSOAS", "RECURSOS", "OPERAÇÕES"])

    var stats: String = text_of(main, "UI/Stats")
    var subtitle: String = text_of(main, "UI/Header/Sub")
    var status: String = text_of(main, "UI/Status")
    var current: String = text_of(main, "UI/Map/CurrentLocation")

    for forbidden in ["Energia", "Fome", "Saúde", "CASA"]:
        if stats.contains(forbidden) or subtitle.contains(forbidden) or status.contains(forbidden):
            fail("ENTIDADE contém elemento pessoal proibido: " + forbidden)
        else:
            ok("ENTIDADE sem elemento pessoal: " + forbidden)

    if not subtitle.contains("GERIR"):
        fail("ENTIDADE sem cabeçalho GERIR")
    else:
        ok("ENTIDADE com cabeçalho GERIR")

    if current != "SEDE / ÁREA DE GESTÃO":
        fail("ENTIDADE sem indicação SEDE / ÁREA DE GESTÃO")
    else:
        ok("ENTIDADE com área de gestão")

    for personal in ["Casa", "Trabalho", "Comercio", "Hospital", "You", "Player"]:
        var path: String = "UI/Map/MapBody/" + personal
        var n: Node = main.get_node_or_null(path)

        if n != null and bool(n.get("visible")):
            fail("ENTIDADE deixou elemento pessoal visível: " + personal)
        else:
            ok("ENTIDADE ocultou: " + personal)

    check_no_overlap(main)

func run_character_test(main: Node) -> void:
    main.set("v030_control_mode", "personagem")
    main.set("v030_selected_character", "Personagem de Teste")
    main.set("v030_selected_profession", "Profissão de Teste")
    main.set("v030_selected_cargo", "Cargo de Teste")
    main.set("current_place", "Casa")
    main.set("health", 80)
    main.call("_v030_set_mode", "personagem")

    var stats: String = text_of(main, "UI/Stats")

    if stats.contains("Energia") and stats.contains("Fome") and stats.contains("Saúde"):
        ok("PERSONAGEM mostra estado pessoal")
    else:
        fail("PERSONAGEM não mostra corretamente estado pessoal")

    var subtitle: String = text_of(main, "UI/Header/Sub")

    if subtitle.contains("Personagem de Teste"):
        ok("PERSONAGEM mostra personagem selecionado")
    else:
        fail("PERSONAGEM não mostra personagem selecionado")

    var work: String = text_of(main, "UI/Actions/Work")
    var shop: String = text_of(main, "UI/Actions/Shop")
    var hospital: String = text_of(main, "UI/Actions/Hospital")

    if work in ["TRABALHAR", "FECHADO"]:
        ok("PERSONAGEM ação TRABALHAR válida")
    else:
        fail("PERSONAGEM ação TRABALHAR inválida: " + work)

    if shop == "PREÇOS POR DEFINIR":
        ok("PERSONAGEM ação COMPRAR válida")
    else:
        fail("PERSONAGEM ação COMPRAR inválida: " + shop)

    if hospital == "CUSTOS POR DEFINIR":
        ok("PERSONAGEM ação de saúde válida")
    else:
        fail("PERSONAGEM ação de saúde inválida: " + hospital)

    check_no_overlap(main)

func check_map_viewport(main: Node) -> void:
    var viewport := main.get_node_or_null("UI/Map/MapBody/Map3D/SubViewport") as SubViewport
    var container := main.get_node_or_null("UI/Map/MapBody/Map3D") as SubViewportContainer
    if viewport == null:
        fail("MAP_RENDER_FAIL: SubViewport do mapa não existe")
        return
    if container == null:
        fail("MAP_RENDER_FAIL: SubViewportContainer do mapa não existe")
        return
    if viewport.render_target_update_mode != SubViewport.UPDATE_ALWAYS:
        fail("MAP_RENDER_FAIL: modo de atualização incorreto (atual=%d, esperado=%d)" % [
            viewport.render_target_update_mode, SubViewport.UPDATE_ALWAYS
        ])
    else:
        ok("Mapa 3D: SubViewport configurado para UPDATE_ALWAYS")
    var city := viewport.get_node_or_null("ValepolisCity3D")
    if city == null:
        fail("MAP_RENDER_FAIL: cidade 3D não está instanciada no SubViewport")
        return
    var cameras: Array[Node] = city.find_children("*", "Camera3D", true, false)
    var has_current_camera := false
    for camera_node in cameras:
        var camera := camera_node as Camera3D
        if camera != null and camera.current:
            has_current_camera = true
            break
    if has_current_camera:
        ok("Mapa 3D: cidade instanciada e câmara ativa")
    else:
        fail("MAP_RENDER_FAIL: a cidade 3D não tem câmara ativa")
    if not container.visible:
        fail("MAP_RENDER_FAIL: container do mapa está invisível")
    else:
        ok("Mapa 3D: container visível")
    # Em modo headless, tamanho/renderização de píxeis pode depender do backend.
    # Não se declara renderização visual aprovada apenas com este teste estrutural.
    if viewport.size.x > 0 and viewport.size.y > 0:
        ok("Mapa 3D: dimensões do SubViewport válidas")
    else:
        fail("MAP_RENDER_FAIL: SubViewport sem dimensões válidas")

func _initialize() -> void:
    var scene: PackedScene = load("res://Main.tscn") as PackedScene

    if scene == null:
        fail("Não foi possível carregar Main.tscn")
        return

    _test_main = scene.instantiate()

    if _test_main == null:
        fail("Main.tscn não instanciou")
        return

    get_root().add_child(_test_main)
    ok("Main.tscn instanciou em modo headless")

func _process(_delta: float) -> bool:
    if _tests_started:
        return false

    # O arranque da UI configura o mapa através de chamadas diferidas.
    # Esperar vários frames evita medir o estado antes da configuração de arranque,
    # sem substituir nem forçar a configuração que o jogo deve fazer sozinho.
    _frames_waited += 1
    if _frames_waited < 6:
        return false

    _tests_started = true
    if _test_main == null or not is_instance_valid(_test_main):
        fail("Main.tscn não está disponível para o teste funcional")
    else:
        check_map_viewport(_test_main)
        run_character_test(_test_main)
        run_entity_test(_test_main)
        # A amostra detalhada de 200 habitantes é inicializada pelo seu sistema
        # próprio; não se exige que esteja materializada antes da inicialização.
        var population_agents_value: Variant = _test_main.get("v030_population_agents")
        if not (population_agents_value is Dictionary):
            fail("Estado da amostra populacional não é um Dictionary")
        else:
            var population_agents: Dictionary = population_agents_value
            if population_agents.is_empty() and _test_main.has_method("v030_initialize_population_agents"):
                _test_main.call("v030_initialize_population_agents")
                population_agents_value = _test_main.get("v030_population_agents")
                if population_agents_value is Dictionary:
                    population_agents = population_agents_value
            if population_agents.size() != 200:
                fail("A amostra detalhada não contém 200 habitantes após inicialização explícita")
            else:
                var population_ids: Dictionary = {}
                var population_names_valid := true
                for agent_name in population_agents.keys():
                    var agent_value: Variant = population_agents[agent_name]
                    if not (agent_value is Dictionary):
                        population_names_valid = false
                        break
                    var agent: Dictionary = agent_value
                    var agent_id: String = str(agent.get("id", ""))
                    if agent_id.is_empty() or population_ids.has(agent_id):
                        population_names_valid = false
                        break
                    population_ids[agent_id] = true
                    if agent.get("income", null) != null or str(agent.get("employment", "")) != "por_definir":
                        population_names_valid = false
                        break
                if population_names_valid:
                    ok("A amostra detalhada de 200 habitantes inicializa corretamente; emprego e rendimentos continuam por definir")
                else:
                    fail("A amostra populacional contém IDs duplicados ou dados económicos não aprovados")
        var registry: Node = get_root().get_node_or_null("ValepolisInstallations")
        if registry == null:
            fail("Autoload ValepolisInstallations não encontrado")
        else:
            var summary: Dictionary = registry.call("get_registry_summary")
            var validation: Dictionary = registry.call("validate_registry")
            var spawnable: Array = registry.call("get_map_spawnable_installations")
            var all_installations: Array = registry.call("get_all_installations")
            if not all_installations.is_empty():
                var activation_probe: Dictionary = registry.call("activate_installation_on_map", str(all_installations[0].get("installation_id", "")), "PREFLIGHT-MUST-NOT-SPAWN", [0.0, 0.0, 0.0], false)
                if not bool(activation_probe.get("ok", false)):
                    ok("Instalação proposta rejeita criação sem aprovação explícita")
                else:
                    fail("Instalação proposta foi ativada sem aprovação")
            if bool(summary.get("loaded", false)) and int(summary.get("physical_installations", 0)) == 275:
                ok("Registo de 275 instalações carregado")
            else:
                fail("Registo de instalações não carregou corretamente")
            if bool(validation.get("ok", false)):
                ok("Validação runtime do registo sem erros")
            else:
                fail("Validação runtime do registo encontrou erros")
            if spawnable.is_empty():
                ok("Propostas não aprovadas não são criadas no mapa 3D")
            else:
                fail("Existem instalações no mapa sem aprovação/coordenação explícita")
        # SectionPanel é criado dinamicamente quando o jogador abre uma página.
        # Exercita a navegação real antes de validar o painel; não exigir que exista
        # antes da primeira abertura.
        if _test_main.has_method("_v030_open_section"):
            _test_main.call("_v030_open_section", "Personagem")
            var section_panel: Control = _test_main.get_node_or_null("UI/ReferenceUI/SectionPanel") as Control
            if section_panel != null and section_panel.get_node_or_null("CloseButton") == null:
                ok("Navegação abre painel de secção sem botão modal de fechar")
            elif section_panel == null:
                fail("Navegação não criou o painel de secção")
            else:
                fail("Painel de secção contém botão modal de fechar")
        else:
            fail("Função de navegação _v030_open_section não encontrada")

    # Round-trip real da persistência dos sistemas integrados. O teste usa um ID
    # sentinela, restaura o estado original e não cria equipas/viaturas de exemplo.
    if _test_main != null and _test_main.has_method("v030_save_state") and _test_main.has_method("v030_load_integrated_state"):
        var original_missions_value: Variant = _test_main.get("v030_missions")
        if original_missions_value is Array:
            var original_missions: Array = original_missions_value.duplicate(true)
            var probe_id := "PREFLIGHT-PERSISTENCE-ROUNDTRIP"
            var probe_missions: Array = original_missions.duplicate(true)
            probe_missions.append({"id": probe_id, "status": "aberta", "assigned_team": "", "assigned_vehicle": ""})
            _test_main.set("v030_missions", probe_missions)
            _test_main.call("v030_save_state")
            _test_main.set("v030_missions", [])
            _test_main.call("v030_load_integrated_state")
            var restored_missions_value: Variant = _test_main.get("v030_missions")
            var persistence_ok := false
            if restored_missions_value is Array:
                for restored_mission in restored_missions_value:
                    if restored_mission is Dictionary and str(restored_mission.get("id", "")) == probe_id:
                        persistence_ok = str(restored_mission.get("status", "")) == "aberta"
                        break
            _test_main.set("v030_missions", original_missions)
            _test_main.call("v030_save_state")
            if persistence_ok:
                ok("Persistência integrada: missões sobrevivem a guardar/carregar")
            else:
                fail("Persistência integrada não recuperou a missão de teste")
        else:
            fail("Persistência integrada: lista de missões inválida")
    else:
        fail("Persistência integrada: funções de guardar/carregar não encontradas")

    print("=== FUNCTIONAL/UI PREFLIGHT ===")
    for p in passes:
        print("PASS | " + p)
    for f in failures:
        print("FAIL | " + f)

    if failures.is_empty():
        print("RESULTADO=FUNCTIONAL_UI_PASS")
        quit(0)
    else:
        print("RESULTADO=FUNCTIONAL_UI_FAIL")
        quit(1)
    return false

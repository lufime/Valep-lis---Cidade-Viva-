# Valepólis V0.3.0 — ruas e placas de porta no mapa 2D

## Aplicado
- Geometrias esquemáticas visíveis de arruamentos por bairro e ligações entre bairros próximos, usando `Line2D`.
- Placas numeradas de amostra (uma por arruamento) usando números de porta do cadastro `data/enderecamento_valepolis.json`.
- Os nomes, IDs, números de porta e códigos postais continuam a vir do cadastro existente; não foram inventados nomes oficiais.
- O cadastro integral de 6.250 moradas é preservado; não são desenhadas 6.250 etiquetas ao mesmo tempo para manter o mapa legível.

## Limites
Esta implementação é geometria visual 2D no mapa de interface, não ruas ou placas físicas num mundo 3D. Não foi possível executar a cena/compilação porque o Godot não está instalado neste ambiente. O PRE-FLIGHT deve validar a alteração antes de considerar o build aprovado.

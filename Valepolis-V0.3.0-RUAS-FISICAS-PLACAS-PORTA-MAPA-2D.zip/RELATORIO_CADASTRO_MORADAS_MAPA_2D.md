# Integração do cadastro de moradas no mapa 2D — Valepólis V0.3.0

## Alteração
- O mapa lê `data/enderecamento_valepolis.json` em tempo de execução.
- Os nomes das ruas apresentados junto dos bairros são gerados a partir dos dados do cadastro, em vez de uma lista manual de seis nomes.
- Mantém-se o cadastro existente: 25 bairros, 125 arruamentos e 6.250 moradas de referência.
- Os registos de morada incluem número de porta, código postal e morada completa; estes dados permanecem no JSON para utilização por pesquisas, residências e empresas.

## Limites e validação
- Os códigos postais são fictícios internos do jogo e não foram verificados como códigos postais reais.
- A alteração não cria geometria física de cada rua nem placas de número de porta no mapa.
- A apresentação de 125 nomes sobre o mapa pode ficar densa em alguns níveis de zoom; o mapa deve ser testado no Godot para ajustar escala/visibilidade.
- Godot não está instalado neste ambiente; não foi possível executar importação, compilação ou teste visual. Não declarar PRE-FLIGHT/APK aprovado com base nesta alteração isolada.

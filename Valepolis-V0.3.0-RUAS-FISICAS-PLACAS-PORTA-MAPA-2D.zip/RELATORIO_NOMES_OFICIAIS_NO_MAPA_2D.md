# Valepólis V0.3.0 — nomes oficiais recuperados no mapa 2D

## Alteração
O overlay do mapa desenha agora os nomes recuperados explicitamente no Documento Mestre:
- Nexora: Avenida da Inovação; Rua dos Navegantes; Praça da União.
- Altavira: Avenida das Colinas; Rua do Miradouro; Travessa da Encosta.

A implementação adiciona rótulos ao mapa existente; não cria geometria viária física nem afirma que estes nomes são a lista completa da cidade.

## Integridade dos dados
Não foram atribuídos nomes aos outros 23 bairros. O documento territorial recuperado estabelece uma regra de nomenclatura escalável, mas não fornece os nomes aprovados completos para todos os bairros. A Ponte da União (principal) e a Ponte do Horizonte (secundária) continuam a ser nomes oficiais, mas não foram desenhadas como novas geometrias nesta alteração.

## Validação
Foi feita uma alteração estática em `main.gd`. Não foi possível executar Godot neste ambiente; importação, renderização e APK permanecem por validar.

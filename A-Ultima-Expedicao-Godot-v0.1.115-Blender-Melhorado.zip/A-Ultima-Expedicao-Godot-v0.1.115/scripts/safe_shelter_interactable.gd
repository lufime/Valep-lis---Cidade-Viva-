extends StaticBody3D

## Interações dedicadas ao abrigo: porta blindada, ponto fraco exterior e comando interior.
@export_enum("door", "panel", "repair") var interaction_mode: String = "door"

func interact(_actor: Node) -> void:
	var world := get_parent()
	# Os elementos estão sob PermanentSafeShelter; subir mais um nível chega ao nó de jogo.
	if world and world.name == "PermanentSafeShelter":
		world = world.get_parent()
	if world == null:
		return
	match interaction_mode:
		"door":
			if world.has_method("interact_safe_shelter_door"):
				world.interact_safe_shelter_door()
		"panel":
			if world.has_method("interact_shelter_weakpoint"):
				world.interact_shelter_weakpoint()
		"repair":
			if world.has_method("repair_shelter_lock"):
				world.repair_shelter_lock()

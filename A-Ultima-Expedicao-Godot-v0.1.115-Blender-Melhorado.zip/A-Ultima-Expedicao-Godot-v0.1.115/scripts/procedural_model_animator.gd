extends Node3D

## Animação procedural leve para modelos criados por primitivas; sem assets externos.
@export var creature_mode := false
@export var idle_breathing := true
var phase := 0.0
var base_transforms: Dictionary = {}

func _ready() -> void:
	for child in get_children():
		if child is Node3D:
			base_transforms[child.get_instance_id()] = {"node": child, "position": child.position, "rotation": child.rotation}

func _process(delta: float) -> void:
	phase += delta
	var speed := 0.0
	var state := "PATROL"
	if creature_mode:
		var presence := get_parent()
		var room := presence.get_parent() if presence else null
		var world := room.get_parent() if room else null
		if world and world.get("entity_ai_state") != null:
			state = str(world.get("entity_ai_state"))
			if world.has_node("Player"):
				var actor := world.get_node("Player") as CharacterBody3D
				if actor:
					speed = Vector2(actor.velocity.x, actor.velocity.z).length()
	else:
		var actor := get_parent()
		if actor is CharacterBody3D:
			speed = Vector2(actor.velocity.x, actor.velocity.z).length()
		else:
			speed = 0.4 # Silhueta do traidor respira e desloca-se discretamente.
	var moving := speed > 0.25
	var gait := phase * (8.5 if creature_mode and state == "HUNT" else 5.8)
	for data in base_transforms.values():
		var node := data["node"] as Node3D
		if not is_instance_valid(node):
			continue
		var original_pos: Vector3 = data["position"]
		var original_rot: Vector3 = data["rotation"]
		node.position = original_pos
		node.rotation = original_rot
		var n := node.name
		if creature_mode:
			if n.begins_with("LongArm_") or n.begins_with("ForearmPlate_"):
				var side := -1.0 if "-1" in n else 1.0
				node.rotation.x += sin(gait + side * 0.8) * (0.38 if state == "HUNT" else 0.19)
				node.rotation.z += sin(gait * 0.5 + side) * 0.12
			elif n.begins_with("ReverseLeg_") or n.begins_with("ShinSpur_"):
				var side_leg := -1.0 if "-1" in n else 1.0
				node.position.z += sin(gait + side_leg * PI) * (0.12 if moving else 0.025)
				node.rotation.x += sin(gait + side_leg * PI) * (0.3 if moving else 0.06)
			elif n == "NarrowTorso":
				node.rotation.x += sin(phase * (7.0 if state == "HUNT" else 2.8)) * (0.055 if state == "HUNT" else 0.025)
				node.position.y += sin(phase * (9.0 if state == "HUNT" else 3.0)) * (0.035 if state == "HUNT" else 0.012)
			elif n == "WedgeSkull":
				node.rotation.y += sin(phase * 1.4) * 0.12
			elif n.begins_with("BackSpine_") or n == "TrailingTendril":
				node.rotation.x += sin(phase * 3.2) * 0.10
		else:
			if n.begins_with("Leg_"):
				var side_h := -1.0 if "-1" in n else 1.0
				node.rotation.x += sin(gait + side_h * PI) * (0.38 if moving else 0.025)
				node.position.y += absf(sin(gait + side_h * PI)) * (0.035 if moving else 0.0)
			elif n.begins_with("Arm_"):
				var side_a := -1.0 if "-1" in n else 1.0
				node.rotation.x += sin(gait + side_a * PI) * (0.22 if moving else 0.035)
			elif n == "InsulatedPolarParka":
				node.rotation.x += sin(phase * (8.0 if moving else 2.2)) * (0.025 if moving else 0.012)

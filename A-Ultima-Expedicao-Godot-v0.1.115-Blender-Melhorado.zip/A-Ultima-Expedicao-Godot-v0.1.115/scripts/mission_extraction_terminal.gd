extends StaticBody3D

func interact(player: Node = null) -> void:
	var world := get_parent()
	while world and not world.has_method("interact_mission_extraction"):
		world = world.get_parent()
	if world:
		world.interact_mission_extraction(player)

extends StaticBody3D

var clue_id: int = 1

func interact(player: Node = null) -> void:
	var world := get_parent()
	while world and not world.has_method("request_experiment_clue"):
		world = world.get_parent()
	if world:
		world.request_experiment_clue(clue_id, player)

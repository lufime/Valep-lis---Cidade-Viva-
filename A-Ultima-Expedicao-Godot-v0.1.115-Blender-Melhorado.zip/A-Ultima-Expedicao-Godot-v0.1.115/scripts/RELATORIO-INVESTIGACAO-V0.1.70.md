# V0.1.70 — Investigação com dificuldade justa

## Alterações aplicadas
- Removidas as etiquetas flutuantes `REGISTO 01..10` e as luzes emissivas das provas.
- Reduzido o contraste/saturação de materiais de prova para os integrar no cenário.
- Distribuídas as provas por superfícies e recantos junto de mobiliário, fora do eixo central.
- Substituídas indicações diretas de zona por pistas narrativas que exigem cruzar registos, horários e equipamento.
- Mantida a interação por proximidade e o registo/sincronização já existentes.

## Limites da validação
- Não foi possível executar Godot 4.5 neste ambiente.
- As posições e colisões devem ser verificadas em jogo, incluindo a acessibilidade de cada objeto e a consistência das pistas com a planta real.
- Não declarar a recolha, multiplayer ou desempenho como aprovados sem testes reais.

extends StaticBody3D

@export var switch_id: String = "A"

func interact(_actor: Node) -> void:
	var expedition := get_parent()
	if expedition and expedition.has_method("request_switch"):
		expedition.request_switch(switch_id)

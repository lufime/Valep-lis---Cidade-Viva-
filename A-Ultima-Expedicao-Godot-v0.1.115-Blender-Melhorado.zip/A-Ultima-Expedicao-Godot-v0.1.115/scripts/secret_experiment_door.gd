extends StaticBody3D

func interact(player: Node = null) -> void:
	var world := get_parent()
	while world and not world.has_method("interact_secret_experiment_door"):
		world = world.get_parent()
	if world:
		world.interact_secret_experiment_door(player)

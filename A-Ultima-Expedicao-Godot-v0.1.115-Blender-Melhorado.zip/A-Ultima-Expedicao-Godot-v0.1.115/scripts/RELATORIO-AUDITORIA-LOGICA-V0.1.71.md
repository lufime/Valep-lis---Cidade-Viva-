# A Última Expedição — Auditoria lógica V0.1.71

## Âmbito e limite
Auditoria estática do código do projeto extraído de V0.1.70. Não é um teste de execução: Godot 4.5 não está disponível neste ambiente. As conclusões abaixo distinguem comportamento confirmado pelo código de testes ainda necessários.

## Fluxo lógico encontrado
1. **Arranque:** a cena Boot abre a expedição; existe introdução com duração configurada de 4 segundos antes do menu.
2. **Preparação:** o jogador entra na Estação Véspera e recebe a missão pública. O papel secreto é atribuído separadamente; a mensagem pública não deve revelar o traidor.
3. **Exploração inicial:** o jogador percorre salas e exterior, encontra relés, equipamentos e provas. A criatura existe separadamente e é controlada pela IA.
4. **Relés A e B:** cada ativação é validada no servidor por proximidade (limite de 5 unidades). Em solo, a mesma pessoa pode ativar ambos; em co-op online, os relés têm de pertencer a participantes diferentes.
5. **Investigação:** há dez provas identificadas por ID. Cada recolha é validada contra IDs repetidos e sincronizada pelo servidor na sessão multijogador. As mensagens dão indícios indiretos.
6. **Revelação:** depois das dez provas, o código revela a consola/área secreta segundo as funções existentes.
7. **Dedução:** quatro documentos fornecem os algarismos 7, 3, 1 e 4; a combinação esperada é `7314`.
8. **Acesso secreto:** a consola valida a combinação no servidor e o acesso à câmara depende das provas e da lógica de abertura existente.
9. **Final da missão:** a auditoria não encontrou um estado explícito e completo de vitória/fim de campanha nem um objetivo final inequívoco de extração/transmissão de provas no fluxo central. Este é um bloqueio de desenho a resolver antes de declarar a missão completa.

## Achados de lógica
- **Crítico — falta um final formal:** não foi encontrada uma transição explícita para “missão concluída”, resumo final ou condição de extração. A abertura da área secreta parece ser o fim funcional mais próximo, mas não prova que a missão tenha um encerramento completo.
- **Alto — objetivos apresentados de forma incompleta:** o painel de objetivos lista os relés, provas e síntese, mas não comunica uma cadeia completa até à conclusão nem separa claramente objetivos principais, secundários e condicionais.
- **Alto — descrição ambígua:** no modo individual, o texto “restabelecer a energia da câmara” é marcado através de `coop_solved`; no código, esse estado é ativado pelos dois relés. O texto pode sugerir uma tarefa de energia distinta da ação que realmente conclui.
- **Médio — exploração do mapa:** o mapa anterior mostrava a geometria completa desde o início, o que anulava parte da descoberta espacial.
- **Médio — persistência:** o progresso de exploração do mapa é apenas da sessão atual; não é guardado entre execuções. Isto é deliberado nesta implementação, mas deve ser uma decisão explícita.
- **Pendente — gameplay real:** não se confirmou em runtime a recolha de cada prova, a acessibilidade das dez posições, a coerência espacial de cada pista, colisões, portas, IA, RPCs em dois dispositivos nem a exportação APK.

## Alteração aplicada nesta versão
- O minimapa começa quase totalmente preto.
- A área próxima do jogador revela-se num raio aproximado de 4,8 unidades de mundo.
- A área já explorada permanece visível durante a sessão.
- Sensores, colegas e criatura só são desenhados no mapa quando a célula correspondente já foi explorada; o indicador do próprio jogador permanece visível.
- As áreas por descobrir são desenhadas como blocos pretos agrupados por linha para reduzir o custo de desenho em dispositivos móveis.

## Sequência recomendada de tarefas para a missão
1. Entrar e orientar-se na estação; recuperar equipamento básico.
2. Investigar os primeiros registos e perceber a contradição dos acontecimentos.
3. Ativar os relés A e B (em solo, sequencialmente; em co-op, por pessoas diferentes).
4. Explorar todas as zonas e salas, recolhendo as dez provas e cruzando os indícios.
5. Deduzir o código a partir dos quatro registos, sem o mostrar antecipadamente na interface.
6. Localizar a consola escondida e abrir o acesso confidencial.
7. **Tarefa por definir/implementar:** concluir a investigação dentro da câmara e criar um objetivo final verificável (por exemplo, preservar e transmitir as provas ou alcançar um ponto de extração), seguido de um ecrã de conclusão. A escolha do objetivo final requer aprovação de design antes de ser codificada.

## Resultado da auditoria
**Parcial:** o fluxo até ao acesso secreto é identificável no código; a conclusão integral da missão não está demonstrada. A implementação do nevoeiro do mapa foi adicionada, mas requer teste no Godot 4.5. Não se declara a missão integralmente aprovada.

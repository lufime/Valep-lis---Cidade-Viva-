extends Control
## Joystick virtual estilo jogo mobile: arrastar o manípulo para andar.
signal value_changed(value: Vector2)

@export var radius: float = 58.0
@export var dead_zone: float = 0.12
var knob_offset := Vector2.ZERO
var active_touch := -1
var active_mouse := false

func _ready() -> void:
	custom_minimum_size = Vector2(156, 156)
	mouse_filter = Control.MOUSE_FILTER_STOP
	queue_redraw()

func _notification(what: int) -> void:
	# Evita movimento preso se Android interromper o toque (notificação, troca de app ou gesto do sistema).
	if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		active_touch = -1
		active_mouse = false
		_reset_stick()

func _gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch:
		if event.pressed and active_touch == -1:
			active_touch = event.index
			_update_stick(get_global_transform().affine_inverse() * event.position)
			accept_event()
		elif not event.pressed and event.index == active_touch:
			active_touch = -1
			_reset_stick()
			accept_event()
	elif event is InputEventScreenDrag and event.index == active_touch:
		_update_stick(get_global_transform().affine_inverse() * event.position)
		accept_event()
	elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		active_mouse = event.pressed
		if active_mouse:
			_update_stick(event.position)
		else:
			_reset_stick()
		accept_event()
	elif event is InputEventMouseMotion and active_mouse:
		_update_stick(event.position)
		accept_event()

func _update_stick(local_pos: Vector2) -> void:
	var center := size * 0.5
	knob_offset = (local_pos - center).limit_length(radius)
	var value := Vector2(knob_offset.x / radius, knob_offset.y / radius)
	if value.length() < dead_zone:
		value = Vector2.ZERO
	value_changed.emit(value)
	queue_redraw()

func _reset_stick() -> void:
	knob_offset = Vector2.ZERO
	value_changed.emit(Vector2.ZERO)
	queue_redraw()

func _draw() -> void:
	var center := size * 0.5
	draw_circle(center, radius + 9.0, Color(0.02, 0.04, 0.06, 0.28))
	draw_circle(center, radius, Color(0.10, 0.14, 0.17, 0.66))
	draw_arc(center, radius, 0.0, TAU, 64, Color(0.72, 0.82, 0.88, 0.82), 2.5, true)
	draw_line(center + Vector2(-radius * 0.58, 0), center + Vector2(radius * 0.58, 0), Color(0.72, 0.82, 0.88, 0.22), 1.0)
	draw_line(center + Vector2(0, -radius * 0.58), center + Vector2(0, radius * 0.58), Color(0.72, 0.82, 0.88, 0.22), 1.0)
	draw_circle(center + knob_offset, 25.0, Color(0.75, 0.84, 0.89, 0.9))
	draw_arc(center + knob_offset, 25.0, 0.0, TAU, 40, Color(0.97, 0.99, 1.0, 0.98), 2.0, true)

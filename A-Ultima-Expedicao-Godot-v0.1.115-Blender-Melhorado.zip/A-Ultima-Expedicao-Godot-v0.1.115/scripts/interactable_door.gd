extends StaticBody3D

## Porta deslizante: a malha e a colisão pertencem ao mesmo StaticBody3D.
## require_coop só deve ficar ativo nas portas do puzzle cooperativo.
@export var require_coop: bool = true
@export var slide_distance: float = 2.55
@export var move_duration: float = 0.42
@export var locked: bool = false
var opened: bool = false
var _closed_position: Vector3
var _door_tween: Tween

func _ready() -> void:
    _closed_position = position

func interact(actor: Node) -> void:
    var expedition := _find_expedition()
    if expedition == null:
        _show_door_feedback("ERRO: controlador da expedição não encontrado")
        return
    if expedition.has_method("request_door_toggle"):
        expedition.call("request_door_toggle", self, actor)
    else:
        # Compatibilidade defensiva para cenas de teste sem ExpeditionRuntime.
        if locked:
            _show_door_feedback("PORTA BLOQUEADA — acesso elétrico sem energia ou autorização")
            return
        if require_coop and not bool(expedition.get("coop_solved")):
            _show_door_feedback("ACESSO BLOQUEADO — os relés A e B têm de ser confirmados")
            return
        _set_opened(not opened)

func open_for_coop() -> void:
    # Chamado pela autoridade quando o puzzle dos relés é concluído.
    _set_opened(true)

func apply_network_state(want_open: bool) -> void:
    # Estado replicado pelo servidor; nunca inicia outra RPC.
    _set_opened(want_open)

func _set_opened(want_open: bool) -> void:
    if opened == want_open and (_door_tween == null or not _door_tween.is_running()):
        return
    opened = want_open
    _play_door_sound()
    if _door_tween != null and _door_tween.is_running():
        _door_tween.kill()
    var target := _closed_position + Vector3(slide_distance, 0.0, 0.0) if want_open else _closed_position
    _door_tween = create_tween()
    _door_tween.set_trans(Tween.TRANS_SINE)
    _door_tween.set_ease(Tween.EASE_IN_OUT)
    _door_tween.tween_property(self, "position", target, maxf(0.05, move_duration))
    _set_indicator(want_open)

func _find_expedition() -> Node:
    var current: Node = get_parent()
    while current != null:
        if current.has_method("_show_toast") and current.has_method("_play_sfx"):
            return current
        current = current.get_parent()
    return null

func _set_indicator(is_open: bool) -> void:
    var indicator := get_node_or_null("LockIndicator") as MeshInstance3D
    if indicator and indicator.material_override is StandardMaterial3D:
        var material := indicator.material_override as StandardMaterial3D
        material.albedo_color = Color(0.12, 1.0, 0.32) if is_open else Color(1.0, 0.12, 0.06)
        material.emission = Color(0.04, 1.0, 0.16) if is_open else Color(1.0, 0.04, 0.015)

func _show_door_feedback(message: String) -> void:
    var expedition := _find_expedition()
    if expedition:
        expedition.call("_show_toast", message)

func _play_door_sound() -> void:
    var expedition := _find_expedition()
    if expedition:
        expedition.call("_play_sfx", "door_motor.wav")

extends StaticBody3D

func interact(player: Node = null) -> void:
	var world := get_parent()
	while world and not world.has_method("interact_evidence_synthesis_console"):
		world = world.get_parent()
	if world:
		world.interact_evidence_synthesis_console(player)

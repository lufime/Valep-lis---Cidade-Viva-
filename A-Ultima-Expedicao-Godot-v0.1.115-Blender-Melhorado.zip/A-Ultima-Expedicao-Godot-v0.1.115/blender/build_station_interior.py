# Blender 4.x — kit modular interior estação polar. Gera .blend e GLB.
import bpy, os
root=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'));assets=os.path.join(root,'assets');os.makedirs(assets,exist_ok=True)
for o in list(bpy.data.objects): bpy.data.objects.remove(o,do_unlink=True)
def mat(n,c,metal=0,rough=.65):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
wall=mat('Insulated_Panel',(.24,.32,.35),.25);floor=mat('Floor_AntiSlip',(.09,.13,.15),.3);orange=mat('Emergency_Orange',(.95,.19,.025));glass=mat('Cold_Glass',(.04,.24,.3),.5,.25);light=mat('LED_Light',(.75,.9,1),.1,.25)
def cube(n,loc,dim,ma):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma);return o
# Corridor module 12x3.2x3.2 with segmented wall panels and open passage
cube('Corridor_Floor',(0,0,0),(12,.18,3),floor);cube('Corridor_Ceiling',(0,3.15,0),(12,.18,3),wall)
for x in [-5,-3,-1,1,3,5]:
 cube('Left_Wall_Panel_'+str(x),(x,1.58,-1.42),(1.9,3,.16),wall);cube('Right_Wall_Panel_'+str(x),(x,1.58,1.42),(1.9,3,.16),wall)
 cube('Ceiling_LED_'+str(x),(x,3.02,0),(1,.035,.38),light)
# bulkhead frames at ends and door panels along corridor
for x in [-5.8,5.8]:
 cube('Bulkhead_Frame_'+str(x),(x,1.55,0),(.22,3,3),orange)
for x in [-3,3]:
 cube('Door_Frame_'+str(x),(x,1.2,-1.30),(.12,2.4,.15),orange);cube('Door_Panel_'+str(x),(x,1.2,-1.20),(.08,2.2,.08),wall);cube('Door_Window_'+str(x),(x,1.65,-1.14),(.09,.5,.03),glass)
# console, pipes, vents
for x in [-4.7,4.7]: cube('Wall_Console_'+str(x),(x,1.1,-1.18),(.6,.65,.25),floor);cube('Console_Screen_'+str(x),(x,1.3,-1.03),(.38,.25,.03),glass)
for z in [-.7,.7]: cube('Ceiling_Pipe_'+str(z),(0,2.78,z),(11,.08,.08),orange)
bpy.ops.object.select_all(action='SELECT');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(assets,'station_interior_modular.blend'));bpy.ops.export_scene.gltf(filepath=os.path.join(assets,'station_interior_modular.glb'),export_format='GLB',use_selection=True);print('Interior .blend e GLB exportados')

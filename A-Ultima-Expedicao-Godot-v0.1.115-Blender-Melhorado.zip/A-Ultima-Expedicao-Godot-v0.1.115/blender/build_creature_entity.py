# Blender 4.x — criatura da Última Expedição: gera .blend editável e GLB.
import bpy, math, os
from mathutils import Vector
root=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
assets=os.path.join(root,'assets'); os.makedirs(assets,exist_ok=True)
for o in list(bpy.data.objects): bpy.data.objects.remove(o,do_unlink=True)
def mat(n,c,metal=0,rough=.7):
 m=bpy.data.materials.new(n); m.diffuse_color=(*c,1); m.use_nodes=True; p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*c,1); p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
hide=mat('Creature_Skin_Charcoal',(.035,.055,.06),.15,.4); bone=mat('Pale_Bone',(.45,.52,.49),.1,.55); eye=mat('Bioluminescent_Eye',(.7,.025,.012),.2,.25); claw=mat('Claws',(.13,.15,.15),.35,.3)
def ell(n,loc,scale,ma):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,location=loc);o=bpy.context.object;o.name=n;o.scale=scale;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma);return o
def cone(n,a,b,r1,r2,ma):
 d=Vector(b)-Vector(a);mid=(Vector(a)+Vector(b))/2;bpy.ops.mesh.primitive_cone_add(vertices=12,radius1=r1,radius2=r2,depth=d.length,location=mid);o=bpy.context.object;o.name=n;o.rotation_mode='QUATERNION';o.rotation_quaternion=d.to_track_quat('Z','Y');o.data.materials.append(ma);return o
ell('Creature_Torso',(0,1.65,0),(.55,.85,.36),hide);ell('Creature_Thorax',(0,1.25,.02),(.48,.55,.34),hide);ell('Creature_Skull',(0,2.48,.12),(.36,.43,.32),hide)
for s in [-1,1]:
 ell('Eye_'+str(s),(s*.22,2.53,.39),(.075,.09,.035),eye)
 cone('Horn_'+str(s),(s*.23,2.75,.08),(s*.43,3.15,.06),.13,.015,bone)
 cone('Arm_'+str(s),(s*.38,2.08,0),(s*.63,1.43,.05),.19,.12,hide);ell('Hand_'+str(s),(s*.65,1.36,.08),(.16,.13,.16),hide)
 for i in range(3): cone('Claw_'+str(s)+'_'+str(i),(s*(.58+i*.07),1.33,.17),(s*(.62+i*.07),1.12,.19),.045,.005,claw)
 cone('Leg_'+str(s),(s*.23,1.05,0),(s*.28,.28,.06),.23,.13,hide);ell('Foot_'+str(s),(s*.29,.17,.18),(.22,.13,.36),hide)
for i in range(7): ell('Dorsal_Ridge_'+str(i),(0,2.15-i*.17,-.30),(.12,.11,.16),bone)
# Armature, with root/spine/head/limbs for later animation authoring
bpy.ops.object.armature_add(enter_editmode=True); arm=bpy.context.object;arm.name='Creature_Armature';eb=arm.data.edit_bones;eb[0].name='Root';eb[0].head=(0,0,0);eb[0].tail=(0,.5,0)
def bn(n,h,t,p): b=eb.new(n);b.head=h;b.tail=t;b.parent=eb.get(p)
bn('Spine',(0,.5,0),(0,1.8,0),'Root');bn('Head',(0,1.8,0),(0,2.7,0),'Spine')
for s in [-1,1]: bn('Arm.'+str(s),(s*.3,2,0),(s*.65,1.35,0),'Spine');bn('Leg.'+str(s),(s*.2,1.1,0),(s*.28,.2,0),'Root')
bpy.ops.object.mode_set(mode='OBJECT')
# Associar cada peça rígida ao osso correspondente para que o rig mova realmente a geometria.
def bone_for_object(obj):
 n=obj.name.lower()
 if any(k in n for k in ('skull','eye_','horn_')): return 'Head'
 if 'arm_' in n or 'hand_' in n or 'claw_' in n: return 'Arm.' + ('-1' if '_-1' in n or n.endswith('_-1') else '1')
 if 'leg_' in n or 'foot_' in n: return 'Leg.' + ('-1' if '_-1' in n or n.endswith('_-1') else '1')
 return 'Spine'
for obj in [o for o in bpy.context.scene.objects if o.type=='MESH']:
 bn=bone_for_object(obj); vg=obj.vertex_groups.new(name=bn); vg.add(list(range(len(obj.data.vertices))),1.0,'REPLACE')
 mod=obj.modifiers.new('Creature_Armature_Deform','ARMATURE'); mod.object=arm
# Add named animation actions for later playback from Godot.
for action_name, frames, amp in [('Idle',[1,20,40],0.025),('Walk',[1,11,21],0.35),('Attack',[1,6,12],0.55)]:
 act=bpy.data.actions.new(action_name); arm.animation_data_create(); arm.animation_data.action=act
 for pb in arm.pose.bones: pb.rotation_mode='XYZ'
 for f in frames:
  phase=(f-1)/(frames[-1]-1)*2*math.pi
  for bn in ('Spine','Head','Arm.-1','Arm.1','Leg.-1','Leg.1'):
   pb=arm.pose.bones.get(bn)
   if pb is None: continue
   if action_name=='Idle': value=amp*math.sin(phase)
   elif action_name=='Walk': value=amp*math.sin(phase)*( -1 if bn.endswith('-1') else 1)
   else: value=amp*math.sin(phase) if bn.startswith('Arm') or bn=='Head' else 0.0
   pb.rotation_euler[0]=value; pb.keyframe_insert(data_path='rotation_euler',frame=f,group=bn)
 act.use_fake_user=True
arm.animation_data.action=bpy.data.actions.get('Idle')
bpy.context.scene.frame_start=1; bpy.context.scene.frame_end=40; bpy.context.scene.render.fps=24
blend_out=os.path.join(assets,'creature_entity.blend'); glb_out=os.path.join(assets,'entity_creature.glb')
bpy.ops.object.select_all(action='DESELECT')
for o in bpy.context.scene.objects:
 if o.type in {'MESH','ARMATURE'}: o.select_set(True)
bpy.context.view_layer.objects.active=arm
bpy.ops.wm.save_as_mainfile(filepath=blend_out)
bpy.ops.export_scene.gltf(filepath=glb_out,export_format='GLB',use_selection=True,export_animations=True,export_skins=True,export_materials='EXPORT')
print('BLEND_OUTPUT=',blend_out); print('GLB_OUTPUT=',glb_out); print('ACTIONS=Idle,Walk,Attack')

# Oito jogadores 3D — Blender/Godot

O jogo aplica oito variantes de aparência aos avatares remotos com base no ID de rede. O modelo-base editável e o script de construção Blender existentes permanecem incluídos. Para oito modelos com geometrias, rostos, corpos e animações realmente independentes, é necessário criar e riggar oito personagens separados; esta versão implementa oito identidades visuais, mas ainda não afirma ter oito malhas independentes.


## Rig e animações (etapa seguinte)
Executar `build_rigged_animated_players.py` no Blender 4.x para gerar uma fonte `.blend` editável e `player_expedition_rigged.glb` com armature e ações Idle/Walk/Run. Ver `docs/JOGADORES_3D_RIG_ANIMACOES.md`. A geração não foi executada aqui, pois Blender não está instalado.

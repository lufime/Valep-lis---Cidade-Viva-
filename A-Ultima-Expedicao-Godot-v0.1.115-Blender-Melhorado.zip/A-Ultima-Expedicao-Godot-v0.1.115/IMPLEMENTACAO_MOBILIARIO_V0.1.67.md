# A Última Expedição — V0.1.67 — Mobiliário completo das 10 zonas

## Alterações nesta versão

- Mobiliário detalhado para as 10 zonas principais e as 20 salas anexas (30 espaços no total).
- Armários com portas, puxadores e ventilação; prateleiras com caixas e conteúdo; mesas com objetos; cadeiras com assento, costas, pernas e pés.
- Equipamento temático: triagem e macas, comunicações e monitores, amostras e microscópio, baterias e armários elétricos, camas clínicas, ferramentas, vidro de contenção, vigilância, cápsula de contenção e arquivo de extração.
- Sinalética por zona e detalhes visuais de terminais, ecrãs, teclados, papéis e recipientes.
- Corrigida a ramificação duplicada da Zona 10 que tornava o segundo conjunto de caixas inalcançável.
- Mantidos os ficheiros e sistemas existentes do projeto; alterações concentradas em `scripts/expedition.gd` e neste README.

## Verificação

- ZIP de origem lido e extraído sem erro.
- Verificação estática de delimitadores GDScript: sem desequilíbrios encontrados.
- Confirmadas as chamadas para os novos construtores de mobiliário e a existência dos ficheiros `res://` referenciados no projeto.
- **Não foi possível executar Godot 4.5 neste ambiente.** A compilação, colisões em runtime, navegação real do jogador e desempenho Android continuam por confirmar; não são declarados aprovados.

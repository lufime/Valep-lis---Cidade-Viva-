# A Última Expedição — Relatório V0.1.102

## Objetivo
Adicionar navegação por caminho à criatura controlada pela IA, preservando as regras narrativas, o papel humano do traidor e a autoridade do servidor no multijogador.

## Alterações
- Implementada uma grelha local A* (AStar2D) à volta da criatura.
- Cada célula é verificada com uma cápsula de espaço físico; células em colisão são bloqueadas.
- A rota usa vizinhos ortogonais, evitando atalhos diagonais por cantos.
- A rota é atualizada periodicamente para reagir a alterações de obstáculos, incluindo portas que abrem ou fecham.
- O movimento continua a usar CharacterBody3D e move_and_slide(); a física continua a ser a última barreira contra atravessar geometria sólida.
- A grelha é local e limitada; se o destino estiver fora dela, a IA avança para a extremidade na direção do destino e recalcula à medida que se move.
- Preservadas as transições narrativas já existentes, incluindo o desaparecimento quando observada e os reposicionamentos intencionais associados a esses estados.

## Verificações
- Auditoria estática do projeto: executada separadamente; consultar o ficheiro de testes entregue com o ZIP.
- Integridade do arquivo ZIP: verificada após empacotamento.
- Execução no Godot 4.5: NÃO EXECUTADA neste ambiente (binário indisponível).
- Teste real de navegação contra portas abertas/fechadas, corredores, perseguição e multijogador: PENDENTE.
- Exportação Android: NÃO EXECUTADA.

## Limitações conhecidas
A grelha usa amostragem física local e pode falhar em corredores mais estreitos do que a resolução da grelha, em desníveis relevantes ou em geometria não alinhada com o piso assumido. O bloqueio físico continua a impedir a passagem através de colisores, mas isso não prova que a criatura encontre sempre uma rota alternativa. É necessário validar em runtime no Godot 4.5 e ajustar a resolução/limites se os testes reais revelarem problemas.

## Integridade das regras
Não foram alteradas as regras de atribuição do traidor, a natureza da criatura, os objetivos secretos nem a lógica de interação cooperativa.

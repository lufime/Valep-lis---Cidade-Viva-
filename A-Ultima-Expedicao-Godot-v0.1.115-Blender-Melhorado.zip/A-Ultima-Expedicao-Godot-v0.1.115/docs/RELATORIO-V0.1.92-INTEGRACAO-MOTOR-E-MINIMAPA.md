# V0.1.92 — Integração do motor e planta do complexo

## Alterações concretas
- Corrigidos os limites do minimapa para abranger o terreno gerado entre X=-38.3..38.3 e Z=-217.3..15.3.
- A área cartográfica mantém a mesma escala nos eixos X/Z; o desenho é centrado no painel em vez de esticar a planta.
- A planta mostra desde o início a Zona 02, as Zonas 03–10 e os corredores com base nas mesmas coordenadas usadas pelo gerador 3D.
- A exploração progressiva continua a controlar a apresentação de jogadores remotos e da entidade; deixou de ocultar a própria planta estrutural.
- Mantidos os pontos de entrada do projeto: `project.godot` → `Boot.tscn` → `boot.gd` → `Expedition.tscn` → `expedition.gd`; o minimapa é instanciado no HUD e resolve o nó `Player` na cena `ExpeditionRuntime`.

## Auditoria técnica
- Verificados os caminhos `res://` literais e a integridade do ZIP.
- A auditoria estática Python verifica recursos e regras lógicas, mas não interpreta GDScript como o Godot.
- Não foi possível executar o motor Godot 4.5 neste ambiente; compilação GDScript, colisões reais, percurso das dez zonas, multiplayer e exportação APK continuam por validar em runtime.

## Limitação conhecida
As portas decorativas entre Zonas 03–10 são geometria visual recolhida lateralmente, não portas interativas com estado. Esta alteração corrige a planta do minimapa e as referências de escala, mas não declara as portas como mecanismos funcionais.

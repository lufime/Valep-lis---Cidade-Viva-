# V0.1.74 — Sequência jogável de extração

## Alterações
- O terminal exige os objetivos de investigação já existentes antes de permitir pedir o resgate.
- A interação inicia uma janela de sobrevivência de 35 segundos; a IA da criatura continua ativa.
- Depois da contagem, acende-se o marcador exterior de extração e o jogador tem de chegar à zona iluminada.
- Só chegar à zona exterior após a espera conclui a missão e apresenta «EXTRAÇÃO CONFIRMADA».
- No multijogador, o servidor controla o estado da sequência e replica as mudanças essenciais aos clientes.
- O modo individual não depende de um segundo jogador.

## Verificação e limitações
- Foi verificada a integridade do ZIP e a presença das funções/estados no código.
- Não foi possível executar o Godot 4.5 nesta sessão; compilação, navegação real até ao marcador e teste em duas instâncias continuam por executar.
- A chegada ao marcador é validada por proximidade; não existe sistema de morte/ferimentos neste patch, portanto a sobrevivência significa manter a personagem ativa durante a janela de espera.

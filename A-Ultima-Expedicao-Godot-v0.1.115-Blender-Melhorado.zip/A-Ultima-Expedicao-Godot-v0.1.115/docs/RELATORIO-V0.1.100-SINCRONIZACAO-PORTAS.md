# Relatório V0.1.100 — Sincronização multijogador das portas

## Alteração implementada
- A interação com uma porta passa pelo controlador da expedição.
- Em multijogador, clientes enviam ao servidor o caminho da porta, em vez de alterar localmente a colisão.
- O servidor valida que a porta existe, que o jogador está a 3,6 m ou menos, que não está bloqueada e que os relés cooperativos estão concluídos quando exigidos.
- Só depois da validação, o servidor altera a porta e replica o estado aberto/fechado a todos os clientes através de RPC fiável.
- O caminho de estado replicado não volta a iniciar RPC, evitando ciclos de sincronização.
- O modo individual continua a usar a autoridade local.

## Limites de validação
A auditoria estática verifica a presença dos pontos críticos no código. Não foi possível executar Godot neste ambiente; a sintaxe GDScript em runtime, colisões reais e sincronização com dois dispositivos continuam por validar numa execução Godot 4.5.

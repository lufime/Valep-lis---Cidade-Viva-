# Relatório V0.1.33 — combinação da sala secreta

- A porta da sala secreta já não é desbloqueada por uma simples interação com a consola.
- É necessário encontrar as 10 provas, localizar quatro algarismos escondidos em quatro documentos e introduzir a combinação no painel da consola.
- As pistas revelam os algarismos na ordem dos documentos: 4, 8, 2, 6.
- A combinação correta é 4826. Um código errado mantém a fechadura bloqueada e mostra uma mensagem de erro.
- Depois de validar a combinação, o jogador ainda tem de interagir com a porta para a abrir.
- O painel tem campo numérico de quatro algarismos, botão de validação e botão para fechar, adequado a ecrãs táteis.

Validação efetuada: integridade do ZIP e inspeção textual das alterações. Não foi possível executar o projeto no motor Godot nesta sessão; a compilação GDScript e o comportamento em jogo/multijogador continuam por validar.

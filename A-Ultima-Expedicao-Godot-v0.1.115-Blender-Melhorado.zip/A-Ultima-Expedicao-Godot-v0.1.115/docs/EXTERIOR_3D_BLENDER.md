# Exterior 3D — A Última Expedição

Foi adicionado um cenário exterior modular da estação polar em `assets/polar_station_exterior.glb` e uma cena reutilizável `scenes/PolarStationExterior.tscn`.

O modelo inclui terreno nevado, módulo principal, laboratório, entrada, janelas, antena, prato de comunicações, iluminação, geradores, caixas e rochas/cristas de gelo.

`blender/build_polar_station_exterior.py` é o script editável para reconstruir o modelo dentro do Blender e exportar GLB. O Blender não é necessário durante o jogo: Godot carrega o GLB exportado.

**Validação pendente:** executar a cena no Godot 4.5, verificar escala/iluminação/colisões e integrar a cena no fluxo de jogo sem substituir a cena interior existente. Não foi declarado teste de runtime aprovado.

# V0.1.69 — Trilho de pistas e legibilidade

- Cada prova recolhida dá uma indicação da zona e do tipo de sala onde procurar a seguinte.
- As provas têm uma etiqueta 3D pequena (`REGISTO 01`–`REGISTO 10`) e brilho frio moderado, para se distinguirem de mobiliário e decoração.
- Mantém-se a progressão narrativa: pistas adicionais para a parede falsa/consola são dadas aos 3, 6 e 10 registos.
- Removidos dois spawns explícitos duplicados das provas 01 e 02; cada zona principal mantém o spawn de prova do gerador de zonas.

## Validação

ZIP reempacotado e verificado estruturalmente. Godot 4.5 não está instalado neste ambiente; parse, posicionamento em runtime, colisões e recolha em jogo continuam por executar e não são declarados aprovados.

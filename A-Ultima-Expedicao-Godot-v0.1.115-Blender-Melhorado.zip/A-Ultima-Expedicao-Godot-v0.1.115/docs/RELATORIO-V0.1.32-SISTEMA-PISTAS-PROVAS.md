# V0.1.32 — Sistema de pistas e provas

## Fluxo de jogo
1. Os jogadores exploram as dez zonas e interagem com dez objetos de prova.
2. O servidor regista cada fragmento apenas uma vez e sincroniza o progresso com os clientes.
3. Com menos de dez provas, a consola recusa a síntese e informa que faltam fragmentos.
4. Com as dez provas, a equipa tem de regressar à consola e interagir para reconstruir a cadeia de evidências.
5. A síntese reúne os registos numa sequência narrativa que aponta para uma experiência planeada pela VANTHIS.
6. A porta secreta só abre depois da recolha integral e da síntese.

## Tipos de prova
- Admissão do sujeito.
- Consentimento falsificado.
- Relatório de manutenção e sensores desligados.
- Protocolo de incubação.
- Falha de energia provocada.
- Relatório de contenção.
- Diário de laboratório.
- Ordem de segurança e atraso na evacuação.
- Sequência de ativação.
- Gravação final da experiência.

## Estado técnico
O código foi alterado e o arquivo ZIP foi validado quanto à integridade e presença dos ficheiros. Não foi possível executar Godot nesta sessão; sintaxe GDScript, geometria e rede têm de ser confirmadas no motor antes de considerar o sistema testado.

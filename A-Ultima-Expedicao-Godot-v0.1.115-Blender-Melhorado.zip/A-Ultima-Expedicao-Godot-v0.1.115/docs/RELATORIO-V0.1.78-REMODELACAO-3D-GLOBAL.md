# V0.1.78 — Remodelação visual 3D global

## Alterações
- Passe visual transversal ao cenário sem alterar a estrutura de missão.
- Condutas técnicas e suportes no teto ao longo do eixo principal.
- Grelhas de ventilação, LEDs de serviço, painéis de manutenção e faixas de segurança nas oito zonas modulares.
- Mastro de comunicações e projetores junto à zona exterior do gerador.
- Névoa atmosférica ajustada para reforçar a profundidade sem efeitos volumétricos pesados.
- Elementos decorativos sem colisões novas para evitar bloquear corredores e portas.
- Renderizador Mobile e lógica de jogo preservados.

## Validação
- ZIP e alterações textuais verificados.
- Godot 4.5 não está instalado neste ambiente; compilação, renderização, FPS e exportação Android ainda precisam de ser confirmados no workflow.

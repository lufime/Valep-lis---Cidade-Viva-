# V0.1.63 — Abrigo seguro e ponto fraco integrado

## Integração realizada
- Construído um abrigo físico na área polar exterior, com chão, paredes, teto, porta blindada com colisão, iluminação de emergência e provisões/rádio visuais.
- A alimentação/fecho do abrigo é independente do MRE.
- A porta abre e fecha por interação; enquanto o fecho está normal, a criatura não a abre diretamente.
- O painel exterior é o ponto fraco: a criatura tem de permanecer junto dele durante 9 segundos para causar avaria; afastar-se interrompe a pressão e reduz o progresso.
- A avaria é sinalizada visualmente e pode ser reparada a partir do comando de emergência no interior, permitindo jogar a solo sem depender de outro jogador.
- A IA desloca a criatura para outra zona quando o jogador está dentro do abrigo e a criatura se aproxima da entrada, evitando o bloqueio indefinido à porta.
- O abrigo não é alimentado pelo MRE; a perda do MRE não afeta o fecho.

## Limites e validação
- Foram feitas alterações no código e verificações estáticas/estruturais do ZIP.
- O executável Godot não está instalado neste ambiente; não foi possível executar o parser/runtime, validar colisões em jogo, testar a IA em movimento nem exportar APK. Não declarar esta versão aprovada em runtime.
- O ponto fraco é um protótipo funcional por interação: o painel fica danificado por proximidade prolongada da criatura, não por um sistema de animação física de golpes. A regra de rota é por posição, não navegação completa com NavigationAgent3D.

# A Última Expedição — interface Android V0.1.23

## Correções adicionais
- Corrigida a referência do botão AGACHAR/LEVANTAR: o caminho era consultado antes de o botão entrar na árvore de cena, podendo ficar vazio. Agora o jogador guarda uma referência direta ao botão.
- A área dos botões é excluída do gesto de rotação da câmara, com margem de segurança adicional para toques próximos dos controlos.
- Reduzida a largura relativa dos painéis de pistas e confronto em ecrãs estreitos para diminuir a sobreposição da zona de jogo.
- Mantidas as regras de cooperação, a criatura sob controlo da IA e os objetivos secretos do traidor.

## Validação honesta
- Verificada a estrutura do projeto e a presença dos scripts/cenas necessários.
- Não foi possível executar o motor Godot neste ambiente. A compilação Android, a apresentação em diferentes resoluções e a ligação LAN permanecem por testar em dispositivos reais ou num runner Godot.

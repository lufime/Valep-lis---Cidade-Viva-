# Relatório V0.1.83 — correção de versão e auditoria do HUD

## Correção realizada
- O diretório interno do projeto passa a identificar corretamente `A-Ultima-Expedicao-Godot-v0.1.83-CORRECAO-VERSAO-HUD`.
- `VERSION.txt` e `scripts/VERSION.txt` foram atualizados para 0.1.83.
- Referências à versão 0.1.81 em README e metadados principais foram atualizadas quando presentes.

## Auditoria do HUD fisiológico
A versão recebida já cria visualmente os controlos `PulseBar`, `PulseValue`, `HealthBar`, `HealthValue` e `PhysiologyStatus`. Porém, a inspeção estática deste ficheiro não encontrou lógica que atualize estes controlos durante o jogo nem um sistema de saúde/pulsação associado. Assim, não é correto declarar que a pulsação e a saúde são dinâmicas nesta versão; os valores definidos no HUD parecem ser valores iniciais estáticos.

## Testes
- ZIP de entrada extraído e analisado.
- Integridade do ZIP de saída verificada com `unzip -t`.
- Não foi possível executar o Godot 4.5 neste ambiente; compilação e teste de runtime não confirmados.

# Auditoria V0.1.98 — Ciclo de observação da criatura

## Problema reproduzido por análise do fluxo de código

Em `scripts/expedition.gd`, a IA entrava no estado `OBSERVED` e definia `entity_hidden_time = 2.6`. No processamento seguinte, a verificação `_is_entity_observed(player)` voltava a executar antes de tratar a saída desse estado, renovando o temporizador enquanto o jogador continuasse a olhar para a posição da criatura. Isso podia deixar a criatura invisível indefinidamente e interromper a perseguição/patrulha.

## Correção

- O estado `OBSERVED` é agora processado antes de uma nova verificação de observação.
- O temporizador diminui de forma contínua e não é renovado a cada frame.
- Quando o temporizador termina, a criatura muda para um ponto de patrulha, volta a ficar visível e a IA retoma o ciclo.
- Adicionada uma verificação estática de regressão para a ordem dos ramos.

## Limites

A auditoria estática pode verificar a ordem e a presença da lógica, mas não comprova comportamento visual nem navegação real. O executável Godot 4.5 não está disponível neste ambiente; não foi possível executar a cena, a IA ou os testes multijogador.

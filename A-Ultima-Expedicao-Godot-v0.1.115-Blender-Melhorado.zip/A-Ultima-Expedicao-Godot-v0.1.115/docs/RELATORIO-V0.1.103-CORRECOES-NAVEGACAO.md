# A Última Expedição — Relatório V0.1.103

## Base
ZIP V0.1.102 inspecionado e auditado novamente.

## Problemas concretos encontrados
- Quando o cursor da rota chegava ao último ponto, o código podia voltar a apontar diretamente para o alvo enquanto aguardava a atualização do A*. Isso permitia tentar contornar a rota calculada durante esse intervalo.
- Se a pesquisa A* devolvesse uma rota vazia, o movimento ainda tinha o alvo direto como destino de recurso.
- O preset de exportação Android ainda indicava o nome de APK da versão V0.1.75.

## Correções aplicadas
- O destino de movimento passa a permanecer no último ponto da rota até a grelha ser recalculada.
- Se não houver rota válida, a criatura para em vez de avançar em linha direta.
- O caminho de exportação da APK foi atualizado para V0.1.103.
- Atualizadas as versões e acrescentadas três verificações estáticas de regressão.

## Validação
- A auditoria estática e a integridade do ZIP devem ser executadas após empacotamento.
- Godot 4.5 não está instalado neste ambiente: importação, análise GDScript em runtime, arranque do jogo, física, navegação real, multijogador e exportação APK permanecem NÃO TESTADOS.
- A função de IA continua a ser chamada pelo ciclo `_process`; a adequação de `move_and_slide()` ao ciclo de física deve ser verificada no Godot 4.5 e, se necessário, separada em `_physics_process` numa correção própria.

## Âmbito
Não foram alteradas regras narrativas, papéis, objetivos secretos ou autoridade de servidor.

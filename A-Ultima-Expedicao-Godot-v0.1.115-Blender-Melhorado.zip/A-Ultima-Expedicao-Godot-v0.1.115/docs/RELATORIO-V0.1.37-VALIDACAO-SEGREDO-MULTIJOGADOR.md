# V0.1.37 — validação do segredo e sincronização

## Regras
- As dez provas revelam a consola, nunca a porta.
- A porta permanece invisível e sem colisão até a combinação ser validada pelo anfitrião.
- O código é dedutível pela ordem indicada na chave de leitura: alertas confirmados (7), ciclos rejeitados (3), circuito isolado primeiro (1), primeiro ciclo estável (4). O código completo não surge num único documento.
- O servidor sincroniza o progresso e envia o estado atual a quem entra numa sessão em curso.
- O servidor valida a combinação e controla o estado da porta.

## Validação
- Verificada a integridade do ZIP.
- Reverificação estática das funções alteradas.
- Não foi possível executar o Godot 4.5 neste ambiente. Compilação GDScript, execução 3D, teste em dois dispositivos e APK não são declarados como aprovados.

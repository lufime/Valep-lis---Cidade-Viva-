# A Última Expedição v0.1.20 — auditoria e correções

## Correções aplicadas

- Corrigida a pesquisa do HUD pelo controlador do jogador: o jogador procura `HUD/Prompt` na sua cena `ExpeditionRuntime`, em vez de procurar na cena global `Boot`.
- Corrigida a descoberta do mundo e do jogador no mini-mapa: sobe a árvore de ancestrais até encontrar o nó que contém `Player`, sem depender de `SceneTree.current_scene`.
- Adicionado aviso de diagnóstico se o HUD não for encontrado.
- Atualizado o caminho de exportação do preset Android para v0.1.20.
- Mantida a cena de arranque e a camada de diagnóstico separada da cena do jogo.

## Validação e limitações

- O arquivo ZIP de entrada foi extraído com sucesso.
- Esta versão foi revista estaticamente e o ZIP final será verificado quanto à integridade.
- O ambiente de trabalho não tem o executável Godot 4.5 instalado; não foi possível executar o parser, importar recursos, correr a cena ou exportar/testar um APK.
- Portanto, não se declara que todos os erros estejam eliminados. A validação final requer o workflow Godot 4.5/Android e análise dos logs resultantes.

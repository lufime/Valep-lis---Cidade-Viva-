# Relatório V0.1.85 — etiquetas de teste de interação

## Alterações
- Adicionado helper `_add_interaction_test_label()` que cria `Label3D` com billboard, contraste e contorno.
- Etiquetas nas 10 pistas físicas recolhíveis.
- Etiquetas nos relés A/B, consola de síntese, terminal de extração, porta experimental e painéis interativos do abrigo.
- Não foram convertidos objetos meramente decorativos em objetos interativos; as etiquetas são colocadas nos nós que já possuem lógica de interação.

## Limites da validação
- Inspeção estática do código e teste de integridade do arquivo ZIP.
- Não foi possível executar Godot 4.5, exportar APK nem validar as etiquetas no ecrã real.

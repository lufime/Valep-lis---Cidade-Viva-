# A Última Expedição — v0.1.13

## Integração incluída
- Introdução pública no menu: desaparecimento das comunicações da Estação Véspera, enquadramento oficial da VANTHIS Corporation e objetivos da equipa, sem revelar a ameaça nem o papel secreto.
- Atribuição aleatória de um traidor humano pelo anfitrião após a entrada do primeiro cliente.
- Mensagem privada explícita para o traidor (“ÉS O TRAIDOR”) e instruções secretas de encobrimento; os restantes participantes recebem uma instrução de explorador.
- Criatura criada em todas as execuções e controlada pela lógica de IA existente. Nenhum jogador é escolhido para a controlar.

## Limitações e validação
- Não foi possível executar Godot 4.5 neste ambiente; não declarar a revisão compilada ou testada no motor.
- A distribuição de papéis é acionada pela primeira ligação de cliente, pois ainda não existe sala de espera/início formal da partida.
- A criatura ainda não tem sincronização autoritativa de posição/estado entre os clientes; a IA corre localmente em cada instância.
- A atribuição e as mensagens privadas devem ser testadas com dois ou mais dispositivos antes de considerar a funcionalidade pronta para lançamento.

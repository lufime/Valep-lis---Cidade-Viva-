# A Última Expedição — V0.1.27
## Diretor de suspense polar

### Alterações nesta revisão
- A criatura deixa de ser materializada imediatamente no arranque normal da partida.
- O anfitrião executa um diretor de suspense autoritativo.
- Antes do primeiro contacto visual, o HUD apresenta sinais ambientais variáveis: interferência de rádio, impactos metálicos, leituras inconclusivas, rajadas polares, passos e oscilações de energia.
- Os intervalos dos sinais e a janela da primeira aparição variam por partida.
- A primeira aparição é comunicada como um contacto visual breve, mantendo a criatura sob controlo da IA.
- Os efeitos sonoros usam recursos já presentes no projeto.

### Limitações e validação
- O código foi alterado, mas não foi possível executar o projeto no motor Godot neste ambiente; a compilação/runtime não está certificada.
- A sincronização da sequência de suspense para todos os clientes deve ser validada numa sessão multijogador real.
- A lógica narrativa existente pode ainda ativar a criatura mais cedo como consequência de uma decisão; esse caminho foi mantido para preservar os eventos atuais.

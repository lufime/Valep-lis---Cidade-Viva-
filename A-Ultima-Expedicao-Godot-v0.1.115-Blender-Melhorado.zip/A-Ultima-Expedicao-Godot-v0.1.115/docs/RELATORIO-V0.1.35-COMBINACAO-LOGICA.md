# V0.1.35 — combinação lógica

As pistas deixaram de revelar algarismos diretamente. O jogador tem de cruzar a cronologia dos turnos, os ciclos de incubação, os avisos confirmados e a ordem real dos procedimentos. Números administrativos e alarmes de teste são distratores que devem ser excluídos. A consola e as mensagens de erro orientam o método sem revelar a resposta.

Validação: integridade do ZIP e inspeção textual. O projeto não foi executado no Godot nesta sessão; compilação GDScript e dedução em jogo por validar.

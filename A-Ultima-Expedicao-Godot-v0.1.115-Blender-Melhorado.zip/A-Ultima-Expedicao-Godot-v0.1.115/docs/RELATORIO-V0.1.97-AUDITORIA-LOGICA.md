# Auditoria lógica V0.1.97 — Extração de equipa

## Correções desta revisão

- O pedido de extração é rejeitado quando iniciado por um participante já eliminado.
- A fase final deixa de concluir a missão quando apenas um jogador alcança o ponto de resgate.
- Todos os jogadores sobreviventes ativos da sessão têm de chegar à zona de extração.
- Participantes eliminados não bloqueiam o resgate dos sobreviventes; uma sessão sem sobreviventes nunca recebe vitória.
- As mensagens da interface foram ajustadas para indicar que a equipa deve reunir-se no ponto de extração.

## Verificação

Foi executada a auditoria estática `python tests/quality_audit.py`. Esta verifica referências e regras de código, não a execução de GDScript, física, IA, ligação multijogador ou exportação Android.

O executável Godot 4.5 não está disponível neste ambiente; por isso, esta revisão não é declarada testada em runtime. A lógica de extração deve ser validada no motor com cenários solo, dois jogadores, desconexão e jogador eliminado.

# V0.1.93 — Dossier de provas e comparação

## Implementado no código
- Botão HUD `DOSSIÊ / COMPARAR PROVAS`.
- Painel de dossier acessível durante a missão.
- A lista mostra apenas as dez provas efetivamente recolhidas pelo jogador.
- Seleção de duas provas diferentes e comparação lado a lado.
- Relações classificadas como possíveis, cronológicas, inconsistências ou pistas espaciais; não declara uma hipótese como facto.
- O painel atualiza a lista após recolher uma prova.
- Não revela a identidade nem o papel secreto dos outros participantes.

## Limitações e validação pendente
- A comparação usa descrições e relações determinísticas do conteúdo atual; não é um motor de dedução geral.
- O jogo não foi executado no Godot 4.5 neste ambiente. Compilação GDScript, apresentação no Android e sincronização multijogador do dossier têm de ser validadas no motor.
- Não declarar a versão como pronta para lançamento antes dos testes de execução.

# A Última Expedição — V0.1.24

## Correção aplicada
- Corrigida a ligação entre o botão móvel de agachamento e o controlador da personagem.
- A interface guardava um NodePath antes de o botão ser inserido na árvore e o controlador procurava uma meta diferente. Agora o controlador recebe a referência direta do botão criado e pode alternar o rótulo entre **AGACHAR** e **LEVANTAR**.
- Mantidos os controlos de movimento, interação, lanterna, minimapa, decisões e rede LAN.

## Verificação realizada
- Confirmado que o bloco de código original existia antes de o substituir.
- Verificada a presença da nova referência `crouch_button_ref` no HUD e no controlador.
- Integridade do ZIP validada após a criação.

## Limitações
Não foi possível executar Godot nesta sessão. Não declarar compilação, execução Android ou testes LAN como aprovados sem os executar no motor e em dispositivos.

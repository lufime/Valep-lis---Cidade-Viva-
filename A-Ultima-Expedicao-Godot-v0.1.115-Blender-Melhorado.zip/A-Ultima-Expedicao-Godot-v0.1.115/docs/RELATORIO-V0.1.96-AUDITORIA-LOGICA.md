# Relatório — V0.1.96: quórum de votação

## Correção aplicada

A V0.1.95 resolvia a votação após no máximo dois votos, mesmo quando havia mais participantes ligados. Isso podia fazer com que a decisão coletiva ignorasse parte da equipa.

Nesta versão:
- cada jogador ligado precisa de votar para a decisão ser resolvida;
- o servidor só aceita votos do anfitrião ou de IDs atualmente ligados;
- votos de jogadores desligados são removidos;
- quando alguém se desliga, o quórum é recalculado para a decisão não ficar bloqueada por um participante ausente;
- o modo individual mantém a decisão de um único jogador.

## Validação

- Executar `python tests/quality_audit.py` para verificar os ficheiros, referências e condições estáticas.
- O teste estático não simula uma sessão ENet nem substitui testes de rede no Godot.
- Godot 4.5 não está disponível neste ambiente; compilação GDScript, partida real, rede multijogador e exportação APK não foram executadas.

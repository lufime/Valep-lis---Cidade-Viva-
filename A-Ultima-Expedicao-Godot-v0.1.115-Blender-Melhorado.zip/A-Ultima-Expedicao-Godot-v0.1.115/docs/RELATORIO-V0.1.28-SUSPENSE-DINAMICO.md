# A Última Expedição — V0.1.28
## Suspense sem cronómetro fixo para a primeira aparição

### Alteração
- Removida a aparição automática da criatura baseada num intervalo fixo de 150–240 segundos.
- Os sinais ambientais continuam a ocorrer com intervalos variáveis para criar tensão.
- A criatura pode ser ativada pelos acontecimentos narrativos existentes, incluindo a resolução da decisão do grupo; o anfitrião continua a ser a autoridade da IA.
- Não há promessa de uma primeira aparição num minuto específico.

### Limitação
Esta alteração elimina o gatilho temporal, mas não cria por si só um sistema completo de pontuação de progresso ambiental. A aparição continua dependente dos gatilhos narrativos já existentes no projeto, e a execução no Godot/multijogador precisa de ser validada.

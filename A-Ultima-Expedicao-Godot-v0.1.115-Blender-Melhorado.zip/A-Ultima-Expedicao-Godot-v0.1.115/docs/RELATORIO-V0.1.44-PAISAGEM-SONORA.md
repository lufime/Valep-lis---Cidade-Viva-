# Relatório V0.1.44 — Paisagem Sonora Imersiva

## Alterações
- Camadas contínuas de vento polar e zumbido elétrico, com volume baixo para não tapar passos nem diálogos.
- Novos efeitos procedurais: rangido estrutural, fissura de gelo, batimento cardíaco grave e três variantes de deslocação da criatura.
- Adicionados os ficheiros `door_open.wav` e `radio_static.wav`, que já eram referenciados pelo código mas não existiam no pacote anterior.
- Eventos ambientais variam entre rangidos, estalidos de gelo, interferência de rádio e cliques de relé. Os intervalos de suspense continuam espaçados.
- Corrigida a ligação duplicada ao sinal `finished` dos emissores 3D.

## Limites
Os sons novos foram sintetizados proceduralmente para este projeto e não são gravações de campo. A validação do ZIP e as verificações estáticas não substituem a audição no jogo nem a execução no Godot 4.5.

# V0.1.61 — Danos ambientais e iluminação avariada

- Acrescentadas marcas de impacto e queimadura em superfícies.
- Adicionado painel de teto caído e fragmentos de vidro.
- Adicionado cabo solto junto à parede.
- Adicionada luminária fundida, com energia luminosa a zero.
- Adicionada luminária intermitente e painel emissivo sincronizado com a falha.

Verificação realizada: inspeção estática do código e integridade do arquivo ZIP. O jogo não foi executado no Godot 4.5, portanto a aparência em runtime continua por confirmar.

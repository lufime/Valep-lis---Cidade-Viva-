# Relatório V0.1.81 — Acesso às salas laterais

## Alteração aplicada
- Corrigida a geometria da parede direita nas zonas 03–10.
- As duas aberturas da parede principal ficam agora alinhadas com os vãos das salas auxiliares A e B.
- Adicionada uma faixa luminosa discreta no piso à entrada de cada zona para ajudar a reconhecer a transição.

## Causa identificada
A parede direita deixava uma abertura centrada no eixo da zona, mas as entradas das salas auxiliares estavam centradas aproximadamente 3,125 m para a frente e para trás. A parede bloqueava a passagem, apesar de as salas e os seus equipamentos serem criados no código.

## Conteúdo das salas
O projeto já inclui catálogos de salas e equipamento visual específico por zona (por exemplo, amostras e análise, geradores e baterias, enfermaria/farmácia, oficina/armazém, contenção, vigilância e arquivo).

## Limites de validação
- ZIP verificado quanto à integridade.
- Alteração verificada por inspeção estática do código.
- Não foi possível executar o projeto no Godot 4.5 neste ambiente; por isso, não declaro compilação, exploração 3D nem exportação Android aprovadas.
- As zonas 01 e 02 usam geometria própria e necessitam de validação separada no jogo; esta alteração corrige os vãos das zonas 03–10.

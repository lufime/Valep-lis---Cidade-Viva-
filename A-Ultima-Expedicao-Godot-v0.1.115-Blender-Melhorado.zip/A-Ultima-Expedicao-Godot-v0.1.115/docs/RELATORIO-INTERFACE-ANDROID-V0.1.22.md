# A Última Expedição — correções da interface Android (V0.1.22)

## Alterações aplicadas
- Ações móveis reposicionadas com margens inferiores e laterais de segurança.
- Botão de agachamento usa texto curto para evitar corte em ecrãs estreitos.
- O texto do botão alterna entre **AGACHAR** e **LEVANTAR** conforme o estado da personagem.
- Mantidos os botões de interação e lanterna, o joystick, o painel de confronto, o minimapa e os controlos LAN.
- Não foram alteradas as regras da criatura controlada pela IA nem a identidade secreta do traidor.

## Validação
- O ZIP de origem foi extraído e a estrutura do projeto foi inspecionada.
- Não foi possível executar testes no motor Godot neste ambiente; compilação, execução em Android e rede LAN continuam por validar.

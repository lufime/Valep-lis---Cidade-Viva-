# V0.1.86 — Clareza visual e iluminação

## Alterações
- Aumentada a iluminação ambiente global de 0.72 para 1.05.
- Reduzida a densidade da névoa de 0.0055 para 0.0035 e afastado o início da névoa.
- Reforçada a luz de preenchimento global e o seu alcance.
- Aumentados moderadamente o alcance, energia e ângulo da lanterna para melhorar a leitura de salas e objetos.

## Limites
Estas alterações são ajustes estáticos no código. O ZIP foi verificado quanto à integridade, mas não foi possível executar o projeto no Godot 4.5, validar visualmente em dispositivo Android nem testar o desempenho/efeito de sombras.

# Relatório — V0.1.95 Auditoria lógica e validação de interações

## Problemas corrigidos nesta passagem

1. **Recolha remota de provas:** antes, a chamada remota aceitava um identificador válido sem confirmar a distância ao objeto. Agora, o servidor identifica o jogador e a prova e exige proximidade física de até 3,2 unidades antes de registar a recolha.
2. **Combinação VANTHIS:** a validação agora exige que o jogador esteja a até 4 unidades da consola, além de manter a exigência das dez provas e do código correto.
3. **Porta do arquivo confidencial:** a abertura agora exige proximidade física de até 4 unidades, dez provas e síntese validada.
4. **Conclusão da missão:** no multijogador, a conclusão é recusada no cliente e decidida pela autoridade do servidor.
5. **Versão:** atualizados os ficheiros de versão e o README para V0.1.95.

## Verificações

- Auditoria estática do projeto: executada; resultado registado no teste `quality_audit.py`.
- Integridade do ZIP: verificada após criação.
- **Não executado:** análise/compilação do GDScript pelo Godot 4.5, jogo real, movimento e colisões no dispositivo, rede multijogador real e exportação APK. O binário Godot não está disponível neste ambiente.

## Limites desta auditoria

Esta versão corrige validações concretas nas interações e na autoridade da missão, mas não constitui certificação de toda a lógica do jogo. A navegação da criatura, acessos físicos, sincronização em rede e coerência narrativa precisam de validação dentro do Godot 4.5.

# Relatório V0.1.34 — pistas para localizar a sala secreta

- A porta da sala secreta e a consola VANTHIS começam ocultas e sem colisão/interação.
- As provas passam a revelar progressivamente a localização: ao reunir 3 provas surge uma referência à parede falsa a oeste da Zona 10; com 6 provas, uma referência à consola junto da passagem selada.
- Ao recolher as 10 provas, a localização é revelada e a porta e a consola tornam-se visíveis e interativas.
- Só depois de localizar a consola se pode introduzir a combinação de quatro algarismos. A combinação correta continua a ser 4826, inferida a partir de quatro documentos.
- Depois de validar o código, é necessário interagir com a porta para entrar.

Validação efetuada: integridade do ZIP e inspeção textual das alterações. Não foi possível executar o projeto no motor Godot nesta sessão; a compilação GDScript e o comportamento em jogo/multijogador continuam por validar.

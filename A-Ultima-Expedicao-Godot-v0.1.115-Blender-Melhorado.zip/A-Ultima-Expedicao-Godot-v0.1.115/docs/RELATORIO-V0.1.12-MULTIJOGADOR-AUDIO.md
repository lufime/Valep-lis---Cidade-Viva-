# A Última Expedição — v0.1.12

## Alterações aplicadas
- Servidor ENet configurado para aceitar até 7 clientes além do anfitrião (máximo teórico de 8 jogadores).
- Efeitos de passos, lanterna, roupa e respiração emitidos através de AudioStreamPlayer3D, com atenuação espacial por distância e posicionamento 3D.
- Eventos sonoros permitidos são validados no servidor antes de serem retransmitidos aos restantes clientes.
- Deteção aproximada de superfície pelos nomes dos colliders: neve (predefinição), gelo, pedra, metal e interior; pitch/volume varia por superfície e por passo.
- Passos e respiração usam variação moderada de pitch/intervalo para reduzir repetição mecânica.

## Limitações e validação
- O projeto usa os ficheiros de som já existentes; não foram criadas gravações novas de passos específicos para cada material. A diferenciação atual usa pitch e volume sobre o som de passo existente.
- A deteção de superfície depende dos nomes dos colliders; para classificar cada zona com precisão, os colliders do cenário devem ter nomes ou grupos consistentes.
- Não foi possível executar testes no motor Godot nesta sessão; por isso, a compilação, exportação Android, rede real entre dispositivos e mistura de áudio ainda precisam de validação no Godot. Não declarar esta versão como testada/aprovada.

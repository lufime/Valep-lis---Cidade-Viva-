# A Última Expedição — v0.1.10

## Integração visual
- Adicionadas `art/intro_estacao_vespera.png` e `art/menu_estacao_vespera.png` como fundos de ecrã completos.
- Intro continua a usar a barra de progresso real de 0 a 100% durante 4 segundos.
- Menu mantém os botões e páginas gerados por Godot, incluindo WLAN, som, vídeo, regras e sair.
- Camadas escuras semitransparentes preservam a legibilidade e os controlos permanecem elementos nativos interativos.

## Validação
- Confirmada a presença de `project.godot`, cena principal e script de expedição.
- Verificada a existência dos dois PNG e referências `res://art/...` no script.
- Não foi possível executar validação no motor Godot nesta sessão porque o executável Godot não está instalado. É necessária validação no editor/exportação Android.

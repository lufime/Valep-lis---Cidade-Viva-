# A Última Expedição — 8 variantes visuais de jogadores 3D

## Implementação
- O modelo-base 3D de expedição é carregado de `scenes/PlayerExpeditionSurvivor.tscn`.
- Os avatares remotos recebem uma variante estável calculada a partir do ID de rede (`peer_id`), sem alterar a sincronização de posição/rotação.
- Existem oito paletas distintas de fato, capacete e mochila e pequenas diferenças de escala para facilitar a identificação visual dos colegas.
- A seleção é determinística: o mesmo ID de jogador recebe a mesma variante durante a sessão.
- O jogador local continua em primeira pessoa; esta integração afeta os avatares remotos.

## Limites conhecidos
Estas são oito variantes visuais do modelo-base, não oito malhas humanas modeladas de raiz. A geometria e o equipamento-base são partilhados; as diferenças atuais são sobretudo cores e escala. O modelo continua estático, sem esqueleto deformável/animações de caminhada. A validação em Godot 4.5 e em rede ainda tem de ser executada num ambiente com Godot instalado; não declarar o teste como aprovado antes disso.

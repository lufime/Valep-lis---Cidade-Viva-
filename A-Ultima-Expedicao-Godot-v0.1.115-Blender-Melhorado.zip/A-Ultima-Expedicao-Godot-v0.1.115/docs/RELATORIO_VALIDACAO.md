# Relatório de validação estática — v0.1.8

## Correções feitas após inspeção do v0.1.7
- Corrigida a string multilinha inválida do texto de controlo tátil, que impedia a análise sintática GDScript.
- Adicionado ao HUD um painel recolhível “REDE LAN” para criar/entrar numa sessão; os métodos de rede existiam mas não havia botões/campo IP visíveis. O painel está ancorado à direita para melhor adaptação a ecrãs estreitos.
- Agachar agora altera a altura e a posição da cápsula de colisão, além da altura da câmara e da velocidade.
- O texto de interação distingue relés cooperativos da porta.
- README e versão atualizados para documentar o estado real e os testes pendentes.

## Verificações executadas
- Estrutura de pastas e recursos do projeto inspecionados.
- Referências `res://` do projeto e cenas inspecionadas manualmente.
- Funções duplicadas não detetadas por análise textual.
- Arquivo ZIP verificado com `unzip -t`.
- Verificação estática de aspas/string multilinha e contagem de blocos feita por script auxiliar.

## Limitações que permanecem
- O executável Godot 4.5 não está instalado neste ambiente; não foi possível importar, compilar ou executar o projeto.
- Não foi possível validar a sintaxe completa do GDScript por meio do parser oficial do Godot.
- Rede LAN, RPCs, firewall, dois dispositivos e exportação Android continuam sem teste em runtime.
- A entidade continua a executar IA local por instância; a sua posição/estado não são autoritativamente sincronizados pelo servidor.
- A votação resolve após dois votos, não é um sistema de votação completa de toda a equipa.
- Os relés estão em pontos separados, mas não existe validação de distância/linha de visão no servidor para as interações.
- O cenário e a entidade usam geometria procedural simples; não são modelos 3D finais realistas.
- Ainda não existe sistema de dano, captura, inventário completo, extração funcional ou missão com começo/fim completos.

## Resultado honesto
ZIP íntegro e correções estáticas aplicadas. **Não classificar como aprovado para lançamento** até executar o projeto no Godot 4.5, corrigir todos os erros reportados pelo motor e concluir testes LAN e Android.

# V0.1.36 — Desbloqueio da porta oculta e da consola

- No início, porta e consola estão invisíveis e com colisões desativadas.
- Ao reunir as 10 provas, apenas a consola é revelada e ativada.
- A porta permanece oculta e bloqueada enquanto a combinação não for validada.
- A combinação correta revela e ativa a porta; a interação seguinte abre o acesso.
- A validação é comunicada aos clientes multiplayer por RPC.

Validação efetuada neste pacote: integridade do ZIP e inspeção textual das alterações. O executável Godot não estava disponível; não foi possível confirmar compilação GDScript nem comportamento em runtime.

# Correção v0.1.21 — erros de parsing no arranque

## Erros identificados no log do GitHub Actions
- `scripts/expedition.gd:499-501`: `_entity_sync_accumulator` não declarado.
- `scripts/expedition.gd:500`: `ENTITY_SYNC_INTERVAL` não declarado.

## Alterações
- Declarado `_entity_sync_accumulator` com valor inicial `0.0`.
- Declarado `ENTITY_SYNC_INTERVAL` com intervalo de sincronização de `0.08` segundos, alinhado com o acumulador de sincronização local já existente.

## Limitações de validação
Esta correção é baseada nos erros explícitos do log fornecido. O Godot não foi executado neste ambiente; é necessário executar o workflow para confirmar se existem outros erros de parsing ou runtime. A criação de um APK, por si só, não prova que a cena inicia corretamente.

# Relatório v0.1.14 — IA autoritativa e atribuição de papéis

## Alterações
- O anfitrião/servidor é a única autoridade que executa a lógica da criatura.
- A posição, visibilidade, estado de IA, waypoint e texto de reação são replicados para clientes a cada 100 ms.
- A IA escolhe o alvo mais próximo entre o anfitrião e avatares remotos conhecidos pelo servidor.
- Clientes pedem ao anfitrião o estado inicial da sessão e recebem o estado atual da criatura e o seu próprio papel privado.
- O anfitrião envia o papel individual por RPC privado, nunca por broadcast.

## Limitações e validação
- O ambiente de execução desta preparação não tem o executável Godot disponível; por isso, não foi possível executar importação, análise de scripts pelo motor, exportação APK nem testes com dois dispositivos reais.
- A sincronização de posição dos jogadores continua a depender do sistema de estados existente; a IA só pode escolher alvos cujos avatares remotos já sejam conhecidos do servidor.
- A atribuição escolhe o traidor quando o primeiro cliente entra; recomenda-se iniciar a partida apenas depois de todos os jogadores terem entrado. Jogadores que entrem depois recebem o papel atribuído, sem reeleição.
- A atribuição de papel é funcionalmente privada por RPC, mas ainda deve ser submetida a testes de segurança de rede e desconexão/religação.

## Testes estáticos executados
- Verificação de que a lógica da IA tem guarda `multiplayer.is_server()`.
- Verificação de existência de RPCs de estado da criatura e de pedido de estado inicial.
- Verificação de que a distribuição de papéis usa `rpc_id` para cada destinatário.
- Verificação de consistência do ZIP e presença dos ficheiros essenciais.

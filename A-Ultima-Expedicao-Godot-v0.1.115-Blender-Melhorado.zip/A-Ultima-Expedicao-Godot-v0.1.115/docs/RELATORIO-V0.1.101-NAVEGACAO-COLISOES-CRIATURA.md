# Relatório V0.1.101 — Movimento físico e colisões da criatura

## Base analisada
- ZIP de entrada: `A-Ultima-Expedicao-Godot-v0.1.100-SINCRONIZACAO-PORTAS.zip`.
- A pasta interna do ZIP identifica-se como V0.1.99, mas os ficheiros de versão e o relatório de sincronização das portas indicam V0.1.100. Para evitar substituir silenciosamente a base, a nova entrega é identificada como V0.1.101.

## Problema identificado
A criatura era criada como `Node3D` e a sua cápsula de colisão ficava dentro de um `StaticBody3D` separado. A posição era atualizada diretamente com `global_position.move_toward(...)`. Esse movimento não passa pelo solver físico do motor e, por isso, podia atravessar paredes, portas fechadas e limites colidíveis.

## Correção aplicada
- A presença da criatura passa a ser um `CharacterBody3D`.
- A cápsula de colisão passa a ser filha direta do corpo móvel.
- Camada e máscara de colisão são definidas para a camada física padrão (1), usada pela geometria física criada pelo projeto.
- O movimento normal de patrulha/perseguição usa velocidade e `move_and_slide()`, deixando o motor resolver contactos físicos.
- Mantida a autoridade da IA no servidor, os estados, velocidades de patrulha/perseguição, deteção, captura, regras de abrigo e mecânica de desaparecimento observada.
- Acrescentadas verificações estáticas de regressão para o corpo físico e a ligação da forma de colisão.

## Resultados reais dos testes
- Antes da alteração: `tests/quality_audit.py` — **79 verificações estáticas PASS**.
- Depois da alteração: `tests/quality_audit.py` — **81 verificações estáticas PASS, 0 FAIL**.
- Integridade ZIP: verificada depois de criar o pacote.
- Godot 4.5: não disponível neste ambiente; não foi possível executar compilação/importação GDScript, simulação física real, testes de navegação no cenário nem multijogador com dois clientes.

## Limitações conhecidas
Esta correção impede o movimento normal da criatura de atravessar corpos físicos colidíveis; não acrescenta um `NavigationRegion3D`/navmesh nem um algoritmo de desvio de obstáculos. Se uma parede bloquear a linha direta até ao alvo, a criatura pode ficar encostada ao obstáculo em vez de encontrar autonomamente uma rota alternativa. O teste real de portas abertas/fechadas e dos limites da estação continua pendente no Godot 4.5. A mecânica existente de desaparecimento e reaparecimento da criatura mantém reposicionamentos intencionais enquanto invisível.

## Ficheiros alterados
- `scripts/expedition.gd`
- `scripts/VERSION.txt`
- `VERSION.txt`
- `tests/quality_audit.py`
- `docs/RELATORIO-V0.1.101-NAVEGACAO-COLISOES-CRIATURA.md` (este relatório)

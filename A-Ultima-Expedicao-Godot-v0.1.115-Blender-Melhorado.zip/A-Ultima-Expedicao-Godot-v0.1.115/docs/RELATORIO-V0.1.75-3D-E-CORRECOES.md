# V0.1.75 — melhoria visual 3D e correção do arranque

## Alterações aplicadas
- Removida a segunda declaração de `client_mission_completed()` em `scripts/expedition.gd`, que causava erro fatal de parsing no arranque. Mantida a versão que atualiza o estado da extração.
- Corrigido `scaling_3d/mode` de FSR1 para bilinear, compatível com o renderizador Mobile selecionado. O log anterior repetia `FSR1 is only available when using the Forward+ renderer`.
- Exterior enriquecido com silhuetas de gelo facetado e sinalética industrial de orientação, usando malhas simples para limitar o custo no Android.
- Piso da sala principal enriquecido com juntas de placas, grelhas e ranhuras decorativas sem colisão, para não bloquear movimento.
- Atualizado o caminho de exportação Android para V0.1.75.

## Verificações realizadas
- ZIP de origem: 108 entradas, teste de integridade sem erros.
- Correção do nome de função duplicado confirmada por pesquisa textual.
- Configuração Mobile já existente preservada; modo de escala incompatível removido.
- Não foi possível confirmar compilação, renderização real, FPS ou funcionamento no telemóvel: o executável Godot não está instalado neste ambiente. O workflow anexado deverá executar os testes do motor.

# A Última Expedição — V0.1.30
## Salas auxiliares variadas por zona

### Alterações
- As 20 salas adicionais já não repetem a mesma designação genérica.
- Cada uma das 10 zonas recebe duas salas com nomes e funções específicas.
- Foram adicionados elementos geométricos de cenário diferenciados, por exemplo cacifos térmicos, maca, armários de amostras, bancadas laboratoriais, ferramentas, baterias, estantes de arquivo, consola de segurança e caixas de evacuação.
- Mantidas as 10 zonas principais e a estrutura do jogo.

### Limitações de validação
- ZIP testado estruturalmente.
- Não foi possível executar o projeto no motor Godot nesta sessão; colisões, alinhamento das portas e aparência 3D precisam de validação no motor.
- Os elementos são cenário procedural. A interação funcional com armários, consolas, amostras e caixas não faz parte desta alteração.

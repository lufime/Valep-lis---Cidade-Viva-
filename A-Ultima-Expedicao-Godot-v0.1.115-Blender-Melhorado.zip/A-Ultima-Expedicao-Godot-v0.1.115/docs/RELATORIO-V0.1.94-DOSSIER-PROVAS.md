# V0.1.94 — Dossier interativo de provas

## Implementação
- Adicionado o botão `DOSSIÊ / COMPARAR PROVAS` ao HUD da expedição.
- O painel apresenta apenas as provas registadas em `experiment_clues_found`.
- Permite selecionar duas provas recolhidas e comparar descrições, contexto temporal, próximo passo e relações investigativas possíveis.
- As relações são apresentadas como hipóteses/contradições, não como prova automática da identidade do traidor.
- A lista é atualizada quando o progresso das provas muda.
- A comparação não expõe papéis secretos nem informações privadas de outros jogadores.

## Verificações executadas
- `tests/quality_audit.py`: PASS, 48 verificações estáticas.
- Integridade do ZIP: a validar na criação do pacote.

## Limitações
- Não existe executável Godot 4.5 disponível neste ambiente. Não foi possível validar a análise sintática do GDScript pelo motor, executar a cena, testar o HUD em ecrã real, nem validar uma sessão multijogador.
- A correspondência entre as dez provas e os dados do dossier foi ligada ao estado `experiment_clues_found`; os textos de contexto devem ser confirmados no teste de jogo para assegurar que correspondem à narrativa final.

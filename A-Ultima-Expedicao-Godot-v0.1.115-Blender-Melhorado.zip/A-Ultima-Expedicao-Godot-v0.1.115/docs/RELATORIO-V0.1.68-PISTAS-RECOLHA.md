# V0.1.68 — Correção da recolha de provas/pistas

- Adicionado grupo `collectible_evidence` às dez provas.
- O botão INTERAGIR procura a prova mais próxima num raio de 4,8 m quando o raio da câmara não encontra um objeto interativo.
- O HUD mostra uma indicação explícita quando uma prova está ao alcance.
- A recolha remove o objeto do mundo local para não parecer que a prova continua por apanhar.
- Mantida a via de recolha autoritativa do servidor e a sincronização existente.

## Limitação de validação
Foi feita inspeção e verificação estática dos ficheiros e da estrutura ZIP. O motor Godot não está instalado neste ambiente; a execução dentro do jogo ainda precisa de ser validada no workflow Godot 4.5.

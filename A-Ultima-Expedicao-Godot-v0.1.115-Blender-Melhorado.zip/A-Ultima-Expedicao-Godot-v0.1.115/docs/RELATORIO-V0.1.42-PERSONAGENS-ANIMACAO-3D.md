# Relatório V0.1.42 — Personagens e criatura 3D

## Alterações
- Criado `scripts/procedural_model_animator.gd`, um animador procedural leve sem assets externos.
- Movimento de braços/pernas no jogador baseado na velocidade horizontal.
- Animação de repouso e silhueta discreta para o traidor.
- Animação assimétrica da criatura, com intensidade diferente durante patrulha e caça.
- Detalhes faciais adicionais: sobrancelhas, ponte nasal e respirador.
- A IA continua a controlar a criatura; não é atribuído controlo ao jogador.

## Limites conhecidos
- Os modelos são construídos a partir de primitivas 3D. A animação é procedural, não usa esqueleto/rig profissional nem captura de movimento.
- Não foi possível executar Godot 4.5 neste ambiente. A compilação e a visualização em jogo precisam de ser verificadas no workflow do GitHub ou no motor.
- Este relatório não declara a APK nem o gameplay como aprovados.

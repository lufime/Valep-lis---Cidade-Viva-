# Jogador humano 3D — A Última Expedição

Adicionado um modelo 3D base de jogador em `assets/player_expedition_survivor.glb`, com fato de expedição polar, capacete com viseira, mochila, rádio, arnês refletor, luvas e botas. A cena reutilizável Godot está em `scenes/PlayerExpeditionSurvivor.tscn`.

O script `blender/build_player_expedition_survivor.py` reconstrói a geometria no Blender e cria um armature de referência, exportando GLB. O armature é um esqueleto inicial: a geometria não está ainda ligada por pesos de skinning para animações deformáveis. O GLB que acompanha o ZIP é um modelo estático composto por peças.

**Não validado:** execução em Godot, escala no jogo, animações, skinning, integração com o controlador de jogador e sincronização multiplayer. O modelo está adicionado como recurso/cena reutilizável, sem substituir automaticamente o sistema atual de jogadores.


## Integração no avatar remoto

A função `_make_remote_avatar()` em `scripts/expedition.gd` instancia agora `scenes/PlayerExpeditionSurvivor.tscn` para representar visualmente os jogadores remotos. A raiz do avatar continua a ser o nó que recebe a posição e rotação sincronizadas pela lógica de rede existente. O jogador local permanece em primeira pessoa e não recebe um corpo visível para evitar que a câmara fique dentro do modelo.

**Limitação ainda existente:** o modelo é estático; não tem skinning funcional nem animações de caminhada/corrida. A sincronização visual em runtime e a exportação Android precisam de ser executadas no Godot 4.5 antes de se poder declarar a integração aprovada.

# A Última Expedição — Melhorias Blender v0.1.115

## Objetivo

Uniformizar a geração dos recursos 3D, preservar fontes editáveis `.blend` e exportar modelos `.glb` para uso no Godot. O Blender é ferramenta de autoria; o jogo utiliza os modelos exportados.

## Alterações

- Exterior polar: passa a guardar `assets/polar_station_exterior.blend` e exportar o respetivo `.glb` na pasta `assets/`.
- Jogador de expedição: passa a guardar a fonte `.blend` e exportar GLB com as opções de skins/animações ativadas. O modelo base mantém peças rígidas; isto não substitui a versão rigada.
- Jogador rigado: saída normalizada para `assets/player_expedition_rigged.blend` e `.glb`.
- Criatura: as peças de malha são associadas a grupos de vértices e a um modificador Armature por osso correspondente; são criadas ações `Idle`, `Walk` e `Attack`.
- Workflow `blender-full-assets.yml`: executa cada script num processo Blender separado, verifica a sintaxe, confirma a estrutura GLB, reabre os `.blend` e publica os recursos/logs como artefacto.

## Saídas esperadas do workflow

- `assets/polar_station_exterior.blend` e `.glb`
- `assets/station_interior_modular.blend` e `.glb`
- `assets/creature_entity.blend` e `assets/entity_creature.glb`
- `assets/player_expedition_survivor.blend` e `.glb`
- `assets/player_expedition_rigged.blend` e `.glb`

## Limites e validação

O workflow tem de ser executado no GitHub Actions para confirmar a compatibilidade com a versão Blender instalada no runner. A verificação estrutural do GLB e a reabertura de `.blend` não garantem, por si só, a qualidade visual, deformação perfeita, importação Godot ou sincronização multijogador. Essas validações são etapas separadas.

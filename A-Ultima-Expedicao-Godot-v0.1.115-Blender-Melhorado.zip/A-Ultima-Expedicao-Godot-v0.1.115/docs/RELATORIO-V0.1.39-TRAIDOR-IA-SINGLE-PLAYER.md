# Relatório V0.1.39 — Traidor IA no Single Player

## Alteração
O modo individual tem agora um traidor controlado por IA, separado da criatura. O traidor não é apresentado como personagem identificado nem tem o seu papel anunciado na interface pública.

## Comportamento implementado
- Ativa apenas quando não existe peer de rede e a criatura já está ativa.
- Em intervalos variáveis, provoca uma perturbação temporária do sistema de alarme.
- Apresenta mensagens de registos/energia/comunicações sem credenciais válidas.
- Pode ser visto como uma silhueta distante durante cerca de dois segundos, sem identificação.
- A IA da criatura mantém o seu próprio estado e ciclo.

## Limites
Não foram executados testes dentro do Godot 4.5 neste ambiente. A aparência da silhueta, a temporização e a interação com todos os finais devem ser validadas em execução. O sistema atual representa uma primeira implementação funcional do papel narrativo; não simula ainda todas as sabotagens complexas ou objetivos dinâmicos da VANTHIS.

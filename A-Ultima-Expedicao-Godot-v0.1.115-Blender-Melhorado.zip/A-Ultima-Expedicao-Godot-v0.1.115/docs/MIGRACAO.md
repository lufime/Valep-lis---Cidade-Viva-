# Migração para v0.1.8

Base: protótipo v0.1.7 Furtividade Cooperativa.

Correções: string de ajuda tátil corrigida; painel LAN visível adicionado; agachamento altera colisão; mensagens de interação dos relés melhoradas.

Validação: inspeção estática e teste de integridade ZIP. Godot 4.5, rede real e exportação Android não foram executados neste ambiente. Consultar `RELATORIO_VALIDACAO.md`.

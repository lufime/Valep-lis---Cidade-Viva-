# A Última Expedição — Interface integrada V0.1.25

## Alterações nesta revisão
- Centro de missão acessível no HUD com separadores Objetivos, Inventário, Equipa e Dossiê.
- Objetivos ligados ao estado real dos relés A/B e à condição cooperativa existente; não são marcados como concluídos sem estado correspondente.
- Inventário descreve o equipamento/controlos realmente existentes e declara explicitamente que a versão ainda não tem objetos físicos recolhíveis ligados a inventário.
- Estado de equipa apresenta participantes na sessão e estado dos relés sem expor os papéis secretos de outros participantes.
- Dossiê apresenta a pista privada do participante local, sem a transformar em informação pública.
- Comunicação rápida cooperativa com três mensagens predefinidas através da sessão LAN.
- Menu de pausa com retoma, que pausa a simulação e preserva a sessão de rede.
- Mantidos os controlos Android existentes: joystick, olhar por arrasto, interagir, lanterna e agachar/levantar.

## Limites de validação
A revisão foi feita estaticamente sobre os scripts e cenas do projeto. Não foi possível executar o editor/runtime Godot neste ambiente; portanto, não se declara compilação Godot, teste em telemóvel nem sessão LAN real aprovados. O inventário físico continua informativo e não finge que há recolha de objetos implementada.

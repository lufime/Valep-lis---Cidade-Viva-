# A Última Expedição — pacote Blender v0.1.114

Este pacote inclui fontes/scripts para criar recursos 3D editáveis no Blender e exportá-los para o Godot.

## Como gerar (Blender 4.x)
1. Extrair o ZIP completo.
2. Abrir Blender > Scripting > Open e executar cada script em `blender/`.
3. Os scripts guardam os `.blend` em `assets/` e exportam os `.glb` correspondentes.
4. Abrir o projeto no Godot 4.5 e deixar o importador processar os GLB.

Scripts adicionados nesta versão:
- `build_creature_entity.py`: cria criatura, fonte Blender e GLB. O esqueleto é base de rig, não uma animação validada nem uma malha deformável.
- `build_station_interior.py`: cria kit interior modular, fonte Blender e GLB.
- `build_polar_station_exterior.py`: existente; cria exterior e GLB.
- `build_rigged_animated_players.py`: existente; tenta gerar rig/animações e variantes de jogador.

## Estado honesto da validação
O ambiente de preparação não tem Blender nem Godot instalados. Os scripts novos foram incluídos no ZIP, mas não foram executados aqui. Por isso, os `.blend` gerados pelos scripts ainda não estão presentes como resultados confirmados e o funcionamento no Godot não está validado. A presença de um armature sem pesos de deformação não equivale a um personagem totalmente rigado.

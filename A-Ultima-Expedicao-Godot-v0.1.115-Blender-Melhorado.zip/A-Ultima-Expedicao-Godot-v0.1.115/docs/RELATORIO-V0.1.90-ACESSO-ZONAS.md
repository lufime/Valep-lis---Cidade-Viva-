# V0.1.90 — Correção de acesso às zonas

## Alterações
- Alargadas as aberturas das entradas/saídas das zonas 02–10 de 3,0 m para 4,4 m.
- Alargados os corredores de ligação de 3,0 m para 4,4 m e reposicionadas as molduras.
- Folhas deslizantes decorativas recolhidas para fora da passagem e sem colisão física, para não bloquear o jogador.
- Mantida a geometria das salas e restantes sistemas fora das passagens.

## Validação
- Alterações de texto/script verificadas estaticamente.
- Integridade do ZIP será verificada na embalagem.
- Não foi possível executar o projeto no Godot 4.5 neste ambiente; a passagem real em jogo continua a exigir teste no motor/dispositivo.

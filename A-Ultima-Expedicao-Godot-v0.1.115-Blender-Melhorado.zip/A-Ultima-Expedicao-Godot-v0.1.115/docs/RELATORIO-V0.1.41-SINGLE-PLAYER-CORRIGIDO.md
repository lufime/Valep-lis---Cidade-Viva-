# Relatório V0.1.41 — Correção do Single Player

## Problema identificado
A partida local herdava bloqueios de cooperação: a ativação dos relés era recusada sem sessão LAN, a porta dependia de dois IDs diferentes e as decisões exigiam uma sessão com outro participante. Isso impedia o jogador individual de concluir todos os objetivos.

## Alterações
- O modo local encaminha a interação de ambos os relés para o jogador local (ID 1).
- A condição de conclusão no modo individual exige ambos os relés ativos, mas não dois IDs distintos.
- A validação de proximidade de cada relé continua ativa; o jogador tem de se deslocar entre as estações.
- A porta da câmara é desbloqueada através do estado partilhado dos relés.
- A decisão narrativa aceita uma escolha local e resolve imediatamente, mantendo a votação online para sessões cooperativas.
- O painel de objetivos distingue o modo individual do cooperativo e apresenta as provas, a combinação e a passagem secreta como objetivos de campanha.
- As sincronizações RPC de estado foram protegidas para não serem chamadas no modo local.

## Verificações feitas
- Confirmada a existência das funções e ramos modificados.
- Confirmada a presença das condições para ativar os dois relés em modo local e para decisão individual.
- ZIP final validado com `ZipFile.testzip()`.

## Limites conhecidos
Godot 4.5 não está disponível neste ambiente. Não foi possível executar a cena, verificar erros de parser GDScript, testar a distância real dos relés, percorrer a missão ou exportar/testar uma APK. O multijogador online não foi intencionalmente convertido em modo solo: mantém o requisito de participantes diferentes.

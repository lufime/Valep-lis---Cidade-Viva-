# V0.1.77 — Sistema de captura e sobrevivência

## Implementado no código
- A IA do servidor inicia a captura quando a criatura alcança o alvo a menos de 1,15 m.
- O jogador capturado deixa de se mover e vê uma interface com botão de esforço.
- O jogador tem 5 segundos para fazer 8 pressões; sucesso liberta-o e a criatura retoma a perseguição.
- Falha elimina o jogador localmente e regista a eliminação no servidor; os restantes jogadores continuam.
- A captura, progresso e resultado são enviados por RPC fiável ao cliente visado.
- O sistema não permite matar a criatura.

## Limitações / testes pendentes
- A compilação e execução do Godot não foram realizadas neste ambiente porque o executável Godot não está instalado.
- Ainda é necessário testar em Godot 4.5: parsing, captura solo, host/cliente, desconexão durante captura, UI Android e estado pós-eliminação.
- A interface de eliminação informa o jogador, mas a câmara de espectador ainda não está implementada nesta versão.
- Distrações por objetos e resgate ativo por colegas continuam como próximos passos, não são declarados implementados.

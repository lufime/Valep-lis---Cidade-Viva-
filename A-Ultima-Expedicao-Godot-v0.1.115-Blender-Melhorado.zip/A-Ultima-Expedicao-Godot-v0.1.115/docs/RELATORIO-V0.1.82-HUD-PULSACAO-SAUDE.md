# V0.1.82 — HUD de pulsação e saúde

## Implementado
- Painel permanente no HUD com barra de pulsação (BPM), barra de saúde (%) e estado textual.
- A pulsação responde ao movimento, exposição ao exterior, saúde reduzida e captura.
- A saúde começa a diminuir após 30 segundos contínuos no exterior; regressar ao interior abranda a exposição e permite recuperação gradual.
- Painel ancorado no canto superior direito e com fundo translúcido para leitura em ecrãs móveis.
- Os valores são locais ao jogador, evitando mostrar no HUD do jogador A o estado fisiológico do jogador B.

## Validação
- ZIP e estrutura de ficheiros verificados.
- Foram feitas verificações estáticas dos nomes dos nós e referências do HUD.
- Não foi possível executar Godot 4.5 nesta sessão; compilação, teste em execução, multijogador e exportação Android continuam por validar.

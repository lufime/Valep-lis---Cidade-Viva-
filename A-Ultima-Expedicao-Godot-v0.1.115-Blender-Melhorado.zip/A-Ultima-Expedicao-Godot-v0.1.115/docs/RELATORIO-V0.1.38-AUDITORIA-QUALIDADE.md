# V0.1.38 — Auditoria de qualidade

## Alterações
- Corrigida a instrução de abertura do projeto no README: a pasta real é a raiz extraída que contém `project.godot`.
- Atualizado o caminho da APK de exportação para `build/A-Ultima-Expedicao-v0.1.38-android.apk`.
- Adicionado `tests/quality_audit.py`, que verifica ficheiros essenciais, referências literais `res://` e invariantes centrais da missão/autoridade de rede.
- Adicionado `.github/workflows/quality.yml`, que corre a auditoria, importa o projeto com Godot 4.5 e tenta arrancar a cena em modo headless.

## Limites
A auditoria estática não prova que o jogo é divertido, que todos os RPCs funcionam, que a criatura é visualmente sincronizada sem falhas, que a sessão aguenta desconexões, nem que a APK exporta. Essas etapas dependem de o workflow correr com sucesso e de testes em dispositivos reais.

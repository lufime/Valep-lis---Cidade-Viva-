# A Última Expedição — V0.1.29
## 10 zonas com várias salas

### Alterações no código
- Mantidas as 10 zonas narrativas da estação polar.
- Cada zona recebe duas salas laterais adicionais, além da sala principal: 3 salas físicas por zona.
- Total planeado no mapa: 30 salas (10 salas principais + 20 salas laterais).
- As salas laterais têm piso, teto, paredes, abertura de acesso, letreiro e iluminação próprios.
- A alteração é procedural e foi adicionada ao construtor da cena existente, sem substituir os sistemas de jogador, áudio, rede ou IA.

### Distribuição narrativa
01 — Entrada e preparação; salas anexas de equipamento e apoio.
02 — Investigação; salas anexas de amostras e análise.
03 — Manutenção; ferramentas e peças.
04 — Laboratório; preparação de amostras e análise.
05 — Central elétrica; controlo e baterias.
06 — Contenção; observação e antecâmara.
07 — Arquivo subterrâneo; arquivo físico e sala de registos.
08 — Segurança; monitorização e armamento de emergência.
09 — Núcleo da entidade; observação e controlo.
10 — Extração final; preparação de evacuação e armazenamento de emergência.

### Estado da validação
- O ZIP foi criado e a sua integridade será verificada.
- O Godot não está disponível neste ambiente, por isso não foi possível confirmar a execução 3D, colisões ou circulação no motor.
- A distribuição é geométrica/procedural; objetivos e puzzles individuais por sala não estão implementados nesta alteração.

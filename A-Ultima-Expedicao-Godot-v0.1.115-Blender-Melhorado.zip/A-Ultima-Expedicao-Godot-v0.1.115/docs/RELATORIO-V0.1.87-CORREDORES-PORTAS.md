# V0.1.87 — Corredores interiores e portas entre zonas

## Alterações
- Acrescentado teto aos corredores de ligação entre módulos.
- Acrescentadas molduras de porta nas duas extremidades de cada corredor.
- Acrescentadas folhas de porta deslizante recolhidas lateralmente, mantendo a passagem central livre para circulação.
- Mantidas as coordenadas e a geometria base das 10 zonas.

## Verificação
- Verificado que o bloco de construção dos corredores contém os novos elementos.
- ZIP testado quanto à integridade.
- Não foi possível executar o projeto no Godot 4.5 neste ambiente; colisões, navegação da criatura e aspeto visual precisam de teste no jogo.

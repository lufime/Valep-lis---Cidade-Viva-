# V0.1.57 — minimapa e controlos móveis

- Minimapa aumentado de 168×160 para 300×270 unidades de interface e reposicionado a meio da lateral direita.
- Joystick converte as coordenadas do toque global para coordenadas locais do controlo.
- Joystick repõe o vetor de movimento ao perder foco, para evitar movimento preso após interrupções do Android.

## Validação
- Alterações estáticas aplicadas aos scripts do projeto.
- O arquivo ZIP será verificado estruturalmente.
- Não foi possível confirmar execução no Godot 4.5 nem exportação APK nesta sessão; esses testes permanecem pendentes.

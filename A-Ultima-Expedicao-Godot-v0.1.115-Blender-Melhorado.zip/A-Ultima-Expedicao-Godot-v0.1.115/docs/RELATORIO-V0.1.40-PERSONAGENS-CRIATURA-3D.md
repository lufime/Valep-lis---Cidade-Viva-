# Relatório V0.1.40 — Personagens e criatura 3D

## Alterações
- O equipamento humano procedural foi detalhado com proteção de ombros/joelhos, sola de botas, cinto, fivela, depósitos de oxigénio e distintivo.
- A criatura deixou de reutilizar diretamente o modelo humano de explorador. Tem silhueta alongada e assimétrica, caixa torácica externa, placas, crânio angular, olhos emissivos, braços alongados, garras e espigões dorsais.
- As peças usam primitivas nativas de Godot, mantendo o modelo gerado em runtime e sem assets externos.

## Verificações efetuadas
- ZIP de origem extraído sem erros.
- Alteração aplicada ao script principal `scripts/expedition.gd`.
- Verificação estática de marcadores das novas funções e ausência da chamada antiga que sobrepunha os olhos da criatura.
- ZIP final validado com `ZipFile.testzip()`.

## Limitações
Godot 4.5 não está disponível neste ambiente. A compilação GDScript, renderização real, colisões, silhueta em movimento, desempenho em Android e animações não foram confirmados em runtime. Os modelos são procedurais de qualidade estilizada; não são modelos artísticos externos de alta resolução nem têm rigging completo.

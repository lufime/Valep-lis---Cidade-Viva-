# Recursos Blender — A Última Expedição v0.1.107

## Recursos integrados

- `assets/station_corridor_kit.glb`: modelo binário utilizado pelo Godot.
- `assets/station_corridor_kit.blend`: ficheiro de projeto Blender editável, importado a partir do GLB.

O `.blend` foi gerado por Blender 4.0.2 a partir do GLB do projeto. O registo da execução de CI incluído em `docs/blender-validation/` documenta a importação de 61 objetos (60 malhas), 6 materiais, a reabertura do `.blend`, e a gravação de uma cópia validada. Esta validação refere-se ao kit modular da estação; não significa que todos os elementos 3D do jogo tenham ficheiros `.blend` próprios.

## Regenerar/validar no GitHub Actions

O workflow `blender-assets.yml` instala Blender, reimporta o GLB, gera um `.blend`, reabre-o e verifica a estrutura do GLB. O artefacto final contém o projeto completo com o `.blend` e o `.glb`.

## Limites

A inclusão do `.blend` não prova, por si só, que o modelo esteja instanciado corretamente em todas as cenas Godot nem valida o jogo em Android. Isso exige uma execução Godot/runtime e teste no dispositivo.

## Criatura 3D integrada

- `assets/entity_creature.glb`: modelo visual 3D leve da criatura, com silhueta alongada, costelas, espinhos e olhos luminosos. O Godot carrega este recurso durante a partida; a IA, navegação e colisão continuam no `CharacterBody3D`. O modelo original procedural permanece como fallback.
- O GLB é um formato de intercâmbio compatível com Blender/Godot; o Blender não é necessário no telemóvel nem no runtime.

# Relatório de alterações — v0.1.9

## Implementado
- Introdução de 4 segundos em `CanvasLayer`, acima do menu, com progresso temporizado de 0 a 100%.
- Menu principal com nova paleta azul-petróleo/dourado e botões com estados visuais de foco, hover e pressão.
- Modelos humanoides procedurais compostos por tronco, colete refletor, faixa refletora, braços, luvas, pernas, botas e mochila. O avatar remoto e a entidade têm cabeça; o avatar local omite a cabeça para não tapar a câmara em primeira pessoa.
- Indentação de `heat_phase += delta` corrigida em `scripts/mini_map.gd`.
- Nome da APK atualizado para v0.1.9 e filtro do workflow corrigido para o caminho real `build-android.yml`.

## Limitações conhecidas
- Os modelos são geométricos/procedurais e não têm esqueleto, animações de caminhada ou expressões faciais avançadas.
- A introdução progride com o tempo decorrido (4 s); não representa o progresso real de carregamento dos recursos.
- Não foi possível executar o Godot 4.5 neste ambiente. A compilação e a execução em Android permanecem por validar.

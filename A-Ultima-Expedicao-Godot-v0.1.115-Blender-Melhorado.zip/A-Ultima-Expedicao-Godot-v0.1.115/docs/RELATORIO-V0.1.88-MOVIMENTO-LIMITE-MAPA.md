# V0.1.88 — Recuperação de movimento em bloqueios

- Adicionado detetor de bloqueio quando existe input de movimento mas o jogador não se desloca durante 1,25 s no chão.
- Ao detetar bloqueio, o controlador repõe a última posição recente em que houve movimento e mostra feedback no prompt.
- A intenção é evitar bloqueio permanente em colisões/limites, permitindo ao jogador regressar pelo corredor.

## Verificação
- Código do controlador alterado e incluído no ZIP.
- ZIP validado quanto à integridade.
- O projeto não foi executado no Godot 4.5 neste ambiente; é necessário testar limites, portas, multiplayer e comportamento normal de movimento.

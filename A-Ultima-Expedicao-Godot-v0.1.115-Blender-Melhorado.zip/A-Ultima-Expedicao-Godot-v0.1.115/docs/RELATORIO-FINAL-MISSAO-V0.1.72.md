# V0.1.72 — Conclusão formal da missão

## Implementação
- Adicionado terminal físico de transmissão/extração na câmara confidencial.
- A missão só termina se os relés A e B estiverem ativos, a energia estiver restabelecida, as dez provas tiverem sido recolhidas, a combinação VANTHIS estiver validada e o arquivo secreto estiver aberto.
- A interação é validada por proximidade no servidor em multijogador; em modo individual o jogador pode concluir tudo sozinho.
- Se faltarem tarefas, o terminal mostra explicitamente os requisitos pendentes.
- Ao concluir, aparece um ecrã inequívoco de MISSÃO CONCLUÍDA com resumo e opção de continuar a explorar.

## Validação
- ZIP reaberto e reconstruído após as alterações.
- Foram feitas verificações estáticas de presença de funções, script de interação, condição de vitória e texto de encerramento.
- O motor Godot 4.5 não está instalado neste ambiente; compilação/runtime e teste multijogador real continuam por executar.

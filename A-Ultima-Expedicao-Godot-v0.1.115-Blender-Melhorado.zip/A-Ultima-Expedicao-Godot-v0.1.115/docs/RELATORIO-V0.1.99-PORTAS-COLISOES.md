# Relatório V0.1.99 — Portas e colisões

## Alterações feitas

- As portas deslizantes deixam de saltar instantaneamente entre posições: usam um Tween com duração configurável (`move_duration`, por omissão 0,42 s).
- A animação move o `StaticBody3D` da porta, mantendo a folha e a respetiva `CollisionShape3D` no mesmo corpo físico durante o movimento.
- A abertura manual e a abertura desencadeada pelo puzzle cooperativo passam pela mesma função, evitando comportamentos de movimento diferentes.
- A procura da expedição percorre os nós ancestrais. Assim, portas colocadas dentro de subnós (por exemplo, corredores exteriores) conseguem localizar os métodos de feedback e som no nó da expedição.
- Se a porta for acionada durante uma animação, o Tween anterior é cancelado antes de iniciar o movimento para o novo destino.

## Validação

- Foram adicionadas quatro verificações estáticas específicas para a implementação das portas e uma verificação de versão.
- O teste estático confirma a presença das estruturas esperadas no código; não prova a execução física no motor.
- Não foi possível executar o projeto no Godot nesta sessão porque o executável Godot não está disponível. A abertura, a colisão durante a animação e a sincronização em multijogador continuam a precisar de teste real no Godot.
- Esta alteração não resolve ainda a sincronização de estado das portas entre clientes em multijogador; não se declara essa parte aprovada.

# V0.1.64 — Remodelação gráfica Android

## Alterações no projeto
- Renderizador do projeto alterado para **Godot Mobile**, apropriado para Android moderno.
- Iluminação ambiente derivada do céu e luz direcional polar ajustada.
- Névoa atmosférica moderada para profundidade no exterior, sem nevoeiro volumétrico.
- Bloom/glow discreto para LEDs, indicadores e alarmes.
- Detalhe adicional no interior: painéis de serviço, juntas, fixações metálicas, faixas de segurança e grelha de ventilação.
- Montes de neve arredondados adicionados para reduzir o aspeto excessivamente geométrico do exterior.
- Caminho de exportação Android atualizado para V0.1.64.

## Limites e validação
- Alterações aplicadas aos ficheiros reais do projeto.
- A auditoria estática do projeto e a integridade do ZIP devem ser executadas antes da entrega.
- Não foi possível executar o jogo nem exportar APK sem o executável Godot disponível. A renderização, o desempenho no Android e a compatibilidade real do renderer Mobile continuam por validar no dispositivo.
- Não foram adicionados modelos externos nem texturas fotográficas; o detalhe novo é procedural e leve para preservar o desempenho móvel.

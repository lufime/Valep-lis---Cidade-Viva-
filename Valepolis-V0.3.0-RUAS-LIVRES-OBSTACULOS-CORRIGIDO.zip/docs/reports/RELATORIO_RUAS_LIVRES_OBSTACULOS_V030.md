# Valepólis V0.3.0 — Correção inicial de corredores rodoviários

## Alteração aplicada
- `systems/city_3d.gd`: acrescentada reserva geométrica para eixos viários globais e ruas locais.
- O gerador de edifícios ignora posições dentro dos corredores reservados.
- Árvores, árvores de parques e veículos ambientais não são colocados quando a posição intersecta os corredores reservados.

## Limites
Esta alteração reduz obstáculos criados por estes geradores junto às vias principais e aos eixos locais. Não prova ausência total de colisões: as ligações inter-bairros, instalações registadas, marcos, geometria do terreno, passeios e pontes ainda precisam de validação no Godot em runtime. O projeto não foi executado neste ambiente; não declarar PRE-FLIGHT aprovado até correr os testes reais.

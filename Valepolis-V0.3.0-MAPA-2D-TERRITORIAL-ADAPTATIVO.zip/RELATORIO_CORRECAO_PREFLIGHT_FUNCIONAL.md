# Correção do PRE-FLIGHT funcional — Valepólis V0.3.0

## Evidência dos logs
A execução anterior imprime `RESULTADO=FUNCTIONAL_UI_PASS`, mas o workflow marca FAIL porque o log contém `SCRIPT ERROR`:
`Invalid assignment of property or key 'mouse_filter' ... on ... Polygon2D` em `main.gd` durante `_v030_setup_2d_map`.

## Correção aplicada
- Removida a atribuição inválida de `mouse_filter` ao `Polygon2D`.
- Ajustada a sincronização do tamanho do viewport para respeitar o `SubViewportContainer` quando `stretch` está ativo, evitando a tentativa de redimensionamento manual que gerava aviso.

## Limitações
- Não foi possível executar o Godot nesta sessão. Esta é uma correção estática baseada no log fornecido.
- O PRE-FLIGHT e a exportação APK têm de ser executados novamente no GitHub Actions.
- Os mapas antigos continuam desativados conforme a versão de base; não foi criado um mapa novo.

# Valepólis V0.3.0 — Auditoria e calibração de densidades e escalas

## Resultado
- População total preservada: 1.000.000 habitantes.
- Bairros preservados: 25.
- Área territorial dos polígonos virtuais: %.4f km².
- Margens exteriores/água declaradas: %.4f km².
- Área total declarada: %.4f km².
- Densidade média recalculada: %d hab./km².
- Áreas e densidades de `populacao_por_bairro_v030.json` sincronizadas com as áreas da matriz territorial.
- Alvos de densidade na matriz recalibrados para `população aprovada ÷ área do polígono virtual`. Não foram alteradas as populações por bairro.

## Incompatibilidade de escala identificada
`limites_bairros_v030.json` declara uma envolvente de 24,802 × 23,224 km sobre coordenadas de mundo de aproximadamente 105 × 98,322 unidades, ou seja, cerca de 0,236206 km/unidade. Já `systems/city_3d.gd` usa dimensões de ruas, praças, edifícios e deslocamentos em unidades pequenas e trata os centros dos bairros como coordenadas de uma cena esquemática. Se a conversão territorial for aplicada literalmente aos tamanhos dos objetos, uma estrada com largura 4,2 unidades equivaleria a aproximadamente 991 m. Portanto, a conversão territorial NÃO pode ser considerada escala métrica validada do cenário 3D.

## Decisão segura nesta calibração
- Manter os centros e os 25 polígonos existentes.
- Manter a população aprovada por bairro.
- Reconciliar matematicamente as áreas e densidades entre os dois ficheiros de dados.
- Assinalar explicitamente que a escala visual 3D permanece esquemática e carece de validação no Godot.
- Não ampliar os nós 3D nem multiplicar posições automaticamente: isso ampliaria também estradas, edifícios, agentes e relevo, podendo criar outra incompatibilidade.

## Limitações / testes pendentes
- Não foi possível executar o motor Godot nesta sessão.
- Não se declara o mapa 3D ou a APK aprovados.
- Continuam pendentes teste visual de zoom/camadas, sobreposição de edifícios, continuidade das estradas, relevo, rios/costa e leitura dos nomes dos 25 bairros em runtime.
- A geometria é virtual/proposta, não levantamento GIS real.

## Resumo por bairro
| Bairro | População preservada | Área calibrada (km²) | Densidade calibrada (hab./km²) |
|---|---:|---:|---:|
| Nexora | 80.000 | 25.6500 | 3119 |
| Altavira | 48.000 | 30.7644 | 1560 |
| Rivéria | 54.000 | 23.7793 | 2271 |
| Marévia | 45.000 | 19.1663 | 2348 |
| Montélia | 30.000 | 50.4426 | 595 |
| Lúmora | 42.000 | 7.9393 | 5290 |
| Florávia | 38.000 | 15.6230 | 2432 |
| Pedrália | 32.000 | 6.5327 | 4898 |
| Valeora | 48.000 | 11.6901 | 4106 |
| Brisamar | 43.000 | 34.5967 | 1243 |
| Fontélia | 35.000 | 17.7701 | 1970 |
| Silvéria | 40.000 | 10.5724 | 3783 |
| Portávia | 36.000 | 19.7359 | 1824 |
| Lacéria | 39.000 | 20.7133 | 1883 |
| Ventúria | 25.000 | 26.0271 | 961 |
| Olivéria | 34.000 | 14.8977 | 2282 |
| Ribeora | 44.000 | 22.1413 | 1987 |
| Solária | 50.000 | 34.3535 | 1455 |
| Avelora | 35.000 | 5.2330 | 6688 |
| Terrávia | 38.000 | 12.4799 | 3045 |
| Altória | 28.000 | 13.9890 | 2002 |
| Marivora | 39.000 | 18.3178 | 2129 |
| Verdelis | 37.000 | 8.1490 | 4540 |
| Estúria | 32.000 | 31.4992 | 1016 |
| Pedravora | 28.000 | 20.0762 | 1395 |

## Ficheiros alterados
- `data/limites_bairros_v030.json` — nota explícita sobre o limite da conversão territorial.
- `data/matriz_territorial_densidade_v030.json` — densidades-alvo alinhadas com população e áreas dos polígonos.
- `data/populacao_por_bairro_v030.json` — áreas e densidades sincronizadas com a matriz.
- `RELATORIO_AUDITORIA_ESCALAS_DENSIDADES_V030.md` — este relatório.

Nenhum ficheiro de interface, `main.gd`, cena, workflow ou regra operacional foi alterado.

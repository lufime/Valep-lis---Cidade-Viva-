# Mapa 2D territorial adaptativo — Valepólis V0.3.0

- O painel MAPA passa a instanciar `systems/territorial_map_2d.gd`.
- O novo desenho lê `data/limites_bairros_v030.json` e representa os polígonos dos 25 bairros.
- O mapa adapta-se ao tamanho do painel com escala uniforme para evitar deformação.
- O marcador do jogador é desenhado no centro da vista; a função `set_player_world_position(x, z)` permite ligar a posição real da simulação.
- O ZIP passou na verificação de integridade.

Limitações: não foi executado o motor Godot nem a APK nesta sessão. A ligação automática da posição real do jogador ao novo renderer ainda deve ser confirmada/integrada caso o estado do jogador não esteja disponível na chamada de setup. Zoom/arrasto também carecem de teste no dispositivo.

extends Control
## Mapa territorial 2D procedural, baseado nos limites oficiais virtuais V0.3.0.
## A vista acompanha o jogador: o jogador fica no centro e o mundo é transformado.
const DATA_PATH := "res://data/limites_bairros_v030.json"
const COLORS := [
    Color("#285844"), Color("#315f49"), Color("#37654c"), Color("#2d5943"),
    Color("#41694f"), Color("#345b46"), Color("#3c674b")
]
var neighborhoods: Array = []
var world_center := Vector2(-3.0, -3.0)
var zoom := 1.0
var world_bounds := Rect2(-52.5, -49.16, 105.0, 98.32)
var pan := Vector2.ZERO
var player_dot_radius := 7.0

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    _load_territory()
    resized.connect(queue_redraw)
    queue_redraw()

func _notification(what: int) -> void:
    if what == NOTIFICATION_RESIZED:
        queue_redraw()

func _load_territory() -> void:
    if not FileAccess.file_exists(DATA_PATH):
        push_warning("Dados territoriais V0.3.0 não encontrados: " + DATA_PATH)
        return
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(DATA_PATH))
    if not parsed is Dictionary:
        push_warning("JSON territorial inválido.")
        return
    var bounds: Dictionary = parsed.get("world_bounds_xz", {})
    if not bounds.is_empty():
        var min_x := float(bounds.get("min_x", -52.5))
        var max_x := float(bounds.get("max_x", 52.5))
        var min_z := float(bounds.get("min_z", -49.16))
        var max_z := float(bounds.get("max_z", 49.16))
        world_bounds = Rect2(min_x, min_z, max_x - min_x, max_z - min_z)
    neighborhoods = parsed.get("neighborhoods", [])

func set_player_world_position(x: float, z: float) -> void:
    world_center = Vector2(x, z)
    queue_redraw()

func set_zoom(value: float) -> void:
    zoom = clampf(value, 0.65, 3.5)
    queue_redraw()

func _world_to_screen(x: float, z: float, scale: float, center: Vector2) -> Vector2:
    return Vector2(size.x * 0.5, size.y * 0.5) + Vector2((x - center.x) * scale, (z - center.y) * scale)

func _draw() -> void:
    if size.x < 2.0 or size.y < 2.0:
        return
    draw_rect(Rect2(Vector2.ZERO, size), Color("#173d4b"), true)
    # Ajuste automático à largura e altura disponíveis, sem deformar os bairros.
    var margin := 12.0
    var scale_fit := minf((size.x - margin * 2.0) / maxf(world_bounds.size.x, 1.0),
                          (size.y - margin * 2.0) / maxf(world_bounds.size.y, 1.0))
    var scale := maxf(0.1, scale_fit) * zoom
    # Desenha polígonos do mundo relativos à posição do jogador.
    for i in range(neighborhoods.size()):
        var n: Dictionary = neighborhoods[i]
        var boundary: Array = n.get("boundary_xz", [])
        if boundary.size() < 3:
            continue
        var points := PackedVector2Array()
        for point in boundary:
            points.append(_world_to_screen(float(point.get("x", 0.0)), float(point.get("z", 0.0)), scale, world_center))
        draw_colored_polygon(points, COLORS[i % COLORS.size()])
        for j in range(points.size()):
            draw_line(points[j], points[(j + 1) % points.size()], Color("#9cb9a3", 0.68), 1.2, true)
        var c: Dictionary = n.get("center_xz", {})
        var label_pos := _world_to_screen(float(c.get("x", 0.0)), float(c.get("z", 0.0)), scale, world_center)
        var font := ThemeDB.fallback_font
        var font_size := int(clampf(size.x * 0.022, 10.0, 17.0))
        var label := str(n.get("name", "Bairro"))
        if label_pos.x > -80 and label_pos.x < size.x + 20 and label_pos.y > 0 and label_pos.y < size.y:
            draw_string(font, label_pos + Vector2(4, -4), label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color("#f0e7c4"))
    # Marcador do jogador sempre no centro do ecrã; só o mundo se desloca.
    var center_screen := size * 0.5
    draw_circle(center_screen, player_dot_radius + 3.0, Color(0.05, 0.09, 0.10, 0.75))
    draw_circle(center_screen, player_dot_radius, Color("#ffd43b"))
    draw_circle(center_screen, 2.5, Color("#26333a"))

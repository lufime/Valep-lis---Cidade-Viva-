# Valepólis V0.3.0 — Limpeza de mapas antigos

## Alterações
- Removido o script legado `systems/neighborhood_overview_map.gd`, responsável pelo desenho/interação do atlas antigo.
- Removida documentação de implementação dos mapas/atlas antigos para não os confundir com a nova implementação.
- Preservados os dados territoriais dos 25 bairros, incluindo `data/limites_bairros_v030.json`, população, economia e influências culturais.
- Preservados os restantes sistemas e a interface geral.
- As funções legadas em `main.gd` que podem ser chamadas por referências existentes continuam como stubs seguros sem criar mapas; não foram removidas cegamente para evitar quebrar chamadas.

## Limitações
Esta limpeza remove os componentes e documentação identificados como legados. A validação final exige executar o Godot/ PRE-FLIGHT para detetar referências indiretas e confirmar compilação. O novo mapa ainda não está implementado.

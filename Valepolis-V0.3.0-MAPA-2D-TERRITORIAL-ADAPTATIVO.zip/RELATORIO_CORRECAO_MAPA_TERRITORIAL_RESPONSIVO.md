# Correção do mapa territorial responsivo — Valepólis V0.3.0

## Causa corrigida
O renderizador territorial era criado como filho de `UI/Map`, enquanto `MapBody` é uma superfície opaca que o podia cobrir. Isso explicava o painel vazio apesar de os dados territoriais existirem.

## Alterações
- O renderizador `TerritorialMap2D` passa a ser criado dentro de `UI/Map/MapBody`.
- O renderizador usa âncoras de retângulo completo, sem dimensões fixas, margens internas ou posição fixa.
- A camada do mapa tem z-index acima do fundo do painel.
- A escala inicial usa a dimensão útil real do display e ajusta largura/altura mantendo a proporção do território.
- O jogador continua representado no centro do mapa, com o território transformado relativamente à posição de mundo.

## Validação
- ZIP verificado estruturalmente.
- Não foi possível executar Godot/Android nesta sessão; o PRE-FLIGHT deve confirmar sintaxe, renderização e responsividade.

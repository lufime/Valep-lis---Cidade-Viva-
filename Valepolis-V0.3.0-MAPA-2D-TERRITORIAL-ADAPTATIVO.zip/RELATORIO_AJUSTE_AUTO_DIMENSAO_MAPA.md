# Ajuste automático da área do mapa — Valepólis V0.3.0

## Alterações
- A altura do painel MAPA é agora calculada pelo espaço disponível entre navegação e contexto, sem impor um mínimo de 360 px que podia ultrapassar o ecrã.
- O painel ativa `clip_contents` para impedir que conteúdo ultrapasse os limites.
- Após cada cálculo de layout, o tamanho do SubViewport é sincronizado de forma deferred com as dimensões efetivas do container.
- A largura continua calculada pela largura útil do display, com margens responsivas.

## Limitações
- A alteração foi verificada estaticamente no código e o ZIP passou no teste de integridade.
- Não foi executado o motor Godot nem uma APK nesta sessão. Confirmar orientação vertical/horizontal e diferentes resoluções no PRE-FLIGHT/Android.

# Limpeza do painel MAPA — Valepólis V0.3.0

## Objetivo
Impedir a criação dos marcadores de locais/NPC e dos elementos cartográficos antigos no arranque.

## Alterações
- Removidas do arranque as chamadas para `_create_map_location_buttons()`, `_v030_create_neighborhood_overlay()`, `_v030_build_geography()`, `_create_npc_markers()` e `_v030_create_map_zoom_controls()`.
- O painel limpo oculta os filhos visuais existentes e remove nós residuais `NPC_`, `Location_` e `Geo_`.
- O marcador do jogador e a respetiva etiqueta ficam ocultos.
- Mantidos os dados dos locais, NPC, bairros e a lógica de simulação; só foi desativada a criação visual no mapa.

## Validação
- O ZIP foi validado com `ZipFile.testzip()`.
- A análise/compilação Godot e o teste Android não foram executados neste ambiente.
- O mapa ficará sem elementos até à nova implementação territorial 2D.

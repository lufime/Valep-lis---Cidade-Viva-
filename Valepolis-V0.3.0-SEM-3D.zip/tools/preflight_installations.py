#!/usr/bin/env python3
"""Static Pre-Flight for the Valepólis V0.3.0 proposed installation registry."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
failures = []
passes = []

def check(condition, message):
    (passes if condition else failures).append(message)

def read_json(relative):
    path = ROOT / relative
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        failures.append(f"JSON inválido: {relative}: {exc}")
        return {}

# Validate all project JSON files for parseability.
json_paths = list(ROOT.rglob("*.json"))
for path in json_paths:
    try:
        json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        failures.append(f"JSON inválido: {path.relative_to(ROOT)}: {exc}")
check(not any(x.startswith("JSON inválido:") for x in failures), f"JSON parseáveis ({len(json_paths)} ficheiros)")

registry = read_json("data/installation_registry_v030.json")
addresses = read_json("data/enderecamento_valepolis.json").get("addresses", [])
hoods = read_json("bairros_valepolis.json").get("neighborhoods", [])
ops = read_json("data/entity_operations_registry.json")
economy = read_json("data/economy_config.json")

rows = registry.get("installations", [])
ids = [row.get("installation_id") for row in rows]
address_ids = [row.get("address_id") for row in rows]
address_by_id = {row.get("id"): row for row in addresses}
check(len(rows) == 275, f"275 registos físicos propostos (encontrados {len(rows)})")
check(len(ids) == len(set(ids)) and all(ids), "IDs de instalação únicos e não vazios")
check(len(address_ids) == len(set(address_ids)) and all(address_ids), "IDs de morada únicos e não vazios")
check(all(aid in address_by_id for aid in address_ids), "Todas as moradas referenciam o registo de endereços")
check(all(row.get("neighborhood_name") == address_by_id.get(row.get("address_id"), {}).get("bairro") for row in rows), "Bairro da instalação coincide com o bairro da morada")
check(all(row.get("map_spawned") is False and row.get("building_id") is None for row in rows), "Nenhuma instalação foi criada no mapa; building_id por definir")
map_refs = [row.get("planned_map_object_id") for row in rows]
check(len(map_refs) == len(set(map_refs)) and all(map_refs), "Referências planeadas para objetos 3D únicas, sem criar objetos")
check(all(row.get("planned_map_object_class") and row.get("map_object_link_status") == "referencia_planeada_sem_objeto_3d_criado" for row in rows), "Classe e estado da ligação futura ao mapa registados")
check(all(row.get(field) is None for row in rows for field in ["staff_count", "vehicle_count", "inventory", "economy", "budget_eur", "balance_eur", "capacity", "opening_hours"]), "Efetivos, viaturas, inventário, economia, orçamento, saldo, capacidade e horários sem valores inventados")
check(len(registry.get("neighborhood_distribution", [])) == 25, "Distribuição contém os 25 bairros")
population = read_json("populacao_valepolis.json")
check(set(x.get("name") for x in population.get("neighborhoods", [])) == set(x.get("name") for x in hoods), "Configuração populacional coincide com os 25 bairros oficiais")
check(all(int(x.get("physical_installation_records", 0)) == 11 for x in registry.get("neighborhood_distribution", [])), "Distribuição de planeamento: 11 registos por bairro")
check(registry.get("count_summary", {}).get("tnur_standalone_installations") == 0, "TNUR não tem instalações independentes")
check(len([x for x in registry.get("embedded_units", []) if x.get("entity_id") == "TNUR"]) == 10, "10 centros TNUR integrados registados")
check(len([x for x in registry.get("embedded_units", []) if x.get("unit_type") == "unidade_policial_especializada_integrada"]) == 5, "5 unidades policiais especializadas integradas")
ids_set = set(ids)
check(all(x.get("host_installation_id") in ids_set for x in registry.get("embedded_units", [])), "Todas as unidades integradas têm instalação anfitriã válida")
check(all(x.get("standalone_installation") is False and x.get("counts_as_physical_location") is False for x in registry.get("embedded_units", [])), "Unidades integradas não duplicam locais físicos")
salary_catalog = read_json("data/salary_by_profession_proposal_v030.json")
tax_model = economy.get("tax_model", {})
check(salary_catalog.get("status") == "approved_gameplay_reference_rules" and len(salary_catalog.get("professions", [])) > 0, "Tabela salarial de referência aprovada presente")
check(tax_model.get("social_security_rate") == 0.11 and len(tax_model.get("irs_marginal_brackets", [])) == 5 and economy.get("status") == "approved_rules_values_pending", "Modelo fiscal aprovado presente; montantes operacionais pendentes")
check(all(economy.get(field) is None for field in ["prices", "revenue", "expenses", "budget", "balance", "credit", "subsidies"]), "Preços, stocks e transações continuam bloqueados enquanto faltam valores obrigatórios")

project_godot = (ROOT / "project.godot").read_text(encoding="utf-8")
main = (ROOT / "main.gd").read_text(encoding="utf-8")
check('ValepolisInstallations="*res://systems/valepolis_installation_registry.gd"' in project_godot, "Singleton do registo de instalações declarado")
check('"📍 INSTALAÇÕES", "Instalacoes"' in main, "Secção Instalações ligada à navegação de entidade")
check('ValepolisInstallations.get_installations_for_entity' in main and 'ValepolisInstallations.get_neighborhood_distribution' in main, "UI consulta registo real de instalações e distribuição")
check('$UI/Map.visible = false' in main and '$UI/Map.visible = true' in main, "Página substitui o mapa sem janela modal; navegação pode regressar ao mapa")
check('installation_ids' in json.dumps(ops, ensure_ascii=False), "Registo operacional referencia IDs de instalações")
check('installation_registry' in json.dumps(read_json("data/entity_master_catalog.json"), ensure_ascii=False), "Catálogo mestre referencia o registo de instalações")

for message in passes:
    print("PASS|" + message)
for message in failures:
    print("FAIL|" + message)
print(f"RESULT={'PASS' if not failures else 'FAIL'}|passes={len(passes)}|failures={len(failures)}")
sys.exit(0 if not failures else 1)

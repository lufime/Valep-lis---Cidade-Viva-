# Valepólis V0.3.0 — alteração do mapa para 2D

## Alteração aplicada
- A câmara do mapa passa para projeção ortográfica superior (vista de cima), com norte fixo para cima.
- A rotação da câmara fica desativada neste modo; o zoom e o foco de bairro continuam disponíveis através dos métodos existentes.
- Foram preservados o sistema 3D subjacente, as coordenadas e nomes dos 25 bairros, os dados territoriais e os restantes ficheiros do projeto. Esta alteração muda a apresentação da câmara para uma leitura cartográfica 2D; não converte toda a geometria do mundo em sprites 2D.

## Limite de validação
Não foi possível executar o Godot neste ambiente. É necessário executar o workflow PRE-FLIGHT/Android para validar a compilação e confirmar a apresentação no dispositivo. Não declarar APK aprovada até esses testes passarem.

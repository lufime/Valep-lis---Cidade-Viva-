# Valepólis V0.3.0 — Correções PRE-FLIGHT e workflow sem secrets

## Resultado de verificações estáticas

O `tools/preflight.sh` foi executado após as correções. Resultado: `RESULT=PASS`; sem falhas estáticas. Foram corrigidos os testes económicos que incorretamente exigiam `tax_model` nulo, apesar de as regras fiscais aprovadas estarem configuradas; os testes agora validam a tabela salarial de referência aprovada e mantêm bloqueadas transações sem preços, receitas, despesas, orçamento, saldo, crédito e subsídios configurados.

Também foram corrigidos erros no auditor de regras (expressão regular mal escapada e verificação demasiado restritiva dos sistemas económicos) e o workflow deixou de depender de GitHub Secrets para a APK de teste, usando chave temporária efémera. Foi removido o arranque do ADB, que não é necessário para exportar/validar uma APK sem dispositivo ligado.

## Limitação importante

A auditoria independente `tools/preflight.py` resulta em `INCOMPLETE`, com `TOTAL_PASS=21`, `TOTAL_FAIL=0`, `TOTAL_SKIP=3`, porque este ambiente não tem Godot 4.x instalado e não executou a importação Godot, os testes funcionais em runtime nem a exportação APK. A compilação e a execução real continuam por confirmar no GitHub Actions. Não declarar APK ou runtime como aprovados até o workflow completar todos os gates com `RESULTADO=PASS`, `TOTAL_FAIL=0` e `TOTAL_SKIP=0`.

## Saída completa do PRE-FLIGHT estático

```text
PASS|Estrutura V0.3.0
PASS|Android V0.3.0
PASS|Metadados ativos em V0.3.0
PASS|Funções/constantes sem duplicação
PASS|Sistemas principais V0.3.0 presentes
PASS|JSON parseáveis (81 ficheiros)
PASS|275 registos físicos propostos (encontrados 275)
PASS|IDs de instalação únicos e não vazios
PASS|IDs de morada únicos e não vazios
PASS|Todas as moradas referenciam o registo de endereços
PASS|Bairro da instalação coincide com o bairro da morada
PASS|Nenhuma instalação foi criada no mapa; building_id por definir
PASS|Referências planeadas para objetos 3D únicas, sem criar objetos
PASS|Classe e estado da ligação futura ao mapa registados
PASS|Efetivos, viaturas, inventário, economia, orçamento, saldo, capacidade e horários sem valores inventados
PASS|Distribuição contém os 25 bairros
PASS|Configuração populacional coincide com os 25 bairros oficiais
PASS|Distribuição de planeamento: 11 registos por bairro
PASS|TNUR não tem instalações independentes
PASS|10 centros TNUR integrados registados
PASS|5 unidades policiais especializadas integradas
PASS|Todas as unidades integradas têm instalação anfitriã válida
PASS|Unidades integradas não duplicam locais físicos
PASS|Tabela salarial de referência aprovada presente
PASS|Modelo fiscal aprovado presente; montantes operacionais pendentes
PASS|Preços, stocks e transações continuam bloqueados enquanto faltam valores obrigatórios
PASS|Singleton do registo de instalações declarado
PASS|Secção Instalações ligada à navegação de entidade
PASS|UI consulta registo real de instalações e distribuição
PASS|Página substitui o mapa sem janela modal; navegação pode regressar ao mapa
PASS|Registo operacional referencia IDs de instalações
PASS|Catálogo mestre referencia o registo de instalações
RESULT=PASS|passes=27|failures=0
PASS|25 bairros oficiais, nomes e ordem|encontrados=25
PASS|Fonte populacional marcada como aprovada|aprovado_pelo_utilizador_para_integracao
PASS|População aprovada totaliza 1.000.000|total=1000000
PASS|Distribuição aprovada cobre os 25 bairros
PASS|Configuração populacional de runtime coincide com fonte aprovada
PASS|Quotas populacionais correspondem à distribuição aprovada
PASS|Catálogo territorial coincide com população aprovada
PASS|Seis influências culturais e atribuições aprovadas
PASS|Dez identidades locais distintas
PASS|Não inventa atribuições dos dez bairros de identidade local
PASS|Perfis económicos cobrem exatamente os 25 bairros
PASS|Perfis económicos usam a população aprovada por bairro
PASS|Cada bairro tem setores, oferta potencial e fatores de procura
PASS|Runtime expõe registo e consulta da oferta/procura por bairro
PASS|Runtime carrega os perfis económicos dos bairros
PASS|Não altera preços automaticamente sem regra e valores configurados
PASS|Regras de mercado auditáveis presentes por bairro
PASS|Preços graduais e sem valores inventados
PASS|200 episódios sem duplicação
PASS|20 temporadas com 10 episódios cada
PASS|275 instalações permanecem propostas e não geram edifícios automaticamente
PASS|TNUR sem instalações independentes
PASS|Economia usa EUR e contabilidade em cêntimos
PASS|Modelo fiscal coincide com regras aprovadas|modelo={'social_security_rate': 0.11, 'irs_marginal_brackets': [{'up_to': 900, 'rate': 0.0}, {'up_to': 1500, 'rate': 0.05}, {'up_to': 2500, 'rate': 0.1}, {'up_to': 4000, 'rate': 0.18}, {'up_to': None, 'rate': 0.25}], 'consumption_tax_rates': {'essentials': 0.0, 'ordinary': 0.13, 'non_essential': 0.23}, 'property_tax_annual_range': [0.003, 0.008], 'profits_tax_rate': 0.15}
PASS|Fórmula de salário líquido aprovada
PASS|Saldo inicial corresponde a um mês de salário líquido
PASS|Sistemas económicos aprovados identificados
PASS|Regras fiscais aprovadas sem inventar salários-base/preços
PASS|Versão ativa V0.3.0 coerente
PASS|versionCode Android igual a 30000
PASS|Workflow chama o PRE-FLIGHT
PASS|Runner distingue INCOMPLETE de PASS
RULES_AUDIT=PASS|passes=32|failures=0
PASS|ponte principal presente
PASS|ponte secundária presente
PASS|pontes marcadas como travessias do rio
PASS|tabuleiro e rampas alinham nos extremos
PASS|largura do tabuleiro compatível com rampas
PASS|rampas nas duas margens
PASS|corredor regional conecta as pontes
PASS|Santo André do Vale ligado
PASS|Portela do Sul ligada
PASS|acessos a vilas/arredores
PASS|vias regionais identificadas
PASS|rotas regionais expostas para consulta
PASS|grafo regional inclui as duas cidades e as duas pontes
PASS|construção regional invocada no mapa
PASS|diagnóstico de rotas disponível
PASS|rotas evitam arestas rejeitadas pela heurística
PASS|diagnóstico identifica limitações da geometria
NOTE|Auditoria estrutural apenas; colisões geométricas e circulação exigem execução real no Godot.
RESULT=PASS_STATIC_ONLY
PASS|Referências literais res:// existentes (19 verificadas; em falta 0)
PASS|Sem nomes de função duplicados nos scripts GDScript
PASS|Versão do projeto e preset Android coerentes em V0.3.0
PASS|Cena principal e script ligados
PASS|Cena inicial sem saldo/data/necessidades fictícias visíveis
PASS|Cena inicial usa estado neutro até carregar a simulação
PASS|Autoload do registo de instalações configurado
PASS|Workflow prepara pasta de relatório antes do preflight
PASS|Workflow verifica SDK Manager e declara Android Build Tools
PASS|Workflow não depende de GitHub Secrets de assinatura
PASS|Workflow cria chave temporária apenas para APK de teste
PASS|Workflow mantém gates PRE-FLIGHT obrigatórios
PASS|Preset Android contém a opção de password da chave de release
PASS|Catálogo narrativo com 200 episódios únicos (200 encontrados)
PASS|20 temporadas com 10 episódios cada
PASS|Os 25 bairros coincidem entre catálogo e mapa 3D
PASS|Distribuição populacional usa exatamente os 25 bairros oficiais
PASS|As quotas populacionais somam 100%
PASS|Distribuição aprovada totaliza exatamente 1.000.000 habitantes
PASS|Distribuição aprovada tem exatamente os 25 bairros oficiais
PASS|populacao_valepolis.json coincide com a distribuição aprovada
PASS|bairros_valepolis.json coincide com a distribuição aprovada
PASS|Quotas populacionais correspondem às populações aprovadas
PASS|Tabela salarial de referência aprovada presente
PASS|Modelo fiscal aprovado presente
PASS|Transações continuam bloqueadas sem valores operacionais obrigatórios
PASS|Sem saldo, salário ou despesa de demonstração ativa no main.gd
PASS|UI financeira suporta campos por definir sem converter null em valores falsos
PASS|Runtime bloqueia transações quando a economia não está configurada
PASS|População detalhada preparada para 200 agentes com nomes fictícios únicos
PASS|Agentes sem rendimentos fictícios e sem capacidade residencial inventada
PASS|Registo canónico alinhado com 200 agentes e economia adiada
PASS|Missões só terminam por transição explícita com equipa e viatura registadas
PASS|Inventário de edifícios físicos não é fabricado antes da aprovação do mapa
PASS|Inventário não recebe stock automático fictício
PASS|Economia não gera receitas/despesas por fórmulas de demonstração
PASS|275 propostas de instalações sem criação automática no mapa
PASS|TNUR sem instalações independentes
PASS|Unidades integradas não duplicam locais físicos
PASS|Ligação 3D só consulta instalações explicitamente aprovadas
PASS|Mapa 3D não cria bases/serviços físicos não aprovados nem base TNUR independente
PASS|Sem funções/constantes/variáveis V0.2 ativas nos scripts
PASS|Sem painel PNG antigo do mapa
PASS|Sem painel PNG antigo da personagem
PASS|Interface sem referência à biblioteca PNG antiga de personagens
PASS|Perfil usa pré-visualização procedural 3D
PASS|Geometria da cidade consulta altura do relevo próprio
PROJECT_AUDIT=PASS|passes=47|failures=0
PASS|Auditoria estática de referências, sistemas e regras concluída
PASS|Registo de instalações validado estaticamente
PASS|Perfis arquitetónicos e requisitos culturais validados estaticamente
PASS|Sem funções/constantes/variáveis com prefixo V0.2 ativo.
RESULT=PASS

```

## Saída da auditoria independente

```text
VALEPÓLIS V0.3.0 — RELATÓRIO PRE-FLIGHT INDEPENDENTE
Data: 2026-10-11T16:15:22+00:00
Projeto: /mnt/data/valepolis_work
Ferramenta: preflight.py

RESULTADOS:
INFO|Projeto|/mnt/data/valepolis_work
PASS|Pasta do projeto existe|/mnt/data/valepolis_work
PASS|Ficheiro essencial: project.godot|project.godot
PASS|Ficheiro essencial: Main.tscn|Main.tscn
PASS|Ficheiro essencial: main.gd|main.gd
PASS|Ficheiro essencial: export_presets.cfg|export_presets.cfg
PASS|Versão ativa V0.3.0|project.godot
PASS|Cena principal declarada|res://Main.tscn
PASS|Script principal ligado à cena|Main.tscn
PASS|Preset Android existe|export_presets.cfg
PASS|Preset Android V0.3.0|export_presets.cfg
PASS|versionCode Android = 30000|export_presets.cfg
PASS|JSON válido (81 ficheiros)
PASS|Referências res:// (19 verificadas)
PASS|Sem funções/constantes duplicadas por script
PASS|Script da cidade 3D localizado|systems/city_3d.gd
PASS|Script da cidade contém rotina de integração de instalações|systems/city_3d.gd
PASS|25 bairros oficiais coincidem com o mapa 3D|catálogo=25; mapa=25
PASS|Tabela salarial de referência aprovada presente|profissões=800
PASS|Modelo fiscal aprovado presente|valida as taxas configuradas
PASS|Transações permanecem bloqueadas sem valores operacionais obrigatórios|campos de operação ainda pendentes
PASS|Auditoria estrutural da rede rodoviária regional|exit=0; log=regional-roads-audit.log
SKIP|Importação Godot headless|Godot 4.x não encontrado; validação de runtime não executada
SKIP|Teste funcional Godot|Godot 4.x não encontrado; teste funcional não executado
SKIP|Exportação APK Android|Godot não encontrado ou exportação não solicitada

TOTAL_PASS=21
TOTAL_FAIL=0
TOTAL_SKIP=3
RESULTADO=INCOMPLETE

Interpretação: PASS = verificações concluídas sem falhas; INCOMPLETE = não houve falhas estáticas, mas existem etapas não executadas; FAIL = pelo menos uma verificação falhou.
Logs: /tmp/valepolis-independent-audit/logs-20261011-161521

```

# Valepólis V0.3.0 — remoção do 3D

Alterações aplicadas nesta entrega:
- Removido o nó SubViewport 3D do mapa principal.
- Desativados os plugins de terreno 3D e estúdio 3D.
- Retirados os ficheiros de cena/runtime e plugins específicos de 3D do pacote.
- Impedida a inicialização automática de `City3D.tscn`.
- Substituídas as pré-visualizações 3D geradas em runtime por componentes 2D simples.
- Preservados os dados e sistemas de jogo que não dependem diretamente do renderizador 3D.

## Limites
Esta alteração remove o caminho de renderização 3D do projeto, mas ainda precisa de compilação e teste funcional no Godot 4.5 e na APK Android. O mapa 2D presente nesta base ainda precisa de validação visual e de testes de navegação; este relatório não declara esses testes aprovados.

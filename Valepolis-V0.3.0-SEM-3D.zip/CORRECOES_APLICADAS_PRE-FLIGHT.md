# Valepólis V0.3.0 — correções dirigidas ao PRE-FLIGHT

## Corrigido
1. `systems/valepolis_systems_runtime.gd`
   - Declaradas as propriedades de estado que eram usadas sem declaração: `neighborhood_economy`, `market_observations` e `market_audit`.
   - Os nomes e o comportamento já referenciado no runtime foram preservados.

2. `data/salary_by_profession_proposal_v030.csv`
   - Convertido o delimitador do ficheiro de `;` para `,`, formato esperado pelo importador CSV do Godot.
   - Validação estrutural: cabeçalho + 800 registos; 13 colunas em todas as 801 linhas; nenhum registo removido.

## Limitação de validação
Este ambiente não tem o executável Godot disponível. Por isso, estas correções foram verificadas estruturalmente, mas **não** foi possível executar a importação real, compilar todos os scripts nem gerar/testar a APK. O PRE-FLIGHT deve ser executado novamente no GitHub Actions/Godot para confirmar se existem erros seguintes.

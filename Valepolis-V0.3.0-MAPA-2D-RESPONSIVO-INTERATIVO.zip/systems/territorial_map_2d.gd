extends Control
## Mapa territorial 2D procedural, baseado nos limites oficiais virtuais V0.3.0.
## A vista acompanha o jogador: o jogador fica no centro e o mundo é transformado.
const DATA_PATH := "res://data/limites_bairros_v030.json"
const COLORS := [
    Color("#285844"), Color("#315f49"), Color("#37654c"), Color("#2d5943"),
    Color("#41694f"), Color("#345b46"), Color("#3c674b")
]
var neighborhoods: Array = []
var world_center := Vector2(-3.0, -3.0)
var zoom := 1.0
var world_bounds := Rect2(-52.5, -49.16, 105.0, 98.32)
var pan := Vector2.ZERO
var player_dot_radius := 7.0
var dragging := false
var drag_start := Vector2.ZERO
var pan_start := Vector2.ZERO
var touch_points: Dictionary = {}
var last_pinch_distance := 0.0

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP
    _load_territory()
    resized.connect(queue_redraw)
    queue_redraw()

func _notification(what: int) -> void:
    if what == NOTIFICATION_RESIZED:
        queue_redraw()

func _load_territory() -> void:
    if not FileAccess.file_exists(DATA_PATH):
        push_warning("Dados territoriais V0.3.0 não encontrados: " + DATA_PATH)
        return
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(DATA_PATH))
    if not parsed is Dictionary:
        push_warning("JSON territorial inválido.")
        return
    var bounds: Dictionary = parsed.get("world_bounds_xz", {})
    if not bounds.is_empty():
        var min_x := float(bounds.get("min_x", -52.5))
        var max_x := float(bounds.get("max_x", 52.5))
        var min_z := float(bounds.get("min_z", -49.16))
        var max_z := float(bounds.get("max_z", 49.16))
        world_bounds = Rect2(min_x, min_z, max_x - min_x, max_z - min_z)
    neighborhoods = parsed.get("neighborhoods", [])

func set_player_world_position(x: float, z: float) -> void:
    world_center = Vector2(x, z)
    queue_redraw()

func set_zoom(value: float) -> void:
    zoom = clampf(value, 0.65, 3.5)
    queue_redraw()

func _world_to_screen(x: float, z: float, scale: float, center: Vector2) -> Vector2:
    return Vector2(size.x * 0.5, size.y * 0.5) + pan + Vector2((x - center.x) * scale, (z - center.y) * scale)

func _draw() -> void:
    if size.x < 2.0 or size.y < 2.0:
        return
    draw_rect(Rect2(Vector2.ZERO, size), Color("#173d4b"), true)
    # Ajuste automático à largura e altura disponíveis, sem deformar os bairros.
    var margin := 12.0
    var scale_fit := minf((size.x - margin * 2.0) / maxf(world_bounds.size.x, 1.0),
                          (size.y - margin * 2.0) / maxf(world_bounds.size.y, 1.0))
    var scale := maxf(0.1, scale_fit) * zoom
    # Desenha polígonos do mundo relativos à posição do jogador.
    for i in range(neighborhoods.size()):
        var n: Dictionary = neighborhoods[i]
        var boundary: Array = n.get("boundary_xz", [])
        if boundary.size() < 3:
            continue
        var points := PackedVector2Array()
        for point in boundary:
            points.append(_world_to_screen(float(point.get("x", 0.0)), float(point.get("z", 0.0)), scale, world_center))
        draw_colored_polygon(points, COLORS[i % COLORS.size()])
        for j in range(points.size()):
            draw_line(points[j], points[(j + 1) % points.size()], Color("#9cb9a3", 0.68), 1.2, true)
        var c: Dictionary = n.get("center_xz", {})
        var cx := float(c.get("x", 0.0))
        var cz := float(c.get("z", 0.0))
        # Usar o centro territorial quando existe; se estiver fora do polígono,
        # usar o centro médio dos vértices para evitar etiquetas nos limites.
        if boundary.size() >= 3:
            var sx := 0.0
            var sz := 0.0
            for bp in boundary:
                sx += float(bp.get("x", 0.0))
                sz += float(bp.get("z", 0.0))
            var centroid := Vector2(sx / boundary.size(), sz / boundary.size())
            if c.is_empty():
                cx = centroid.x
                cz = centroid.y
        var label_pos := _world_to_screen(cx, cz, scale, world_center)
        var font := ThemeDB.fallback_font
        var font_size := clampi(int(size.x * 0.020), 10, 15)
        var label := str(n.get("name", "Bairro"))
        var label_width := font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x
        label_pos.x = clampf(label_pos.x - label_width * 0.5, 5.0, maxf(5.0, size.x - label_width - 5.0))
        label_pos.y = clampf(label_pos.y, font_size + 4.0, size.y - 5.0)
        if label_pos.x > -label_width and label_pos.x < size.x and label_pos.y > 0 and label_pos.y < size.y:
            draw_string(font, label_pos, label, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, Color("#f0e7c4"))
    # Marcador do jogador sempre no centro do ecrã; só o mundo se desloca.
    var center_screen := size * 0.5
    draw_circle(center_screen, player_dot_radius + 3.0, Color(0.05, 0.09, 0.10, 0.75))
    draw_circle(center_screen, player_dot_radius, Color("#ffd43b"))
    draw_circle(center_screen, 2.5, Color("#26333a"))


func _gui_input(event: InputEvent) -> void:
    if event is InputEventMouseButton:
        var mouse := event as InputEventMouseButton
        if mouse.button_index == MOUSE_BUTTON_WHEEL_UP and mouse.pressed:
            zoom = clampf(zoom * 1.15, 0.65, 3.5)
            queue_redraw()
            accept_event()
        elif mouse.button_index == MOUSE_BUTTON_WHEEL_DOWN and mouse.pressed:
            zoom = clampf(zoom / 1.15, 0.65, 3.5)
            queue_redraw()
            accept_event()
        elif mouse.button_index == MOUSE_BUTTON_LEFT:
            dragging = mouse.pressed
            drag_start = mouse.position
            pan_start = pan
            accept_event()
    elif event is InputEventMouseMotion and dragging:
        pan = pan_start + ((event as InputEventMouseMotion).position - drag_start)
        queue_redraw()
        accept_event()
    elif event is InputEventScreenTouch:
        var touch := event as InputEventScreenTouch
        if touch.pressed:
            touch_points[touch.index] = touch.position
            dragging = true
            drag_start = touch.position
            pan_start = pan
        else:
            touch_points.erase(touch.index)
            if touch_points.is_empty():
                dragging = false
                last_pinch_distance = 0.0
        accept_event()
    elif event is InputEventScreenDrag:
        var drag := event as InputEventScreenDrag
        touch_points[drag.index] = drag.position
        if touch_points.size() >= 2:
            var keys := touch_points.keys()
            var a: Vector2 = touch_points[keys[0]]
            var b: Vector2 = touch_points[keys[1]]
            var distance := a.distance_to(b)
            if last_pinch_distance > 0.0:
                zoom = clampf(zoom * (distance / last_pinch_distance), 0.65, 3.5)
            last_pinch_distance = distance
        else:
            pan = pan_start + (drag.position - drag_start)
        queue_redraw()
        accept_event()

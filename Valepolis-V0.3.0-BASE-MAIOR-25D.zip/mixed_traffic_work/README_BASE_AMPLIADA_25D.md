# Valepólis V0.3.0 — Base ampliada e visual 2.5D

## Alterações
- Terreno procedural ampliado de 256×256 para 320×320 unidades base.
- Resolução do terreno aumentada de 192 para 256 segmentos, para evitar que a ampliação reduza a qualidade geométrica.
- Câmara alterada para projeção ortográfica oblíqua (2.5D), mantendo modelos e terreno 3D.
- Zoom passa a ajustar a escala ortográfica e não depende de aproximar a câmara aos edifícios.
- Limite de zoom afastado para permitir uma vista geral maior.

## Limitações
A geometria urbana existente não foi automaticamente redesenhada nem redistribuída por todo o novo terreno. Esta alteração amplia a base e muda a apresentação para 2.5D; não equivale a uma escala geográfica real e precisa de inspeção no Godot, incluindo gestos, enquadramento, visibilidade de pontes/estradas e desempenho Android.

# Valepólis V0.3.0 — Remoção da imagem estática dos mapas

## Alteração
- Removida `images/mapa_25_bairros_isometrico.png` do projeto.
- Mantidos os dados territoriais, os 25 bairros, a população, os sistemas de simulação, a interface e os restantes recursos gráficos.
- Mantida `images/intro_valepolis.png`, por ser a imagem de introdução e não a imagem estática do mapa.
- Não foram alterados scripts, cenas ou workflow nesta operação.

## Nota
Esta alteração remove o ficheiro de imagem estática do mapa do pacote. Não garante, por si só, que o ecrã do mapa fique vazio ou que passe a gerar um mapa procedural: isso depende da cena e do código atualmente responsáveis pela apresentação do mapa. A execução no Godot/Android continua por testar.

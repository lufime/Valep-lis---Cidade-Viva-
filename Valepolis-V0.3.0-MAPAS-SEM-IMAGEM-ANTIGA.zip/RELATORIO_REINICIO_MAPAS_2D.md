# Valepólis V0.3.0 — Reinício visual dos mapas 2D

## Alterações
- Ocultados os elementos provisórios antigos (estradas retangulares, água retangular, casa/trabalho/comércio/hospital e marcador fixo).
- O painel base deixou de apresentar o grande fundo verde como mapa provisório.
- Mantido o atlas territorial 2D com os 25 polígonos e seleção por toque.
- Reduzida a tipografia do atlas em ecrãs estreitos e removido o título desenhado dentro da área do mapa para evitar duplicação.
- Mantidos os dados territoriais, populações, regras e sistemas de simulação.

## Estado
Esta é uma limpeza visual inicial para recomeçar a construção do mapa. Não é uma validação de execução Godot/Android. Zoom e arrasto do atlas ainda precisam de ser ligados e testados no motor.

extends Control

var status_label: Label
var detail_label: Label
var elapsed := 0.0
var boot_finished := false

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var background := ColorRect.new()
	background.color = Color(0.012, 0.022, 0.032, 1.0)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(background)
	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)
	var stack := VBoxContainer.new()
	stack.custom_minimum_size = Vector2(300, 0)
	stack.add_theme_constant_override("separation", 18)
	center.add_child(stack)
	var title := Label.new()
	title.text = "A ÚLTIMA EXPEDIÇÃO"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 25)
	title.add_theme_color_override("font_color", Color(0.95, 0.78, 0.48))
	stack.add_child(title)
	status_label = Label.new()
	status_label.text = "A INICIAR O JOGO…"
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	status_label.add_theme_font_size_override("font_size", 16)
	status_label.add_theme_color_override("font_color", Color(0.78, 0.88, 0.9))
	stack.add_child(status_label)
	var bar := ProgressBar.new()
	bar.custom_minimum_size = Vector2(0, 8)
	bar.show_percentage = false
	bar.value = 15
	stack.add_child(bar)
	detail_label = Label.new()
	detail_label.text = "A preparar a Estação Véspera"
	detail_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	detail_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	detail_label.add_theme_font_size_override("font_size", 12)
	detail_label.add_theme_color_override("font_color", Color(0.58, 0.68, 0.72))
	stack.add_child(detail_label)
	# Load after the boot screen has been drawn, so startup failures do not look like a silent black screen.
	call_deferred("_load_expedition")

func _load_expedition() -> void:
	await get_tree().process_frame
	status_label.text = "A CARREGAR CENÁRIO…"
	var packed := ResourceLoader.load("res://scenes/Expedition.tscn", "PackedScene") as PackedScene
	if packed == null:
		_show_failure("Não foi possível carregar Expedition.tscn. Verifica os recursos importados e os erros de compilação GDScript.")
		return
	var game := packed.instantiate()
	if game == null:
		_show_failure("O cenário foi encontrado, mas não foi possível criar a cena do jogo.")
		return
	game.name = "ExpeditionRuntime"
	add_child(game)
	# Expedition calls on_expedition_ready only after its initialization has completed.

func on_expedition_ready() -> void:
	boot_finished = true
	visible = false

func _process(delta: float) -> void:
	if boot_finished:
		return
	elapsed += delta
	if elapsed > 12.0 and status_label and status_label.text != "FALHA NO ARRANQUE":
		_show_failure("O jogo não confirmou a inicialização em 12 segundos. A camada de diagnóstico ficou visível em vez de esconder o erro num ecrã preto.")

func _show_failure(message: String) -> void:
	if status_label:
		status_label.text = "FALHA NO ARRANQUE"
		status_label.add_theme_color_override("font_color", Color(1.0, 0.35, 0.28))
	if detail_label:
		detail_label.text = message + "\n\nEnvia uma captura deste ecrã para identificar a falha seguinte."

# Valepólis V0.3.0 — Rede viária 3D, interseções e sinalização

## Alterações nesta entrega
- Mantida a geração nativa Godot do terreno e da rede viária 3D; sem Blender.
- Mantidas as ligações entre os 25 bairros através do grafo rodoviário existente.
- Mantidos os eixos principais, vias locais, variante periférica, acessos regionais e as pontes da União e do Horizonte com rampas e guardas.
- Acrescentadas cinco rotundas 3D em interseções principais, com anel viário, ilha central, bordadura e braços de acesso.
- Acrescentadas três passadeiras nas proximidades de cruzamentos principais.
- Os arruamentos locais continuam associados ao cadastro de moradas; o cadastro tem 125 arruamentos e 6.250 moradas de referência.
- Não foram criados novos nomes declarados como oficiais. O próprio cadastro assinala muitos nomes/códigos como fictícios para uso interno do jogo; não devem ser confundidos com topónimos oficialmente aprovados.

## Limitações conhecidas
- As estradas são geometria procedural segmentada, não uma malha de engenharia topográfica de precisão.
- A prevenção automática de todos os obstáculos e o pathfinding efetivo de veículos precisam de validação no jogo.
- O projeto ainda não foi executado/compilado com Godot neste ambiente; o PRE-FLIGHT deve correr antes de considerar a build aprovada.

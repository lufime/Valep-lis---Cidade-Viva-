# Valepólis V0.3.0 — configuração operacional inicial

## Recursos criados

- **Equipa BRG00001**: 1 chefe de equipa + 6 operacionais, disponível no início.
- **Viatura BRGA01**: classe genérica `Emergência`, disponível e atribuída ao quartel inicial do jogador. O identificador segue o formato de quatro letras + dois algarismos; não define marca/modelo.
- **CENTRALISTA-URG-01**: função de centralista urgente.
- **CENTRALISTA-TNUR-01**: função de centralista não urgente, identificada como unidade TNUR integrada na BRIGADA.

## Limites preservados

Esta é uma configuração inicial jogável mínima, criada a pedido do jogador. Não representa o efetivo nem a frota total da cidade. Não cria bases adicionais nem usa as instalações listadas como propostas. TNUR continua integrado nas bases BRIGADA e não recebe uma base independente.

As equipas/viaturas adicionais de S.U.E., Polícia e TNUR não são inventadas: permanecem por configurar, pois os números de equipas, composição operacional e tipos/quantidades de viaturas dessas entidades não estão definidos por esta configuração inicial. A cedência de ambulâncias S.U.E. à BRIGADA continua a exigir acordo explícito e apenas o tipo AMBS pode ser cedido.

## Persistência e despacho

`main.gd` inicializa a equipa e viatura se ainda não existirem, guarda e recupera equipas, viaturas, centralistas, despachos e estado das viaturas. O PRE-FLIGHT verifica o registo inicial e testa uma missão BRIGADA usando os recursos reais da configuração inicial.

O workflow `.github/workflows/build.yml` não foi alterado. É necessário executar o PRE-FLIGHT no Godot/GitHub Actions para confirmar compilação e comportamento em runtime.

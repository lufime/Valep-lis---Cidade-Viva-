# Blender 3.6+ / UPBGE compatible (run inside Blender: Scripting > Run Script)
# Generates three real .blend files: complete ring, wall module, door module.
import bpy, math, os
from mathutils import Vector

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'saida_blend'))
os.makedirs(ROOT, exist_ok=True)

# Materials
def material(name, color, metallic=0.0, roughness=0.45):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get('Principled BSDF')
    if bs:
        bs.inputs['Base Color'].default_value = (*color, 1)
        bs.inputs['Metallic'].default_value = metallic
        bs.inputs['Roughness'].default_value = roughness
    return m

wall_mat = material('Painel estrutural | aço polar', (0.42,0.53,0.59), .45)
trim_mat = material('Reforço | grafite', (0.055,0.075,0.09), .65)
door_mat = material('Porta blindada | azul petróleo', (0.035,0.19,0.25), .55)
light_mat = material('Sinal luminoso | ciano', (0.02,0.75,0.95), .25, .22)
glass_mat = material('Janela | vidro frio', (0.025,0.22,0.30), .45, .18)
floor_mat = material('Pavimento | metal', (0.10,0.14,0.17), .4)

def cube(name, loc, dims, mat, bevel=0.035):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
    o=bpy.context.object; o.name=name; o.dimensions=dims
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if mat: o.data.materials.append(mat)
    if bevel:
        mod=o.modifiers.new('Chanfro de segurança','BEVEL'); mod.width=bevel; mod.segments=2
        o.modifiers.new('Normais ponderadas','WEIGHTED_NORMAL')
    return o

def clear_scene():
    bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.cameras, bpy.data.lights):
        pass

def make_door_module(prefix='Porta modular', origin=(0,0,0), width=2.4, height=3.0, thickness=.22):
    x,y,z=origin
    # Frame with a clear opening; door panel sits inside frame and can be animated in UPBGE.
    frame_w=.16; frame_d=thickness
    cube(prefix+' | ombreira esquerda',(x-width/2+frame_w/2,y+height/2,z),(frame_w,height,frame_d),trim_mat)
    cube(prefix+' | ombreira direita',(x+width/2-frame_w/2,y+height/2,z),(frame_w,height,frame_d),trim_mat)
    cube(prefix+' | lintel',(x,y+height-frame_w/2,z),(width,height*0+frame_w,frame_d),trim_mat)
    panel=cube(prefix+' | folha (móvel)',(x,y+height/2,z),(width-2*frame_w,height-frame_w,thickness*.65),door_mat)
    panel['tipo']='porta_movel'; panel['interacao']='E'; panel['animacao']='configurar no UPBGE'
    cube(prefix+' | faixa luminosa',(x,y+height*.72,z-thickness*.36),(.75,.07,.035),light_mat,.01)
    cube(prefix+' | puxador',(x+width*.34,y+height*.48,z-thickness*.48),(.07,.32,.06),light_mat,.015)
    # sill/threshold
    cube(prefix+' | soleira',(x,.08,z),(width,.16,thickness*1.4),trim_mat,.02)
    return panel

def save_blend(path):
    bpy.ops.wm.save_as_mainfile(filepath=path)

def build_wall_module():
    clear_scene()
    # One modular wall segment with metal frame, panel and a narrow status light.
    cube('Parede | painel modular',(0,1.5,0),(4.0,3.0,.22),wall_mat,.04)
    cube('Parede | montante esquerdo',(-1.94,1.5,-.14),(.12,3.0,.12),trim_mat,.02)
    cube('Parede | montante direito',(1.94,1.5,-.14),(.12,3.0,.12),trim_mat,.02)
    cube('Parede | faixa de identificação',(0,2.68,-.14),(.85,.08,.035),light_mat,.01)
    cube('Parede | rodapé',(0,.12,-.15),(3.85,.18,.12),trim_mat,.02)
    bpy.ops.object.select_all(action='SELECT'); bpy.context.view_layer.objects.active=bpy.context.selected_objects[0]
    save_blend(os.path.join(ROOT,'Modulo_Parede.blend'))

def build_door_module():
    clear_scene(); make_door_module()
    save_blend(os.path.join(ROOT,'Modulo_Porta.blend'))

def build_complete_ring():
    clear_scene()
    N=15; radius=34.0; room_w=10.0; room_d=12.0; wall_h=4.0; thick=.28; door_w=2.4
    # Central floor
    cube('Pátio central',(0,-.28,0),(29,.56,29),floor_mat,.12)
    for i in range(N):
        theta=2*math.pi*i/N; x=radius*math.cos(theta); z=radius*math.sin(theta); a=theta+math.pi/2
        def local(dx,dz):
            return (x+dx*math.cos(a)+dz*math.sin(a), z-dx*math.sin(a)+dz*math.cos(a))
        # floors and roof
        cube(f'Zona {i+1:02d} | pavimento',(x,-.12,z),(room_w,.24,room_d),floor_mat,.05)
        cube(f'Zona {i+1:02d} | teto',(x,wall_h+.08,z),(room_w,.16,room_d),wall_mat,.03)
        # side walls
        for side in (-1,1):
            px,pz=local(side*room_w/2,0)
            ob=cube(f'Zona {i+1:02d} | parede lateral {side}',(px,wall_h/2,pz),(thick,wall_h,room_d),wall_mat,.035); ob.rotation_euler[1]=a
        # outside wall, full segment
        px,pz=local(0,room_d/2)
        ob=cube(f'Zona {i+1:02d} | parede exterior',(px,wall_h/2,pz),(room_w,wall_h,thick),wall_mat,.035); ob.rotation_euler[1]=a
        # inward wall split around opening, with door frame/panel
        segment=(room_w-door_w)/2
        for side in (-1,1):
            px,pz=local(side*(door_w/2+segment/2),-room_d/2)
            ob=cube(f'Zona {i+1:02d} | parede interior {side}',(px,wall_h/2,pz),(segment,wall_h,thick),wall_mat,.035); ob.rotation_euler[1]=a
        # door geometry transformed to room tangent orientation
        px,pz=local(0,-room_d/2)
        panel_parts=[]
        panel_parts.append(cube(f'Zona {i+1:02d} | porta | ombreira E',(px-door_w/2+.08,wall_h/2,pz),( .16,wall_h,thick),trim_mat,.02))
        panel_parts.append(cube(f'Zona {i+1:02d} | porta | ombreira D',(px+door_w/2-.08,wall_h/2,pz),(.16,wall_h,thick),trim_mat,.02))
        panel_parts.append(cube(f'Zona {i+1:02d} | porta | lintel',(px,wall_h-.08,pz),(door_w,.16,thick),trim_mat,.02))
        panel=cube(f'Zona {i+1:02d} | porta | folha',(px,wall_h/2,pz-.06),(door_w-.32,wall_h-.16,.12),door_mat,.025)
        panel['zona']=i+1; panel['tipo']='porta_movel'; panel['interacao']='E'; panel['nota']='A folha é geometria; ligar lógica de abertura no UPBGE.'
        # Rotate door frame/panel as a group around Y to align with wall.
        for ob in panel_parts+[panel]:
            # objects built axis aligned; rotate around room centre
            rel=Vector(ob.location)-Vector((px,ob.location.y,pz)); rel.rotate(Vector((0,1,0)),a)
            ob.location.x=px+rel.x; ob.location.z=pz+rel.z; ob.rotation_euler[1]=a
        # zone plaque on outer side
        px,pz=local(0,room_d/2+.16)
        plaque=cube(f'Zona {i+1:02d} | sinalização',(px,2.75,pz),(2.2,.35,.08),light_mat,.025); plaque.rotation_euler[1]=a
    # Simple corridor loop connecting zone entrances: segments around the ring, visually continuous.
    for i in range(N):
        t1=2*math.pi*i/N; t2=2*math.pi*(i+1)/N
        p1=Vector((radius*math.cos(t1),.03,radius*math.sin(t1)))
        p2=Vector((radius*math.cos(t2),.03,radius*math.sin(t2)))
        mid=(p1+p2)/2; length=(p2-p1).length
        ob=cube(f'Ciclo | corredor {i+1:02d}',(mid.x,mid.y,mid.z),(3.0,.18,length),floor_mat,.04)
        ob.rotation_euler[1]=-math.atan2((p2-p1).x,(p2-p1).z)
    # lighting and camera for convenient preview
    bpy.ops.object.light_add(type='AREA', location=(0,24,0)); bpy.context.object.name='Luz de apresentação'; bpy.context.object.data.energy=5000; bpy.context.object.data.shape='DISK'; bpy.context.object.data.size=25
    bpy.ops.object.camera_add(location=(0,68,75)); cam=bpy.context.object; cam.name='Câmara de planta'; cam.rotation_euler=(math.radians(35),0,0); bpy.context.scene.camera=cam
    bpy.context.scene.render.engine='BLENDER_EEVEE_NEXT' if hasattr(bpy.types, 'SceneEEVEE') else 'BLENDER_EEVEE'
    bpy.context.scene.render.resolution_x=1400; bpy.context.scene.render.resolution_y=1400; bpy.context.scene.render.resolution_percentage=100
    bpy.ops.object.select_all(action='DESELECT')
    save_blend(os.path.join(ROOT,'A_Ultima_Expedicao_Paredes_Portas_15_Zonas.blend'))

if __name__=='__main__':
    build_wall_module(); build_door_module(); build_complete_ring()
    print('CONCLUIDO: 3 ficheiros .blend gerados em', ROOT)

# Valepólis V0.3.0 — Fase 6.1.8: rede viária local e edifícios adaptativos

## Alterações aplicadas ao código Kotlin
- A rede viária deixou de ligar automaticamente os centros dos bairros em padrão radial.
- Geração de ruas locais horizontais e verticais recortadas pelos polígonos operacionais de cada um dos 25 bairros.
- Espaçamento viário adaptado à densidade populacional do bairro; eixos principais locais mais largos do que as ruas secundárias.
- Edifícios colocados apenas dentro dos polígonos dos respetivos bairros, com quantidade-alvo derivada da população aprovada e compactação/altura adaptadas à densidade.
- Malhas dos edifícios e linhas de janelas agregadas por tipo para limitar chamadas OpenGL.
- Ponte da União e Ponte do Horizonte mantidas; o ponto ocidental foi trazido para dentro da extensão visível do mapa.
- Versão de interface atualizada para BUILD 618 / Fase 6.1.8.

## Dados preservados
- Não foram alteradas as populações, áreas, densidades, nomes de bairros ou regras aprovadas.
- A geometria é uma geração procedural visual baseada nos polígonos operacionais existentes, ainda não um cadastro georreferenciado.
- A biblioteca só contém nomenclatura explicitamente aprovada para Nexora e Altavira. Por isso, esta fase não inventa nomes oficiais para as vias dos restantes 23 bairros.
- A regra de máximo de 15 pisos aplica-se apenas ao polígono central quando definido; como esse polígono não consta dos dados territoriais atuais, esta fase não declara conformidade com esse limite específico. Edifícios de referência podem chegar a 30 pisos, conforme a regra geral.

## Validação realizada
- ZIP de entrada aberto e lido sem erro.
- JSON territorial original preservado byte a byte.
- Verificação de integridade do ZIP de saída e análise de sintaxe JSON executadas.
- Não foi possível confirmar compilação Kotlin/Gradle, execução Android ou resultado visual no dispositivo neste ambiente. Esta entrega não é uma declaração de APK testada.

# Integração de roupa e materiais Vitruvian — PREVIEW

## Recursos adicionados
- Corpo masculino Vitruvian (`assets/vitruvian_body.glb`), que inclui roupa e rig/animações do modelo de origem.
- Cabeça/olhos/rosto e cabelo rigged já referenciados pela cena `PlayerExpeditionSurvivor.tscn` e pelo script `scripts/player_realistic_model.gd`.
- Texturas de corpo, rosto, tecido, cabelo, íris, esclera e boca copiadas para `assets/`.
- Shader de olhos e licença/aviso de atribuição do repositório de origem incluídos.

## Limitações importantes
- O corpo Vitruvian vestido é um modelo masculino. Não é correto afirmar que essa roupa serve na malha feminina: roupa/skinning têm de ser ajustados à anatomia e ao esqueleto feminino.
- O modelo feminino (`assets/female_expedition_base_large_chest.glb`) continua uma base anatómica e não está vestido nesta prévia.
- A cabeça/cabelo Vitruvian são desenhados para o corpo Vitruvian e o alinhamento não foi confirmado em execução.
- Não foi possível executar o projeto no Godot nesta sessão; isto não é uma validação de runtime.

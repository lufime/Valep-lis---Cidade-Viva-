extends Node3D
## Modelo humano Vitruvian: corpo animado, cabeça com olhos/rosto e cabelo rigged.
## A posição/rotação de rede continua a ser controlada pelo Node3D pai.

const BODY_SCENE: PackedScene = preload("res://assets/vitruvian_body.glb")
const HEAD_SCENE: PackedScene = preload("res://assets/vitruvian_head.glb")
const HAIR_SCENE: PackedScene = preload("res://assets/vitruvian_hair_rigged.glb")
const HairSpringScript = preload("res://scripts/hair_spring.gd")
const HEAD_BONE := "mixamorig_Head"

var body_skeleton: Skeleton3D
var animation_player: AnimationPlayer
var hair_physics: Node

func _ready() -> void:
    var body := BODY_SCENE.instantiate()
    body.name = "RealisticBody"
    add_child(body)
    body_skeleton = _find_node_of_type(body, "Skeleton3D") as Skeleton3D
    animation_player = _find_node_of_type(body, "AnimationPlayer") as AnimationPlayer

    var head_parent: Node = self
    if body_skeleton != null:
        var bone_index := body_skeleton.find_bone(HEAD_BONE)
        if bone_index >= 0:
            var attachment := BoneAttachment3D.new()
            attachment.name = "RealisticHeadAttachment"
            attachment.bone_name = HEAD_BONE
            body_skeleton.add_child(attachment)
            var head_rig := Node3D.new()
            head_rig.name = "RealisticHeadRig"
            attachment.add_child(head_rig)
            head_rig.global_transform = Transform3D.IDENTITY
            head_parent = head_rig

    var head := HEAD_SCENE.instantiate()
    head.name = "RealisticHeadEyesFace"
    head_parent.add_child(head)

    var hair := HAIR_SCENE.instantiate()
    hair.name = "RealisticRiggedHair"
    head_parent.add_child(hair)
    var hair_skeleton := _find_node_of_type(hair, "Skeleton3D") as Skeleton3D
    if hair_skeleton != null:
        hair_physics = Node.new()
        hair_physics.set_script(HairSpringScript)
        hair.add_child(hair_physics)
        hair_physics.call("setup", hair_skeleton)
        if body_skeleton != null:
            hair_physics.call("set_body_colliders", body_skeleton)

    if animation_player != null:
        if animation_player.has_animation("Idle"):
            animation_player.play("Idle")
        else:
            var clips := animation_player.get_animation_list()
            if not clips.is_empty():
                animation_player.play(clips[0])

func _find_node_of_type(root: Node, type_name: String) -> Node:
    if root.get_class() == type_name:
        return root
    for child in root.get_children():
        var found := _find_node_of_type(child, type_name)
        if found != null:
            return found
    return null

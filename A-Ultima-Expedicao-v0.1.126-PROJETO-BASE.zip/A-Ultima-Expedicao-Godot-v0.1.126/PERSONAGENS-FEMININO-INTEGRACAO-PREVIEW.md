# Personagem feminino — integração preliminar

- Modelo feminino GLB original incluído e preservado como base rigged.
- Deformação localizada e moderada do volume do peito aplicada ao mesh principal (313 vértices ajustados), preservando o esqueleto, os pesos, materiais e restantes dados GLB.
- Cena isolada: `scenes/FemaleExpeditionBase.tscn`.
- O avatar masculino Vitruvian existente e a lógica de rede não foram alterados por esta etapa.

## Limitações verificadas
- Esta é uma base anatómica, não um personagem final vestido: não foram adicionados roupa feminina, cabelo feminino ou animações femininas específicas.
- A deformação foi feita diretamente nos vértices do GLB; ainda é necessária inspeção visual no Godot para confirmar o resultado, materiais, rig e escala.
- Não foi executado o motor Godot nesta sessão; não declarar o projeto como testado ou pronto para lançamento.

# LIMPEZA — A Última Expedição V0.1.126

## Alterações feitas
- Removida a construção automática do interior da estação, corredores, exterior antigo, abrigo, zonas, portas, relés e objetos antigos de missão da inicialização.
- Criado apenas um terreno neutro com colisão para permitir testar movimento enquanto o novo cenário é reconstruído.
- Desativada a criação da criatura antiga e a presença da silhueta humana antiga.
- Desativados os construtores procedurais de humanos e criatura.
- Removidos os assets antigos da estação, da criatura e do modelo humano antigo, incluindo scripts Blender dedicados a esses assets.
- Mantidos os modelos Vitruvian de corpo, cabeça/olhos/rosto e cabelo rigged, bem como a cena de avatar que os referencia.
- Removidas as imagens cinematográficas antigas da estação; o menu/intro deixam de carregar essas imagens.
- Mantidos os scripts de rede, jogador, HUD e menu; as interações de missão ligadas ao cenário removido precisam de ser reconstruídas no novo mapa.

## Validação
- ZIP validado com teste de integridade.
- Referências diretas aos antigos GLB removidos foram verificadas; as referências dinâmicas em funções antigas não chamadas podem continuar presentes no código-fonte.
- Não foi possível executar uma validação no motor Godot nesta sessão; não se declara compilação ou teste de jogo aprovado.

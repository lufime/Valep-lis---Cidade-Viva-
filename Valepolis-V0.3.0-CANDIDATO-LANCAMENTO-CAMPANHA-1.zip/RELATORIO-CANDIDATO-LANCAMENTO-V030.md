# Valepólis — Cidade Viva V0.3.0 — pacote candidato a lançamento

## Alterações nesta consolidação
- Corrigido o dimensionamento do `SubViewport`: com `SubViewportContainer.stretch = true`, a rotina não tenta impor manualmente `SubViewport.size`.
- Adicionada navegação de campanha ao menu inicial: catálogo existente de 20 temporadas/200 episódios, seleção por temporada e episódio, seleção de modo Personagem/Entidade e continuidade da cidade autónoma.
- Mantidos os dados existentes do projeto, incluindo o catálogo de episódios e os dados territoriais.

## Limites de validação
- ZIP verificado estruturalmente.
- Catálogo JSON validado quanto à quantidade e distribuição dos episódios.
- Não foi possível executar o editor/runtime Godot nesta sessão; por isso não se declara compilação, execução Android ou validação visual aprovada.
- A navegação da campanha usa o catálogo oficial existente. A existência de 200 entradas não demonstra, por si só, 200 episódios com objetivos narrativos e condições de conclusão individualmente implementados. Essa validação tem de ser feita no jogo.
- O mapa preto visto no dispositivo permanece um bloqueio de lançamento até confirmação visual no Android, apesar da correção do dimensionamento do viewport.

## Próxima validação obrigatória no GitHub Actions
1. Importar o conteúdo deste ZIP para o projeto usado pelo workflow.
2. Executar o workflow Android PRE-FLIGHT.
3. Confirmar ausência do aviso de redimensionamento do SubViewport.
4. Instalar a APK de teste e confirmar mapa, câmara, bairros e navegação de campanha.
5. Só promover a lançamento depois de os gates funcionais passarem.

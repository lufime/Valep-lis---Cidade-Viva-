# A Última Expedição — V0.1.88

- Encerramento da missão apresentado como **EXTRAÇÃO CONFIRMADA**.
- A extração exige relés A e B ativos, energia restabelecida, 10 provas recolhidas, combinação VANTHIS validada e arquivo confidencial aberto.
- O terminal apresenta as tarefas em falta quando a missão ainda não está pronta para terminar.
- O modo individual permite concluir os objetivos sem depender de outro jogador; no multijogador, a validação é feita pelo servidor.
- A cena final mantém em aberto o destino da experiência VANTHIS.

## Validação honesta

O pacote ZIP pode ser verificado estruturalmente, mas o Godot 4.5 não está disponível neste ambiente. Não declarar compilação, execução nem teste multijogador como aprovados sem os executar.


## V0.1.84 — integração fisiológica
- A pulsação responde ao movimento, exposição ao frio, saúde baixa e captura.
- A saúde diminui após exposição prolongada ao exterior e recupera lentamente no interior.
- Saúde abaixo de 55% e 25% reduz progressivamente a velocidade de movimento.
- Saúde a 0% incapacita o jogador e apresenta um aviso de falha fisiológica no HUD.
- A barra de saúde muda de cor conforme a gravidade.
- Verificação realizada: inspeção estática dos scripts e integridade do ZIP. Compilação/runtime Godot 4.5 ainda por executar.


## V0.1.88 — etiquetas de teste de interação
- Etiquetas 3D sobre as 10 pistas recolhíveis: `PISTA NN · INTERAGIR`.
- Etiquetas sobre os relés cooperativos, consola de síntese, terminal de extração, porta experimental e painéis do abrigo.
- Etiquetas usam billboard, contorno escuro e texto contrastante para leitura no cenário 3D.
- Objetivo: facilitar testes funcionais no jogo; estas etiquetas identificam elementos interativos e não substituem a ação real de interação.
- Validação feita: inspeção estática das inserções e integridade do ZIP. Godot 4.5/runtime não executado neste ambiente.

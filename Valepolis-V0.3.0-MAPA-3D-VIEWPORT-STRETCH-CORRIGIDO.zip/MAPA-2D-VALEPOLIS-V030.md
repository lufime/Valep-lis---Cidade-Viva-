# Valepólis V0.3.0 — Conversão da apresentação dos mapas para 2D

## Alteração aplicada
- O mapa principal passa a apresentar a geografia 2D existente: costa e praias a norte, rio/estuário a oeste, lago, montanhas a leste, rede viária e rótulos territoriais.
- A camada `Map3D` fica oculta e não é instanciada no painel principal.
- O título passa a identificar explicitamente `MAPA 2D • VALEPÓLIS — 25 BAIRROS`.
- O atlas interativo mantém o mapa geral baseado nos polígonos do ficheiro `data/limites_bairros_v030.json` e os cartões dos 25 bairros.
- Selecionar um bairro atualiza o bairro selecionado e o destaque visual, sem tentar abrir uma vista 3D.
- As cenas e recursos 3D existentes são preservados no ZIP; não são apagados nem usados como mapa apresentado.
- A população aprovada, as áreas/densidades calibradas e os dados dos bairros não foram alterados nesta conversão.

## Limites conhecidos
- A geografia do mapa principal é esquemática, não um levantamento GIS nem uma reprodução métrica validada.
- Os cartões individuais do atlas são pré-visualizações esquemáticas 2D; não devem ser interpretados como mapas de ruas detalhados.
- Os controlos antigos relacionados com câmara 3D podem não oferecer todas as funções de zoom/pan esperadas numa versão 2D. Não se declara essa interação validada.
- Não foi possível executar o projeto no motor Godot nesta sessão. A compilação, o PRE-FLIGHT e a APK Android permanecem por testar.

## Ficheiros alterados
- `main.gd`
- `Main.tscn`
- `MAPA-2D-VALEPOLIS-V030.md` (novo)

Nenhum outro ficheiro foi modificado por esta conversão.

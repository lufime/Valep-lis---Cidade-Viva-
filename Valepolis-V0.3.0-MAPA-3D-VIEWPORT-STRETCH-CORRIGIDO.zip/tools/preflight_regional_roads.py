#!/usr/bin/env python3
"""Auditoria estrutural da rede regional de Valepólis; não substitui teste Godot/runtime."""
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
city_path = root / "systems/city_3d.gd"
source = city_path.read_text(encoding="utf-8")
checks = {
    "ponte principal presente": '"Ponte_da_Uniao"' in source and '"Ponte da União"' in source,
    "ponte secundária presente": '"Ponte_do_Horizonte"' in source and '"Ponte do Horizonte"' in source,
    "pontes marcadas como travessias do rio": 'set_meta("crosses_water", "Rio_Estuario_Oeste")' in source and 'set_meta("connects_both_banks", true)' in source,
    "tabuleiro e rampas alinham nos extremos": all(x in source for x in ["Vector3(-44.0, 0.72, z_value)", "Vector2(-66.0, z_value), Vector2(-57.5, z_value)", "Vector2(-30.5, z_value), Vector2(-20.5, z_value)"]),
    "largura do tabuleiro compatível com rampas": "Vector3(27.0, 0.44, 5.2)" in source and '5.0, bridge_name + "_Rampa_Oeste"' in source and '5.0, bridge_name + "_Rampa_Leste"' in source,
    "rampas nas duas margens": 'bridge_name + "_Rampa_Oeste"' in source and 'bridge_name + "_Rampa_Leste"' in source and '_bridge_deck(-17.0, "Ponte_da_Uniao")' in source and '_bridge_deck(23.0, "Ponte_do_Horizonte")' in source,
    "corredor regional conecta as pontes": 'Corredor_Regional_Oeste_Norte' in source and 'Corredor_Regional_Oeste_Sul' in source,
    "Santo André do Vale ligado": 'Acesso_Santo_Andre_do_Vale' in source and '"Santo André do Vale"' in source,
    "Portela do Sul ligada": 'Acesso_Portela_do_Sul' in source and '"Portela do Sul"' in source,
    "acessos a vilas/arredores": 'Acesso_Vilas_Sul_Leste' in source and 'Acesso_Vilas_Oeste' in source and '"Vilas e arredores"' in source,
    "vias regionais identificadas": 'set_meta("road_class", "regional")' in source,
    "rotas regionais expostas para consulta": 'func get_regional_destinations()' in source and 'func get_regional_route(origin: String, destination: String)' in source,
    "grafo regional inclui as duas cidades e as duas pontes": all(x in source for x in ['"Santo André do Vale"', '"Portela do Sul"', '"Ponte da União"', '"Ponte do Horizonte"']),
    "construção regional invocada no mapa": '_build_bridges_and_regional_roads()' in source,
    "diagnóstico de rotas disponível": 'func get_vehicle_route_network_diagnostics(' in source,
    "rotas evitam arestas rejeitadas pela heurística": 'get_route_avoiding_edges(origin, destination, blocked_edges)' in source,
    "diagnóstico identifica limitações da geometria": 'Não verifica água, árvores, instalações, tráfego, colisões reais ou continuidade física das pontes.' in source,
    "autoestrada periférica de quatro faixas": '"Autoestrada_Leste", 56' in source and '"Autoestrada_Variante_Sul", 56' in source and 'Vector2(51,-48), Vector2(51,48), 10.8, 4' in source,
    "avenidas de três e quatro faixas": '"Avenida_Central", 48' in source and '"Avenida_Transversal", 48' in source and '"Avenida_Norte", 24' in source and '"Avenida_Sul", 24' in source,
    "corredores regionais reservados contra colocação de objetos": 'var regional_corridors: Array[Dictionary]' in source and '_point_segment_distance_2d(point, corridor_start, corridor_end)' in source,
    "acessos das duas pontes incluídos na reserva": all(x in source for x in ['Vector2(-66.0, -17.0)', 'Vector2(-30.5, -17.0)', 'Vector2(-66.0, 23.0)', 'Vector2(-30.5, 23.0)']),
    "distância ponto-segmento protege toda a extensão do corredor": 'func _point_segment_distance_2d(point: Vector2, start: Vector2, finish: Vector2) -> float:' in source and 'clampf((point - start).dot(segment) / length_squared, 0.0, 1.0)' in source,
}
failed = []
for label, ok in checks.items():
    print(("PASS|" if ok else "FAIL|") + label)
    if not ok:
        failed.append(label)
if failed:
    print("RESULT=FAIL")
    sys.exit(1)
print("NOTE|Auditoria estrutural apenas; colisões geométricas e circulação exigem execução real no Godot.")
print("RESULT=PASS_STATIC_ONLY")

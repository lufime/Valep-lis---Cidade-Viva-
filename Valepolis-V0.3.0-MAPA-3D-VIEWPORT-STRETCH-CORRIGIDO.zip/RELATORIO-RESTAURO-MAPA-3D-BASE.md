# Valepólis V0.3.0 — Restauro da vista 3D principal

## Correção
- A rotina `_v030_setup_2d_map()` já não desativa permanentemente a vista 3D.
- Se `Map3D` não existir, cria um `SubViewportContainer` de ecrã completo, um `SubViewport` e instancia `res://City3D.tscn`.
- O container 3D passa para a frente e os elementos de mapa 2D antigos são ocultados para não taparem a cidade nem deixarem o retângulo verde por cima.
- O dimensionamento do viewport continua a ser tratado por `_v030_sync_map_viewport_size()`.

## Limites da validação
- Esta alteração foi verificada por inspeção do código e integridade do ZIP.
- Não foi possível executar o Godot neste ambiente; compilação, renderização no Android e desempenho continuam por validar no PRE-FLIGHT e no dispositivo.
- Não foram alteradas as regras de simulação nem os dados territoriais.

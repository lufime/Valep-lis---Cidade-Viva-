# Valepólis V0.3.0 — Correção do SubViewport móvel

## Causa confirmada nos logs
O `build-functional.log` registava `Can't change the size of a SubViewport with a SubViewportContainer parent that has stretch enabled`, com origem em `main.gd:1560`.

## Alteração
- Removida a atribuição manual a `SubViewport.size` enquanto o `SubViewportContainer.stretch` está ativo.
- O container continua ancorado ao painel e gere a escala da apresentação.
- Preservados a cena 3D, os dados territoriais, os sistemas e a interface.

## Validação
- Integridade do ZIP verificada.
- Verificação textual confirma que a função de sincronização já não altera `viewport.size`.
- Godot não está disponível neste ambiente; esta correção ainda precisa de ser executada pelo workflow PRE-FLIGHT.

# Valepólis V0.3.0 — Reserva dos corredores de circulação

## Alteração
- A função `_is_reserved_road_corridor()` passa a reservar também os eixos das estradas regionais, os acessos das duas pontes e as ligações às localidades já presentes no projeto.
- A reserva usa distância ponto-segmento, cobrindo toda a extensão de cada corredor e somando a margem de segurança configurada pelo chamador.
- O PRE-FLIGHT estático passa a verificar a presença da reserva dos corredores, dos acessos às pontes, das avenidas de três/quatro faixas e da autoestrada de quatro faixas.

## Âmbito preservado
- Não foram alterados nomes/quantidades dos 25 bairros, população, culturas, edifícios aprovados, economia, efetivos ou regras de simulação.
- Não foram introduzidos nomes novos de bairros ou localidades.
- Não foram alterados os percursos existentes nem as regras de prioridade dos veículos.

## Validação e limitações
- O ZIP foi verificado quanto à integridade estrutural.
- O PRE-FLIGHT estático foi atualizado para validar estas garantias de código.
- Esta alteração não equivale a teste de colisões em runtime: a compilação Godot, a geração do mapa e a circulação real têm de ser confirmadas no workflow PRE-FLIGHT e no jogo.

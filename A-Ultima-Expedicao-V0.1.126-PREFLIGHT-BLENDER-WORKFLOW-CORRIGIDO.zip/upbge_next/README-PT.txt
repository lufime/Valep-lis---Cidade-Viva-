A ÚLTIMA EXPEDIÇÃO V0.1.126 — PRE-FLIGHT UPBGE

Conteúdo:
- gerar_projeto_upbge.py: gerador de geometria .blend para Blender moderno; não valida o runtime do jogo.
- player_tick.py, creature_ai.py, interactions.py: protótipos de lógica, ainda sem ligação automática comprovada aos controladores do motor.
- validar_pacote.py: validação estática, sem alegar execução do jogo.
- projeto_godot_v0.1.126_referencia.zip: cópia de referência do projeto original.
- .github/workflows/upbge-preflight.yml: workflow GitHub Actions.

USO NO GITHUB
1. Colocar esta pasta como `upbge/` na raiz do repositório.
2. Abrir Actions e executar “A Última Expedição V0.1.126 — PRE-FLIGHT e geração BLEND”.
3. O workflow instala Blender no runner e tenta gerar a cena .blend de 15 zonas.
4. Descarregar o artefacto `A-Ultima-Expedicao-V0.1.126-15-Zonas-BLEND` na execução concluída.
5. Consultar `geracao-blend.log`; se a geração falhar, não considerar o ficheiro validado.

LIMITAÇÕES IMPORTANTES
- O workflow não converte automaticamente toda a lógica Godot para UPBGE.
- A geração do .blend só é considerada executada se o ficheiro for produzido e o passo terminar sem erro. A abertura visual, colisões, portas interativas e jogabilidade ainda precisam de teste separado.
- Ainda não estão portados/validados integralmente o multijogador, o traidor, as missões, pistas, extração, HUD e áudio.
- Não se afirma que movimento, colisões, portas ou IA funcionam em jogo sem teste real.
- UPBGE oficial: https://github.com/UPBGE/upbge/releases

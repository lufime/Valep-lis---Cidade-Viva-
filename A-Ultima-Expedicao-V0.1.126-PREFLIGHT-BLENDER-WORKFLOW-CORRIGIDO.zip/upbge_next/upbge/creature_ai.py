"""UPBGE Python Controller main(cont): criatura autónoma, distinta do traidor.
Ligar a sensor Always no objeto CRIATURA_IA. IA de perseguição por distância; colisões físicas do cenário limitam movimento.
"""
import bge
from mathutils import Vector

def main(cont):
    own=cont.owner; scene=bge.logic.getCurrentScene()
    players=[o for o in scene.objects if o.get('role')=='player']
    if not players: return
    target=min(players,key=lambda p:(p.worldPosition-own.worldPosition).length)
    delta=target.worldPosition-own.worldPosition; delta.z=0
    dist=delta.length
    if dist>0.01:
        direction=delta.normalized(); own.alignAxisToVect(direction,1,.12)
        speed=float(own.get('speed',2.7))
        if dist>1.8: own.applyMovement(direction*speed/60.0,False)
    own['state']='CHASE' if dist<12 else 'PATROL'

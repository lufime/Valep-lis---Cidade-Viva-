"""UPBGE Python Controller main(cont): movimento WASD, olhar rato e interação E.
Ligar a um sensor Always do objeto JOGADOR. Configurar a câmara como filha do jogador.
"""
import bge, math
from mathutils import Vector

def main(cont):
    own=cont.owner; scene=bge.logic.getCurrentScene(); keyboard=bge.logic.keyboard; mouse=bge.logic.mouse
    events=keyboard.events; active=bge.logic.KX_INPUT_ACTIVE
    dt=1.0/60.0
    speed=float(own.get('speed',4.2))
    forward=own.worldOrientation.col[1].copy(); forward.z=0
    if forward.length: forward.normalize()
    right=own.worldOrientation.col[0].copy(); right.z=0
    if right.length: right.normalize()
    move=Vector((0,0,0))
    if events.get(bge.events.WKEY,0)==active or events.get(bge.events.UPARROWKEY,0)==active: move+=forward
    if events.get(bge.events.SKEY,0)==active or events.get(bge.events.DOWNARROWKEY,0)==active: move-=forward
    if events.get(bge.events.DKEY,0)==active or events.get(bge.events.RIGHTARROWKEY,0)==active: move+=right
    if events.get(bge.events.AKEY,0)==active or events.get(bge.events.LEFTARROWKEY,0)==active: move-=right
    if move.length: move.normalize(); own.applyMovement(move*speed*dt,False)
    # Gravity + collision response
    own.applyMovement((0,0,-9.81*dt*dt),False)
    # Mouse look, only if a camera child exists
    cam=next((o for o in scene.objects if o.name=='Camera_Jogador'),None)
    if cam:
        x,y=mouse.position; dx=x-.5; dy=y-.5
        own.applyRotation((0,0,-dx*2.6),False)
        cam.applyRotation((dy*2.0,0,0),True)
        bge.render.setMousePosition(int(bge.render.getWindowWidth()/2),int(bge.render.getWindowHeight()/2))
    # E toggles nearest door or marks nearby objective as interacted
    if events.get(bge.events.EKEY,0)==active:
        nearest=None; nd=2.6
        for o in scene.objects:
            if o.name.startswith('PORTA_') or o.get('interactable',False):
                d=(o.worldPosition-own.worldPosition).length
                if d<nd: nearest=o; nd=d
        if nearest:
            if nearest.name.startswith('PORTA_'):
                opened=not bool(nearest.get('door_open',False)); nearest['door_open']=opened
                # visibly move door panel upward; restore to closed base on toggle
                if opened: nearest.applyMovement((0,0,2.8),False)
                else: nearest.applyMovement((0,0,-2.8),False)
            else:
                nearest['activated']=True; own['last_interaction']=nearest.name

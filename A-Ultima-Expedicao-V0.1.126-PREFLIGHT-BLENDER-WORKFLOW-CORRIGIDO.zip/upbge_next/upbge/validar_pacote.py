#!/usr/bin/env python3
"""Validação estática; não afirma que o jogo executou."""
from pathlib import Path
import ast, sys, zipfile
ROOT = Path(__file__).resolve().parent
checks=[]
def check(name, ok, detail): checks.append((name, bool(ok), detail))

src=(ROOT/'gerar_projeto_upbge.py').read_text(encoding='utf-8')
try: ast.parse(src); check('Sintaxe do gerador', True, 'AST válido')
except SyntaxError as e: check('Sintaxe do gerador', False, str(e))
check('15 zonas declaradas', 'N=15' in src, 'Constante de zonas')
check('Ciclo fecha Z15→Z01', '(i+1)%N' in src and 'zone_centers[(i+1)%N]' in src, 'Conector cíclico declarado')
check('Objetos de portas', "'PORTA_Z%02d_%s'" in src, 'Portas declaradas no gerador')
check('Jogador declarado', "'JOGADOR'" in src and "['role']='player'" in src, 'Jogador presente no código')
check('Criatura IA declarada', "'CRIATURA_IA'" in src and "['role']='creature_ai'" in src, 'Criatura presente no código')
for name in ('player_tick.py','creature_ai.py','interactions.py'):
    p=ROOT/name
    try: ast.parse(p.read_text(encoding='utf-8')); check('Sintaxe '+name, True, 'AST válido')
    except (SyntaxError, OSError) as e: check('Sintaxe '+name, False, str(e))
ref=ROOT/'projeto_godot_v0.1.126_referencia.zip'
try:
    with zipfile.ZipFile(ref) as z: bad=z.testzip(); check('ZIP original íntegro', bad is None, 'Entradas='+str(len(z.namelist())) if bad is None else 'Corrompida: '+str(bad))
except Exception as e: check('ZIP original íntegro', False, str(e))
print('PRE-FLIGHT ESTÁTICO UPBGE')
for name,ok,detail in checks: print(f"{'PASS' if ok else 'FAIL'} | {name} | {detail}")
passed=sum(ok for _,ok,_ in checks); failed=len(checks)-passed
print(f'TOTAL_PASS={passed} TOTAL_FAIL={failed}')
print('NOTA: PASS estático não significa que o .blend foi gerado nem que a jogabilidade foi testada.')
sys.exit(1 if failed else 0)

# A Última Expedição V0.1.126 — gerador de cena UPBGE
# Executar dentro do Blender/UPBGE com bpy disponível.
import bpy, math, os
from mathutils import Vector

OUT = os.environ.get('BLEND_OUTPUT', os.path.join(os.path.dirname(os.path.abspath(__file__)), 'A_Ultima_Expedicao_UPBGE.blend'))
# Reset scene
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.cameras, bpy.data.lights, bpy.data.materials):
    for datablock in list(datablocks):
        if datablock.users == 0: datablocks.remove(datablock)
scene=bpy.context.scene
# Compatibilidade: gerar e guardar geometria .blend com Blender moderno.
# Isto NÃO ativa nem valida o runtime UPBGE; os scripts bge exigem execução no UPBGE compatível.
try:
    scene.render.engine = 'BLENDER_EEVEE_NEXT'
except Exception:
    try: scene.render.engine = 'BLENDER_EEVEE'
    except Exception: pass

# Materials
def mat(name, color, metallic=0.0, rough=0.65, emission=0.0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF')
    if bs:
        bs.inputs['Base Color'].default_value=(*color,1); bs.inputs['Metallic'].default_value=metallic; bs.inputs['Roughness'].default_value=rough
        if emission:
            if 'Emission Color' in bs.inputs: bs.inputs['Emission Color'].default_value=(*color,1)
            if 'Emission Strength' in bs.inputs: bs.inputs['Emission Strength'].default_value=emission
    return m
metal=mat('Aço industrial',(.12,.17,.19),.72,.35); floor=mat('Piso técnico',(.075,.09,.095),.25,.7); wall=mat('Painel polar',(.24,.29,.3),.35,.48); orange=mat('Sinalização âmbar',(1,.22,.025),.15,.3,1.2); blue=mat('Luz azul de emergência',(.02,.35,.8),.1,.3,1.5); dark=mat('Sombra',(.018,.025,.03),.1,.8); creaturemat=mat('Criatura — superfície escura',(.035,.018,.025),.05,.85)

def cube(name, loc, scale, material, dynamic=False, mass=1):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc); o=bpy.context.object; o.name=name; o.dimensions=scale; bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    if material: o.data.materials.append(material)
    if hasattr(o,'game'):
        try: o.game.physics_type='DYNAMIC' if dynamic else 'STATIC'; o.game.use_collision_bounds=True; o.game.collision_bounds_type='BOX'; o.game.mass=mass
        except Exception: pass
    return o

def text_obj(body, loc, size=0.8):
    cu=bpy.data.curves.new('Etiqueta_'+body,'FONT'); cu.body=body; cu.size=size; cu.extrude=.008
    ob=bpy.data.objects.new('Etiqueta_'+body,cu); scene.objects.link(ob) if hasattr(scene.objects,'link') else scene.collection.objects.link(ob); ob.location=loc; cu.materials.append(orange); return ob

# Ring of 15 rooms. Each room is a tangential module; doors align to neighbouring modules through radial connectors.
N=15; R=24.0; room_len=8.0; room_w=6.0; H=3.6; wall_t=.28; door_w=1.8; door_h=2.45
zone_centers=[]; door_objects=[]
for i in range(N):
    a=2*math.pi*i/N-math.pi/2
    cx,cy=R*math.cos(a),R*math.sin(a); zone_centers.append((cx,cy,a))
    # local axis x tangent to ring; radial axis y
    tangent=a+math.pi/2
    # floor and ceiling
    f=cube('Z%02d_Piso'%(i+1),(cx,cy,.0),(room_len,room_w,.24),floor); f.rotation_euler.z=tangent
    c=cube('Z%02d_Teto'%(i+1),(cx,cy,H),(room_len,room_w,.22),metal); c.rotation_euler.z=tangent
    # side walls at local y +/- room_w/2
    for side in (-1,1):
        x=cx-side*math.sin(tangent)*room_w/2; y=cy+side*math.cos(tangent)*room_w/2
        w=cube('Z%02d_Parede_Lateral_%s'%(i+1,side),(x,y,H/2),(room_len,wall_t,H),wall); w.rotation_euler.z=tangent
    # end walls with centered door openings, wall split left/right + lintel. doors face next zone
    for end in (-1,1):
        # local x direction transformed to world
        ex=cx+end*math.cos(tangent)*room_len/2; ey=cy+end*math.sin(tangent)*room_len/2
        for side in (-1,1):
            px=ex-side*math.sin(tangent)*(room_w-door_w)/4; py=ey+side*math.cos(tangent)*(room_w-door_w)/4
            w=cube('Z%02d_Parede_Extremo_%s_%s'%(i+1,end,side),(px,py,H/2),(wall_t,(room_w-door_w)/2,H),wall); w.rotation_euler.z=tangent
        w=cube('Z%02d_Vergalhao_%s'%(i+1,end),(ex,ey,door_h+.5),(wall_t,door_w,.9),metal); w.rotation_euler.z=tangent
        # door panel: movable upward by script when E pressed near it
        d=cube('PORTA_Z%02d_%s'%(i+1,'SAIDA' if end==1 else 'ENTRADA'),(ex,ey,door_h/2),(0.16,door_w,door_h),orange)
        d.rotation_euler.z=tangent; d['door_open']=False; d['zone_a']=i+1; d['zone_b']=(i+2 if end==1 else ((i-1)%N+1)); d['door_id']='D%02d_%02d'%(i+1,(i+2 if end==1 else ((i-1)%N+1)))
        door_objects.append(d)
    # wall details, panel lights and zone ID
    light=cube('Luz_Z%02d'%(i+1),(cx,cy,H-.18),(1.2,.12,.08),blue); light.rotation_euler.z=tangent
    text_obj('ZONA %02d'%(i+1),(cx-1.6,cy-room_w*.15,H+.16),.58)

# Connectors/tunnels between adjacent rooms (all 15, including Z15 -> Z01).
for i in range(N):
    cx,cy,a=zone_centers[i]; nx,ny,na=zone_centers[(i+1)%N]
    mid=((cx+nx)/2,(cy+ny)/2)
    # narrow tunnel from midpoint with orientation toward next center
    ang=math.atan2(ny-cy,nx-cx); dist=math.hypot(nx-cx,ny-cy)-room_len*.35
    if dist<1: dist=1
    t=cube('TUNEL_Z%02d_Z%02d'%(i+1,(i+1)%N+1),(mid[0],mid[1],-.08),(dist,2.25,.22),floor); t.rotation_euler.z=ang
    for side in (-1,1):
        wx=mid[0]-side*math.sin(ang)*1.12; wy=mid[1]+side*math.cos(ang)*1.12
        q=cube('Parede_Tunel_%02d_%02d_%s'%(i+1,(i+1)%N+1,side),(wx,wy,1.55),(dist,.18,3.1),metal); q.rotation_euler.z=ang
    roof=cube('Teto_Tunel_%02d_%02d'%(i+1,(i+1)%N+1),(mid[0],mid[1],3.1),(dist,2.25,.18),wall); roof.rotation_euler.z=ang

# Exterior base
cube('Base_Estacao',(0,0,-.55),(78,78,.5),dark)
# Player starting zone 1: body capsule-ish cube + camera
player=cube('JOGADOR',(0,-R+1,1.0),(.65,.65,1.8),blue,True,70); player['role']='player'; player['speed']=4.2
cam_data=bpy.data.cameras.new('Camera_Jogador'); cam=bpy.data.objects.new('Camera_Jogador',cam_data); scene.objects.link(cam) if hasattr(scene.objects,'link') else scene.collection.objects.link(cam); cam.location=(0,-R+1,2.45); cam.rotation_euler=(math.radians(90),0,0); cam_data.lens=30; cam.parent=player; cam.location=(0,0,1.2); scene.camera=cam
# Creature, separate AI agent
creature=cube('CRIATURA_IA',(R,0,1.0),(1.0,1.0,2.2),creaturemat,True,90); creature['role']='creature_ai'; creature['state']='PATROL'; creature['speed']=2.7
# Interaction / objective props in selected zones
for idx,label,material in [(2,'PISTA_01',orange),(4,'RELE_A',blue),(7,'PISTA_02',orange),(9,'RELE_B',blue),(12,'CONSOLa_PROVAS',orange),(14,'TERMINAL_EXTRACAO',blue)]:
    x,y,a=zone_centers[idx]; obj=cube(label,(x,y,1.0),(.55,.55,1.4),material); obj['interactable']=True; obj['activated']=False
# Lighting
ld=bpy.data.lights.new('Luz_ambiente','AREA'); lo=bpy.data.objects.new('Luz_ambiente',ld); scene.objects.link(lo) if hasattr(scene.objects,'link') else scene.collection.objects.link(lo); lo.location=(0,0,22); ld.energy=4500; ld.size=35
# world background
try: scene.world.color=(.015,.02,.03)
except: pass
# Game logic scripts are connected in the scene via UPBGE components/logic bricks by the install script.
scene['project_title']='A Última Expedição V0.1.126 — UPBGE'; scene['zones']=15; scene['cycle_closed']=True; scene['runtime_scripts']='runtime/player_tick.py; runtime/creature_ai.py; runtime/interactions.py'
# Save
bpy.ops.wm.save_as_mainfile(filepath=OUT)
print('GUARDADO:',OUT)

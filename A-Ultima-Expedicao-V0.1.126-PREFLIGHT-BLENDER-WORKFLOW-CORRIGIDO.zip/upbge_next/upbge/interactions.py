"""Helpers de interação UPBGE. A lógica de missões completa deve ser portada por módulos, não presumida.
"""
def door_toggle(door):
    opened=not bool(door.get('door_open',False)); door['door_open']=opened
    door.applyMovement((0,0,2.8 if opened else -2.8),False)
    return opened

def activate_object(obj):
    if not obj.get('interactable',False): return False
    obj['activated']=True
    return True

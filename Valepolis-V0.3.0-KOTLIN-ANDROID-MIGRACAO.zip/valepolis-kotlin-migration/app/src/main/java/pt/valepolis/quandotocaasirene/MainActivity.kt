package pt.valepolis.quandotocaasirene

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

/** Native Kotlin migration shell. Approved data are loaded from assets; gameplay systems are migrated incrementally. */
class MainActivity : Activity() {
    private val bg = Color.rgb(5, 20, 30)
    private val panel = Color.rgb(10, 34, 49)
    private val accent = Color.rgb(239, 202, 94)
    private lateinit var content: LinearLayout
    private var section = "PAINEL"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showShell()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(8), dp(8), dp(8), dp(8)); gravity = Gravity.CENTER_VERTICAL
    }
    private fun showShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(12), dp(8), dp(12), dp(8)) }
        root.addView(label("VALEPÓLIS — CIDADE VIVA", 23f, accent, true))
        root.addView(label("V0.3.0 · Migração Kotlin nativo", 14f, Color.LTGRAY))
        val scroller = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, dp(8)) }
        scroller.addView(content); root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("PAINEL", "BAIRROS", "OPERAÇÕES").forEach { row1.addView(navButton(it), LinearLayout.LayoutParams(0, dp(58), 1f)) }
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("EQUIPAS", "VEÍCULOS", "INSTALAÇÕES").forEach { row2.addView(navButton(it), LinearLayout.LayoutParams(0, dp(58), 1f)) }
        nav.addView(row1); nav.addView(row2); root.addView(nav)
        setContentView(root); renderSection()
    }
    private fun navButton(name: String) = Button(this).apply {
        text = name; textSize = 13f; isAllCaps = false; setTextColor(Color.WHITE); setBackgroundColor(panel)
        setPadding(dp(4), dp(4), dp(4), dp(4)); minHeight = dp(54); setOnClickListener { section = name; renderSection() }
    }
    private fun renderSection() {
        content.removeAllViews()
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(panel); setPadding(dp(12), dp(12), dp(12), dp(12)) }
        card.addView(label(section, 22f, accent, true))
        when (section) {
            "BAIRROS" -> {
                card.addView(label("Valepólis · 25 bairros", 18f, Color.WHITE, true))
                val names = loadJson("bairros_valepolis.json")
                card.addView(label(if (names != null) "Registo territorial carregado. A vista cartográfica 3D está em migração." else "Registo de bairros ainda não carregado.", 16f))
                card.addView(label("A população oficial da cidade é de 1.000.000 de habitantes.", 16f))
            }
            "OPERAÇÕES" -> card.addView(label("Centro de operações\nOs sistemas de ocorrência e despacho serão migrados por módulos, mantendo as regras V0.3.0.", 17f))
            "EQUIPAS" -> card.addView(label("BRIGADA e TNUR\nTNUR permanece integrada nas bases BRIGADA. Efetivos, turnos e disponibilidade só serão apresentados quando carregados dos registos operacionais aprovados.", 17f))
            "VEÍCULOS" -> card.addView(label("Gestão de viaturas\nA atribuição a missões exige equipa e viatura registadas e disponíveis.", 17f))
            "INSTALAÇÕES" -> card.addView(label("Instalações\nPropostas não aprovadas não são criadas automaticamente no mapa.", 17f))
            else -> {
                card.addView(label("A IA aconselha. O jogador comanda. A cidade reage.", 18f, Color.WHITE, true))
                card.addView(label("População: 1.000.000 · Bairros: 25\nNarrativa: 200 episódios · 20 temporadas", 17f))
                card.addView(label("Estado: base Kotlin em migração. Os módulos de jogo e o renderizador 3D ainda não estão concluídos.", 16f, Color.LTGRAY))
            }
        }
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }
    private fun loadJson(file: String): JSONObject? = try { assets.open("data/$file").bufferedReader().use { JSONObject(it.readText()) } } catch (_: Exception) { null }
}

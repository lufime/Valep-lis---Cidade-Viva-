# Valepólis — Cidade Viva V0.3.0 (Kotlin Android)

## Direção técnica
Esta base inicia a migração de Godot/GDScript para Android nativo com Kotlin. A aplicação usa uma Activity Android nativa e registos JSON em `app/src/main/assets/data/`. Google Filament está declarado como dependência para a futura camada de renderização 3D.

## Estado honesto da migração
- Estrutura Android/Kotlin e navegação inicial: base implementada.
- Registos JSON e imagens selecionadas: incluídos como assets.
- Sistemas de simulação completos, despacho integral, mundo 3D interativo, animações e equivalência funcional total: ainda por migrar.
- A APK só pode ser considerada compilada após sucesso real do workflow GitHub Actions.

## Regras preservadas nesta base
- Valepólis: 1.000.000 habitantes e 25 bairros.
- 200 episódios em 20 temporadas.
- TNUR integrada nas bases BRIGADA, sem bases independentes.
- Propostas de instalações não aprovadas não são criadas automaticamente.
- A economia não deve fabricar saldos, receitas ou despesas.
- A interface deve priorizar legibilidade móvel e alvos de toque grandes.

## Compilação
Executar o workflow **Valepólis V0.3.0 — Kotlin Android Build** em GitHub Actions. Usa Java 17, Gradle 8.9 e Android API 35. O artefacto esperado é `app-debug.apk` com o respetivo SHA-256.

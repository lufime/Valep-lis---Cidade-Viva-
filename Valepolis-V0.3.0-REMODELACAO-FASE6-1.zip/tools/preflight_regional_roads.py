#!/usr/bin/env python3
"""Auditoria estrutural da rede regional de Valepólis; não substitui teste Godot/runtime."""
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
city_path = root / "systems/ city_3d.gd"
city_path = root / "systems/city_3d.gd"
source = city_path.read_text(encoding="utf-8")
checks = {
    "ponte principal presente": '"Ponte_da_Uniao"' in source and '"Ponte da União"' in source,
    "ponte secundária presente": '"Ponte_do_Horizonte"' in source and '"Ponte do Horizonte"' in source,
    "pontes marcadas como travessias do rio": 'set_meta("crosses_water", "Rio_Estuario_Oeste")' in source and 'set_meta("connects_both_banks", true)' in source,
    "rampas nas duas margens": 'bridge_name + "_Rampa_Oeste"' in source and 'bridge_name + "_Rampa_Leste"' in source and '_bridge_deck(-17.0, "Ponte_da_Uniao")' in source and '_bridge_deck(23.0, "Ponte_do_Horizonte")' in source,
    "corredor regional conecta as pontes": 'Corredor_Regional_Oeste_Norte' in source and 'Corredor_Regional_Oeste_Sul' in source,
    "Santo André do Vale ligado": 'Acesso_Santo_Andre_do_Vale' in source and '"Santo André do Vale"' in source,
    "Portela do Sul ligada": 'Acesso_Portela_do_Sul' in source and '"Portela do Sul"' in source,
    "acessos a vilas/arredores": 'Acesso_Vilas_Sul_Leste' in source and 'Acesso_Vilas_Oeste' in source and '"Vilas e arredores"' in source,
    "vias regionais identificadas": 'set_meta("road_class", "regional")' in source,
    "rotas regionais expostas para consulta": 'func get_regional_destinations()' in source and 'func get_regional_route(origin: String, destination: String)' in source,
    "grafo regional inclui as duas cidades e as duas pontes": all(x in source for x in ['"Santo André do Vale"', '"Portela do Sul"', '"Ponte da União"', '"Ponte do Horizonte"']),
    "construção regional invocada no mapa": '_build_bridges_and_regional_roads()' in source,
}
failed = []
for label, ok in checks.items():
    print(("PASS|" if ok else "FAIL|") + label)
    if not ok:
        failed.append(label)
if failed:
    print("RESULT=FAIL")
    sys.exit(1)
print("NOTE|Auditoria estrutural apenas; colisões geométricas e circulação exigem execução real no Godot.")
print("RESULT=PASS_STATIC_ONLY")

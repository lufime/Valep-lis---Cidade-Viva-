extends StaticBody3D

## Porta deslizante com colisão real. A folha e a CollisionShape3D movem-se juntas.
## require_coop fica ativo apenas nas portas que dependem do puzzle cooperativo.
@export var require_coop: bool = true
@export var slide_distance: float = 2.55
@export var locked: bool = false
var opened: bool = false
var _closed_position: Vector3

func _ready() -> void:
    _closed_position = position

func interact(_actor: Node) -> void:
    var expedition := get_parent()
    if locked:
        _show_door_feedback("PORTA BLOQUEADA — acesso elétrico sem energia ou autorização")
        return
    if require_coop and expedition and not bool(expedition.get("coop_solved")):
        _show_door_feedback("ACESSO BLOQUEADO — os relés A e B têm de ser confirmados")
        return
    if opened:
        _play_door_sound()
        position = _closed_position
        opened = false
        _set_indicator(false)
    else:
        _play_door_sound()
        # Porta exterior abre para o lado; porta principal usa o eixo X por omissão.
        position = _closed_position + Vector3(slide_distance, 0.0, 0.0)
        opened = true
        _set_indicator(true)

func open_for_coop() -> void:
    if opened:
        return
    _play_door_sound()
    position = _closed_position + Vector3(slide_distance, 0.0, 0.0)
    opened = true
    _set_indicator(true)

func _set_indicator(is_open: bool) -> void:
    var indicator := get_node_or_null("LockIndicator") as MeshInstance3D
    if indicator and indicator.material_override is StandardMaterial3D:
        var material := indicator.material_override as StandardMaterial3D
        material.albedo_color = Color(0.12, 1.0, 0.32) if is_open else Color(1.0, 0.12, 0.06)
        material.emission = Color(0.04, 1.0, 0.16) if is_open else Color(1.0, 0.04, 0.015)

func _show_door_feedback(message: String) -> void:
    var world := get_parent()
    if world and world.has_method("_show_toast"):
        world.call("_show_toast", message)

func _play_door_sound() -> void:
    var world := get_parent()
    if world and world.has_method("_play_sfx"):
        world.call("_play_sfx", "door_motor.wav")

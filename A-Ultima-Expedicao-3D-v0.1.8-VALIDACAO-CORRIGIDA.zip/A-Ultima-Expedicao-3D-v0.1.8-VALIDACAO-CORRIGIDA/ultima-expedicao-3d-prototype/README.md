# A Última Expedição 3D — v0.1.8 Validação e Correções de Base

Protótipo experimental Godot 4.5: exploração em primeira pessoa, controlos táteis, painel LAN, relés cooperativos, pistas privadas, votação narrativa, furtividade e entidade reativa.

## Correções nesta versão
- Corrigida uma string inválida no texto de ajuda dos controlos táteis.
- Adicionado painel recolhível “REDE LAN” para criar sessão ou entrar pelo IP do anfitrião (porta UDP 24567), ancorado à direita para se adaptar melhor a ecrãs estreitos.
- O agachamento altera a câmara, velocidade e cápsula de colisão.
- O aviso de interação distingue os relés da porta.
- Relatório de validação em `docs/RELATORIO_VALIDACAO.md`.

## Abrir
Importar a pasta `ultima-expedicao-3d-prototype` no Godot 4.5 e executar `project.godot`.

## Estado dos testes
O ZIP foi verificado. O motor Godot 4.5 não está disponível neste ambiente, pelo que não foi possível compilar/importar ou executar o projeto. A rede entre dispositivos, os RPCs, os controlos táteis em Android e a exportação APK **continuam por validar**. Esta versão não está aprovada para lançamento.

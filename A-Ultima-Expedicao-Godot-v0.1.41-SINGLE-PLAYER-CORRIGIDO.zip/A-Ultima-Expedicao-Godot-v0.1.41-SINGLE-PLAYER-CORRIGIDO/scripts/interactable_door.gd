extends StaticBody3D

var opened := false

func interact(_actor: Node) -> void:
	var expedition := get_parent()
	if expedition and not bool(expedition.get("coop_solved")):
		return
	if opened:
		_play_door_sound()
		position.x = 0.0
		opened = false
	else:
		_play_door_sound()
		position.x = 2.55
		opened = true

func open_for_coop() -> void:
	if opened:
		return
	_play_door_sound()
	position.x = 2.55
	opened = true

func _play_door_sound() -> void:
	var world := get_parent()
	if world and world.has_method("_play_sfx"):
		world.call("_play_sfx", "door_motor.wav")

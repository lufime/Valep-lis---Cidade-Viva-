# A Última Expedição — v0.7.0

## Objetivo desta versão
Preparar a primeira etapa de validação do multijogador local: validação de mensagens recebidas, ações permitidas, estado de partida e sequência de ações. A campanha e as mecânicas de investigação existentes são preservadas.

## Alterações concretas
- Novo módulo `www/js/multiplayer-protocol.js`, usado pela interface e pelos testes.
- Validação de tipo/tamanho das mensagens e limites básicos do estado recebido.
- Lista explícita de ações permitidas e validação de sequência crescente.
- Sanitização do texto do chat para limitar tamanho e dados exibidos.
- `npm test` com testes automatizados do protocolo. O workflow executa os testes antes de tentar gerar a APK.
- Workflow atualizado para v0.7.0.

## Limitações conhecidas
- Os testes automatizados não substituem testes em Android real.
- A descoberta/ligação Nearby, atribuição definitiva de um dispositivo a um jogador, sincronização concorrente, reconexão e experiência de 2–10 telemóveis ainda precisam de validação em dispositivos reais.
- Não afirmar que a APK está compilada nem que o multijogador está funcional até o workflow terminar com sucesso e o jogo ser testado em pelo menos dois Android sem Internet.

## Validar
1. Colocar este ZIP no repositório GitHub.
2. Executar o workflow `.github/workflows/android-apk.yml`.
3. Confirmar que a etapa `Testes automatizados do protocolo` passa antes da compilação Android.
4. Se a APK for gerada, instalar em dois Android, ligar sem Internet e verificar chat, votação, prova recolhida, estado de missão e reconexão.

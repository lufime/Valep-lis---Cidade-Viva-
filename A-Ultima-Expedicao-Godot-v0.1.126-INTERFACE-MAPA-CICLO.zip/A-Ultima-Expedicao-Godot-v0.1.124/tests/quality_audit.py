#!/usr/bin/env python3
"""Static project audit for A Última Expedição. Does not replace Godot runtime tests."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
checks: list[str] = []

def check(condition: bool, message: str) -> None:
    if condition:
        checks.append(message)
    else:
        errors.append(message)

# Essential files
for rel in [
    "project.godot", "scenes/Boot.tscn", "scenes/Expedition.tscn",
    "scripts/boot.gd", "scripts/expedition.gd", "scripts/player_controller.gd",
    "scripts/experiment_clue.gd", "scripts/evidence_synthesis_console.gd",
    "scripts/secret_experiment_door.gd", "export_presets.cfg",
]:
    check((ROOT / rel).is_file(), f"ficheiro essencial: {rel}")

check((ROOT / "assets/station_corridor_kit.glb").is_file(), "kit GLB modular para corredores e salas")

# Validate every literal res:// reference found in Godot source and scene files.
refs: set[str] = set()
for path in list(ROOT.rglob("*.gd")) + list(ROOT.rglob("*.tscn")) + list(ROOT.rglob("*.tres")) + [ROOT / "project.godot"]:
    if not path.is_file():
        continue
    try:
        source = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        continue
    refs.update(re.findall(r'res://[^"\s)]+', source))
for ref in sorted(refs):
    # Some audio paths are assembled dynamically as res://audio/ + filename.
    if ref.endswith("/"):
        continue
    target = ROOT / ref.removeprefix("res://")
    check(target.exists(), f"referência de recurso: {ref}")

expedition = (ROOT / "scripts/expedition.gd").read_text(encoding="utf-8")
check('const SECRET_COMBINATION := "7314"' in expedition, "combinação lógica 7314")
check("if clue_id < 1 or clue_id > 12 or experiment_clues_found.has(clue_id):" in expedition, "validação das 12 provas exteriores")
check("if evidence_id < 16 or evidence_id > 20 or special_investigation_found.has(evidence_id):" in expedition, "validação das cinco provas especiais")
check("if evidence_id < 1 or evidence_id > 3 or secret_archive_evidence_found.has(evidence_id):" in expedition, "validação das três provas da sala secreta")
check("if experiment_clues_found.size() < 12" in expedition and "if secret_archive_evidence_found.size() < 3" in expedition and "if special_investigation_found.size() < 5" in expedition, "extração exige as 20 provas previstas (12 exteriores, 3 secretas, 5 especiais)")
check("func _server_validate_secret_combination" in expedition and 'entered_code != SECRET_COMBINATION' in expedition, "validação do código no servidor")
check('func _update_entity_ai' in expedition and 'if not multiplayer.is_server() or entity_presence == null:' in expedition, "IA da criatura autoritativa")
entity_ai_start = expedition.find('func _update_entity_ai')
entity_ai_end = expedition.find('\nfunc ', entity_ai_start + 1)
entity_ai = expedition[entity_ai_start:entity_ai_end]
check(entity_ai.find('if entity_ai_state == "OBSERVED":') < entity_ai.find('var observed := _is_entity_observed(player)'), "estado OBSERVED processado antes de nova deteção")
check('entity_hidden_time = maxf(0.0, entity_hidden_time - delta)' in entity_ai and 'entity_presence.visible = true' in entity_ai, "temporizador de desaparecimento termina e criatura reaparece")
check((ROOT / "docs/RELATORIO-V0.1.98-CICLO-OBSERVACAO-CRIATURA.md").is_file(), "relatório V0.1.98 ciclo de observação")
# V0.1.99: sliding doors animate the same StaticBody3D that owns the collision.
door_script = (ROOT / "scripts/interactable_door.gd").read_text(encoding="utf-8")
door = door_script
check('func _set_opened(want_open: bool)' in door_script and 'create_tween()' in door_script and 'tween_property(self, "position", target' in door_script, "porta desliza gradualmente com a colisão no mesmo corpo")
check('func _find_expedition()' in door_script and 'current = current.get_parent()' in door_script, "porta encontra a expedição através dos nós ancestrais")
check('func open_for_coop()' in door_script and '_set_opened(true)' in door_script, "abertura cooperativa usa o mesmo movimento da porta")
check('move_duration: float = 0.42' in door_script and '_door_tween.kill()' in door_script, "animação de porta tem duração configurável e cancela movimento anterior")
check('0.1.124' in (ROOT / "scripts/VERSION.txt").read_text(encoding="utf-8"), "versão dos scripts V0.1.124")
check("entity_presence = CharacterBody3D.new()" in expedition and "creature_body.move_and_slide()" in expedition, "criatura usa corpo físico e move_and_slide")
check('collision_shape.name = "EntityCollisionShape"' in expedition and "entity_presence.add_child(collision_shape)" in expedition, "colisão da criatura ligada ao CharacterBody3D")
check('func _calculate_entity_path(target_world: Vector3) -> Array[Vector3]:' in expedition and 'var astar := AStar2D.new()' in expedition, 'navegação A* recalcula percurso da criatura')
check('astar.set_point_disabled(point_id, true)' in expedition and 'space.intersect_shape(query, 1)' in expedition, 'grelha de navegação bloqueia células com colisões físicas')
check('astar.connect_points(point_id, right_id, true)' in expedition and 'astar.connect_points(point_id, down_id, true)' in expedition and 'func _nearest_entity_path_cell' in expedition, 'rota evita diagonais e procura células transitáveis')
check('entity_path_refresh_timer = ENTITY_PATH_REFRESH_SECONDS' in expedition and 'ENTITY_PATH_REFRESH_SECONDS := 1.0' in expedition, 'rota renovada para detetar alterações nas portas')
check('var has_navigation_target := false' in expedition and 'movement_target = entity_path[entity_path.size() - 1]' in expedition, 'criatura não abandona a rota para avançar em linha direta')
check('if has_navigation_target and offset.length_squared() > 0.0001' in expedition, 'criatura fica parada se A* não encontrar rota válida')
check('build/A-Ultima-Expedicao-v0.1.124-android.apk' in (ROOT / 'export_presets.cfg').read_text(encoding='utf-8'), 'destino de exportação Android corresponde à versão')
check('func request_door_toggle(door: Node, actor: Node)' in expedition and 'rpc_id(1, "server_toggle_door", door_path)' in expedition, "pedido de porta encaminhado à autoridade no multijogador")
check('func _server_toggle_door(door_path: NodePath, peer_id: int)' in expedition and 'distance_to(door.global_position) > 3.6' in expedition, "servidor valida proximidade antes de alterar porta")
check('func client_apply_door_state(door_path: NodePath, want_open: bool)' in expedition and 'rpc("client_apply_door_state", door_path, target_open)' in expedition, "estado da porta replicado a todos os clientes")
check('expedition.call("request_door_toggle", self, actor)' in door and 'func apply_network_state(want_open: bool)' in door, "interação da porta usa estado replicado sem recursão RPC")
check('func _assign_hidden_roles()' in expedition and 'func receive_secret_role' in expedition, "atribuição e entrega privada dos papéis")
check('func client_sync_secret_progress' in expedition and 'request_initial_session_state' in expedition, "sincronização do progresso para entrada tardia")
check('func _reveal_secret_access()' in expedition and 'if not multiplayer.is_server():' in expedition, "consola revelada apenas pela autoridade")
check('func _server_try_open_secret_door()' in expedition and 'if not evidence_synthesis_complete:' in expedition, "porta protegida por síntese")

# V0.1.71: fog-of-war and end-to-end logical audit presence.
mini_map = (ROOT / "scripts/mini_map.gd").read_text(encoding="utf-8")
check("FOG_COLS" in mini_map and "FOG_ROWS" in mini_map, "grelha de exploração do minimapa")
check("_update_exploration()" in mini_map and "explored_cells" in mini_map, "descoberta progressiva do mapa")
check("const WORLD_MIN_Z := -217.3" in mini_map and "const WORLD_MAX_Z := 15.3" in mini_map, "limites do minimapa cobrem as dez zonas")
check("func _fit_world_rect(panel: Rect2)" in mini_map, "minimapa preserva escala X/Z")
check('"%02d" % zone_number' in mini_map and 'for i in range(8)' in mini_map, "minimapa representa Zonas 03–10")
check("_draw_fog_of_war(r)" not in mini_map, "planta estrutural visível desde o início")
boot = (ROOT / "scripts/boot.gd").read_text(encoding="utf-8")
check('res://scenes/Expedition.tscn' in boot and 'game.name = "ExpeditionRuntime"' in boot, "Boot liga à cena principal de expedição")
check('set_script(load("res://scripts/mini_map.gd"))' in expedition, "HUD instancia o minimapa pelo recurso Godot")
check('ancestor.get_node_or_null("Player")' in mini_map, "minimapa resolve o jogador na árvore de cena")
check('func _build_world_foundation()' in expedition and 'ContinuousGroundCollision' in expedition, "gerador cria chão físico contínuo")
check((ROOT / "scripts/RELATORIO-AUDITORIA-LOGICA-V0.1.71.md").is_file(), "relatório de auditoria lógica ponta a ponta")
check('func _server_collect_experiment_clue(clue_id: int, peer_id: int)' in expedition and 'actor.global_position.distance_to(target.global_position) > 3.2' in expedition, "recolha de provas validada por proximidade no servidor")
check('actor.global_position.distance_to(secret_synthesis_console.global_position) > 4.0' in expedition, "consola VANTHIS validada por proximidade")
check('actor.global_position.distance_to(secret_experiment_door.global_position) > 4.0' in expedition, "porta secreta validada por proximidade")
check('if not _is_solo_session() and not multiplayer.is_server():' in expedition and 'func _complete_extraction()' in expedition, "final da missão protegido pela autoridade do servidor")
check('func _try_resolve_decision()' in expedition and 'if received < eligible_ids.size():' in expedition, "votação aguarda todos os jogadores ligados")
check('network_peer.get_peers().has(peer_id)' in expedition, "votação rejeita participantes que não estão ligados")
check('_try_resolve_decision()' in expedition[expedition.find('func _on_peer_disconnected'):expedition.find('func _process')], "quórum recalculado após desconexão")
check('func _all_surviving_players_reached_landing_zone()' in expedition, "extração exige todos os sobreviventes ativos")
check('if eliminated_peers.has(peer_id):' in expedition[expedition.find('func _server_start_extraction'):expedition.find('func _update_extraction_sequence')], "jogador eliminado não pode iniciar extração")
check('return active_survivors > 0' in expedition, "vitória impossível sem sobreviventes")
check((ROOT / "docs/RELATORIO-V0.1.97-AUDITORIA-LOGICA.md").is_file(), "relatório da auditoria V0.1.97")

# Dynamic audio paths: all sounds referenced by string-based audio loaders must exist.
for sound in ["ambient_tension.wav", "polar_wind_loop.wav", "station_hum_loop.wav", "metal_creak.wav", "ice_stress_crack.wav", "heartbeat_low.wav", "door_open.wav", "radio_static.wav"]:
    check((ROOT / "audio" / sound).is_file(), f"ficheiro de áudio: {sound}")

if errors:
    print(f"FAIL: {len(errors)} falha(s), {len(checks)} verificações aprovadas")
    for item in errors:
        print("[FAIL] " + item)
    for item in checks:
        print("[PASS] " + item)
    sys.exit(1)
print(f"PASS: {len(checks)} verificações estáticas")
for item in checks:
    print("[PASS] " + item)
print("NOTA: não valida sintaxe GDScript em runtime, gameplay, rede real ou exportação APK.")


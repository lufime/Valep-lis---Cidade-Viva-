# Valepólis — Cidade Viva V0.3.0

Projeto de jogo para Godot 4.5, com alvo Android.

## Estrutura do repositório

- `project.godot`, `Main.tscn`, `main.gd`: entrada principal do jogo.
- `City3D.tscn`: cena 3D da cidade.
- `systems/`: sistemas e lógica de simulação.
- `data/`: catálogos, configurações e dados usados pelo jogo.
- `assets/`, `images/`: recursos visuais.
- `character_generator/`: geração de personagens.
- `tools/`: preflight e ferramentas de validação.
- `addons/valepolis_terrain/`: relevo procedural próprio.
- `addons/valepolis_3d_studio/`: geração procedural de personagens e recursos 3D diretamente no Godot.
- `docs/reports/`: relatórios de auditoria e preflight.
- `docs/audits/`: resultados e manifestos de auditoria/consolidação.
- `docs/specifications/`: regras e documentação funcional.
- `docs/manifests/`: manifestos de recursos e geradores.
- `.github/workflows/`: automações GitHub Actions.

## Abrir no Godot

Importa a pasta que contém `project.godot`. Não abras uma subpasta como se fosse o projeto.

## Upload para GitHub

Extrai o ZIP e carrega o conteúdo desta pasta para a raiz do repositório, mantendo a estrutura das pastas. Não carregues o ZIP como único ficheiro.

## Estado de validação

A organização de ficheiros e as verificações estáticas não substituem a importação/execução no Godot nem a compilação real do APK. Confirma esses passos em GitHub Actions antes de considerar a versão validada.


## Relevo geográfico próprio

O projeto usa `addons/valepolis_terrain/` para gerar automaticamente a costa norte, o estuário oeste, a planície urbana central, as montanhas orientais e as colinas a sul. Ver `docs/VALEPOLIS_TERRAIN_GEOGRAFIA.md`. A validação de runtime Godot/Android continua pendente.


## Atualização de integração 3D (auditoria do pacote)
- A secção **Personagem** usa uma pré-visualização 3D procedural gerada em runtime, em vez dos retratos PNG antigos.
- A secção **Mapa** deixou de carregar o painel PNG antigo.
- Estradas locais, passeios, parques, edifícios e instalações amostram a altura do addon `valepolis_terrain` ao posicionar a geometria. As vias longas continuam a usar um ponto de amostragem no centro; a adaptação contínua das suas superfícies ao terreno é uma limitação conhecida.
- Removidos os PNGs placeholder dedicados a personagem e aos painéis antigos Mapa/Personagem; recursos de entidades e restantes painéis foram preservados.
- A execução real no Godot 4.5 e a exportação APK continuam por validar neste ambiente.


## Correção integrada de pré-visualização da personagem (2026-10-10)

- A pré-visualização da personagem usa um `World3D` dedicado no `SubViewport`, câmara nomeada com planos near/far explícitos e viewport com resolução aumentada para reduzir o risco de apresentar apenas a cor de fundo em Android.
- O painel do perfil passa a distinguir o caso de personagem selecionada com perfil ainda vazio.
- Mantém-se a geração procedural nativa; não requer assets externos.
- O preflight estático passou (18 PASS, 0 FAIL). Godot 4.x não está instalado neste ambiente, pelo que runtime e exportação APK continuam por validar.
## Interface com cidade 3D viva

A interface utiliza `City3D.tscn` como fundo 3D procedural atrás dos ecrãs, em vez de depender exclusivamente de uma imagem estática. O viewport adapta a resolução ao ecrã e limita a resolução máxima para reduzir o consumo de memória em Android. A imagem `images/intro_valepolis.png` mantém-se como recurso alternativo do projeto, mas deixa de ser o fundo do menu inicial.


## Circulação V16 — integração PRE-FLIGHT
A V16 integra `tools/preflight_regional_roads.py` no runner `tools/preflight.py` e acrescenta verificações estáticas para a API de diagnóstico de rotas. Esta etapa não equivale a teste de runtime nem validação física das estradas. Ver `README-CIRCULACAO-V16.md`.


## Limpeza estática V21 (2026-10-11)

Foi removido o ficheiro de workflow alternativo explicitamente inativo. O workflow ativo em `.github/workflows/build.yml` e os addons necessários foram preservados. A auditoria estática teve 19 PASS, 0 FAIL e 3 SKIP; a validação Godot/APK continua pendente. Ver `docs/reports/AUDITORIA_LIMPEZA_CODIGO_V030_V21.md`.

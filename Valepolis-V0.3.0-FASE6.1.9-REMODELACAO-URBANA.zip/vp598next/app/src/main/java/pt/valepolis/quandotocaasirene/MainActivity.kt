package pt.valepolis.quandotocaasirene

import android.app.Activity
import android.util.Log
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.absoluteValue
import android.view.Gravity
import android.view.View
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale

/**
 * Fase 6.1.1: reforço visual da rede viária proposta da rede viária derivada dos centros dos bairros.
 * Não representa ainda o motor 3D nem os sistemas operacionais completos.
 */
class MainActivity : Activity() {
    private val bg = Color.rgb(5, 20, 30)
    private val panel = Color.rgb(10, 34, 49)
    private val panelAlt = Color.rgb(16, 46, 62)
    private val accent = Color.rgb(239, 202, 94)
    private val muted = Color.rgb(190, 205, 214)
    private lateinit var content: LinearLayout
    private var section = "PAINEL"
    private var mapZoom = 1.0f
    private var mapPanX = 0f
    private var mapPanY = 0f
    private val localePt = Locale("pt", "PT")
    private val numberFormat: NumberFormat = NumberFormat.getIntegerInstance(localePt)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        showShell()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(
        text: String,
        size: Float,
        color: Int = Color.WHITE,
        bold: Boolean = false
    ): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        setPadding(dp(8), dp(8), dp(8), dp(8))
        gravity = Gravity.CENTER_VERTICAL
        setLineSpacing(dp(2).toFloat(), 1.05f)
        contentDescription = text
    }

    private fun showShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        root.addView(label("VALEPÓLIS — CIDADE VIVA", 24f, accent, true))
        root.addView(label("V0.3.0 · Kotlin nativo · Fase 6.1.9 · BUILD 619", 15f, muted))

        val scroller = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(12))
        }
        scroller.addView(content)
        root.addView(scroller, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(4), 0, 0)
        }
        listOf(
            listOf("PAINEL", "BAIRROS"),
            listOf("OPERAÇÕES", "EQUIPAS"),
            listOf("VEÍCULOS", "INSTALAÇÕES"),
            listOf("MAPA 3D")
        ).forEach { names ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            names.forEach { name ->
                row.addView(navButton(name), LinearLayout.LayoutParams(0, dp(56), 1f).apply {
                    marginEnd = dp(4)
                    bottomMargin = dp(4)
                })
            }
            nav.addView(row)
        }
        root.addView(nav)
        setContentView(root)
        renderSection()
    }

    private fun navButton(name: String) = Button(this).apply {
        text = name
        textSize = 15f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(if (section == name) Color.rgb(100, 78, 29) else panel)
        setPadding(dp(6), dp(6), dp(6), dp(6))
        minHeight = dp(54)
        minWidth = dp(0)
        setOnClickListener {
            section = name
            renderSection()
            (content.parent as? ScrollView)?.post { (content.parent as? ScrollView)?.scrollTo(0, 0) }
        }
    }

    private fun card(title: String): LinearLayout {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(panel)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        layout.addView(label(title, 22f, accent, true))
        return layout
    }

    private fun addCard(view: View) {
        content.addView(view, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(12)
        })
    }

    private fun renderSection() {
        content.removeAllViews()
        when (section) {
            "BAIRROS" -> renderNeighborhoods()
            "MAPA 3D" -> render3DMap()
            "OPERAÇÕES" -> {
                val c = card("CENTRO DE OPERAÇÕES")
                c.addView(label(
                    "Módulo em migração. Esta versão ainda não despacha ocorrências reais.",
                    17f
                ))
                c.addView(label(
                    "Regra de integridade: uma missão só poderá ser despachada quando existir uma equipa e uma viatura registadas, disponíveis e compatíveis.",
                    16f, muted
                ))
                addCard(c)
            }
            "EQUIPAS" -> {
                val c = card("EQUIPAS E SERVIÇOS")
                c.addView(label(
                    "BRIGADA e TNUR\nTNUR permanece integrada nas bases BRIGADA; não são criadas bases TNUR independentes.",
                    17f
                ))
                c.addView(label(
                    "Os efetivos e a disponibilidade só serão apresentados quando os registos operacionais forem ligados e validados.",
                    16f, muted
                ))
                addCard(c)
            }
            "VEÍCULOS" -> {
                val c = card("GESTÃO DE VIATURAS")
                c.addView(label(
                    "O catálogo de veículos ainda não está ligado ao despacho. Não são atribuídos veículos fictícios nem disponibilidades presumidas.",
                    17f
                ))
                addCard(c)
            }
            "INSTALAÇÕES" -> {
                val c = card("INSTALAÇÕES")
                c.addView(label(
                    "Os registos de instalações estão incluídos nos dados do projeto, mas a visualização e a validação operacional ainda precisam de integração.",
                    17f
                ))
                c.addView(label(
                    "Propostas não aprovadas não são tratadas como instalações oficiais.",
                    16f, muted
                ))
                addCard(c)
            }
            else -> renderDashboard()
        }
    }

    private fun render3DMap() {
        val info = card("MAPA 3D — PROTÓTIPO NATIVO")
        info.addView(label(
            "Vista 3D experimental baseada nos polígonos territoriais V0.3.0, com limites dos bairros, costa, estuário, relevo ilustrativo e volumes urbanos. A rede viária real e os dados topográficos reais continuam pendentes.",
            16f, muted
        ))
        addCard(info)
        val geography = card("REFERÊNCIAS GEOGRÁFICAS")
        geography.addView(label(
            "NORTE · MAR  |  OESTE · ESTUÁRIO  |  ESTE · CADEIA MONTANHOSA / PEDRAVORA",
            13f, muted
        ))
        geography.addView(label(
            "Os polígonos dos 25 bairros são preservados. A rede viária detalhada e os dados topográficos reais continuam pendentes.",
            12f, muted
        ))
        addCard(geography)
        val status = label(
            "A iniciar renderizador OpenGL… Se a cena não aparecer, esta indicação ajuda a distinguir falha de inicialização.",
            15f, muted
        )
        val statusCard = card("ESTADO DO RENDERIZADOR")
        statusCard.addView(status)
        addCard(statusCard)
        val surface = object : GLSurfaceView(this) {
            private var lastX = 0f
            private var lastY = 0f
            private var lastPinchDistance = 0f
            override fun onTouchEvent(event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        lastX = event.x
                        lastY = event.y
                        lastPinchDistance = 0f
                        return true
                    }
                    MotionEvent.ACTION_POINTER_DOWN -> {
                        if (event.pointerCount >= 2) lastPinchDistance = pointerDistance(event)
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (event.pointerCount >= 2) {
                            val distance = pointerDistance(event)
                            if (lastPinchDistance > 0f && distance > 0f) {
                                val ratio = distance / lastPinchDistance
                                mapCameraDistance = (mapCameraDistance / ratio.coerceIn(0.88f, 1.14f)).coerceIn(6.5f, 90f)
                            }
                            lastPinchDistance = distance
                        } else {
                            val deltaX = event.x - lastX
                            val deltaY = event.y - lastY
                            // Touch drag: horizontal movement rotates the map;
                            // vertical movement pans the camera on the terrain.
                            // MotionEvent has no isShiftPressed property on Android.
                            mapRotation += deltaX * 0.008f
                            mapCameraPanZ = (mapCameraPanZ + deltaY * 0.008f).coerceIn(-8f, 8f)
                            lastX = event.x
                            lastY = event.y
                        }
                        return true
                    }
                    MotionEvent.ACTION_POINTER_UP -> {
                        lastPinchDistance = 0f
                        return true
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        lastPinchDistance = 0f
                        return true
                    }
                }
                return true
            }
            private fun pointerDistance(event: MotionEvent): Float {
                if (event.pointerCount < 2) return 0f
                val dx = event.getX(0) - event.getX(1)
                val dy = event.getY(0) - event.getY(1)
                return kotlin.math.sqrt(dx * dx + dy * dy)
            }
        }.apply {
            // Corrigir a composição SurfaceView: camada de media sobre as vistas normais,
            // sem colocar a superfície acima de toda a janela (o que cortava a navegação).
            setZOrderOnTop(false)
            setZOrderMediaOverlay(true)
            holder.setFormat(PixelFormat.OPAQUE)
            setEGLContextClientVersion(2)
            setRenderer(Valepolis3DRenderer { message ->
                runOnUiThread { status.text = message }
            })
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            // Não desenhar uma cor de fundo da View por cima da superfície OpenGL.
            setBackgroundColor(Color.TRANSPARENT)
            contentDescription = "Vista 3D experimental de Valepólis; arrasta para rodar"
        }
        content.addView(surface, LinearLayout.LayoutParams(-1, dp(400)).apply {
            bottomMargin = dp(12)
            topMargin = dp(4)
        })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("↶", "−", "+", "↷", "Recentrar").forEach { text ->
            val b = Button(this).apply {
                this.text = text
                textSize = if (text == "Recentrar") 12f else 20f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(panelAlt)
                contentDescription = when (text) {
                    "↶" -> "Rodar à esquerda"
                    "↷" -> "Rodar à direita"
                    "+" -> "Aproximar mapa"
                    "−" -> "Afastar mapa"
                    else -> "Recentrar câmara"
                }
                setOnClickListener {
                    when (text) {
                        "↶" -> mapRotation -= 0.18f
                        "↷" -> mapRotation += 0.18f
                        "+" -> mapCameraDistance = (mapCameraDistance - 2.0f).coerceAtLeast(6.5f)
                        "−" -> mapCameraDistance = (mapCameraDistance + 2.0f).coerceAtMost(90f)
                        else -> { mapRotation = 0f; mapCameraDistance = 31f; mapCameraPanX = 0f; mapCameraPanZ = 0f }
                    }
                }
            }
            controls.addView(b, LinearLayout.LayoutParams(0, dp(52), if (text == "Recentrar") 1.7f else 1f).apply { marginEnd = dp(5) })
        }
        addCard(controls)
        addCard(label("Controlos: arrasta para rodar/deslocar; usa dois dedos para aproximar ou afastar. Zoom reforçado: distância 6,5–90; passos finos e pinça suavizada para permitir aproximação sem saltos bruscos. O relevo continua ilustrativo e o APK mantém-se bloqueado.", 14f, muted))
    }

    private var mapRotation = 0f
    private var mapCameraDistance = 31f
    private var mapCameraPanX = 0f
    private var mapCameraPanZ = 0f

    /**
     * Protótipo OpenGL ES 2.0 sem dependência de motor externo.
     * A geometria é gerada proceduralmente; não pretende reproduzir a malha final da cidade.
     */
    private data class Mesh(val vertices: FloatArray, val color: FloatArray, val mode: Int = GLES20.GL_TRIANGLES)

    private inner class Valepolis3DRenderer(
        private val reportStatus: (String) -> Unit
    ) : GLSurfaceView.Renderer {
        private val vertexShader = """
            attribute vec3 aPosition;
            uniform mat4 uMVP;
            void main() { gl_Position = uMVP * vec4(aPosition, 1.0); }
        """.trimIndent()
        private val fragmentShader = """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """.trimIndent()
        private var program = 0
        private var positionHandle = 0
        private var mvpHandle = 0
        private var colorHandle = 0
        private val projection = FloatArray(16)
        private val view = FloatArray(16)
        private val model = FloatArray(16)
        private val mvp = FloatArray(16)
        private val identity = FloatArray(16)
        private val meshes = mutableListOf<Mesh>()
        private var frameCount = 0
        private var surfaceWidth = 0
        private var surfaceHeight = 0
        private var statusSentForFirstFrame = false

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0.02f, 0.07f, 0.10f, 1f)
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            GLES20.glDisable(GLES20.GL_CULL_FACE)
            GLES20.glDisable(GLES20.GL_BLEND)
            frameCount = 0
            statusSentForFirstFrame = false
            try {
                program = createProgram(vertexShader, fragmentShader)
                positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
                mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
                colorHandle = GLES20.glGetUniformLocation(program, "uColor")
                Matrix.setIdentityM(identity, 0)
                buildMeshes()
                Log.i("Valepolis3D", "Renderer inicializado; malhas=${meshes.size}; versão=6.1")
                reportStatus("BUILD 619 · OpenGL inicializado · ${meshes.size} malhas preparadas; à espera do primeiro frame.")
            } catch (error: Exception) {
                program = 0
                // Diagnóstico visível: não deixar a falha parecer apenas um mapa vazio.
                GLES20.glClearColor(0.38f, 0.025f, 0.035f, 1f)
                Log.e("Valepolis3D", "Falha ao inicializar renderizador OpenGL", error)
                reportStatus("BUILD 619 · FALHA OPENGL: ${error.message ?: error.javaClass.simpleName}")
            }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            surfaceWidth = width
            surfaceHeight = height
            GLES20.glViewport(0, 0, width, height)
            val ratio = width.toFloat() / height.coerceAtLeast(1)
            Matrix.perspectiveM(projection, 0, 42f, ratio, 0.1f, 220f)
            Log.i("Valepolis3D", "Superfície OpenGL: ${width}x${height}")
            reportStatus("BUILD 619 · SUPERFÍCIE OK ${width}×${height}px · malhas=${meshes.size} · cena real ativa")
        }

        override fun onDrawFrame(gl: GL10?) {
            frameCount++
            GLES20.glClearColor(0.02f, 0.07f, 0.10f, 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            if (program == 0) {
                GLES20.glClearColor(0.38f, 0.025f, 0.035f, 1f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
                reportStatus("BUILD 619 · ERRO: programa OpenGL inválido")
                return
            }
            if (meshes.isEmpty()) {
                GLES20.glClearColor(0.32f, 0.03f, 0.03f, 1f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
                reportStatus("BUILD 619 · ERRO: nenhuma malha carregada")
                return
            }
            Matrix.setLookAtM(view, 0, mapCameraPanX, 0.20f + mapCameraDistance * 0.58f, mapCameraDistance, mapCameraPanX, 0.20f, mapCameraPanZ, 0f, 1f, 0f)
            val rotation = FloatArray(16)
            Matrix.setRotateM(rotation, 0, mapRotation * 57.2958f, 0f, 1f, 0f)
            val rotatedView = FloatArray(16)
            Matrix.multiplyMM(rotatedView, 0, view, 0, rotation, 0)
            GLES20.glUseProgram(program)
            var drawCalls = 0
            var vertexCount = 0
            meshes.forEach { mesh ->
                val buffer = ByteBuffer.allocateDirect(mesh.vertices.size * 4)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer()
                buffer.put(mesh.vertices).position(0)
                Matrix.setIdentityM(model, 0)
                Matrix.multiplyMM(mvp, 0, rotatedView, 0, model, 0)
                Matrix.multiplyMM(mvp, 0, projection, 0, mvp, 0)
                GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
                GLES20.glUniform4fv(colorHandle, 1, mesh.color, 0)
                GLES20.glEnableVertexAttribArray(positionHandle)
                GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, buffer)
                GLES20.glDrawArrays(mesh.mode, 0, mesh.vertices.size / 3)
                GLES20.glDisableVertexAttribArray(positionHandle)
                drawCalls++
                vertexCount += mesh.vertices.size / 3
            }
            val glError = GLES20.glGetError()
            if (!statusSentForFirstFrame || frameCount % 120 == 0) {
                statusSentForFirstFrame = true
                val message = "BUILD 619 · FRAME=$frameCount · CENA REAL · camadas/ malhas=${meshes.size} · chamadas=$drawCalls · vértices=$vertexCount · superfície=${surfaceWidth}×${surfaceHeight} · glError=0x${glError.toString(16)}"
                Log.i("Valepolis3D", message)
                reportStatus(message)
            }
            if (glError != GLES20.GL_NO_ERROR) {
                Log.e("Valepolis3D", "Erro OpenGL na cena real: 0x${glError.toString(16)}")
                reportStatus("BUILD 619 · ERRO OPENGL: 0x${glError.toString(16)}")
            }
        }

        private fun buildMeshes() {
            meshes.clear()

            // Carregar polígonos territoriais reais do registo V0.3.0.
            // As coordenadas do JSON são normalizadas para a área de renderização,
            // preservando a topologia e os 25 limites existentes.
            val boundaryRoot = readBoundaryData()
            val neighborhoods = boundaryRoot?.optJSONArray("neighborhoods")
            val bounds = boundaryRoot?.optJSONObject("world_bounds_xz")
            val minX = bounds?.optDouble("min_x", -52.5)?.toFloat() ?: -52.5f
            val maxX = bounds?.optDouble("max_x", 52.5)?.toFloat() ?: 52.5f
            val minZ = bounds?.optDouble("min_z", -49.16)?.toFloat() ?: -49.16f
            val maxZ = bounds?.optDouble("max_z", 49.16)?.toFloat() ?: 49.16f

            fun sx(x: Float) = -9.6f + ((x - minX) / (maxX - minX).coerceAtLeast(0.001f)) * 19.2f
            fun sz(z: Float) = -8.8f + ((z - minZ) / (maxZ - minZ).coerceAtLeast(0.001f)) * 17.6f

            // Altimetria procedural contínua: ondulação interior e encosta oriental
            // com cristas/vales. Não substitui dados topográficos reais, mas cria
            // relevo geométrico efetivo em vez de uma superfície plana.
            fun terrainHeight(x: Float, z: Float): Float {
                val east = ((x + 1.0f) / 10.0f).coerceIn(0f, 1f)
                val ridge = kotlin.math.exp((-((x - 7.9f) * (x - 7.9f)) / 2.8f).toDouble()).toFloat()
                val ridgeVariation = 0.62f + 0.24f * kotlin.math.sin(z * 1.12f) +
                    0.14f * kotlin.math.sin(z * 2.65f + 0.8f)
                val hills = 0.10f * kotlin.math.sin(x * 0.72f + z * 0.31f) +
                    0.075f * kotlin.math.cos(z * 0.91f - x * 0.22f) +
                    0.045f * kotlin.math.sin(x * 1.7f + z * 1.3f)
                val coastalFalloff = ((z + 8.8f) / 3.8f).coerceIn(0f, 1f)
                return (hills * coastalFalloff + ridge * ridgeVariation * east * 1.5f).coerceAtLeast(0f)
            }

            // Malha contínua de terreno (80 x 80 células), base real do relevo.
            // Os bairros são desenhados por cima, acompanhando a altimetria calculada.
            run {
                val terrain = mutableListOf<Float>()
                val cells = 80
                for (iz in 0 until cells) {
                    val z0 = -8.8f + 17.6f * iz / cells
                    val z1 = -8.8f + 17.6f * (iz + 1) / cells
                    for (ix in 0 until cells) {
                        val x0 = -9.6f + 19.2f * ix / cells
                        val x1 = -9.6f + 19.2f * (ix + 1) / cells
                        terrain.addAll(listOf(
                            x0, terrainHeight(x0,z0), z0, x1, terrainHeight(x1,z0), z0,
                            x1, terrainHeight(x1,z1), z1,
                            x0, terrainHeight(x0,z0), z0, x1, terrainHeight(x1,z1), z1,
                            x0, terrainHeight(x0,z1), z1
                        ))
                    }
                }
                meshes.add(Mesh(terrain.toFloatArray(), floatArrayOf(0.19f, 0.34f, 0.23f, 1f)))
            }

            // Superfície base: polígonos de bairro desenhados individualmente,
            // em vez da antiga grelha artificial de ruas e blocos repetidos.
            if (neighborhoods != null && neighborhoods.length() == 25) {
                val palette = arrayOf(
                    floatArrayOf(0.22f,0.42f,0.31f,1f),
                    floatArrayOf(0.25f,0.45f,0.34f,1f),
                    floatArrayOf(0.28f,0.44f,0.32f,1f),
                    floatArrayOf(0.20f,0.39f,0.30f,1f),
                    floatArrayOf(0.31f,0.47f,0.35f,1f)
                )
                for (i in 0 until neighborhoods.length()) {
                    val district = neighborhoods.optJSONObject(i) ?: continue
                    val polygon = district.optJSONArray("boundary_xz") ?: continue
                    if (polygon.length() < 3) continue
                    val pts = mutableListOf<Pair<Float, Float>>()
                    for (j in 0 until polygon.length()) {
                        val point = polygon.optJSONObject(j) ?: continue
                        pts.add(sx(point.optDouble("x", 0.0).toFloat()) to
                                sz(point.optDouble("z", 0.0).toFloat()))
                    }
                    if (pts.size < 3) continue

                    // Fan triangulation; estes polígonos Voronoi são convexos.
                    val triangles = mutableListOf<Float>()
                    val centerX = pts.map { it.first }.average().toFloat()
                    val centerZ = pts.map { it.second }.average().toFloat()
                    for (j in pts.indices) {
                        val a = pts[j]
                        val b = pts[(j + 1) % pts.size]
                        triangles.addAll(listOf(centerX, terrainHeight(centerX, centerZ) + 0.025f, centerZ,
                            a.first, terrainHeight(a.first, a.second) + 0.025f, a.second,
                            b.first, terrainHeight(b.first, b.second) + 0.025f, b.second))
                    }
                    meshes.add(Mesh(triangles.toFloatArray(), palette[i % palette.size]))

                    // Contorno fino para que cada limite de bairro seja visível.
                    val outline = mutableListOf<Float>()
                    for (j in pts.indices) {
                        val a = pts[j]
                        val b = pts[(j + 1) % pts.size]
                        val dx = b.first - a.first
                        val dz = b.second - a.second
                        val length = kotlin.math.sqrt(dx * dx + dz * dz).coerceAtLeast(0.001f)
                        val liftA = terrainHeight(a.first, a.second) + 0.065f
                        val liftB = terrainHeight(b.first, b.second) + 0.065f
                        outline.addAll(listOf(a.first, liftA, a.second, b.first, liftB, b.second))
                    }
                    meshes.add(Mesh(outline.toFloatArray(),
                        floatArrayOf(0.78f, 0.72f, 0.49f, 1f), GLES20.GL_LINES))
                }
            } else {
                // Falhar visivelmente se os dados territoriais não puderem ser lidos.
                Log.e("Valepolis3D", "Dados de limites territoriais indisponíveis ou sem 25 bairros")
                meshes.add(Mesh(floatArrayOf(
                    -9.6f,0f,-8.8f, 9.6f,0f,-8.8f, 9.6f,0f,8.8f,
                    -9.6f,0f,-8.8f, 9.6f,0f,8.8f, -9.6f,0f,8.8f
                ), floatArrayOf(0.18f,0.30f,0.22f,1f)))
            }

            // Mar a norte (z negativo), fora do perímetro urbano.
            meshes.add(Mesh(floatArrayOf(
                -9.6f,0.0f,-9.8f, 9.6f,0.0f,-9.8f, 9.6f,0.0f,-8.95f,
                -9.6f,0.0f,-9.8f, 9.6f,0.0f,-8.95f, -9.6f,0.0f,-8.95f
            ), floatArrayOf(0.025f,0.27f,0.46f,1f)))

            // Estuário ocidental: faixa sinuosa em polígonos, sem rede viária inventada.
            // Estuário ocidental com margens curvas e largura variável. A geometria
            // acompanha a margem oeste e afunila para o interior, em vez de formar
            // uma faixa diagonal uniforme. Mantém-se ilustrativo, sem inventar afluentes.
            val estuary = mutableListOf<Float>()
            val estuarySections = 32
            for (i in 0 until estuarySections) {
                val t0 = i.toFloat() / estuarySections
                val t1 = (i + 1).toFloat() / estuarySections
                val z0 = -8.8f + 17.6f * t0
                val z1 = -8.8f + 17.6f * t1
                val center0 = -9.42f + 0.48f * kotlin.math.sin(t0 * 3.4f + 0.2f)
                val center1 = -9.42f + 0.48f * kotlin.math.sin(t1 * 3.4f + 0.2f)
                val width0 = 0.20f + 0.18f * kotlin.math.sin(t0 * Math.PI.toFloat()).let { kotlin.math.abs(it) }
                val width1 = 0.20f + 0.18f * kotlin.math.sin(t1 * Math.PI.toFloat()).let { kotlin.math.abs(it) }
                val inner0 = (center0 + width0).coerceAtMost(-8.88f)
                val inner1 = (center1 + width1).coerceAtMost(-8.88f)
                estuary.addAll(listOf(
                    center0,0.045f,z0, inner0,0.045f,z0, inner1,0.045f,z1,
                    center0,0.045f,z0, inner1,0.045f,z1, center1,0.045f,z1
                ))
            }
            meshes.add(Mesh(estuary.toFloatArray(), floatArrayOf(0.035f,0.30f,0.48f,1f)))

            // Cadeia montanhosa oriental contínua com encostas mais altas e cristas
            // distinguíveis. A geometria permanece confinada ao setor oriental.
            meshes.add(mountainRange())
            meshes.add(mountainRangeRidge())

            // Rede viária local gerada dentro dos polígonos territoriais V0.3.0.
            // A geometria é procedural e explícita como proposta visual: não inventa
            // coordenadas cadastrais nem apresenta alinhamentos como georreferenciados.
            if (neighborhoods != null && neighborhoods.length() == 25) {
                data class RoadDistrict(val id: Int, val name: String, val population: Int,
                    val density: Float, val polygon: List<Pair<Float, Float>>, val cx: Float, val cz: Float)
                val districts = mutableListOf<RoadDistrict>()
                for (i in 0 until neighborhoods.length()) {
                    val district = neighborhoods.optJSONObject(i) ?: continue
                    val center = district.optJSONObject("center_xz") ?: continue
                    val rawBoundary = district.optJSONArray("boundary_xz") ?: continue
                    val poly = mutableListOf<Pair<Float, Float>>()
                    for (j in 0 until rawBoundary.length()) {
                        val point = rawBoundary.optJSONObject(j) ?: continue
                        poly.add(sx(point.optDouble("x", 0.0).toFloat()) to
                            sz(point.optDouble("z", 0.0).toFloat()))
                    }
                    if (poly.size >= 3) {
                        districts.add(RoadDistrict(i, district.optString("name", "Bairro ${i+1}"),
                            district.optInt("population", 0),
                            district.optDouble("population_density_per_km2", 2500.0).toFloat(),
                            poly, sx(center.optDouble("x", 0.0).toFloat()),
                            sz(center.optDouble("z", 0.0).toFloat())))
                    }
                }
                fun insidePolygon(x: Float, z: Float, poly: List<Pair<Float, Float>>): Boolean {
                    var inside = false
                    var j = poly.size - 1
                    for (i in poly.indices) {
                        val xi = poly[i].first; val zi = poly[i].second
                        val xj = poly[j].first; val zj = poly[j].second
                        if (((zi > z) != (zj > z)) &&
                            (x < (xj - xi) * (z - zi) / ((zj - zi).let { if (kotlin.math.abs(it) < 0.00001f) 0.00001f else it }) + xi)) {
                            inside = !inside
                        }
                        j = i
                    }
                    return inside
                }
                val roadVertices = mutableListOf<Float>()
                val roadEdgeVertices = mutableListOf<Float>()
                var localRoadCount = 0
                fun addRoadStrip(x0: Float, z0: Float, x1: Float, z1: Float, width: Float, yOffset: Float) {
                    val dx = x1 - x0; val dz = z1 - z0
                    val len = kotlin.math.sqrt(dx*dx + dz*dz)
                    if (len < 0.015f) return
                    val px = -dz / len * width * 0.5f
                    val pz = dx / len * width * 0.5f
                    val y0 = terrainHeight(x0, z0) + yOffset
                    val y1 = terrainHeight(x1, z1) + yOffset
                    val ax = x0 + px; val az = z0 + pz
                    val bx = x0 - px; val bz = z0 - pz
                    val cx = x1 - px; val cz = z1 - pz
                    val dx2 = x1 + px; val dz2 = z1 + pz
                    roadVertices.addAll(listOf(
                        ax,y0,az, bx,y0,bz, cx,y1,cz,
                        ax,y0,az, cx,y1,cz, dx2,y1,dz2
                    ))
                    roadEdgeVertices.addAll(listOf(
                        ax,y0+0.006f,az, dx2,y1+0.006f,dz2,
                        bx,y0+0.006f,bz, cx,y1+0.006f,cz
                    ))
                }
                for (d in districts) {
                    val minX = d.polygon.minOf { it.first }; val maxX = d.polygon.maxOf { it.first }
                    val minZ = d.polygon.minOf { it.second }; val maxZ = d.polygon.maxOf { it.second }
                    val densityFactor = ((d.density - 1500f) / 5500f).coerceIn(0f, 1f)
                    // Maior densidade = malha local mais apertada; cada bairro tem
                    // ruas horizontais e verticais recortadas pelo seu próprio polígono.
                    val spacing = 0.66f - densityFactor * 0.18f
                    val step = 0.055f
                    var roadRow = 0
                    var z = minZ + spacing * 0.5f
                    while (z < maxZ) {
                        var runStart: Float? = null
                        var x = minX
                        while (x <= maxX + step) {
                            val isInside = x <= maxX && insidePolygon(x, z, d.polygon)
                            if (isInside && runStart == null) runStart = x
                            if ((!isInside || x >= maxX) && runStart != null) {
                                val endX = if (isInside) x else x - step
                                if (endX - runStart!! > 0.16f) {
                                    val major = roadRow % 3 == 0
                                    addRoadStrip(runStart!!, z, endX, z,
                                        if (major) 0.095f else 0.047f, 0.045f)
                                    localRoadCount++
                                }
                                runStart = null
                            }
                            x += step
                        }
                        z += spacing
                        roadRow++
                    }
                    var roadColumn = 0
                    var x = minX + spacing * 0.5f
                    while (x < maxX) {
                        var runStart: Float? = null
                        var z2 = minZ
                        while (z2 <= maxZ + step) {
                            val isInside = z2 <= maxZ && insidePolygon(x, z2, d.polygon)
                            if (isInside && runStart == null) runStart = z2
                            if ((!isInside || z2 >= maxZ) && runStart != null) {
                                val endZ = if (isInside) z2 else z2 - step
                                if (endZ - runStart!! > 0.16f) {
                                    val major = roadColumn % 3 == 0
                                    addRoadStrip(x, runStart!!, x, endZ,
                                        if (major) 0.095f else 0.047f, 0.046f)
                                    localRoadCount++
                                }
                                runStart = null
                            }
                            z2 += step
                        }
                        x += spacing
                        roadColumn++
                    }
                }
                // As duas pontes oficiais mantêm nomes e hierarquia; posição continua
                // ilustrativa até existir implantação cartográfica aprovada.
                val bridgeVertices = mutableListOf<Float>()
                val bridgeEdgeVertices = mutableListOf<Float>()
                fun addBridge(zCenter: Float, halfWidth: Float) {
                    val xWest = -9.55f; val xEast = -8.82f
                    val z0 = zCenter - halfWidth; val z1 = zCenter + halfWidth
                    val y0 = terrainHeight(xWest, zCenter) + 0.20f
                    val y1 = terrainHeight(xEast, zCenter) + 0.20f
                    bridgeVertices.addAll(listOf(
                        xWest,y0,z0, xEast,y1,z0, xEast,y1,z1,
                        xWest,y0,z0, xEast,y1,z1, xWest,y0,z1))
                    bridgeEdgeVertices.addAll(listOf(
                        xWest,y0+0.012f,z0, xEast,y1+0.012f,z0,
                        xWest,y0+0.012f,z1, xEast,y1+0.012f,z1))
                }
                addBridge(-4.1f, 0.19f) // Ponte da União — principal
                addBridge(4.25f, 0.13f) // Ponte do Horizonte — secundária
                meshes.add(Mesh(bridgeVertices.toFloatArray(), floatArrayOf(0.34f,0.36f,0.36f,1f)))
                meshes.add(Mesh(bridgeEdgeVertices.toFloatArray(), floatArrayOf(0.78f,0.72f,0.54f,1f), GLES20.GL_LINES))
                if (roadVertices.isNotEmpty()) {
                    meshes.add(Mesh(roadVertices.toFloatArray(), floatArrayOf(0.25f,0.26f,0.24f,1f)))
                    meshes.add(Mesh(roadEdgeVertices.toFloatArray(), floatArrayOf(0.72f,0.68f,0.55f,1f), GLES20.GL_LINES))
                }
                Log.i("Valepolis3D", "Rede viária local: $localRoadCount segmentos recortados pelos polígonos dos 25 bairros; ruas de densidade adaptativa; 2 pontes")
            }

            // Edifícios procedurais individualizados por densidade e população.
            // A colocação é limitada ao polígono de cada bairro; geometrias e contagens
            // são geradas deterministicamente a partir dos dados V0.3.0.
            if (neighborhoods != null && neighborhoods.length() == 25) {
                val lowBuildings = mutableListOf<Float>()
                val mediumBuildings = mutableListOf<Float>()
                val highBuildings = mutableListOf<Float>()
                val windowLines = mutableListOf<Float>()
                var buildingCount = 0
                var apartmentCapacity = 0L
                fun insideBuildingPolygon(x: Float, z: Float, poly: List<Pair<Float, Float>>): Boolean {
                    var inside = false
                    var j = poly.size - 1
                    for (i in poly.indices) {
                        val xi = poly[i].first; val zi = poly[i].second
                        val xj = poly[j].first; val zj = poly[j].second
                        if (((zi > z) != (zj > z)) &&
                            (x < (xj - xi) * (z - zi) / ((zj - zi).let { if (kotlin.math.abs(it) < 0.00001f) 0.00001f else it }) + xi)) inside = !inside
                        j = i
                    }
                    return inside
                }
                for (i in 0 until neighborhoods.length()) {
                    val district = neighborhoods.optJSONObject(i) ?: continue
                    val rawBoundary = district.optJSONArray("boundary_xz") ?: continue
                    val poly = mutableListOf<Pair<Float, Float>>()
                    for (j in 0 until rawBoundary.length()) {
                        val point = rawBoundary.optJSONObject(j) ?: continue
                        poly.add(sx(point.optDouble("x", 0.0).toFloat()) to
                            sz(point.optDouble("z", 0.0).toFloat()))
                    }
                    if (poly.size < 3) continue
                    val population = district.optInt("population", 0).coerceAtLeast(0)
                    val density = district.optDouble("population_density_per_km2", 2500.0).toFloat()
                    val minX = poly.minOf { it.first }; val maxX = poly.maxOf { it.first }
                    val minZ = poly.minOf { it.second }; val maxZ = poly.maxOf { it.second }
                    // Meta proporcional à população aprovada, moderada para manter
                    // o desenho fluido no Android. A densidade altera a compactação.
                    val target = (12 + population / 1800).coerceIn(16, 72)
                    val spacing = kotlin.math.sqrt(((maxX-minX)*(maxZ-minZ)).coerceAtLeast(0.04f) / target.toFloat())
                        .coerceIn(0.15f, 0.40f)
                    val densityFactor = ((density - 1500f) / 5500f).coerceIn(0f, 1f)
                    val roadSpacing = 0.66f - densityFactor * 0.18f
                    var row = 0
                    var roadRow = 0
                    var z = minZ + spacing * 0.5f
                    while (z < maxZ) {
                        var col = 0
                        var x = minX + spacing * 0.5f
                        while (x < maxX) {
                            // Deslocamento repetível evita uma grelha artificial.
                            val jitterX = (((i + 3) * 17 + row * 7 + col * 11) % 13 - 6) * 0.008f
                            val jitterZ = (((i + 5) * 19 + row * 13 + col * 3) % 11 - 5) * 0.008f
                            val bx = x + jitterX; val bz = z + jitterZ
                            val nearLocalStreetX = kotlin.math.abs(((bx - minX - roadSpacing * 0.5f) % roadSpacing).let { if (it < 0f) it + roadSpacing else it } - roadSpacing * 0.5f) < 0.085f
                            val nearLocalStreetZ = kotlin.math.abs(((bz - minZ - roadSpacing * 0.5f) % roadSpacing).let { if (it < 0f) it + roadSpacing else it } - roadSpacing * 0.5f) < 0.085f
                            if (insideBuildingPolygon(bx, bz, poly) && !(nearLocalStreetX || nearLocalStreetZ) &&
                                buildingCount < 1100) {
                                val selector = (i * 31 + row * 7 + col * 13) % 100
                                val floors = when {
                                    density >= 6000f -> when {
                                        selector < 5 -> 25 + selector % 6 // edifícios de referência até 30 pisos
                                        selector < 35 -> 10 + selector % 9
                                        else -> 5 + selector % 7
                                    }
                                    density >= 4000f -> when {
                                        selector < 12 -> 12 + selector % 5
                                        else -> 4 + selector % 8
                                    }
                                    density >= 2500f -> 3 + selector % 8
                                    else -> 1 + selector % 6
                                }.coerceIn(1, 30)
                                val height = 0.075f + floors * 0.035f
                                val half = (0.042f + densityFactor * 0.030f).coerceIn(0.042f, 0.072f)
                                val depth = half * (if ((selector % 2) == 0) 0.82f else 1.05f)
                                val baseY = terrainHeight(bx, bz) + 0.035f
                                val x0=bx-half; val x1=bx+half; val z0=bz-depth; val z1=bz+depth
                                val y0=baseY; val y1=baseY+height
                                val vertices = floatArrayOf(
                                    x0,y0,z0, x1,y0,z0, x1,y1,z0, x0,y0,z0, x1,y1,z0, x0,y1,z0,
                                    x1,y0,z0, x1,y0,z1, x1,y1,z1, x1,y0,z0, x1,y1,z1, x1,y1,z0,
                                    x1,y0,z1, x0,y0,z1, x0,y1,z1, x1,y0,z1, x0,y1,z1, x1,y1,z1,
                                    x0,y0,z1, x0,y0,z0, x0,y1,z0, x0,y0,z1, x0,y1,z0, x0,y1,z1,
                                    x0,y1,z0, x1,y1,z0, x1,y1,z1, x0,y1,z0, x1,y1,z1, x0,y1,z1)
                                when {
                                    floors >= 14 -> highBuildings.addAll(vertices.toList())
                                    floors >= 6 -> mediumBuildings.addAll(vertices.toList())
                                    else -> lowBuildings.addAll(vertices.toList())
                                }
                                // Linhas de janelas em fachadas frontais, agregadas numa
                                // única malha para evitar centenas de chamadas OpenGL.
                                val floorsShown = minOf(floors, 16)
                                for (fl in 0 until floorsShown) {
                                    val wy = baseY + (fl + 0.5f) * height / floors
                                    val wxL = bx - half * 0.55f
                                    val wxR = bx + half * 0.55f
                                    windowLines.addAll(listOf(
                                        wxL,wy,bz-depth-0.002f, wxR,wy,bz-depth-0.002f,
                                        bx,wy-height/floors*0.22f,bz-depth-0.002f,
                                        bx,wy+height/floors*0.22f,bz-depth-0.002f
                                    ))
                                }
                                buildingCount++
                                apartmentCapacity += floors.toLong() * (if (density >= 4000f) 4 else 2)
                            }
                            x += spacing
                            col++
                        }
                        z += spacing
                        row++
                    }
                }
                if (lowBuildings.isNotEmpty()) meshes.add(Mesh(lowBuildings.toFloatArray(), floatArrayOf(0.53f,0.58f,0.52f,1f)))
                if (mediumBuildings.isNotEmpty()) meshes.add(Mesh(mediumBuildings.toFloatArray(), floatArrayOf(0.66f,0.63f,0.55f,1f)))
                if (highBuildings.isNotEmpty()) meshes.add(Mesh(highBuildings.toFloatArray(), floatArrayOf(0.72f,0.76f,0.79f,1f)))
                if (windowLines.isNotEmpty()) meshes.add(Mesh(windowLines.toFloatArray(), floatArrayOf(0.24f,0.38f,0.48f,1f), GLES20.GL_LINES))
                Log.i("Valepolis3D", "Edifícios V0.3.0: $buildingCount volumes dentro dos polígonos; população territorial usada para dimensionamento; capacidade visual aproximada=$apartmentCapacity")
            }
        }

        private fun cube(cx:Float, cz:Float, half:Float, h:Float, depth:Float, baseY:Float = 0f): Mesh {
            val x0=cx-half; val x1=cx+half; val z0=cz-depth; val z1=cz+depth
            val y0=baseY; val y1=baseY+h
            val v=floatArrayOf(
                x0,y0,z0, x1,y0,z0, x1,y1,z0, x0,y0,z0, x1,y1,z0, x0,y1,z0,
                x1,y0,z0, x1,y0,z1, x1,y1,z1, x1,y0,z0, x1,y1,z1, x1,y1,z0,
                x1,y0,z1, x0,y0,z1, x0,y1,z1, x1,y0,z1, x0,y1,z1, x1,y1,z1,
                x0,y0,z1, x0,y0,z0, x0,y1,z0, x0,y0,z1, x0,y1,z0, x0,y1,z1,
                x0,y1,z0, x1,y1,z0, x1,y1,z1, x0,y1,z0, x1,y1,z1, x0,y1,z1
            )
            val shade=0.38f + ((cx+cz+30).toInt().absoluteValue%4)*0.08f
            return Mesh(v,floatArrayOf(shade,shade+0.08f,shade+0.12f,1f))
        }

        private fun mountainRange(): Mesh {
            // Cadeia oriental estreita, com base no terreno e transições graduais.
            // Evita a grande face plana que surgia quando a faixa exterior era larga.
            val vertices = mutableListOf<Float>()
            val sections = 48
            val zStart = -8.15f
            val zEnd = 8.15f

            fun height(t: Float): Float {
                val broad = 0.72f + 0.28f * kotlin.math.sin(t * 5.7f + 0.4f)
                val peaks = 0.52f * kotlin.math.abs(kotlin.math.sin(t * 17.0f + 0.8f))
                val shoulders = 0.13f * kotlin.math.sin(t * 31f)
                return (broad + peaks + shoulders).coerceIn(0.38f, 1.25f)
            }

            for (i in 0 until sections) {
                val t0 = i.toFloat() / sections
                val t1 = (i + 1).toFloat() / sections
                val z0 = zStart + (zEnd - zStart) * t0
                val z1 = zStart + (zEnd - zStart) * t1
                val h0 = height(t0)
                val h1 = height(t1)
                val xBase0 = 9.25f
                val xBase1 = 9.25f
                val xLow0 = 8.92f + 0.07f * kotlin.math.sin(t0 * 9f)
                val xLow1 = 8.92f + 0.07f * kotlin.math.sin(t1 * 9f)
                val xMid0 = 8.42f + 0.13f * kotlin.math.sin(t0 * 11f + 0.3f)
                val xMid1 = 8.42f + 0.13f * kotlin.math.sin(t1 * 11f + 0.3f)
                val xRidge0 = 7.82f + 0.20f * kotlin.math.sin(t0 * 12f)
                val xRidge1 = 7.82f + 0.20f * kotlin.math.sin(t1 * 12f)

                fun quad(
                    xa0: Float, ya0: Float, xa1: Float, ya1: Float,
                    xb0: Float, yb0: Float, xb1: Float, yb1: Float,
                    za: Float, zb: Float
                ) {
                    vertices.addAll(listOf(
                        xa0, ya0, za, xb0, yb0, za, xb1, yb1, zb,
                        xa0, ya0, za, xb1, yb1, zb, xa1, ya1, zb
                    ))
                }

                // Faixa exterior estreita, seguida de encostas mais marcadas e cristas irregulares.
                quad(xBase0, 0.035f, xBase1, 0.035f,
                     xLow0, h0 * 0.18f, xLow1, h1 * 0.18f, z0, z1)
                quad(xLow0, h0 * 0.18f, xLow1, h1 * 0.18f,
                     xMid0, h0 * 0.48f, xMid1, h1 * 0.48f, z0, z1)
                quad(xMid0, h0 * 0.48f, xMid1, h1 * 0.48f,
                     xRidge0, h0, xRidge1, h1, z0, z1)
            }
            return Mesh(vertices.toFloatArray(), floatArrayOf(0.34f, 0.40f, 0.32f, 1f))
        }

        private fun mountainRangeRidge(): Mesh {
            // Faixa de crista sombreada para tornar a cadeia oriental legível à escala da cidade.
            val vertices = mutableListOf<Float>()
            val sections = 48
            val zStart = -8.05f
            val zEnd = 8.05f
            for (i in 0 until sections) {
                val t0 = i.toFloat() / sections
                val t1 = (i + 1).toFloat() / sections
                val z0 = zStart + (zEnd - zStart) * t0
                val z1 = zStart + (zEnd - zStart) * t1
                val x0 = 7.80f + 0.20f * kotlin.math.sin(t0 * 12f)
                val x1 = 7.80f + 0.20f * kotlin.math.sin(t1 * 12f)
                val peak0 = 0.86f + 0.31f * kotlin.math.abs(kotlin.math.sin(t0 * 17f + 0.8f))
                val peak1 = 0.86f + 0.31f * kotlin.math.abs(kotlin.math.sin(t1 * 17f + 0.8f))
                val back0 = x0 + 0.22f
                val back1 = x1 + 0.22f
                vertices.addAll(listOf(
                    x0,peak0,z0, back0,peak0*0.62f,z0, back1,peak1*0.62f,z1,
                    x0,peak0,z0, back1,peak1*0.62f,z1, x1,peak1,z1
                ))
            }
            return Mesh(vertices.toFloatArray(), floatArrayOf(0.25f,0.31f,0.27f,1f))
        }

        private fun hill(cx: Float, cz: Float, radius: Float, height: Float, seed: Int): Mesh {
            // Malha radial com anéis de elevação; cria silhueta natural sem picos pontiagudos.
            val vertices = mutableListOf<Float>()
            val segments = 12
            val rings = arrayOf(
                1.00f to 0.02f,
                0.78f to height * 0.30f,
                0.52f to height * 0.66f,
                0.25f to height * 0.91f
            )
            val phase = seed * 0.37f
            for (ringIndex in 0 until rings.size - 1) {
                val (r0, y0) = rings[ringIndex]
                val (r1, y1) = rings[ringIndex + 1]
                for (i in 0 until segments) {
                    val a0 = (2.0 * Math.PI * i / segments + phase)
                    val a1 = (2.0 * Math.PI * (i + 1) / segments + phase)
                    fun px(r: Float, a: Double) = cx + kotlin.math.cos(a).toFloat() * radius * r *
                        (1f + 0.07f * kotlin.math.sin(a * 3.0 + seed).toFloat())
                    fun pz(r: Float, a: Double) = cz + kotlin.math.sin(a).toFloat() * radius * r *
                        (1f + 0.06f * kotlin.math.cos(a * 2.0 + seed).toFloat())
                    val x00 = px(r0, a0); val z00 = pz(r0, a0)
                    val x01 = px(r0, a1); val z01 = pz(r0, a1)
                    val x10 = px(r1, a0); val z10 = pz(r1, a0)
                    val x11 = px(r1, a1); val z11 = pz(r1, a1)
                    vertices.addAll(listOf(
                        x00,y0,z00, x10,y1,z10, x11,y1,z11,
                        x00,y0,z00, x11,y1,z11, x01,y0,z01
                    ))
                }
            }
            // Fechar o topo com um pequeno platô, não um vértice agudo.
            val (r, y) = rings.last()
            for (i in 0 until segments) {
                val a0 = 2.0 * Math.PI * i / segments + phase
                val a1 = 2.0 * Math.PI * (i + 1) / segments + phase
                val x0 = cx + kotlin.math.cos(a0).toFloat() * radius * r
                val z0 = cz + kotlin.math.sin(a0).toFloat() * radius * r
                val x1 = cx + kotlin.math.cos(a1).toFloat() * radius * r
                val z1 = cz + kotlin.math.sin(a1).toFloat() * radius * r
                vertices.addAll(listOf(cx,y + height * 0.035f,cz, x0,y,z0, x1,y,z1))
            }
            return Mesh(vertices.toFloatArray(), floatArrayOf(0.27f,0.36f,0.30f,1f))
        }

        private fun createProgram(vs:String, fs:String): Int {
            fun compile(type:Int, source:String):Int {
                val shader=GLES20.glCreateShader(type)
                GLES20.glShaderSource(shader,source)
                GLES20.glCompileShader(shader)
                val status=IntArray(1)
                GLES20.glGetShaderiv(shader,GLES20.GL_COMPILE_STATUS,status,0)
                if(status[0]==0) {
                    val error=GLES20.glGetShaderInfoLog(shader)
                    GLES20.glDeleteShader(shader)
                    throw IllegalStateException("Shader compilation failed: $error")
                }
                return shader
            }
            val vertex=compile(GLES20.GL_VERTEX_SHADER,vs)
            val fragment=compile(GLES20.GL_FRAGMENT_SHADER,fs)
            val p=GLES20.glCreateProgram()
            GLES20.glAttachShader(p,vertex); GLES20.glAttachShader(p,fragment)
            GLES20.glLinkProgram(p)
            val status=IntArray(1); GLES20.glGetProgramiv(p,GLES20.GL_LINK_STATUS,status,0)
            if(status[0]==0) throw IllegalStateException("OpenGL link failed: "+GLES20.glGetProgramInfoLog(p))
            return p
        }
    }

    private fun renderDashboard() {
        val c = card("CENTRO DE COMANDO")
        c.addView(label("A IA aconselha. O jogador comanda. A cidade reage.", 18f, Color.WHITE, true))
        c.addView(label("População oficial: 1 000 000", 19f, Color.WHITE, true))
        c.addView(label("Bairros: ${readNeighborhoods().length()} / 25", 18f))
        val episodeCount = readEpisodes()?.optJSONArray("episodes")?.length()
        c.addView(label("Narrativa: ${episodeCount ?: "—"} episódios · 20 temporadas", 18f))
        c.addView(label(
            "Estado da migração: interface e leitura territorial em implementação. O mapa 3D e os sistemas operacionais ainda não estão concluídos.",
            16f, muted
        ))
        addCard(c)

        val dataCard = card("DADOS CARREGADOS")
        val neighborhoods = readNeighborhoods()
        val episodes = readEpisodes()
        dataCard.addView(label(
            if (neighborhoods.length() == 25) "✓ Registo territorial: 25 bairros encontrados"
            else "⚠ Registo territorial: ${neighborhoods.length()} bairros encontrados",
            16f,
            if (neighborhoods.length() == 25) Color.rgb(145, 220, 170) else accent
        ))
        dataCard.addView(label(
            if (episodes?.optJSONArray("episodes")?.length() == 200) "✓ Registo narrativo: 200 episódios encontrados"
            else "⚠ Registo narrativo incompleto ou indisponível",
            16f,
            if (episodes?.optJSONArray("episodes")?.length() == 200) Color.rgb(145, 220, 170) else accent
        ))
        addCard(dataCard)
    }

    private fun renderNeighborhoods() {
        val root = card("TERRITÓRIO DE VALEPÓLIS")
        root.addView(label(
            "Mapa territorial 2D baseado nas coordenadas oficiais dos registos. Ainda não é o renderizador 3D.",
            16f, muted
        ))
        val arr = readNeighborhoods()
        val map = NeighborhoodMapView(arr)
        val mapControls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("−", "Repor mapa", "+").forEach { title ->
            val b = Button(this).apply {
                text = title
                textSize = 16f
                isAllCaps = false
                setTextColor(Color.WHITE)
                setBackgroundColor(panelAlt)
                minHeight = dp(48)
                setOnClickListener {
                    when (title) {
                        "+" -> mapZoom = (mapZoom * 1.25f).coerceAtMost(3.0f)
                        "−" -> mapZoom = (mapZoom / 1.25f).coerceAtLeast(0.75f)
                        else -> { mapZoom = 1.0f; mapPanX = 0f; mapPanY = 0f }
                    }
                    map.invalidate()
                }
            }
            mapControls.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                marginEnd = dp(4)
            })
        }
        root.addView(mapControls)
        root.addView(map, LinearLayout.LayoutParams(-1, dp(340)).apply {
            topMargin = dp(8)
            bottomMargin = dp(8)
        })
        if (arr.length() == 0) {
            root.addView(label("Não foi possível ler o registo de bairros.", 17f))
        } else {
            root.addView(label(
                "No mapa, cada número corresponde à mesma posição na lista abaixo. Toca num ponto para o destacar.",
                15f, muted
            ))
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val name = item.optString("name", "Bairro sem nome")
                val population = item.optLong("population", -1L)
                val role = item.optString("territorial_role", "")
                val active = item.optBoolean("active", true)
                val entry = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(if (i % 2 == 0) panelAlt else panel)
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                entry.addView(label("${item.optInt("id", i + 1)}. $name", 19f, Color.WHITE, true))
                if (population >= 0) {
                    entry.addView(label("População de referência: ${numberFormat.format(population)}", 16f, muted))
                }
                if (role.isNotBlank()) entry.addView(label(role, 16f))
                entry.addView(label(if (active) "Estado do registo: ativo" else "Estado do registo: inativo", 14f, muted))
                root.addView(entry, LinearLayout.LayoutParams(-1, -2).apply {
                    topMargin = dp(4)
                })
            }
        }
        addCard(root)
    }


    /**
     * Mapa territorial 2D interativo: posições e rótulos são lidos do JSON oficial.
     * A geografia (mar a norte, estuário a oeste e montanhas a este) é uma camada
     * esquemática orientativa; não substitui o terreno/renderizador 3D.
     */
    private inner class NeighborhoodMapView(private val neighborhoods: JSONArray) : View(this@MainActivity) {
        private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(12, 29, 39) }
        private val seaPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(23, 74, 101) }
        private val riverPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(32, 100, 128) }
        private val landPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(42, 77, 59) }
        private val mountainPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(82, 87, 82) }
        private val roadPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(185, 174, 135); strokeWidth = dp(2).toFloat(); style = Paint.Style.STROKE
        }
        private val districtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent; style = Paint.Style.FILL }
        private val selectedPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = dp(2).toFloat()
        }
        private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = sp(10f); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            setShadowLayer(dp(2).toFloat(), 0f, 1f, Color.BLACK)
        }
        private val regionPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(218, 229, 232); textSize = sp(11f); typeface = Typeface.DEFAULT_BOLD
        }
        private var selectedIndex = -1
        private val points = mutableListOf<Pair<Float, Float>>()
        private var lastTouchX = 0f
        private var lastTouchY = 0f
        private var moved = false

        private fun sp(v: Float) = v * resources.displayMetrics.scaledDensity

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            canvas.drawRoundRect(RectF(0f, 0f, width.toFloat(), height.toFloat()), dp(10).toFloat(), dp(10).toFloat(), backgroundPaint)
            val w = width.toFloat()
            val h = height.toFloat()
            // Norte no topo: costa superior e estuário a oeste.
            canvas.drawRect(0f, 0f, w, h * .18f, seaPaint)
            canvas.drawText("MAR · NORTE", dp(12).toFloat(), dp(22).toFloat(), regionPaint)

            val river = Path().apply {
                moveTo(0f, h * .18f)
                cubicTo(w * .12f, h * .30f, w * .02f, h * .42f, w * .13f, h * .55f)
                cubicTo(w * .18f, h * .66f, w * .06f, h * .78f, w * .11f, h)
                lineTo(0f, h)
                close()
            }
            canvas.drawPath(river, riverPaint)
            canvas.drawText("RIO / ESTUÁRIO", dp(7).toFloat(), h * .48f, regionPaint)

            val mountain = Path().apply {
                moveTo(w * .82f, h * .18f)
                lineTo(w, h * .18f)
                lineTo(w, h)
                lineTo(w * .70f, h)
                lineTo(w * .78f, h * .72f)
                lineTo(w * .74f, h * .52f)
                close()
            }
            canvas.drawPath(mountain, mountainPaint)
            canvas.drawText("MONTANHAS", w * .75f, h - dp(12).toFloat(), regionPaint)

            val mapLeft = w * .17f
            val mapRight = w * .77f
            val mapTop = h * .22f
            val mapBottom = h * .91f
            val mapCenterX = (mapLeft + mapRight) / 2f
            val mapCenterY = (mapTop + mapBottom) / 2f
            canvas.save()
            canvas.translate(mapPanX, mapPanY)
            canvas.scale(mapZoom, mapZoom, mapCenterX, mapCenterY)
            // Eixos viários esquemáticos; não representam ainda a rede viária navegável.
            canvas.drawLine(mapLeft, mapTop + (mapBottom-mapTop)*.48f, mapRight, mapTop + (mapBottom-mapTop)*.48f, roadPaint)
            canvas.drawLine(mapLeft + (mapRight-mapLeft)*.52f, mapTop, mapLeft + (mapRight-mapLeft)*.52f, mapBottom, roadPaint)
            canvas.drawLine(mapLeft, mapBottom*.80f, mapRight, mapTop + (mapBottom-mapTop)*.22f, roadPaint)

            points.clear()
            var minX = -45.0
            var maxX = 45.0
            var minZ = -45.0
            var maxZ = 45.0
            for (i in 0 until neighborhoods.length()) {
                val obj = neighborhoods.optJSONObject(i) ?: continue
                val pos = obj.optJSONObject("world_position_xz") ?: continue
                minX = minOf(minX, pos.optDouble("x", 0.0))
                maxX = maxOf(maxX, pos.optDouble("x", 0.0))
                minZ = minOf(minZ, pos.optDouble("z", 0.0))
                maxZ = maxOf(maxZ, pos.optDouble("z", 0.0))
            }
            val usableLeft = mapLeft + dp(8)
            val usableRight = mapRight - dp(8)
            val usableTop = mapTop + dp(8)
            val usableBottom = mapBottom - dp(8)
            for (i in 0 until neighborhoods.length()) {
                val obj = neighborhoods.optJSONObject(i) ?: continue
                val pos = obj.optJSONObject("world_position_xz") ?: continue
                val x = pos.optDouble("x", 0.0)
                val z = pos.optDouble("z", 0.0)
                val px = usableLeft + ((x - minX) / (maxX - minX)).toFloat() * (usableRight - usableLeft)
                val py = usableTop + ((z - minZ) / (maxZ - minZ)).toFloat() * (usableBottom - usableTop)
                points.add(px to py)
                if (i == selectedIndex) canvas.drawCircle(px, py, dp(9).toFloat(), selectedPaint)
                canvas.drawCircle(px, py, dp(4.5f.toInt()).toFloat(), districtPaint)
                // Numerar os pontos evita a sobreposição de nomes no ecrã móvel.
                // A lista imediatamente abaixo do mapa associa cada número ao nome completo.
                val markerNumber = (i + 1).toString()
                val numberPaint = Paint(textPaint).apply {
                    textSize = sp(10f)
                    textAlign = Paint.Align.CENTER
                    color = Color.rgb(5, 20, 30)
                    clearShadowLayer()
                }
                canvas.drawCircle(px, py, dp(8).toFloat(), districtPaint)
                canvas.drawText(markerNumber, px, py + dp(3).toFloat(), numberPaint)
            }
            canvas.restore()
        }

        override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
            when (event.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    lastTouchX = event.x
                    lastTouchY = event.y
                    moved = false
                    return true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    if (kotlin.math.abs(dx) > dp(3) || kotlin.math.abs(dy) > dp(3)) moved = true
                    if (moved) {
                        mapPanX = (mapPanX + dx).coerceIn(-width.toFloat(), width.toFloat())
                        mapPanY = (mapPanY + dy).coerceIn(-height.toFloat(), height.toFloat())
                        invalidate()
                    }
                    lastTouchX = event.x
                    lastTouchY = event.y
                    return true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (moved) return true
                var nearest = -1
                var distance = Float.MAX_VALUE
                points.forEachIndexed { index, point ->
                    val dx = event.x - point.first
                    val dy = event.y - point.second
                    val d = dx * dx + dy * dy
                    if (d < distance) { distance = d; nearest = index }
                }
                if (nearest >= 0 && distance < dp(36).toFloat() * dp(36).toFloat()) {
                    selectedIndex = nearest
                    invalidate()
                    val obj = neighborhoods.optJSONObject(nearest)
                    if (obj != null) {
                        android.widget.Toast.makeText(
                            this@MainActivity,
                            "${obj.optString("name")} · ${obj.optString("territorial_role")}",
                            android.widget.Toast.LENGTH_LONG
                        ).show()
                    }
                }
                    return true
                }
            }
            return true
        }
    }

    private fun readJsonObject(file: String): JSONObject? = try {
        assets.open("data/$file").bufferedReader(Charsets.UTF_8).use {
            JSONObject(it.readText())
        }
    } catch (_: Exception) {
        null
    }

    private fun readBoundaryData(): JSONObject? = try {
        assets.open("data/limites_bairros_v030.json").bufferedReader(Charsets.UTF_8).use {
            JSONObject(it.readText())
        }
    } catch (error: Exception) {
        Log.e("Valepolis3D", "Não foi possível ler limites_bairros_v030.json", error)
        null
    }

    private fun readNeighborhoods(): JSONArray =
        readJsonObject("bairros_valepolis.json")?.optJSONArray("neighborhoods") ?: JSONArray()

    private fun readEpisodes(): JSONObject? = readJsonObject("episodes_200.json")
}

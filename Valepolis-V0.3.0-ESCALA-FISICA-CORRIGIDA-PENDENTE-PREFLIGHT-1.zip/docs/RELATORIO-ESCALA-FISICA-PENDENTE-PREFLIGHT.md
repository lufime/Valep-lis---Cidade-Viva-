# Valepólis V0.3.0 — alterações de escala física

Estado: ALTERAÇÕES DE CÓDIGO APLICADAS; PRE-FLIGHT PENDENTE.

Alterações aplicadas em `systems/city_3d.gd`:
- Adicionar constantes físicas explícitas.
- Veículos com dimensões de carro ligeiro realistas.
- Reposicionar rodas de acordo com a carroçaria.
- Remover redução artificial da largura das vias.
- Passeios com largura pedonal utilizável.
- Avenidas principais com quatro faixas de 3,1 m.
- Ruas locais com largura física mínima de 3,2 m.
- Altura de edifícios coerente com pisos de aproximadamente 3 m.
- Aplicar limite máximo de 30 pisos.

Foi acrescentado `data/escala_fisica_v030.json` com a tabela de dimensões de referência.

## Limitações e riscos ainda por validar
- O executável Godot não está instalado no ambiente que produziu este pacote; não foi possível compilar/importar nem executar a cena.
- O mapa continua a usar coordenadas de bairro concentradas em dezenas de unidades. Esta alteração corrige dimensões físicas locais, mas **não transforma ainda** a geometria territorial atual numa projeção cartográfica literal de 333,60 km².
- Aumentar a largura das avenidas e passeios e a altura dos edifícios pode criar sobreposições com edifícios, corredores, sinalização e bairros adjacentes. É obrigatório correr PRE-FLIGHT e rever o resultado visual antes de considerar esta versão aprovada.
- A área de 333,60 km² é uma proposta calculada, não uma cartografia oficial aprovada.
- Os perfis de edifícios ainda não calculam a capacidade habitacional total de cada bairro; a integração da população e área edificável com o inventário de edifícios é uma etapa separada.

## Não declarado como validado
Não foi declarado que a APK compila, que a cena abre sem erros, que a circulação funciona em runtime ou que a escala territorial final está concluída.

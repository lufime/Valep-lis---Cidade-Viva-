extends CharacterBody3D

@export var walk_speed: float = 3.2
@export var mouse_sensitivity: float = 0.0018
@export var gravity_strength: float = 13.0
var look_pitch := 0.0
var look_enabled := true
var touch_move := Vector2.ZERO
var move_touch_id := -1
var look_touch_id := -1
var move_touch_origin := Vector2.ZERO
var last_look_position := Vector2.ZERO
var is_crouching := false
var standing_camera_y := 0.55
var crouching_camera_y := 0.22

@onready var pivot: Node3D = $CameraPivot
@onready var camera: Camera3D = $CameraPivot/Camera3D
@onready var ray: RayCast3D = $CameraPivot/Camera3D/InteractionRay
@onready var flashlight: SpotLight3D = $CameraPivot/Camera3D/Flashlight
@onready var body_collider: CollisionShape3D = $CollisionShape3D
@onready var prompt: Label = get_tree().current_scene.get_node_or_null("HUD/Prompt")

func _ready() -> void:
	if not OS.has_feature("mobile"):
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	# HUD is created by the parent immediately after adding the player.
	call_deferred("_bind_hud")

func _bind_hud() -> void:
	prompt = get_tree().current_scene.get_node_or_null("HUD/Prompt")

func set_touch_move(value: Vector2) -> void:
	touch_move = value.limit_length(1.0)

func toggle_flashlight() -> void:
	flashlight.visible = not flashlight.visible

func toggle_crouch() -> void:
	is_crouching = not is_crouching
	walk_speed = 1.35 if is_crouching else 3.2
	pivot.position.y = crouching_camera_y if is_crouching else standing_camera_y
	var capsule := body_collider.shape as CapsuleShape3D
	if capsule:
		capsule.height = 1.1 if is_crouching else 1.75
		body_collider.position.y = -0.325 if is_crouching else 0.0
	if prompt:
		prompt.text = "AGACHADO · ruído reduzido" if is_crouching else "De pé · movimento mais rápido, mas mais ruidoso"

func interact_now() -> void:
	_interact()

func _input(event: InputEvent) -> void:
	# Mobile controls: left half moves, right half looks. HUD buttons occupy
	# the lower-right corner and are excluded from look input.
	var screen_size := get_viewport().get_visible_rect().size
	if event is InputEventScreenTouch:
		if event.pressed:
			if event.position.x < screen_size.x * 0.46 and event.position.y > screen_size.y * 0.28 and move_touch_id == -1:
				move_touch_id = event.index
				move_touch_origin = event.position
				touch_move = Vector2.ZERO
			elif event.position.x >= screen_size.x * 0.46 and not _is_touch_button_area(event.position) and look_touch_id == -1:
				look_touch_id = event.index
				last_look_position = event.position
		else:
			if event.index == move_touch_id:
				move_touch_id = -1
				touch_move = Vector2.ZERO
			if event.index == look_touch_id:
				look_touch_id = -1
	elif event is InputEventScreenDrag:
		if event.index == move_touch_id:
			var delta: Vector2 = event.position - move_touch_origin
			touch_move = Vector2(clamp(delta.x / 68.0, -1.0, 1.0), clamp(delta.y / 68.0, -1.0, 1.0))
		elif event.index == look_touch_id:
			var look_delta: Vector2 = event.position - last_look_position
			_apply_look(look_delta)
			last_look_position = event.position

func _is_touch_button_area(pos: Vector2) -> bool:
	var size := get_viewport().get_visible_rect().size
	return pos.x > size.x - 205.0 and pos.y > size.y - 225.0

func _apply_look(delta: Vector2) -> void:
	rotate_y(-delta.x * mouse_sensitivity * 1.6)
	look_pitch = clamp(look_pitch - delta.y * mouse_sensitivity * 1.6, deg_to_rad(-82), deg_to_rad(82))
	pivot.rotation.x = look_pitch

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		_apply_look(event.relative)
	if event.is_action_pressed("ui_cancel"):
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED
	if event.is_action_pressed("flashlight"):
		toggle_flashlight()
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_C:
		toggle_crouch()
	if event.is_action_pressed("interact"):
		_interact()

func _physics_process(delta: float) -> void:
	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	input_vec = (input_vec + touch_move).limit_length(1.0)
	var dir := (transform.basis * Vector3(input_vec.x, 0, input_vec.y)).normalized()
	velocity.x = dir.x * walk_speed
	velocity.z = dir.z * walk_speed
	if not is_on_floor():
		velocity.y -= gravity_strength * delta
	else:
		velocity.y = 0.0
	move_and_slide()
	_update_prompt()

func _update_prompt() -> void:
	if not prompt:
		return
	ray.force_raycast_update()
	if ray.is_colliding():
		var target := ray.get_collider()
		if target and target.has_method("interact"):
			if target.name.begins_with("CoopSwitch"):
				prompt.text = "E  ·  Ativar relé cooperativo"
			else:
				prompt.text = "E  ·  Interagir com a porta selada"
			return
	prompt.text = "Mover: WASD / joystick · Olhar: rato / arrastar · Interagir: E / botão · Lanterna: F / botão"

func _interact() -> void:
	ray.force_raycast_update()
	if not ray.is_colliding():
		return
	var target := ray.get_collider()
	if target and target.has_method("interact"):
		target.interact(self)

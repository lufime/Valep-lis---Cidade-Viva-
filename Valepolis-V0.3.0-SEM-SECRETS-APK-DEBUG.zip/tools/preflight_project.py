#!/usr/bin/env python3
"""Cross-file static audit for Valepólis V0.3.0; no Godot runtime implied."""
import json
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
passes, failures, notes = [], [], []
def check(ok, message):
    (passes if ok else failures).append(message)
def load_json(path):
    try:
        return json.loads((ROOT / path).read_text(encoding="utf-8"))
    except Exception as exc:
        failures.append(f"JSON não legível {path}: {exc}")
        return {}

# Literal project resource paths in scenes, scripts and project settings.
resource_refs = {}
for path in list(ROOT.rglob("*.gd")) + list(ROOT.rglob("*.tscn")) + list(ROOT.rglob("*.tres")) + [ROOT / "project.godot", ROOT / "export_presets.cfg"]:
    if not path.is_file():
        continue
    text = path.read_text(encoding="utf-8", errors="replace")
    for ref in re.findall(r'res://[^"\s,)]+', text):
        # Only paths with a resource extension can be checked as files; directory prefixes are dynamic.
        if Path(ref).suffix in {".gd", ".tscn", ".tres", ".res", ".scn", ".json", ".svg", ".png", ".jpg", ".webp", ".ogg", ".wav", ".ttf", ".otf", ".mp3", ".import"}:
            resource_refs.setdefault(ref, []).append(path.relative_to(ROOT).as_posix())
missing = {ref: owners for ref, owners in resource_refs.items() if not (ROOT / ref.removeprefix("res://")).is_file()}
check(not missing, f"Referências literais res:// existentes ({len(resource_refs)} verificadas; em falta {len(missing)})")
for ref, owners in sorted(missing.items()):
    failures.append(f"Recurso res:// em falta: {ref} (referido em {', '.join(owners[:3])})")

# Duplicate function names per GDScript file, and expected project hooks.
duplicate_functions = []
for path in ROOT.rglob("*.gd"):
    text = path.read_text(encoding="utf-8", errors="replace")
    funcs = re.findall(r'^func\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(', text, re.M)
    counts = Counter(funcs)
    dupes = [name for name, count in counts.items() if count > 1]
    if dupes:
        duplicate_functions.append(f"{path.relative_to(ROOT)}: {', '.join(dupes)}")
check(not duplicate_functions, "Sem nomes de função duplicados nos scripts GDScript")
failures.extend("Funções duplicadas: " + x for x in duplicate_functions)

project = (ROOT / "project.godot").read_text(encoding="utf-8")
scene = (ROOT / "Main.tscn").read_text(encoding="utf-8")
export = (ROOT / "export_presets.cfg").read_text(encoding="utf-8")
workflow = (ROOT / ".github/workflows/build.yml").read_text(encoding="utf-8")
check('config/version="0.3.0"' in project and 'version/name="0.3.0"' in export, "Versão do projeto e preset Android coerentes em V0.3.0")
check('run/main_scene="res://Main.tscn"' in project and 'res://main.gd' in scene, "Cena principal e script ligados")
# A cena deve iniciar sem valores de demonstração visíveis caso o script falhe.
check("€ 120" not in scene and "01/01/2026\\nDia 1" not in scene and "Energia 80" not in scene, "Cena inicial sem saldo/data/necessidades fictícias visíveis")
check("Os dados da partida serão apresentados aqui." in scene, "Cena inicial usa estado neutro até carregar a simulação")
check('ValepolisInstallations="*res://systems/valepolis_installation_registry.gd"' in project, "Autoload do registo de instalações configurado")
check('mkdir -p build' in workflow and 'tools/preflight.sh build/preflight-v0.3.0.txt' in workflow, "Workflow prepara pasta de relatório antes do preflight")
check('sdkmanager não encontrado' in workflow and 'build-tools;35.0.0' in workflow, "Workflow verifica SDK Manager e declara Android Build Tools")
required_secrets = ["secrets.ANDROID_KEYSTORE_BASE64", "secrets.ANDROID_KEYSTORE_PASSWORD", "secrets.ANDROID_KEY_ALIAS", "secrets.ANDROID_KEY_PASSWORD"]
check(all(secret in workflow for secret in required_secrets), "Workflow utiliza os quatro GitHub Secrets oficiais de assinatura")
check("valepolis-preview.keystore" not in workflow and "assinatura temporária" not in workflow.lower(), "Workflow não declara nem cria chave temporária")
check('keystore/release_password' in export, "Preset Android contém a opção de password da chave de release")

# Episode and neighborhood integrity.
episodes = load_json("data/episodes_200.json")
items = episodes.get("episodes", [])
keys = [(x.get("season"), x.get("episode")) for x in items]
season_counts = Counter(x.get("season") for x in items)
check(len(items) == 200 and len(set(keys)) == 200, f"Catálogo narrativo com 200 episódios únicos ({len(items)} encontrados)")
check(len(season_counts) == 20 and all(season_counts.get(i) == 10 for i in range(1, 21)), "20 temporadas com 10 episódios cada")
hoods_data = load_json("bairros_valepolis.json").get("neighborhoods", [])
hood_names = {x.get("name") for x in hoods_data}
city_script = (ROOT / "systems/city_3d.gd").read_text(encoding="utf-8")
city_names_match = re.search(r'const NEIGHBORHOODS := \[(.*?)\]', city_script, re.S)
city_names = set(re.findall(r'"([^"\n]+)"', city_names_match.group(1))) if city_names_match else set()
check(len(hood_names) == 25 and len(city_names) == 25 and hood_names == city_names, "Os 25 bairros coincidem entre catálogo e mapa 3D")
population = load_json("populacao_valepolis.json")
pop_names = [x.get("name") for x in population.get("neighborhoods", [])]
pop_shares = [float(x.get("population_share", 0.0)) for x in population.get("neighborhoods", [])]
approved_population = load_json("data/populacao_por_bairro_v030.json")
approved_rows = approved_population.get("neighborhoods", [])
approved_map = {x.get("name"): int(x.get("population_proposed", -1)) for x in approved_rows}
root_map = {x.get("name"): int(x.get("population", -1)) for x in population.get("neighborhoods", [])}
hood_map = {x.get("name"): int(x.get("population", -1)) for x in hoods_data}
check(len(pop_names) == 25 and set(pop_names) == hood_names, "Distribuição populacional usa exatamente os 25 bairros oficiais")
check(len(pop_shares) == 25 and abs(sum(pop_shares) - 1.0) < 1e-8, "As quotas populacionais somam 100%")
check(approved_population.get("population_total") == 1000000 and sum(approved_map.values()) == 1000000, "Distribuição aprovada totaliza exatamente 1.000.000 habitantes")
check(len(approved_map) == 25 and set(approved_map) == hood_names, "Distribuição aprovada tem exatamente os 25 bairros oficiais")
check(root_map == approved_map, "populacao_valepolis.json coincide com a distribuição aprovada")
check(hood_map == approved_map, "bairros_valepolis.json coincide com a distribuição aprovada")
check(all(abs(float(x.get("population_share", -1)) - approved_map.get(x.get("name"), 0) / 1000000.0) < 1e-8 for x in population.get("neighborhoods", [])), "Quotas populacionais correspondem às populações aprovadas")

# The economy must remain disabled until the owner configures it.
economy = load_json("data/economy_config.json")
main = (ROOT / "main.gd").read_text(encoding="utf-8")
runtime = (ROOT / "systems/valepolis_systems_runtime.gd").read_text(encoding="utf-8")
salary_catalog = load_json("data/salary_by_profession_proposal_v030.json")
salary_records = salary_catalog.get("professions", [])
salary_ids = [str(item.get("ID", "")) for item in salary_records]
tax_model = economy.get("tax_model") or {}
check(
    salary_catalog.get("status") == "approved_gameplay_reference_rules"
    and len(salary_records) == 800
    and all(salary_ids)
    and len(set(salary_ids)) == len(salary_ids)
    and all(item.get("Salario_bruto_mensal_proposto_EUR") is not None for item in salary_records)
    and economy.get("status") == "approved_rules_values_pending"
    and tax_model.get("social_security_rate") == 0.11
    and isinstance(tax_model.get("irs_marginal_brackets"), list)
    and isinstance(tax_model.get("consumption_tax_rates"), dict),
    "Catálogo salarial de referência presente; modelo fiscal aprovado com valores operacionais pendentes"
)
check('money += 25.0' not in main and 'Dinheiro: €' not in main and '"renda":250.0' not in main, "Sem saldo, salário ou despesa de demonstração ativa no main.gd")
check('income_value == null' in main and 'expenses_value == null' in main, "UI financeira suporta campos por definir sem converter null em valores falsos")
check('economy.get("balance", null) == null' in runtime and 'Economia por definir; transação não registada.' in runtime, "Runtime bloqueia transações quando a economia não está configurada")
check('while v030_population_agents.size() < 200' in main and 'V030_CHARACTER_GENERATOR.generate_name' in main, "População detalhada preparada para 200 agentes com nomes fictícios únicos")
check('"income": null' in main and '"employment": "por_definir"' in main and '"capacity": 120' not in main, "Agentes sem rendimentos fictícios e sem capacidade residencial inventada")
systems_runtime = (ROOT / "systems/valepolis_systems_registry.gd").read_text(encoding="utf-8")
check('const ACTIVE_DETAIL_TARGET := 200' in systems_runtime and '"economy": "deferred_pending_owner_definition"' in systems_runtime, "Registo canónico alinhado com 200 agentes e economia adiada")
check('func v030_complete_mission(' in main and 'team_id.is_empty() or not v030_teams.has(team_id)' in main and 'vehicle_id.is_empty() or not v030_vehicles.has(vehicle_id)' in main and 'func v030_update_dispatches() -> void:\n    # O tempo decorrido' in main, "Missões só terminam por transição explícita com equipa e viatura registadas")
check('v030_buildings = {}' in main, "Inventário de edifícios físicos não é fabricado antes da aprovação do mapa")
check('func v030_update_inventories() -> void:\n    # O inventário só muda' in main and 'stock[item] = clampi(int(stock[item]) + 1' not in main, "Inventário não recebe stock automático fictício")
check('func v030_update_finance() -> void:\n    # Nenhuma receita/despesa é inferida' in main and 'income += float(v030_city_state.get("commerce"' not in main, "Economia não gera receitas/despesas por fórmulas de demonstração")

# Installation proposal / hosted-unit rules.
registry = load_json("data/installation_registry_v030.json")
rows = registry.get("installations", [])
embedded = registry.get("embedded_units", [])
check(len(rows) == 275 and all(not row.get("map_spawned", False) and row.get("building_id") is None for row in rows), "275 propostas de instalações sem criação automática no mapa")
check(registry.get("count_summary", {}).get("tnur_standalone_installations") == 0, "TNUR sem instalações independentes")
check(all(unit.get("standalone_installation") is False and unit.get("counts_as_physical_location") is False for unit in embedded), "Unidades integradas não duplicam locais físicos")
check('func get_map_spawnable_installations()' in (ROOT / "systems/valepolis_installation_registry.gd").read_text(encoding="utf-8") and '_build_registered_installations()' in city_script, "Ligação 3D só consulta instalações explicitamente aprovadas")
check('Base TNUR' not in city_script and '_service_building(' not in city_script and 'Hospital_Municipal' not in city_script, "Mapa 3D não cria bases/serviços físicos não aprovados nem base TNUR independente")

# No active V0.2-prefixed symbols. Historical documentation is intentionally not rewritten.
active_v020 = []
for path in ROOT.rglob("*.gd"):
    text = path.read_text(encoding="utf-8", errors="replace")
    if re.search(r'^(?:func|const|var)\s+(?:v020_|V020_)', text, re.M):
        active_v020.append(path.relative_to(ROOT).as_posix())
check(not active_v020, "Sem funções/constantes/variáveis V0.2 ativas nos scripts")

# Valepolis 3D Studio: audit references to removed legacy map/character placeholder art.
check(not (ROOT / "assets/ui/panel_mapa.png").exists(), "Sem painel PNG antigo do mapa")
check(not (ROOT / "assets/ui/panel_personagem.png").exists(), "Sem painel PNG antigo da personagem")
main_source = (ROOT / "main.gd").read_text(encoding="utf-8")
check("V030_CHARACTER_ASSETS" not in main_source, "Interface sem referência à biblioteca PNG antiga de personagens")
check('"Generated3DCharacterHero"' in main_source and "_v030_create_runtime_character_preview" in main_source, "Perfil usa pré-visualização procedural 3D")
city_source = (ROOT / "systems/city_3d.gd").read_text(encoding="utf-8")
check("_ground_height(" in city_source and "terrain_generator.gd" in city_source, "Geometria da cidade consulta altura do relevo próprio")

for msg in passes:
    print("PASS|" + msg)
for msg in failures:
    print("FAIL|" + msg)
for msg in notes:
    print("INFO|" + msg)
print(f"PROJECT_AUDIT={'PASS' if not failures else 'FAIL'}|passes={len(passes)}|failures={len(failures)}")
sys.exit(0 if not failures else 1)

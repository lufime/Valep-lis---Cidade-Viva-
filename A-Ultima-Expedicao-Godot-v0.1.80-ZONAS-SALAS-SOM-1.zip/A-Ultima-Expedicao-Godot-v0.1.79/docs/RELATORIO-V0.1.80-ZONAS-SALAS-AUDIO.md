# A Última Expedição — V0.1.80
## Visibilidade das zonas, sinalética e som localizado

Alterações nesta versão:
- Aumentada a distância de visibilidade interior e reduzido o efeito de nevoeiro que podia ocultar módulos distantes da estação.
- Reforçada a identificação das zonas principais e das salas anexas com letreiros mais legíveis.
- Adicionado ambiente industrial espacial às zonas 03–10 e às salas auxiliares; o som diminui com a distância.
- Mantidos os construtores existentes de salas, mobiliário, equipamentos, provas, portas e sistemas de jogo.

Validação honesta:
- O ZIP original foi extraído e o script alterado diretamente.
- A integridade do ZIP e verificações estáticas serão feitas após empacotamento.
- Godot 4.5 não está instalado neste ambiente; compilação, execução 3D, áudio real, colisões e exportação Android não foram testados.

extends StaticBody3D

var opened := false

func interact(_actor: Node) -> void:
	var expedition := get_parent()
	if expedition and not bool(expedition.get("coop_solved")):
		return
	if opened:
		position.x = 0.0
		opened = false
	else:
		position.x = 2.55
		opened = true

func open_for_coop() -> void:
	if opened:
		return
	position.x = 2.55
	opened = true

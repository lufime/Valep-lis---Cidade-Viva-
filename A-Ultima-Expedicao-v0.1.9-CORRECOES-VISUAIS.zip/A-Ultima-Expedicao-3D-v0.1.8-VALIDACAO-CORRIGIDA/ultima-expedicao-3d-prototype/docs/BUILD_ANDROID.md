# Build Android — v0.1.8

O workflow `.github/workflows/build-android.yml` instala Godot 4.5 e os templates oficiais, importa os recursos, executa um teste de arranque headless e tenta exportar uma APK Android de depuração.

## Como executar no GitHub (também pelo telemóvel)
1. Enviar o conteúdo deste ZIP para o repositório GitHub, mantendo `ultima-expedicao-3d-prototype/` e `.github/workflows/build-android.yml` nos caminhos indicados.
2. Abrir o separador **Actions** do repositório.
3. Escolher **A Última Expedição 3D v0.1.8 — Build Android** e carregar em **Run workflow**.
4. Aguardar a conclusão. Se o workflow terminar com sucesso, abrir a execução e descarregar o artefacto `A-Ultima-Expedicao-v0.1.8-Android-Build`; a APK estará dentro do ZIP do artefacto.
5. Se falhar, descarregar os logs do artefacto e corrigir o primeiro erro real antes de voltar a executar.

A APK gerada é de depuração e não está assinada para publicação na Play Store. A criação deste workflow não significa que uma APK já tenha sido compilada; a compilação real ocorre no runner do GitHub Actions.

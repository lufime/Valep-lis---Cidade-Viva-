# A Última Expedição — Android v0.4.0

Protótipo cooperativo de terror psicológico e mistério para 2–10 jogadores. Preserva as nove zonas, provas, stress, ameaça, tempo, dificuldades, pontuação e objetivos públicos.

## Plano aplicado nesta versão
- Mantém o jogo local existente.
- Liga dispositivos próximos através do módulo Android baseado em Google Nearby Connections (Bluetooth/BLE/Wi-Fi, sem exigir Internet).
- Acrescenta protocolo experimental de mensagens JSON: `HELLO`, `WELCOME`, `STATE` e pedidos `ACTION`; o anfitrião publica snapshots da partida e os clientes aplicam o estado recebido.
- O anfitrião é a autoridade da partida; pedidos remotos repetidos são filtrados por sequência por ligação.
- Os objetivos são públicos e incluídos no estado sincronizado.

## Estado e limitações
**Não declarar como multijogador validado.** A sincronização foi implementada como camada experimental, mas ainda precisa de testes em dois ou mais Android reais. Não foi executada compilação Android nem teste físico nesta sessão. A reconexão após perda de anfitrião, validação completa de turnos/identidade do jogador e tratamento de concorrência exigem testes e trabalho adicional.

## Compilação
1. Coloca esta pasta ou o ZIP no repositório GitHub.
2. Confirma `.github/workflows/android-apk.yml` no ramo pretendido.
3. Executa **Actions → A Última Expedição v0.4.0 — Nearby e APK Android → Run workflow**.
4. Só descarrega o artefacto se a execução terminar com sucesso.
5. Testa em pelo menos dois Android reais: permissões, descoberta, aceitação, ações remotas, estado final e desconexão.

## Testes recomendados
- 2, 6 e 10 jogadores;
- cada dispositivo envia uma ação e recebe atualização;
- anfitrião desliga-se;
- dois pedidos chegam quase ao mesmo tempo;
- Android 12+ e versões Android suportadas pelo projeto.

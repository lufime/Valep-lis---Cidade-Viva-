# Plano de desenvolvimento — A Última Expedição

## Objetivo
Multijogador local real para 2–10 telemóveis Android, sem Internet, com Bluetooth/Wi-Fi através de Nearby Connections. Atmosfera de terror psicológico e mistério; objetivos públicos.

## Fases
1. **Camada de transporte** — descoberta, aceitação, mensagens e desconexão. Base já presente no módulo nativo.
2. **Protocolo de partida** — anfitrião autoritativo; snapshots de estado e pedidos de ação com sequência. Implementação experimental incluída em v0.4.0.
3. **Atribuição de jogadores** — associar cada dispositivo a um único jogador e rejeitar ações de outros jogadores fora do turno. Pendente.
4. **Robustez** — reconexão, duplicação/ordenação de mensagens, anfitrião perdido e limite real de dez dispositivos. Pendente.
5. **Validação Android** — compilar via GitHub Actions e testar com dois, seis e dez aparelhos. Pendente; nenhum teste físico declarado como aprovado.

## Critérios de aceitação
- Sem Internet e com permissões autorizadas, dois Android encontram-se e ligam-se.
- O anfitrião cria a expedição e todos os clientes recebem o mesmo mapa, provas, tempo, stress, ameaça, pontuação e objetivos públicos.
- Uma ação autorizada é aplicada uma única vez e a atualização chega a todos os clientes.
- A perda de ligação é indicada sem apagar silenciosamente a partida.
- APK só é considerada compilada se o workflow terminar com sucesso; só é considerada testada depois de teste físico documentado.

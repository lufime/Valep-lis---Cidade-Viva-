# Valepólis — Cidade Viva V0.3.0 (Kotlin Android)

## Direção técnica
Esta base inicia a migração de Godot/GDScript para Android nativo com Kotlin. A aplicação usa uma Activity Android nativa e registos JSON em `app/src/main/assets/data/`. Google Filament está declarado como dependência para a futura camada de renderização 3D.

## Estado honesto da migração
- Estrutura Android/Kotlin e navegação inicial: base implementada.
- Registos JSON e imagens selecionadas: incluídos como assets.
- Sistemas de simulação completos, despacho integral, mundo 3D interativo, animações e equivalência funcional total: ainda por migrar.
- A APK só pode ser considerada compilada após sucesso real do workflow GitHub Actions.

## Regras preservadas nesta base
- Valepólis: 1.000.000 habitantes e 25 bairros.
- 200 episódios em 20 temporadas.
- TNUR integrada nas bases BRIGADA, sem bases independentes.
- Propostas de instalações não aprovadas não são criadas automaticamente.
- A economia não deve fabricar saldos, receitas ou despesas.
- A interface deve priorizar legibilidade móvel e alvos de toque grandes.

## Compilação
Executar o workflow **Valepólis V0.3.0 — Kotlin Android Build** em GitHub Actions. Usa Java 17, Gradle 8.9 e Android API 35. O artefacto esperado é `app-debug.apk` com o respetivo SHA-256.


## Fase 1 — território e legibilidade móvel

Esta entrega melhora a legibilidade da navegação nativa e passa a apresentar os 25 registos territoriais a partir de `bairros_valepolis.json`, incluindo nome, população de referência, função territorial e estado tal como fornecidos no JSON. O painel também verifica a quantidade de registos narrativos encontrada em `episodes_200.json`.

**Limitações explícitas:** isto ainda não é a migração completa. Não existe nesta fase um mapa 3D interativo funcional, nem os sistemas completos de trânsito, NPCs, despacho, viaturas ou persistência. Os ecrãs de operações/equipas/veículos/instalações continuam informativos e não devem ser tratados como módulos concluídos.

## Verificação da fase

- Verificar visualmente no Android a legibilidade e navegação.
- Confirmar que a secção Bairros apresenta 25 registos com dados lidos do JSON.
- Confirmar que o painel identifica 200 episódios no registo.
- Compilar novamente no GitHub Actions; esta entrega não declara compilação aprovada até existir uma execução bem-sucedida.


## Fase 2 — mapa territorial 2D

Foi acrescentada uma visualização territorial 2D na secção Bairros. Os pontos e nomes dos bairros são lidos de `bairros_valepolis.json` e posicionados pelas coordenadas `world_position_xz`. É possível tocar num ponto para destacar o bairro e mostrar o seu papel territorial.

A costa norte, o rio/estuário ocidental e as montanhas orientais são representados nesta fase como zonas esquemáticas de orientação. As linhas de estrada também são esquemáticas, não são a rede viária real. Esta visualização **não é um mapa 3D nem substitui o renderizador de terreno**.

Ainda pendente: mapa 3D, geometria e edifícios detalhados, rede viária real, navegação/câmara, tráfego, NPCs e sistemas de despacho.


## Fase 2.1 — legibilidade do mapa territorial

Ajuste visual após teste no telemóvel: os nomes longos sobrepunham-se no mapa. Os marcadores passaram a mostrar números e a lista abaixo apresenta os nomes completos na mesma ordem. O cabeçalho identifica agora corretamente a Fase 2. A geometria continua esquemática e 2D; não é ainda o mapa 3D final.


## Fase 3 — navegação territorial

Adicionados controlos de zoom (+/−/repor) e deslocação por arrastamento na visualização territorial. A seleção por toque mantém-se. A camada continua 2D e esquemática; não existe ainda um renderizador 3D funcional, nem uma rede viária real migrada. Os dados de trânsito são configuração, não geometria de estradas.


## Fase 4 — protótipo de visualização 3D nativa

Foi adicionado um ecrã experimental OpenGL ES 2.0 com terreno base, faixa costeira, estradas esquemáticas, volumes de edifícios e volumes de montanha. A geometria é procedural e serve apenas para estabelecer o caminho de renderização 3D na app Android.

**Limitações:** a geometria ainda não é derivada da matriz territorial completa nem representa os 25 bairros com fidelidade. Não inclui edifícios reais, relevo importado, rede viária oficial, personagens, trânsito ou gameplay. É um protótipo de renderer, não o mapa 3D final. Compilação e teste Android ainda necessários.


## Fase 4.1 — correção da superfície OpenGL

Ajustada a composição da `GLSurfaceView` dentro do conteúdo rolável e acrescentado diagnóstico Logcat para erros de inicialização do renderer. Necessário testar no Android; ainda não declarar o mapa 3D funcional até aparecer terreno e edifícios no dispositivo.


## Fase 4.2 — diagnóstico visível do OpenGL

Acrescentado estado do renderizador no ecrã e logs de tamanho da superfície. Ajustada a ordem de composição da `GLSurfaceView`. Necessário validar no telemóvel antes de declarar o mapa 3D funcional.


## Fase 4.3 — enquadramento e controlo direto da vista 3D

Após a captura do dispositivo, foram ajustados o enquadramento e a densidade da geometria provisória, adicionada uma grelha de ruas esquemática e rotação por arrastamento na superfície. O mapa continua a ser um protótipo procedural: não corresponde ainda ao território oficial nem deve ser apresentado como mapa final. Necessita de nova compilação e validação no dispositivo.

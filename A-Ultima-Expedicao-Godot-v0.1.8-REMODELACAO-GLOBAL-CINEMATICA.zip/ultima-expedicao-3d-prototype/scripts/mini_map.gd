extends Control
## Mini-mapa dinâmico da sala: mostra apenas pessoas/entidade em movimento.
## Não desenha o corredor de saída.

var world: Node3D
var player: Node3D
const ROOM_WIDTH := 12.0
const ROOM_DEPTH := 16.0
const ROOM_CENTER_Z := -2.0
# Sensores térmicos virtuais distribuídos pela sala (coordenadas do cenário).
const HEAT_SENSORS: Array[Vector3] = [
    Vector3(-4.2, 1.2, -7.0),
    Vector3(4.2, 1.2, -7.0),
    Vector3(-3.8, 1.2, 2.2),
    Vector3(3.8, 1.2, 2.2)
]
var heat_phase := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	world = get_tree().current_scene
	if is_instance_valid(world):
		player = world.get_node_or_null("Player") as Node3D
	queue_redraw()

func _process(delta: float) -> void:
    heat_phase += delta
	if not is_instance_valid(world):
		world = get_tree().current_scene
	if is_instance_valid(world) and not is_instance_valid(player):
		player = world.get_node_or_null("Player") as Node3D
	queue_redraw()

func _map_pos(world_pos: Vector3, room_rect: Rect2) -> Vector2:
	var nx := clampf((world_pos.x + ROOM_WIDTH * 0.5) / ROOM_WIDTH, 0.035, 0.965)
	var nz := clampf((world_pos.z - (ROOM_CENTER_Z - ROOM_DEPTH * 0.5)) / ROOM_DEPTH, 0.035, 0.965)
	return Vector2(room_rect.position.x + nx * room_rect.size.x, room_rect.position.y + nz * room_rect.size.y)

func _draw_person(pos: Vector2, yaw: float, color: Color, radius: float, is_local: bool) -> void:
	var forward := Vector2(sin(yaw), cos(yaw))
	var tip := pos + forward * (radius * 2.2)
	var side := Vector2(-forward.y, forward.x) * radius
	draw_colored_polygon(PackedVector2Array([tip, pos - forward * radius + side, pos - forward * radius - side]), color)
	draw_circle(pos, radius * 0.55, Color(0.94, 0.98, 1.0))
	if is_local:
		draw_arc(pos, radius * 1.65, 0.0, TAU, 20, Color(0.25, 1.0, 0.55, 0.9), 1.3)

func _draw_marker(pos: Vector2, color: Color, label: String, diamond: bool = false) -> void:
	if diamond:
		var r := 4.5
		draw_colored_polygon(PackedVector2Array([pos + Vector2(0, -r), pos + Vector2(r, 0), pos + Vector2(0, r), pos + Vector2(-r, 0)]), color)
	else:
		draw_circle(pos, 4.0, color)
	draw_string(ThemeDB.fallback_font, pos + Vector2(6, -4), label, HORIZONTAL_ALIGNMENT_LEFT, 66.0, 8, Color(0.82, 0.91, 0.96))

func _draw() -> void:
	if size.x < 30.0 or size.y < 30.0:
		return
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.015, 0.035, 0.045, 0.96), true)
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.12, 0.88, 0.96, 0.95), false, 2.0)
	draw_string(ThemeDB.fallback_font, Vector2(9, 15), "MAPA · SALA AO VIVO · T=CALOR", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.65, 0.95, 1.0))
	var room_rect := Rect2(Vector2(9, 23), size - Vector2(18, 31))
	draw_rect(room_rect, Color(0.06, 0.12, 0.15, 0.96), true)
	draw_rect(room_rect, Color(0.25, 0.9, 1.0), false, 1.6)
	for i in range(1, 4):
		var x := room_rect.position.x + room_rect.size.x * float(i) / 4.0
		var y := room_rect.position.y + room_rect.size.y * float(i) / 4.0
		draw_line(Vector2(x, room_rect.position.y), Vector2(x, room_rect.end.y), Color(0.1, 0.34, 0.39, 0.4), 1.0)
		draw_line(Vector2(room_rect.position.x, y), Vector2(room_rect.end.x, y), Color(0.1, 0.34, 0.39, 0.4), 1.0)

	# Sensores térmicos: os marcadores indicam a localização do sensor;
	# o anel muda de cor/intensidade quando deteta uma fonte quente próxima.
	var heat_sources: Array[Vector3] = []
	if is_instance_valid(player):
		heat_sources.append(player.global_position)
	if is_instance_valid(world):
		var entity := world.get("entity_presence") as Node3D
		if is_instance_valid(entity) and entity.visible:
			heat_sources.append(entity.global_position)
		var remotes: Variant = world.get("remote_players")
		if remotes is Dictionary:
			for peer_id in remotes.keys():
				var avatar := remotes[peer_id] as Node3D
				if is_instance_valid(avatar):
					heat_sources.append(avatar.global_position)

	for i in range(HEAT_SENSORS.size()):
		var sensor_world := HEAT_SENSORS[i]
		var sensor_pos := _map_pos(sensor_world, room_rect)
		var detected := false
		var nearest_distance := 999.0
		for source_pos in heat_sources:
			var distance := Vector2(source_pos.x - sensor_world.x, source_pos.z - sensor_world.z).length()
			nearest_distance = minf(nearest_distance, distance)
			if distance <= 5.0:
				detected = true
		var pulse := 0.65 + 0.35 * absf(sin(heat_phase * 3.0 + float(i)))
		var sensor_color := Color(0.2, 0.85, 1.0, 0.95)
		if detected:
			sensor_color = Color(1.0, 0.22 + 0.18 * pulse, 0.08, 0.98)
			draw_circle(sensor_pos, 8.0 + 2.0 * pulse, Color(1.0, 0.12, 0.04, 0.12 + 0.1 * pulse))
			draw_arc(sensor_pos, 8.0 + 2.0 * pulse, 0.0, TAU, 24, sensor_color, 1.6)
		else:
			draw_arc(sensor_pos, 5.5, 0.0, TAU, 20, sensor_color, 1.2)
		draw_circle(sensor_pos, 2.7, sensor_color)
		draw_string(ThemeDB.fallback_font, sensor_pos + Vector2(6, 3), "T%d" % (i + 1), HORIZONTAL_ALIGNMENT_LEFT, 22.0, 7, sensor_color)

	# Jogador local: posição e orientação atualizadas continuamente.
	if is_instance_valid(player):
		_draw_person(_map_pos(player.global_position, room_rect), player.global_rotation.y, Color(0.28, 1.0, 0.52), 5.0, true)
		_draw_string_label(_map_pos(player.global_position, room_rect) + Vector2(7, 10), "TU", Color(0.45, 1.0, 0.65))

	# Outros jogadores: os avatares remotos já são atualizados pela rede.
	if is_instance_valid(world):
		var remotes: Variant = world.get("remote_players")
		if remotes is Dictionary:
			for peer_id in remotes.keys():
				var avatar := remotes[peer_id] as Node3D
				if is_instance_valid(avatar):
					_draw_person(_map_pos(avatar.global_position, room_rect), avatar.global_rotation.y, Color(0.25, 0.72, 1.0), 4.6, false)
					_draw_string_label(_map_pos(avatar.global_position, room_rect) + Vector2(6, 10), "P%s" % str(peer_id), Color(0.48, 0.8, 1.0))

		# Entidade em movimento: visível no mapa apenas quando está presente no cenário.
		var entity := world.get("entity_presence") as Node3D
		if is_instance_valid(entity) and entity.visible:
			var entity_pos := _map_pos(entity.global_position, room_rect)
			draw_circle(entity_pos, 7.0, Color(1.0, 0.12, 0.18, 0.18))
			draw_arc(entity_pos, 7.0, 0.0, TAU, 24, Color(1.0, 0.18, 0.24), 1.5)
			draw_circle(entity_pos, 3.5, Color(1.0, 0.18, 0.24))
			_draw_string_label(entity_pos + Vector2(7, -5), "PRESENÇA", Color(1.0, 0.45, 0.45))

func _draw_string_label(pos: Vector2, label: String, color: Color) -> void:
	draw_string(ThemeDB.fallback_font, pos, label, HORIZONTAL_ALIGNMENT_LEFT, 70.0, 8, color)

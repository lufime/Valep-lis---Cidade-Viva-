# A Última Expedição 3D — v0.1.8 Validação e Correções de Base

Protótipo experimental Godot 4.5: exploração em primeira pessoa, controlos táteis, painel LAN, relés cooperativos, pistas privadas, votação narrativa, furtividade e entidade reativa.

## Correções nesta versão
- Corrigida uma string inválida no texto de ajuda dos controlos táteis.
- Adicionado painel recolhível “REDE LAN” para criar sessão ou entrar pelo IP do anfitrião (porta UDP 24567), ancorado à direita para se adaptar melhor a ecrãs estreitos.
- O agachamento altera a câmara, velocidade e cápsula de colisão.
- O aviso de interação distingue os relés da porta.
- Relatório de validação em `docs/RELATORIO_VALIDACAO.md`.

## Abrir
Importar a pasta `ultima-expedicao-3d-prototype` no Godot 4.5 e executar `project.godot`.

## Estado dos testes
O ZIP foi verificado. O motor Godot 4.5 não está disponível neste ambiente, pelo que não foi possível compilar/importar ou executar o projeto. A rede entre dispositivos, os RPCs, os controlos táteis em Android e a exportação APK **continuam por validar**. Esta versão não está aprovada para lançamento.

## Build Android
Foi incluído `export_presets.cfg` para Android e o workflow `.github/workflows/build-android.yml`. O workflow executa importação, teste de arranque headless e exportação de APK debug no GitHub Actions. Instruções: `docs/BUILD_ANDROID.md`. A APK só existirá depois de uma execução do workflow terminar com sucesso; não foi compilada neste ambiente.


## Controlos táteis Android
- Joystick virtual no canto inferior esquerdo: andar em qualquer direção.
- Arrastar no lado direito do ecrã: rodar a câmara.
- Botões do lado direito: interagir, lanterna e agachar/levantar.
\n\n## Vozes e vocalizações contextuais (v0.1.8)\n\nForam adicionados efeitos vocais sintéticos locais, sem dependência de Internet: sussurro distante quando a entidade inicia a perseguição, grito curto em perigo imediato, gemido quando desaparece ao ser observada e gasp quando a equipa ativa os dois relés. São vocalizações não verbais; diálogo falado com palavras ainda precisa de gravações/locução próprias. Os eventos têm cooldown para evitar repetição excessiva.\n

## Modo cooperativo WLAN (sem Internet)
- Ambos os telemóveis têm de estar ligados à mesma rede Wi-Fi local. A rede pode não ter acesso à Internet.
- No telemóvel anfitrião, toque em **Criar sessão**.
- Descubra o endereço IPv4 local do anfitrião nas definições Wi-Fi do Android.
- No segundo telemóvel, abra **REDE LAN**, introduza esse endereço IPv4 (não use `127.0.0.1`) e toque em **Ligar**.
- A porta de jogo é UDP 24567. Se a rede tiver isolamento de clientes, os dispositivos podem não conseguir comunicar.
- Esta versão usa ENet sobre WLAN. **Não implementa Bluetooth nem Wi-Fi Direct**.
- O estado do código e os RPCs ainda precisam de ser testados no Godot 4.5 e em dois dispositivos reais; este ZIP não é uma compilação validada.

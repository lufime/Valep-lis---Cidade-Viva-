# Valepólis V0.3.0 — Registo de aprovação global

**Data:** 13-10-2026  
**Estado:** aprovado para implementação e integração documental.

## Deliberação

Por instrução expressa do responsável pelo projeto, ficam aprovadas para implementação todas as regras e propostas pendentes constantes da documentação disponível do projeto Valepólis V0.3.0, desde que não contradigam decisões oficiais anteriores. Esta deliberação abrange a proposta de quantidades de instalações como metas de planeamento e a organização modular da progressão por temporadas.

## Regras preservadas

- Cidade: Valepólis; população de referência: 1.000.000.
- 25 bairros oficiais e seis influências culturais, sem redistribuir culturas ou nomes por suposição.
- Progressão prevista: 200 episódios em 20 temporadas, 10 episódios por temporada.
- BRIGADA, S.U.E., TNUR e Polícia mantêm as regras de pertença e integração já aprovadas; TNUR integrado nas bases BRIGADA, sem instalações independentes.
- As quantidades da tabela de instalações ficam aprovadas como metas de planeamento, não como autorização para inventar coordenadas, moradas, IDs, capacidades, horários, efetivos, orçamentos, viaturas ou inventários.
- As propostas de instalação modular por temporadas ficam aprovadas como direção de organização; não se inventam tamanhos de download, requisitos de armazenamento ou conteúdo ainda inexistente.

## Critérios obrigatórios de implementação e validação

1. A aprovação documental não equivale a implementação técnica. Cada sistema deve ser integrado no projeto e coberto por testes executados.
2. O mapa 3D só passa quando a renderização efetiva for confirmada; a presença de nós, câmara ou terreno não é suficiente.
3. O `SubViewport` deve estar ativo, ter dimensões válidas e atualizar a cena. Se a renderização falhar, o PRE-FLIGHT falha e a cartografia 2D permanece disponível.
4. A exportação APK e a validação em Android só podem ser declaradas concluídas com logs de exportação e teste correspondentes.
5. Os 200 episódios só podem ser declarados totalmente jogáveis depois de cada episódio possuir objetivos, condições de conclusão e progressão verificáveis.
6. Não enfraquecer nem ignorar um teste falhado para obter um resultado PASS.
7. Preservar a interface aprovada e os dados oficiais não relacionados com a correção.

## Estado técnico inicial desta revisão

O relatório de CI mais recente disponível indica `MAP_RENDER_FAIL` e `TOTAL_FAIL=1`. Por isso, o estado do mapa permanece **por validar** até o teste ser executado novamente e passar. Esta decisão não declara a APK compilada nem o jogo integralmente concluído.

# Proposta de quantidades de instalações — Valepólis V0.3.0

**Estado: quantidades aprovadas para planeamento por deliberação global de 13-10-2026. A aprovação não cria edifícios no mapa nem aprova coordenadas, moradas, IDs, capacidades, horários ou efetivos ainda não definidos.**

Referência: 1.000.000 de habitantes e 25 bairros, organizados em cinco agrupamentos de cinco bairros. Este documento regista quantidades para planeamento; não cria instalações físicas no mapa.

| Categoria | Quantidade proposta | Contagem física | Regra / distribuição |
|---|---:|---|---|
| Bases BRIGADA | 13 | 13 locais | 1 central + 12 operacionais |
| Bases S.U.E. | 10 | 10 locais | 1 central + 9 bases de resposta médica |
| Instalações policiais gerais | 15 | 15 locais | 1 comando + 14 esquadras |
| Centros TNUR integrados | 10 | 0 locais adicionais | Dentro de bases BRIGADA; não são instalações independentes |
| Centros administrativos municipais | 5 | 5 locais | Um por agrupamento |
| Hospitais | 12 | 12 locais | Dimensões e especialidades por definir |
| Centros de saúde | 25 | 25 locais | Alvo médio de um por bairro |
| Escolas | 100 | 100 locais | Média de quatro por bairro |
| Centros de serviços públicos | 25 | 25 locais | Alvo médio de um por bairro |
| Bases de manutenção municipal | 5 | 5 locais | Uma por agrupamento |
| Unidades policiais especializadas | 5 | 0 locais adicionais | Unidades funcionais alojadas nas 15 instalações policiais gerais |
| Centros logísticos e de abastecimento | 10 | 10 locais | Zonas estratégicas por definir |
| Mercados municipais | 5 | 5 locais | Um por agrupamento |
| Parques e jardins públicos | 50 | 50 espaços | Média de dois por bairro |

## Contagem após auditoria de dupla contagem conhecida

- **225 instalações construídas / centros / estabelecimentos** propostos.
- **50 parques e jardins públicos** propostos.
- **275 registos de localização física** propostos, assumindo locais separados para as categorias físicas.
- **10 centros TNUR integrados** dentro de bases BRIGADA; **0** instalações TNUR independentes.
- **5 unidades policiais especializadas** integradas nas 15 instalações policiais gerais; **0** instalações especializadas adicionais.

## Regras obrigatórias

1. As quantidades desta tabela ficam aprovadas como metas de planeamento; a implantação física só pode ocorrer após existirem dados de localização e identificadores validados.
2. TNUR pertence à estrutura da BRIGADA; os centros TNUR ficam dentro de bases BRIGADA e não aumentam o total de instalações.
3. As unidades policiais especializadas são funções/unidades internas, não edifícios adicionais nesta proposta.
4. Não preencher nem inferir efetivos, economia, viaturas, inventário, orçamento ou saldo.
5. Não gerar moradas, edifícios ou marcadores no mapa apenas com base nestas quantidades. A localização por bairro, IDs globais, capacidade e horários ficam por definir.
6. Comércio e empresas privadas são variáveis e não entram no subtotal fixo.
7. A distribuição por agrupamento é orientativa. A colocação final deve considerar população, geografia, rede rodoviária e tempos de resposta.
8. A contagem de 275 elimina as sobreposições conhecidas entre TNUR/BRIGADA e unidades policiais especializadas/polícia geral. Possíveis co-localizações de outras categorias ficam por validar após atribuição de moradas.

## Campos deliberadamente em aberto

Efetivos, economia, viaturas, inventário, orçamento, saldo, localização exata, IDs únicos, capacidade e horários.

# A Última Expedição — Android v0.1.0

Protótipo de terror psicológico e mistério para adultos, pensado para 2–10 jogadores.

## O que contém
- Interface responsiva para ecrãs Android.
- Configuração de 2 a 10 participantes.
- Mapa estratégico com nove locais.
- Investigação de pistas, turnos, tempo, stress e pontuação.
- Objetivos privados básicos e finais de expedição.
- Workflow GitHub Actions para compilar um APK de depuração.

## Limitações importantes
Esta versão é um **protótipo local**: todos os participantes jogam no mesmo dispositivo, passando o telemóvel de pessoa para pessoa. Não tem ainda salas online, sincronização entre telemóveis, contas, chat ou servidor multijogador. Os objetivos privados são mostrados no ecrã partilhado, pelo que não são realmente secretos neste modo local.

O APK **não foi compilado nem testado neste ambiente**. O workflow permite tentar a compilação no GitHub Actions; só considerar o APK válido depois de o workflow terminar com sucesso e de o instalar e testar num dispositivo Android real.

## Compilar APK pelo GitHub usando apenas o telemóvel
1. Cria um repositório GitHub vazio.
2. Carrega o conteúdo deste ZIP para a raiz do repositório, incluindo a pasta `.github`.
3. Abre o separador **Actions** e permite workflows, se o GitHub pedir.
4. Executa **A Última Expedição — Android APK** em **Run workflow**, ou faz push para `main`/`master`.
5. Quando o workflow terminar com sucesso, abre a execução e descarrega o artefacto `A-Ultima-Expedicao-Android-debug`.
6. Extrai o ZIP do artefacto e instala `app-debug.apk` no Android. Poderá ser necessário autorizar a instalação a partir dessa origem.

## Próxima etapa técnica
Para cumprir o requisito de cada pessoa jogar no seu próprio telemóvel, é necessário implementar backend de salas online, códigos de convite, estado de jogo autoritativo no servidor, reconexão e canais separados para objetivos privados. Isso ainda não está incluído nesta versão.

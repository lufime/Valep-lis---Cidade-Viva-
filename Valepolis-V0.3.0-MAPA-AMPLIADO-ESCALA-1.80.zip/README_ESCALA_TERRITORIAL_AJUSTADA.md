# Valepólis V0.3.0 — Ajuste da extensão do terreno

## Alteração
- Reduzida a extensão-base do terreno procedural de 192 × 176 para 136 × 124 unidades.
- O fator global existente (1,45) mantém a extensão final aproximada em 197 × 180 unidades.
- O objetivo é reduzir a proporção de terreno vazio em relação à cidade construída, sem aumentar apenas a escala de todo o mundo.
- Preservados os nomes dos 25 bairros, a distribuição de população, as regras aprovadas, as estradas e os sistemas existentes.

## Limites e validação
- As unidades do Godot continuam a ser unidades técnicas, não uma escala geográfica oficial em metros.
- A extensão foi escolhida para manter as coordenadas máximas existentes do mapa (vias até aproximadamente ±51 e costa/estuário a norte/oeste) dentro da área de terreno com margem.
- Verificações estáticas e integridade do ZIP não substituem a inspeção visual/runtime no Godot. Ainda falta confirmar margens do terreno, colisões, água, relevo, circulação e exportação APK.

# Valepólis V0.3.0 — ajuste de escala global

Este pacote mantém o projeto completo e ajusta a escala da personagem, do marcador, da etiqueta e do zoom para acompanhar a expansão do mundo 3D. A alteração não inventa dimensões geográficas oficiais.

Ver `RELATORIO_ESCALA_GLOBAL_V030.md` para os detalhes e limitações de validação.

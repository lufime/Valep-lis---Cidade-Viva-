# Valepólis V0.3.0 — correção dos limites do terreno

Esta revisão corrige a redução indevida do terreno procedural introduzida na versão anterior.

- `terrain_width = 192.0` unidades-base.
- `terrain_depth = 176.0` unidades-base.
- O fator `WORLD_EXPANSION_FACTOR = 1.45` foi mantido, não sendo apresentado como uma escala geográfica real.
- Dimensões finais nominais após expansão: 278,4 × 255,2 unidades do Godot.

A razão para restaurar estes limites é geométrica: os dados existentes posicionam partes da rede viária e localidades até cerca de X=-85 e Z=62 antes da expansão. Um terreno de 136 × 124 unidades-base, centrado na origem, só cobre aproximadamente X=±68 e Z=±62, deixando parte do mundo fora da superfície gerada. A configuração 192 × 176 cobre os limites existentes com margem, sem inventar novas coordenadas de bairros.

## Limitações

Isto corrige a extensão do terreno em relação às coordenadas já existentes; não define metros reais nem valida a qualidade visual, colisões, estradas, pontes ou APK. Esses pontos exigem execução do projeto no Godot e inspeção no dispositivo.

# Relatório — escala territorial corrigida

## Correção
Restaurados os valores de terreno procedural para 192 × 176 unidades-base. A versão anterior reduzia-os para 136 × 124, embora as coordenadas de estradas e localidades se estendam além desses limites.

## Cálculo
- 192 × 1,45 = 278,4
- 176 × 1,45 = 255,2

Os resultados são unidades do mundo Godot, não metros reais.

## Verificações estáticas executadas
- Valores do terreno confirmados no script.
- Fator de expansão mantido em 1,45.
- Extremos das coordenadas existentes comparados com os limites do terreno.
- ZIP testado com `unzip -t`.

## Não executado
Não foi possível executar Godot neste ambiente. Não se afirma aprovação de runtime, colisões, renderização, navegação ou exportação Android.

# Valepólis V0.3.0 — coerência de escala (alteração técnica)

## Alterações
- Mantido o fator global já existente `WORLD_EXPANSION_FACTOR = 1.45` para o mundo gerado.
- A personagem, criada depois da expansão, recebe o mesmo fator de escala.
- Etiqueta e marcador da personagem ajustados para acompanhar a escala.
- Distâncias padrão e limites de zoom ajustados proporcionalmente para não perder o enquadramento após a expansão.
- Não foram alterados população, nomes dos 25 bairros, regras de jogo nem dimensões geográficas oficiais não documentadas.

## Limitações importantes
Este ajuste procura coerência entre o mundo já expandido e os elementos criados depois. Não estabelece uma escala geográfica real em metros: o projeto não tem, neste momento, uma referência oficial de área total e distâncias geográficas aprovadas. O fator 1.45 existente é um fator técnico, não uma medição geográfica.

## Validação
Verificação estática do código e integridade do ZIP. Godot não estava disponível para executar a cena, pelo que colisões, escala visual, controlos e exportação Android permanecem por validar em runtime.

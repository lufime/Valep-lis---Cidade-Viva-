# Relatório — Ajuste territorial de escala V0.3.0

- `terrain_width`: 192.0 → 136.0
- `terrain_depth`: 176.0 → 124.0
- Fator global preservado: `WORLD_EXPANSION_FACTOR = 1.45`
- Extensão final nominal do terreno: cerca de 197 × 180 unidades, em vez de cerca de 278 × 255.
- Não se alteraram posições dos bairros, dados populacionais, nomes, regras de jogo ou workflow.

## Verificações efetuadas
- Confirmadas as duas novas dimensões no gerador de terreno.
- Confirmada a preservação do fator global de 1.45.
- Confirmados `project.godot` e `.github/workflows/build.yml`.
- ZIP submetido a teste de integridade.

## Não verificado
- Execução no Godot, inspeção visual, colisões, travessia das pontes e compilação/instalação Android. Não declarar esses testes aprovados.

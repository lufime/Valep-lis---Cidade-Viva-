# Valepólis V0.3.0 — Mapa ampliado

Esta revisão aumenta o terreno procedural para 256 × 256 unidades-base e o fator de expansão do mundo de 1,45 para 1,80. A mudança é global: aplica-se aos elementos 3D gerados, posições, percursos e referências de câmara que já usam WORLD_EXPANSION_FACTOR.

## Limites
- Unidades Godot, não metros geográficos oficiais.
- A expansão não reorganiza individualmente os bairros; aumenta as separações e os objetos existentes uniformemente.
- Não foi possível executar o projeto no Godot neste ambiente; colisões, aparência, estradas, pontes e APK permanecem por validar.
- A alteração deve ser testada visualmente antes de ser considerada final.

# Relatório — mapa ampliado

Alterações realizadas:
1. `terrain_width`: 192 → 256 unidades.
2. `terrain_depth`: 176 → 256 unidades.
3. `WORLD_EXPANSION_FACTOR`: 1,45 → 1,80.

Verificações estáticas: valores esperados encontrados nos dois scripts; ficheiros do projeto e workflow mantidos.

Não executado: importação/execução Godot, inspeção visual, teste de colisões, condução de veículos, travessia de pontes, compilação/instalação APK. Não declarar estes testes aprovados.

package pt.ultimaexpedicao.nearby

import android.Manifest
import android.os.Build
import com.getcapacitor.*
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import com.google.android.gms.tasks.Task
import org.json.JSONObject
import java.nio.charset.StandardCharsets

@CapacitorPlugin(
    name = "NearbyLink",
    permissions = [
        Permission(alias = "nearby", strings = [Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.NEARBY_WIFI_DEVICES])
    ]
)
class NearbyLinkPlugin : Plugin() {
    private val serviceId = "pt.ultimaexpedicao.game.nearby"
    private val strategy = Strategy.P2P_STAR
    private val endpoints = linkedSetOf<String>()
    private val pendingActions = mutableMapOf<String, String>()
    private val names = mutableMapOf<String, String>()
    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                val bytes = payload.asBytes() ?: return
                val data = String(bytes, StandardCharsets.UTF_8)
                val event = JSObject().put("endpointId", endpointId).put("data", data)
                notifyListeners("nearbyMessage", event)
            }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }
    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            names[endpointId] = info.endpointName
            Nearby.getConnectionsClient(context).acceptConnection(endpointId, payloadCallback)
            notifyListeners("nearbyStatus", JSObject().put("message", "A aceitar ligação de ${info.endpointName}…"))
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                endpoints.add(endpointId)
                notifyListeners("nearbyConnected", JSObject().put("endpointId", endpointId).put("name", names[endpointId] ?: "Dispositivo"))
            } else {
                notifyListeners("nearbyStatus", JSObject().put("message", "A ligação falhou (${result.status.statusCode})."))
            }
        }
        override fun onDisconnected(endpointId: String) {
            endpoints.remove(endpointId)
            notifyListeners("nearbyDisconnected", JSObject().put("endpointId", endpointId))
        }
    }
    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            names[endpointId] = info.endpointName
            notifyListeners("deviceFound", JSObject().put("endpointId", endpointId).put("name", info.endpointName))
        }
        override fun onEndpointLost(endpointId: String) {
            notifyListeners("nearbyStatus", JSObject().put("message", "Um dispositivo deixou de estar visível."))
        }
    }
    @PluginMethod fun startHost(call: PluginCall) {
        requestNearbyPermissions(call, "host") {
            val name = call.getString("name") ?: "Anfitrião"
            Nearby.getConnectionsClient(context).startAdvertising(name, serviceId, lifecycle, AdvertisingOptions.Builder().setStrategy(strategy).build())
                .addOnSuccessListener { call.resolve(); notifyListeners("nearbyStatus", JSObject().put("message", "Sala anunciada.")) }
                .addOnFailureListener { call.reject("Falha ao anunciar sala: ${it.message}") }
        }
    }
    @PluginMethod fun startScan(call: PluginCall) {
        requestNearbyPermissions(call, "scan") {
            Nearby.getConnectionsClient(context).startDiscovery(serviceId, discovery, DiscoveryOptions.Builder().setStrategy(strategy).build())
                .addOnSuccessListener { call.resolve() }
                .addOnFailureListener { call.reject("Falha ao procurar dispositivos: ${it.message}") }
        }
    }
    @PluginMethod fun connect(call: PluginCall) {
        val id = call.getString("endpointId") ?: return call.reject("endpointId obrigatório")
        val name = call.getString("name") ?: "Investigador"
        Nearby.getConnectionsClient(context).requestConnection(name, id, lifecycle)
            .addOnSuccessListener { call.resolve() }
            .addOnFailureListener { call.reject("Falha ao pedir ligação: ${it.message}") }
    }
    @PluginMethod fun send(call: PluginCall) {
        val data = call.getString("data") ?: return call.reject("data obrigatório")
        val bytes = data.toByteArray(StandardCharsets.UTF_8)
        if (bytes.size > 30000) return call.reject("Mensagem demasiado grande")
        val payload = Payload.fromBytes(bytes)
        if (endpoints.isEmpty()) return call.reject("Não há dispositivos ligados")
        Nearby.getConnectionsClient(context).sendPayload(endpoints.toList(), payload)
            .addOnSuccessListener { call.resolve() }
            .addOnFailureListener { call.reject("Falha ao enviar mensagem: ${it.message}") }
    }
    @PluginMethod fun stop(call: PluginCall) {
        Nearby.getConnectionsClient(context).stopAdvertising()
        Nearby.getConnectionsClient(context).stopDiscovery()
        Nearby.getConnectionsClient(context).stopAllEndpoints()
        endpoints.clear(); names.clear(); call.resolve()
        notifyListeners("nearbyStatus", JSObject().put("message", "Ligação terminada."))
    }
    private fun requestNearbyPermissions(call: PluginCall, action: String, onGranted: () -> Unit) {
        val perms = JSArray()
        if (Build.VERSION.SDK_INT >= 31) {
            perms.put(Manifest.permission.BLUETOOTH_SCAN)
            perms.put(Manifest.permission.BLUETOOTH_CONNECT)
            perms.put(Manifest.permission.BLUETOOTH_ADVERTISE)
        } else {
            perms.put(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        if (Build.VERSION.SDK_INT >= 33) perms.put(Manifest.permission.NEARBY_WIFI_DEVICES)
        if (getPermissionState("nearby") != PermissionState.GRANTED) {
            pendingActions[call.callbackId] = action
            requestPermissionForAlias("nearby", call, "nearbyPermissionCallback")
        } else onGranted()
    }
    @PermissionCallback private fun nearbyPermissionCallback(call: PluginCall) {
        if (getPermissionState("nearby") == PermissionState.GRANTED) {
            val action = pendingActions.remove(call.callbackId)
            if (action == "host") { val name = call.getString("name") ?: "Anfitrião"; Nearby.getConnectionsClient(context).startAdvertising(name, serviceId, lifecycle, AdvertisingOptions.Builder().setStrategy(strategy).build()).addOnSuccessListener { call.resolve() }.addOnFailureListener { call.reject("Falha ao anunciar sala: ${it.message}") } } else { Nearby.getConnectionsClient(context).startDiscovery(serviceId, discovery, DiscoveryOptions.Builder().setStrategy(strategy).build()).addOnSuccessListener { call.resolve() }.addOnFailureListener { call.reject("Falha ao procurar dispositivos: ${it.message}") } }
        } else call.reject("Permissões de dispositivos próximos recusadas")
    }
}

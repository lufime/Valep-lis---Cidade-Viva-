#!/usr/bin/env python3
"""Force the local Nearby plugin into the generated Capacitor Android app."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
android = root / "android"
settings = android / "settings.gradle"
if not settings.exists():
    settings = android / "settings.gradle.kts"
if not settings.exists():
    raise SystemExit("Não foi encontrado settings.gradle(.kts) do Android.")

settings_text = settings.read_text()
if "capacitor-nearby-link" not in settings_text:
    if settings.suffix == ".kts":
        settings_text += '\ninclude(":capacitor-nearby-link")\nproject(":capacitor-nearby-link").projectDir = file("../node_modules/capacitor-nearby-link/android")\n'
    else:
        settings_text += "\ninclude ':capacitor-nearby-link'\nproject(':capacitor-nearby-link').projectDir = new File(settingsDir, '../node_modules/capacitor-nearby-link/android')\n"
    settings.write_text(settings_text)

app_gradle = android / "app" / "capacitor.build.gradle"
if not app_gradle.exists():
    app_gradle = android / "app" / "build.gradle"
if not app_gradle.exists():
    raise SystemExit("Não foi encontrado o Gradle da aplicação Android.")
app_text = app_gradle.read_text()
if "capacitor-nearby-link" not in app_text:
    match = re.search(r"dependencies\s*\{", app_text)
    if match:
        pos = match.end()
        app_text = app_text[:pos] + "\n    implementation project(':capacitor-nearby-link')" + app_text[pos:]
    else:
        app_text += "\ndependencies { implementation project(':capacitor-nearby-link') }\n"
    app_gradle.write_text(app_text)

activities = list((android / "app" / "src" / "main" / "java").rglob("MainActivity.java"))
if not activities:
    raise SystemExit("MainActivity.java não encontrado; não foi possível registar o plugin explicitamente.")
activity = activities[0]
source = activity.read_text()
registry = android / "app" / "src" / "main" / "assets" / "capacitor.plugins.json"
registry_has_plugin = registry.exists() and "NearbyLinkPlugin" in registry.read_text(errors="ignore")
if not registry_has_plugin and "NearbyLinkPlugin.class" not in source:
    if "import com.getcapacitor.BridgeActivity;" not in source:
        raise SystemExit("MainActivity não tem o import esperado de BridgeActivity.")
    source = source.replace(
        "import com.getcapacitor.BridgeActivity;",
        "import com.getcapacitor.BridgeActivity;\nimport pt.ultimaexpedicao.nearby.NearbyLinkPlugin;",
        1,
    )
    needle = "public class MainActivity extends BridgeActivity {"
    if needle not in source:
        raise SystemExit("Estrutura de MainActivity não reconhecida; registo abortado.")
    source = source.replace(
        needle,
        needle + "\n    @Override\n    public void onCreate(android.os.Bundle savedInstanceState) {\n        registerPlugin(NearbyLinkPlugin.class);\n        super.onCreate(savedInstanceState);\n    }",
        1,
    )
    activity.write_text(source)
elif registry_has_plugin:
    print("Capacitor já incluiu NearbyLinkPlugin no registo gerado; não será duplicado na MainActivity.")

plugin_java = root / "node_modules" / "capacitor-nearby-link" / "android" / "src" / "main" / "java" / "pt" / "ultimaexpedicao" / "nearby" / "NearbyLinkPlugin.java"
if not plugin_java.is_file():
    raise SystemExit(f"Fonte Java do plugin não encontrada: {plugin_java}")
print("NearbyLink registado explicitamente em", activity)
print("Projeto nativo incluído em", settings)
print("Dependência incluída em", app_gradle)

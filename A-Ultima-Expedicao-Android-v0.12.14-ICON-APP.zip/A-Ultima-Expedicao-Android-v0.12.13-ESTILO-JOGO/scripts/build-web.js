const fs = require('node:fs');
const path = require('node:path');
const esbuild = require('esbuild');
const root = path.resolve(__dirname, '..');
(async () => {
  for (const file of ['www/index.html', 'www/js/multiplayer-protocol.js', 'www/js/nearby-bridge.src.js']) {
    if (!fs.existsSync(path.join(root, file))) throw new Error('Falta ficheiro obrigatório: ' + file);
  }
  await esbuild.build({
    entryPoints: [path.join(root, 'www/js/nearby-bridge.src.js')],
    outfile: path.join(root, 'www/js/nearby-bridge.bundle.js'),
    bundle: true, format: 'iife', platform: 'browser', target: ['es2020'],
    logLevel: 'info'
  });
  console.log('Bridge Nearby compilada para www/js/nearby-bridge.bundle.js');
})();

import { registerPlugin } from '@capacitor/core';
export interface NearbyLinkPlugin { startHost(options: {name:string}): Promise<void>; startScan(options: {name:string}): Promise<void>; connect(options: {endpointId:string; name?:string}): Promise<void>; send(options: {data:string}): Promise<void>; sendTo(options: {endpointId:string; data:string}): Promise<void>; stop(): Promise<void>; }
export const NearbyLink = registerPlugin<NearbyLinkPlugin>('NearbyLink');

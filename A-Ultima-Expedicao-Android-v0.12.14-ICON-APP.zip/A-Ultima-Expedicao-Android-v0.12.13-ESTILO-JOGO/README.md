# A Última Expedição v0.12.8 — Áudio reativo

Esta versão parte do projeto v0.11.1 e mantém o mapa tátil, os nove locais, os cenários visuais, a lógica de investigação e o multijogador local Nearby Connections.

## Evolução do áudio
- A banda sonora muda dinamicamente conforme ameaça, stress e zona selecionada.
- A narração é acionada por descoberta de pistas, acontecimentos perigosos, progresso de objetivos e fim da expedição, com controlo para reduzir repetições.
- Nas zonas isoladas, o motor Web Audio gera uma textura baixa de ruído filtrado para sugerir sussurros indistintos. Não é uma nova gravação de voz inteligível.
- O volume continua ajustável e o som pode ser desligado no painel de áudio.
- Os ficheiros MP3 locais incluídos são `ambiente.mp3`, `tensao.mp3`, `ameaca.mp3`, `voz-entrada.mp3`, `voz-pista.mp3`, `voz-ameaca.mp3` e `voz-silencio.mp3`.

## Testes e limitações
- Os ficheiros de áudio acima estão incluídos no ZIP; isso **não** significa que o áudio tenha sido validado numa APK instalada.
- A validação de sintaxe JavaScript e os testes de protocolo podem ser executados localmente sem APK.
- Este ZIP não inclui uma APK pré-compilada. A compilação Android é feita pelo GitHub Actions.
- A reprodução, mistura de música/voz, comportamento em segundo plano e multijogador entre telefones devem ser testados numa APK real em dispositivos Android.

## Compilar
1. Enviar o conteúdo do projeto para o repositório GitHub, mantendo `.github/workflows/android-apk.yml`.
2. Executar o workflow `A Última Expedição v0.12.8 — Testes e APK Android` em Actions.
3. Só considerar a APK validada se o workflow terminar com sucesso e os testes físicos forem feitos.

import { registerPlugin } from '@capacitor/core';
// Capacitor bundle: expose the native plugin proxy for the plain HTML interface.
window.NearbyLink = registerPlugin('NearbyLink');

# Plano multijogador — v0.7.0

## Fase atual: validar protocolo e preparar build
- [x] Parser de mensagens com lista permitida de tipos e limite de tamanho.
- [x] Validação de ações permitidas.
- [x] Validação estrutural básica do estado sincronizado.
- [x] Proteção de sequência crescente (helper testado; integração total continua por validar).
- [x] Testes automáticos executáveis por `npm test`.
- [ ] Compilar APK no GitHub Actions.
- [ ] Testar descoberta e ligação em 2 Android sem Internet.
- [ ] Confirmar que a mesma prova e a mesma decisão aparecem nos dois ecrãs.
- [ ] Testar desconexão e reconexão.
- [ ] Testar 6 e 10 dispositivos.

## Critério de avanço
Só considerar a primeira missão cooperativa validada quando dois Android reais, sem Internet, conseguem criar/entrar numa sala, trocar mensagens, realizar uma ação, sincronizar o estado e concluir a missão sem divergências.


## v0.8.0 — bridge nativa
A bridge `NearbyLink` é agora incluída no bundle web através de esbuild e a interface só considera o módulo disponível quando `Capacitor.isNativePlatform()` é verdadeiro. Abrir a página no Chrome continua a mostrar a mensagem de indisponibilidade, de forma intencional. A APK tem de ser compilada e instalada para aceder ao módulo nativo.


## v0.12.9 — Influência secreta (implementação inicial)
- [x] Protocolo aceita mensagens `SECRET`.
- [x] Plugin Android adiciona `sendTo(endpointId, data)` para entrega dirigida.
- [x] O anfitrião seleciona secretamente um jogador por condições variáveis da partida.
- [x] A mensagem de influência é enviada apenas ao dispositivo escolhido; a identidade não entra no estado público sincronizado.
- [x] Interface mostra instruções privadas no dispositivo destinatário.
- [x] Ações do jogador influenciado podem sofrer interferência de registo, com consequência visível no registo da expedição.
- [ ] Compilar a APK com Gradle no GitHub Actions.
- [ ] Validar entrega privada em pelo menos dois Android reais.
- [ ] Testar que os restantes dispositivos não recebem a mensagem `SECRET`.
- [ ] Rever equilíbrio e confirmar que a sabotagem não bloqueia a missão.

**Limitação conhecida:** a entrega privada e a sabotagem foram implementadas no código, mas não estão validadas em dispositivos Android reais nesta sessão. O ambiente local não tem a dependência `esbuild` instalada, por isso o bundle web e a APK não foram compilados aqui.

extends Control
## Mapa esquemático de todo o complexo: edifício, acessos e área exterior.
## Coordenadas de mundo convertidas para uma vista global fixa (não apenas a sala).

var world: Node3D
var player: Node3D
var heat_phase := 0.0
# Fog of war: the layout is concealed until the local player physically explores it.
const FOG_COLS := 27
const FOG_ROWS := 43
const REVEAL_RADIUS := 4.8
var explored_cells: Dictionary = {}
var _fog_update_accumulator := 0.0
# Limites comuns ao terreno criado por _build_world_foundation() em expedition.gd.
# Incluem a estação, as dez zonas e o exterior sem cortar os módulos finais.
const WORLD_MIN_X := -38.3
const WORLD_MAX_X := 38.3
const WORLD_MIN_Z := -217.3
const WORLD_MAX_Z := 15.3
const HEAT_SENSORS: Array[Vector3] = [
    Vector3(-4.2, 1.2, -7.0), Vector3(4.2, 1.2, -7.0),
    Vector3(-3.8, 1.2, 2.2), Vector3(3.8, 1.2, 2.2)
]

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    _resolve_world()
    queue_redraw()

func _process(delta: float) -> void:
    heat_phase += delta
    _fog_update_accumulator += delta
    if not is_instance_valid(world) or not is_instance_valid(player):
        _resolve_world()
    if _fog_update_accumulator >= 0.12:
        _fog_update_accumulator = 0.0
        _update_exploration()
        queue_redraw()

func _resolve_world() -> void:
    var ancestor: Node = get_parent()
    while is_instance_valid(ancestor):
        if ancestor.get_node_or_null("Player") is Node3D:
            world = ancestor
            player = ancestor.get_node_or_null("Player") as Node3D
            return
        ancestor = ancestor.get_parent()
    world = null
    player = null

func _map_pos(p: Vector3, r: Rect2) -> Vector2:
    var nx := clampf((p.x - WORLD_MIN_X) / (WORLD_MAX_X - WORLD_MIN_X), 0.0, 1.0)
    var nz := clampf((p.z - WORLD_MIN_Z) / (WORLD_MAX_Z - WORLD_MIN_Z), 0.0, 1.0)
    return Vector2(r.position.x + nx * r.size.x, r.position.y + nz * r.size.y)

func _world_rect(x1: float, z1: float, x2: float, z2: float, r: Rect2) -> Rect2:
    var a := _map_pos(Vector3(x1, 0, z1), r)
    var b := _map_pos(Vector3(x2, 0, z2), r)
    # Z cresce para baixo no ecrã, enquanto as coordenadas do mundo crescem
    # no sentido oposto; normalizar evita Rect2 com largura/altura negativas.
    var top_left := Vector2(minf(a.x, b.x), minf(a.y, b.y))
    var rect_size := Vector2(absf(b.x - a.x), absf(b.y - a.y))
    return Rect2(top_left, rect_size)

func _fit_world_rect(panel: Rect2) -> Rect2:
    # O mapa é esquemático: usa toda a área disponível para manter salas,
    # corredores e marcadores legíveis em ecrãs móveis. As coordenadas de
    # cada objeto continuam a ser convertidas a partir das mesmas dimensões
    # do mundo; só a representação visual é adaptada ao painel.
    return panel

func _label(pos: Vector2, value: String, color: Color, font_size: int = 8) -> void:
    draw_string(ThemeDB.fallback_font, pos, value, HORIZONTAL_ALIGNMENT_LEFT, 100.0, font_size, color)

func _draw_person(pos: Vector2, yaw: float, color: Color, radius: float, local: bool) -> void:
    var f := Vector2(sin(yaw), cos(yaw))
    var side := Vector2(-f.y, f.x) * radius * 0.72
    draw_colored_polygon(PackedVector2Array([pos + f * radius * 1.7, pos - f * radius + side, pos - f * radius - side]), color)
    draw_circle(pos, radius * 0.52, Color(0.94, 0.98, 1.0))
    if local:
        draw_arc(pos, radius * 1.65, 0.0, TAU, 20, Color(0.25, 1.0, 0.55, 0.95), 1.3)

func _draw_marker(pos: Vector2, color: Color, text: String, radius: float = 3.0) -> void:
    draw_circle(pos, radius + 2.0, Color(color.r, color.g, color.b, 0.14))
    draw_circle(pos, radius, color)
    _label(pos + Vector2(4, -3), text, color, 7)


func _cell_for_world_position(pos: Vector3) -> Vector2i:
    var col := clampi(int(floor((pos.x - WORLD_MIN_X) / (WORLD_MAX_X - WORLD_MIN_X) * FOG_COLS)), 0, FOG_COLS - 1)
    var row := clampi(int(floor((pos.z - WORLD_MIN_Z) / (WORLD_MAX_Z - WORLD_MIN_Z) * FOG_ROWS)), 0, FOG_ROWS - 1)
    return Vector2i(col, row)

func _cell_key(col: int, row: int) -> String:
    return "%d:%d" % [col, row]

func _update_exploration() -> void:
    if not is_instance_valid(player):
        return
    var pos := player.global_position
    var center := _cell_for_world_position(pos)
    var cells_x := int(ceil(REVEAL_RADIUS / ((WORLD_MAX_X - WORLD_MIN_X) / FOG_COLS))) + 1
    var cells_z := int(ceil(REVEAL_RADIUS / ((WORLD_MAX_Z - WORLD_MIN_Z) / FOG_ROWS))) + 1
    var changed := false
    for row in range(maxi(0, center.y - cells_z), mini(FOG_ROWS, center.y + cells_z + 1)):
        for col in range(maxi(0, center.x - cells_x), mini(FOG_COLS, center.x + cells_x + 1)):
            var wx := WORLD_MIN_X + (float(col) + 0.5) / FOG_COLS * (WORLD_MAX_X - WORLD_MIN_X)
            var wz := WORLD_MIN_Z + (float(row) + 0.5) / FOG_ROWS * (WORLD_MAX_Z - WORLD_MIN_Z)
            if Vector2(wx - pos.x, wz - pos.z).length() <= REVEAL_RADIUS:
                var key := _cell_key(col, row)
                if not explored_cells.has(key):
                    explored_cells[key] = true
                    changed = true
    if changed:
        queue_redraw()

func _is_world_position_explored(pos: Vector3) -> bool:
    var cell := _cell_for_world_position(pos)
    return explored_cells.has(_cell_key(cell.x, cell.y))

func _draw_fog_of_war(r: Rect2) -> void:
    var cell_w := r.size.x / FOG_COLS
    var cell_h := r.size.y / FOG_ROWS
    # Merge contiguous unexplored cells into one rectangle per run to keep mobile rendering cheap.
    for row in range(FOG_ROWS):
        var run_start := -1
        for col in range(FOG_COLS + 1):
            var hidden := col < FOG_COLS and not explored_cells.has(_cell_key(col, row))
            if hidden and run_start < 0:
                run_start = col
            elif not hidden and run_start >= 0:
                var fog_rect := Rect2(r.position.x + run_start * cell_w, r.position.y + row * cell_h, (col - run_start) * cell_w + 0.35, cell_h + 0.35)
                draw_rect(fog_rect, Color(0.002, 0.004, 0.006, 0.995), true)
                run_start = -1

func _draw() -> void:
    if size.x < 30.0 or size.y < 30.0:
        return
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.012, 0.027, 0.036, 0.97), true)
    draw_rect(Rect2(Vector2.ZERO, size), Color(0.12, 0.88, 0.96, 0.95), false, 2.0)
    _label(Vector2(7, 13), "MAPA TÁTICO · COMPLEXO VÉSPERA", Color(0.65, 0.95, 1.0), 9)
    var panel_rect := Rect2(Vector2(7, 20), size - Vector2(14, 27))
    draw_rect(panel_rect, Color(0.035, 0.075, 0.09, 0.98), true)
    var r := _fit_world_rect(panel_rect)
    draw_rect(r, Color(0.025, 0.055, 0.065, 0.98), true)
    # Grelha dentro da área à escala real.
    for i in range(1, 4):
        var gx := r.position.x + r.size.x * float(i) / 4.0
        draw_line(Vector2(gx, r.position.y), Vector2(gx, r.end.y), Color(0.13, 0.31, 0.36, 0.35), 1.0)
    for i in range(1, 5):
        var gy := r.position.y + r.size.y * float(i) / 5.0
        draw_line(Vector2(r.position.x, gy), Vector2(r.end.x, gy), Color(0.13, 0.31, 0.36, 0.35), 1.0)

    # Complexo em ciclo: representação tática do percurso aprovado.
    # A planta usa posições locais no painel para garantir leitura no telemóvel.
    var inner := Rect2(r.position + Vector2(r.size.x * 0.12, r.size.y * 0.13), r.size * Vector2(0.76, 0.72))
    var wall := Color(0.20, 0.83, 0.91, 0.95)
    var room_fill := Color(0.08, 0.19, 0.23, 0.98)
    var corridor_fill := Color(0.18, 0.40, 0.45, 0.98)
    # Circuito rectangular contínuo com duas alas e corredores de ligação.
    var left_x := inner.position.x + inner.size.x * 0.12
    var right_x := inner.position.x + inner.size.x * 0.88
    var top_y := inner.position.y + inner.size.y * 0.12
    var bottom_y := inner.position.y + inner.size.y * 0.82
    var room_w := maxf(13.0, inner.size.x * 0.20)
    var room_h := maxf(9.0, inner.size.y * 0.105)
    # Alas superior e inferior; salas numeradas 01–12 distribuídas pelo circuito.
    for i in range(4):
        var x := lerpf(left_x + room_w * 0.5, right_x - room_w * 0.5, float(i) / 3.0)
        var top_room := Rect2(Vector2(x - room_w * 0.5, top_y), Vector2(room_w, room_h))
        draw_rect(top_room, room_fill, true)
        draw_rect(top_room, wall, false, 1.0)
        _label(top_room.position + Vector2(3, 8), "%02d" % (i + 1), Color(0.88, 0.98, 1.0), 7)
        var bottom_room := Rect2(Vector2(x - room_w * 0.5, bottom_y), Vector2(room_w, room_h))
        draw_rect(bottom_room, room_fill, true)
        draw_rect(bottom_room, wall, false, 1.0)
        _label(bottom_room.position + Vector2(3, 8), "%02d" % (12 - i), Color(0.88, 0.98, 1.0), 7)
    # Salas laterais 05–08 completam o percurso em ciclo.
    for i in range(2):
        var y := lerpf(top_y + room_h * 1.5, bottom_y - room_h * 0.5, float(i))
        var left_room := Rect2(Vector2(left_x - room_w * 0.52, y), Vector2(room_w * 0.72, room_h))
        var right_room := Rect2(Vector2(right_x - room_w * 0.20, y), Vector2(room_w * 0.72, room_h))
        draw_rect(left_room, room_fill, true)
        draw_rect(left_room, wall, false, 1.0)
        _label(left_room.position + Vector2(3, 8), "%02d" % (5 + i), Color(0.88, 0.98, 1.0), 7)
        draw_rect(right_room, room_fill, true)
        draw_rect(right_room, wall, false, 1.0)
        _label(right_room.position + Vector2(3, 8), "%02d" % (8 - i), Color(0.88, 0.98, 1.0), 7)
    # Traçado luminoso contínuo no interior do anel.
    var route := PackedVector2Array([
        Vector2(left_x, top_y + room_h), Vector2(left_x, bottom_y),
        Vector2(right_x, bottom_y), Vector2(right_x, top_y + room_h)
    ])
    for i in range(route.size() - 1):
        draw_line(route[i], route[i + 1], corridor_fill, 4.0)
    draw_line(route[route.size() - 1], route[0], corridor_fill, 4.0)
    # Câmara secreta central: provas 13–15, desbloqueio após as 12 exteriores.
    var secret := Rect2(Vector2(r.position.x + r.size.x * 0.36, r.position.y + r.size.y * 0.43), Vector2(r.size.x * 0.28, r.size.y * 0.19))
    draw_rect(secret, Color(0.20, 0.08, 0.12, 0.98), true)
    draw_rect(secret, Color(1.0, 0.35, 0.25, 0.98), false, 1.4)
    _label(secret.position + Vector2(3, 9), "SALA SECRETA", Color(1.0, 0.72, 0.62), 7)
    _label(secret.position + Vector2(3, 18), "13 · 14 · 15", Color(1.0, 0.86, 0.80), 7)
    # Entradas A (principal) e B (serviço), assinaladas separadamente.
    var entry_a := Vector2(left_x, bottom_y + room_h)
    var entry_b := Vector2(right_x, top_y - 3.0)
    draw_circle(entry_a, 3.2, Color(0.30, 1.0, 0.62))
    _label(entry_a + Vector2(4, 2), "A", Color(0.42, 1.0, 0.70), 8)
    draw_circle(entry_b, 3.2, Color(1.0, 0.72, 0.24))
    _label(entry_b + Vector2(4, 2), "B", Color(1.0, 0.78, 0.35), 8)
    _label(Vector2(r.position.x + 4, r.end.y - 4), "CICLO · 12 EXTERIORES + 3 SECRETAS", Color(0.58, 0.90, 0.94), 7)

    # Sensores térmicos permanecem no interior, mas agora usam o mesmo mapa global.
    var sources: Array[Vector3] = []
    if is_instance_valid(player):
        sources.append(player.global_position)
    if is_instance_valid(world):
        var entity := world.get("entity_presence") as Node3D
        if is_instance_valid(entity) and entity.visible:
            sources.append(entity.global_position)
        var remotes: Variant = world.get("remote_players")
        if remotes is Dictionary:
            for peer_id in remotes.keys():
                var avatar := remotes[peer_id] as Node3D
                if is_instance_valid(avatar):
                    sources.append(avatar.global_position)
    for i in range(HEAT_SENSORS.size()):
        if not _is_world_position_explored(HEAT_SENSORS[i]):
            continue
        var sp := _map_pos(HEAT_SENSORS[i], r)
        var detected := false
        for source in sources:
            if Vector2(source.x - HEAT_SENSORS[i].x, source.z - HEAT_SENSORS[i].z).length() <= 5.0:
                detected = true
                break
        var pulse := 0.65 + 0.35 * absf(sin(heat_phase * 3.0 + float(i)))
        var c := Color(1.0, 0.27, 0.12) if detected else Color(0.2, 0.85, 1.0)
        if detected:
            draw_arc(sp, 5.0 + pulse * 2.0, 0.0, TAU, 20, c, 1.1)
        draw_circle(sp, 2.0, c)
        _label(sp + Vector2(3, 2), "T%d" % (i + 1), c, 6)

    if is_instance_valid(player):
        var pp := _map_pos(player.global_position, r)
        _draw_person(pp, player.global_rotation.y, Color(0.28, 1.0, 0.52), 3.8, true)
        _label(pp + Vector2(4, 8), "TU", Color(0.45, 1.0, 0.65), 7)
    if is_instance_valid(world):
        var remotes: Variant = world.get("remote_players")
        if remotes is Dictionary:
            for peer_id in remotes.keys():
                var avatar := remotes[peer_id] as Node3D
                if is_instance_valid(avatar) and _is_world_position_explored(avatar.global_position):
                    var rp := _map_pos(avatar.global_position, r)
                    _draw_person(rp, avatar.global_rotation.y, Color(0.25, 0.72, 1.0), 3.4, false)
                    _label(rp + Vector2(4, 7), "P%s" % str(peer_id), Color(0.48, 0.8, 1.0), 6)
        var entity := world.get("entity_presence") as Node3D
        if is_instance_valid(entity) and entity.visible and _is_world_position_explored(entity.global_position):
            _draw_marker(_map_pos(entity.global_position, r), Color(1.0, 0.18, 0.24), "?", 3.0)

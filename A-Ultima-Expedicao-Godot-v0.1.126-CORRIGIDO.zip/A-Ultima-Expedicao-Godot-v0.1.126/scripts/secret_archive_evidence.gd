extends StaticBody3D

var evidence_id: int = 1

func interact(player: Node = null) -> void:
	var world := get_parent()
	while world and not world.has_method("request_secret_archive_evidence"):
		world = world.get_parent()
	if world:
		world.request_secret_archive_evidence(evidence_id, player)

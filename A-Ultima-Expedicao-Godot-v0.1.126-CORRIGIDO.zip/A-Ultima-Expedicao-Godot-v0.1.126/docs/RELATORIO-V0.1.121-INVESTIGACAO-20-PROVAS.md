# A Última Expedição v0.1.121 — Investigação integrada (20 provas)

## Conteúdo
- Mantidas as 12 provas exteriores existentes e as 3 provas interativas da sala secreta.
- Adicionadas 5 provas especiais (16–20) em cinco zonas diferentes.
- Cada prova especial exige provas anteriores específicas, promovendo cruzamento de informação antes da recolha.
- A extração fica bloqueada até as 20 provas estarem reunidas, além dos restantes objetivos da missão.
- As novas provas apresentam descrições que distinguem observação, inferência e factos ainda não confirmados.

## Dependências para as provas especiais
- 16: provas 1 e 3.
- 17: provas 4 e 6.
- 18: provas 5 e 9.
- 19: provas 7 e 10.
- 20: provas 2, 8, 11 e 12.

## Limitações de validação
A alteração foi integrada estaticamente no script GDScript. Não foi possível executar o projeto no motor Godot nesta sessão; sintaxe em runtime, colisões, RPC multijogador e percurso devem ser testados no Godot antes de declarar a versão validada.

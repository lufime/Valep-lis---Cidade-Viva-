# A Última Expedição v0.1.119 — Provas da sala secreta

## Alterações
- Adicionados três objetos interativos exclusivos no arquivo VANTHIS: Registo Original, Relatório de Contenção e Arquivo de Encerramento.
- Cada objeto desaparece após recolha e apresenta o respetivo texto no HUD.
- A extração passa a exigir as três provas interiores, além dos objetivos anteriores.
- A recolha interior está bloqueada até a porta secreta estar aberta.

## Limites de validação
- Alteração estática ao código e estrutura do ZIP.
- Não foi executado o motor Godot nem um teste de jogo nesta sessão; a integração/runtime e o comportamento em rede continuam por validar.

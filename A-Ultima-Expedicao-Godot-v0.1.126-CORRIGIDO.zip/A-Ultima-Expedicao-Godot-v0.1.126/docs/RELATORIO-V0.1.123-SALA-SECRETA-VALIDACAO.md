# v0.1.123 — Auditoria da sala secreta

## Correções feitas
- A consola e a extração referem agora as 12 provas exteriores (em vez de mensagens desatualizadas sobre 10).
- A validação do código exige a presença de cada identificador exterior 1–12; não basta ter 12 entradas arbitrárias no dicionário.
- A porta continua a exigir as 12 provas e a síntese correta.
- As três provas interiores continuam a exigir a porta aberta, proximidade física do jogador e recolha única.
- A extração continua bloqueada até serem reunidas as três provas interiores e as cinco provas especiais, além dos relés e da síntese.

## Limites da verificação
Foram feitas verificações estáticas do conteúdo do ZIP e dos blocos de lógica alterados. Não foi possível executar o projeto no motor Godot nesta sessão; não declarar a sala funcionalmente testada até executar o jogo e os testes de rede.

# v0.1.124 — Código secreto implementado

## Objetivo
Transformar a descoberta da combinação `7314` num enigma dedutivo, com dados recuperados de quatro provas, em vez de apresentar a solução diretamente.

## Alterações
- Prova 2 define os quatro campos e a ordem de leitura.
- Prova 4 apresenta a sequência dos ciclos rejeitados e a primeira leitura estável.
- Prova 7 apresenta nove linhas de registo, incluindo duas marcadas `TESTE`; só contam as linhas com confirmação operacional.
- Prova 9 identifica o circuito isolado primeiro e o ciclo da primeira leitura estável, com metadados como distratores.
- O diário de síntese e a sincronização multijogador usam a mesma descrição das evidências.
- A validação mantém a combinação `7314`, exige as 12 provas exteriores e verifica proximidade física à consola.

## Verificações realizadas
- Integridade do ZIP verificada.
- Presença das quatro pistas e da combinação esperada verificada estaticamente.
- Guardas de acesso e diário de síntese verificados estaticamente.

## Limitações
O motor Godot não foi executado nesta sessão. Não se declara validada a sintaxe em runtime, a interação real nem a sincronização multijogador por execução.

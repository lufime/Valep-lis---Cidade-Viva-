# A Última Expedição — Blender Detalhes v0.1.116

## Alterações nos geradores Blender

- Exterior da estação: painéis de serviço, fixações, marcas de segurança, grelhas, condutas, cabos, luzes de estado e pequenos detalhes de neve/gelo.
- Interior modular: juntas, tiras antiderrapantes, grelhas de ventilação, armários técnicos, botões de emergência, dobradiças, marcas nas portas e suportes de cablagem.
- Criatura: placas dérmicas, costelas, mandíbula, dentes irregulares, sobrancelhas, nódulos e cicatrizes.
- Sobrevivente: bolsos, costuras, faixas refletoras, fivelas, bolsas de mochila e detalhes do capacete.
- Jogador rigado: bolsos, joelheiras, faixas refletoras, fechos e bolsas adicionais associadas aos grupos ósseos existentes.

## Validação e limites

Os scripts foram atualizados dentro do pacote e a sintaxe Python é verificada fora do Blender. O Blender não está disponível neste ambiente; por isso, os `.blend` e `.glb` já presentes não foram regenerados aqui e a qualidade visual, o rig e a exportação devem ser confirmados executando o workflow Blender no GitHub Actions. Não se declara o APK ou os modelos regenerados como testados.

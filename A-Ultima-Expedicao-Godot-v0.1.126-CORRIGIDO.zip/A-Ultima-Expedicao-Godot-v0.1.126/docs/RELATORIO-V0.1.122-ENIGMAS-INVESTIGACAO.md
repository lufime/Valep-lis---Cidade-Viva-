# v0.1.122 — Enigmas de investigação integrados

## Alterações
- As cinco provas especiais (16–20) passam a exigir tanto as provas de pré-requisito como uma comparação específica no dossiê.
- Pares exigidos: 3–5 para a prova 16; 4–9 para a 17; 6–10 para a 18; 7–10 para a 19; 2–12 para a 20.
- O registo da comparação é sincronizado no multijogador através de RPC validado por lista permitida.
- A mensagem de missão passa a explicitar que as provas especiais exigem investigação, não apenas recolha.

## Limitações de validação
O código foi alterado por análise estática do script existente. Não foi possível executar o projeto no Godot nesta sessão; por isso, a sintaxe/runtime Godot, o comportamento de RPC e a experiência de jogo ainda precisam de execução real. Este relatório não declara os testes aprovados.

# A Última Expedição v0.1.124 — correção geométrica do ciclo

## Alteração efetuada
- Ajustadas apenas as dimensões e posições das quatro secções de piso do anel da sala secreta.
- As secções norte/sul e oeste/este passam a sobrepor-se nos cantos e a alcançar as aberturas das entradas A e B.
- Mantidas as 12 provas exteriores, as 3 provas interiores, as 5 provas especiais, o código 7314 e os restantes ficheiros/conteúdos.

## Verificações realizadas
- Auditoria estática `tests/quality_audit.py`: 98 verificações aprovadas, 0 falhas.
- Conferência textual do bloco de geometria e das dimensões/posições do anel: concluída.
- Integridade do ZIP de saída: verificada após criação.

## Limitações
Não existe executável Godot disponível nesta sessão. Portanto, não foi possível executar o projeto, verificar colisões em runtime, percorrer o ciclo no jogo, testar multijogador ou exportar APK. A auditoria estática não substitui esses testes.

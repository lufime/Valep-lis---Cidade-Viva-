# A Última Expedição v0.1.120 — 15 provas e complexo cíclico

## Alterações
- 12 provas exteriores, incluindo dois objetos adicionais nas zonas 09 e 10.
- 3 provas interiores na sala secreta. Total planeado: 15 provas.
- A progressão exterior exige as 12 provas e a combinação VANTHIS antes de abrir o acesso.
- A sala secreta foi remodelada com percurso em anel retangular em torno da câmara central e duas aberturas assinaladas: Entrada A e Entrada B.
- O percurso cíclico tem guias visuais no piso e mantém a câmara central como elemento de referência.

## Verificação
- Foi validada a integridade estrutural do ZIP e a presença dos ficheiros/scripts alterados.
- Não foi executado o projeto no motor Godot nesta operação; colisões, navegação, multiplayer e exportação APK continuam por validar em runtime.

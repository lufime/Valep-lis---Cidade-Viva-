# V0.1.118 — Pistas mais realistas

## Alterações
- Reescritas as descrições das dez provas como observações de investigação: o que foi observado, o que não pode ser concluído e qual o próximo cruzamento recomendado.
- Adicionadas ressalvas sobre carimbos temporais, documentos em falta, cadeia de inferência e limites das gravações.
- Mantidas as relações investigativas existentes e a regra de que uma hipótese não identifica automaticamente o traidor.
- Acrescentados detalhes discretos aos modelos físicos de frascos e módulos de dados.
- Mantida a recolha autoritativa, a sincronização e o estado multijogador existentes.

## Validação
- ZIP aberto e verificado estruturalmente.
- Uma única raiz de projeto Godot; cena principal, scripts e assets existentes preservados.
- Não foi executado Godot 4.5 neste ambiente. A sintaxe GDScript, a apresentação 3D no jogo e o APK necessitam de validação no workflow.

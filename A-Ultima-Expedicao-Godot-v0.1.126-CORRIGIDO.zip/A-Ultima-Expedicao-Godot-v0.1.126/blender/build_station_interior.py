# Blender 4.x — kit modular interior estação polar. Gera .blend e GLB.
import bpy, os
root=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'));assets=os.path.join(root,'assets');os.makedirs(assets,exist_ok=True)
for o in list(bpy.data.objects): bpy.data.objects.remove(o,do_unlink=True)
def mat(n,c,metal=0,rough=.65):
 m=bpy.data.materials.new(n);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;return m
wall=mat('Insulated_Panel',(.24,.32,.35),.25);floor=mat('Floor_AntiSlip',(.09,.13,.15),.3);orange=mat('Emergency_Orange',(.95,.19,.025));glass=mat('Cold_Glass',(.04,.24,.3),.5,.25);light=mat('LED_Light',(.75,.9,1),.1,.25)
def cube(n,loc,dim,ma):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=bpy.context.object;o.name=n;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(ma);return o
# Corridor module 12x3.2x3.2 with segmented wall panels and open passage
cube('Corridor_Floor',(0,0,0),(12,.18,3),floor);cube('Corridor_Ceiling',(0,3.15,0),(12,.18,3),wall)
for x in [-5,-3,-1,1,3,5]:
 cube('Left_Wall_Panel_'+str(x),(x,1.58,-1.42),(1.9,3,.16),wall);cube('Right_Wall_Panel_'+str(x),(x,1.58,1.42),(1.9,3,.16),wall)
 cube('Ceiling_LED_'+str(x),(x,3.02,0),(1,.035,.38),light)
# bulkhead frames at ends and door panels along corridor
for x in [-5.8,5.8]:
 cube('Bulkhead_Frame_'+str(x),(x,1.55,0),(.22,3,3),orange)
for x in [-3,3]:
 cube('Door_Frame_'+str(x),(x,1.2,-1.30),(.12,2.4,.15),orange);cube('Door_Panel_'+str(x),(x,1.2,-1.20),(.08,2.2,.08),wall);cube('Door_Window_'+str(x),(x,1.65,-1.14),(.09,.5,.03),glass)
# console, pipes, vents
for x in [-4.7,4.7]: cube('Wall_Console_'+str(x),(x,1.1,-1.18),(.6,.65,.25),floor);cube('Console_Screen_'+str(x),(x,1.3,-1.03),(.38,.25,.03),glass)
for z in [-.7,.7]: cube('Ceiling_Pipe_'+str(z),(0,2.78,z),(11,.08,.08),orange)

# --- Detalhe adicional v0.1.116: juntas, rodapés, grelhas, cablagem e controlos ---
steel=mat('Machined_Trim',(.34,.42,.45),.62,.38); warning=mat('Hazard_Yellow',(.98,.57,.06),.15,.5); red=mat('Alarm_Red',(.75,.025,.012),.15,.25)
def detail_box(n,loc,dim,ma,bevel=.02):
 o=cube(n,loc,dim,ma)
 if bevel:
  b=o.modifiers.new('Edge_Bevel','BEVEL'); b.width=bevel; b.segments=2
  o.modifiers.new('Weighted_Normals','WEIGHTED_NORMAL')
 return o
# Floor anti-slip strips and panel joints.
for x in [i*.5 for i in range(-11,12)]:
 detail_box('Floor_Grip_Stripe_%s'%str(x).replace('.','_'),(x,.105,0),(.025,.012,2.8),steel,.003)
for x in [-5,-3,-1,1,3,5]:
 for z in [-1.2,1.2]:
  detail_box('Wall_Seam_%s_%s'%(x,z),(x,1.55,z),(.035,2.82,.025),steel,.004)
# Ceiling ventilation panels with slats.
for x in [-4,0,4]:
 detail_box('Ceiling_Vent_Frame_%s'%x,(x,3.02,0),(.9,.04,.65),floor,.015)
 for j in range(5): detail_box('Ceiling_Vent_Slat_%s_%02d'%(x,j),(x,3.045,-.25+j*.125),(.78,.025,.035),steel,.004)
# Utility cabinets, labels and red emergency call buttons.
for x in [-4.5,-1.5,1.5,4.5]:
 side=-1 if x<0 else 1
 detail_box('Wall_Utility_Cabinet_%s'%x,(x,1.25,side*1.27),(.48,.72,.12),floor,.025)
 detail_box('Cabinet_Label_%s'%x,(x,1.42,side*1.20),(.22,.07,.025),orange,.005)
 detail_box('Emergency_Button_%s'%x,(x+.14,1.1,side*1.19),(.075,.075,.035),red,.01)
# Door warning borders, hinges and handles.
for x in [-3,3]:
 for y in [.35,2.0]:
  detail_box('Door_Hinge_%s_%s'%(x,y),(x,y,-1.235),(.09,.22,.05),steel,.01)
 detail_box('Door_Handle_%s'%x,(x+.24,1.15,-1.145),(.045,.3,.045),orange,.008)
 for j in range(6): detail_box('Door_Warning_Mark_%s_%02d'%(x,j),(x-.32+j*.13,.17,-1.12),(.07,.025,.025),warning,.002)
# Cable trays, clamps and service pipes along the ceiling.
for z in [-.95,.95]:
 detail_box('Ceiling_Cable_Tray_%s'%z,(0,2.87,z),(10.5,.09,.18),steel,.015)
 for x in range(-5,6): detail_box('Cable_Tray_Clamp_%s_%s'%(z,x),(x,2.81,z),(.07,.08,.25),orange,.008)

bpy.ops.object.select_all(action='SELECT');bpy.ops.wm.save_as_mainfile(filepath=os.path.join(assets,'station_interior_modular.blend'));bpy.ops.export_scene.gltf(filepath=os.path.join(assets,'station_interior_modular.glb'),export_format='GLB',use_selection=True);print('Interior .blend e GLB exportados')

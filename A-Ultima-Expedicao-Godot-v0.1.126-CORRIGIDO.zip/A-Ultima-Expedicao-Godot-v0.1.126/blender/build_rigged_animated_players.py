# A Última Expedição — Rig funcional e animações dos jogadores
# Blender 4.x: abrir Blender > Scripting > Open > Run Script.
# Gera .blend editável e GLB com armature, animações Idle/Walk/Run e 8 variantes.
import bpy, math, os
from mathutils import Vector
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'assets'))
os.makedirs(ROOT, exist_ok=True)
# Limpeza
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for datablocks in (bpy.data.meshes, bpy.data.curves, bpy.data.materials, bpy.data.armatures, bpy.data.actions):
    pass

def material(name, color, metallic=0.0, rough=0.72):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    bs=m.node_tree.nodes.get('Principled BSDF'); bs.inputs['Base Color'].default_value=(*color,1); bs.inputs['Metallic'].default_value=metallic; bs.inputs['Roughness'].default_value=rough
    return m
fabric=material('Suit_Teal',(.06,.19,.22)); orange=material('Rescue_Orange',(1,.22,.035)); dark=material('Equipment_Dark',(.025,.04,.05)); visor=material('Visor_Glass',(.04,.18,.23),.55,.22); skin=material('Skin',(.42,.25,.17)); metal=material('Metal',(.42,.48,.48),.5,.35)
# Armature: hierarchy for full body movement
bpy.ops.object.armature_add(enter_editmode=True, location=(0,0,0)); arm=bpy.context.object; arm.name='Player_Armature'; arm.data.name='Player_Skeleton'; eb=arm.data.edit_bones
root=eb[0]; root.name='Root'; root.head=(0,0.05,0); root.tail=(0,.35,0)
def bone(n,h,t,p):
 b=eb.new(n); b.head=h; b.tail=t; b.parent=eb.get(p); return b
bone('Spine',(0,.35,0),(0,1.58,0),'Root'); bone('Head',(0,1.58,0),(0,2.38,0),'Spine')
bone('Arm.L',(-.38,1.75,0),(-.58,1.05,0),'Spine'); bone('Arm.R',(.38,1.75,0),(.58,1.05,0),'Spine')
bone('Leg.L',(-.23,.95,0),(-.23,.12,0),'Root'); bone('Leg.R',(.23,.95,0),(.23,.12,0),'Root')
bpy.ops.object.mode_set(mode='OBJECT')
# assign every generated rigid mesh to a bone vertex group so it follows the rig
def part(name, loc, dims, mat, bone_name, kind='cube'):
 if kind=='sphere': bpy.ops.mesh.primitive_uv_sphere_add(segments=16, ring_count=12, location=loc)
 elif kind=='cylinder': bpy.ops.mesh.primitive_cylinder_add(vertices=16, radius=dims[0], depth=dims[1], location=loc)
 else: bpy.ops.mesh.primitive_cube_add(size=1, location=loc)
 o=bpy.context.object; o.name=name
 if kind=='cube': o.dimensions=dims; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 elif kind=='sphere': o.scale=dims; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
 o.data.materials.append(mat)
 vg=o.vertex_groups.new(name=bone_name); vg.add(list(range(len(o.data.vertices))),1.0,'REPLACE')
 mod=o.modifiers.new('Armature_Deform','ARMATURE'); mod.object=arm
 return o
# legs and boots
for s,x,bn in [('L',-.23,'Leg.L'),('R',.23,'Leg.R')]:
 part('Boot.'+s,(x,.14,.10),(.34,.40,.50),dark,bn)
 part('Trouser.'+s,(x,.57,0),(.30,.65,.30),fabric,bn)
# torso, belt, arms, head and equipment
part('Torso',(0,1.40,0),(.72,.88,.40),fabric,'Spine','sphere')
part('Chest_Rescue_Panel',(0,1.52,.215),(.40,.25,.045),orange,'Spine')
part('Belt',(0,1.02,0),(.67,.14,.38),dark,'Spine')
for s,x,bn in [('L',-.48,'Arm.L'),('R',.48,'Arm.R')]:
 part('Sleeve.'+s,(x,1.42,0),(.25,.67,.28),fabric,bn,'sphere'); part('Glove.'+s,(x*1.18,1.05,.02),(.18,.20,.20),dark,bn,'sphere')
part('Neck',(0,1.88,0),(.14,.18,.14),skin,'Head','cylinder')
part('Head_Mesh',(0,2.10,0),(.24,.30,.22),skin,'Head','sphere')
part('Helmet',(0,2.30,0),(.31,.22,.29),orange,'Head','sphere')
part('Visor',(0,2.13,.19),(.30,.13,.045),visor,'Head')
part('Helmet_Lamp',(0,2.38,.23),(.10,.06,.05),metal,'Head')
part('Backpack',(0,1.43,-.29),(.42,.56,.22),dark,'Spine')
part('Backpack_Orange',(0,1.70,-.30),(.30,.13,.24),orange,'Spine')
part('Radio',(.38,1.34,-.07),(.12,.22,.10),dark,'Spine')

# --- Detalhe adicional v0.1.116: bolsos, faixas refletoras, costuras e fechos ---
reflective=material('Reflective_Silver',(.72,.80,.78),.45,.3)
stitch=material('Suit_Stitching',(.18,.34,.36),.05,.8)
for s,x,bn in [('L',-.23,'Leg.L'),('R',.23,'Leg.R')]:
 part('Reflective_Ankle_Band.'+s,(x,.38,.02),(.34,.055,.32),reflective,bn)
 part('Knee_Patch.'+s,(x,.72,.17),(.23,.18,.045),dark,bn)
for s,x,bn in [('L',-.48,'Arm.L'),('R',.48,'Arm.R')]:
 part('Reflective_Forearm_Band.'+s,(x*1.12,1.23,.02),(.27,.065,.30),reflective,bn,'sphere')
 part('Sleeve_Patch.'+s,(x*1.08,1.52,.14),(.13,.13,.035),orange,bn)
for s,x in [('L',-.20),('R',.20)]:
 part('Chest_Pocket.'+s,(x,1.47,.205),(.16,.18,.045),dark,'Spine')
 part('Chest_Pocket_Flap.'+s,(x,1.54,.23),(.17,.05,.025),orange,'Spine')
for i,x in enumerate([-.22,0,.22]):
 part('Belt_Buckle_%02d'%i,(x,1.02,.205),(.065,.09,.04),metal,'Spine')
part('Backpack_Side_Pocket.L',(-.25,1.42,-.39),(.12,.24,.12),dark,'Spine')
part('Backpack_Side_Pocket.R',(.25,1.42,-.39),(.12,.24,.12),dark,'Spine')

# animations: pose rotations in radians, all bone keyframes are exported in glTF
pose_bones=arm.pose.bones
for action_name, frames, amplitude in [('Idle',[1,20,40],.025),('Walk',[1,11,21],.55),('Run',[1,8,15],.9)]:
 act=bpy.data.actions.new(action_name); arm.animation_data_create(); arm.animation_data.action=act
 for pb in pose_bones: pb.rotation_mode='XYZ'
 for f in frames:
  phase=(f-1)/(frames[-1]-1)*2*math.pi
  for name in ['Arm.L','Arm.R','Leg.L','Leg.R']:
   pb=pose_bones.get(name)
   if not pb: continue
   sign=-1 if name.endswith('.L') else 1
   if action_name=='Idle': val=amplitude*math.sin(phase)
   elif name.startswith('Leg'): val=sign*amplitude*math.sin(phase)
   else: val=-sign*amplitude*math.sin(phase)
   pb.rotation_euler[0]=val; pb.keyframe_insert(data_path='rotation_euler',frame=f,group=name)
  pose_bones['Spine'].rotation_euler[2]=.015*math.sin(phase); pose_bones['Spine'].keyframe_insert(data_path='rotation_euler',frame=f,group='Spine')
 act.use_fake_user=True
# restore neutral pose and save source project
arm.animation_data.action=bpy.data.actions.get('Idle'); bpy.context.scene.frame_start=1; bpy.context.scene.frame_end=40; bpy.context.scene.render.fps=24
bpy.ops.object.select_all(action='DESELECT'); arm.select_set(True); bpy.context.view_layer.objects.active=arm
blend_path=os.path.join(ROOT,'player_expedition_rigged.blend'); bpy.ops.wm.save_as_mainfile(filepath=blend_path)
# Export rig + geometry and actions. Godot can select animation by name after import.
bpy.ops.object.select_all(action='DESELECT')
for o in bpy.context.scene.objects:
 if o.type in {'MESH','ARMATURE'}: o.select_set(True)
bpy.context.view_layer.objects.active=arm
glb_path=os.path.join(ROOT,'player_expedition_rigged.glb')
bpy.ops.export_scene.gltf(filepath=glb_path, export_format='GLB', use_selection=True, export_animations=True, export_skins=True, export_morph=True, export_materials='EXPORT')
print('OK: fonte Blender:',blend_path); print('OK: GLB rigged:',glb_path); print('Ações incluídas: Idle, Walk, Run')

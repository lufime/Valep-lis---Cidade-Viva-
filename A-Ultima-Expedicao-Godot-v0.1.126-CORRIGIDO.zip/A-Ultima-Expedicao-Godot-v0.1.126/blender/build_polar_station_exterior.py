# A Última Expedição — Exterior da estação polar
# Abrir no Blender > Scripting > Run Script. Exporta assets/polar_station_exterior.glb.
import bpy, math, os
from mathutils import Vector
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
def material(name, color, metallic=0.15, roughness=0.78):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    bs=m.node_tree.nodes.get("Principled BSDF"); bs.inputs["Base Color"].default_value=(*color,1)
    bs.inputs["Metallic"].default_value=metallic; bs.inputs["Roughness"].default_value=roughness
    return m
snow=material("Snow_Ice",(0.78,0.88,0.92)); ice=material("Blue_Ice",(0.22,0.43,0.54))
metal=material("Station_Composite",(0.22,0.29,0.33)); dark=material("Dark_Metal",(0.07,0.10,0.13))
orange=material("Emergency_Orange",(0.92,0.28,0.08)); window=material("Frosted_Window",(0.12,0.45,0.58))
rock=material("Basalt_Rock",(0.17,0.20,0.23))
def cube(name, loc, scale, mat):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc); o=bpy.context.object; o.name=name
    o.dimensions=scale; bpy.ops.object.transform_apply(location=False, rotation=False, scale=True); o.data.materials.append(mat); return o
def cyl(name, loc, radius, depth, mat):
    bpy.ops.mesh.primitive_cylinder_add(vertices=12, radius=radius, depth=depth, location=loc); o=bpy.context.object; o.name=name; o.data.materials.append(mat); return o
def ico(name, loc, scale, mat):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=1, radius=1, location=loc); o=bpy.context.object; o.name=name; o.scale=scale; o.data.materials.append(mat); return o
cube("Snow_Base",(0,-.5,0),(46,.8,46),snow)
cube("Station_Main_Hull",(0,2,0),(16,4.2,8),metal); cube("Station_Roof",(0,4.32,0),(16.6,.45,8.6),dark)
cube("Front_Safety_Band",(0,1.15,4.06),(16.05,.35,.12),orange)
cube("Main_Airlock",(0,1.35,4.12),(2,2.6,.22),dark); cube("Airlock_Window",(0,1.85,4.25),(.8,.9,.05),window)
for x in [-6,-3,3,6]: cube("Front_Window_"+str(x),(x,2.55,4.12),(1.5,1,.12),window)
cube("Laboratory_Module",(10.5,1.5,-1.5),(6,3.2,5),metal); cube("Lab_Roof",(10.5,3.25,-1.5),(6.4,.35,5.4),dark)
cube("Lab_Window",(10.5,2,1.05),(2.2,1,.1),window)
cyl("Antenna_Mast",(-7,4.2,-3),.12,8,dark)
for y in [5.5,7,8]: cube("Antenna_Crossbar_"+str(y),(-7,y,-3),(2.4,.12,.12),orange)
cyl("Dish_Post",(7,5.1,-2),.08,2,dark)
for x in [-8,8]:
    cyl("Lamp_Post_"+str(x),(x,1.5,5.5),.09,3,dark); cube("Lamp_Head_"+str(x),(x,3.05,5.5),(.55,.18,.35),orange)
for i,(x,z) in enumerate([(-11,2),(-11,4),(-9,3),(13,-3),(13,-5)]): cube("Supply_Crate_"+str(i),(x,.6,z),(1.3,1.2,1.2),orange if i%2==0 else metal)
for i,x in enumerate([-4,4]): cube("Generator_"+str(i),(x,.6,-6),(2,1.2,1.5),dark)
for i,(x,z,s) in enumerate([(-18,-12,2.5),(-16,9,2.2),(18,12,3),(19,-8,2.6),(-13,-18,2.4),(10,18,2),(-20,2,2.2),(4,-19,2.8)]): ico("Snow_Rock_"+str(i),(x,s*.25,z),(s*1.3,s*.65,s),rock if i%2 else snow)
for i,(x,z) in enumerate([(-20,-18),(-14,-21),(-4,-21),(8,-21),(17,-17),(21,-7),(21,8),(16,21),(-18,19)]): ico("Ice_Ridge_"+str(i),(x,.2,z),(2.2,1.5,3.2),ice)

# --- Detalhe adicional v0.1.116: painéis, fixações, grelhas, cabos e sinalética ---
steel_detail=material("Panel_Edge_Steel",(0.36,0.43,0.46),.62,.38)
warning=material("Hazard_Stripe_Yellow",(0.98,.57,.06),.18,.5)
red=material("Status_Light_Red",(.8,.025,.012),.25,.28)
blue=material("Status_Light_Cyan",(.04,.55,.78),.35,.25)
def detail_cube(name, loc, dims, ma, bevel=0.035):
    ob=cube(name,loc,dims,ma)
    if bevel:
        mod=ob.modifiers.new("Soft_Machined_Edges","BEVEL"); mod.width=bevel; mod.segments=2
        ob.modifiers.new("Weighted_Corner_Normals","WEIGHTED_NORMAL")
    return ob
def detail_cylinder(name, loc, radius, depth, ma, vertices=12):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc)
    ob=bpy.context.object; ob.name=name; ob.data.materials.append(ma); return ob
# Repeating external service panels and bolts along the station front.
for idx,x in enumerate([-6.6,-4.8,-2.4,0,2.4,4.8,6.6]):
    detail_cube("Hull_Service_Panel_%02d"%idx,(x,2.0,4.105),(.82,1.15,.045),steel_detail,.025)
    detail_cube("Panel_Label_Slot_%02d"%idx,(x,2.26,4.137),(.36,.055,.018),dark,.008)
    for dx in [-.31,.31]:
        for dy in [-.43,.43]: detail_cylinder("Panel_Fastener_%02d"%idx,(x+dx,2.0+dy,4.145),.035,.025,orange,8)
# Airlock hazard markings, door handles and threshold.
detail_cube("Airlock_Threshold",(0,.63,4.28),(2.35,.10,.32),steel_detail,.025)
for x in [-.85,-.55,-.25,.05,.35,.65,.95]:
    stripe=detail_cube("Airlock_Hazard_Stripe_%s"%str(x).replace('.','_'),(x,.70,4.45),(.12,.018,.025),warning,.004)
    stripe.rotation_euler[1]=-.28
detail_cube("Airlock_Handle_Left",(-.73,1.28,4.28),(.055,.38,.055),steel_detail,.012)
detail_cube("Airlock_Handle_Right",(.73,1.28,4.28),(.055,.38,.055),steel_detail,.012)
# Vents and louvers on laboratory side walls.
for side in [-1,1]:
    for i in range(5):
        detail_cube("Lab_Vent_Louver_%s_%02d"%(side,i),(10.5+side*3.08,1.1+i*.17,-1.5),(.045,.055,1.25),steel_detail,.01)
# Exterior utility conduit: curves remain real geometry on export.
def detail_pipe(name, points, radius, ma):
    curve=bpy.data.curves.new(name+"_Curve",'CURVE'); curve.dimensions='3D'; curve.resolution_u=2
    curve.bevel_depth=radius; curve.bevel_resolution=2
    spl=curve.splines.new('POLY'); spl.points.add(len(points)-1)
    for p,co in zip(spl.points,points): p.co=(*co,1)
    ob=bpy.data.objects.new(name,curve); bpy.context.collection.objects.link(ob); ob.data.materials.append(ma); return ob
detail_pipe("Exterior_Cable_Run",[(-7,3.6,4.3),(-7,3.0,4.3),(-5,3.0,4.3),(-5,2.8,4.3)],.035,orange)
detail_pipe("Lab_Conduit",[(7.6,1.0,-4.05),(8.2,.85,-4.05),(8.2,.85,-2.8),(10.5,.85,-2.8)],.045,steel_detail)
# Antenna signal lamps and small support brackets.
for idx,y in enumerate([6.2,7.0,7.8]): detail_cylinder("Antenna_Status_Light_%02d"%idx,(-7,y,-2.92),.075,.08,red if idx==0 else blue)
for x in [-8,8]:
    detail_cube("Lamp_Base_%s"%x,(x,.12,5.5),(.48,.18,.48),steel_detail,.04)
# Surface breakup: shallow snow drifts and small ice chunks, kept away from main doors.
for i,(x,z,s) in enumerate([(-22,-7,1.1),(-21,13,1.3),(-14,14,.9),(14,15,1.0),(22,2,1.2),(19,-14,.8),(-5,-22,1.0),(5,20,.8)]):
    ico("Snow_Drift_Detail_%02d"%i,(x,.05,z),(s*1.6,s*.35,s),snow)

# Guardar fonte editável e exportar GLB para assets/
root=os.path.abspath(os.path.join(os.path.dirname(__file__),'..'))
assets=os.path.join(root,'assets'); os.makedirs(assets,exist_ok=True)
blend_out=os.path.join(assets,'polar_station_exterior.blend')
glb_out=os.path.join(assets,'polar_station_exterior.glb')
bpy.ops.object.select_all(action='SELECT')
bpy.ops.wm.save_as_mainfile(filepath=blend_out)
bpy.ops.export_scene.gltf(filepath=glb_out, export_format='GLB', use_selection=True, export_materials='EXPORT')
print('BLEND_OUTPUT=',blend_out)
print('GLB_OUTPUT=',glb_out)

# A Última Expedição — V0.1.106

- Encerramento da missão apresentado como **EXTRAÇÃO CONFIRMADA**.
- A extração exige relés A e B ativos, energia restabelecida, 10 provas recolhidas, combinação VANTHIS validada e arquivo confidencial aberto.
- O terminal apresenta as tarefas em falta quando a missão ainda não está pronta para terminar.
- O modo individual permite concluir os objetivos sem depender de outro jogador; no multijogador, a validação é feita pelo servidor.
- A cena final mantém em aberto o destino da experiência VANTHIS.

## Validação honesta

O pacote ZIP pode ser verificado estruturalmente, mas o Godot 4.5 não está disponível neste ambiente. Não declarar compilação, execução nem teste multijogador como aprovados sem os executar.


## V0.1.84 — integração fisiológica
- A pulsação responde ao movimento, exposição ao frio, saúde baixa e captura.
- A saúde diminui após exposição prolongada ao exterior e recupera lentamente no interior.
- Saúde abaixo de 55% e 25% reduz progressivamente a velocidade de movimento.
- Saúde a 0% incapacita o jogador e apresenta um aviso de falha fisiológica no HUD.
- A barra de saúde muda de cor conforme a gravidade.
- Verificação realizada: inspeção estática dos scripts e integridade do ZIP. Compilação/runtime Godot 4.5 ainda por executar.


## V0.1.93 — etiquetas de teste de interação
- Etiquetas 3D sobre as 10 pistas recolhíveis: `PISTA NN · INTERAGIR`.
- Etiquetas sobre os relés cooperativos, consola de síntese, terminal de extração, porta experimental e painéis do abrigo.
- Etiquetas usam billboard, contorno escuro e texto contrastante para leitura no cenário 3D.
- Objetivo: facilitar testes funcionais no jogo; estas etiquetas identificam elementos interativos e não substituem a ação real de interação.
- Validação feita: inspeção estática das inserções e integridade do ZIP. Godot 4.5/runtime não executado neste ambiente.

## V0.1.94 — Dossier de investigação
- Adicionado dossier interativo para consultar provas recolhidas.
- Comparação lado a lado de duas provas, com relações possíveis, contradições e próximos passos.
- O dossier só apresenta provas já recolhidas e não declara hipóteses como factos confirmados.


## V0.1.95 — auditoria lógica e validação de interações
- A recolha de provas passa a exigir proximidade física validada no servidor.
- A combinação VANTHIS só é validada quando o jogador está junto da consola.
- A porta do arquivo secreto exige interação junto da porta e pré-requisitos concluídos.
- A conclusão da extração é protegida para ser decidida pelo servidor no multijogador.
- Auditoria estática alargada; não equivale a teste de runtime, rede real ou APK.


## V0.1.96 — votação coerente no multijogador
- A decisão aguarda um voto de cada jogador atualmente ligado, em vez de terminar automaticamente após dois votos.
- O servidor rejeita votos de IDs que não pertencem à sessão ativa.
- Quando um participante sai, o seu voto é removido e o quórum é recalculado para evitar bloqueios.
- A auditoria estática inclui verificações específicas destas regras; testes de runtime Godot continuam pendentes.


## V0.1.104 — correções visuais após análise de vídeo
- Removido o modelo visual do jogador local na perspetiva de primeira pessoa para evitar que a geometria do próprio corpo ocupe a câmara; o corpo físico e a colisão mantêm-se.
- O minimapa utiliza melhor a área do painel em ecrãs móveis e foi aumentado para facilitar a leitura.
- Removida a ligação duplicada do sinal `finished` nos emissores de som 3D.
- Verificação realizada: auditoria estática do projeto e integridade do ZIP. Godot 4.5, runtime, multijogador e APK não foram executados nesta validação.


## V0.1.106 — passe de qualidade visual móvel
- Ajuste moderado da luz ambiente para maior contraste sem ativar efeitos pesados incompatíveis com telemóveis.
- Adicionados ecrãs emissivos de consola, botões/indicadores, marcação visual de segurança na saída e fixações metálicas decorativas sem colisão.
- Mantida a configuração do renderizador Mobile e a escala 3D existente para evitar uma regressão de desempenho não medida.
- Validação: auditoria estática e integridade do ZIP; Godot runtime e FPS Android não executados.


## Fase gráfica V0.1.107 — kit modular GLB

Foi acrescentado `assets/station_corridor_kit.glb`, um conjunto modular de detalhe industrial de baixo custo (painéis de serviço, grelhas de ventilação, condutas, indicadores luminosos e marcações de segurança). O recurso é instanciado em quatro segmentos da estação através de `scripts/expedition.gd`. As peças são decorativas e não acrescentam colisões, para preservar a circulação e a lógica de interação.

O GLB foi gerado programaticamente como recurso 3D compatível com o fluxo Blender/GLB; não foi executado Blender nesta sessão. Para validar materiais e escala visual, importar/abrir o projeto no Godot 4.5 e verificar no dispositivo Android continua pendente.


## Alterações v0.1.126 — interface e mapa tático
- Reorganização visual do minimapa para representar o percurso cíclico aprovado, com duas entradas identificadas e sala secreta central (provas 13–15).
- Aumentada a área do painel do mapa para melhorar a leitura em ecrãs móveis.
- Nota de validação: esta alteração atualiza a representação do mapa; a geometria 3D e a navegação física em ciclo ainda necessitam de validação/correção no motor Godot antes de se considerar a funcionalidade concluída.
